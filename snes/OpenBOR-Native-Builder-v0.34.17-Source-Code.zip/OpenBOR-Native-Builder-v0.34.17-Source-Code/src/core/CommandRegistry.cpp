#include "CommandRegistry.hpp"
#include <algorithm>
#include <cctype>
#include <string>

namespace {
std::string lower(std::string_view in){
    std::string s(in);
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return (char)std::tolower(c); });
    return s;
}
CommandInfo make(bool parser, bool runtime, const char* note, CommandStatus overrideStatus = CommandStatus::Unknown){
    CommandInfo info;
    info.parser = parser;
    info.runtime = runtime;
    info.note = note;
    if(overrideStatus != CommandStatus::Unknown) info.status = overrideStatus;
    else if(parser && runtime) info.status = CommandStatus::Supported;
    else if(parser && !runtime) info.status = CommandStatus::Partial;
    else info.status = CommandStatus::Unknown;
    return info;
}
}

const char* CommandRegistry::statusName(CommandStatus status){
    switch(status){
        case CommandStatus::Supported: return "SUPPORTED";
        case CommandStatus::Partial: return "PARTIAL";
        case CommandStatus::Unsupported: return "UNSUPPORTED";
        case CommandStatus::IgnoredSafely: return "IGNORED_SAFELY";
        case CommandStatus::Unknown: return "UNKNOWN";
    }
    return "UNKNOWN";
}

CommandInfo CommandRegistry::lookup(std::string_view command){
    const std::string c = lower(command);
    auto attackN = c.rfind("attack", 0) == 0 && c.size() > 6 && std::all_of(c.begin()+6,c.end(),[](unsigned char ch){return std::isdigit(ch);});
    if(c=="name"||c=="type"||c=="subtype"||c=="health"||c=="speed"||c=="runspeed"||c=="jumpheight"||c=="jumpmove")
        return make(true,true,"Model property applied to the generated entity.");
    if(c=="anim"||c=="frame"||c=="delay"||c=="offset"||c=="loop"||c=="move"||c=="movez"||c=="movea"||c=="sound"||c=="flipframe")
        return make(true,true,"Animation command executed by the native animation player.");
    if(c=="blast"||c=="burn"||c=="shock") return make(true,true,"Legacy special attack boxes preserve their attack type, drop flag and basic reaction selection. Palette and specialized damage effects remain partial.", CommandStatus::Partial);
    if(c=="landframe") return make(true,true,"Ground contact resumes the configured landing frame through its remaining delays and spawns the optional named dust model once.");
    if(c=="shadow") return make(true,true,"OpenBOR shadow 0-6 is rendered under native actors, using original shadow sprites when present and a safe fallback otherwise.");
    if(c=="diesound"||c=="lifespan") return make(true,true,"Native entity lifecycle executes lifespan expiry and death audio.");
    if(c=="energycost"||c=="mpcost"||c=="mponly") return make(true,true,"Animation activation checks and consumes MP/HP by resource mode without splitting the cost. Type disable rules apply; deferred costs are controlled separately by nocost.");
    if(c=="nocost") return make(true,true,"Melee energy cost is deferred until an animation with contact finishes; misses are free. Projectile ownership, smartbomb and resource changes during deferred cost remain partial.",CommandStatus::Partial);
    if(c=="defense") return make(true,true,"Per-attack-type damage, pain, knockdown resistance, block power/threshold, chip ratio and block resource routing are translated to native runtime rules with models.txt global fallbacks.", CommandStatus::Partial);
    if(c=="knockdowncount") return make(true,true,"Model knockdown meter threshold is consumed by the native hit/knockdown runtime.");
    if(c=="bbox"||c=="attack"||c=="attack1"||c=="attack2"||c=="attack3"||c=="fall"||c=="dropv"||c=="pausetime"||c=="guardcost"||c=="noblock"||c=="jugglecost"||c=="attack.tag"||c=="attack.block.cost"||c=="attack.block.penetrate"||c=="attack.reaction.pause.time")
        return make(true,true,"Per-frame hit/attack data. attack4+ is parsed; only 1-3 are bound to default controls.");
    if(attackN) return make(true,true,"Numbered attack collision boxes preserve damage type and run through native damage, defense, reaction and combo rules.");
    if(c=="attackone") return make(true,true,"attackone is preserved per animation and enforced for player, coop and projectile attacks; enemy multi-target parity when attackone=0 remains partial.",CommandStatus::Partial);
    if(c=="drawmethod")
        return make(true,true,"Scale/flip/rotate/shift/fill, alpha modes 1-6 and tint mode/color are executed by the software compositor. Indexed palette LUT remap remains partial.", CommandStatus::Partial);
    if(c=="nodrawmethod")
        return make(true,true,"Resets inherited frame drawmethod state to the native default renderer.");
    if(c=="blockratio"||c=="mpblock"||c=="nochipdeath")
        return make(true,true,"models.txt global blocking rules are applied natively: quarter chip damage, MP-first chip routing and optional non-lethal chip damage.", CommandStatus::Supported);
    if(c=="jugglepoints"||c=="grabdistance"||c=="grabin"||c=="knife"||c=="bomb"||c=="project"||c=="blockodds"||c=="blockpain"||c=="thold"||c=="blockthreshold"||c=="guardpoints"||c=="guardrate"||c=="blockback")
        return make(true,true,"Combat/projectile/blocking model properties used by the native runtime.");
    if(c=="candamage"||c=="hostile")
        return make(true,true,"Canonical textual OpenBOR type masks are parsed and applied independently to native intentional targeting and hit permission, including entity-vs-entity combat and ScriptVM findtarget.");
    if(c=="aggression")
        return make(true,true,"Enemy aggression adjusts native attack reaction delay: positive values react faster and negative values react slower.");
    if(c=="aiattack"||c=="aimove"||c=="projectilehit")
        return make(true,true,"OpenBOR AI/projectile metadata influences native movement, attack selection and projectile targets; uncommon legacy bit-layout modes remain partial.", CommandStatus::Partial);
    if(c=="cantgrab"||c=="notgrab")
        return make(true,true,"OpenBOR v7533 legacy grab tuning: value 2 sets grab force to -999999; other values set resistance to 1. Later force/resistance directives override in source order.");
    if(c=="nograb"||c=="grabforce"||c=="grabresistance"||c=="grab_resistance"||c=="antigrab"||c=="throwdamage"||c=="throwdist"||c=="throwheight")
        return make(true,true,"Native grab/throw resolution consumes these model values; uncommon legacy grab edge cases remain partial.", CommandStatus::Partial);
    if(c=="bounce")
        return make(true,true,"Bounce count is applied to projectile and falling-entity ground contacts.", CommandStatus::Partial);
    if(c=="bouncefactor")
        return make(true,true,"Bounce velocity multiplier is preserved without the former native upper clamp for projectiles and falling entities.");
    if(c=="subject_to_gravity"||c=="subjecttogravity")
        return make(true,true,"Controls free-fall gravity for runtime entities/projectiles while explicit knockdown launches still fall by attack reaction.");
    if(c=="antigravity")
        return make(true,true,"Legacy antigravity is normalized to a gravity multiplier and applied to actors and projectiles.");
    if(c=="nopain")
        return make(true,true,"Suppresses native pain reactions while still allowing damage and knockdown.");
    if(c=="nodrop")
        return make(true,true,"Prevents automatic weapon drops caused by damage, knockdown or death.");
    if(c=="subject_to_hole")
        return make(true,true,"Controls whether actors are affected by stage holes.");
    if(c=="subject_to_wall")
        return make(true,true,"Players, coop and entities share trapezoid wall collision with world-height checks and wall-over-hole masking. Landing on wall tops and dynamic platforms remain partial.",CommandStatus::Partial);
    if(c=="nomove")
        return make(true,true,"Legacy movement and facing constraints: blocks voluntary/AI movement and fall reactions, with advanced OpenBOR movement exceptions remaining partial.",CommandStatus::Partial);
    if(c=="offscreenkill")
        return make(true,true,"Entities beyond the configured offscreen distance are removed by the native runtime.");
    if(c=="noquake")
        return make(true,true,"Suppresses quakeframe screen shake for the model.");
    if(c=="nodieblink")
        return make(true,false,"Legacy death-blink flag is parsed. The compact runtime does not emulate every historical blink cadence.", CommandStatus::Partial);
    if(c=="falldie"||c=="death")
        return make(true,false,"Legacy death/fall mode is parsed; immediate/fall selection is preserved while multi-stage fall-then-death timing remains partial.", CommandStatus::Partial);
    if(c=="risetime"||c=="riseattacktype")
        return make(true,true,"Knockdown recovery delay and attack-type-aware rise selection are mapped to the native recovery runtime.", CommandStatus::Partial);
    if(c=="fmap")
        return make(true,false,"Legacy freeze-map metadata is preserved; indexed palette freeze semantics remain partial.", CommandStatus::Partial);
    if(c=="remove")
        return make(true,true,"Native projectiles use the legacy remove flag (default 1); remove 0 preserves them after impact, with per-target hit tracking. Bomb contact selects attack2 and ground contact selects attack1. Advanced historical hit-ID modes remain partial.", CommandStatus::Partial);
    if(c=="throw")
        return make(true,false,"Legacy throw model flag is preserved; native grab/throw uses throwdamage/throwdist/throwheight.", CommandStatus::Partial);
    if(c=="no_adjust_base")
        return make(true,false,"Base-adjust metadata is preserved. The native renderer already uses explicit offsets/altitude, so uncommon legacy base adjustment remains partial.", CommandStatus::Partial);
    if(c=="jumpframe"||c=="throwframe"||c=="shootframe"||c=="pshotframe"||c=="tossframe"||c=="custknife"||c=="custbomb"||c=="custpbomb")
        return make(true,true,"Projectile spawn frames.");
    if(c=="seta")
        return make(true,true,"Frame altitude is applied natively and persists with inherited frame state until animation state changes.");
    if(c=="quakeframe")
        return make(true,true,"Animation frame triggers deterministic native screen shake with loop/intensity metadata.");
    if(c=="hitfx")
        return make(true,true,"Animation-specific hit sound is played when the attack connects.");
    if(c=="damageonlanding")
        return make(true,true,"Landing damage from an attack box is applied once on the victim's first ground contact after knockdown. Named normal/blast/burn/freeze/shock/steal types are parsed; blast landing mode and advanced death/defense effects remain partial.",CommandStatus::Partial);
    if(c=="hitflash"||c=="attack.effect.hit.flash.model")
        return make(true,true,"Per-frame hit effect model spawns at collision overlap, respects noflash/noatflash and ends with its animation. Advanced collision flash layers are separate commands.");
    if(c=="flash"||c=="bflash"||c=="blockflash"||c=="attack.effect.block.flash.model"||c=="attack.effect.hit.flash.disable"||c=="noflash"||c=="noatflash"||c=="toflip")
        return make(true,true,"Model hit/block flash fallbacks, per-frame block effects, incoming override suppression and effect facing run in the native combat/effect lifecycle.");
    if(c=="modelflag")
        return make(true,true,"Weapon model-copy flags are parsed; no_basic prevents inherited basic animations while no_weapon/no_script are preserved for compatibility analysis.", CommandStatus::Partial);
    if(c=="range"||c=="rangez"||c=="rangea")
        return make(true,true,"Animation activation ranges feed dynamic combostyle=1 branch selection.");
    if(c=="atchain"||c=="combostyle"||c=="combodelay")
        return make(true,true,"Native player/coop combo chains use atchain/combodelay; combostyle=1 selects range branches from animation range/rangez/rangea metadata. Exotic legacy branch layouts remain partial.", CommandStatus::Partial);
    if(c=="com"||c=="cmd")
        return make(true,true,"OpenBOR command sequences use a 128-tick per-player history with press/release, passive hold min/max, auto hold-trigger, chord grace and sequence grace; weapon models can replace the active command list.", CommandStatus::Partial);
    if(c=="followanim"||c=="followcond")
        return make(true,true,"Follow transitions execute from actual hit/block/lethal/grabbable results using OpenBOR followcond 1-5 semantics.");
    if(c=="counterframe"||c=="counterrange")
        return make(true,true,"Counter transitions execute from real hit results and frame windows; uncommon legacy freeze/unblockable combinations remain partial.", CommandStatus::Partial);
    if(c=="cancel")
        return make(true,true,"Animation cancel windows, hit requirements and common OpenBOR input tokens are executed natively.", CommandStatus::Partial);
    if(c=="weapons"||c=="weapnum"||c=="shootnum"||c=="reload"||c=="weapon"||c=="weaponframe"||c=="weaploss"||c=="weapon_loss_index"||c=="weapon_loss_condition"||c=="counter"||c=="typeshot"||c=="animal")
        return make(true,true,"Weapon model swap, limited uses, inherited/overridden weaploss, drop counter and gun depletion behavior are active. Full model-copy/drop animation edge cases remain partial.", CommandStatus::Partial);
    if(c=="subentity"||c=="custentity"||c=="spawnframe"||c=="summonframe"||c=="unsummonframe"||c=="summonkill")
        return make(true,true,"Child entity selection, frame spawning/summoning, screen-relative placement, unsummon and parent-death cleanup execute natively.");
    if(c=="child_follow_offset_x"||c=="child_follow_offset_y"||c=="child_follow_offset_z"||c.rfind("child_follow_range_",0)==0||c.rfind("child_follow_recall_",0)==0||c=="child_follow_direction_adjust_config")
        return make(true,true,"Child follow/recall positioning executes natively; rare legacy interpolation/direction edge cases remain partial.", CommandStatus::Partial);
    if(c=="thinkscript"||c=="updatescript"||c=="animationscript"||c=="takedamagescript"||c=="didhitscript"||c=="ondrawscript"||c=="onspawnscript"||c=="ondeathscript"||c=="onpainscript"||c=="onfallscript"||c=="onpain_script"||c=="onfall_script"||c=="takedamage_script"||c=="didhit_script"||c=="ondraw_script"||c=="onspawn_script"||c=="ondeath_script")
        return make(true,true,"Hook is invoked by ScriptVM. Unmapped APIs inside the script stay PARTIAL.", CommandStatus::Partial);
    if(c=="levelscript")
        return make(true,true,"Level script main() runs once when the native stage loads. Unmapped OpenBOR APIs remain partial.", CommandStatus::Partial);
    if(c=="keyscript"||c=="onmovexscript"||c=="onmovezscript"||c=="onentitycollision")
        return make(true,true,"Hook is fired by ScriptVM. Exact legacy event ordering and unmapped APIs remain partial.", CommandStatus::Partial);
    if(c=="spawnscript")
        return make(true,true,"Spawn-entry script runs after the model onspawn hook with self/spawnx/spawnz/spawny/spawnat locals.", CommandStatus::Partial);
    if(c=="onblockzscript"||c=="onblocksscript"||c=="onblockwscript"||c=="onblockoscript"||c=="didblockscript")
        return make(true,true,"Blocking hook is fired by the native collision/block runtime; uncommon legacy ordering remains partial.", CommandStatus::Partial);
    if(c=="onblockascript"||c=="onblockyscript"||c=="onblockpscript")
        return make(true,false,"Blocking hook is parsed, but platform/overhead exact firing remains partial.");
    if(c=="onkillscript") return make(true,true,"Runs when a runtime entity is actually removed after its death/removal delay.", CommandStatus::Partial);
    if(c=="script"||c=="updatescript") return make(true,true,"Legacy/update entity script is executed each runtime entity update. Unmapped APIs remain partial.", CommandStatus::Partial);
    if(c=="ondoattack"||c=="ondoattackscript")
        return make(true,true,"Hook fires when player, coop, enemy or ScriptVM performattack begins an attack.", CommandStatus::Partial);
    if(c=="onmodelcopy")
        return make(true,true,"onmodelcopy is invoked when a weapon model is applied.", CommandStatus::Partial);
    if(c=="@script")
        return make(true,true,"Inline source is preserved by model/animation and executed on frame entry with frame and animhandle locals; unmapped APIs and rare source-order cases remain partial.", CommandStatus::Partial);
    if(c=="@cmd") return make(true,true,"@cmd is bound to the immediately following animation frame and executed by ScriptVM in source order; unsupported helper APIs remain partial.", CommandStatus::Partial);
    if(c=="@end_script") return make(true,true,"Closes the inline script block whose source is preserved and executed on animation frame entry; unsupported body APIs are reported separately.");
    if(c=="animation") return make(true,true,"Scene animation entries execute natively with original image/GIF path, position, skip policy and decoded frame timing.");
    if(c=="scene") return make(true,true,"levels.txt scene files are attached to the following stage and execute through the native cutscene player; uncommon scene directives outside music/animation remain partial.", CommandStatus::Partial);
    if(c=="bossmusic") return make(true,true,"Boss music switches on the first boss spawn and its byte offset is mapped to the native loop return point.", CommandStatus::Supported);
    if(c=="water") return make(true,true,"Legacy water overlay uses warp as animation speed and honors rock mode with native sine/parallax approximations.", CommandStatus::Partial);
    if(c=="rock") return make(true,true,"Legacy rock mode is parsed and applied to water/stage motion; exact historical camera shake timing remains partial.", CommandStatus::Partial);
    if(c=="set"||c=="file"||c=="z"||c=="music"||c=="background"||c=="panel"||c=="spawn"||c=="coords"||c=="at"||c=="alias"||c=="flip"||c=="boss"||c=="spawn1"||c=="direction"||c=="next")
        return make(true,true,"Stage/spawn command consumed by the generic stage runtime.");
    if(c=="bglayer"||c=="fglayer"||c=="frontpanel")
        return make(true,true,"Layer path, floating scroll ratios, offsets, spacing/repeat and foreground depth are rendered. Water/neon/palette-specific effects remain partial.", CommandStatus::Partial);
    if(c=="wall"||c=="platform"||c=="hole")
        return make(true,true,"Rectangular collision is active. Complex elevation and moving platforms are partial.", CommandStatus::Partial);
    if(c=="wait")
        return make(true,true,"Stage scrolling pauses at the bound `at` point until all active enemies are defeated.");
    if(c=="group")
        return make(true,true,"Persistent OpenBOR group min/max spawning is enforced: once active enemies drop below min, eligible enemy spawns refill up to max.");
    if(c=="blockade"||c=="branch"||c=="end"||c=="endlevel"||c=="scrollx"||c=="scrollspeed"||c=="cameratype"||c=="nojoin")
        return make(true,true,"Stage control is mapped to native runtime state; unusual legacy ordering and a few frontend edge cases remain partial.", CommandStatus::Partial);
    if(c=="item"||c=="map"||c=="health"||c=="score")
        return make(true,true,"Spawn properties.");
    if(c=="video"||c=="videomode"||c=="hresolution"||c=="vresolution")
        return make(true,true,"Logical resolution is detected from video.txt instead of assuming 320x240.");
    if(c=="palette"||c=="alternatepal"||c=="remap"||c=="colourmap"||c=="colormap")
        return make(true,true,"Palette/remap is applied at runtime from image or ACT palette references. Duplicate-color/index-only edge cases remain partial.", CommandStatus::Partial);
    if(c=="load")
        return make(true,true,"models.txt load entry registers the external model name and source file used by native spawns.");
    if(c=="know")
        return make(true,true,"models.txt know entry registers the model name/path in the native registry while asset decoding remains lazy until the model is actually used.");
    if(c=="mp") return make(true,true,"Model maximum MP is emitted and consumed by player, coop, entities, blocking and energy-cost rules.");
    if(c=="select") return make(true,false,"Recognized menu command; selection metadata remains partially mapped.");
    if(c=="icon") return make(true,true,"Default HUD icon path and current-palette flag are applied by the native HUD for players and popup enemy/boss status.");
    if(c=="icondie"||c=="nolife"||c=="lifeposition"||c=="nameposition"||c=="iconposition")
        return make(true,true,"Native HUD applies death icon, life visibility and popup HUD positions directly.");
    if(c=="lbarsize"||c=="lifebarsize")
        return make(true,true,"Global lifebar dimensions from lifebar.txt are consumed directly by the native HUD.");
    if(c=="lifebarstatus")
        return make(true,true,"Popup HUD width/height, border suppression, absolute/ratio fill and horizontal/vertical orientation execute natively; legacy per-component Z-layer offsets are preserved but not fully composited.", CommandStatus::Partial);
    if(c=="order")
        return make(true,true,"Panel order strings select and repeat panel definitions by letter, preserving case-insensitive order and concatenating repeated order directives.");
    if(c=="2pitem")
        return make(false,false,"Two-player conditional item drop is recognized; conditional stage-item substitution remains partial.", CommandStatus::Partial);
    if(c=="lives"||c=="credits")
        return make(true,false,"Level-set lives/credits are parsed as frontend metadata; continue/life consumption remains partial.", CommandStatus::Partial);

    // v0.34.14: generic coverage expanded from the Evil Dead v1.4.0 audit.
    // These are standard OpenBOR directives. Gameplay-bearing commands are
    // only SUPPORTED when the generated runtime consumes their semantics;
    // recognized legacy/frontend directives are catalogued honestly instead
    // of falling through to UNKNOWN.
    if(c=="forcedirection") return make(true,true,"Per-animation attack facing reaction is preserved: -2 left, -1 opposite attacker, 0 unchanged, 1 attacker-facing, 2 right.");
    if(c=="dropframe") return make(true,true,"Airborne animations jump forward to the configured frame when vertical velocity crosses the apex.");
    if(c=="alpha") return make(true,true,"Model-level OpenBOR blend modes 0-6 are applied by the native software compositor; per-frame drawmethod alpha still takes precedence.");
    if(c=="setlayer") return make(true,true,"Model render depth override is applied relative to the stage Z base while normal actors remain Z-sorted.");
    if(c=="subject_to_screen") return make(true,true,"Entity screen-bound movement flag is parsed and applied by the native actor runtime.");
    if(c=="spawn2"||c=="spawn3"||c=="spawn4") return make(true,true,"Additional player start coordinates are parsed and used for co-op spawn, stage transition and respawn.");
    if(c=="setweap") return make(true,true,"Stage weapon index is parsed and applied to player/co-op loadout on stage start.");
    if(c=="projectile") return make(true,true,"Legacy projectile hit-mask alias is parsed through the same native target-mask path as projectilehit.");
    if(c=="running") return make(true,false,"Legacy running speed/jump metadata is parsed. Native run speed is active; the full historical running-jump move/land matrix remains partial.",CommandStatus::Partial);
    if(c=="gfxshadow") return make(true,false,"Legacy projected-shadow selector is parsed. The native renderer provides actor shadows but not every historical gfxshadow projection mode.",CommandStatus::Partial);
    if(c=="dust") return make(true,false,"Model dust references for fall/land/jump are parsed; animation-specific land dust is active, while all model-level automatic dust triggers remain partial.",CommandStatus::Partial);
    if(c=="facing") return make(true,true,"Legacy forced facing modes are applied continuously: normal, force right, force left, or follow stage direction.");
    if(c=="pbombframe") return make(true,false,"Projectile-bomb trigger frame/delay is parsed per animation; complete historical smart-bomb timing remains partial.",CommandStatus::Partial);
    if(c=="holdblock") return make(true,false,"Hold-block policy is parsed. Native blocking is active, while exact legacy hold/release input arbitration remains partial.",CommandStatus::Partial);
    if(c=="chargetime") return make(true,false,"Charge-time metadata is parsed per animation; exact legacy charge-input timing remains partial.",CommandStatus::Partial);
    if(c=="riseinv") return make(true,false,"Post-rise invulnerability duration is parsed; exact blink/no-blink legacy presentation remains partial.",CommandStatus::Partial);
    if(c=="subject_to_minz"||c=="subject_to_maxz") return make(true,true,"Per-model Z boundary flags independently control minimum/maximum stage-Z clamping for players, co-op and runtime entities.");
    if(c=="subject_to_obstacle"||c=="subject_to_platform")
        return make(true,false,"OpenBOR movement-subject flag is parsed; native terrain collision covers the common case but exact per-flag historical terrain precedence remains partial.",CommandStatus::Partial);
    if(c=="cameraoffset"||c=="light"||c=="shadowcolor"||c=="shadowalpha"||c=="settime"||c=="notime")
        return make(true,false,"Stage presentation/timing directive is parsed into generated stage metadata; exact legacy camera/light/shadow/time presentation remains partial.",CommandStatus::Partial);
    if(c=="noslow") return make(true,true,"Legacy engine slowdown suppression is unnecessary in the fixed-step native runtime.",CommandStatus::IgnoredSafely);
    if(c=="nodropen") return make(true,true,"Legacy drop-in policy is recognized; the native frontend uses its own deterministic join/respawn policy.",CommandStatus::IgnoredSafely);

    // Legacy HUD, score, allocation and frontend directives. The native port
    // uses dynamic containers and a resolution-aware frontend, so these are
    // recognized rather than misreported as unknown source syntax.
    if(c=="totalscore"||c=="steal"||c=="skipselect"||c=="showrushbonus"||c=="scoreformat"||c=="rushbonus"||c=="rush"||c=="recharge"||
       c=="p2rush"||c=="p2mp"||c=="p1rush"||c=="p1mp"||c=="otg"||c=="olbarsize"||c=="offscreen_noatk_factor"||c=="none"||
       c=="nomaxrushreset"||c=="nohit"||c=="mpbarsize"||c=="maxrises"||c=="maxindexedvars"||c=="maxglobalvars"||c=="maxfollows"||
       c=="maxentityvars"||c=="maxscriptvars"||c=="maxcancels"||c=="lifebonus"||c=="height"||c=="escapehits"||c=="colormagic"||c=="clearbonus"||
       c=="camera"||c=="ajspecial")
        return make(true,true,"Recognized legacy OpenBOR global/frontend directive; the native runtime uses dynamic storage or its own resolution-aware presentation for this field.",CommandStatus::IgnoredSafely);

    // v0.34.13: commands found in Final Fight X that were previously uncatalogued.
    // Gameplay-bearing model commands are parsed/emitted; legacy frontend-only
    // layout/allocation directives are explicitly catalogued as safe no-ops
    // rather than being silently reported as UNKNOWN.
    if(c=="makeinv") return make(true,true,"Spawn invulnerability metadata is emitted; positive values protect the spawned actor for the configured legacy interval.");
    if(c=="grabback") return make(true,true,"Grab render ordering is emitted so the grabber can remain behind the held target.");
    if(c=="grabfinish") return make(true,true,"Grab actions honor the model grab-finish lock before a throw/next action is accepted.");
    if(c=="throwframewait") return make(true,true,"Legacy throw release frame metadata is emitted and retained by the runtime.");
    if(c=="fastattack") return make(true,true,"Fast-attack metadata is emitted and shortens AI post-reaction attack delay.");
    if(c=="playshotno") return make(true,true,"Legacy no-ammo shot animation token is preserved with the generated model for projectile/weapon fallback selection.");
    if(c=="maxplayers") return make(true,true,"Level-set maximum player count is consumed by the native frontend and clamped to the four-player runtime limit.");
    if(c=="blocked") return make(true,true,"Stage blocked flag is recognized by the stage-control layer and prevents backward camera release while active.");
    if(c=="stop"||c=="silence") return make(true,true,"Scene control directive is consumed by the native cutscene player (stop terminates the scene; silence suppresses scene music).");
    if(c=="blackbox"||c=="whitebox"||c=="color25"||c=="color50"||c=="color100"||c=="color200"||c=="color300"||c=="color400"||c=="color500")
        return make(true,true,"Legacy HUD color directive is parsed by the runtime HUD configuration.");
    if(c=="renamekey")
        return make(true,true,"Legacy key label override is recognized for the controls frontend; it does not change the physical binding.", CommandStatus::IgnoredSafely);
    if(c=="disablekey")
        return make(true,true,"Legacy disabled control is recognized. Controls not exposed by the compact native frontend remain unavailable by design.", CommandStatus::IgnoredSafely);
    if(c=="maxfreespecials"||c=="maxattacks"||c=="maxattacktypes"||c=="maxwalks"||c=="maxidles")
        return make(true,true,"Legacy fixed-table capacity directive is unnecessary because the native port uses dynamically sized generated tables.", CommandStatus::IgnoredSafely);
    if(c=="colourselect"||c=="colorselect")
        return make(true,true,"Legacy palette-selection frontend switch is recognized; native character selection derives available palettes directly from generated model data.", CommandStatus::IgnoredSafely);
    if(c=="nolost"||c=="versusdamage"||c=="spdirection"||c=="lifescore"||c=="credscore"||c=="noaircancel"||c=="autoland")
        return make(true,true,"Legacy global gameplay/frontend policy is recognized; the compact native runtime already uses the corresponding fixed policy for this port.", CommandStatus::IgnoredSafely);
    if(c=="timeloc"||c=="timeicon"||c=="hiscorebg"||c=="loadingbg"||c=="loadingbg2"||c=="nosame"||c=="continuescore"||c=="cansave")
        return make(true,true,"Legacy frontend/HUD layout directive is recognized; the native frontend owns this presentation and does not require the original fixed-coordinate field.", CommandStatus::IgnoredSafely);
    if(c=="p1smenu"||c=="p1score"||c=="p1namej"||c=="p1lifex"||c=="p1lifen"||c=="p1life"||c=="p1icon"||
       c=="p2smenu"||c=="p2score"||c=="p2namej"||c=="p2lifex"||c=="p2lifen"||c=="p2life"||c=="p2icon"||
       c=="p3smenu"||c=="p3score"||c=="p3namej"||c=="p3lifex"||c=="p3lifen"||c=="p3life"||c=="p3icon"||
       c=="e1name"||c=="e1life"||c=="e1icon"||c=="e2name"||c=="e2life"||c=="e2icon"||c=="e3name"||c=="e3life"||c=="e3icon")
        return make(true,true,"Legacy absolute HUD coordinate is catalogued; the native HUD uses resolution-aware anchors instead of fixed 320x240 coordinates.", CommandStatus::IgnoredSafely);
    if(c=="bgspeed")
        return make(true,true,"Legacy background auto-scroll hint is recognized; stage layer scroll ratios remain authoritative in the native renderer.", CommandStatus::IgnoredSafely);
    if(c=="colourdepth")
        return make(true,true,"Native renderer is RGBA internally; legacy indexed colour depth does not require a separate runtime mode.", CommandStatus::IgnoredSafely);
    if(c=="comment"||c=="#"||c=="musicloop")
        return make(true,true,"", CommandStatus::IgnoredSafely);
    if(c.find("script")!=std::string::npos)
        return make(true,false,"Script-related command recorded without a dedicated runtime hook.");
    return make(false,false,"Command is not in the central registry. It is logged and does not abort conversion.", CommandStatus::Unknown);
}

std::string CommandRegistry::classifyLine(std::string_view command){
    auto info = lookup(command);
    std::string out = statusName(info.status);
    out += info.parser ? " parser=YES" : " parser=NO";
    out += info.runtime ? " runtime=YES" : " runtime=NO";
    if(info.note && *info.note){ out += " | "; out += info.note; }
    return out;
}
