OpenBOR Native Builder v0.34.17 - Windows x64

Extraia o ZIP e abra OpenBOR-Native-Builder.exe com dois cliques.
Escolha pasta, ZIP ou PAK e gere novamente o port.

Corrigido tratamento de acentos e nomes internacionais na analise, geracao e empacotamento.
Referencias antigas em Windows-1252 sao decodificadas.
Base preservada: v0.34.14.

O Builder ja esta compilado. Para compilar o jogo gerado, instale CMake e Visual Studio 2022 Build Tools (Desktop C++) ou use MinGW.
A GUI Windows nao foi executada nesta entrega; leia o relatorio de validacao.
