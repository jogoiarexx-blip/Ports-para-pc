$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Build = Join-Path $Root "build-portable-win64"
$Dist = Join-Path $Root "dist-portable"

function Find-CMake {
    $cmd = Get-Command cmake.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }

    $candidates = @(
        (Join-Path $Root "tools\cmake\bin\cmake.exe"),
        "$env:ProgramFiles\CMake\bin\cmake.exe",
        "${env:ProgramFiles(x86)}\CMake\bin\cmake.exe",
        "$env:ProgramFiles\Microsoft Visual Studio\2022\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe",
        "$env:ProgramFiles\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe",
        "$env:ProgramFiles\Microsoft Visual Studio\2022\Professional\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe",
        "$env:ProgramFiles\Microsoft Visual Studio\2022\Enterprise\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe",
        "$env:ProgramFiles\Microsoft Visual Studio\2019\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe",
        "${env:ProgramFiles(x86)}\Microsoft Visual Studio\2019\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
    )
    foreach ($p in $candidates) {
        if ($p -and (Test-Path $p)) { return $p }
    }
    return $null
}

function Find-VSWhere {
    $cmd = Get-Command vswhere.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $p = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
    if (Test-Path $p) { return $p }
    return $null
}

function Find-MSVCInstallation {
    $vswhere = Find-VSWhere
    if (-not $vswhere) { return $null }
    $install = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    if ($LASTEXITCODE -ne 0) { return $null }
    if ($install) { return ($install | Select-Object -First 1) }
    return $null
}

$CMake = Find-CMake
$MSVC = Find-MSVCInstallation

if (-not $CMake -or -not $MSVC) {
    Write-Host "" -ForegroundColor Yellow
    if (-not $CMake) { Write-Host "FALTA: CMake" -ForegroundColor Red }
    if (-not $MSVC) { Write-Host "FALTA: Visual Studio C++ Build Tools / MSVC v143" -ForegroundColor Red }
    Write-Host "" -ForegroundColor Yellow
    Write-Host "Execute INSTALAR-FERRAMENTAS-WINDOWS.cmd e depois rode este build novamente." -ForegroundColor Cyan
    Write-Host "O instalador corrigido NAO tenta atualizar CMake se ele ja estiver instalado." -ForegroundColor Yellow
    exit 11
}

Write-Host "CMake encontrado: $CMake" -ForegroundColor Green
Write-Host "MSVC encontrado: $MSVC" -ForegroundColor Green

if (Test-Path $Build) { Remove-Item $Build -Recurse -Force }
if (Test-Path $Dist) { Remove-Item $Dist -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Dist | Out-Null

& $CMake -S $Root -B $Build -A x64 -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded
if ($LASTEXITCODE -ne 0) { throw "Falha ao configurar o projeto com CMake (codigo $LASTEXITCODE)." }

& $CMake --build $Build --config Release --parallel
if ($LASTEXITCODE -ne 0) { throw "Falha ao compilar o Builder (codigo $LASTEXITCODE)." }

$Exe = Join-Path $Build "Release\openbor-native-builder.exe"
if (!(Test-Path $Exe)) { throw "Executavel Win64 nao foi gerado: $Exe" }
Copy-Item $Exe (Join-Path $Dist "OpenBOR-Native-Builder.exe")
Copy-Item (Join-Path $Root "README.md") $Dist
@"
OpenBOR Native Builder v0.34.17 - Portable Win64

1. Execute OpenBOR-Native-Builder.exe.
2. Escolha uma pasta, ZIP ou PAK do jogo OpenBOR.
3. O Builder localiza automaticamente data/ ou extrai Paks/*.pak.
4. Confira o resumo de compatibilidade e confirme a conversao.
5. O port sera gerado ao lado da entrada escolhida.

O OpenBOR-Native-Builder.exe e portatil e nao precisa de instalacao.
O runtime C/C++ do MSVC e ligado estaticamente (/MT). APIs normais do Win32
(Shell32/Ole32 e outras) sao fornecidas pelo proprio Windows.
"@ | Set-Content -Encoding UTF8 (Join-Path $Dist "LEIA-ME.txt")

$Size = (Get-Item (Join-Path $Dist "OpenBOR-Native-Builder.exe")).Length
Write-Host "" -ForegroundColor Green
Write-Host "Portable Win64 pronto em: $Dist" -ForegroundColor Green
Write-Host ("OpenBOR-Native-Builder.exe: {0:N0} bytes" -f $Size) -ForegroundColor Green
