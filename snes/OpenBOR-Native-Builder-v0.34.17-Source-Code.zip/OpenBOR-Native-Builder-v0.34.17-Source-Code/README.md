# OpenBOR Native Builder v0.34.17

Continuação direta da v0.34.16. Esta versão compara o Builder com o port direto Final Fight X Native v0.3.39 e promove somente comportamentos genéricos do OpenBOR Build 3797, sem hardcode de jogo.

## Principais melhorias

- Executa `spawn`, `wait`, `group` e `blockade` na ordem original da fase.
- Preserva capítulos criados por `next` em `levels.txt`.
- Preserva cenas pré-fase, pós-fase e finais, incluindo `skipone`, `noskip`, `music` e `silence`.
- Mantém HP entre partes do mesmo capítulo com recuperação legacy de +5 e restaura HP ao cruzar um `next`.
- Corrige `direction up/down` para progresso vertical equivalente ao Build 3797 (~100 px/s).
- Preserva `canSave`; valor 0 bloqueia gravação e o save de entrada agora registra a fase nova, não a anterior.
- Corrige spawn padrão P1-P4 quando `spawn1..4` não existem: 20/50/80/110 para a direita e 300/270/240/210 para a esquerda, com Z = `zmin+5`.
- Fases `direction left` passam a iniciar a câmera no extremo direito e os jogadores virados para a esquerda.
- Mantém as correções v0.34.16 de `flipframe` e pivô espelhado, além da base Unicode/Windows-1252 da v0.34.15.

## Validação

- Regressão: 372 verificações PASS, 0 falhas.
- CTest: 1/1 PASS.
- Nove suítes de runtime: effects, contacts, grabs, bindings, Unicode, terrain, energy, commands e compatibility — todas PASS.
- Final Fight X v0.3.39: 99 modelos, 21 fases, 1106 animações, 15465 SUPPORTED, 0 PARTIAL, 0 UNSUPPORTED e 0 UNKNOWN.
- Runtime C++ gerado a partir do Final Fight X compilado com sucesso no ambiente Linux disponível.

## Windows

Abra `BUILD-PORTABLE-WINDOWS.cmd` ou use os scripts PowerShell incluídos. A compilação Windows requer CMake e Visual Studio 2022 Build Tools com Desktop C++, ou MSYS2/MinGW conforme os scripts.

Este pacote de fonte não contém um EXE v0.34.17 pré-compilado porque o ambiente usado nesta validação não possui toolchain Windows. Não substitua o EXE por uma versão anterior: isso perderia as correções desta versão.

## Testes dos fontes

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j 4
ctest --test-dir build --output-on-failure
python3 tests/run-runtime-tests.py build/openbor-native-builder validation
```

Consulte `VALIDACAO-v0.34.17.md` para os detalhes.
