# Validação — OpenBOR Native Builder v0.34.17

## Objetivo

A v0.34.17 foi criada a partir da v0.34.16 depois de comparar o Builder com o port direto Final Fight X Native v0.3.39. Foram importadas somente semânticas genéricas do OpenBOR; nenhuma regra depende do nome Final Fight X, de personagens específicos ou de caminhos exclusivos do jogo.

## O que foi promovido para o Builder

- Ordem unificada de `spawn`, `wait`, `group` e `blockade`.
- Capítulos de campanha via `next`.
- Cenas pré-fase, pós-fase e cenas finais.
- `skipone`/`noskip`, música e silêncio dentro das cenas.
- Persistência de HP entre níveis no mesmo capítulo (+5 HP legacy) e restauração ao mudar de capítulo.
- Progresso/scroll de fases `direction up/down` a aproximadamente 100 px/s.
- `canSave` real de `levels.txt`, incluindo gravação da fase recém-carregada.
- Spawn padrão P1-P4 do Build 3797 quando `spawn1..4` não são fornecidos.
- Entrada correta em fases `direction left`: câmera no extremo direito e jogadores virados para a esquerda.

## Testes do Builder

- CMake/Ninja Release: aprovado.
- CTest: 1/1 aprovado.
- Regressão: 372 verificações PASS, 0 falhas.
- Runtime effects: PASS.
- Runtime contacts: PASS.
- Runtime grabs: PASS.
- Runtime bindings: PASS.
- Runtime Unicode: PASS.
- Runtime terrain: PASS.
- Runtime energy: PASS.
- Runtime commands: PASS.
- Runtime compatibility: PASS.

## Validação com Final Fight X v0.3.39

Dados OpenBOR preservados no port direto foram usados como entrada real do Builder. Resultado da análise/conversão:

- 1770 arquivos.
- 1519 imagens.
- 103 áudios.
- 143 arquivos de texto.
- 99 modelos.
- 21 fases.
- 1106 animações.
- 5 scripts.
- 15465 ocorrências SUPPORTED.
- 0 PARTIAL.
- 0 UNSUPPORTED.
- 0 UNKNOWN.

A tabela gerada confirmou `canSave=2` em todas as fases do conjunto, os quatro limites de capítulo do `levels.txt`, fases `direction left`, `direction up` na fase 18 e as três cenas finais ligadas à fase 21. O runtime C++ produzido pelo Builder foi configurado e compilado com sucesso. O comando `openbor-native-builder test` também concluiu com `NATIVE BUILD SUCCESS`.

## Limites desta validação

A compilação e os testes automatizados foram executados no ambiente Linux disponível. Não foi executada uma partida interativa completa no Windows. O ambiente atual também não possui MinGW/MSVC para gerar honestamente o EXE Windows x64 da v0.34.17. Os scripts Windows permanecem no fonte para compilação em uma máquina com a toolchain instalada.

Esta entrega melhora fidelidade estrutural/runtime, mas não declara paridade visual/gameplay 100% com toda versão e todo módulo OpenBOR.
