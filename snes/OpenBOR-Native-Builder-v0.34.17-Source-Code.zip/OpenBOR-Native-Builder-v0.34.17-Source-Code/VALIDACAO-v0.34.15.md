# Validação — OpenBOR Native Builder v0.34.15

Base: código-fonte v0.34.14 recuperado. As melhorias dessa base foram preservadas. Esta entrega corrige conversões de nomes e caminhos; não declara paridade completa com OpenBOR nem redução nova de PARTIAL/UNKNOWN.

## Correção

Substituídas conversões de caminhos dependentes de locale por UTF-8 explícito. No Windows, argumentos e operações nativas usam UTF-16. A correção cobre descoberta de projetos, extração de PAK, análise, metadados, relatórios, empacotamento e caminhos do runtime gerado.

Nomes internos e referências de PAKs antigos em Windows-1252 são convertidos consistentemente; UTF-8 válido permanece intacto. Scripts/includes e recursos de áudio/imagem usam o mesmo helper. Texto de comandos é normalizado e BOM UTF-8 ignorado. CMake/PowerShell/tar são iniciados diretamente no Windows; nomes não são expandidos pelo CMD. MSVC recebe /utf-8.

## Testes desta entrega

| Conjunto | Verificações aprovadas |
| --- | ---: |
| Regressão do Builder | 350 |
| Efeitos | 25 |
| Contatos | 21 |
| Agarrões | 21 |
| Vínculos | 53 |
| Unicode, scripts/includes e áudio | 15 |
| Terreno | 38 |
| Energia | 41 |
| Comandos | 25 |
| Compatibilidade de animação | 17 |
| **Total** | **606** |

CTest: 1/1 passou, zero falhas. O runtime dos testes foi gerado novamente com este Builder e compilado no Linux. O teste Unicode executou referências UTF-8 e Windows-1252, includes e um WAV sob caminho com acentos, ideogramas e emoji; também verificou rejeição de traversal e codificações UTF-8 inválidas.

O teste de entradas passou nos oito cenários: pasta; PAK UTF-8; PAK Windows-1252; ZIP de pasta; ZIP contendo PAK; nome padrão da análise; nome padrão do port; compilação e ZIP portátil com preservação de nomes acentuados. O caminho de saída incluiu `ação 日本語 🎮 %USERPROFILE% & jogos`.

Builder compilado em Linux e Windows x64. Um runtime gerado também compilou para Windows x64 sob caminho Unicode. O EXE do Builder usa runtime do compilador estático e importa apenas comdlg32, KERNEL32, msvcrt, ole32, SHELL32 e USER32.

## Limites

As execuções de testes ocorreram em Linux. A compilação Windows x64 foi feita por MinGW; não houve execução da GUI, teste do MSVC ou partida interativa em Windows real nesta entrega. Não foram enviados os PAKs específicos que falharam na imagem; os testes usam fixtures controladas. A correção remove conversões que podiam produzir a exceção mostrada, mas não comprova todos os jogos como jogáveis.

Outras codificações legadas, além de Windows-1252, não são detectadas automaticamente. PARTIAL/UNKNOWN precisam de análise de compatibilidade própria.

## Aplicar

Extraia o ZIP Portable-Windows-x64-EXE e abra OpenBOR-Native-Builder.exe. Gere os ports novamente a partir dos arquivos originais. Compilar jogos gerados requer CMake e ferramentas C++ no Windows. Os fontes, fixtures e logs atuais acompanham o ZIP Source-Code.
