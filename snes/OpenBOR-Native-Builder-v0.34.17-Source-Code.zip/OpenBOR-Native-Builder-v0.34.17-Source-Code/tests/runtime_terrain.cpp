#include "Engine.hpp"
#include <iostream>
#include <stdexcept>
struct RuntimeCompatibilityTest {
 static void check(bool ok,const char* label){if(!ok)throw std::runtime_error(label);std::cout<<"PASS: "<<label<<"\n";}
 static void run(const std::filesystem::path& root){
  Engine e;check(e.initialize(root),"terrain fixture initializes");e.config_.autoPreviewMusic=false;
  std::vector<std::string> missing;
  auto query=[&](const char* name,std::vector<ScriptValue> args){missing.clear();auto v=e.callScriptFunction(name,args,e.playerScriptCtx_,missing);auto p=std::get_if<double>(&v);if(!p)throw std::runtime_error("terrain result must be numeric");return *p;};
  check(query("checkhole",{140.0,180.0})==1&&missing.empty(),"point inside trapezoid detects hole without unmapped warning");
  check(query("checkhole",{105.0,160.5})==0,"sloped upper boundary excludes point inside old bounding rectangle");
  check(query("checkhole",{100.25,200.5})==1,"float coordinates and bottom boundary are inclusive");
  check(query("checkhole",{140.0,160.499})==0&&query("checkhole",{140.0,200.501})==0,"points beyond depth bounds do not hit hole");
  check(query("checkholeindex",{140.0,180.0})==0,"two-argument query returns first hole index");
  check(query("checkholeindex",{140.0,180.0,1.0})==1,"altitude query selects highest eligible overlapping hole");
  check(query("checkhole",{140.0,180.0,22.0})==1&&query("checkhole",{140.0,180.0,22.01})==0,"hole altitude uses OpenBOR two-unit walkoff tolerance");
  check(query("checkholeindex",{140.0,180.0,22.01})==-1,"no eligible hole returns negative index");
  check(query("checkhole",{125.0,185.0})==0&&query("checkholeindex",{125.0,185.0,0.0})==-1,"overlapping wall suppresses hole even above query altitude");
  check(query("checkwall",{230.0,180.0})==30&&missing.empty(),"wall query returns highest overlapping height");
  check(query("checkwall",{230.0,180.0,15.0})==10,"wall query respects maximum altitude");
  check(query("checkwall",{230.0,180.0,30.0})==30,"wall height equal to query altitude is eligible");
  check(query("checkwall",{230.0,180.0,9.0})==0&&query("checkwallindex",{230.0,180.0,9.0})==-1,"walls above requested altitude do not count");
  check(query("checkwallindex",{230.0,180.0})==1&&query("checkwallindex",{230.0,180.0,15.0})==0,"wall index counts walls independently of holes and platform entries");
  check(query("checkwall",{201.0,160.0})==10&&query("checkwall",{220.0,160.0})==30,"sloped wall sides use interpolated corner offsets");
  check(query("checkwall",{1000.0,180.0})==0&&query("checkwallindex",{1000.0,180.0})==-1,"empty terrain returns zero height and negative index");
  check(query("checkwall",{410.0,200.0})==0,"zero-depth shape does not divide by zero or invent a wall");
  check(query("checkwall",{460.0,190.0})==0&&query("checkwallindex",{460.0,190.0})==-1,"zero-height wall follows original highest-wall selection");
  query("checkwall",{615.0,185.0});check(missing.size()==1&&missing[0]=="terrain-legacy-rectangle","legacy rectangle fallback is explicitly logged as incomplete");
  e.loadCurrentPlayerSprite();auto&g=e.scriptVm_.globals();check(std::get<double>(g.at("holeProbe"))==1&&std::get<double>(g.at("wallProbe"))==30,"actual @cmd helper receives hole and wall results through ScriptVM");
  query("checkwall",{1.0});check(missing.size()==1&&missing[0]=="checkwall-arguments","missing coordinates produce a visible argument diagnostic");
  auto hero=*e.playerModel_;float x=230,z=180;
  auto terrain=[&](float y,float ox,float oz){return e.applyActorTerrain(&hero,e.playerScriptCtx_,x,z,-y,ox,oz);};
  terrain(35,190,180);check(x==230,"actor above wall height passes through its footprint");
  x=230;terrain(30,190,180);check(x==230,"actor at wall height is not blocked laterally");
  x=230;terrain(20,190,180);check(x==190,"actor below highest overlapping wall is blocked");
  auto& globals=e.scriptVm_.globals();check(std::get<double>(globals.at("blockedHeight"))==30&&std::get<double>(globals.at("blockedIndex"))==1&&std::get<double>(globals.at("blockedDepth"))==40,"wall hook gets world height, wall-only index and shape depth");
  check(std::get<double>(globals.at("blockedType"))==0&&std::get<double>(globals.at("blockedPlane"))==0,"wall hook gets numeric terrain type and X plane");
  check(!e.playerScriptCtx_.local.contains("height")&&!e.playerScriptCtx_.local.contains("index"),"wall event locals are cleared after execution");
  x=230;z=180;terrain(0,230,150);check(std::get<double>(globals.at("blockedPlane"))==2,"Z collision reports PLANE_Z two");
  hero.subjectToWall=false;x=230;z=180;terrain(0,190,180);check(x==230,"subject_to_wall zero bypasses actual actor collision");hero.subjectToWall=true;
  x=201;z=160;terrain(20,190,160);check(x==201,"sloped wall corner outside tall shape does not block against rectangle");
  x=105;z=160.5f;check(!terrain(0,104,160.5f),"actor outside sloped hole does not reset in old rectangular footprint");
  x=140;z=180;check(terrain(22,140,180)&&!terrain(22.01f,140,180),"actor hole predicate shares two-unit altitude tolerance");
  x=125;z=185;check(!terrain(0,125,185),"wall footprint suppresses hole for actual actor geometry");
  x=460;z=190;terrain(0,440,190);check(x==460,"zero-height wall does not invent lateral blockage");
  hero.subjectToHole=false;x=140;z=180;check(!terrain(0,140,180),"subject_to_hole zero bypasses actor hole handling");
  std::vector<std::string> constants;check(std::get<double>(e.callScriptFunction("openborconstant",{std::string("PLANE_Y")},e.playerScriptCtx_,constants))==1&&std::get<double>(e.callScriptFunction("openborconstant",{std::string("PLANE_Z")},e.playerScriptCtx_,constants))==2,"plane constants follow supplied OpenBOR enum");
  auto stage=e.stage_;e.stage_=nullptr;check(query("checkhole",{0.0,0.0})==0&&query("checkholeindex",{0.0,0.0})==-1&&query("checkwall",{0.0,0.0})==0,"absent stage returns neutral terrain values");e.stage_=stage;
 }
};
int main(int argc,char**argv){try{if(argc!=2)return 2;RuntimeCompatibilityTest::run(argv[1]);std::cout<<"RUNTIME TERRAIN PASS\n";return 0;}catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}}
