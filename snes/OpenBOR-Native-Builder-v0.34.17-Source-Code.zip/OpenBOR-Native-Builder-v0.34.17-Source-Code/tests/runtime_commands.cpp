#include "Engine.hpp"
#include <iostream>
#include <stdexcept>
#include <fstream>
struct RuntimeCompatibilityTest {
 static void check(bool v,const char* label){if(!v)throw std::runtime_error(label);std::cout<<"PASS: "<<label<<"\n";}
 static double number(const ScriptVM& vm,const char* key){auto it=vm.globals().find(key);if(it==vm.globals().end())return 0;if(auto p=std::get_if<double>(&it->second))return *p;if(auto p=std::get_if<bool>(&it->second))return *p?1:0;return 0;}
 static void run(const std::filesystem::path& root){
  Engine e;check(e.initialize(root),"command fixture initializes");e.config_.autoPreviewMusic=false;e.tickCounter_=1;
  e.loadCurrentPlayerSprite();
  const auto& globals=e.scriptVm_.globals();auto label=globals.find("label");
  check(label!=globals.end()&&std::get<std::string>(label->second)=="power # one","quoted spaces and # survive actual @cmd execution");
  auto actor=globals.find("actor");check(actor!=globals.end()&&std::get<std::uintptr_t>(actor->second)==1,"nested expression with spaces receives correct actor handle");
  check(number(e.scriptVm_,"scopeInner")==8&&number(e.scriptVm_,"scopeOuter")==7,"nested helper parameters and declarations do not corrupt caller locals");
  check(number(e.scriptVm_,"bad")==0,"false conditions and short-circuited calls have no effects");
  check(number(e.scriptVm_,"negativeBranch")==4,"unselected unary expressions are consumed without execution");
  check(number(e.scriptVm_,"macro")==4,"function macro and parenthesized object macro expand through nested mixed-case import");
  check(std::get<double>(e.playerScriptCtx_.local.at("persistent"))==77,"setlocalvar persists independently of automatic helper locals");
  check(!e.playerScriptCtx_.local.contains("x")&&!e.playerScriptCtx_.local.contains("label"),"automatic helper locals do not leak into frame context");
  check(number(e.scriptVm_,"order")==2,"multiple frame commands execute in source order");
  check(number(e.scriptVm_,"helperFrames")==1,"helper main runs once alongside frame commands");
  e.loadCurrentPlayerSprite();check(number(e.scriptVm_,"order")==2&&number(e.scriptVm_,"helperFrames")==1,"reloading same frame does not repeat commands");
  ScriptVM vm;vm.setRoot(root/"assets/openbor-data");ScriptContext ctx;ctx.local["self"]=std::uintptr_t(9);
  auto result=vm.runAnimationCommand("","setglobalvar(\"core\", getlocalvar(\"self\")); setglobalvar(\"zero\",NULL());",ctx);
  check(result.ok&&result.unsupported.empty()&&std::get<std::uintptr_t>(vm.globals().at("core"))==9,"verified direct core cmd subset executes with original handle");
  check(std::get<std::uintptr_t>(vm.globals().at("zero"))==0,"NULL cmd argument retains null-handle semantics");
  result=vm.runAnimationCommand("DATA/SCRIPTS/helper.C","stamp(-6);",ctx);check(result.ok&&result.unsupported.empty()&&number(vm,"stamp")==-6,"direct helper lookup is case-insensitive");
  result=vm.runAnimationCommand("","if(0){ setglobalvar(\"skip\",!~(-2)); } setglobalvar(\"after\",3);",ctx);
  check(result.ok&&number(vm,"after")==3&&number(vm,"skip")==0,"stacked unary operators in skipped block do not break later commands");
  result=vm.runAnimationCommand("","setglobalvar(\"and\",0 && unknown_skipped()); setglobalvar(\"or\",1 || unknown_skipped());",ctx);
  check(result.ok&&result.unsupported.empty()&&number(vm,"and")==0&&number(vm,"or")==1,"short circuit does not dispatch skipped unknown function");
  auto temp=std::filesystem::temp_directory_path()/"obor-prototype-0343";std::filesystem::create_directories(temp);
  std::ofstream(temp/"proto.c")<<"void missing(); void main(){setglobalvar(\"called\",getglobalvar(\"called\")+1);missing();}";vm.setRoot(temp);
  result=vm.runFile("proto.c",ctx);check(result.ok&&result.unsupported.size()==1&&result.unsupported[0]=="missing"&&number(vm,"called")==1,"prototype is not mistaken for following main function body");
  result=vm.runAnimationCommand("no-file.c","setglobalvar(\"independent\",42); missing_helper(); setglobalvar(\"afterMissing\",7);",ctx);
  check(!result.ok&&number(vm,"independent")==42&&number(vm,"afterMissing")==7&&result.unsupported.size()==1,"missing helper does not suppress independent frame commands and retains failure");
  RuntimeEntity screenBound;screenBound.model=e.playerModel_;screenBound.alive=true;screenBound.visible=true;screenBound.worldX=e.cameraX_-50.0f;e.entities_.push_back(std::move(screenBound));auto&bound=e.entities_.back();ScriptContext boundCtx;boundCtx.entity=&bound;std::vector<std::string> unsupported;
  e.callScriptFunction("changeentityproperty",{std::uintptr_t((std::uintptr_t)&bound),std::string("subject_to_screen"),1.0},boundCtx,unsupported);
  check(bound.subjectToScreen,"subject_to_screen script property is stored on runtime entities");
  auto subject=e.callScriptFunction("getentityproperty",{std::uintptr_t((std::uintptr_t)&bound),std::string("subject_to_screen")},boundCtx,unsupported);
  check(std::get<bool>(subject),"subject_to_screen script property is readable");
  auto beforeProjectile=e.projectiles_.size();ScriptContext projectileCtx;projectileCtx.player=true;projectileCtx.playerIndex=0;unsupported.clear();
  auto projectileResult=e.callScriptFunction("projectile",{std::string("Knife"),120.0,205.0,14.0,1.0,0.0,0.0,0.0},projectileCtx,unsupported);
  check(unsupported.empty()&&std::get<std::uintptr_t>(projectileResult)!=0&&e.projectiles_.size()==beforeProjectile+1,"legacy projectile() script API spawns a native runtime projectile");
  const auto& spawnedProjectile=e.projectiles_.back();check(spawnedProjectile.model&&std::string(spawnedProjectile.model->name)=="Knife"&&spawnedProjectile.worldX==120.0f&&spawnedProjectile.z==205.0f&&spawnedProjectile.altitude==-14.0f&&spawnedProjectile.facing==1&&!spawnedProjectile.bomb,"projectile() absolute coordinates, altitude and knife type are preserved");
  result=vm.runAnimationCommand("../outside.c","stamp(1);",ctx);check(!result.ok,"unsafe animation helper path remains rejected");
  result=vm.runAnimationCommand("no-file.c","stamp(1);",ctx);check(!result.ok&&result.error.find("not found")!=std::string::npos,"missing animation helper is reported as failure");
 }
};
int main(int argc,char**argv){try{if(argc!=2)return 2;RuntimeCompatibilityTest::run(argv[1]);std::cout<<"RUNTIME COMMANDS PASS\n";return 0;}catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}}
