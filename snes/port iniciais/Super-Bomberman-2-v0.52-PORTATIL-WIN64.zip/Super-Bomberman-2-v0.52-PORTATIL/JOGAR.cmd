@echo off
setlocal
cd /d "%~dp0"
set "FORJA65_HEADLESS="
set "FORJA65_UNCAPPED="
set "FORJA65_INPUT_RECORD=partida-replay.txt"
set "FORJA65_AUDIO_MODE=native"
set "FORJA65_AUDIO_DUMP="
set "FORJA65_DSP_PROFILE=v16"
set "FORJA65_DSP_CLOCK=fractional"
set "FORJA65_SPC_CLOCK=accurate"
if not exist game.exe (echo ERRO: game.exe nao encontrado nesta pasta. & pause & exit /b 2)
if not exist assets\cart-data.bin (echo ERRO: assets\cart-data.bin ausente. & pause & exit /b 3)
game.exe
if errorlevel 1 (
  if exist forja65-last-error.txt type forja65-last-error.txt
  pause
)
