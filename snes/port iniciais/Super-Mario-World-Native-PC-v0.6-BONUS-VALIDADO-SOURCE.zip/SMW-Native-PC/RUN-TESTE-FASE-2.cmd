@echo off
setlocal
cd /d "%~dp0"
set "SMW_EXE=%~dp0build-win\Release\game.exe"
if exist "%~dp0game.exe" set "SMW_EXE=%~dp0game.exe"
if exist "%~dp0bin\game.exe" set "SMW_EXE=%~dp0bin\game.exe"
if not exist "%SMW_EXE%" (echo Execute BUILD-WINDOWS.cmd primeiro. & exit /b 1)
py -3 tools\verify_smw_island_2.py --exe "%SMW_EXE%"
exit /b %ERRORLEVEL%
