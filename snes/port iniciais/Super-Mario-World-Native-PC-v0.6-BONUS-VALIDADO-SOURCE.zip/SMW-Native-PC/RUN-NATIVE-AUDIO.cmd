@echo off
setlocal
cd /d "%~dp0"
set FORJA65_AUDIO_MODE=native
set FORJA65_AUDIO_DUMP=1
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=%~1
if "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=2200
call RUN-WINDOWS.cmd
echo Audio WAV e diagnostico na pasta onde game.exe foi executado.
pause
