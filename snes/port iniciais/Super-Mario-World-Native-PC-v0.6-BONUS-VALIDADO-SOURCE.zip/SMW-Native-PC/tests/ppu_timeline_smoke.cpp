#include "runtime.hpp"
#include <fstream>
#include <iostream>
#include <iterator>
int main(){try{std::string file;{SnesRuntime hw;hw.beginFrame();hw.ppuPortWrite(0x2100,0x0F);hw.ppuPortWrite(0x2105,0x01);hw.ppuPortWrite(0x212C,0x13);hw.ppuPortWrite(0x212D,0x02);file=hw.ppuTimelineFile;if(hw.ppu.tm!=0x13||hw.ppu.ts!=0x02||hw.ppu.brightness!=15)return 14;}
std::ifstream in(file);if(!in)return 10;std::string csv((std::istreambuf_iterator<char>(in)),{});if(csv.find("event,frame,instruction,pc,")==std::string::npos)return 11;if(csv.find("write,0,")==std::string::npos)return 12;if(csv.find(",8492,19,")==std::string::npos)return 13;std::cout<<"FORJA65_PPU_TIMELINE_SMOKE_OK"<<std::endl;return 0;}catch(const std::exception&e){std::cerr<<e.what()<<std::endl;return 2;}}
