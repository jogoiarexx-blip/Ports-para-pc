#include "pcm_audio_output.hpp"
#include <cassert>
#include <fstream>
#include <filesystem>
#include <iostream>
int main(){
  PcmAudioOutput out;
  out.start(false,true,"audio-transport-smoke.wav");
  assert(out.wavReady&&!out.liveReady);
  for(int i=0;i<1101;i++)out.push((std::int16_t)(i%101), (std::int16_t)(-i%101));
  out.finish();
  assert(out.framesGenerated==1101 && out.waveFrames==1101);
  assert(out.peak==100 && out.framesNonzero>0);
  assert(out.wavEverOpened);
  std::ifstream f("audio-transport-smoke.wav",std::ios::binary);
  assert(f && std::filesystem::file_size("audio-transport-smoke.wav")==44+1101*4);
  char hdr[44]{}; f.read(hdr,44);
  assert(std::string(hdr,4)=="RIFF" && std::string(hdr+8,4)=="WAVE" && std::string(hdr+36,4)=="data");
  const auto u32=[](const char*p){return unsigned((unsigned char)p[0])|(unsigned((unsigned char)p[1])<<8)|(unsigned((unsigned char)p[2])<<16)|(unsigned((unsigned char)p[3])<<24);};
  assert(u32(hdr+40)==1101*4 && u32(hdr+24)==32000);
  std::filesystem::remove("audio-transport-smoke.wav");
  std::cout<<"PCM transport: 32kHz stereo, nonzero samples, WAV streaming and partial flush PASS\n";
}
