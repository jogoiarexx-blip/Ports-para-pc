#include "runtime.hpp"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
int main(){
  ApuBridge wet,dry;
  wet.legacyDspClock=dry.legacyDspClock=true; // v0.19 recorded legacy 671-cycle cadence
  wet.setNativeDsp(true);dry.setNativeDsp(true);
  wet.configureAudioOutput(false,true);
  for(int n=0;n<20;n++){
    wet.tickDspMasterCycles(671u); dry.tickDspMasterCycles(671u);
  }
  assert(wet.dspNativeSamples==20 && dry.dspNativeSamples==20);
  assert(wet.dspMasterRemainder==dry.dspMasterRemainder);
  assert(wet.spc.pc==dry.spc.pc);
  assert(wet.nativePcm.empty() && dry.nativePcm.empty());
  assert(wet.pcmOutput->framesGenerated==20);
  assert(wet.pcmOutput->waveFrames==0);
  wet.enableMemoryPcmCapture(true);
  wet.tickDspMasterCycles(671u*4u);
  assert(wet.nativePcm.size()==8 && wet.pcmOutput->framesGenerated==24);
  wet.finishAudioOutput();
  assert(wet.pcmOutput->waveFrames==24);
  assert(std::filesystem::file_size("forja65-native-audio.wav")==44u+24u*4u);
  std::filesystem::remove("forja65-native-audio.wav");
  std::cout<<"FORJA65_APU_TRANSPORT_CROSSFEED_PASS samples=24 memory_optin=4\n";
  return 0;
}
