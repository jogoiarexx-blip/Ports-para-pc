#include "runtime.hpp"
#include <iostream>
int main(){try{SnesRuntime hw("assets/cart-data.bin",MapperKind::LoROM,2048u,9u,1u,CartChip::None,"runtime-smoke.srm",1u,true);if(hw.cart.empty()||hw.framebuffer.empty())return 3;if(hw.cartHashHex()!="4d7bc08f726d10cb"){std::cerr<<"ROM fingerprint mismatch "<<hw.cartHashHex()<<" expected 4d7bc08f726d10cb\n";return 4;}std::cout<<"FORJA65_RUNTIME_SMOKE_OK cart="<<hw.cart.size()<<" refresh="<<hw.hostRefreshHz()<<" rom=4d7bc08f726d10cb\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}}
