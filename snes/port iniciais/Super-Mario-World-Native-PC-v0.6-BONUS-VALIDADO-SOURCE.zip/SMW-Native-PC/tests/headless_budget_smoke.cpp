#include "runtime.hpp"
#include <iostream>
#include <stdexcept>
#include <string>
int main(){try{SnesRuntime hw;hw.headless=true;hw.beginFrame();hw.endVblank();if(hw.frameCounter!=1||hw.stopped)return 10;hw.beginFrame();bool completed=false;try{hw.endVblank();}catch(const std::runtime_error&e){completed=std::string(e.what())=="FORJA65_HEADLESS_COMPLETE";}if(!completed||hw.frameCounter!=2||!hw.stopped)return 11;std::cout<<"FORJA65_HEADLESS_BUDGET_PASS frames="<<hw.frameCounter<<"\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 2;}}
