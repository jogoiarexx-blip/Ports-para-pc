#include "runtime.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <cstring>
int main(){namespace fs=std::filesystem;try{SnesRuntime hw("assets/cart-data.bin",MapperKind::LoROM,2048u,9u,1u,CartChip::None,"scene-smoke.srm",1u,true);hw.ppu.bgmode=1;hw.ppu.tm=1;hw.ppu.ts=0;hw.ppu.brightness=15;hw.ppu.cgram[2]=0x1f;hw.ppu.cgram[3]=0;hw.ppu.vram[0]=0x80;hw.ppu.vram[1]=0;hw.framebuffer.assign(hw.fbWidth*hw.fbHeight,0xFF336699u);fs::remove_all("scene-smoke");if(!hw.captureNativeScene("scene-smoke","smoke"))return 4;for(const char*f:{"scene-smoke/smoke.nscene","scene-smoke/palette.npal","scene-smoke/bg1.ntiles","scene-smoke/bg1.nmap","scene-smoke/vram.bin","scene-smoke/oam.bin","scene-smoke/preview.ppm","scene-smoke/oam-layer.nspr","scene-smoke/oam-sprites.txt","scene-smoke/capture-manifest.txt"})if(!fs::exists(f)||fs::file_size(f)==0)return 5;std::ifstream n("scene-smoke/palette.npal",std::ios::binary);char m[4]{};n.read(m,4);if(std::memcmp(m,"NPAL",4)!=0)return 6;std::ifstream sn("scene-smoke/oam-layer.nspr",std::ios::binary);char sm[4]{};sn.read(sm,4);if(std::memcmp(sm,"NSPR",4)!=0)return 7;
#ifdef _WIN32
_putenv_s("FORJA65_CAPTURE_FRAMES","3,5");_putenv_s("FORJA65_CAPTURE_DIR","scene-smoke-multi");
#else
setenv("FORJA65_CAPTURE_FRAMES","3,5",1);setenv("FORJA65_CAPTURE_DIR","scene-smoke-multi",1);
#endif
fs::remove_all("scene-smoke-multi");hw.frameCounter=2;if(hw.maybeCaptureNativeScene())return 8;
hw.frameCounter=3;if(!hw.maybeCaptureNativeScene())return 9;
if(!fs::exists("scene-smoke-multi/frame-3/frame-3.nscene"))return 10;
if(hw.maybeCaptureNativeScene())return 11;
hw.frameCounter=4;if(hw.maybeCaptureNativeScene())return 12;
hw.frameCounter=5;if(!hw.maybeCaptureNativeScene())return 13;
if(!fs::exists("scene-smoke-multi/frame-5/frame-5.nscene")||!fs::exists("scene-smoke-multi/frame-3/capture-manifest.txt")||!fs::exists("scene-smoke-multi/frame-5/capture-manifest.txt"))return 14;
std::cout<<"FORJA65_SCENE_CAPTURE_SMOKE_OK hash="<<std::hex<<hw.framebufferHash()<<"\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}}
