@echo off
setlocal
cd /d "%~dp0"
set "FORJA65_EXECUTION=reference"
set "FORJA65_HEADLESS_FRAMES=180"
set "FORJA65_WATCHDOG_INSTRUCTIONS=40000000"
call RUN-HEADLESS.cmd
exit /b %ERRORLEVEL%
