@echo off
setlocal
cd /d "%~dp0"
set FORJA65_AUDIO_MODE=native
set FORJA65_AUDIO_GAIN=100
set FORJA65_AUDIO_DUMP=0
set FORJA65_HEADLESS=0
call RUN-WINDOWS.cmd
