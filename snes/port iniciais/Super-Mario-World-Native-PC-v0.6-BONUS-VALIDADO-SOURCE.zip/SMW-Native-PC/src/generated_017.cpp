#include "generated.hpp"
void sub_0080F7_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0080F7u: goto L_0080F7;
    case 0x0080F8u: goto L_0080F8;
    case 0x0080FBu: goto L_0080FB;
    case 0x0080FCu: goto L_0080FC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0080F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u,cpu,0x78u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080F7 SEI
    cpu.setFlag('I', true);
    goto L_0080F8;
L_0080F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F8u, 6u, 3u, cpu.address("abs", 0x8079u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0080F8 JSR -> $008079 stack real
    { cpu.push16Value(hw,0x80FAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80FBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8079u), 0x0080F8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0080FB;
L_0080FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80FBu,0x0080FBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu,cpu,0x58u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080FB CLI
    cpu.setFlag('I', false);
    goto L_0080FC;
L_0080FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0080FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0080FCu);return;} hw.unresolvedReturn(0x0080FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_008134_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00811Du: goto L_00811D;
    case 0x00811Fu: goto L_00811F;
    case 0x008122u: goto L_008122;
    case 0x008125u: goto L_008125;
    case 0x008127u: goto L_008127;
    case 0x00812Au: goto L_00812A;
    case 0x00812Du: goto L_00812D;
    case 0x008130u: goto L_008130;
    case 0x008131u: goto L_008131;
    case 0x008133u: goto L_008133;
    case 0x008134u: goto L_008134;
    case 0x008137u: goto L_008137;
    case 0x008139u: goto L_008139;
    case 0x00813Cu: goto L_00813C;
    case 0x00813Eu: goto L_00813E;
    case 0x008140u: goto L_008140;
    case 0x008143u: goto L_008143;
    case 0x008146u: goto L_008146;
    case 0x008148u: goto L_008148;
    case 0x00814Au: goto L_00814A;
    case 0x00814Du: goto L_00814D;
    case 0x00814Fu: goto L_00814F;
    case 0x008152u: goto L_008152;
    case 0x008154u: goto L_008154;
    case 0x008157u: goto L_008157;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00811D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00811D LDA
    cpu.setA(0xFFu, 8);
    goto L_00811F;
L_00811F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00811F STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_008122;
L_008122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u, 6u, 3u, cpu.address("abs", 0x80F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008122 JSR -> $0080F7 stack real
    { cpu.push16Value(hw,0x8124u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8125u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80F7u), 0x008122u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008125;
L_008125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8125u,0x008125u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008125 LDX
    cpu.setX(0x3u, 8);
    goto L_008127;
L_008127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u, 5u, 3u, cpu.address("absx", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008127 STZ
    hw.write(cpu.address("absx", 0x2140u), 0, cpu.m8?8:16);
    goto L_00812A;
L_00812A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au, 5u, 3u, cpu.address("absx", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00812A STZ
    hw.write(cpu.address("absx", 0x1DF9u), 0, cpu.m8?8:16);
    goto L_00812D;
L_00812D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du, 5u, 3u, cpu.address("absx", 0x1DFDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00812D STZ
    hw.write(cpu.address("absx", 0x1DFDu), 0, cpu.m8?8:16);
    goto L_008130;
L_008130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008130 DEX
    cpu.decReg('X');
    goto L_008131;
L_008131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008131 BPL -> $008127
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008127; }
    goto L_008133;
L_008133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008133 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008133u);return;} hw.unresolvedReturn(0x008133u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_008134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8134u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8134u, 4u, 3u, cpu.address("abs", 0x1425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008134 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1425u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008137;
L_008137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8137u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8137u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008137 BNE -> $008148
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008148; }
    goto L_008139;
L_008139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8139u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8139u, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008139 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00813C;
L_00813C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00813C CMP
    cpu.compareA(0xE9u);
    goto L_00813E;
L_00813E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00813E BEQ -> $008148
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008148; }
    goto L_008140;
L_008140:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8140u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8140u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8140u, 4u, 3u, cpu.address("abs", 0x141Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008140 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x141Au), cpu.m8?8:16));
    goto L_008143;
L_008143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8143u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8143u, 4u, 3u, cpu.address("abs", 0x141Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008143 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x141Du), cpu.m8?8:16));
    goto L_008146;
L_008146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8146u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8146u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008146 BNE -> $008133
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008133; }
    goto L_008148;
L_008148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8148u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8148u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008148 LDA
    cpu.setA(0xD6u, 8);
    goto L_00814A;
L_00814A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Au, 4u, 3u, cpu.address("abs", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00814A STA
    hw.write(cpu.address("abs", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00814D;
L_00814D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00814D LDA
    cpu.setA(0xAEu, 8);
    goto L_00814F;
L_00814F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Fu, 4u, 3u, cpu.address("abs", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00814F STA
    hw.write(cpu.address("abs", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_008152;
L_008152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8152u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8152u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008152 LDA
    cpu.setA(0xEu, 8);
    goto L_008154;
L_008154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8154u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8154u, 4u, 3u, cpu.address("abs", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008154 STA
    hw.write(cpu.address("abs", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_008157;
L_008157:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8157u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8157u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8157u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008157 BRA -> $00811D
    goto L_00811D;
}

void sub_00AE47_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00AE47u: goto L_00AE47;
    case 0x00AE49u: goto L_00AE49;
    case 0x00AE4Bu: goto L_00AE4B;
    case 0x00AE4Eu: goto L_00AE4E;
    case 0x00AE51u: goto L_00AE51;
    case 0x00AE52u: goto L_00AE52;
    case 0x00AE54u: goto L_00AE54;
    case 0x00AE55u: goto L_00AE55;
    case 0x00AE57u: goto L_00AE57;
    case 0x00AE59u: goto L_00AE59;
    case 0x00AE5Bu: goto L_00AE5B;
    case 0x00AE5Eu: goto L_00AE5E;
    case 0x00AE61u: goto L_00AE61;
    case 0x00AE62u: goto L_00AE62;
    case 0x00AE64u: goto L_00AE64;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00AE47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE47u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE47 LDX
    cpu.setX(0x2u, 8);
    goto L_00AE49;
L_00AE49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE49u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE49u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE49 REP
    cpu.rep(0x20u);
    goto L_00AE4B;
L_00AE4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Bu, 5u, 3u, cpu.address("abs", 0x0701u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE4B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x701u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AE4E;
L_00AE4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Eu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Eu, 4u + ((((0xAE41u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xAE41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE4E LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xAE41u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00AE51;
L_00AE51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE51u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE51 DEY
    cpu.decReg('Y');
    goto L_00AE52;
L_00AE52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE52u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE52u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE52 BMI -> $00AE57
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AE57; }
    goto L_00AE54;
L_00AE54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE54u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE54 LSR
    cpu.lsrA();
    goto L_00AE55;
L_00AE55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE55u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE55u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE55 BRA -> $00AE51
    goto L_00AE51;
L_00AE57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE57u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE57u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE57 SEP
    cpu.sep(0x20u);
    goto L_00AE59;
L_00AE59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE59u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE59 AND
    cpu.logicAnd(0x1Fu);
    goto L_00AE5B;
L_00AE5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Bu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Bu, 4u + ((((0xAE44u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xAE44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE5B ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0xAE44u), cpu.m8?8:16));
    goto L_00AE5E;
L_00AE5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Eu, 4u, 3u, cpu.address("abs", 0x2132u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE5E STA
    hw.write(cpu.address("abs", 0x2132u), cpu.a, cpu.m8?8:16);
    goto L_00AE61;
L_00AE61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE61u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE61u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE61 DEX
    cpu.decReg('X');
    goto L_00AE62;
L_00AE62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE62u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE62 BPL -> $00AE49
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AE49; }
    goto L_00AE64;
L_00AE64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE64u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE64u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AE64 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00AE64u);return;} hw.unresolvedReturn(0x00AE64u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00BEB0_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00BEB0u: goto L_00BEB0;
    case 0x00BEB1u: goto L_00BEB1;
    case 0x00BEB3u: goto L_00BEB3;
    case 0x00BEB4u: goto L_00BEB4;
    case 0x00BEB6u: goto L_00BEB6;
    case 0x00BEB9u: goto L_00BEB9;
    case 0x00BEBBu: goto L_00BEBB;
    case 0x00BEBEu: goto L_00BEBE;
    case 0x00BEC0u: goto L_00BEC0;
    case 0x00BEC2u: goto L_00BEC2;
    case 0x00BEC4u: goto L_00BEC4;
    case 0x00BEC6u: goto L_00BEC6;
    case 0x00BEC9u: goto L_00BEC9;
    case 0x00BECBu: goto L_00BECB;
    case 0x00BECDu: goto L_00BECD;
    case 0x00BECFu: goto L_00BECF;
    case 0x00BED2u: goto L_00BED2;
    case 0x00BED4u: goto L_00BED4;
    case 0x00BED6u: goto L_00BED6;
    case 0x00BED8u: goto L_00BED8;
    case 0x00BEDAu: goto L_00BEDA;
    case 0x00BEDCu: goto L_00BEDC;
    case 0x00BEDEu: goto L_00BEDE;
    case 0x00BEE0u: goto L_00BEE0;
    case 0x00BEE2u: goto L_00BEE2;
    case 0x00BEE4u: goto L_00BEE4;
    case 0x00BEE6u: goto L_00BEE6;
    case 0x00BEE8u: goto L_00BEE8;
    case 0x00BEEAu: goto L_00BEEA;
    case 0x00BEECu: goto L_00BEEC;
    case 0x00BEEFu: goto L_00BEEF;
    case 0x00BEF1u: goto L_00BEF1;
    case 0x00BEF4u: goto L_00BEF4;
    case 0x00BEF5u: goto L_00BEF5;
    case 0x00BEF6u: goto L_00BEF6;
    case 0x00BEFAu: goto L_00BEFA;
    case 0x00BEFCu: goto L_00BEFC;
    case 0x00BF00u: goto L_00BF00;
    case 0x00BF02u: goto L_00BF02;
    case 0x00BF04u: goto L_00BF04;
    case 0x00BF07u: goto L_00BF07;
    case 0x00BF08u: goto L_00BF08;
    case 0x00BF09u: goto L_00BF09;
    case 0x00BF0Bu: goto L_00BF0B;
    case 0x00BF0Du: goto L_00BF0D;
    case 0x00BF0Eu: goto L_00BF0E;
    case 0x00BF10u: goto L_00BF10;
    case 0x00BF12u: goto L_00BF12;
    case 0x00BF14u: goto L_00BF14;
    case 0x00BF16u: goto L_00BF16;
    case 0x00BF18u: goto L_00BF18;
    case 0x00BF19u: goto L_00BF19;
    case 0x00BF1Au: goto L_00BF1A;
    case 0x00BF1Cu: goto L_00BF1C;
    case 0x00BF1Du: goto L_00BF1D;
    case 0x00BF1Fu: goto L_00BF1F;
    case 0x00BF21u: goto L_00BF21;
    case 0x00BF23u: goto L_00BF23;
    case 0x00BF24u: goto L_00BF24;
    case 0x00BF26u: goto L_00BF26;
    case 0x00BF28u: goto L_00BF28;
    case 0x00BF2Au: goto L_00BF2A;
    case 0x00BF2Cu: goto L_00BF2C;
    case 0x00BF2Eu: goto L_00BF2E;
    case 0x00BF2Fu: goto L_00BF2F;
    case 0x00BF31u: goto L_00BF31;
    case 0x00BF33u: goto L_00BF33;
    case 0x00BF35u: goto L_00BF35;
    case 0x00BF37u: goto L_00BF37;
    case 0x00BF39u: goto L_00BF39;
    case 0x00BF3Au: goto L_00BF3A;
    case 0x00BF3Cu: goto L_00BF3C;
    case 0x00BF3Eu: goto L_00BF3E;
    case 0x00BF41u: goto L_00BF41;
    case 0x00BF43u: goto L_00BF43;
    case 0x00BF44u: goto L_00BF44;
    case 0x00BF46u: goto L_00BF46;
    case 0x00BF47u: goto L_00BF47;
    case 0x00BF48u: goto L_00BF48;
    case 0x00BF49u: goto L_00BF49;
    case 0x00BF4Bu: goto L_00BF4B;
    case 0x00BF4Du: goto L_00BF4D;
    case 0x00BF50u: goto L_00BF50;
    case 0x00BF52u: goto L_00BF52;
    case 0x00BF53u: goto L_00BF53;
    case 0x00BF55u: goto L_00BF55;
    case 0x00BF57u: goto L_00BF57;
    case 0x00BF59u: goto L_00BF59;
    case 0x00BF5Bu: goto L_00BF5B;
    case 0x00BF5Cu: goto L_00BF5C;
    case 0x00BF5Du: goto L_00BF5D;
    case 0x00BF5Eu: goto L_00BF5E;
    case 0x00BF60u: goto L_00BF60;
    case 0x00BF61u: goto L_00BF61;
    case 0x00BF63u: goto L_00BF63;
    case 0x00BF65u: goto L_00BF65;
    case 0x00BF67u: goto L_00BF67;
    case 0x00BF69u: goto L_00BF69;
    case 0x00BF6Bu: goto L_00BF6B;
    case 0x00BF6Cu: goto L_00BF6C;
    case 0x00BF6Du: goto L_00BF6D;
    case 0x00BF6Eu: goto L_00BF6E;
    case 0x00BF70u: goto L_00BF70;
    case 0x00BF72u: goto L_00BF72;
    case 0x00BF74u: goto L_00BF74;
    case 0x00BF76u: goto L_00BF76;
    case 0x00BF78u: goto L_00BF78;
    case 0x00BF7Au: goto L_00BF7A;
    case 0x00BF7Cu: goto L_00BF7C;
    case 0x00BF7Fu: goto L_00BF7F;
    case 0x00BF81u: goto L_00BF81;
    case 0x00BF83u: goto L_00BF83;
    case 0x00BF84u: goto L_00BF84;
    case 0x00BF87u: goto L_00BF87;
    case 0x00BF88u: goto L_00BF88;
    case 0x00BF8Au: goto L_00BF8A;
    case 0x00BF8Du: goto L_00BF8D;
    case 0x00BF8Fu: goto L_00BF8F;
    case 0x00BF91u: goto L_00BF91;
    case 0x00BF93u: goto L_00BF93;
    case 0x00BF94u: goto L_00BF94;
    case 0x00BF97u: goto L_00BF97;
    case 0x00BF98u: goto L_00BF98;
    case 0x00BF9Bu: goto L_00BF9B;
    case 0x00BF9Du: goto L_00BF9D;
    case 0x00BF9Fu: goto L_00BF9F;
    case 0x00BFA0u: goto L_00BFA0;
    case 0x00BFA3u: goto L_00BFA3;
    case 0x00BFA4u: goto L_00BFA4;
    case 0x00BFA7u: goto L_00BFA7;
    case 0x00BFA9u: goto L_00BFA9;
    case 0x00BFABu: goto L_00BFAB;
    case 0x00BFACu: goto L_00BFAC;
    case 0x00BFAFu: goto L_00BFAF;
    case 0x00BFB0u: goto L_00BFB0;
    case 0x00BFB2u: goto L_00BFB2;
    case 0x00BFB4u: goto L_00BFB4;
    case 0x00BFB6u: goto L_00BFB6;
    case 0x00BFB9u: goto L_00BFB9;
    case 0x00BFBAu: goto L_00BFBA;
    case 0x00BFBBu: goto L_00BFBB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00BEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB0u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BEB0 PHP
    cpu.push("PHP", hw);
    goto L_00BEB1;
L_00BEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEB1 REP
    cpu.rep(0x30u);
    goto L_00BEB3;
L_00BEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB3u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00BEB3 PHX
    cpu.push("PHX", hw);
    goto L_00BEB4;
L_00BEB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEB4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BEB6;
L_00BEB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEB6 AND
    cpu.logicAnd(0xFFu);
    goto L_00BEB9;
L_00BEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEB9 BNE -> $00BEBE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00BEBE; }
    goto L_00BEBB;
L_00BEBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBBu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBBu, 3u, 3u, cpu.address("abs", 0xBFB9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEBB JMP -> $00BFB9
    goto L_00BFB9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBBu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBBu, 3u, 3u, cpu.address("abs", 0xBFB9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEBB JMP -> $00BFB9
    goto L_00BFB9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEBBu,0x00BEBBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00BEBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEBE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BEC0;
L_00BEC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEC0 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_00BEC2;
L_00BEC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEC2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BEC4;
L_00BEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEC4 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_00BEC6;
L_00BEC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEC6 LDA
    cpu.setA(0x0u, 16);
    goto L_00BEC9;
L_00BEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEC9 SEP
    cpu.sep(0x20u);
    goto L_00BECB;
L_00BECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BECB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BECD;
L_00BECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BECD STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_00BECF;
L_00BECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECFu, 4u, 3u, cpu.address("abs", 0x1933u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BECF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1933u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BED2;
L_00BED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BED2 BEQ -> $00BED6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00BED6; }
    goto L_00BED4;
L_00BED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED4u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BED4 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x9u), cpu.m8?8:16);
    goto L_00BED6;
L_00BED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED6u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BED6 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00BED8;
L_00BED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BED8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BEDA;
L_00BEDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEDA AND
    cpu.logicAnd(0x1u);
    goto L_00BEDC;
L_00BEDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEDC BEQ -> $00BEEC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00BEEC; }
    goto L_00BEDE;
L_00BEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEDE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BEE0;
L_00BEE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEE0 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00BEE2;
L_00BEE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEE2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x99u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BEE4;
L_00BEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEE4 STA
    hw.write(cpu.address("dp", 0x9Bu), cpu.a, cpu.m8?8:16);
    goto L_00BEE6;
L_00BEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEE6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BEE8;
L_00BEE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEE8 STA
    hw.write(cpu.address("dp", 0x99u), cpu.a, cpu.m8?8:16);
    goto L_00BEEA;
L_00BEEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEAu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEEA LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00BEEC;
L_00BEEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEECu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEEC CPY
    cpu.compareY(0x200u);
    goto L_00BEEF;
L_00BEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEFu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEEF BCS -> $00BEBB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00BEBB; }
    goto L_00BEF1;
L_00BEF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF1u, 4u, 3u, cpu.address("abs", 0x1933u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEF1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1933u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BEF4;
L_00BEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEF4 ASL
    cpu.aslA();
    goto L_00BEF5;
L_00BEF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEF5 TAX
    cpu.transfer("TAX");
    goto L_00BEF6;
L_00BEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF6u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF6u, 5u, 4u, ((0x00BEA8u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEF6 LDA
    cpu.loadA(hw.readW(((0xBEA8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BEFA;
L_00BEFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEFA STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_00BEFC;
L_00BEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFCu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFCu, 5u, 4u, ((0x00BEA9u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BEFC LDA
    cpu.loadA(hw.readW(((0xBEA9u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF00;
L_00BF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF00u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF00u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF00 STA
    hw.write(cpu.address("dp", 0x66u), cpu.a, cpu.m8?8:16);
    goto L_00BF02;
L_00BF02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF02u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF02u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF02 STZ
    hw.write(cpu.address("dp", 0x67u), 0, cpu.m8?8:16);
    goto L_00BF04;
L_00BF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF04u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF04u, 4u, 3u, cpu.address("abs", 0x1925u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF04 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1925u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF07;
L_00BF07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF07u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF07 ASL
    cpu.aslA();
    goto L_00BF08;
L_00BF08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF08u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF08u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF08 TAY
    cpu.transfer("TAY");
    goto L_00BF09;
L_00BF09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF09u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF09u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $00BF09 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF0B;
L_00BF0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF0B STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00BF0D;
L_00BF0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF0D INY
    cpu.inc('Y');
    goto L_00BF0E;
L_00BF0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Eu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $00BF0E LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF10;
L_00BF10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF10u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF10u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF10 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_00BF12;
L_00BF12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF12u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF12u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF12 STZ
    hw.write(cpu.address("dp", 0x6u), 0, cpu.m8?8:16);
    goto L_00BF14;
L_00BF14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF14u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF14u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF14 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF16;
L_00BF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF16u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF16u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF16 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_00BF18;
L_00BF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF18u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF18 ASL
    cpu.aslA();
    goto L_00BF19;
L_00BF19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF19u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF19u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF19 CLC
    cpu.setFlag('C', false);
    goto L_00BF1A;
L_00BF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF1A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16));
    goto L_00BF1C;
L_00BF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF1C TAY
    cpu.transfer("TAY");
    goto L_00BF1D;
L_00BF1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Du,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 3u, 0u);
    // $00BF1D LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF1F;
L_00BF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF1F STA
    hw.write(cpu.address("dp", 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_00BF21;
L_00BF21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF21u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF21u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF21 STA
    hw.write(cpu.address("dp", 0x6Eu), cpu.a, cpu.m8?8:16);
    goto L_00BF23;
L_00BF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF23u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF23 INY
    cpu.inc('Y');
    goto L_00BF24;
L_00BF24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF24u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF24u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 3u, 0u);
    // $00BF24 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF26;
L_00BF26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF26u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF26 STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_00BF28;
L_00BF28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF28u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF28u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF28 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_00BF2A;
L_00BF2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF2A LDA
    cpu.setA(0x7Eu, 8);
    goto L_00BF2C;
L_00BF2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF2C STA
    hw.write(cpu.address("dp", 0x6Du), cpu.a, cpu.m8?8:16);
    goto L_00BF2E;
L_00BF2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF2E INC
    cpu.inc('A');
    goto L_00BF2F;
L_00BF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x70u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF2F STA
    hw.write(cpu.address("dp", 0x70u), cpu.a, cpu.m8?8:16);
    goto L_00BF31;
L_00BF31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF31u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF31 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF33;
L_00BF33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF33u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF33 AND
    cpu.logicAnd(0x1u);
    goto L_00BF35;
L_00BF35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF35u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF35 BEQ -> $00BF41
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00BF41; }
    goto L_00BF37;
L_00BF37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF37u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF37u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF37 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x99u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF39;
L_00BF39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF39u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF39u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF39 LSR
    cpu.lsrA();
    goto L_00BF3A;
L_00BF3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF3A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF3C;
L_00BF3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF3C AND
    cpu.logicAnd(0x1u);
    goto L_00BF3E;
L_00BF3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Eu, 3u, 3u, cpu.address("abs", 0xBF46u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF3E JMP -> $00BF46
    goto L_00BF46;
L_00BF41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF41u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF41u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF41 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF43;
L_00BF43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF43u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF43 LSR
    cpu.lsrA();
    goto L_00BF44;
L_00BF44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF44u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF44u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF44 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x99u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF46;
L_00BF46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF46u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF46 ROL
    cpu.rolA();
    goto L_00BF47;
L_00BF47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF47u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF47 ASL
    cpu.aslA();
    goto L_00BF48;
L_00BF48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF48u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF48 ASL
    cpu.aslA();
    goto L_00BF49;
L_00BF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF49u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF49u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF49 ORA
    cpu.logicOr(0x20u);
    goto L_00BF4B;
L_00BF4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF4Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF4Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF4B STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00BF4D;
L_00BF4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF4Du,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF4D CPX
    cpu.compareX(0x0u);
    goto L_00BF50;
L_00BF50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF50u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF50 BEQ -> $00BF57
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00BF57; }
    goto L_00BF52;
L_00BF52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF52u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF52 CLC
    cpu.setFlag('C', false);
    goto L_00BF53;
L_00BF53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF53u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF53 ADC
    cpu.adc(0x10u);
    goto L_00BF55;
L_00BF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF55u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF55u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF55 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00BF57;
L_00BF57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF57u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF57u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF57 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF59;
L_00BF59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF59u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF59 AND
    cpu.logicAnd(0xF0u);
    goto L_00BF5B;
L_00BF5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF5B CLC
    cpu.setFlag('C', false);
    goto L_00BF5C;
L_00BF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF5C ASL
    cpu.aslA();
    goto L_00BF5D;
L_00BF5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Du,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF5D ROL
    cpu.rolA();
    goto L_00BF5E;
L_00BF5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF5E STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_00BF60;
L_00BF60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF60u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF60u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF60 ROL
    cpu.rolA();
    goto L_00BF61;
L_00BF61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF61u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF61 AND
    cpu.logicAnd(0x3u);
    goto L_00BF63;
L_00BF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF63u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF63u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF63 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_00BF65;
L_00BF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF65u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF65u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF65 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_00BF67;
L_00BF67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF67u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF67u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF67 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF69;
L_00BF69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF69u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF69u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF69 AND
    cpu.logicAnd(0xF0u);
    goto L_00BF6B;
L_00BF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF6B LSR
    cpu.lsrA();
    goto L_00BF6C;
L_00BF6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF6C LSR
    cpu.lsrA();
    goto L_00BF6D;
L_00BF6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF6D LSR
    cpu.lsrA();
    goto L_00BF6E;
L_00BF6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF6E STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00BF70;
L_00BF70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF70u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF70u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF70 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF72;
L_00BF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF72u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF72 AND
    cpu.logicAnd(0xC0u);
    goto L_00BF74;
L_00BF74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF74u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF74u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF74 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_00BF76;
L_00BF76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF76u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF76u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF76 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_00BF78;
L_00BF78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF78u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF78u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF78 REP
    cpu.rep(0x20u);
    goto L_00BF7A;
L_00BF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF7A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF7C;
L_00BF7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF7C AND
    cpu.logicAnd(0x1u);
    goto L_00BF7F;
L_00BF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF7F BNE -> $00BF9B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00BF9B; }
    goto L_00BF81;
L_00BF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF81u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF81u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF81 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF83;
L_00BF83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF83u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF83u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF83 SEC
    cpu.setFlag('C', true);
    goto L_00BF84;
L_00BF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF84u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF84 SBC
    cpu.sbc(0x80u);
    goto L_00BF87;
L_00BF87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF87u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF87u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF87 TAX
    cpu.transfer("TAX");
    goto L_00BF88;
L_00BF88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF88u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF88u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF88 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00BF8A;
L_00BF8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Au, 5u, 3u, cpu.address("abs", 0x1933u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF8A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1933u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF8D;
L_00BF8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF8D BEQ -> $00BFB2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00BFB2; }
    goto L_00BF8F;
L_00BF8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF8F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00BF91;
L_00BF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF91u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF91u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF91 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF93;
L_00BF93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF93u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF93u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF93 SEC
    cpu.setFlag('C', true);
    goto L_00BF94;
L_00BF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF94u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF94 SBC
    cpu.sbc(0x80u);
    goto L_00BF97;
L_00BF97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF97u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF97 TAY
    cpu.transfer("TAY");
    goto L_00BF98;
L_00BF98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF98u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF98u, 3u, 3u, cpu.address("abs", 0xBFB2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF98 JMP -> $00BFB2
    goto L_00BFB2;
L_00BF9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF9B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00BF9D;
L_00BF9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF9D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BF9F;
L_00BF9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BF9F SEC
    cpu.setFlag('C', true);
    goto L_00BFA0;
L_00BFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA0u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BFA0 SBC
    cpu.sbc(0x80u);
    goto L_00BFA3;
L_00BFA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BFA3 TAY
    cpu.transfer("TAY");
    goto L_00BFA4;
L_00BFA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA4u, 5u, 3u, cpu.address("abs", 0x1933u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BFA4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1933u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BFA7;
L_00BFA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BFA7 BEQ -> $00BFB2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00BFB2; }
    goto L_00BFA9;
L_00BFA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BFA9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BFAB;
L_00BFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFABu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BFAB SEC
    cpu.setFlag('C', true);
    goto L_00BFAC;
L_00BFAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFACu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BFAC SBC
    cpu.sbc(0x80u);
    goto L_00BFAF;
L_00BFAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFAFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFAFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BFAF TAX
    cpu.transfer("TAX");
    goto L_00BFB0;
L_00BFB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BFB0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x20u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00BFB2;
L_00BFB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB2u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BFB2 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_00BFB4;
L_00BFB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BFB4 STY
    hw.write(cpu.address("dp", 0xAu), cpu.y, cpu.x8?8:16);
    goto L_00BFB6;
L_00BFB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB6u, 6u, 3u, cpu.address("abs", 0xBFBCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00BFB6 JSR -> $00BFBC stack real
    { cpu.push16Value(hw,0xBFB8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBFB9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBFBCu), 0x00BFB6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00BFB9;
L_00BFB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB9u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB9u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00BFB9 PLX
    cpu.pop("PLX", hw);
    goto L_00BFBA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB9u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB9u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00BFB9 PLX
    cpu.pop("PLX", hw);
    goto L_00BFBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFB9u,0x00BFB9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00BFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBAu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BFBA PLP
    cpu.pop("PLP", hw);
    goto L_00BFBB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBAu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BFBA PLP
    cpu.pop("PLP", hw);
    goto L_00BFBB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFBAu,0x00BFBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00BFBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFBBu,0x00BFBBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBBu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00BFBB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00BFBBu);return;} hw.unresolvedReturn(0x00BFBBu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_00CA31_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CA31u: goto L_00CA31;
    case 0x00CA33u: goto L_00CA33;
    case 0x00CA36u: goto L_00CA36;
    case 0x00CA38u: goto L_00CA38;
    case 0x00CA3Au: goto L_00CA3A;
    case 0x00CA3Du: goto L_00CA3D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA31u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA31 LDA
    cpu.setA(0x26u, 8);
    goto L_00CA33;
L_00CA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA33u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA33u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA33 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x187Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CA36;
L_00CA36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA36u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA36 BEQ -> $00CA3A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA3A; }
    goto L_00CA38;
L_00CA38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA38u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA38 LDA
    cpu.setA(0x14u, 8);
    goto L_00CA3A;
L_00CA3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Au, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA3A STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00CA3D;
L_00CA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA3D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CA3Du);return;} hw.unresolvedReturn(0x00CA3Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CA31_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CA31u: goto L_00CA31;
    case 0x00CA33u: goto L_00CA33;
    case 0x00CA36u: goto L_00CA36;
    case 0x00CA38u: goto L_00CA38;
    case 0x00CA3Au: goto L_00CA3A;
    case 0x00CA3Du: goto L_00CA3D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA31u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA31 LDA
    cpu.setA(0x26u, 8);
    goto L_00CA33;
L_00CA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA33u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA33u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA33 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x187Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CA36;
L_00CA36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA36u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA36 BEQ -> $00CA3A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA3A; }
    goto L_00CA38;
L_00CA38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA38u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA38 LDA
    cpu.setA(0x14u, 8);
    goto L_00CA3A;
L_00CA3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Au, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA3A STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00CA3D;
L_00CA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA3D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CA3Du);return;} hw.unresolvedReturn(0x00CA3Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00DC2D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00DC2Du: goto L_00DC2D;
    case 0x00DC2Fu: goto L_00DC2F;
    case 0x00DC31u: goto L_00DC31;
    case 0x00DC34u: goto L_00DC34;
    case 0x00DC36u: goto L_00DC36;
    case 0x00DC37u: goto L_00DC37;
    case 0x00DC39u: goto L_00DC39;
    case 0x00DC3Bu: goto L_00DC3B;
    case 0x00DC3Du: goto L_00DC3D;
    case 0x00DC3Eu: goto L_00DC3E;
    case 0x00DC40u: goto L_00DC40;
    case 0x00DC42u: goto L_00DC42;
    case 0x00DC45u: goto L_00DC45;
    case 0x00DC47u: goto L_00DC47;
    case 0x00DC4Au: goto L_00DC4A;
    case 0x00DC4Cu: goto L_00DC4C;
    case 0x00DC4Eu: goto L_00DC4E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00DC2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC2F;
L_00DC2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC2F STA
    hw.write(cpu.address("dp", 0x8Au), cpu.a, cpu.m8?8:16);
    goto L_00DC31;
L_00DC31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC31u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC31u, 4u, 3u, cpu.address("abs", 0x13E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC31 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13E3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC34;
L_00DC34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC34u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC34u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC34 BEQ -> $00DC40
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DC40; }
    goto L_00DC36;
L_00DC36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC36u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC36 LSR
    cpu.lsrA();
    goto L_00DC37;
L_00DC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC37u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC37u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC37 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC39;
L_00DC39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC39u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC39 BCC -> $00DC3E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00DC3E; }
    goto L_00DC3B;
L_00DC3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC3B EOR
    cpu.logicXor(0xFFu);
    goto L_00DC3D;
L_00DC3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC3D INC
    cpu.inc('A');
    goto L_00DC3E;
L_00DC3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC3E STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00DC40;
L_00DC40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC40u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC40 LDX
    cpu.setX(0x0u, 8);
    goto L_00DC42;
L_00DC42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC42u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC42u, 6u, 3u, cpu.address("abs", 0xDC4Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC42 JSR -> $00DC4F stack real
    { cpu.push16Value(hw,0xDC44u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC45u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDC4Fu), 0x00DC42u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DC45;
L_00DC45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC45u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC45u,0x00DC45u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC45u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC45 LDX
    cpu.setX(0x2u, 8);
    goto L_00DC47;
L_00DC47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC47u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC47u, 6u, 3u, cpu.address("abs", 0xDC4Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC47 JSR -> $00DC4F stack real
    { cpu.push16Value(hw,0xDC49u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC4Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDC4Fu), 0x00DC47u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DC4A;
L_00DC4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC4Au,0x00DC4Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC4A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC4C;
L_00DC4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC4C STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00DC4E;
L_00DC4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC4E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DC4Eu);return;} hw.unresolvedReturn(0x00DC4Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00EBDD_E0M1X1C1_part19(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF1Cu: goto L_00EF1C;
    case 0x00EF1Fu: goto L_00EF1F;
    case 0x00EF21u: goto L_00EF21;
    case 0x00EF23u: goto L_00EF23;
    case 0x00EF25u: goto L_00EF25;
    case 0x00EF26u: goto L_00EF26;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Cu))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu, 5u, 3u, cpu.address("abs", 0x13E5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1C STX
    hw.write(cpu.address("abs", 0x13E5u), cpu.x, cpu.x8?8:16);
    goto L_00EF1F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1C STX
    hw.write(cpu.address("abs", 0x13E5u), cpu.x, cpu.x8?8:16);
    goto L_00EF1F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu, 5u, 3u, cpu.address("abs", 0x13E5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1C STX
    hw.write(cpu.address("abs", 0x13E5u), cpu.x, cpu.x8?8:16);
    goto L_00EF1F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1C STX
    hw.write(cpu.address("abs", 0x13E5u), cpu.x, cpu.x8?8:16);
    goto L_00EF1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,0x00EF1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Fu))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF21;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF21;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF21;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,0x00EF1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF21u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF21 BPL -> $00EF26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF26; }
    goto L_00EF23;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF21 BPL -> $00EF26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF26; }
    goto L_00EF23;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF21 BPL -> $00EF26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF26; }
    goto L_00EF23;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF21 BPL -> $00EF26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF26; }
    goto L_00EF23;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF21u,0x00EF21u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF23u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF23 EOR
    cpu.logicXor(0x1AFFu);
    goto L_00EF26;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF23 EOR
    cpu.logicXor(0x1AFFu);
    goto L_00EF26;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF23 EOR
    cpu.logicXor(0xFFu);
    goto L_00EF25;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF23 EOR
    cpu.logicXor(0xFFu);
    goto L_00EF25;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF23u,0x00EF23u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF25u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF25 INC
    cpu.inc('A');
    goto L_00EF26;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF25 INC
    cpu.inc('A');
    goto L_00EF26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF25u,0x00EF25u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF26u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF26 CMP
    cpu.compareA(0x9028u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF29u,0x00EF26u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF26 CMP
    cpu.compareA(0x9028u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF29u,0x00EF26u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF26 CMP
    cpu.compareA(0x28u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF28u,0x00EF26u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF26 CMP
    cpu.compareA(0x28u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF28u,0x00EF26u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF26u,0x00EF26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part19(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF1Cu: goto L_00EF1C;
    case 0x00EF1Fu: goto L_00EF1F;
    case 0x00EF21u: goto L_00EF21;
    case 0x00EF23u: goto L_00EF23;
    case 0x00EF25u: goto L_00EF25;
    case 0x00EF26u: goto L_00EF26;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Cu))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu, 5u, 3u, cpu.address("abs", 0x13E5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1C STX
    hw.write(cpu.address("abs", 0x13E5u), cpu.x, cpu.x8?8:16);
    goto L_00EF1F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1C STX
    hw.write(cpu.address("abs", 0x13E5u), cpu.x, cpu.x8?8:16);
    goto L_00EF1F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu, 5u, 3u, cpu.address("abs", 0x13E5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1C STX
    hw.write(cpu.address("abs", 0x13E5u), cpu.x, cpu.x8?8:16);
    goto L_00EF1F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1C STX
    hw.write(cpu.address("abs", 0x13E5u), cpu.x, cpu.x8?8:16);
    goto L_00EF1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,0x00EF1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Fu))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF21;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF21;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF21;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,0x00EF1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF21u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF21 BPL -> $00EF26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF26; }
    goto L_00EF23;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF21 BPL -> $00EF26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF26; }
    goto L_00EF23;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF21 BPL -> $00EF26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF26; }
    goto L_00EF23;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF21 BPL -> $00EF26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF26; }
    goto L_00EF23;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF21u,0x00EF21u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF23u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF23 EOR
    cpu.logicXor(0x1AFFu);
    goto L_00EF26;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF23 EOR
    cpu.logicXor(0x1AFFu);
    goto L_00EF26;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF23 EOR
    cpu.logicXor(0xFFu);
    goto L_00EF25;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF23 EOR
    cpu.logicXor(0xFFu);
    goto L_00EF25;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF23u,0x00EF23u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF25u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF25 INC
    cpu.inc('A');
    goto L_00EF26;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF25 INC
    cpu.inc('A');
    goto L_00EF26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF25u,0x00EF25u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF26u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF26 CMP
    cpu.compareA(0x9028u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF29u,0x00EF26u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF26 CMP
    cpu.compareA(0x9028u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF29u,0x00EF26u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF26 CMP
    cpu.compareA(0x28u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF28u,0x00EF26u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF26 CMP
    cpu.compareA(0x28u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF28u,0x00EF26u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF26u,0x00EF26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_018172_E0M1X1C0_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018172u: goto L_018172;
    case 0x018174u: goto L_018174;
    case 0x018177u: goto L_018177;
    case 0x018179u: goto L_018179;
    case 0x01817Du: goto L_01817D;
    case 0x01817Fu: goto L_01817F;
    case 0x018181u: goto L_018181;
    case 0x018183u: goto L_018183;
    case 0x018185u: goto L_018185;
    case 0x018187u: goto L_018187;
    case 0x018189u: goto L_018189;
    case 0x01818Au: goto L_01818A;
    case 0x01818Bu: goto L_01818B;
    case 0x01818Cu: goto L_01818C;
    case 0x01818Du: goto L_01818D;
    case 0x01818Eu: goto L_01818E;
    case 0x01818Fu: goto L_01818F;
    case 0x018190u: goto L_018190;
    case 0x018192u: goto L_018192;
    case 0x018194u: goto L_018194;
    case 0x018196u: goto L_018196;
    case 0x018198u: goto L_018198;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8172u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8172u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018172 LDA
    cpu.setA(0x8u, 8);
    goto L_018174;
L_018174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018174 STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_018177;
L_018177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8177u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8177u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018177 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018179;
L_018179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8179u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8179u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $018179 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x817Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x817Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x018179u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01817D;
L_01817D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x817Du,0x01817Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Du,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01817D ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_01817F;
L_01817F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Fu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01817F ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_018181;
L_018181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8181u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8181u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018181 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_018183;
L_018183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8183u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8183u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018183 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_018185;
L_018185:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8185u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8185u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8185u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018185 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_018187;
L_018187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8187u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8187u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018187 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_018189;
L_018189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018189 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_01818B;
L_01818A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Au))return;
  // 16 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01818A STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_01818C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x818Au,0x01818Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01818B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Bu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01818B ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_01818D;
L_01818C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Cu))return;
  // 16 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01818C STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_01818E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x818Cu,0x01818Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01818D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Du,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01818D ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_01818F;
L_01818E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Eu))return;
  // 16 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01818E STA
    hw.write(cpu.address("dp", 0x6Eu), cpu.a, cpu.m8?8:16);
    goto L_018190;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x818Eu,0x01818Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01818F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Fu,cpu,0x6Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Fu, 6u, 3u, cpu.address("abs", 0x7585u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01818F ROR
    cpu.rorMem(hw, cpu.address("abs", 0x7585u), cpu.m8?8:16);
    goto L_018192;
L_018190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8190u))return;
  // 16 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8190u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8190u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018190 STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_018192;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8190u,0x018190u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8192u))return;
  // 17 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8192u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8192u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018192 STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_018194;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8192u,0x018192u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8194u))return;
  // 17 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8194u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8194u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018194 STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_018196;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8194u,0x018194u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8196u))return;
  // 17 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8196u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8196u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018196 STA
    hw.write(cpu.address("dp", 0x5Du), cpu.a, cpu.m8?8:16);
    goto L_018198;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8196u,0x018196u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8198u))return;
  // 17 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8198u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8198u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018198 STA
    hw.write(cpu.address("dp", 0xB8u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x819Au,0x018198u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8198u,0x018198u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_018172_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018172u: goto L_018172;
    case 0x018174u: goto L_018174;
    case 0x018177u: goto L_018177;
    case 0x018179u: goto L_018179;
    case 0x01817Du: goto L_01817D;
    case 0x01817Fu: goto L_01817F;
    case 0x018181u: goto L_018181;
    case 0x018183u: goto L_018183;
    case 0x018185u: goto L_018185;
    case 0x018187u: goto L_018187;
    case 0x018189u: goto L_018189;
    case 0x01818Au: goto L_01818A;
    case 0x01818Bu: goto L_01818B;
    case 0x01818Cu: goto L_01818C;
    case 0x01818Du: goto L_01818D;
    case 0x01818Eu: goto L_01818E;
    case 0x01818Fu: goto L_01818F;
    case 0x018190u: goto L_018190;
    case 0x018192u: goto L_018192;
    case 0x018194u: goto L_018194;
    case 0x018196u: goto L_018196;
    case 0x018198u: goto L_018198;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8172u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8172u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018172 LDA
    cpu.setA(0x8u, 8);
    goto L_018174;
L_018174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018174 STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_018177;
L_018177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8177u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8177u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018177 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018179;
L_018179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8179u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8179u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $018179 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x817Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x817Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x018179u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01817D;
L_01817D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x817Du,0x01817Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Du,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01817D ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_01817F;
L_01817F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Fu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01817F ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_018181;
L_018181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8181u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8181u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018181 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_018183;
L_018183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8183u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8183u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018183 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_018185;
L_018185:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8185u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8185u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8185u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018185 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_018187;
L_018187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8187u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8187u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018187 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_018189;
L_018189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018189 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_01818B;
L_01818A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Au))return;
  // 16 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01818A STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_01818C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x818Au,0x01818Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01818B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Bu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01818B ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_01818D;
L_01818C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Cu))return;
  // 16 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01818C STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_01818E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x818Cu,0x01818Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01818D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Du,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01818D ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x85u), cpu.m8?8:16));
    goto L_01818F;
L_01818E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Eu))return;
  // 16 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01818E STA
    hw.write(cpu.address("dp", 0x6Eu), cpu.a, cpu.m8?8:16);
    goto L_018190;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x818Eu,0x01818Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01818F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Fu,cpu,0x6Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Fu, 6u, 3u, cpu.address("abs", 0x7585u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01818F ROR
    cpu.rorMem(hw, cpu.address("abs", 0x7585u), cpu.m8?8:16);
    goto L_018192;
L_018190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8190u))return;
  // 16 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8190u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8190u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018190 STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_018192;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8190u,0x018190u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8192u))return;
  // 17 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8192u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8192u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018192 STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_018194;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8192u,0x018192u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8194u))return;
  // 17 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8194u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8194u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018194 STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_018196;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8194u,0x018194u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8196u))return;
  // 17 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8196u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8196u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018196 STA
    hw.write(cpu.address("dp", 0x5Du), cpu.a, cpu.m8?8:16);
    goto L_018198;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8196u,0x018196u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8198u))return;
  // 17 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8198u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8198u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018198 STA
    hw.write(cpu.address("dp", 0xB8u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x819Au,0x018198u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8198u,0x018198u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_02CBA1_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02CBA1u: goto L_02CBA1;
    case 0x02CBA3u: goto L_02CBA3;
    case 0x02CBA5u: goto L_02CBA5;
    case 0x02CBA7u: goto L_02CBA7;
    case 0x02CBAAu: goto L_02CBAA;
    case 0x02CBACu: goto L_02CBAC;
    case 0x02CBAEu: goto L_02CBAE;
    case 0x02CBB0u: goto L_02CBB0;
    case 0x02CBB2u: goto L_02CBB2;
    case 0x02CBB4u: goto L_02CBB4;
    case 0x02CBB6u: goto L_02CBB6;
    case 0x02CBB7u: goto L_02CBB7;
    case 0x02CBB9u: goto L_02CBB9;
    case 0x02CBBBu: goto L_02CBBB;
    case 0x02CBBEu: goto L_02CBBE;
    case 0x02CBBFu: goto L_02CBBF;
    case 0x02CBC1u: goto L_02CBC1;
    case 0x02CBC2u: goto L_02CBC2;
    case 0x02CBC3u: goto L_02CBC3;
    case 0x02CBC5u: goto L_02CBC5;
    case 0x02CBC6u: goto L_02CBC6;
    case 0x02CBC9u: goto L_02CBC9;
    case 0x02CBCAu: goto L_02CBCA;
    case 0x02CBCCu: goto L_02CBCC;
    case 0x02CBCDu: goto L_02CBCD;
    case 0x02CBD0u: goto L_02CBD0;
    case 0x02CBD3u: goto L_02CBD3;
    case 0x02CBD4u: goto L_02CBD4;
    case 0x02CBD6u: goto L_02CBD6;
    case 0x02CBD7u: goto L_02CBD7;
    case 0x02CBDAu: goto L_02CBDA;
    case 0x02CBDCu: goto L_02CBDC;
    case 0x02CBDFu: goto L_02CBDF;
    case 0x02CBE1u: goto L_02CBE1;
    case 0x02CBE3u: goto L_02CBE3;
    case 0x02CBE4u: goto L_02CBE4;
    case 0x02CBE7u: goto L_02CBE7;
    case 0x02CBEAu: goto L_02CBEA;
    case 0x02CBEDu: goto L_02CBED;
    case 0x02CBF0u: goto L_02CBF0;
    case 0x02CBF1u: goto L_02CBF1;
    case 0x02CBF2u: goto L_02CBF2;
    case 0x02CBF3u: goto L_02CBF3;
    case 0x02CBF4u: goto L_02CBF4;
    case 0x02CBF7u: goto L_02CBF7;
    case 0x02CBFAu: goto L_02CBFA;
    case 0x02CBFBu: goto L_02CBFB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02CBA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA1u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBA1 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02CBA3;
L_02CBA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBA3 CMP
    cpu.compareA(0x46u);
    goto L_02CBA5;
L_02CBA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBA5 BNE -> $02CBFB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02CBFB; }
    goto L_02CBA7;
L_02CBA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA7u, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBA7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02CBAA;
L_02CBAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBAAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBAAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBAA CMP
    cpu.compareA(0x5u);
    goto L_02CBAC;
L_02CBAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBACu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBAC BNE -> $02CBB2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02CBB2; }
    goto L_02CBAE;
L_02CBAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBAEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBAE LDA
    cpu.setA(0x1u, 8);
    goto L_02CBB0;
L_02CBB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBB0 BRA -> $02CBB9
    goto L_02CBB9;
L_02CBB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBB2 CMP
    cpu.compareA(0xEu);
    goto L_02CBB4;
L_02CBB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBB4 BCC -> $02CBFB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_02CBFB; }
    goto L_02CBB6;
L_02CBB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBB6 SEC
    cpu.setFlag('C', true);
    goto L_02CBB7;
L_02CBB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBB7 SBC
    cpu.sbc(0xEu);
    goto L_02CBB9;
L_02CBB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBB9 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_02CBBB;
L_02CBBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBBBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBBBu, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBBB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02CBBE;
L_02CBBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBBEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBBE CLC
    cpu.setFlag('C', false);
    goto L_02CBBF;
L_02CBBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBBFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBBFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBBF ADC
    cpu.adc(0xCu);
    goto L_02CBC1;
L_02CBC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBC1 TAY
    cpu.transfer("TAY");
    goto L_02CBC2;
L_02CBC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC2u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02CBC2 PHX
    cpu.push("PHX", hw);
    goto L_02CBC3;
L_02CBC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBC3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02CBC5;
L_02CBC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBC5 ASL
    cpu.aslA();
    goto L_02CBC6;
L_02CBC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC6u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC6u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBC6 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16));
    goto L_02CBC9;
L_02CBC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBC9 TAX
    cpu.transfer("TAX");
    goto L_02CBCA;
L_02CBCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBCA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02CBCC;
L_02CBCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBCC CLC
    cpu.setFlag('C', false);
    goto L_02CBCD;
L_02CBCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCDu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCDu, 4u + ((((0xCB90u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCB90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBCD ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xCB90u), cpu.m8?8:16));
    goto L_02CBD0;
L_02CBD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD0u, 5u, 3u, cpu.address("absy", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBD0 STA
    hw.write(cpu.address("absy", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_02CBD3;
L_02CBD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD3u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBD3 TXA
    cpu.transfer("TXA");
    goto L_02CBD4;
L_02CBD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBD4 AND
    cpu.logicAnd(0x1u);
    goto L_02CBD6;
L_02CBD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBD6 TAX
    cpu.transfer("TAX");
    goto L_02CBD7;
L_02CBD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD7u, 4u + ((((0xCB96u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCB96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBD7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xCB96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02CBDA;
L_02CBDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBDAu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBDAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBDA ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16));
    goto L_02CBDC;
L_02CBDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBDCu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBDCu, 5u, 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBDC STA
    hw.write(cpu.address("absy", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_02CBDF;
L_02CBDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBDFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBDFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBDF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02CBE1;
L_02CBE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBE1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02CBE3;
L_02CBE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBE3 CLC
    cpu.setFlag('C', false);
    goto L_02CBE4;
L_02CBE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE4u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE4u, 4u + ((((0xCB98u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCB98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBE4 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xCB98u), cpu.m8?8:16));
    goto L_02CBE7;
L_02CBE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE7u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE7u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBE7 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_02CBEA;
L_02CBEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBEAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBEAu, 4u + ((((0xCB9Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCB9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBEA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xCB9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02CBED;
L_02CBED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBEDu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBEDu, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBED STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_02CBF0;
L_02CBF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF0u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBF0 TYA
    cpu.transfer("TYA");
    goto L_02CBF1;
L_02CBF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBF1 LSR
    cpu.lsrA();
    goto L_02CBF2;
L_02CBF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBF2 LSR
    cpu.lsrA();
    goto L_02CBF3;
L_02CBF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBF3 TAY
    cpu.transfer("TAY");
    goto L_02CBF4;
L_02CBF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF4u, 4u + ((((0xCB9Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCB9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBF4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xCB9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02CBF7;
L_02CBF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF7u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF7u, 5u, 3u, cpu.address("absy", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02CBF7 STA
    hw.write(cpu.address("absy", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_02CBFA;
L_02CBFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBFAu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBFAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02CBFA PLX
    cpu.pop("PLX", hw);
    goto L_02CBFB;
L_02CBFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBFBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBFBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02CBFB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02CBFBu);return;} hw.unresolvedReturn(0x02CBFBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02D017_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02D017u: goto L_02D017;
    case 0x02D019u: goto L_02D019;
    case 0x02D021u: goto L_02D021;
    case 0x02D023u: goto L_02D023;
    case 0x02D027u: goto L_02D027;
    case 0x02D02Au: goto L_02D02A;
    case 0x02D02Cu: goto L_02D02C;
    case 0x02D02Eu: goto L_02D02E;
    case 0x02D030u: goto L_02D030;
    case 0x02D032u: goto L_02D032;
    case 0x02D034u: goto L_02D034;
    case 0x02D036u: goto L_02D036;
    case 0x02D038u: goto L_02D038;
    case 0x02D03Au: goto L_02D03A;
    case 0x02D03Bu: goto L_02D03B;
    case 0x02D03Du: goto L_02D03D;
    case 0x02D040u: goto L_02D040;
    case 0x02D042u: goto L_02D042;
    case 0x02D044u: goto L_02D044;
    case 0x02D046u: goto L_02D046;
    case 0x02D049u: goto L_02D049;
    case 0x02D04Bu: goto L_02D04B;
    case 0x02D04Du: goto L_02D04D;
    case 0x02D04Fu: goto L_02D04F;
    case 0x02D051u: goto L_02D051;
    case 0x02D053u: goto L_02D053;
    case 0x02D055u: goto L_02D055;
    case 0x02D056u: goto L_02D056;
    case 0x02D058u: goto L_02D058;
    case 0x02D059u: goto L_02D059;
    case 0x02D05Cu: goto L_02D05C;
    case 0x02D05Eu: goto L_02D05E;
    case 0x02D060u: goto L_02D060;
    case 0x02D061u: goto L_02D061;
    case 0x02D063u: goto L_02D063;
    case 0x02D065u: goto L_02D065;
    case 0x02D068u: goto L_02D068;
    case 0x02D069u: goto L_02D069;
    case 0x02D06Cu: goto L_02D06C;
    case 0x02D06Eu: goto L_02D06E;
    case 0x02D070u: goto L_02D070;
    case 0x02D072u: goto L_02D072;
    case 0x02D074u: goto L_02D074;
    case 0x02D076u: goto L_02D076;
    case 0x02D078u: goto L_02D078;
    case 0x02D07Au: goto L_02D07A;
    case 0x02D07Du: goto L_02D07D;
    case 0x02D07Fu: goto L_02D07F;
    case 0x02D081u: goto L_02D081;
    case 0x02D084u: goto L_02D084;
    case 0x02D086u: goto L_02D086;
    case 0x02D088u: goto L_02D088;
    case 0x02D08Au: goto L_02D08A;
    case 0x02D08Du: goto L_02D08D;
    case 0x02D090u: goto L_02D090;
    case 0x02D091u: goto L_02D091;
    case 0x02D094u: goto L_02D094;
    case 0x02D096u: goto L_02D096;
    case 0x02D098u: goto L_02D098;
    case 0x02D09Au: goto L_02D09A;
    case 0x02D09Bu: goto L_02D09B;
    case 0x02D09Du: goto L_02D09D;
    case 0x02D09Fu: goto L_02D09F;
    case 0x02D0A1u: goto L_02D0A1;
    case 0x02D0A2u: goto L_02D0A2;
    case 0x02D0A4u: goto L_02D0A4;
    case 0x02D0A5u: goto L_02D0A5;
    case 0x02D0A8u: goto L_02D0A8;
    case 0x02D0AAu: goto L_02D0AA;
    case 0x02D0ACu: goto L_02D0AC;
    case 0x02D0ADu: goto L_02D0AD;
    case 0x02D0B0u: goto L_02D0B0;
    case 0x02D0B2u: goto L_02D0B2;
    case 0x02D0B5u: goto L_02D0B5;
    case 0x02D0B6u: goto L_02D0B6;
    case 0x02D0B9u: goto L_02D0B9;
    case 0x02D0BBu: goto L_02D0BB;
    case 0x02D0BDu: goto L_02D0BD;
    case 0x02D0BFu: goto L_02D0BF;
    case 0x02D0C1u: goto L_02D0C1;
    case 0x02D0C3u: goto L_02D0C3;
    case 0x02D0C5u: goto L_02D0C5;
    case 0x02D0C7u: goto L_02D0C7;
    case 0x02D0C9u: goto L_02D0C9;
    case 0x02D0CCu: goto L_02D0CC;
    case 0x02D0CFu: goto L_02D0CF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02D017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD017u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD017u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D017 LDA
    cpu.setA(0x6u, 8);
    goto L_02D019;
L_02D019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD019u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD019u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D019 BRA -> $02D021
    goto L_02D021;
L_02D021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD021u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD021u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D021 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_02D023;
L_02D023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD023u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD023u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D023 BRA -> $02D027
    goto L_02D027;
L_02D027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD027u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD027u, 6u, 3u, cpu.address("abs", 0xD0C9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02D027 JSR -> $02D0C9 stack real
    { cpu.push16Value(hw,0xD029u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD02Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD0C9u), 0x02D027u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02D02A;
L_02D02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD02Au,0x02D02Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D02A BEQ -> $02D090
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02D090; }
    goto L_02D02C;
L_02D02C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D02C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D02E;
L_02D02E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D02E AND
    cpu.logicAnd(0x1u);
    goto L_02D030;
L_02D030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD030u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD030u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D030 BNE -> $02D091
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02D091; }
    goto L_02D032;
L_02D032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD032u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD032u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD032u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D032 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D034;
L_02D034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD034u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD034u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D034 CMP
    cpu.compareA(0x4u);
    goto L_02D036;
L_02D036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD036u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD036u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D036 BEQ -> $02D04D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02D04D; }
    goto L_02D038;
L_02D038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD038u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD038u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D038 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D03A;
L_02D03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D03A CLC
    cpu.setFlag('C', false);
    goto L_02D03B;
L_02D03B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD03Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D03B ADC
    cpu.adc(0x50u);
    goto L_02D03D;
L_02D03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Du, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D03D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D040;
L_02D040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD040u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD040u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D040 ADC
    cpu.adc(0x0u);
    goto L_02D042;
L_02D042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD042u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD042u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D042 CMP
    cpu.compareA(0x2u);
    goto L_02D044;
L_02D044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD044u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD044u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D044 BPL -> $02D07A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02D07A; }
    goto L_02D046;
L_02D046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD046u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD046u, 4u + ((((0x167Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x167Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D046 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x167Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D049;
L_02D049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD049u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD049u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D049 AND
    cpu.logicAnd(0x4u);
    goto L_02D04B;
L_02D04B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD04Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D04B BNE -> $02D090
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02D090; }
    goto L_02D04D;
L_02D04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD04Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D04D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D04F;
L_02D04F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD04Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D04F AND
    cpu.logicAnd(0x1u);
    goto L_02D051;
L_02D051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD051u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD051u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D051 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_02D053;
L_02D053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD053u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD053u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D053 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_02D055;
L_02D055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD055u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD055u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D055 TAY
    cpu.transfer("TAY");
    goto L_02D056;
L_02D056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD056u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD056u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD056u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D056 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D058;
L_02D058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD058u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD058u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D058 CLC
    cpu.setFlag('C', false);
    goto L_02D059;
L_02D059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD059u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD059u, 4u + ((((0xD007u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD007u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D059 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD007u), cpu.m8?8:16));
    goto L_02D05C;
L_02D05C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD05Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Cu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D05C ROL
    cpu.rolMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_02D05E;
L_02D05E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD05Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Eu,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D05E CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16));
    goto L_02D060;
L_02D060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD060u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD060u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD060u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D060 PHP
    cpu.push("PHP", hw);
    goto L_02D061;
L_02D061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD061u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD061u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD061u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D061 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D063;
L_02D063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD063u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD063u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD063u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D063 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_02D065;
L_02D065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD065u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD065u, 4u + ((((0xD00Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD00Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D065 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD00Fu), cpu.m8?8:16));
    goto L_02D068;
L_02D068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD068u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD068u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD068u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D068 PLP
    cpu.pop("PLP", hw);
    goto L_02D069;
L_02D069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD069u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD069u,0x02D069u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD069u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD069u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D069 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16));
    goto L_02D06C;
L_02D06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D06C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_02D06E;
L_02D06E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD06Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Eu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D06E LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_02D070;
L_02D070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD070u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD070u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD070u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D070 BCC -> $02D076
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_02D076; }
    goto L_02D072;
L_02D072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD072u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD072u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D072 EOR
    cpu.logicXor(0x80u);
    goto L_02D074;
L_02D074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD074u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD074u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D074 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_02D076;
L_02D076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD076u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD076u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D076 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D078;
L_02D078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD078u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD078u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D078 BPL -> $02D090
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02D090; }
    goto L_02D07A;
L_02D07A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD07Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD07Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD07Au, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D07A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D07D;
L_02D07D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD07Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD07Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD07Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D07D CMP
    cpu.compareA(0x8u);
    goto L_02D07F;
L_02D07F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD07Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD07Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD07Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D07F BCC -> $02D08D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_02D08D; }
    goto L_02D081;
L_02D081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD081u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD081u, 4u + ((((0x161Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x161Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D081 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x161Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02D084;
L_02D084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD084u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD084u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D084 CPY
    cpu.compareY(0xFFu);
    goto L_02D086;
L_02D086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD086u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD086u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD086u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D086 BEQ -> $02D08D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02D08D; }
    goto L_02D088;
L_02D088:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD088u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD088u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD088u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D088 LDA
    cpu.setA(0x0u, 8);
    goto L_02D08A;
L_02D08A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD08Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Au, 5u, 3u, cpu.address("absy", 0x1938u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D08A STA
    hw.write(cpu.address("absy", 0x1938u), cpu.a, cpu.m8?8:16);
    goto L_02D08D;
L_02D08D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD08Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Du, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D08D STZ
    hw.write(cpu.address("absx", 0x14C8u), 0, cpu.m8?8:16);
    goto L_02D090;
L_02D090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD090u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD090u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD090u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02D090 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02D090u);return;} hw.unresolvedReturn(0x02D090u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_02D091:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD091u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD091u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD091u, 4u + ((((0x167Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x167Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D091 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x167Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D094;
L_02D094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD094u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD094u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD094u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D094 AND
    cpu.logicAnd(0x4u);
    goto L_02D096;
L_02D096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD096u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD096u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD096u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D096 BNE -> $02D090
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02D090; }
    goto L_02D098;
L_02D098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD098u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD098u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D098 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D09A;
L_02D09A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD09Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D09A LSR
    cpu.lsrA();
    goto L_02D09B;
L_02D09B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD09Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D09B BCS -> $02D090
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_02D090; }
    goto L_02D09D;
L_02D09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD09Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D09D AND
    cpu.logicAnd(0x1u);
    goto L_02D09F;
L_02D09F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD09Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D09F STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_02D0A1;
L_02D0A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0A1 TAY
    cpu.transfer("TAY");
    goto L_02D0A2;
L_02D0A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0A2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D0A4;
L_02D0A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0A4 CLC
    cpu.setFlag('C', false);
    goto L_02D0A5;
L_02D0A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A5u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A5u, 4u + ((((0xD003u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0A5 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD003u), cpu.m8?8:16));
    goto L_02D0A8;
L_02D0A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A8u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0A8 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_02D0AA;
L_02D0AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0AAu,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0AA CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16));
    goto L_02D0AC;
L_02D0AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ACu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ACu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D0AC PHP
    cpu.push("PHP", hw);
    goto L_02D0AD;
L_02D0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ADu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ADu, 4u, 3u, cpu.address("abs", 0x001Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0AD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D0B0;
L_02D0B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B0u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0B0 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_02D0B2;
L_02D0B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B2u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B2u, 4u + ((((0xD005u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0B2 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD005u), cpu.m8?8:16));
    goto L_02D0B5;
L_02D0B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B5u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D0B5 PLP
    cpu.pop("PLP", hw);
    goto L_02D0B6;
L_02D0B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0B6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0B6u,0x02D0B6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B6u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B6u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0B6 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16));
    goto L_02D0B9;
L_02D0B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0B9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_02D0BB;
L_02D0BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BBu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0BB LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02D0BD;
L_02D0BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0BD BEQ -> $02D0C3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02D0C3; }
    goto L_02D0BF;
L_02D0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BFu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0BF EOR
    cpu.logicXor(0x80u);
    goto L_02D0C1;
L_02D0C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0C1 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_02D0C3;
L_02D0C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0C3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D0C5;
L_02D0C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0C5 BPL -> $02D090
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02D090; }
    goto L_02D0C7;
L_02D0C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C7u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0C7 BMI -> $02D07A
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_02D07A; }
    goto L_02D0C9;
L_02D0C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C9u, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0C9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D0CC;
L_02D0CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CCu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CCu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0CC ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16));
    goto L_02D0CF;
L_02D0CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02D0CF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02D0CFu);return;} hw.unresolvedReturn(0x02D0CFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB1C8_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB1C8u: goto L_0DB1C8;
    case 0x0DB1CAu: goto L_0DB1CA;
    case 0x0DB1CCu: goto L_0DB1CC;
    case 0x0DB1CDu: goto L_0DB1CD;
    case 0x0DB1CFu: goto L_0DB1CF;
    case 0x0DB1D1u: goto L_0DB1D1;
    case 0x0DB1E3u: goto L_0DB1E3;
    case 0x0DB1E6u: goto L_0DB1E6;
    case 0x0DB1E8u: goto L_0DB1E8;
    case 0x0DB1EBu: goto L_0DB1EB;
    case 0x0DB1EDu: goto L_0DB1ED;
    case 0x0DB1F0u: goto L_0DB1F0;
    case 0x0DB1F1u: goto L_0DB1F1;
    case 0x0DB1F3u: goto L_0DB1F3;
    case 0x0DB1F5u: goto L_0DB1F5;
    case 0x0DB1F8u: goto L_0DB1F8;
    case 0x0DB1FBu: goto L_0DB1FB;
    case 0x0DB1FDu: goto L_0DB1FD;
    case 0x0DB200u: goto L_0DB200;
    case 0x0DB201u: goto L_0DB201;
    case 0x0DB203u: goto L_0DB203;
    case 0x0DB205u: goto L_0DB205;
    case 0x0DB208u: goto L_0DB208;
    case 0x0DB20Bu: goto L_0DB20B;
    case 0x0DB20Du: goto L_0DB20D;
    case 0x0DB20Fu: goto L_0DB20F;
    case 0x0DB211u: goto L_0DB211;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1C8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB1CA;
L_0DB1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1CA STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB1CC;
L_0DB1CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1CC TAX
    cpu.transfer("TAX");
    goto L_0DB1CD;
L_0DB1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1CD LDA
    cpu.setA(0x2u, 8);
    goto L_0DB1CF;
L_0DB1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1CF STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DB1D1;
L_0DB1D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D1u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D1u, 3u, 3u, cpu.address("abs", 0xB1E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1D1 JMP -> $0DB1E3
    goto L_0DB1E3;
L_0DB1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E3u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1E3 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xB1E5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1E6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DB1E3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1E6;
L_0DB1E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1E6u,0x0DB1E6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E6u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1E6 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB1E8;
L_0DB1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E8u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1E8 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xB1EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1EBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DB1E8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1EB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E8u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1E8 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xB1EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1EBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DB1E8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1EB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1E8u,0x0DB1E8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DB1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1EB LDA
    cpu.setA(0x0u, 8);
    goto L_0DB1ED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1EB LDA
    cpu.setA(0x0u, 8);
    goto L_0DB1ED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1EBu,0x0DB1EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DB1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1ED JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB1EFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1F0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB1EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1F0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1ED JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB1EFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1F0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB1EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1EDu,0x0DB1EDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DB1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F0 DEX
    cpu.decReg('X');
    goto L_0DB1F1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F0 DEX
    cpu.decReg('X');
    goto L_0DB1F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1F0u,0x0DB1F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DB1F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F1u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F1 CPX
    cpu.compareX(0xFFu);
    goto L_0DB1F3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F1u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F1 CPX
    cpu.compareX(0xFFu);
    goto L_0DB1F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1F1u,0x0DB1F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DB1F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F3 BNE -> $0DB1E8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB1E8; }
    goto L_0DB1F5;
L_0DB1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F5u, 3u, 3u, cpu.address("abs", 0xB205u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F5 JMP -> $0DB205
    goto L_0DB205;
L_0DB1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F8u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1F8 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB1FAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1FBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB1F8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1FB;
L_0DB1FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1FBu,0x0DB1FBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1FB LDA
    cpu.setA(0x3Fu, 8);
    goto L_0DB1FD;
L_0DB1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1FD JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB1FFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB200u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB1FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB200;
L_0DB200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB200u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB200u,0x0DB200u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB200u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB200u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB200 DEX
    cpu.decReg('X');
    goto L_0DB201;
L_0DB201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB201u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB201u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB201 CPX
    cpu.compareX(0xFFu);
    goto L_0DB203;
L_0DB203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB203u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB203u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB203 BNE -> $0DB1F8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB1F8; }
    goto L_0DB205;
L_0DB205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB205u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB205u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB205 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xB207u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB208u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DB205u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB208;
L_0DB208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB208u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB208u,0x0DB208u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB208u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB208u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB208 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xB20Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB20Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DB208u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB20B;
L_0DB20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB20Bu,0x0DB20Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB20B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB20D;
L_0DB20D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Du,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB20D DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DB20F;
L_0DB20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB20F BPL -> $0DB1F8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB1F8; }
    goto L_0DB211;
L_0DB211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB211 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB211u);return;} hw.unresolvedReturn(0x0DB211u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB1C8_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB1C8u: goto L_0DB1C8;
    case 0x0DB1CAu: goto L_0DB1CA;
    case 0x0DB1CCu: goto L_0DB1CC;
    case 0x0DB1CDu: goto L_0DB1CD;
    case 0x0DB1CFu: goto L_0DB1CF;
    case 0x0DB1D1u: goto L_0DB1D1;
    case 0x0DB1E3u: goto L_0DB1E3;
    case 0x0DB1E6u: goto L_0DB1E6;
    case 0x0DB1E8u: goto L_0DB1E8;
    case 0x0DB1EBu: goto L_0DB1EB;
    case 0x0DB1EDu: goto L_0DB1ED;
    case 0x0DB1F0u: goto L_0DB1F0;
    case 0x0DB1F1u: goto L_0DB1F1;
    case 0x0DB1F3u: goto L_0DB1F3;
    case 0x0DB1F5u: goto L_0DB1F5;
    case 0x0DB1F8u: goto L_0DB1F8;
    case 0x0DB1FBu: goto L_0DB1FB;
    case 0x0DB1FDu: goto L_0DB1FD;
    case 0x0DB200u: goto L_0DB200;
    case 0x0DB201u: goto L_0DB201;
    case 0x0DB203u: goto L_0DB203;
    case 0x0DB205u: goto L_0DB205;
    case 0x0DB208u: goto L_0DB208;
    case 0x0DB20Bu: goto L_0DB20B;
    case 0x0DB20Du: goto L_0DB20D;
    case 0x0DB20Fu: goto L_0DB20F;
    case 0x0DB211u: goto L_0DB211;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1C8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB1CA;
L_0DB1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1CA STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB1CC;
L_0DB1CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1CC TAX
    cpu.transfer("TAX");
    goto L_0DB1CD;
L_0DB1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1CD LDA
    cpu.setA(0x2u, 8);
    goto L_0DB1CF;
L_0DB1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1CF STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DB1D1;
L_0DB1D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D1u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D1u, 3u, 3u, cpu.address("abs", 0xB1E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1D1 JMP -> $0DB1E3
    goto L_0DB1E3;
L_0DB1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E3u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1E3 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xB1E5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1E6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DB1E3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1E6;
L_0DB1E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1E6u,0x0DB1E6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E6u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1E6 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB1E8;
L_0DB1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E8u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1E8 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xB1EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1EBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DB1E8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1EB;
L_0DB1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1EBu,0x0DB1EBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1EB LDA
    cpu.setA(0x0u, 8);
    goto L_0DB1ED;
L_0DB1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1ED JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB1EFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1F0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB1EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1F0;
L_0DB1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1F0u,0x0DB1F0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F0 DEX
    cpu.decReg('X');
    goto L_0DB1F1;
L_0DB1F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F1u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F1 CPX
    cpu.compareX(0xFFu);
    goto L_0DB1F3;
L_0DB1F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F3 BNE -> $0DB1E8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB1E8; }
    goto L_0DB1F5;
L_0DB1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F5u, 3u, 3u, cpu.address("abs", 0xB205u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F5 JMP -> $0DB205
    goto L_0DB205;
L_0DB1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F8u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1F8 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB1FAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1FBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB1F8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1FB;
L_0DB1FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1FBu,0x0DB1FBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1FB LDA
    cpu.setA(0x3Fu, 8);
    goto L_0DB1FD;
L_0DB1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1FD JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB1FFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB200u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB1FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB200;
L_0DB200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB200u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB200u,0x0DB200u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB200u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB200u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB200 DEX
    cpu.decReg('X');
    goto L_0DB201;
L_0DB201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB201u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB201u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB201 CPX
    cpu.compareX(0xFFu);
    goto L_0DB203;
L_0DB203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB203u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB203u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB203 BNE -> $0DB1F8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB1F8; }
    goto L_0DB205;
L_0DB205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB205u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB205u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB205 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xB207u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB208u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DB205u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB208;
L_0DB208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB208u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB208u,0x0DB208u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB208u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB208u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB208 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xB20Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB20Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DB208u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB20B;
L_0DB20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB20Bu,0x0DB20Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB20B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB20D;
L_0DB20D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Du,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB20D DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DB20F;
L_0DB20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB20F BPL -> $0DB1F8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB1F8; }
    goto L_0DB211;
L_0DB211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB211 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB211u);return;} hw.unresolvedReturn(0x0DB211u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB5B7_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB5B7u: goto L_0DB5B7;
    case 0x0DB5B9u: goto L_0DB5B9;
    case 0x0DB5BBu: goto L_0DB5BB;
    case 0x0DB5BDu: goto L_0DB5BD;
    case 0x0DB5BFu: goto L_0DB5BF;
    case 0x0DB5C1u: goto L_0DB5C1;
    case 0x0DB5C2u: goto L_0DB5C2;
    case 0x0DB5C3u: goto L_0DB5C3;
    case 0x0DB5C4u: goto L_0DB5C4;
    case 0x0DB5C5u: goto L_0DB5C5;
    case 0x0DB5C6u: goto L_0DB5C6;
    case 0x0DB5C9u: goto L_0DB5C9;
    case 0x0DB5CDu: goto L_0DB5CD;
    case 0x0DB5D0u: goto L_0DB5D0;
    case 0x0DB5D3u: goto L_0DB5D3;
    case 0x0DB5D7u: goto L_0DB5D7;
    case 0x0DB5DAu: goto L_0DB5DA;
    case 0x0DB5DCu: goto L_0DB5DC;
    case 0x0DB5DEu: goto L_0DB5DE;
    case 0x0DB5E1u: goto L_0DB5E1;
    case 0x0DB5E5u: goto L_0DB5E5;
    case 0x0DB5E7u: goto L_0DB5E7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB5B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B7u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5B7 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB5B9;
L_0DB5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5B9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB5BB;
L_0DB5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5BB AND
    cpu.logicAnd(0xFu);
    goto L_0DB5BD;
L_0DB5BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5BD STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB5BF;
L_0DB5BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5BF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB5C1;
L_0DB5C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5C1 LSR
    cpu.lsrA();
    goto L_0DB5C2;
L_0DB5C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5C2 LSR
    cpu.lsrA();
    goto L_0DB5C3;
L_0DB5C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5C3 LSR
    cpu.lsrA();
    goto L_0DB5C4;
L_0DB5C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5C4 LSR
    cpu.lsrA();
    goto L_0DB5C5;
L_0DB5C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5C5 TAX
    cpu.transfer("TAX");
    goto L_0DB5C6;
L_0DB5C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C6u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB5C6 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB5C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5C9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB5C6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB5C9;
L_0DB5C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5C9u,0x0DB5C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C9u, 5u, 4u, ((0x0DB5A8u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5C9 LDA
    cpu.loadA(hw.readW(((0xDB5A8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB5CD;
L_0DB5CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu, 3u, 3u, cpu.address("abs", 0xB5D7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5CD JMP -> $0DB5D7
    goto L_0DB5D7;
L_0DB5D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D0u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB5D0 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB5D2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5D3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB5D0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB5D3;
L_0DB5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5D3u,0x0DB5D3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D3u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D3u, 5u, 4u, ((0x0DB5ADu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5D3 LDA
    cpu.loadA(hw.readW(((0xDB5ADu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB5D7;
L_0DB5D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB5D7 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB5D9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5DAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB5D7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB5DA;
L_0DB5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5DAu,0x0DB5DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DAu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5DA DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DB5DC;
L_0DB5DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5DC BNE -> $0DB5D0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB5D0; }
    goto L_0DB5DE;
L_0DB5DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DEu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB5DE JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB5E0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5E1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB5DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB5E1;
L_0DB5E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5E1u,0x0DB5E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E1u, 5u, 4u, ((0x0DB5B2u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5E1 LDA
    cpu.loadA(hw.readW(((0xDB5B2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB5E5;
L_0DB5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB5E5 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DB5E7;
L_0DB5E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB5E7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB5E7u);return;} hw.unresolvedReturn(0x0DB5E7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB5B7_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB5B7u: goto L_0DB5B7;
    case 0x0DB5B9u: goto L_0DB5B9;
    case 0x0DB5BBu: goto L_0DB5BB;
    case 0x0DB5BDu: goto L_0DB5BD;
    case 0x0DB5BFu: goto L_0DB5BF;
    case 0x0DB5C1u: goto L_0DB5C1;
    case 0x0DB5C2u: goto L_0DB5C2;
    case 0x0DB5C3u: goto L_0DB5C3;
    case 0x0DB5C4u: goto L_0DB5C4;
    case 0x0DB5C5u: goto L_0DB5C5;
    case 0x0DB5C6u: goto L_0DB5C6;
    case 0x0DB5C9u: goto L_0DB5C9;
    case 0x0DB5CDu: goto L_0DB5CD;
    case 0x0DB5D0u: goto L_0DB5D0;
    case 0x0DB5D3u: goto L_0DB5D3;
    case 0x0DB5D7u: goto L_0DB5D7;
    case 0x0DB5DAu: goto L_0DB5DA;
    case 0x0DB5DCu: goto L_0DB5DC;
    case 0x0DB5DEu: goto L_0DB5DE;
    case 0x0DB5E1u: goto L_0DB5E1;
    case 0x0DB5E5u: goto L_0DB5E5;
    case 0x0DB5E7u: goto L_0DB5E7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB5B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B7u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5B7 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB5B9;
L_0DB5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5B9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB5BB;
L_0DB5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5BB AND
    cpu.logicAnd(0xFu);
    goto L_0DB5BD;
L_0DB5BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5BD STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB5BF;
L_0DB5BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5BF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB5C1;
L_0DB5C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5C1 LSR
    cpu.lsrA();
    goto L_0DB5C2;
L_0DB5C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5C2 LSR
    cpu.lsrA();
    goto L_0DB5C3;
L_0DB5C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5C3 LSR
    cpu.lsrA();
    goto L_0DB5C4;
L_0DB5C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5C4 LSR
    cpu.lsrA();
    goto L_0DB5C5;
L_0DB5C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5C5 TAX
    cpu.transfer("TAX");
    goto L_0DB5C6;
L_0DB5C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C6u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB5C6 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB5C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5C9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB5C6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB5C9;
L_0DB5C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5C9u,0x0DB5C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C9u, 5u, 4u, ((0x0DB5A8u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5C9 LDA
    cpu.loadA(hw.readW(((0xDB5A8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB5CD;
L_0DB5CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu, 3u, 3u, cpu.address("abs", 0xB5D7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5CD JMP -> $0DB5D7
    goto L_0DB5D7;
L_0DB5D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D0u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB5D0 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB5D2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5D3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB5D0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB5D3;
L_0DB5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5D3u,0x0DB5D3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D3u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D3u, 5u, 4u, ((0x0DB5ADu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5D3 LDA
    cpu.loadA(hw.readW(((0xDB5ADu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB5D7;
L_0DB5D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB5D7 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB5D9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5DAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB5D7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB5DA;
L_0DB5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5DAu,0x0DB5DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DAu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5DA DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DB5DC;
L_0DB5DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5DC BNE -> $0DB5D0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB5D0; }
    goto L_0DB5DE;
L_0DB5DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DEu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB5DE JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB5E0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5E1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB5DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB5E1;
L_0DB5E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5E1u,0x0DB5E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E1u, 5u, 4u, ((0x0DB5B2u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5E1 LDA
    cpu.loadA(hw.readW(((0xDB5B2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB5E5;
L_0DB5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB5E5 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DB5E7;
L_0DB5E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB5E7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB5E7u);return;} hw.unresolvedReturn(0x0DB5E7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DD24E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DD24Eu: goto L_0DD24E;
    case 0x0DD250u: goto L_0DD250;
    case 0x0DD252u: goto L_0DD252;
    case 0x0DD254u: goto L_0DD254;
    case 0x0DD256u: goto L_0DD256;
    case 0x0DD258u: goto L_0DD258;
    case 0x0DD25Bu: goto L_0DD25B;
    case 0x0DD25Du: goto L_0DD25D;
    case 0x0DD260u: goto L_0DD260;
    case 0x0DD262u: goto L_0DD262;
    case 0x0DD264u: goto L_0DD264;
    case 0x0DD267u: goto L_0DD267;
    case 0x0DD26Bu: goto L_0DD26B;
    case 0x0DD26Eu: goto L_0DD26E;
    case 0x0DD270u: goto L_0DD270;
    case 0x0DD272u: goto L_0DD272;
    case 0x0DD275u: goto L_0DD275;
    case 0x0DD278u: goto L_0DD278;
    case 0x0DD27Au: goto L_0DD27A;
    case 0x0DD27Cu: goto L_0DD27C;
    case 0x0DD27Du: goto L_0DD27D;
    case 0x0DD27Fu: goto L_0DD27F;
    case 0x0DD281u: goto L_0DD281;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DD24E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD24Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD24Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD24Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD24E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DD250;
L_0DD250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD250u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD250u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD250 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DD252;
L_0DD252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD252u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD252u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD252 AND
    cpu.logicAnd(0xFu);
    goto L_0DD254;
L_0DD254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD254u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD254u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD254 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DD256;
L_0DD256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD256u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD256u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD256 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DD258;
L_0DD258:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD258u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD258u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD258u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD258 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xD25Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD25Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DD258u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD25B;
L_0DD25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD25Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD25Bu,0x0DD25Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD25B LDX
    cpu.setX(0x0u, 8);
    goto L_0DD25D;
L_0DD25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Du, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD25D JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xD25Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD260u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DD25Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD260;
L_0DD260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD260u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD260u,0x0DD260u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD260u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD260u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD260 CPX
    cpu.compareX(0x0u);
    goto L_0DD262;
L_0DD262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD262u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD262u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD262 BEQ -> $0DD267
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DD267; }
    goto L_0DD264;
L_0DD264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD264u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD264u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD264 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xD266u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD267u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DD264u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD267;
L_0DD267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD267u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD267u,0x0DD267u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD267u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD267u, 5u, 4u, ((0x0DD24Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD267 LDA
    cpu.loadA(hw.readW(((0xDD24Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DD26B;
L_0DD26B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD26Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD26Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD26Bu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD26B JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xD26Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD26Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DD26Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD26E;
L_0DD26E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD26Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD26Eu,0x0DD26Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD26Eu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD26Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD26E DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DD270;
L_0DD270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD270u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD270u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD270 BPL -> $0DD25D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DD25D; }
    goto L_0DD272;
L_0DD272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD272u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD272u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD272 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xD274u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD275u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DD272u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD275;
L_0DD275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD275u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD275u,0x0DD275u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD275u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD275u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD275 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xD277u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD278u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DD275u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD278;
L_0DD278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD278u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD278u,0x0DD278u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD278u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD278u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD278 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DD27A;
L_0DD27A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD27Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD27A STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DD27C;
L_0DD27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD27C INX
    cpu.inc('X');
    goto L_0DD27D;
L_0DD27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD27Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Du,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD27D CPX
    cpu.compareX(0x2u);
    goto L_0DD27F;
L_0DD27F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD27Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD27F BNE -> $0DD25D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DD25D; }
    goto L_0DD281;
L_0DD281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD281u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD281u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD281 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DD281u);return;} hw.unresolvedReturn(0x0DD281u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A95D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A95Du: goto L_B1A95D;
    case 0xB1A960u: goto L_B1A960;
    case 0xB1A962u: goto L_B1A962;
    case 0xB1A965u: goto L_B1A965;
    case 0xB1A967u: goto L_B1A967;
    case 0xB1A969u: goto L_B1A969;
    case 0xB1A96Bu: goto L_B1A96B;
    case 0xB1A96Du: goto L_B1A96D;
    case 0xB1A96Eu: goto L_B1A96E;
    case 0xB1A96Fu: goto L_B1A96F;
    case 0xB1A973u: goto L_B1A973;
    case 0xB1A974u: goto L_B1A974;
    case 0xB1A975u: goto L_B1A975;
    case 0xB1A977u: goto L_B1A977;
    case 0xB1A979u: goto L_B1A979;
    case 0xB1A97Bu: goto L_B1A97B;
    case 0xB1A97Du: goto L_B1A97D;
    case 0xB1A97Fu: goto L_B1A97F;
    case 0xB1A981u: goto L_B1A981;
    case 0xB1A983u: goto L_B1A983;
    case 0xB1A986u: goto L_B1A986;
    case 0xB1A988u: goto L_B1A988;
    case 0xB1A98Au: goto L_B1A98A;
    case 0xB1A98Cu: goto L_B1A98C;
    case 0xB1A98Eu: goto L_B1A98E;
    case 0xB1A990u: goto L_B1A990;
    case 0xB1A993u: goto L_B1A993;
    case 0xB1A996u: goto L_B1A996;
    case 0xB1A998u: goto L_B1A998;
    case 0xB1A99Bu: goto L_B1A99B;
    case 0xB1A99Du: goto L_B1A99D;
    case 0xB1A9A0u: goto L_B1A9A0;
    case 0xB1A9A2u: goto L_B1A9A2;
    case 0xB1A9A4u: goto L_B1A9A4;
    case 0xB1A9A8u: goto L_B1A9A8;
    case 0xB1A9ABu: goto L_B1A9AB;
    case 0xB1A9ADu: goto L_B1A9AD;
    case 0xB1A9AFu: goto L_B1A9AF;
    case 0xB1A9B2u: goto L_B1A9B2;
    case 0xB1A9B4u: goto L_B1A9B4;
    case 0xB1A9B6u: goto L_B1A9B6;
    case 0xB1A9B8u: goto L_B1A9B8;
    case 0xB1A9BAu: goto L_B1A9BA;
    case 0xB1A9BDu: goto L_B1A9BD;
    case 0xB1A9BEu: goto L_B1A9BE;
    case 0xB1A9C0u: goto L_B1A9C0;
    case 0xB1A9C1u: goto L_B1A9C1;
    case 0xB1A9C3u: goto L_B1A9C3;
    case 0xB1A9C5u: goto L_B1A9C5;
    case 0xB1A9C7u: goto L_B1A9C7;
    case 0xB1A9CAu: goto L_B1A9CA;
    case 0xB1A9CCu: goto L_B1A9CC;
    case 0xB1A9CFu: goto L_B1A9CF;
    case 0xB1A9D1u: goto L_B1A9D1;
    case 0xB1A9D3u: goto L_B1A9D3;
    case 0xB1A9D5u: goto L_B1A9D5;
    case 0xB1A9D8u: goto L_B1A9D8;
    case 0xB1A9DAu: goto L_B1A9DA;
    case 0xB1A9DDu: goto L_B1A9DD;
    case 0xB1A9DFu: goto L_B1A9DF;
    case 0xB1A9E1u: goto L_B1A9E1;
    case 0xB1A9E2u: goto L_B1A9E2;
    case 0xB1A9E5u: goto L_B1A9E5;
    case 0xB1A9E7u: goto L_B1A9E7;
    case 0xB1A9E9u: goto L_B1A9E9;
    case 0xB1A9EBu: goto L_B1A9EB;
    case 0xB1A9EEu: goto L_B1A9EE;
    case 0xB1A9F0u: goto L_B1A9F0;
    case 0xB1A9F2u: goto L_B1A9F2;
    case 0xB1A9F4u: goto L_B1A9F4;
    case 0xB1A9F6u: goto L_B1A9F6;
    case 0xB1A9F8u: goto L_B1A9F8;
    case 0xB1A9FBu: goto L_B1A9FB;
    case 0xB1A9FDu: goto L_B1A9FD;
    case 0xB1AA00u: goto L_B1AA00;
    case 0xB1AA01u: goto L_B1AA01;
    case 0xB1AA04u: goto L_B1AA04;
    case 0xB1AA07u: goto L_B1AA07;
    case 0xB1AA09u: goto L_B1AA09;
    case 0xB1AA0Bu: goto L_B1AA0B;
    case 0xB1AA0Du: goto L_B1AA0D;
    case 0xB1AA0Fu: goto L_B1AA0F;
    case 0xB1AA12u: goto L_B1AA12;
    case 0xB1AA14u: goto L_B1AA14;
    case 0xB1AA16u: goto L_B1AA16;
    case 0xB1AA18u: goto L_B1AA18;
    case 0xB1AA1Au: goto L_B1AA1A;
    case 0xB1AA1Cu: goto L_B1AA1C;
    case 0xB1AA1Eu: goto L_B1AA1E;
    case 0xB1AA20u: goto L_B1AA20;
    case 0xB1AA22u: goto L_B1AA22;
    case 0xB1AA24u: goto L_B1AA24;
    case 0xB1AA26u: goto L_B1AA26;
    case 0xB1AA28u: goto L_B1AA28;
    case 0xB1AA2Au: goto L_B1AA2A;
    case 0xB1AA2Du: goto L_B1AA2D;
    case 0xB1AA2Fu: goto L_B1AA2F;
    case 0xB1AA32u: goto L_B1AA32;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Du, 6u, 3u, cpu.address("abs", 0xAB46u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A95D JSR -> $B1AB46 stack real
    { cpu.push16Value(hw,0xA95Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA960u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAB46u), 0xB1A95Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A960;
L_B1A960:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA960u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA960u,0xB1A960u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA960u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA960u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A960 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A962;
L_B1A962:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA962u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA962u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA962u, 4u + ((((0x1686u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A962 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1686u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A965;
L_B1A965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA965u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA965u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A965 AND
    cpu.logicAnd(0x40u);
    goto L_B1A967;
L_B1A967:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA967u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA967u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA967u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A967 BEQ -> $B1A9BE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A9BE; }
    goto L_B1A969;
L_B1A969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA969u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA969u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA969u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A969 CPY
    cpu.compareY(0x72u);
    goto L_B1A96B;
L_B1A96B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A96B BCC -> $B1A979
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A979; }
    goto L_B1A96D;
L_B1A96D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Du,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A96D PHX
    cpu.push("PHX", hw);
    goto L_B1A96E;
L_B1A96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Eu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A96E PHY
    cpu.push("PHY", hw);
    goto L_B1A96F;
L_B1A96F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Fu, 8u, 4u, 0x02EAF2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A96F JSL -> $02EAF2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA972u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA973u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02EAF2u, 0xB1A96Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A973;
L_B1A973:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA973u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA973u,0xB1A973u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA973u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA973u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A973 PLY
    cpu.pop("PLY", hw);
    goto L_B1A974;
L_B1A974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA974u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA974u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A974 PLX
    cpu.pop("PLX", hw);
    goto L_B1A975;
L_B1A975:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA975u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA975u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA975u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A975 LDA
    cpu.setA(0x2u, 8);
    goto L_B1A977;
L_B1A977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA977u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA977u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A977 BRA -> $B1A99B
    goto L_B1A99B;
L_B1A979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA979u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA979u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A979 CPY
    cpu.compareY(0x6Eu);
    goto L_B1A97B;
L_B1A97B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A97B BNE -> $B1A98A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A98A; }
    goto L_B1A97D;
L_B1A97D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A97D LDA
    cpu.setA(0x2u, 8);
    goto L_B1A97F;
L_B1A97F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A97F STA
    hw.write(cpu.address("dpx", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_B1A981;
L_B1A981:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA981u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA981u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA981u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A981 LDA
    cpu.setA(0xFFu, 8);
    goto L_B1A983;
L_B1A983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA983u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA983u, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A983 STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B1A986;
L_B1A986:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA986u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA986u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA986u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A986 LDA
    cpu.setA(0x6Fu, 8);
    goto L_B1A988;
L_B1A988:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA988u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA988u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA988u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A988 BRA -> $B1A99B
    goto L_B1A99B;
L_B1A98A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Au,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A98A CPY
    cpu.compareY(0x3Fu);
    goto L_B1A98C;
L_B1A98C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A98C BCC -> $B1A998
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A998; }
    goto L_B1A98E;
L_B1A98E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A98E LDA
    cpu.setA(0x80u, 8);
    goto L_B1A990;
L_B1A990:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA990u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA990u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA990u, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A990 STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B1A993;
L_B1A993:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA993u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA993u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA993u, 4u + ((((0xA79Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA79Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A993 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA79Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A996;
L_B1A996:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA996u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA996u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA996u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A996 BRA -> $B1A99B
    goto L_B1A99B;
L_B1A998:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA998u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA998u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA998u, 4u + ((((0xA7C9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA7C9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A998 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA7C9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A99B;
L_B1A99B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA99Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA99Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA99Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A99B STA
    hw.write(cpu.address("dpx", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_B1A99D;
L_B1A99D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA99Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA99Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA99Du, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A99D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9A0;
L_B1A9A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9A0 AND
    cpu.logicAnd(0xEu);
    goto L_B1A9A2;
L_B1A9A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9A2 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_B1A9A4;
L_B1A9A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A4u, 8u, 4u, 0x07F78Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A9A4 JSL -> $07F78B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA9A7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA9A8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F78Bu, 0xB1A9A4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A9A8;
L_B1A9A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9A8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA9A8u,0xB1A9A8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A8u, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9A8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9AB;
L_B1A9AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ABu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9AB AND
    cpu.logicAnd(0xF1u);
    goto L_B1A9AD;
L_B1A9AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ADu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9AD ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16));
    goto L_B1A9AF;
L_B1A9AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9AFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9AFu, 5u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9AF STA
    hw.write(cpu.address("absx", 0x15F6u), cpu.a, cpu.m8?8:16);
    goto L_B1A9B2;
L_B1A9B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B2u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9B2 STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_B1A9B4;
L_B1A9B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9B4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9B6;
L_B1A9B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9B6 CMP
    cpu.compareA(0x2u);
    goto L_B1A9B8;
L_B1A9B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9B8 BNE -> $B1A9BD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A9BD; }
    goto L_B1A9BA;
L_B1A9BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9BAu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9BAu, 7u, 3u, cpu.address("absx", 0x151Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9BA INC
    cpu.incMem(hw, cpu.address("absx", 0x151Cu), cpu.m8?8:16);
    goto L_B1A9BD;
L_B1A9BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9BDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9BDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A9BD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A9BDu);return;} hw.unresolvedReturn(0xB1A9BDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A9BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9BEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9BE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9C0;
L_B1A9C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9C0 SEC
    cpu.setFlag('C', true);
    goto L_B1A9C1;
L_B1A9C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C1u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9C1 SBC
    cpu.sbc(0x4u);
    goto L_B1A9C3;
L_B1A9C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9C3 CMP
    cpu.compareA(0xDu);
    goto L_B1A9C5;
L_B1A9C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9C5 BCS -> $B1A9CC
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A9CC; }
    goto L_B1A9C7;
L_B1A9C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C7u, 4u, 3u, cpu.address("abs", 0x1407u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9C7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1407u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9CA;
L_B1A9CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9CA BNE -> $B1A9D3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A9D3; }
    goto L_B1A9CC;
L_B1A9CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CCu, 4u + ((((0x1656u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1656u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9CC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1656u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9CF;
L_B1A9CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9CF AND
    cpu.logicAnd(0x20u);
    goto L_B1A9D1;
L_B1A9D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9D1 BEQ -> $B1A9E2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A9E2; }
    goto L_B1A9D3;
L_B1A9D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9D3 LDA
    cpu.setA(0x3u, 8);
    goto L_B1A9D5;
L_B1A9D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D5u, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9D5 STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A9D8;
L_B1A9D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9D8 LDA
    cpu.setA(0x20u, 8);
    goto L_B1A9DA;
L_B1A9DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DAu, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9DA STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B1A9DD;
L_B1A9DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DDu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9DD STZ
    hw.write(cpu.address("dpx", 0xB6u), 0, cpu.m8?8:16);
    goto L_B1A9DF;
L_B1A9DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DFu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9DF STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_B1A9E1;
L_B1A9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A9E1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A9E1u);return;} hw.unresolvedReturn(0xB1A9E1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A9E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E2u, 4u + ((((0x1662u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1662u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9E2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1662u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9E5;
L_B1A9E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9E5 AND
    cpu.logicAnd(0x80u);
    goto L_B1A9E7;
L_B1A9E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9E7 BEQ -> $B1AA01
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA01; }
    goto L_B1A9E9;
L_B1A9E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9E9 LDA
    cpu.setA(0x2u, 8);
    goto L_B1A9EB;
L_B1A9EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EBu, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9EB STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A9EE;
L_B1A9EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EEu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9EE STZ
    hw.write(cpu.address("dpx", 0xB6u), 0, cpu.m8?8:16);
    goto L_B1A9F0;
L_B1A9F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9F0 STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_B1A9F2;
L_B1A9F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9F2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9F4;
L_B1A9F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9F4 CMP
    cpu.compareA(0x1Eu);
    goto L_B1A9F6;
L_B1A9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9F6 BNE -> $B1AA00
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA00; }
    goto L_B1A9F8;
L_B1A9F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F8u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F8u, 4u, 3u, cpu.address("abs", 0x18E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9F8 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x18E1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A9FB;
L_B1A9FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9FB LDA
    cpu.setA(0x1Fu, 8);
    goto L_B1A9FD;
L_B1A9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu, 5u, 3u, cpu.address("absy", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9FD STA
    hw.write(cpu.address("absy", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B1AA00;
L_B1AA00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA00u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA00u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1AA00 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1AA00u);return;} hw.unresolvedReturn(0xB1AA00u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1AA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA01 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x14C8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1AA04;
L_B1AA04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u, 5u, 3u, cpu.address("absx", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA04 STZ
    hw.write(cpu.address("absx", 0x1626u), 0, cpu.m8?8:16);
    goto L_B1AA07;
L_B1AA07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA07 CPY
    cpu.compareY(0x8u);
    goto L_B1AA09;
L_B1AA09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA09u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA09 BEQ -> $B1AA14
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA14; }
    goto L_B1AA0B;
L_B1AA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA0B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1AA0D;
L_B1AA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA0D BNE -> $B1AA14
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA14; }
    goto L_B1AA0F;
L_B1AA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA0F STZ
    hw.write(cpu.address("absx", 0x1540u), 0, cpu.m8?8:16);
    goto L_B1AA12;
L_B1AA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA12 BRA -> $B1AA2D
    goto L_B1AA2D;
L_B1AA14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA14u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA14u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA14 LDA
    cpu.setA(0x2u, 8);
    goto L_B1AA16;
L_B1AA16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA16u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA16 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1AA18;
L_B1AA18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA18u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA18 CPY
    cpu.compareY(0xFu);
    goto L_B1AA1A;
L_B1AA1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA1A BEQ -> $B1AA28
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA28; }
    goto L_B1AA1C;
L_B1AA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA1C CPY
    cpu.compareY(0x11u);
    goto L_B1AA1E;
L_B1AA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA1E BEQ -> $B1AA28
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA28; }
    goto L_B1AA20;
L_B1AA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA20 CPY
    cpu.compareY(0xA2u);
    goto L_B1AA22;
L_B1AA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA22 BEQ -> $B1AA28
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA28; }
    goto L_B1AA24;
L_B1AA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA24u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA24 CPY
    cpu.compareY(0xDu);
    goto L_B1AA26;
L_B1AA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA26u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA26 BNE -> $B1AA2A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA2A; }
    goto L_B1AA28;
L_B1AA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA28u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA28 LDA
    cpu.setA(0xFFu, 8);
    goto L_B1AA2A;
L_B1AA2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Au, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA2A STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B1AA2D;
L_B1AA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA2D LDA
    cpu.setA(0x9u, 8);
    goto L_B1AA2F;
L_B1AA2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Fu, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA2F STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1AA32;
L_B1AA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA32u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA32u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1AA32 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1AA32u);return;} hw.unresolvedReturn(0xB1AA32u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_D68DD6_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xD68DD6u: goto L_D68DD6;
    case 0xD68DD7u: goto L_D68DD7;
    case 0xD68DDAu: goto L_D68DDA;
    case 0xD68DDDu: goto L_D68DDD;
    case 0xD68DE0u: goto L_D68DE0;
    case 0xD68DE3u: goto L_D68DE3;
    case 0xD68DE6u: goto L_D68DE6;
    case 0xD68DE8u: goto L_D68DE8;
    case 0xD68DEBu: goto L_D68DEB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_D68DD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $D68DD6 PHD
    cpu.push("PHD", hw);
    goto L_D68DD7;
L_D68DD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD7u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD7u, 4u, 3u, cpu.address("abs", 0x0C0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $D68DD7 STX
    hw.write(cpu.address("abs", 0xC0Fu), cpu.x, cpu.x8?8:16);
    goto L_D68DDA;
L_D68DDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDAu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDAu, 4u, 3u, cpu.address("abs", 0x0D0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $D68DDA STX
    hw.write(cpu.address("abs", 0xD0Fu), cpu.x, cpu.x8?8:16);
    goto L_D68DDD;
L_D68DDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDDu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDDu, 4u, 3u, cpu.address("abs", 0x0E0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $D68DDD STX
    hw.write(cpu.address("abs", 0xE0Fu), cpu.x, cpu.x8?8:16);
    goto L_D68DE0;
L_D68DE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE0u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE0u, 4u, 3u, cpu.address("abs", 0x0F0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $D68DE0 STX
    hw.write(cpu.address("abs", 0xF0Fu), cpu.x, cpu.x8?8:16);
    goto L_D68DE3;
L_D68DE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE3u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE3u, 4u, 3u, cpu.address("abs", 0x5807u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $D68DE3 STX
    hw.write(cpu.address("abs", 0x5807u), cpu.x, cpu.x8?8:16);
    goto L_D68DE6;
L_D68DE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xAAu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $D68DE6 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0xAAu), cpu.m8?8:16));
    goto L_D68DE8;
L_D68DE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE8u,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE8u, 4u + ((((0x0FF3u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0FF3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $D68DE8 BIT
    cpu.bit(hw.readW(cpu.address("absx", 0xFF3u), cpu.m8?8:16), false);
    goto L_D68DEB;
L_D68DEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEBu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEBu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $D68DEB BRK
    hw.partial(0xD68DEBu, "BRK"); return;
}

