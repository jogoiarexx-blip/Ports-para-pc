#include "generated.hpp"
void sub_00816A_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0082EEu: goto L_0082EE;
    case 0x0082F1u: goto L_0082F1;
    case 0x0082F4u: goto L_0082F4;
    case 0x0082F7u: goto L_0082F7;
    case 0x0082F9u: goto L_0082F9;
    case 0x0082FCu: goto L_0082FC;
    case 0x0082FEu: goto L_0082FE;
    case 0x0082FFu: goto L_0082FF;
    case 0x008301u: goto L_008301;
    case 0x008304u: goto L_008304;
    case 0x008306u: goto L_008306;
    case 0x008308u: goto L_008308;
    case 0x00830Bu: goto L_00830B;
    case 0x00830Du: goto L_00830D;
    case 0x00830Eu: goto L_00830E;
    case 0x008310u: goto L_008310;
    case 0x008313u: goto L_008313;
    case 0x008315u: goto L_008315;
    case 0x008317u: goto L_008317;
    case 0x00831Au: goto L_00831A;
    case 0x00831Cu: goto L_00831C;
    case 0x00831Fu: goto L_00831F;
    case 0x008321u: goto L_008321;
    case 0x008324u: goto L_008324;
    case 0x008326u: goto L_008326;
    case 0x008329u: goto L_008329;
    case 0x00832Bu: goto L_00832B;
    case 0x00832Eu: goto L_00832E;
    case 0x008330u: goto L_008330;
    case 0x008333u: goto L_008333;
    case 0x008335u: goto L_008335;
    case 0x008338u: goto L_008338;
    case 0x00833Au: goto L_00833A;
    case 0x00833Du: goto L_00833D;
    case 0x00833Fu: goto L_00833F;
    case 0x008342u: goto L_008342;
    case 0x008345u: goto L_008345;
    case 0x008348u: goto L_008348;
    case 0x008349u: goto L_008349;
    case 0x00834Bu: goto L_00834B;
    case 0x00834Eu: goto L_00834E;
    case 0x008351u: goto L_008351;
    case 0x008354u: goto L_008354;
    case 0x008357u: goto L_008357;
    case 0x008359u: goto L_008359;
    case 0x00835Cu: goto L_00835C;
    case 0x00835Eu: goto L_00835E;
    case 0x008361u: goto L_008361;
    case 0x008363u: goto L_008363;
    case 0x008366u: goto L_008366;
    case 0x008367u: goto L_008367;
    case 0x008368u: goto L_008368;
    case 0x00836Bu: goto L_00836B;
    case 0x00836Du: goto L_00836D;
    case 0x00836Fu: goto L_00836F;
    case 0x008371u: goto L_008371;
    case 0x00838Cu: goto L_00838C;
    case 0x00838Fu: goto L_00838F;
    case 0x008391u: goto L_008391;
    case 0x008394u: goto L_008394;
    case 0x008396u: goto L_008396;
    case 0x008399u: goto L_008399;
    case 0x00839Bu: goto L_00839B;
    case 0x00839Eu: goto L_00839E;
    case 0x0083A0u: goto L_0083A0;
    case 0x0083A3u: goto L_0083A3;
    case 0x0083A5u: goto L_0083A5;
    case 0x0083A8u: goto L_0083A8;
    case 0x0083AAu: goto L_0083AA;
    case 0x0083ADu: goto L_0083AD;
    case 0x0083AFu: goto L_0083AF;
    case 0x0083B2u: goto L_0083B2;
    case 0x0083B4u: goto L_0083B4;
    case 0x0083B5u: goto L_0083B5;
    case 0x0083B6u: goto L_0083B6;
    case 0x0083B7u: goto L_0083B7;
    case 0x0083B8u: goto L_0083B8;
    case 0x0083B9u: goto L_0083B9;
    case 0x0083F3u: goto L_0083F3;
    case 0x0083F6u: goto L_0083F6;
    case 0x0083F9u: goto L_0083F9;
    case 0x0083FAu: goto L_0083FA;
    case 0x0083FBu: goto L_0083FB;
    case 0x0083FDu: goto L_0083FD;
    case 0x008400u: goto L_008400;
    case 0x008402u: goto L_008402;
    case 0x008405u: goto L_008405;
    case 0x008407u: goto L_008407;
    case 0x00840Au: goto L_00840A;
    case 0x00840Cu: goto L_00840C;
    case 0x00840Fu: goto L_00840F;
    case 0x008411u: goto L_008411;
    case 0x008414u: goto L_008414;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0082EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82EEu,0x0082EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EEu, 6u, 3u, cpu.address("abs", 0x85D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082EE JSR -> $0085D2 stack real
    { cpu.push16Value(hw,0x82F0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82F1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D2u), 0x0082EEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082F1;
L_0082F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82F1u,0x0082F1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F1u, 6u, 3u, cpu.address("abs", 0x8449u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082F1 JSR -> $008449 stack real
    { cpu.push16Value(hw,0x82F3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82F4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8449u), 0x0082F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082F4;
L_0082F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82F4u,0x0082F4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F4u, 6u, 3u, cpu.address("abs", 0x8650u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082F4 JSR -> $008650 stack real
    { cpu.push16Value(hw,0x82F6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82F7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8650u), 0x0082F4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082F7;
L_0082F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82F7u,0x0082F7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082F7 LDA
    cpu.setA(0x9u, 8);
    goto L_0082F9;
L_0082F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F9u, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082F9 STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_0082FC;
L_0082FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082FC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0082FE;
L_0082FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082FE CLC
    cpu.setFlag('C', false);
    goto L_0082FF;
L_0082FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082FF ADC
    cpu.adc(0x80u);
    goto L_008301;
L_008301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8301u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8301u, 4u, 3u, cpu.address("abs", 0x211Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008301 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_008304;
L_008304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8304u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8304u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008304 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008306;
L_008306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8306u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8306u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008306 ADC
    cpu.adc(0x0u);
    goto L_008308;
L_008308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8308u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8308u, 4u, 3u, cpu.address("abs", 0x211Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008308 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_00830B;
L_00830B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00830B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00830D;
L_00830D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00830D CLC
    cpu.setFlag('C', false);
    goto L_00830E;
L_00830E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00830E ADC
    cpu.adc(0x80u);
    goto L_008310;
L_008310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8310u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8310u, 4u, 3u, cpu.address("abs", 0x2120u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008310 STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_008313;
L_008313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8313u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8313u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008313 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008315;
L_008315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8315u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8315u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008315 ADC
    cpu.adc(0x0u);
    goto L_008317;
L_008317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8317u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8317u, 4u, 3u, cpu.address("abs", 0x2120u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008317 STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_00831A;
L_00831A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00831A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00831C;
L_00831C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00831C STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_00831F;
L_00831F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00831F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008321;
L_008321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8321u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8321u, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008321 STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_008324;
L_008324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x30u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008324 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008326;
L_008326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8326u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8326u, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008326 STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_008329;
L_008329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8329u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8329u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x31u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008329 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x31u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00832B;
L_00832B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Bu, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00832B STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_00832E;
L_00832E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00832E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x32u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008330;
L_008330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8330u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8330u, 4u, 3u, cpu.address("abs", 0x211Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008330 STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_008333;
L_008333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8333u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8333u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x33u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008333 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x33u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008335;
L_008335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8335u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8335u, 4u, 3u, cpu.address("abs", 0x211Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008335 STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_008338;
L_008338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8338u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8338u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x34u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008338 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x34u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00833A;
L_00833A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Au, 4u, 3u, cpu.address("abs", 0x211Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00833A STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_00833D;
L_00833D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00833D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x35u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00833F;
L_00833F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Fu, 4u, 3u, cpu.address("abs", 0x211Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00833F STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_008342;
L_008342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8342u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8342u, 6u, 3u, cpu.address("abs", 0x8416u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008342 JSR -> $008416 stack real
    { cpu.push16Value(hw,0x8344u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8345u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8416u), 0x008342u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008345;
L_008345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8345u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8345u,0x008345u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008345 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008348;
L_008348:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8348u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8348u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8348u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008348 LSR
    cpu.lsrA();
    goto L_008349;
L_008349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8349u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8349u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008349 BCC -> $00835C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00835C; }
    goto L_00834B;
L_00834B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Bu, 4u, 3u, cpu.address("abs", 0x0DAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00834B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDAEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00834E;
L_00834E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Eu, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00834E STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_008351;
L_008351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8351u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8351u, 4u, 3u, cpu.address("abs", 0x0D9Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008351 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008354;
L_008354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8354u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8354u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008354 STA
    hw.write(cpu.address("abs", 0x420Cu), cpu.a, cpu.m8?8:16);
    goto L_008357;
L_008357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8357u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8357u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008357 LDA
    cpu.setA(0x81u, 8);
    goto L_008359;
L_008359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u, 3u, 3u, cpu.address("abs", 0x83F3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008359 JMP -> $0083F3
    goto L_0083F3;
L_00835C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00835C LDY
    cpu.setY(0x24u, 8);
    goto L_00835E;
L_00835E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Eu,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Eu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00835E BIT
    cpu.bit(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), false);
    goto L_008361;
L_008361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8361u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8361u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008361 BVC -> $008371
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_008371; }
    goto L_008363;
L_008363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8363u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8363u, 4u, 3u, cpu.address("abs", 0x13FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008363 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13FCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008366;
L_008366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8366u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8366u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008366 ASL
    cpu.aslA();
    goto L_008367;
L_008367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8367u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8367u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008367 TAX
    cpu.transfer("TAX");
    goto L_008368;
L_008368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u, 4u + ((((0xF8E8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF8E8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008368 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF8E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00836B;
L_00836B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00836B CMP
    cpu.compareA(0x2Au);
    goto L_00836D;
L_00836D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00836D BNE -> $008371
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008371; }
    goto L_00836F;
L_00836F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00836F LDY
    cpu.setY(0x2Du, 8);
    goto L_008371;
L_008371:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8371u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8371u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8371u, 3u, 3u, cpu.address("abs", 0x8294u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008371 JMP -> $008294
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8294u),0x008371u); return;
L_00838C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Cu, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00838C STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_00838F;
L_00838F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00838F LDY
    cpu.setY(0x1Fu, 8);
    goto L_008391;
L_008391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8391u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8391u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8391u, 6u, 3u, cpu.address("abs", 0x843Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008391 JSR -> $00843B stack real
    { cpu.push16Value(hw,0x8393u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8394u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x843Bu), 0x008391u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008394;
L_008394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8394u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8394u,0x008394u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8394u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8394u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008394 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008396;
L_008396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8396u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8396u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8396u, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008396 STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_008399;
L_008399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8399u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8399u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x23u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008399 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x23u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00839B;
L_00839B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Bu, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00839B STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_00839E;
L_00839E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00839E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0083A0;
L_0083A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A0u, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083A0 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_0083A3;
L_0083A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083A3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0083A5;
L_0083A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083A5 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_0083A8;
L_0083A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083A8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0083AA;
L_0083AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AAu, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083AA STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_0083AD;
L_0083AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x40u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0083AF;
L_0083AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083AF STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_0083B2;
L_0083B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083B2 REP
    cpu.rep(0x30u);
    goto L_0083B4;
L_0083B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B4u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0083B4 PLB
    cpu.pop("PLB", hw);
    goto L_0083B5;
L_0083B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0083B5 PLY
    cpu.pop("PLY", hw);
    goto L_0083B6;
L_0083B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0083B6 PLX
    cpu.pop("PLX", hw);
    goto L_0083B7;
L_0083B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0083B7 PLA
    cpu.pop("PLA", hw);
    goto L_0083B8;
L_0083B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B8u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0083B8 PLP
    cpu.pop("PLP", hw);
    goto L_0083B9;
L_0083B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83B9u,0x0083B9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0083B9 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x0083B9u);return;}
L_0083F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F3u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083F3 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0083F6;
L_0083F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F6u, 6u, 3u, cpu.address("abs", 0x8439u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0083F6 JSR -> $008439 stack real
    { cpu.push16Value(hw,0x83F8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83F9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8439u), 0x0083F6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0083F9;
L_0083F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83F9u,0x0083F9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F9u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083F9 NOP
    ;
    goto L_0083FA;
L_0083FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FAu,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083FA NOP
    ;
    goto L_0083FB;
L_0083FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083FB LDA
    cpu.setA(0x7u, 8);
    goto L_0083FD;
L_0083FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FDu, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083FD STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_008400;
L_008400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8400u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8400u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008400 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008402;
L_008402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8402u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8402u, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008402 STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_008405;
L_008405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8405u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8405u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8405u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008405 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008407;
L_008407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8407u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8407u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8407u, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008407 STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_00840A;
L_00840A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00840A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00840C;
L_00840C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Cu, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00840C STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_00840F;
L_00840F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00840F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008411;
L_008411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8411u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8411u, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008411 STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_008414;
L_008414:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8414u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8414u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8414u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008414 BRA -> $0083B2
    goto L_0083B2;
}

void sub_008DAE_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008DAEu: goto L_008DAE;
    case 0x008DB0u: goto L_008DB0;
    case 0x008DB2u: goto L_008DB2;
    case 0x008DB4u: goto L_008DB4;
    case 0x008DB6u: goto L_008DB6;
    case 0x008DB9u: goto L_008DB9;
    case 0x008DBBu: goto L_008DBB;
    case 0x008DBEu: goto L_008DBE;
    case 0x008DC1u: goto L_008DC1;
    case 0x008DC2u: goto L_008DC2;
    case 0x008DC4u: goto L_008DC4;
    case 0x008DC6u: goto L_008DC6;
    case 0x008DC9u: goto L_008DC9;
    case 0x008DCCu: goto L_008DCC;
    case 0x008DCEu: goto L_008DCE;
    case 0x008DD1u: goto L_008DD1;
    case 0x008DD3u: goto L_008DD3;
    case 0x008DD6u: goto L_008DD6;
    case 0x008DD8u: goto L_008DD8;
    case 0x008DDBu: goto L_008DDB;
    case 0x008DDEu: goto L_008DDE;
    case 0x008DDFu: goto L_008DDF;
    case 0x008DE1u: goto L_008DE1;
    case 0x008DE3u: goto L_008DE3;
    case 0x008DE6u: goto L_008DE6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008DAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAEu,cpu,0x21u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAEu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA9u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $008DAE AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirectX(hw, 0xA9u), cpu.m8?8:16));
    goto L_008DB0;
L_008DB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB0u,cpu,0x42u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DB0 WDM
    ;
    goto L_008DB2;
L_008DB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB2u,cpu,0x16u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB2u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x21u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DB2 ASL
    cpu.aslMem(hw, cpu.address("dpx", 0x21u), cpu.m8?8:16);
    goto L_008DB4;
L_008DB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DB4 LDA
    cpu.setA(0x50u, 8);
    goto L_008DB6;
L_008DB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB6u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DB6 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008DB9;
L_008DB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DB9 LDX
    cpu.setX(0x6u, 8);
    goto L_008DBB;
L_008DBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBBu, 4u + ((((0x8DE7u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8DE7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DBB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8DE7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008DBE;
L_008DBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBEu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DBE STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008DC1;
L_008DC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC1u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DC1 DEX
    cpu.decReg('X');
    goto L_008DC2;
L_008DC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DC2 BPL -> $008DBB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008DBB; }
    goto L_008DC4;
L_008DC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DC4 LDA
    cpu.setA(0x2u, 8);
    goto L_008DC6;
L_008DC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC6u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DC6 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008DC9;
L_008DC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC9u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DC9 STZ
    hw.write(cpu.address("abs", 0x2115u), 0, cpu.m8?8:16);
    goto L_008DCC;
L_008DCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DCC LDA
    cpu.setA(0x63u, 8);
    goto L_008DCE;
L_008DCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCEu, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DCE STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008DD1;
L_008DD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DD1 LDA
    cpu.setA(0x50u, 8);
    goto L_008DD3;
L_008DD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD3u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DD3 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008DD6;
L_008DD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DD6 LDX
    cpu.setX(0x6u, 8);
    goto L_008DD8;
L_008DD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD8u, 4u + ((((0x8DEEu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8DEEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DD8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8DEEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008DDB;
L_008DDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDBu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DDB STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008DDE;
L_008DDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDEu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DDE DEX
    cpu.decReg('X');
    goto L_008DDF;
L_008DDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DDF BPL -> $008DD8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008DD8; }
    goto L_008DE1;
L_008DE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DE1 LDA
    cpu.setA(0x2u, 8);
    goto L_008DE3;
L_008DE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE3u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DE3 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008DE6;
L_008DE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008DE6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008DE6u);return;} hw.unresolvedReturn(0x008DE6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00A2F3_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A2F3u: goto L_00A2F3;
    case 0x00A2F5u: goto L_00A2F5;
    case 0x00A2F7u: goto L_00A2F7;
    case 0x00A2F9u: goto L_00A2F9;
    case 0x00A2FBu: goto L_00A2FB;
    case 0x00A2FDu: goto L_00A2FD;
    case 0x00A2FFu: goto L_00A2FF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2F3 REP
    cpu.rep(0x20u);
    goto L_00A2F5;
L_00A2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2F5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A2F7;
L_00A2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2F7 STA
    hw.write(cpu.address("dp", 0xD1u), cpu.a, cpu.m8?8:16);
    goto L_00A2F9;
L_00A2F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2F9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A2FB;
L_00A2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2FB STA
    hw.write(cpu.address("dp", 0xD3u), cpu.a, cpu.m8?8:16);
    goto L_00A2FD;
L_00A2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2FD SEP
    cpu.sep(0x20u);
    goto L_00A2FF;
L_00A2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A2FF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A2FFu);return;} hw.unresolvedReturn(0x00A2FFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00A2F3_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A2F3u: goto L_00A2F3;
    case 0x00A2F5u: goto L_00A2F5;
    case 0x00A2F7u: goto L_00A2F7;
    case 0x00A2F9u: goto L_00A2F9;
    case 0x00A2FBu: goto L_00A2FB;
    case 0x00A2FDu: goto L_00A2FD;
    case 0x00A2FFu: goto L_00A2FF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2F3 REP
    cpu.rep(0x20u);
    goto L_00A2F5;
L_00A2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2F5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A2F7;
L_00A2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2F7 STA
    hw.write(cpu.address("dp", 0xD1u), cpu.a, cpu.m8?8:16);
    goto L_00A2F9;
L_00A2F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2F9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A2FB;
L_00A2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2FB STA
    hw.write(cpu.address("dp", 0xD3u), cpu.a, cpu.m8?8:16);
    goto L_00A2FD;
L_00A2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2FD SEP
    cpu.sep(0x20u);
    goto L_00A2FF;
L_00A2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A2FF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A2FFu);return;} hw.unresolvedReturn(0x00A2FFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CC68_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CD04u: goto L_00CD04;
    case 0x00CD06u: goto L_00CD06;
    case 0x00CD09u: goto L_00CD09;
    case 0x00CD0Cu: goto L_00CD0C;
    case 0x00CD0Eu: goto L_00CD0E;
    case 0x00CD11u: goto L_00CD11;
    case 0x00CD14u: goto L_00CD14;
    case 0x00CD17u: goto L_00CD17;
    case 0x00CD1Au: goto L_00CD1A;
    case 0x00CD1Cu: goto L_00CD1C;
    case 0x00CD1Fu: goto L_00CD1F;
    case 0x00CD22u: goto L_00CD22;
    case 0x00CD24u: goto L_00CD24;
    case 0x00CD26u: goto L_00CD26;
    case 0x00CD28u: goto L_00CD28;
    case 0x00CD2Au: goto L_00CD2A;
    case 0x00CD2Cu: goto L_00CD2C;
    case 0x00CD2Eu: goto L_00CD2E;
    case 0x00CD30u: goto L_00CD30;
    case 0x00CD33u: goto L_00CD33;
    case 0x00CD36u: goto L_00CD36;
    case 0x00CD39u: goto L_00CD39;
    case 0x00CD3Cu: goto L_00CD3C;
    case 0x00CD3Fu: goto L_00CD3F;
    case 0x00CD41u: goto L_00CD41;
    case 0x00CD44u: goto L_00CD44;
    case 0x00CD46u: goto L_00CD46;
    case 0x00CD48u: goto L_00CD48;
    case 0x00CD49u: goto L_00CD49;
    case 0x00CD4Au: goto L_00CD4A;
    case 0x00CD4Cu: goto L_00CD4C;
    case 0x00CD4Eu: goto L_00CD4E;
    case 0x00CD51u: goto L_00CD51;
    case 0x00CD54u: goto L_00CD54;
    case 0x00CD56u: goto L_00CD56;
    case 0x00CD58u: goto L_00CD58;
    case 0x00CD5Au: goto L_00CD5A;
    case 0x00CD5Bu: goto L_00CD5B;
    case 0x00CD5Cu: goto L_00CD5C;
    case 0x00CD5Eu: goto L_00CD5E;
    case 0x00CD60u: goto L_00CD60;
    case 0x00CD62u: goto L_00CD62;
    case 0x00CD63u: goto L_00CD63;
    case 0x00CD64u: goto L_00CD64;
    case 0x00CD65u: goto L_00CD65;
    case 0x00CD66u: goto L_00CD66;
    case 0x00CD67u: goto L_00CD67;
    case 0x00CD68u: goto L_00CD68;
    case 0x00CD6Au: goto L_00CD6A;
    case 0x00CD6Bu: goto L_00CD6B;
    case 0x00CD6Cu: goto L_00CD6C;
    case 0x00CD6Du: goto L_00CD6D;
    case 0x00CD6Eu: goto L_00CD6E;
    case 0x00CD70u: goto L_00CD70;
    case 0x00CD71u: goto L_00CD71;
    case 0x00CD72u: goto L_00CD72;
    case 0x00CD73u: goto L_00CD73;
    case 0x00CD74u: goto L_00CD74;
    case 0x00CD76u: goto L_00CD76;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CD04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD04u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD04u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD04 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD06;
L_00CD06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD06u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD06u, 5u, 3u, cpu.address("abs", 0x1436u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD06 STA
    hw.write(cpu.address("abs", 0x1436u), cpu.a, cpu.m8?8:16);
    goto L_00CD09;
L_00CD09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD09u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD09u, 5u, 3u, cpu.address("abs", 0x14B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD09 STA
    hw.write(cpu.address("abs", 0x14B4u), cpu.a, cpu.m8?8:16);
    goto L_00CD0C;
L_00CD0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD0C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD0E;
L_00CD0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD0E AND
    cpu.logicAnd(0xFFF0u);
    goto L_00CD11;
L_00CD11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD11u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD11u, 5u, 3u, cpu.address("abs", 0x1438u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD11 STA
    hw.write(cpu.address("abs", 0x1438u), cpu.a, cpu.m8?8:16);
    goto L_00CD14;
L_00CD14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD14u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD14u, 5u, 3u, cpu.address("abs", 0x14B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD14 STA
    hw.write(cpu.address("abs", 0x14B6u), cpu.a, cpu.m8?8:16);
    goto L_00CD17;
L_00CD17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD17u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD17u, 6u, 3u, cpu.address("abs", 0xF9C9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CD17 JSR -> $00F9C9 stack real
    { cpu.push16Value(hw,0xCD19u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD1Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF9C9u), 0x00CD17u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CD1A;
L_00CD1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD1Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD1Au,0x00CD1Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD1A BRA -> $00CD1F
    goto L_00CD1F;
L_00CD1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Cu, 6u, 3u, cpu.address("abs", 0xDC2Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CD1C JSR -> $00DC2D stack real
    { cpu.push16Value(hw,0xCD1Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD1Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDC2Du), 0x00CD1Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CD1F;
L_00CD1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD1Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Fu, 6u, 3u, cpu.address("abs", 0xF8F2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CD1F JSR -> $00F8F2 stack real
    { cpu.push16Value(hw,0xCD21u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD22u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF8F2u), 0x00CD1Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CD22;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Fu, 6u, 3u, cpu.address("abs", 0xF8F2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CD1F JSR -> $00F8F2 stack real
    { cpu.push16Value(hw,0xCD21u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD22u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF8F2u), 0x00CD1Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CD22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD1Fu,0x00CD1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD22u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD22u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD22u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD22 BRA -> $00CD36
    goto L_00CD36;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD22u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD22u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD22 BRA -> $00CD36
    goto L_00CD36;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD22u,0x00CD22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD24u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD24u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD24 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD26;
L_00CD26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD26u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD26 BPL -> $00CD30
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00CD30; }
    goto L_00CD28;
L_00CD28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD28u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD28u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD28 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD2A;
L_00CD2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD2A AND
    cpu.logicAnd(0x8u);
    goto L_00CD2C;
L_00CD2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD2C BEQ -> $00CD30
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD30; }
    goto L_00CD2E;
L_00CD2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD2E STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00CD30;
L_00CD30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD30u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD30u, 6u, 3u, cpu.address("abs", 0xDC2Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CD30 JSR -> $00DC2D stack real
    { cpu.push16Value(hw,0xCD32u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD33u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDC2Du), 0x00CD30u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CD33;
L_00CD33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD33u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD33u,0x00CD33u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD33u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD33u, 6u, 3u, cpu.address("abs", 0xE92Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CD33 JSR -> $00E92B stack real
    { cpu.push16Value(hw,0xCD35u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD36u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE92Bu), 0x00CD33u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CD36;
L_00CD36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD36u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD36u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD36u, 6u, 3u, cpu.address("abs", 0xF595u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CD36 JSR -> $00F595 stack real
    { cpu.push16Value(hw,0xCD38u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD39u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF595u), 0x00CD36u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CD39;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD36u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD36u, 6u, 3u, cpu.address("abs", 0xF595u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CD36 JSR -> $00F595 stack real
    { cpu.push16Value(hw,0xCD38u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD39u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF595u), 0x00CD36u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CD39;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD36u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD36u, 6u, 3u, cpu.address("abs", 0xF595u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CD36 JSR -> $00F595 stack real
    { cpu.push16Value(hw,0xCD38u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD39u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF595u), 0x00CD36u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CD39;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD36u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD36u, 6u, 3u, cpu.address("abs", 0xF595u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CD36 JSR -> $00F595 stack real
    { cpu.push16Value(hw,0xCD38u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD39u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF595u), 0x00CD36u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CD39;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD36u,0x00CD36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD39u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD39u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD39u, 5u, 3u, cpu.address("abs", 0x13DDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD39 STZ
    hw.write(cpu.address("abs", 0x13DDu), 0, cpu.m8?8:16);
    goto L_00CD3C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD39u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD39u, 4u, 3u, cpu.address("abs", 0x13DDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD39 STZ
    hw.write(cpu.address("abs", 0x13DDu), 0, cpu.m8?8:16);
    goto L_00CD3C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD39u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD39u, 4u, 3u, cpu.address("abs", 0x13DDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD39 STZ
    hw.write(cpu.address("abs", 0x13DDu), 0, cpu.m8?8:16);
    goto L_00CD3C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD39u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD39u, 4u, 3u, cpu.address("abs", 0x13DDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD39 STZ
    hw.write(cpu.address("abs", 0x13DDu), 0, cpu.m8?8:16);
    goto L_00CD3C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD39u,0x00CD39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD3Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Cu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Cu, 4u, 3u, cpu.address("abs", 0x13F3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD3C LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13F3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CD3F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Cu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Cu, 5u, 3u, cpu.address("abs", 0x13F3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD3C LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13F3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CD3F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Cu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Cu, 4u, 3u, cpu.address("abs", 0x13F3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD3C LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13F3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CD3F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Cu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Cu, 4u, 3u, cpu.address("abs", 0x13F3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD3C LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13F3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CD3F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD3Cu,0x00CD3Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD3Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD3F BNE -> $00CD95
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD95u,0x00CD3Fu); return; }
    goto L_00CD41;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD3F BNE -> $00CD95
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD95u,0x00CD3Fu); return; }
    goto L_00CD41;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD3F BNE -> $00CD95
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD95u,0x00CD3Fu); return; }
    goto L_00CD41;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD3F BNE -> $00CD95
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD95u,0x00CD3Fu); return; }
    goto L_00CD41;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD3Fu,0x00CD3Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD41u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD41u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD41u, 5u, 3u, cpu.address("abs", 0x18BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD41 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD44;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD41u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD41u, 4u, 3u, cpu.address("abs", 0x18BEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD41 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD44;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD41u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD41u, 4u, 3u, cpu.address("abs", 0x18BEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD41 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD44;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD41u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD41u, 4u, 3u, cpu.address("abs", 0x18BEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD41 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD44;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD41u,0x00CD41u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD44u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD44u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD44 BEQ -> $00CD4A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD4A; }
    goto L_00CD46;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD44u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD44 BEQ -> $00CD4A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD4A; }
    goto L_00CD46;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD44u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD44 BEQ -> $00CD4A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD4A; }
    goto L_00CD46;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD44u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD44 BEQ -> $00CD4A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD4A; }
    goto L_00CD46;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD44u,0x00CD44u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD46u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD46u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD46u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD46 LDA
    cpu.setA(0x851Fu, 16);
    goto L_00CD49;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD46u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD46u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD46 LDA
    cpu.setA(0x1Fu, 8);
    goto L_00CD48;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD46u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD46u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD46 LDA
    cpu.setA(0x1Fu, 8);
    goto L_00CD48;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD46u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD46u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD46 LDA
    cpu.setA(0x1Fu, 8);
    goto L_00CD48;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD46u,0x00CD46u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD48u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD48u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD48u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD48 STA
    hw.write(cpu.address("dp", 0x8Bu), cpu.a, cpu.m8?8:16);
    goto L_00CD4A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD48u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD48u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD48 STA
    hw.write(cpu.address("dp", 0x8Bu), cpu.a, cpu.m8?8:16);
    goto L_00CD4A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD48u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD48u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD48 STA
    hw.write(cpu.address("dp", 0x8Bu), cpu.a, cpu.m8?8:16);
    goto L_00CD4A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD48u,0x00CD48u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD49u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD49u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00CD49 PHB
    cpu.push("PHB", hw);
    goto L_00CD4A;
L_00CD4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD4Au))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD4A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD4C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD4A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD4C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD4A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD4C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD4A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD4C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD4Au,0x00CD4Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD4Cu))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD4C BNE -> $00CD72
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD72; }
    goto L_00CD4E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD4C BNE -> $00CD72
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD72; }
    goto L_00CD4E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD4C BNE -> $00CD72
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD72; }
    goto L_00CD4E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD4C BNE -> $00CD72
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD72; }
    goto L_00CD4E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD4Cu,0x00CD4Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD4Eu))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Eu, 5u, 3u, cpu.address("abs", 0x148Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD4E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD51;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Eu, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD4E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD51;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Eu, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD4E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD51;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Eu, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD4E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD4Eu,0x00CD4Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD51u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD51u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD51u, 5u, 3u, cpu.address("abs", 0x187Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD51 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16));
    goto L_00CD54;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD51u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD51u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD51 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16));
    goto L_00CD54;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD51u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD51u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD51 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16));
    goto L_00CD54;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD51u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD51u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD51 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16));
    goto L_00CD54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD51u,0x00CD51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD54u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD54u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD54 BNE -> $00CD79
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD79u,0x00CD54u); return; }
    goto L_00CD56;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD54u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD54 BNE -> $00CD79
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD79u,0x00CD54u); return; }
    goto L_00CD56;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD54u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD54 BNE -> $00CD79
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD79u,0x00CD54u); return; }
    goto L_00CD56;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD54u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD54 BNE -> $00CD79
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD79u,0x00CD54u); return; }
    goto L_00CD56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD54u,0x00CD54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD56u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD56u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD56 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD58;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD56u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD56u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD56 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD58;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD56u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD56u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD56 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD58;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD56u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD56u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD56 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD58;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD56u,0x00CD56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD58u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD58u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD58u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD58 AND
    cpu.logicAnd(0xC91Bu);
    goto L_00CD5B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD58u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD58 AND
    cpu.logicAnd(0x1Bu);
    goto L_00CD5A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD58u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD58 AND
    cpu.logicAnd(0x1Bu);
    goto L_00CD5A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD58u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD58 AND
    cpu.logicAnd(0x1Bu);
    goto L_00CD5A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD58u,0x00CD58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD5Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD5A CMP
    cpu.compareA(0x1Bu);
    goto L_00CD5C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD5A CMP
    cpu.compareA(0x1Bu);
    goto L_00CD5C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD5A CMP
    cpu.compareA(0x1Bu);
    goto L_00CD5C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD5Au,0x00CD5Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD5Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Bu,cpu,0x1Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD5B TCS
    cpu.tcs();
    goto L_00CD5C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD5Bu,0x00CD5Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD5Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD5C BNE -> $00CD79
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD79u,0x00CD5Cu); return; }
    goto L_00CD5E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD5C BNE -> $00CD79
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD79u,0x00CD5Cu); return; }
    goto L_00CD5E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD5C BNE -> $00CD79
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD79u,0x00CD5Cu); return; }
    goto L_00CD5E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD5C BNE -> $00CD79
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD79u,0x00CD5Cu); return; }
    goto L_00CD5E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD5Cu,0x00CD5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD5Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD5E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD60;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD5E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD60;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD5E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD60;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD5E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD5Eu,0x00CD5Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD60u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD60u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD60u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD60 AND
    cpu.logicAnd(0xF00Cu);
    goto L_00CD63;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD60u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD60 AND
    cpu.logicAnd(0xCu);
    goto L_00CD62;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD60u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD60 AND
    cpu.logicAnd(0xCu);
    goto L_00CD62;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD60u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD60 AND
    cpu.logicAnd(0xCu);
    goto L_00CD62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD60u,0x00CD60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD62u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD62u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD62 BEQ -> $00CD79
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD79u,0x00CD62u); return; }
    goto L_00CD64;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD62u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD62 BEQ -> $00CD79
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD79u,0x00CD62u); return; }
    goto L_00CD64;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD62u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD62 BEQ -> $00CD79
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD79u,0x00CD62u); return; }
    goto L_00CD64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD62u,0x00CD62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD63u,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD63u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD63 ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0xA4u), cpu.m8?8:16));
    goto L_00CD65;
L_00CD64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD64u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD64u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD64u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD64 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x72u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CD66;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD64u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD64u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD64 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x72u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CD66;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD64u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD64u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD64 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x72u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CD66;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD64u,0x00CD64u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD65u,cpu,0x72u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD65u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xD0u) & 0xFFFFu), 2u, 0u);
    // $00CD65 ADC
    cpu.adc(hw.readW(cpu.addressDpIndirect(hw, 0xD0u), cpu.m8?8:16));
    goto L_00CD67;
L_00CD66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD66u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD66u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD66 BNE -> $00CD72
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD72; }
    goto L_00CD68;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD66u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD66 BNE -> $00CD72
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD72; }
    goto L_00CD68;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD66u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD66 BNE -> $00CD72
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD72; }
    goto L_00CD68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD66u,0x00CD66u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD67u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD67 ASL
    cpu.aslA();
    goto L_00CD68;
L_00CD68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD68u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD68u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD68u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD68 AND
    cpu.logicAnd(0xD008u);
    goto L_00CD6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD68u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD68 AND
    cpu.logicAnd(0x8u);
    goto L_00CD6A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD68u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD68 AND
    cpu.logicAnd(0x8u);
    goto L_00CD6A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD68u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD68 AND
    cpu.logicAnd(0x8u);
    goto L_00CD6A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD68u,0x00CD68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD6A BNE -> $00CD72
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD72; }
    goto L_00CD6C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD6A BNE -> $00CD72
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD72; }
    goto L_00CD6C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD6A BNE -> $00CD72
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CD72; }
    goto L_00CD6C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD6Au,0x00CD6Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Bu,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA5u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD6B ASL
    cpu.aslMem(hw, cpu.address("dp", 0xA5u), cpu.m8?8:16);
    goto L_00CD6D;
L_00CD6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD6C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD6E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD6C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD6E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD6C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD6E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD6Cu,0x00CD6Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Du,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00CD6D PHB
    cpu.push("PHB", hw);
    goto L_00CD6E;
L_00CD6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD6E AND
    cpu.logicAnd(0xF004u);
    goto L_00CD71;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD6E AND
    cpu.logicAnd(0x4u);
    goto L_00CD70;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD6E AND
    cpu.logicAnd(0x4u);
    goto L_00CD70;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD6E AND
    cpu.logicAnd(0x4u);
    goto L_00CD70;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD6Eu,0x00CD6Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD70u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD70u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD70 BEQ -> $00CD79
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD79u,0x00CD70u); return; }
    goto L_00CD72;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD70u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD70 BEQ -> $00CD79
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD79u,0x00CD70u); return; }
    goto L_00CD72;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD70u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD70 BEQ -> $00CD79
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00CD79u,0x00CD70u); return; }
    goto L_00CD72;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD70u,0x00CD70u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD71u,cpu,0x07u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD71u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA5u) & 0xFFFFu), 3u, 0u);
    // $00CD71 ORA
    cpu.logicOr(hw.readW(cpu.addressDpLong(hw, 0xA5u), cpu.m8?8:16));
    goto L_00CD73;
L_00CD72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD72u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD72u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD72u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD72 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD74;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD72u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD72u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD72 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD74;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD72u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD72u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD72 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD74;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD72u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD72u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD72 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CD74;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD72u,0x00CD72u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD73u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD73u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00CD73 PHB
    cpu.push("PHB", hw);
    goto L_00CD74;
L_00CD74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD74u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD74u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD74u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD74 STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_00CD76;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD74u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD74u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD74 STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_00CD76;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD74u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD74u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD74 STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_00CD76;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD74u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD74u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD74 STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_00CD76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD74u,0x00CD74u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CD76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD76u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD76u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD76u, 3u, 3u, cpu.address("abs", 0xDB17u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD76 JMP -> $00DB17
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xDB17u),0x00CD76u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD76u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD76u, 3u, 3u, cpu.address("abs", 0xDB17u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD76 JMP -> $00DB17
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xDB17u),0x00CD76u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD76u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD76u, 3u, 3u, cpu.address("abs", 0xDB17u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD76 JMP -> $00DB17
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xDB17u),0x00CD76u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD76u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD76u, 3u, 3u, cpu.address("abs", 0xDB17u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CD76 JMP -> $00DB17
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xDB17u),0x00CD76u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD76u,0x00CD76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00CC68_E0M1X1CQ_part11(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00DC4Cu: goto L_00DC4C;
    case 0x00DC4Eu: goto L_00DC4E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00DC4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Cu))return;
  // 11 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC4C STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00DC4E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC4Cu,0x00DC4Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Eu))return;
  // 11 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC4E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DC4Eu);return;} hw.unresolvedReturn(0x00DC4Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC4Eu,0x00DC4Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EB42_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EB42u: goto L_00EB42;
    case 0x00EB45u: goto L_00EB45;
    case 0x00EB47u: goto L_00EB47;
    case 0x00EB48u: goto L_00EB48;
    case 0x00EB4Bu: goto L_00EB4B;
    case 0x00EB4Du: goto L_00EB4D;
    case 0x00EB4Eu: goto L_00EB4E;
    case 0x00EB4Fu: goto L_00EB4F;
    case 0x00EB50u: goto L_00EB50;
    case 0x00EB52u: goto L_00EB52;
    case 0x00EB54u: goto L_00EB54;
    case 0x00EB55u: goto L_00EB55;
    case 0x00EB58u: goto L_00EB58;
    case 0x00EB5Au: goto L_00EB5A;
    case 0x00EB5Du: goto L_00EB5D;
    case 0x00EB5Fu: goto L_00EB5F;
    case 0x00EB61u: goto L_00EB61;
    case 0x00EB64u: goto L_00EB64;
    case 0x00EB65u: goto L_00EB65;
    case 0x00EB67u: goto L_00EB67;
    case 0x00EB69u: goto L_00EB69;
    case 0x00EB6Bu: goto L_00EB6B;
    case 0x00EB6Du: goto L_00EB6D;
    case 0x00EB6Fu: goto L_00EB6F;
    case 0x00EB71u: goto L_00EB71;
    case 0x00EB73u: goto L_00EB73;
    case 0x00EB76u: goto L_00EB76;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EB42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB42u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB42u, 4u, 3u, cpu.address("abs", 0x13E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB42 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13E3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EB45;
L_00EB45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB45u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB45 AND
    cpu.logicAnd(0x1u);
    goto L_00EB47;
L_00EB47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB47u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB47 TAY
    cpu.transfer("TAY");
    goto L_00EB48;
L_00EB48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB48u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB48u, 4u + ((((0xEABBu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEABBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB48 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEABBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EB4B;
L_00EB4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB4B STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00EB4D;
L_00EB4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB4D TYA
    cpu.transfer("TYA");
    goto L_00EB4E;
L_00EB4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB4E ASL
    cpu.aslA();
    goto L_00EB4F;
L_00EB4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB4F TAY
    cpu.transfer("TAY");
    goto L_00EB50;
L_00EB50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB50u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB50u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB50 REP
    cpu.rep(0x20u);
    goto L_00EB52;
L_00EB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB52u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB52 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EB54;
L_00EB54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB54u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB54 CLC
    cpu.setFlag('C', false);
    goto L_00EB55;
L_00EB55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB55u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB55u, 5u + ((((0xEABDu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEABDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB55 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xEABDu), cpu.m8?8:16));
    goto L_00EB58;
L_00EB58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB58u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB58 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00EB5A;
L_00EB5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB5Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB5A LDA
    cpu.setA(0x8u, 16);
    goto L_00EB5D;
L_00EB5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB5Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB5Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB5D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EB5F;
L_00EB5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB5Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB5F BEQ -> $00EB64
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EB64; }
    goto L_00EB61;
L_00EB61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB61u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB61u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB61 LDA
    cpu.setA(0x10u, 16);
    goto L_00EB64;
L_00EB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB64u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB64u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB64 CLC
    cpu.setFlag('C', false);
    goto L_00EB65;
L_00EB65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB65u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB65u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB65 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16));
    goto L_00EB67;
L_00EB67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB67u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB67u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB67 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EB69;
L_00EB69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB69u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB69u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB69 SEP
    cpu.sep(0x20u);
    goto L_00EB6B;
L_00EB6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB6B LDA
    cpu.setA(0x24u, 8);
    goto L_00EB6D;
L_00EB6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB6D STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00EB6F;
L_00EB6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB6F LDA
    cpu.setA(0xE0u, 8);
    goto L_00EB71;
L_00EB71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB71u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB71u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB71 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EB73;
L_00EB73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB73u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB73u, 4u, 3u, cpu.address("abs", 0x13E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EB73 STZ
    hw.write(cpu.address("abs", 0x13E3u), 0, cpu.m8?8:16);
    goto L_00EB76;
L_00EB76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB76u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB76u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EB76 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EB76u);return;} hw.unresolvedReturn(0x00EB76u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00F629_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F629u: goto L_00F629;
    case 0x00F62Du: goto L_00F62D;
    case 0x00F62Fu: goto L_00F62F;
    case 0x00F631u: goto L_00F631;
    case 0x00F633u: goto L_00F633;
    case 0x00F635u: goto L_00F635;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u, 8u, 4u, 0x00F606u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F629 JSL -> $00F606 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF62Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF62Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F606u, 0x00F629u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F62D;
L_00F62D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Du))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF62Du,0x00F62Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62D STZ
    hw.write(cpu.address("dp", 0x15u), 0, cpu.m8?8:16);
    goto L_00F62F;
L_00F62F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62F STZ
    hw.write(cpu.address("dp", 0x16u), 0, cpu.m8?8:16);
    goto L_00F631;
L_00F631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF631u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F631 STZ
    hw.write(cpu.address("dp", 0x17u), 0, cpu.m8?8:16);
    goto L_00F633;
L_00F633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F633 STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_00F635;
L_00F635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF635u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F635 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F635u);return;} hw.unresolvedReturn(0x00F635u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01A728_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A728u: goto L_01A728;
    case 0x01A72Au: goto L_01A72A;
    case 0x01A72Du: goto L_01A72D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA728u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA728u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A728 LDA
    cpu.setA(0x3u, 8);
    goto L_01A72A;
L_01A72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Au, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A72A STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_01A72D;
L_01A72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A72D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A72Du);return;} hw.unresolvedReturn(0x01A72Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01F0A2_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01F0A1u: goto L_01F0A1;
    case 0x01F0A2u: goto L_01F0A2;
    case 0x01F0A4u: goto L_01F0A4;
    case 0x01F0A6u: goto L_01F0A6;
    case 0x01F0A8u: goto L_01F0A8;
    case 0x01F0ACu: goto L_01F0AC;
    case 0x01F0AFu: goto L_01F0AF;
    case 0x01F0B1u: goto L_01F0B1;
    case 0x01F0B3u: goto L_01F0B3;
    case 0x01F0B6u: goto L_01F0B6;
    case 0x01F0B8u: goto L_01F0B8;
    case 0x01F0BAu: goto L_01F0BA;
    case 0x01F0BDu: goto L_01F0BD;
    case 0x01F0BFu: goto L_01F0BF;
    case 0x01F0C1u: goto L_01F0C1;
    case 0x01F0C4u: goto L_01F0C4;
    case 0x01F0C7u: goto L_01F0C7;
    case 0x01F0CBu: goto L_01F0CB;
    case 0x01F0CCu: goto L_01F0CC;
    case 0x01F0CEu: goto L_01F0CE;
    case 0x01F0D0u: goto L_01F0D0;
    case 0x01F0D2u: goto L_01F0D2;
    case 0x01F0D4u: goto L_01F0D4;
    case 0x01F0D6u: goto L_01F0D6;
    case 0x01F0D9u: goto L_01F0D9;
    case 0x01F0DAu: goto L_01F0DA;
    case 0x01F0DCu: goto L_01F0DC;
    case 0x01F0DFu: goto L_01F0DF;
    case 0x01F0E1u: goto L_01F0E1;
    case 0x01F0E4u: goto L_01F0E4;
    case 0x01F0E6u: goto L_01F0E6;
    case 0x01F0E8u: goto L_01F0E8;
    case 0x01F0EBu: goto L_01F0EB;
    case 0x01F0EEu: goto L_01F0EE;
    case 0x01F0F0u: goto L_01F0F0;
    case 0x01F0F2u: goto L_01F0F2;
    case 0x01F0F5u: goto L_01F0F5;
    case 0x01F0F7u: goto L_01F0F7;
    case 0x01F0F9u: goto L_01F0F9;
    case 0x01F0FBu: goto L_01F0FB;
    case 0x01F0FDu: goto L_01F0FD;
    case 0x01F0FFu: goto L_01F0FF;
    case 0x01F102u: goto L_01F102;
    case 0x01F105u: goto L_01F105;
    case 0x01F106u: goto L_01F106;
    case 0x01F108u: goto L_01F108;
    case 0x01F10Au: goto L_01F10A;
    case 0x01F10Cu: goto L_01F10C;
    case 0x01F10Eu: goto L_01F10E;
    case 0x01F111u: goto L_01F111;
    case 0x01F114u: goto L_01F114;
    case 0x01F116u: goto L_01F116;
    case 0x01F119u: goto L_01F119;
    case 0x01F11Cu: goto L_01F11C;
    case 0x01F11Eu: goto L_01F11E;
    case 0x01F120u: goto L_01F120;
    case 0x01F123u: goto L_01F123;
    case 0x01F125u: goto L_01F125;
    case 0x01F128u: goto L_01F128;
    case 0x01F12Au: goto L_01F12A;
    case 0x01F12Du: goto L_01F12D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01F0A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F0A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01F0A1u);return;} hw.unresolvedReturn(0x01F0A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01F0A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0A2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0A4;
L_01F0A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0A4 CMP
    cpu.compareA(0x1u);
    goto L_01F0A6;
L_01F0A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0A6 BNE -> $01F0AC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F0AC; }
    goto L_01F0A8;
L_01F0A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A8u, 8u, 4u, 0x02D0D4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01F0A8 JSL -> $02D0D4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF0ABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF0ACu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02D0D4u, 0x01F0A8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01F0AC;
L_01F0AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0ACu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF0ACu,0x01F0ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0ACu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0ACu, 4u, 3u, cpu.address("abs", 0x1410u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0AC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1410u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0AF;
L_01F0AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0AFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0AF CMP
    cpu.compareA(0x1u);
    goto L_01F0B1;
L_01F0B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0B1 BEQ -> $01F0A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F0A1; }
    goto L_01F0B3;
L_01F0B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B3u, 4u, 3u, cpu.address("abs", 0x14A3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0B3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14A3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0B6;
L_01F0B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0B6 CMP
    cpu.compareA(0x10u);
    goto L_01F0B8;
L_01F0B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0B8 BNE -> $01F0C4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F0C4; }
    goto L_01F0BA;
L_01F0BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0BAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0BAu, 4u, 3u, cpu.address("abs", 0x18AEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0BA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18AEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0BD;
L_01F0BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0BDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0BD BNE -> $01F0C4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F0C4; }
    goto L_01F0BF;
L_01F0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0BF LDA
    cpu.setA(0x6u, 8);
    goto L_01F0C1;
L_01F0C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C1u, 4u, 3u, cpu.address("abs", 0x18AEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0C1 STA
    hw.write(cpu.address("abs", 0x18AEu), cpu.a, cpu.m8?8:16);
    goto L_01F0C4;
L_01F0C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C4u, 4u + ((((0x1594u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1594u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0C4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1594u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0C7;
L_01F0C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C7u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01F0C7 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF0CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF0CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x01F0C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01F0CB;
L_01F0CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CBu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF0CBu,0x01F0CBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CBu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01F0CB PHK
    cpu.push("PHK", hw);
    goto L_01F0CC;
L_01F0CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CCu,cpu,0xF1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x14u) & 0xFFFFu), 2u, 0u);
    // $01F0CC SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectY(hw, 0x14u), cpu.m8?8:16));
    goto L_01F0CE;
L_01F0CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CEu,cpu,0xF3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CEu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x32u) & 0xFFFFu), 2u, 0u);
    // $01F0CE SBC
    cpu.sbc(hw.readW(cpu.addressStackIndirectY(hw, 0x32u), cpu.m8?8:16));
    goto L_01F0D0;
L_01F0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D0u,cpu,0xF3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D0u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x2Eu) & 0xFFFFu), 2u, 0u);
    // $01F0D0 SBC
    cpu.sbc(hw.readW(cpu.addressStackIndirectY(hw, 0x2Eu), cpu.m8?8:16));
    goto L_01F0D2;
L_01F0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D2u,cpu,0xF1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA9u) & 0xFFFFu), 2u, 0u);
    // $01F0D2 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectY(hw, 0xA9u), cpu.m8?8:16));
    goto L_01F0D4;
L_01F0D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D4u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0D4 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x8Du), cpu.m8?8:16);
    goto L_01F0D6;
L_01F0D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D6u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D6u, 4u + ((((0x221Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x221Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0D6 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x221Du), cpu.m8?8:16));
    goto L_01F0D9;
L_01F0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0D9 LSR
    cpu.lsrA();
    goto L_01F0DA;
L_01F0DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DAu,cpu,0xB3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DAu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x05u) & 0xFFFFu), 2u, 0u);
    // $01F0DA LDA
    cpu.loadA(hw.readW(cpu.addressStackIndirectY(hw, 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0DC;
L_01F0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DCu, 4u, 3u, cpu.address("abs", 0x18D6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0DC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18D6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0DF;
L_01F0DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0DF BEQ -> $01F12D
    if (cpu.z) { hw.addCpuInternalCycles(2u); goto L_01F12D; }
    goto L_01F0E1;
L_01F0E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E1u, 4u, 3u, cpu.address("abs", 0x18D6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0E1 STZ
    hw.write(cpu.address("abs", 0x18D6u), 0, cpu.m8?8:16);
    goto L_01F0E4;
L_01F0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0E4 CMP
    cpu.compareA(0x1u);
    goto L_01F0E6;
L_01F0E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0E6 BNE -> $01F0F9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F0F9; }
    goto L_01F0E8;
L_01F0E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E8u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E8u, 6u, 3u, cpu.address("abs", 0x18D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0E8 INC
    cpu.incMem(hw, cpu.address("abs", 0x18D4u), cpu.m8?8:16);
    goto L_01F0EB;
L_01F0EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0EBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0EBu, 4u, 3u, cpu.address("abs", 0x18D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0EB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0EE;
L_01F0EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0EEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0EE CMP
    cpu.compareA(0xAu);
    goto L_01F0F0;
L_01F0F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0F0 BNE -> $01F12D
    if (!cpu.z) { hw.addCpuInternalCycles(2u); goto L_01F12D; }
    goto L_01F0F2;
L_01F0F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F2u, 4u, 3u, cpu.address("abs", 0x18D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0F2 STZ
    hw.write(cpu.address("abs", 0x18D4u), 0, cpu.m8?8:16);
    goto L_01F0F5;
L_01F0F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0F5 LDA
    cpu.setA(0x74u, 8);
    goto L_01F0F7;
L_01F0F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0F7 BRA -> $01F125
    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao
    goto L_01F125;
L_01F0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0F9 CMP
    cpu.compareA(0x3u);
    goto L_01F0FB;
L_01F0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0FB BNE -> $01F116
    if (!cpu.z) { hw.addCpuInternalCycles(2u); goto L_01F116; }
    goto L_01F0FD;
L_01F0FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0FD LDA
    cpu.setA(0x29u, 8);
    goto L_01F0FF;
L_01F0FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FFu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0FF STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_01F102;
L_01F102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF102u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF102u, 4u, 3u, cpu.address("abs", 0x0F32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F102 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF32u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F105;
L_01F105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF105u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF105u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F105 CLC
    cpu.setFlag('C', false);
    goto L_01F106;
L_01F106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF106u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF106u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F106 ADC
    cpu.adc(0x2u);
    goto L_01F108;
L_01F108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF108u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF108u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F108 CMP
    cpu.compareA(0xAu);
    goto L_01F10A;
L_01F10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF10Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F10A BCC -> $01F111
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01F111; }
    goto L_01F10C;
L_01F10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF10Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F10C SBC
    cpu.sbc(0xAu);
    goto L_01F10E;
L_01F10E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF10Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Eu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Eu, 6u, 3u, cpu.address("abs", 0x0F31u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F10E INC
    cpu.incMem(hw, cpu.address("abs", 0xF31u), cpu.m8?8:16);
    goto L_01F111;
L_01F111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF111u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF111u, 4u, 3u, cpu.address("abs", 0x0F32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F111 STA
    hw.write(cpu.address("abs", 0xF32u), cpu.a, cpu.m8?8:16);
    goto L_01F114;
L_01F114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF114u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF114u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F114 BRA -> $01F12D
    goto L_01F12D;
L_01F116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF116u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF116u, 6u, 3u, cpu.address("abs", 0x18D5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F116 INC
    cpu.incMem(hw, cpu.address("abs", 0x18D5u), cpu.m8?8:16);
    goto L_01F119;
L_01F119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF119u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF119u, 4u, 3u, cpu.address("abs", 0x18D5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F119 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18D5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F11C;
L_01F11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F11C CMP
    cpu.compareA(0x2u);
    goto L_01F11E;
L_01F11E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF11Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F11E BNE -> $01F12D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F12D; }
    goto L_01F120;
L_01F120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF120u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF120u, 4u, 3u, cpu.address("abs", 0x18D5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F120 STZ
    hw.write(cpu.address("abs", 0x18D5u), 0, cpu.m8?8:16);
    goto L_01F123;
L_01F123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF123u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF123u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F123 LDA
    cpu.setA(0x6Au, 8);
    goto L_01F125;
L_01F125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF125u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF125u, 4u, 3u, cpu.address("abs", 0x18DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F125 STA
    hw.write(cpu.address("abs", 0x18DAu), cpu.a, cpu.m8?8:16);
    goto L_01F128;
L_01F128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF128u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF128u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F128 LDY
    cpu.setY(0x20u, 8);
    goto L_01F12A;
L_01F12A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Au, 4u, 3u, cpu.address("abs", 0x18DEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F12A STY
    hw.write(cpu.address("abs", 0x18DEu), cpu.y, cpu.x8?8:16);
    goto L_01F12D;
L_01F12D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F12D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01F12Du);return;} hw.unresolvedReturn(0x01F12Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04945D_E0M1X1C0_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04959Au: goto L_04959A;
    case 0x04959Cu: goto L_04959C;
    case 0x04959Du: goto L_04959D;
    case 0x0495A0u: goto L_0495A0;
    case 0x0495A2u: goto L_0495A2;
    case 0x0495A5u: goto L_0495A5;
    case 0x0495A6u: goto L_0495A6;
    case 0x0495A7u: goto L_0495A7;
    case 0x0495A8u: goto L_0495A8;
    case 0x0495ABu: goto L_0495AB;
    case 0x0495AEu: goto L_0495AE;
    case 0x0495B0u: goto L_0495B0;
    case 0x0495B2u: goto L_0495B2;
    case 0x0495B5u: goto L_0495B5;
    case 0x0495B6u: goto L_0495B6;
    case 0x0495B9u: goto L_0495B9;
    case 0x0495BCu: goto L_0495BC;
    case 0x0495BEu: goto L_0495BE;
    case 0x0495C0u: goto L_0495C0;
    case 0x0495C3u: goto L_0495C3;
    case 0x0495C6u: goto L_0495C6;
    case 0x0495C9u: goto L_0495C9;
    case 0x0495CCu: goto L_0495CC;
    case 0x0495CEu: goto L_0495CE;
    case 0x0495D0u: goto L_0495D0;
    case 0x0495D2u: goto L_0495D2;
    case 0x0495D5u: goto L_0495D5;
    case 0x0495D7u: goto L_0495D7;
    case 0x0495DBu: goto L_0495DB;
    case 0x0495DEu: goto L_0495DE;
    case 0x0495E1u: goto L_0495E1;
    case 0x0495E3u: goto L_0495E3;
    case 0x0495E6u: goto L_0495E6;
    case 0x0495E8u: goto L_0495E8;
    case 0x0495E9u: goto L_0495E9;
    case 0x0495EAu: goto L_0495EA;
    case 0x0495EBu: goto L_0495EB;
    case 0x0495ECu: goto L_0495EC;
    case 0x0495EFu: goto L_0495EF;
    case 0x0495F2u: goto L_0495F2;
    case 0x0495F4u: goto L_0495F4;
    case 0x0495F7u: goto L_0495F7;
    case 0x0495FAu: goto L_0495FA;
    case 0x0495FCu: goto L_0495FC;
    case 0x0495FFu: goto L_0495FF;
    case 0x049602u: goto L_049602;
    case 0x049605u: goto L_049605;
    case 0x049607u: goto L_049607;
    case 0x04960Au: goto L_04960A;
    case 0x04960Cu: goto L_04960C;
    case 0x04960Fu: goto L_04960F;
    case 0x049610u: goto L_049610;
    case 0x049611u: goto L_049611;
    case 0x049612u: goto L_049612;
    case 0x049614u: goto L_049614;
    case 0x049616u: goto L_049616;
    case 0x049619u: goto L_049619;
    case 0x04961Bu: goto L_04961B;
    case 0x04961Cu: goto L_04961C;
    case 0x04961Fu: goto L_04961F;
    case 0x049620u: goto L_049620;
    case 0x049622u: goto L_049622;
    case 0x049625u: goto L_049625;
    case 0x049628u: goto L_049628;
    case 0x04962Bu: goto L_04962B;
    case 0x04962Du: goto L_04962D;
    case 0x049630u: goto L_049630;
    case 0x049633u: goto L_049633;
    case 0x049636u: goto L_049636;
    case 0x049639u: goto L_049639;
    case 0x04963Cu: goto L_04963C;
    case 0x04963Eu: goto L_04963E;
    case 0x049640u: goto L_049640;
    case 0x049643u: goto L_049643;
    case 0x049645u: goto L_049645;
    case 0x049646u: goto L_049646;
    case 0x049648u: goto L_049648;
    case 0x04964Au: goto L_04964A;
    case 0x04964Bu: goto L_04964B;
    case 0x04964Cu: goto L_04964C;
    case 0x04964Fu: goto L_04964F;
    case 0x049651u: goto L_049651;
    case 0x049654u: goto L_049654;
    case 0x049657u: goto L_049657;
    case 0x049659u: goto L_049659;
    case 0x04965Cu: goto L_04965C;
    case 0x04965Eu: goto L_04965E;
    case 0x049661u: goto L_049661;
    case 0x049663u: goto L_049663;
    case 0x049666u: goto L_049666;
    case 0x049667u: goto L_049667;
    case 0x04966Au: goto L_04966A;
    case 0x04966Bu: goto L_04966B;
    case 0x04966Eu: goto L_04966E;
    case 0x049671u: goto L_049671;
    case 0x049674u: goto L_049674;
    case 0x049676u: goto L_049676;
    case 0x049679u: goto L_049679;
    case 0x04967Au: goto L_04967A;
    case 0x04967Du: goto L_04967D;
    case 0x04967Eu: goto L_04967E;
    case 0x049681u: goto L_049681;
    case 0x049684u: goto L_049684;
    case 0x049687u: goto L_049687;
    case 0x04968Au: goto L_04968A;
    case 0x04968Du: goto L_04968D;
    case 0x049690u: goto L_049690;
    case 0x049693u: goto L_049693;
    case 0x049695u: goto L_049695;
    case 0x049698u: goto L_049698;
    case 0x04969Au: goto L_04969A;
    case 0x04969Du: goto L_04969D;
    case 0x04969Fu: goto L_04969F;
    case 0x0496A2u: goto L_0496A2;
    case 0x0496A5u: goto L_0496A5;
    case 0x0496A6u: goto L_0496A6;
    case 0x0496A7u: goto L_0496A7;
    case 0x0496A8u: goto L_0496A8;
    case 0x0496ABu: goto L_0496AB;
    case 0x0496AEu: goto L_0496AE;
    case 0x0496B1u: goto L_0496B1;
    case 0x0496B3u: goto L_0496B3;
    case 0x0496B4u: goto L_0496B4;
    case 0x0496B5u: goto L_0496B5;
    case 0x0496B8u: goto L_0496B8;
    case 0x0496BBu: goto L_0496BB;
    case 0x0496BCu: goto L_0496BC;
    case 0x0496BEu: goto L_0496BE;
    case 0x0496C0u: goto L_0496C0;
    case 0x0496C4u: goto L_0496C4;
    case 0x0496C7u: goto L_0496C7;
    case 0x0496C8u: goto L_0496C8;
    case 0x0496CBu: goto L_0496CB;
    case 0x0496CEu: goto L_0496CE;
    case 0x0496D1u: goto L_0496D1;
    case 0x0496D2u: goto L_0496D2;
    case 0x0496D5u: goto L_0496D5;
    case 0x0496D6u: goto L_0496D6;
    case 0x0496D9u: goto L_0496D9;
    case 0x0496DAu: goto L_0496DA;
    case 0x0496DDu: goto L_0496DD;
    case 0x0496E0u: goto L_0496E0;
    case 0x0496E2u: goto L_0496E2;
    case 0x0496E5u: goto L_0496E5;
    case 0x0496E7u: goto L_0496E7;
    case 0x0496EAu: goto L_0496EA;
    case 0x0496EDu: goto L_0496ED;
    case 0x0496EFu: goto L_0496EF;
    case 0x0496F2u: goto L_0496F2;
    case 0x0496F5u: goto L_0496F5;
    case 0x0496F8u: goto L_0496F8;
    case 0x0496FAu: goto L_0496FA;
    case 0x0496FCu: goto L_0496FC;
    case 0x0496FDu: goto L_0496FD;
    case 0x0496FEu: goto L_0496FE;
    case 0x0496FFu: goto L_0496FF;
    case 0x049702u: goto L_049702;
    case 0x049704u: goto L_049704;
    case 0x049705u: goto L_049705;
    case 0x049707u: goto L_049707;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04959A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04959A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04959C;
L_04959C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04959C CLC
    cpu.setFlag('C', false);
    goto L_04959D;
L_04959D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Du,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Du, 5u + 1u, 3u, cpu.address("absy", 0x9058u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04959D ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x9058u), cpu.m8?8:16));
    goto L_0495A0;
L_0495A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A0u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495A0 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0495A2;
L_0495A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A2u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495A2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0495A5;
L_0495A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495A5 LSR
    cpu.lsrA();
    goto L_0495A6;
L_0495A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495A6 LSR
    cpu.lsrA();
    goto L_0495A7;
L_0495A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495A7 TAX
    cpu.transfer("TAX");
    goto L_0495A8;
L_0495A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A8u, 6u, 3u, cpu.address("abs", 0x9885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0495A8 JSR -> $049885 stack real
    { cpu.push16Value(hw,0x95AAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x95ABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9885u), 0x0495A8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0495AB;
L_0495AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ABu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x95ABu,0x0495ABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ABu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ABu, 5u, 3u, cpu.address("abs", 0x1B78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495AB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0495AE;
L_0495AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95AEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495AE BEQ -> $0495CE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0495CE; }
    goto L_0495B0;
L_0495B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B0u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495B0 STY
    hw.write(cpu.address("dp", 0x6u), cpu.y, cpu.x8?8:16);
    goto L_0495B2;
L_0495B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B2u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B2u, 5u, 3u, cpu.address("abs", 0x1B7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495B2 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1B7Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0495B5;
L_0495B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495B5 INX
    cpu.inc('X');
    goto L_0495B6;
L_0495B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B6u, 5u + 1u, 3u, cpu.address("absx", 0x90CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495B6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x90CAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0495B9;
L_0495B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495B9 AND
    cpu.logicAnd(0xFFu);
    goto L_0495BC;
L_0495BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BCu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495BC CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16));
    goto L_0495BE;
L_0495BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495BE BNE -> $049575
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x049575u,0x0495BEu); return; }
    goto L_0495C0;
L_0495C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C0u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C0u, 5u, 3u, cpu.address("abs", 0x1B7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495C0 STX
    hw.write(cpu.address("abs", 0x1B7Au), cpu.x, cpu.x8?8:16);
    goto L_0495C3;
L_0495C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C3u, 5u + 1u, 3u, cpu.address("absx", 0x9086u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495C3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9086u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0495C6;
L_0495C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495C6 AND
    cpu.logicAnd(0xFFu);
    goto L_0495C9;
L_0495C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495C9 CMP
    cpu.compareA(0x58u);
    goto L_0495CC;
L_0495CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95CCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495CC BNE -> $0495DE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0495DE; }
    goto L_0495CE;
L_0495CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95CEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495CE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0495D0;
L_0495D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D0u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495D0 BMI -> $049575
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x049575u,0x0495D0u); return; }
    goto L_0495D2;
L_0495D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495D2 CMP
    cpu.compareA(0x800u);
    goto L_0495D5;
L_0495D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495D5 BCS -> $049575
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x049575u,0x0495D5u); return; }
    goto L_0495D7;
L_0495D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D7u, 6u, 4u, ((0x7EC800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495D7 LDA
    cpu.loadA(hw.readW(((0x7EC800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0495DB;
L_0495DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495DB AND
    cpu.logicAnd(0xFFu);
    goto L_0495DE;
L_0495DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DEu, 5u, 3u, cpu.address("abs", 0x13C1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495DE STA
    hw.write(cpu.address("abs", 0x13C1u), cpu.a, cpu.m8?8:16);
    goto L_0495E1;
L_0495E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495E1 BEQ -> $049575
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x049575u,0x0495E1u); return; }
    goto L_0495E3;
L_0495E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495E3 CMP
    cpu.compareA(0x87u);
    goto L_0495E6;
L_0495E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495E6 BCS -> $049575
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x049575u,0x0495E6u); return; }
    goto L_0495E8;
L_0495E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E8u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0495E8 PHA
    cpu.push("PHA", hw);
    goto L_0495E9;
L_0495E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E9u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0495E9 PHY
    cpu.push("PHY", hw);
    goto L_0495EA;
L_0495EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95EAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495EA TAX
    cpu.transfer("TAX");
    goto L_0495EB;
L_0495EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95EBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495EB DEX
    cpu.decReg('X');
    goto L_0495EC;
L_0495EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ECu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495EC LDY
    cpu.setY(0x0u, 16);
    goto L_0495EF;
L_0495EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95EFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95EFu, 5u + 1u, 3u, cpu.address("absx", 0x9FEBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495EF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9FEBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0495F2;
L_0495F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495F2 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0495F4;
L_0495F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495F4 AND
    cpu.logicAnd(0xFFu);
    goto L_0495F7;
L_0495F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495F7 CMP
    cpu.compareA(0x14u);
    goto L_0495FA;
L_0495FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95FAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495FA BNE -> $0495FF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0495FF; }
    goto L_0495FC;
L_0495FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95FCu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495FC LDY
    cpu.setY(0x1u, 16);
    goto L_0495FF;
L_0495FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95FFu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95FFu, 5u, 3u, cpu.address("abs", 0x1B80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495FF STY
    hw.write(cpu.address("abs", 0x1B80u), cpu.y, cpu.x8?8:16);
    goto L_049602;
L_049602:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9602u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9602u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9602u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049602 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049605;
L_049605:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9605u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9605u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9605u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049605 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049607;
L_049607:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9607u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9607u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9607u, 6u, 3u, cpu.address("absx", 0x1F1Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049607 STA
    hw.write(cpu.address("absx", 0x1F1Fu), cpu.a, cpu.m8?8:16);
    goto L_04960A;
L_04960A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x960Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x960Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x960Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04960A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04960C;
L_04960C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x960Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x960Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x960Cu, 6u, 3u, cpu.address("absx", 0x1F21u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04960C STA
    hw.write(cpu.address("absx", 0x1F21u), cpu.a, cpu.m8?8:16);
    goto L_04960F;
L_04960F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x960Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x960Fu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x960Fu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04960F PLY
    cpu.pop("PLY", hw);
    goto L_049610;
L_049610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9610u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9610u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049610 PLA
    cpu.pop("PLA", hw);
    goto L_049611;
L_049611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9611u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9611u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049611 PHA
    cpu.push("PHA", hw);
    goto L_049612;
L_049612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9612u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9612u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049612 SEP
    cpu.sep(0x30u);
    goto L_049614;
L_049614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9614u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9614u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049614 LDX
    cpu.setX(0x9u, 8);
    goto L_049616;
L_049616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9616u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9616u, 4u + ((((0x9426u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049616 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x9426u), cpu.m8?8:16));
    goto L_049619;
L_049619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9619u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9619u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049619 BNE -> $049645
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049645; }
    goto L_04961B;
L_04961B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x961Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x961Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x961Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04961B PHY
    cpu.push("PHY", hw);
    goto L_04961C;
L_04961C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x961Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x961Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x961Cu, 6u, 3u, cpu.address("abs", 0x9A24u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04961C JSR -> $049A24 stack real
    { cpu.push16Value(hw,0x961Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x961Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9A24u), 0x04961Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04961F;
L_04961F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x961Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x961Fu,0x04961Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x961Fu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x961Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04961F PLY
    cpu.pop("PLY", hw);
    goto L_049620;
L_049620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9620u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9620u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049620 LDA
    cpu.setA(0x1u, 8);
    goto L_049622;
L_049622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9622u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9622u, 4u, 3u, cpu.address("abs", 0x1B9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049622 STA
    hw.write(cpu.address("abs", 0x1B9Eu), cpu.a, cpu.m8?8:16);
    goto L_049625;
L_049625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9625u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9625u, 6u, 3u, cpu.address("abs", 0xF407u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049625 JSR -> $04F407 stack real
    { cpu.push16Value(hw,0x9627u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9628u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF407u), 0x049625u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_049628;
L_049628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9628u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9628u,0x049628u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9628u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9628u, 4u, 3u, cpu.address("abs", 0x1B8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049628 STZ
    hw.write(cpu.address("abs", 0x1B8Cu), 0, cpu.m8?8:16);
    goto L_04962B;
L_04962B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04962B REP
    cpu.rep(0x20u);
    goto L_04962D;
L_04962D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Du, 5u, 3u, cpu.address("abs", 0x0701u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04962D STZ
    hw.write(cpu.address("abs", 0x701u), 0, cpu.m8?8:16);
    goto L_049630;
L_049630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9630u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9630u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049630 LDA
    cpu.setA(0x7000u, 16);
    goto L_049633;
L_049633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9633u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9633u, 5u, 3u, cpu.address("abs", 0x1B8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049633 STA
    hw.write(cpu.address("abs", 0x1B8Du), cpu.a, cpu.m8?8:16);
    goto L_049636;
L_049636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9636u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9636u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049636 LDA
    cpu.setA(0x5400u, 16);
    goto L_049639;
L_049639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9639u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9639u, 5u, 3u, cpu.address("abs", 0x1B8Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049639 STA
    hw.write(cpu.address("abs", 0x1B8Fu), cpu.a, cpu.m8?8:16);
    goto L_04963C;
L_04963C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04963C SEP
    cpu.sep(0x20u);
    goto L_04963E;
L_04963E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04963E LDA
    cpu.setA(0xAu, 8);
    goto L_049640;
L_049640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9640u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9640u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049640 STA
    hw.write(cpu.address("abs", 0x13D9u), cpu.a, cpu.m8?8:16);
    goto L_049643;
L_049643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9643u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9643u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9643u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049643 BRA -> $049648
    goto L_049648;
L_049645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9645u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9645u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049645 DEX
    cpu.decReg('X');
    goto L_049646;
L_049646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9646u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9646u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049646 BPL -> $049616
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_049616; }
    goto L_049648;
L_049648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9648u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9648u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9648u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049648 REP
    cpu.rep(0x30u);
    goto L_04964A;
L_04964A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04964A PLA
    cpu.pop("PLA", hw);
    goto L_04964B;
L_04964B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04964B PHA
    cpu.push("PHA", hw);
    goto L_04964C;
L_04964C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04964C CMP
    cpu.compareA(0x56u);
    goto L_04964F;
L_04964F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04964F BCS -> $049654
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_049654; }
    goto L_049651;
L_049651:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9651u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9651u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9651u, 3u, 3u, cpu.address("abs", 0x971Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049651 JMP -> $04971D
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x971Du),0x049651u); return;
L_049654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9654u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9654u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049654 CMP
    cpu.compareA(0x80u);
    goto L_049657;
L_049657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9657u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9657u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049657 BEQ -> $049663
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_049663; }
    goto L_049659;
L_049659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9659u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9659u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049659 CMP
    cpu.compareA(0x6Au);
    goto L_04965C;
L_04965C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x965Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x965Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x965Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04965C BCC -> $049676
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_049676; }
    goto L_04965E;
L_04965E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x965Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x965Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x965Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04965E CMP
    cpu.compareA(0x6Eu);
    goto L_049661;
L_049661:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9661u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9661u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9661u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049661 BCS -> $049676
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_049676; }
    goto L_049663;
L_049663:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9663u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9663u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9663u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049663 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049666;
L_049666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9666u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9666u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049666 LSR
    cpu.lsrA();
    goto L_049667;
L_049667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9667u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9667u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049667 AND
    cpu.logicAnd(0x2u);
    goto L_04966A;
L_04966A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x966Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x966Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x966Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04966A TAX
    cpu.transfer("TAX");
    goto L_04966B;
L_04966B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x966Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x966Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x966Bu, 5u + 1u, 3u, cpu.address("absx", 0x1F13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04966B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04966E;
L_04966E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x966Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x966Eu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x966Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04966E ORA
    cpu.logicOr(0x8u);
    goto L_049671;
L_049671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9671u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9671u, 6u, 3u, cpu.address("absx", 0x1F13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049671 STA
    hw.write(cpu.address("absx", 0x1F13u), cpu.a, cpu.m8?8:16);
    goto L_049674;
L_049674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9674u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9674u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9674u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049674 BRA -> $049687
    goto L_049687;
L_049676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9676u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9676u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049676 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049679;
L_049679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9679u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9679u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049679 LSR
    cpu.lsrA();
    goto L_04967A;
L_04967A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x967Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x967Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x967Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04967A AND
    cpu.logicAnd(0x2u);
    goto L_04967D;
L_04967D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x967Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x967Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x967Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04967D TAX
    cpu.transfer("TAX");
    goto L_04967E;
L_04967E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x967Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x967Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x967Eu, 5u + 1u, 3u, cpu.address("absx", 0x1F13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04967E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049681;
L_049681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9681u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9681u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049681 AND
    cpu.logicAnd(0xF7u);
    goto L_049684;
L_049684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9684u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9684u, 6u, 3u, cpu.address("absx", 0x1F13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049684 STA
    hw.write(cpu.address("absx", 0x1F13u), cpu.a, cpu.m8?8:16);
    goto L_049687;
L_049687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9687u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9687u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9687u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049687 LDA
    cpu.setA(0x1u, 16);
    goto L_04968A;
L_04968A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x968Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x968Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x968Au, 5u, 3u, cpu.address("abs", 0x1444u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04968A STA
    hw.write(cpu.address("abs", 0x1444u), cpu.a, cpu.m8?8:16);
    goto L_04968D;
L_04968D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x968Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x968Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x968Du, 5u, 3u, cpu.address("abs", 0x13C1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04968D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049690;
L_049690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9690u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9690u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049690 CMP
    cpu.compareA(0x5Fu);
    goto L_049693;
L_049693:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9693u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9693u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9693u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049693 BEQ -> $0496A5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0496A5; }
    goto L_049695;
L_049695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9695u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9695u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049695 CMP
    cpu.compareA(0x5Bu);
    goto L_049698;
L_049698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9698u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9698u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9698u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049698 BEQ -> $0496A5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0496A5; }
    goto L_04969A;
L_04969A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04969A CMP
    cpu.compareA(0x82u);
    goto L_04969D;
L_04969D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04969D BEQ -> $0496A5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0496A5; }
    goto L_04969F;
L_04969F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04969F LDA
    cpu.setA(0x23u, 16);
    goto L_0496A2;
L_0496A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A2u, 5u, 3u, cpu.address("abs", 0x1DFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496A2 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_0496A5;
L_0496A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496A5 NOP
    ;
    goto L_0496A6;
L_0496A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A6u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496A6 NOP
    ;
    goto L_0496A7;
L_0496A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496A7 NOP
    ;
    goto L_0496A8;
L_0496A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u, 5u, 3u, cpu.address("abs", 0x13C1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496A8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0496AB;
L_0496AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ABu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496AB AND
    cpu.logicAnd(0xFFu);
    goto L_0496AE;
L_0496AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496AE CMP
    cpu.compareA(0x82u);
    goto L_0496B1;
L_0496B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496B1 BEQ -> $0496D2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0496D2; }
    goto L_0496B3;
L_0496B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0496B3 PHY
    cpu.push("PHY", hw);
    goto L_0496B4;
L_0496B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B4u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496B4 TYA
    cpu.transfer("TYA");
    goto L_0496B5;
L_0496B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496B5 AND
    cpu.logicAnd(0xFFu);
    goto L_0496B8;
L_0496B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B8u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496B8 EOR
    cpu.logicXor(0x2u);
    goto L_0496BB;
L_0496BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496BB TAY
    cpu.transfer("TAY");
    goto L_0496BC;
L_0496BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496BC STZ
    hw.write(cpu.address("dp", 0x6u), 0, cpu.m8?8:16);
    goto L_0496BE;
L_0496BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496BE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0496C0;
L_0496C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C0u, 6u, 4u, ((0x7ED000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496C0 LDA
    cpu.loadA(hw.readW(((0x7ED000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0496C4;
L_0496C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496C4 AND
    cpu.logicAnd(0xFFu);
    goto L_0496C7;
L_0496C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496C7 TAX
    cpu.transfer("TAX");
    goto L_0496C8;
L_0496C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C8u, 5u + 1u, 3u, cpu.address("absy", 0x941Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496C8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x941Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0496CB;
L_0496CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CBu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CBu, 5u + 1u, 3u, cpu.address("absx", 0x1EA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496CB ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1EA2u), cpu.m8?8:16));
    goto L_0496CE;
L_0496CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CEu, 6u, 3u, cpu.address("absx", 0x1EA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496CE STA
    hw.write(cpu.address("absx", 0x1EA2u), cpu.a, cpu.m8?8:16);
    goto L_0496D1;
L_0496D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D1u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D1u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0496D1 PLY
    cpu.pop("PLY", hw);
    goto L_0496D2;
L_0496D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D2u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496D2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0496D5;
L_0496D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496D5 LSR
    cpu.lsrA();
    goto L_0496D6;
L_0496D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496D6 AND
    cpu.logicAnd(0x2u);
    goto L_0496D9;
L_0496D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496D9 TAX
    cpu.transfer("TAX");
    goto L_0496DA;
L_0496DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96DAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96DAu, 5u + 1u, 3u, cpu.address("absx", 0x1F13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496DA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0496DD;
L_0496DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96DDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96DDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496DD AND
    cpu.logicAnd(0xCu);
    goto L_0496E0;
L_0496E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496E0 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0496E2;
L_0496E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496E2 LDA
    cpu.setA(0x1u, 16);
    goto L_0496E5;
L_0496E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496E5 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_0496E7;
L_0496E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E7u, 5u, 3u, cpu.address("abs", 0x1B7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496E7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0496EA;
L_0496EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96EAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496EA AND
    cpu.logicAnd(0xFFu);
    goto L_0496ED;
L_0496ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96EDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496ED STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0496EF;
L_0496EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96EFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496EF LDX
    cpu.setX(0x17u, 16);
    goto L_0496F2;
L_0496F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F2u, 5u + 1u, 3u, cpu.address("absx", 0xA03Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496F2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA03Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0496F5;
L_0496F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496F5 AND
    cpu.logicAnd(0xFFu);
    goto L_0496F8;
L_0496F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496F8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_0496FA;
L_0496FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496FA BNE -> $049704
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049704; }
    goto L_0496FC;
L_0496FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496FC TXA
    cpu.transfer("TXA");
    goto L_0496FD;
L_0496FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496FD ASL
    cpu.aslA();
    goto L_0496FE;
L_0496FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FEu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496FE TAX
    cpu.transfer("TAX");
    goto L_0496FF;
L_0496FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FFu, 5u + 1u, 3u, cpu.address("absx", 0xA054u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496FF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA054u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049702;
L_049702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049702 BRA -> $049718
    hw.requestDispatch(0x049718u,0x049702u); return;
L_049704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9704u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9704u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049704 DEX
    cpu.decReg('X');
    goto L_049705;
L_049705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9705u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9705u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049705 BPL -> $0496F2
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0496F2; }
    goto L_049707;
L_049707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9707u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9707u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049707 LDA
    cpu.setA(0x0u, 16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x970Au,0x049707u); return;
}

void sub_07F722_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x07F722u: goto L_07F722;
    case 0x07F725u: goto L_07F725;
    case 0x07F728u: goto L_07F728;
    case 0x07F72Au: goto L_07F72A;
    case 0x07F72Du: goto L_07F72D;
    case 0x07F730u: goto L_07F730;
    case 0x07F733u: goto L_07F733;
    case 0x07F736u: goto L_07F736;
    case 0x07F739u: goto L_07F739;
    case 0x07F73Cu: goto L_07F73C;
    case 0x07F73Fu: goto L_07F73F;
    case 0x07F742u: goto L_07F742;
    case 0x07F745u: goto L_07F745;
    case 0x07F748u: goto L_07F748;
    case 0x07F74Bu: goto L_07F74B;
    case 0x07F74Eu: goto L_07F74E;
    case 0x07F751u: goto L_07F751;
    case 0x07F754u: goto L_07F754;
    case 0x07F756u: goto L_07F756;
    case 0x07F759u: goto L_07F759;
    case 0x07F75Bu: goto L_07F75B;
    case 0x07F75Eu: goto L_07F75E;
    case 0x07F761u: goto L_07F761;
    case 0x07F764u: goto L_07F764;
    case 0x07F767u: goto L_07F767;
    case 0x07F76Au: goto L_07F76A;
    case 0x07F76Du: goto L_07F76D;
    case 0x07F770u: goto L_07F770;
    case 0x07F773u: goto L_07F773;
    case 0x07F776u: goto L_07F776;
    case 0x07F779u: goto L_07F779;
    case 0x07F77Cu: goto L_07F77C;
    case 0x07F77Fu: goto L_07F77F;
    case 0x07F782u: goto L_07F782;
    case 0x07F785u: goto L_07F785;
    case 0x07F787u: goto L_07F787;
    case 0x07F78Au: goto L_07F78A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_07F722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF722u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF722u, 5u, 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F722 STZ
    hw.write(cpu.address("absx", 0x164Au), 0, cpu.m8?8:16);
    goto L_07F725;
L_07F725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u, 5u, 3u, cpu.address("absx", 0x1632u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F725 STZ
    hw.write(cpu.address("absx", 0x1632u), 0, cpu.m8?8:16);
    goto L_07F728;
L_07F728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF728u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF728u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F728 STZ
    hw.write(cpu.address("dpx", 0xC2u), 0, cpu.m8?8:16);
    goto L_07F72A;
L_07F72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Au, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F72A STZ
    hw.write(cpu.address("absx", 0x151Cu), 0, cpu.m8?8:16);
    goto L_07F72D;
L_07F72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Du, 5u, 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F72D STZ
    hw.write(cpu.address("absx", 0x1528u), 0, cpu.m8?8:16);
    goto L_07F730;
L_07F730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF730u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF730u, 5u, 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F730 STZ
    hw.write(cpu.address("absx", 0x1534u), 0, cpu.m8?8:16);
    goto L_07F733;
L_07F733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF733u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF733u, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F733 STZ
    hw.write(cpu.address("absx", 0x157Cu), 0, cpu.m8?8:16);
    goto L_07F736;
L_07F736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF736u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF736u, 5u, 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F736 STZ
    hw.write(cpu.address("absx", 0x1588u), 0, cpu.m8?8:16);
    goto L_07F739;
L_07F739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF739u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF739u, 5u, 3u, cpu.address("absx", 0x15C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F739 STZ
    hw.write(cpu.address("absx", 0x15C4u), 0, cpu.m8?8:16);
    goto L_07F73C;
L_07F73C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF73Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Cu, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F73C STZ
    hw.write(cpu.address("absx", 0x1602u), 0, cpu.m8?8:16);
    goto L_07F73F;
L_07F73F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF73Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Fu, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F73F STZ
    hw.write(cpu.address("absx", 0x1540u), 0, cpu.m8?8:16);
    goto L_07F742;
L_07F742:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF742u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF742u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF742u, 5u, 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F742 STZ
    hw.write(cpu.address("absx", 0x154Cu), 0, cpu.m8?8:16);
    goto L_07F745;
L_07F745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF745u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF745u, 5u, 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F745 STZ
    hw.write(cpu.address("absx", 0x1558u), 0, cpu.m8?8:16);
    goto L_07F748;
L_07F748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF748u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF748u, 5u, 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F748 STZ
    hw.write(cpu.address("absx", 0x1564u), 0, cpu.m8?8:16);
    goto L_07F74B;
L_07F74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Bu, 5u, 3u, cpu.address("absx", 0x1FE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F74B STZ
    hw.write(cpu.address("absx", 0x1FE2u), 0, cpu.m8?8:16);
    goto L_07F74E;
L_07F74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Eu, 5u, 3u, cpu.address("absx", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F74E STZ
    hw.write(cpu.address("absx", 0x1626u), 0, cpu.m8?8:16);
    goto L_07F751;
L_07F751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF751u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF751u, 5u, 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F751 STZ
    hw.write(cpu.address("absx", 0x1570u), 0, cpu.m8?8:16);
    goto L_07F754;
L_07F754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF754u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF754u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F754 STZ
    hw.write(cpu.address("dpx", 0xB6u), 0, cpu.m8?8:16);
    goto L_07F756;
L_07F756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF756u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF756u, 5u, 3u, cpu.address("absx", 0x14F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F756 STZ
    hw.write(cpu.address("absx", 0x14F8u), 0, cpu.m8?8:16);
    goto L_07F759;
L_07F759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF759u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF759u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F759 STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_07F75B;
L_07F75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Bu, 5u, 3u, cpu.address("absx", 0x14ECu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F75B STZ
    hw.write(cpu.address("absx", 0x14ECu), 0, cpu.m8?8:16);
    goto L_07F75E;
L_07F75E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF75Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Eu, 5u, 3u, cpu.address("absx", 0x15DCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F75E STZ
    hw.write(cpu.address("absx", 0x15DCu), 0, cpu.m8?8:16);
    goto L_07F761;
L_07F761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF761u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF761u, 5u, 3u, cpu.address("absx", 0x15D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F761 STZ
    hw.write(cpu.address("absx", 0x15D0u), 0, cpu.m8?8:16);
    goto L_07F764;
L_07F764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF764u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF764u, 5u, 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F764 STZ
    hw.write(cpu.address("absx", 0x163Eu), 0, cpu.m8?8:16);
    goto L_07F767;
L_07F767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF767u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF767u, 5u, 3u, cpu.address("absx", 0x1656u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F767 STZ
    hw.write(cpu.address("absx", 0x1656u), 0, cpu.m8?8:16);
    goto L_07F76A;
L_07F76A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF76Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Au, 5u, 3u, cpu.address("absx", 0x1662u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F76A STZ
    hw.write(cpu.address("absx", 0x1662u), 0, cpu.m8?8:16);
    goto L_07F76D;
L_07F76D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF76Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Du, 5u, 3u, cpu.address("absx", 0x166Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F76D STZ
    hw.write(cpu.address("absx", 0x166Eu), 0, cpu.m8?8:16);
    goto L_07F770;
L_07F770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF770u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF770u, 5u, 3u, cpu.address("absx", 0x167Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F770 STZ
    hw.write(cpu.address("absx", 0x167Au), 0, cpu.m8?8:16);
    goto L_07F773;
L_07F773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF773u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF773u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF773u, 5u, 3u, cpu.address("absx", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F773 STZ
    hw.write(cpu.address("absx", 0x1686u), 0, cpu.m8?8:16);
    goto L_07F776;
L_07F776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF776u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF776u, 5u, 3u, cpu.address("absx", 0x187Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F776 STZ
    hw.write(cpu.address("absx", 0x187Bu), 0, cpu.m8?8:16);
    goto L_07F779;
L_07F779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF779u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF779u, 5u, 3u, cpu.address("absx", 0x160Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F779 STZ
    hw.write(cpu.address("absx", 0x160Eu), 0, cpu.m8?8:16);
    goto L_07F77C;
L_07F77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Cu, 5u, 3u, cpu.address("absx", 0x1594u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F77C STZ
    hw.write(cpu.address("absx", 0x1594u), 0, cpu.m8?8:16);
    goto L_07F77F;
L_07F77F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF77Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Fu, 5u, 3u, cpu.address("absx", 0x1504u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F77F STZ
    hw.write(cpu.address("absx", 0x1504u), 0, cpu.m8?8:16);
    goto L_07F782;
L_07F782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF782u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF782u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF782u, 5u, 3u, cpu.address("absx", 0x1FD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F782 STZ
    hw.write(cpu.address("absx", 0x1FD6u), 0, cpu.m8?8:16);
    goto L_07F785;
L_07F785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF785u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF785u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F785 LDA
    cpu.setA(0x1u, 8);
    goto L_07F787;
L_07F787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF787u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF787u, 5u, 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F787 STA
    hw.write(cpu.address("absx", 0x15A0u), cpu.a, cpu.m8?8:16);
    goto L_07F78A;
L_07F78A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F78A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x07F78Au);return;} hw.unresolvedReturn(0x07F78Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_07F722_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x07F722u: goto L_07F722;
    case 0x07F725u: goto L_07F725;
    case 0x07F728u: goto L_07F728;
    case 0x07F72Au: goto L_07F72A;
    case 0x07F72Du: goto L_07F72D;
    case 0x07F730u: goto L_07F730;
    case 0x07F733u: goto L_07F733;
    case 0x07F736u: goto L_07F736;
    case 0x07F739u: goto L_07F739;
    case 0x07F73Cu: goto L_07F73C;
    case 0x07F73Fu: goto L_07F73F;
    case 0x07F742u: goto L_07F742;
    case 0x07F745u: goto L_07F745;
    case 0x07F748u: goto L_07F748;
    case 0x07F74Bu: goto L_07F74B;
    case 0x07F74Eu: goto L_07F74E;
    case 0x07F751u: goto L_07F751;
    case 0x07F754u: goto L_07F754;
    case 0x07F756u: goto L_07F756;
    case 0x07F759u: goto L_07F759;
    case 0x07F75Bu: goto L_07F75B;
    case 0x07F75Eu: goto L_07F75E;
    case 0x07F761u: goto L_07F761;
    case 0x07F764u: goto L_07F764;
    case 0x07F767u: goto L_07F767;
    case 0x07F76Au: goto L_07F76A;
    case 0x07F76Du: goto L_07F76D;
    case 0x07F770u: goto L_07F770;
    case 0x07F773u: goto L_07F773;
    case 0x07F776u: goto L_07F776;
    case 0x07F779u: goto L_07F779;
    case 0x07F77Cu: goto L_07F77C;
    case 0x07F77Fu: goto L_07F77F;
    case 0x07F782u: goto L_07F782;
    case 0x07F785u: goto L_07F785;
    case 0x07F787u: goto L_07F787;
    case 0x07F78Au: goto L_07F78A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_07F722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF722u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF722u, 5u, 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F722 STZ
    hw.write(cpu.address("absx", 0x164Au), 0, cpu.m8?8:16);
    goto L_07F725;
L_07F725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u, 5u, 3u, cpu.address("absx", 0x1632u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F725 STZ
    hw.write(cpu.address("absx", 0x1632u), 0, cpu.m8?8:16);
    goto L_07F728;
L_07F728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF728u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF728u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F728 STZ
    hw.write(cpu.address("dpx", 0xC2u), 0, cpu.m8?8:16);
    goto L_07F72A;
L_07F72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Au, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F72A STZ
    hw.write(cpu.address("absx", 0x151Cu), 0, cpu.m8?8:16);
    goto L_07F72D;
L_07F72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Du, 5u, 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F72D STZ
    hw.write(cpu.address("absx", 0x1528u), 0, cpu.m8?8:16);
    goto L_07F730;
L_07F730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF730u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF730u, 5u, 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F730 STZ
    hw.write(cpu.address("absx", 0x1534u), 0, cpu.m8?8:16);
    goto L_07F733;
L_07F733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF733u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF733u, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F733 STZ
    hw.write(cpu.address("absx", 0x157Cu), 0, cpu.m8?8:16);
    goto L_07F736;
L_07F736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF736u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF736u, 5u, 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F736 STZ
    hw.write(cpu.address("absx", 0x1588u), 0, cpu.m8?8:16);
    goto L_07F739;
L_07F739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF739u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF739u, 5u, 3u, cpu.address("absx", 0x15C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F739 STZ
    hw.write(cpu.address("absx", 0x15C4u), 0, cpu.m8?8:16);
    goto L_07F73C;
L_07F73C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF73Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Cu, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F73C STZ
    hw.write(cpu.address("absx", 0x1602u), 0, cpu.m8?8:16);
    goto L_07F73F;
L_07F73F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF73Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Fu, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F73F STZ
    hw.write(cpu.address("absx", 0x1540u), 0, cpu.m8?8:16);
    goto L_07F742;
L_07F742:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF742u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF742u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF742u, 5u, 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F742 STZ
    hw.write(cpu.address("absx", 0x154Cu), 0, cpu.m8?8:16);
    goto L_07F745;
L_07F745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF745u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF745u, 5u, 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F745 STZ
    hw.write(cpu.address("absx", 0x1558u), 0, cpu.m8?8:16);
    goto L_07F748;
L_07F748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF748u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF748u, 5u, 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F748 STZ
    hw.write(cpu.address("absx", 0x1564u), 0, cpu.m8?8:16);
    goto L_07F74B;
L_07F74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Bu, 5u, 3u, cpu.address("absx", 0x1FE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F74B STZ
    hw.write(cpu.address("absx", 0x1FE2u), 0, cpu.m8?8:16);
    goto L_07F74E;
L_07F74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Eu, 5u, 3u, cpu.address("absx", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F74E STZ
    hw.write(cpu.address("absx", 0x1626u), 0, cpu.m8?8:16);
    goto L_07F751;
L_07F751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF751u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF751u, 5u, 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F751 STZ
    hw.write(cpu.address("absx", 0x1570u), 0, cpu.m8?8:16);
    goto L_07F754;
L_07F754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF754u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF754u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F754 STZ
    hw.write(cpu.address("dpx", 0xB6u), 0, cpu.m8?8:16);
    goto L_07F756;
L_07F756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF756u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF756u, 5u, 3u, cpu.address("absx", 0x14F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F756 STZ
    hw.write(cpu.address("absx", 0x14F8u), 0, cpu.m8?8:16);
    goto L_07F759;
L_07F759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF759u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF759u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F759 STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_07F75B;
L_07F75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Bu, 5u, 3u, cpu.address("absx", 0x14ECu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F75B STZ
    hw.write(cpu.address("absx", 0x14ECu), 0, cpu.m8?8:16);
    goto L_07F75E;
L_07F75E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF75Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Eu, 5u, 3u, cpu.address("absx", 0x15DCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F75E STZ
    hw.write(cpu.address("absx", 0x15DCu), 0, cpu.m8?8:16);
    goto L_07F761;
L_07F761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF761u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF761u, 5u, 3u, cpu.address("absx", 0x15D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F761 STZ
    hw.write(cpu.address("absx", 0x15D0u), 0, cpu.m8?8:16);
    goto L_07F764;
L_07F764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF764u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF764u, 5u, 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F764 STZ
    hw.write(cpu.address("absx", 0x163Eu), 0, cpu.m8?8:16);
    goto L_07F767;
L_07F767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF767u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF767u, 5u, 3u, cpu.address("absx", 0x1656u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F767 STZ
    hw.write(cpu.address("absx", 0x1656u), 0, cpu.m8?8:16);
    goto L_07F76A;
L_07F76A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF76Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Au, 5u, 3u, cpu.address("absx", 0x1662u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F76A STZ
    hw.write(cpu.address("absx", 0x1662u), 0, cpu.m8?8:16);
    goto L_07F76D;
L_07F76D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF76Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Du, 5u, 3u, cpu.address("absx", 0x166Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F76D STZ
    hw.write(cpu.address("absx", 0x166Eu), 0, cpu.m8?8:16);
    goto L_07F770;
L_07F770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF770u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF770u, 5u, 3u, cpu.address("absx", 0x167Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F770 STZ
    hw.write(cpu.address("absx", 0x167Au), 0, cpu.m8?8:16);
    goto L_07F773;
L_07F773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF773u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF773u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF773u, 5u, 3u, cpu.address("absx", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F773 STZ
    hw.write(cpu.address("absx", 0x1686u), 0, cpu.m8?8:16);
    goto L_07F776;
L_07F776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF776u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF776u, 5u, 3u, cpu.address("absx", 0x187Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F776 STZ
    hw.write(cpu.address("absx", 0x187Bu), 0, cpu.m8?8:16);
    goto L_07F779;
L_07F779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF779u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF779u, 5u, 3u, cpu.address("absx", 0x160Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F779 STZ
    hw.write(cpu.address("absx", 0x160Eu), 0, cpu.m8?8:16);
    goto L_07F77C;
L_07F77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Cu, 5u, 3u, cpu.address("absx", 0x1594u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F77C STZ
    hw.write(cpu.address("absx", 0x1594u), 0, cpu.m8?8:16);
    goto L_07F77F;
L_07F77F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF77Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Fu, 5u, 3u, cpu.address("absx", 0x1504u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F77F STZ
    hw.write(cpu.address("absx", 0x1504u), 0, cpu.m8?8:16);
    goto L_07F782;
L_07F782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF782u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF782u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF782u, 5u, 3u, cpu.address("absx", 0x1FD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F782 STZ
    hw.write(cpu.address("absx", 0x1FD6u), 0, cpu.m8?8:16);
    goto L_07F785;
L_07F785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF785u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF785u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F785 LDA
    cpu.setA(0x1u, 8);
    goto L_07F787;
L_07F787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF787u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF787u, 5u, 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F787 STA
    hw.write(cpu.address("absx", 0x15A0u), cpu.a, cpu.m8?8:16);
    goto L_07F78A;
L_07F78A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F78A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x07F78Au);return;} hw.unresolvedReturn(0x07F78Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_07F722_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x07F722u: goto L_07F722;
    case 0x07F725u: goto L_07F725;
    case 0x07F728u: goto L_07F728;
    case 0x07F72Au: goto L_07F72A;
    case 0x07F72Du: goto L_07F72D;
    case 0x07F730u: goto L_07F730;
    case 0x07F733u: goto L_07F733;
    case 0x07F736u: goto L_07F736;
    case 0x07F739u: goto L_07F739;
    case 0x07F73Cu: goto L_07F73C;
    case 0x07F73Fu: goto L_07F73F;
    case 0x07F742u: goto L_07F742;
    case 0x07F745u: goto L_07F745;
    case 0x07F748u: goto L_07F748;
    case 0x07F74Bu: goto L_07F74B;
    case 0x07F74Eu: goto L_07F74E;
    case 0x07F751u: goto L_07F751;
    case 0x07F754u: goto L_07F754;
    case 0x07F756u: goto L_07F756;
    case 0x07F759u: goto L_07F759;
    case 0x07F75Bu: goto L_07F75B;
    case 0x07F75Eu: goto L_07F75E;
    case 0x07F761u: goto L_07F761;
    case 0x07F764u: goto L_07F764;
    case 0x07F767u: goto L_07F767;
    case 0x07F76Au: goto L_07F76A;
    case 0x07F76Du: goto L_07F76D;
    case 0x07F770u: goto L_07F770;
    case 0x07F773u: goto L_07F773;
    case 0x07F776u: goto L_07F776;
    case 0x07F779u: goto L_07F779;
    case 0x07F77Cu: goto L_07F77C;
    case 0x07F77Fu: goto L_07F77F;
    case 0x07F782u: goto L_07F782;
    case 0x07F785u: goto L_07F785;
    case 0x07F787u: goto L_07F787;
    case 0x07F78Au: goto L_07F78A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_07F722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF722u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF722u, 5u, 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F722 STZ
    hw.write(cpu.address("absx", 0x164Au), 0, cpu.m8?8:16);
    goto L_07F725;
L_07F725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u, 5u, 3u, cpu.address("absx", 0x1632u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F725 STZ
    hw.write(cpu.address("absx", 0x1632u), 0, cpu.m8?8:16);
    goto L_07F728;
L_07F728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF728u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF728u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F728 STZ
    hw.write(cpu.address("dpx", 0xC2u), 0, cpu.m8?8:16);
    goto L_07F72A;
L_07F72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Au, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F72A STZ
    hw.write(cpu.address("absx", 0x151Cu), 0, cpu.m8?8:16);
    goto L_07F72D;
L_07F72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Du, 5u, 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F72D STZ
    hw.write(cpu.address("absx", 0x1528u), 0, cpu.m8?8:16);
    goto L_07F730;
L_07F730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF730u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF730u, 5u, 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F730 STZ
    hw.write(cpu.address("absx", 0x1534u), 0, cpu.m8?8:16);
    goto L_07F733;
L_07F733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF733u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF733u, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F733 STZ
    hw.write(cpu.address("absx", 0x157Cu), 0, cpu.m8?8:16);
    goto L_07F736;
L_07F736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF736u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF736u, 5u, 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F736 STZ
    hw.write(cpu.address("absx", 0x1588u), 0, cpu.m8?8:16);
    goto L_07F739;
L_07F739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF739u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF739u, 5u, 3u, cpu.address("absx", 0x15C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F739 STZ
    hw.write(cpu.address("absx", 0x15C4u), 0, cpu.m8?8:16);
    goto L_07F73C;
L_07F73C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF73Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Cu, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F73C STZ
    hw.write(cpu.address("absx", 0x1602u), 0, cpu.m8?8:16);
    goto L_07F73F;
L_07F73F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF73Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Fu, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F73F STZ
    hw.write(cpu.address("absx", 0x1540u), 0, cpu.m8?8:16);
    goto L_07F742;
L_07F742:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF742u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF742u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF742u, 5u, 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F742 STZ
    hw.write(cpu.address("absx", 0x154Cu), 0, cpu.m8?8:16);
    goto L_07F745;
L_07F745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF745u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF745u, 5u, 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F745 STZ
    hw.write(cpu.address("absx", 0x1558u), 0, cpu.m8?8:16);
    goto L_07F748;
L_07F748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF748u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF748u, 5u, 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F748 STZ
    hw.write(cpu.address("absx", 0x1564u), 0, cpu.m8?8:16);
    goto L_07F74B;
L_07F74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Bu, 5u, 3u, cpu.address("absx", 0x1FE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F74B STZ
    hw.write(cpu.address("absx", 0x1FE2u), 0, cpu.m8?8:16);
    goto L_07F74E;
L_07F74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Eu, 5u, 3u, cpu.address("absx", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F74E STZ
    hw.write(cpu.address("absx", 0x1626u), 0, cpu.m8?8:16);
    goto L_07F751;
L_07F751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF751u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF751u, 5u, 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F751 STZ
    hw.write(cpu.address("absx", 0x1570u), 0, cpu.m8?8:16);
    goto L_07F754;
L_07F754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF754u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF754u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F754 STZ
    hw.write(cpu.address("dpx", 0xB6u), 0, cpu.m8?8:16);
    goto L_07F756;
L_07F756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF756u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF756u, 5u, 3u, cpu.address("absx", 0x14F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F756 STZ
    hw.write(cpu.address("absx", 0x14F8u), 0, cpu.m8?8:16);
    goto L_07F759;
L_07F759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF759u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF759u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F759 STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_07F75B;
L_07F75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Bu, 5u, 3u, cpu.address("absx", 0x14ECu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F75B STZ
    hw.write(cpu.address("absx", 0x14ECu), 0, cpu.m8?8:16);
    goto L_07F75E;
L_07F75E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF75Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Eu, 5u, 3u, cpu.address("absx", 0x15DCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F75E STZ
    hw.write(cpu.address("absx", 0x15DCu), 0, cpu.m8?8:16);
    goto L_07F761;
L_07F761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF761u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF761u, 5u, 3u, cpu.address("absx", 0x15D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F761 STZ
    hw.write(cpu.address("absx", 0x15D0u), 0, cpu.m8?8:16);
    goto L_07F764;
L_07F764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF764u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF764u, 5u, 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F764 STZ
    hw.write(cpu.address("absx", 0x163Eu), 0, cpu.m8?8:16);
    goto L_07F767;
L_07F767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF767u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF767u, 5u, 3u, cpu.address("absx", 0x1656u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F767 STZ
    hw.write(cpu.address("absx", 0x1656u), 0, cpu.m8?8:16);
    goto L_07F76A;
L_07F76A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF76Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Au, 5u, 3u, cpu.address("absx", 0x1662u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F76A STZ
    hw.write(cpu.address("absx", 0x1662u), 0, cpu.m8?8:16);
    goto L_07F76D;
L_07F76D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF76Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Du, 5u, 3u, cpu.address("absx", 0x166Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F76D STZ
    hw.write(cpu.address("absx", 0x166Eu), 0, cpu.m8?8:16);
    goto L_07F770;
L_07F770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF770u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF770u, 5u, 3u, cpu.address("absx", 0x167Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F770 STZ
    hw.write(cpu.address("absx", 0x167Au), 0, cpu.m8?8:16);
    goto L_07F773;
L_07F773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF773u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF773u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF773u, 5u, 3u, cpu.address("absx", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F773 STZ
    hw.write(cpu.address("absx", 0x1686u), 0, cpu.m8?8:16);
    goto L_07F776;
L_07F776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF776u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF776u, 5u, 3u, cpu.address("absx", 0x187Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F776 STZ
    hw.write(cpu.address("absx", 0x187Bu), 0, cpu.m8?8:16);
    goto L_07F779;
L_07F779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF779u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF779u, 5u, 3u, cpu.address("absx", 0x160Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F779 STZ
    hw.write(cpu.address("absx", 0x160Eu), 0, cpu.m8?8:16);
    goto L_07F77C;
L_07F77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Cu, 5u, 3u, cpu.address("absx", 0x1594u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F77C STZ
    hw.write(cpu.address("absx", 0x1594u), 0, cpu.m8?8:16);
    goto L_07F77F;
L_07F77F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF77Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Fu, 5u, 3u, cpu.address("absx", 0x1504u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F77F STZ
    hw.write(cpu.address("absx", 0x1504u), 0, cpu.m8?8:16);
    goto L_07F782;
L_07F782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF782u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF782u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF782u, 5u, 3u, cpu.address("absx", 0x1FD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F782 STZ
    hw.write(cpu.address("absx", 0x1FD6u), 0, cpu.m8?8:16);
    goto L_07F785;
L_07F785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF785u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF785u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F785 LDA
    cpu.setA(0x1u, 8);
    goto L_07F787;
L_07F787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF787u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF787u, 5u, 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F787 STA
    hw.write(cpu.address("absx", 0x15A0u), cpu.a, cpu.m8?8:16);
    goto L_07F78A;
L_07F78A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F78A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x07F78Au);return;} hw.unresolvedReturn(0x07F78Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0CAB13_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CAB13u: goto L_0CAB13;
    case 0x0CAB14u: goto L_0CAB14;
    case 0x0CAB15u: goto L_0CAB15;
    case 0x0CAB16u: goto L_0CAB16;
    case 0x0CAB19u: goto L_0CAB19;
    case 0x0CAB1Au: goto L_0CAB1A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CAB13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB13u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB13u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CAB13 PHB
    cpu.push("PHB", hw);
    goto L_0CAB14;
L_0CAB14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB14u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB14u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CAB14 PHK
    cpu.push("PHK", hw);
    goto L_0CAB15;
L_0CAB15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB15u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB15u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CAB15 PLB
    cpu.pop("PLB", hw);
    goto L_0CAB16;
L_0CAB16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB16u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB16u, 6u, 3u, cpu.address("abs", 0xAB1Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CAB16 JSR -> $0CAB1F stack real
    { cpu.push16Value(hw,0xAB18u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB19u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAB1Fu), 0x0CAB16u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0CAB19;
L_0CAB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB19u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB19u,0x0CAB19u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB19u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB19u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CAB19 PLB
    cpu.pop("PLB", hw);
    goto L_0CAB1A;
L_0CAB1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB1Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB1Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0CAB1A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x0CAB1Au);return;} hw.unresolvedReturn(0x0CAB1Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0CD4F8_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CD4F8u: goto L_0CD4F8;
    case 0x0CD4FBu: goto L_0CD4FB;
    case 0x0CD4FDu: goto L_0CD4FD;
    case 0x0CD500u: goto L_0CD500;
    case 0x0CD502u: goto L_0CD502;
    case 0x0CD504u: goto L_0CD504;
    case 0x0CD506u: goto L_0CD506;
    case 0x0CD509u: goto L_0CD509;
    case 0x0CD50Cu: goto L_0CD50C;
    case 0x0CD50Fu: goto L_0CD50F;
    case 0x0CD511u: goto L_0CD511;
    case 0x0CD512u: goto L_0CD512;
    case 0x0CD514u: goto L_0CD514;
    case 0x0CD516u: goto L_0CD516;
    case 0x0CD519u: goto L_0CD519;
    case 0x0CD51Bu: goto L_0CD51B;
    case 0x0CD51Du: goto L_0CD51D;
    case 0x0CD51Fu: goto L_0CD51F;
    case 0x0CD521u: goto L_0CD521;
    case 0x0CD523u: goto L_0CD523;
    case 0x0CD525u: goto L_0CD525;
    case 0x0CD527u: goto L_0CD527;
    case 0x0CD529u: goto L_0CD529;
    case 0x0CD52Au: goto L_0CD52A;
    case 0x0CD52Cu: goto L_0CD52C;
    case 0x0CD52Fu: goto L_0CD52F;
    case 0x0CD532u: goto L_0CD532;
    case 0x0CD533u: goto L_0CD533;
    case 0x0CD535u: goto L_0CD535;
    case 0x0CD536u: goto L_0CD536;
    case 0x0CD538u: goto L_0CD538;
    case 0x0CD53Bu: goto L_0CD53B;
    case 0x0CD53Eu: goto L_0CD53E;
    case 0x0CD540u: goto L_0CD540;
    case 0x0CD541u: goto L_0CD541;
    case 0x0CD542u: goto L_0CD542;
    case 0x0CD543u: goto L_0CD543;
    case 0x0CD544u: goto L_0CD544;
    case 0x0CD547u: goto L_0CD547;
    case 0x0CD54Au: goto L_0CD54A;
    case 0x0CD54Cu: goto L_0CD54C;
    case 0x0CD54Fu: goto L_0CD54F;
    case 0x0CD550u: goto L_0CD550;
    case 0x0CD551u: goto L_0CD551;
    case 0x0CD552u: goto L_0CD552;
    case 0x0CD553u: goto L_0CD553;
    case 0x0CD556u: goto L_0CD556;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CD4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F8u, 4u, 3u, cpu.address("abs", 0x1446u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD4F8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1446u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD4FB;
L_0CD4FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD4FB BNE -> $0CD502
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CD502; }
    goto L_0CD4FD;
L_0CD4FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FDu, 4u, 3u, cpu.address("abs", 0x0B43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD4FD STZ
    hw.write(cpu.address("abs", 0xB43u), 0, cpu.m8?8:16);
    goto L_0CD500;
L_0CD500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD500u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD500u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD500 BRA -> $0CD556
    goto L_0CD556;
L_0CD502:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD502u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD502u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD502u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD502 LDX
    cpu.setX(0x2u, 8);
    goto L_0CD504;
L_0CD504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD504u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD504u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD504 LDA
    cpu.setA(0xFDu, 8);
    goto L_0CD506;
L_0CD506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD506u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD506u, 5u, 3u, cpu.address("absx", 0x0B05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD506 STA
    hw.write(cpu.address("absx", 0xB05u), cpu.a, cpu.m8?8:16);
    goto L_0CD509;
L_0CD509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD509u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD509u, 6u, 3u, cpu.address("abs", 0xD33Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CD509 JSR -> $0CD33A stack real
    { cpu.push16Value(hw,0xD50Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD50Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD33Au), 0x0CD509u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0CD50C;
L_0CD50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD50Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD50Cu,0x0CD50Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Cu, 4u + ((((0x0B41u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0B41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD50C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB41u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD50F;
L_0CD50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Fu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD50F EOR
    cpu.logicXor(0xFFu);
    goto L_0CD511;
L_0CD511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD511u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD511u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD511 INC
    cpu.inc('A');
    goto L_0CD512;
L_0CD512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD512u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD512u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD512 CMP
    cpu.compareA(0xDu);
    goto L_0CD514;
L_0CD514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD514u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD514u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD514 BCC -> $0CD51B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0CD51B; }
    goto L_0CD516;
L_0CD516:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD516u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD516u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD516u, 4u, 3u, cpu.address("abs", 0x1446u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD516 STZ
    hw.write(cpu.address("abs", 0x1446u), 0, cpu.m8?8:16);
    goto L_0CD519;
L_0CD519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD519u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD519u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD519 BRA -> $0CD556
    goto L_0CD556;
L_0CD51B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD51Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD51B LDX
    cpu.setX(0x0u, 8);
    goto L_0CD51D;
L_0CD51D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD51Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD51D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD51F;
L_0CD51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD51Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD51F BNE -> $0CD523
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CD523; }
    goto L_0CD521;
L_0CD521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD521u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD521u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD521 LDX
    cpu.setX(0x8u, 8);
    goto L_0CD523;
L_0CD523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD523u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD523u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD523 STX
    hw.write(cpu.address("dp", 0x0u), cpu.x, cpu.x8?8:16);
    goto L_0CD525;
L_0CD525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD525u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD525u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD525 LDX
    cpu.setX(0x34u, 8);
    goto L_0CD527;
L_0CD527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD527u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD527u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD527u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD527 LDA
    cpu.setA(0x4u, 8);
    goto L_0CD529;
L_0CD529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD529u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD529u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD529 CLC
    cpu.setFlag('C', false);
    goto L_0CD52A;
L_0CD52A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD52A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_0CD52C;
L_0CD52C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Cu, 5u, 3u, cpu.address("absx", 0x0200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD52C STA
    hw.write(cpu.address("absx", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_0CD52F;
L_0CD52F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Fu, 4u, 3u, cpu.address("abs", 0x0B43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD52F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xB43u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD532;
L_0CD532:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD532u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD532u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD532u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD532 CLC
    cpu.setFlag('C', false);
    goto L_0CD533;
L_0CD533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD533u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD533u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD533 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16));
    goto L_0CD535;
L_0CD535:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD535u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD535u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD535u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD535 CLC
    cpu.setFlag('C', false);
    goto L_0CD536;
L_0CD536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD536u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD536u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD536 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_0CD538;
L_0CD538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD538u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD538u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD538u, 5u, 3u, cpu.address("absx", 0x0201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD538 STA
    hw.write(cpu.address("absx", 0x201u), cpu.a, cpu.m8?8:16);
    goto L_0CD53B;
L_0CD53B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD53Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Bu, 4u, 3u, cpu.address("abs", 0x0B43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD53B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xB43u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD53E;
L_0CD53E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD53Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Eu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD53E EOR
    cpu.logicXor(0xFFu);
    goto L_0CD540;
L_0CD540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD540u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD540u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD540 INC
    cpu.inc('A');
    goto L_0CD541;
L_0CD541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD541u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD541u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD541 LSR
    cpu.lsrA();
    goto L_0CD542;
L_0CD542:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD542u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD542u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD542u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD542 LSR
    cpu.lsrA();
    goto L_0CD543;
L_0CD543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD543u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD543u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD543u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD543 TAY
    cpu.transfer("TAY");
    goto L_0CD544;
L_0CD544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD544u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD544u, 4u + ((((0xD4F4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD4F4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD544 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD4F4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD547;
L_0CD547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD547u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD547u, 5u, 3u, cpu.address("absx", 0x0202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD547 STA
    hw.write(cpu.address("absx", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_0CD54A;
L_0CD54A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD54Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD54A LDA
    cpu.setA(0x33u, 8);
    goto L_0CD54C;
L_0CD54C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD54Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Cu, 5u, 3u, cpu.address("absx", 0x0203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD54C STA
    hw.write(cpu.address("absx", 0x203u), cpu.a, cpu.m8?8:16);
    goto L_0CD54F;
L_0CD54F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD54Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD54F TXA
    cpu.transfer("TXA");
    goto L_0CD550;
L_0CD550:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD550u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD550u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD550u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD550 LSR
    cpu.lsrA();
    goto L_0CD551;
L_0CD551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD551u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD551u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD551 LSR
    cpu.lsrA();
    goto L_0CD552;
L_0CD552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD552u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD552u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD552 TAX
    cpu.transfer("TAX");
    goto L_0CD553;
L_0CD553:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD553u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD553u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD553u, 5u, 3u, cpu.address("absx", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD553 STZ
    hw.write(cpu.address("absx", 0x420u), 0, cpu.m8?8:16);
    goto L_0CD556;
L_0CD556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD556u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD556u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CD556 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CD556u);return;} hw.unresolvedReturn(0x0CD556u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB916_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB916u: goto L_0DB916;
    case 0x0DB918u: goto L_0DB918;
    case 0x0DB91Au: goto L_0DB91A;
    case 0x0DB920u: goto L_0DB920;
    case 0x0DB922u: goto L_0DB922;
    case 0x0DB924u: goto L_0DB924;
    case 0x0DB926u: goto L_0DB926;
    case 0x0DB928u: goto L_0DB928;
    case 0x0DB92Au: goto L_0DB92A;
    case 0x0DB92Bu: goto L_0DB92B;
    case 0x0DB92Cu: goto L_0DB92C;
    case 0x0DB92Du: goto L_0DB92D;
    case 0x0DB92Eu: goto L_0DB92E;
    case 0x0DB930u: goto L_0DB930;
    case 0x0DB932u: goto L_0DB932;
    case 0x0DB934u: goto L_0DB934;
    case 0x0DB937u: goto L_0DB937;
    case 0x0DB93Au: goto L_0DB93A;
    case 0x0DB93Eu: goto L_0DB93E;
    case 0x0DB940u: goto L_0DB940;
    case 0x0DB943u: goto L_0DB943;
    case 0x0DB945u: goto L_0DB945;
    case 0x0DB948u: goto L_0DB948;
    case 0x0DB94Cu: goto L_0DB94C;
    case 0x0DB94Eu: goto L_0DB94E;
    case 0x0DB950u: goto L_0DB950;
    case 0x0DB953u: goto L_0DB953;
    case 0x0DB955u: goto L_0DB955;
    case 0x0DB957u: goto L_0DB957;
    case 0x0DB95Au: goto L_0DB95A;
    case 0x0DB95Du: goto L_0DB95D;
    case 0x0DB95Fu: goto L_0DB95F;
    case 0x0DB961u: goto L_0DB961;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB916u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB916u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB916u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB916 LDX
    cpu.setX(0x0u, 8);
    goto L_0DB918;
L_0DB918:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB918u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB918u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB918u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB918 BEQ -> $0DB920
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB920; }
    goto L_0DB91A;
L_0DB91A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Au,cpu,0x6Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Au, 5u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, 0x6C6Du, 2u, 0u);
    // $0DB91A JMP (6C6D) dinamico
    { auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(0x6C6Du); hw.requestDispatch(dst,0x0DB91Au); return; }
L_0DB920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB920u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB920u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB920 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB922;
L_0DB922:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB922u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB922u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB922u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB922 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB924;
L_0DB924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB924u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB924 AND
    cpu.logicAnd(0xFu);
    goto L_0DB926;
L_0DB926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB926u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB926u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB926 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB928;
L_0DB928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB928u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB928u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB928u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB928 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB92A;
L_0DB92A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB92A LSR
    cpu.lsrA();
    goto L_0DB92B;
L_0DB92B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB92B LSR
    cpu.lsrA();
    goto L_0DB92C;
L_0DB92C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB92C LSR
    cpu.lsrA();
    goto L_0DB92D;
L_0DB92D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB92D LSR
    cpu.lsrA();
    goto L_0DB92E;
L_0DB92E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB92E STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DB930;
L_0DB930:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB930u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB930u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB930u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB930 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB932;
L_0DB932:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB932u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB932u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB932u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB932 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DB934;
L_0DB934:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB934u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB934u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB934u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB934 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xB936u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB937u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DB934u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB937;
L_0DB937:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB937u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB937u,0x0DB937u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB937u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB937u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB937 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB939u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB93Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB937u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB93A;
L_0DB93A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB93Au,0x0DB93Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Au, 5u, 4u, ((0x0DB91Au + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB93A LDA
    cpu.loadA(hw.readW(((0xDB91Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB93E;
L_0DB93E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB93E STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_0DB940;
L_0DB940:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB940u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB940u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB940u, 4u + ((((0x1F29u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB940 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F29u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB943;
L_0DB943:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB943u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB943u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB943u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB943 BEQ -> $0DB94E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB94E; }
    goto L_0DB945;
L_0DB945:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB945u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB945u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB945u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB945 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xB947u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB948u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DB945u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB948;
L_0DB948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB948u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB948u,0x0DB948u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB948u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB948u, 5u, 4u, ((0x0DB91Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB948 LDA
    cpu.loadA(hw.readW(((0xDB91Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB94C;
L_0DB94C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB94C STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_0DB94E;
L_0DB94E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB94E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB950;
L_0DB950:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB950u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB950u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB950u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB950 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB952u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB953u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB950u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB953;
L_0DB953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB953u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB953u,0x0DB953u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB953u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB953u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB953 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DB955;
L_0DB955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB955u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB955u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB955 BPL -> $0DB937
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB937; }
    goto L_0DB957;
L_0DB957:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB957u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB957u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB957u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB957 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xB959u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB95Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DB957u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB95A;
L_0DB95A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB95Au,0x0DB95Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Au, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB95A JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xB95Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB95Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DB95Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB95D;
L_0DB95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB95Du,0x0DB95Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Du,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB95D DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DB95F;
L_0DB95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB95F BPL -> $0DB930
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB930; }
    goto L_0DB961;
L_0DB961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB961 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB961u);return;} hw.unresolvedReturn(0x0DB961u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DCE94_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DCE94u: goto L_0DCE94;
    case 0x0DCE96u: goto L_0DCE96;
    case 0x0DCE98u: goto L_0DCE98;
    case 0x0DCE99u: goto L_0DCE99;
    case 0x0DCE9Bu: goto L_0DCE9B;
    case 0x0DCE9Cu: goto L_0DCE9C;
    case 0x0DCE9Fu: goto L_0DCE9F;
    case 0x0DCEA3u: goto L_0DCEA3;
    case 0x0DCEA5u: goto L_0DCEA5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DCE94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE94u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE94u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE94 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DCE96;
L_0DCE96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE96u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE96u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE96 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCE98;
L_0DCE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE98u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE98u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE98 SEC
    cpu.setFlag('C', true);
    goto L_0DCE99;
L_0DCE99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE99u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE99 SBC
    cpu.sbc(0x51u);
    goto L_0DCE9B;
L_0DCE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE9B TAX
    cpu.transfer("TAX");
    goto L_0DCE9C;
L_0DCE9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Cu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCE9C JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xCE9Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCE9Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DCE9Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCE9F;
L_0DCE9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE9Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE9Fu,0x0DCE9Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Fu, 5u, 4u, ((0x0DCE90u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE9F LDA
    cpu.loadA(hw.readW(((0xDCE90u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCEA3;
L_0DCEA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA3u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA3u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DCEA3 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DCEA5;
L_0DCEA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCEA5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DCEA5u);return;} hw.unresolvedReturn(0x0DCEA5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DDC61_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DDC61u: goto L_0DDC61;
    case 0x0DDC63u: goto L_0DDC63;
    case 0x0DDC65u: goto L_0DDC65;
    case 0x0DDC67u: goto L_0DDC67;
    case 0x0DDC69u: goto L_0DDC69;
    case 0x0DDC6Cu: goto L_0DDC6C;
    case 0x0DDC6Eu: goto L_0DDC6E;
    case 0x0DDC6Fu: goto L_0DDC6F;
    case 0x0DDC70u: goto L_0DDC70;
    case 0x0DDC71u: goto L_0DDC71;
    case 0x0DDC72u: goto L_0DDC72;
    case 0x0DDC74u: goto L_0DDC74;
    case 0x0DDC76u: goto L_0DDC76;
    case 0x0DDC79u: goto L_0DDC79;
    case 0x0DDC7Cu: goto L_0DDC7C;
    case 0x0DDC7Eu: goto L_0DDC7E;
    case 0x0DDC81u: goto L_0DDC81;
    case 0x0DDC82u: goto L_0DDC82;
    case 0x0DDC84u: goto L_0DDC84;
    case 0x0DDC86u: goto L_0DDC86;
    case 0x0DDC89u: goto L_0DDC89;
    case 0x0DDC8Bu: goto L_0DDC8B;
    case 0x0DDC8Eu: goto L_0DDC8E;
    case 0x0DDC90u: goto L_0DDC90;
    case 0x0DDC92u: goto L_0DDC92;
    case 0x0DDC95u: goto L_0DDC95;
    case 0x0DDC97u: goto L_0DDC97;
    case 0x0DDC9Au: goto L_0DDC9A;
    case 0x0DDC9Du: goto L_0DDC9D;
    case 0x0DDCA0u: goto L_0DDCA0;
    case 0x0DDCA2u: goto L_0DDCA2;
    case 0x0DDCA4u: goto L_0DDCA4;
    case 0x0DDCA6u: goto L_0DDCA6;
    case 0x0DDCA8u: goto L_0DDCA8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DDC61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC61u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC61u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC61 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DDC63;
L_0DDC63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC63u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC63 LDX
    cpu.setX(0x0u, 8);
    goto L_0DDC65;
L_0DDC65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC65u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC65u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC65 STX
    hw.write(cpu.address("dp", 0x2u), cpu.x, cpu.x8?8:16);
    goto L_0DDC67;
L_0DDC67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC67u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC67u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC67 STX
    hw.write(cpu.address("dp", 0x0u), cpu.x, cpu.x8?8:16);
    goto L_0DDC69;
L_0DDC69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC69u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC69u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC69 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xDC6Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC6Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DDC69u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC6C;
L_0DDC6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC6Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC6Cu,0x0DDC6Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC6Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC6Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC6C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDC6E;
L_0DDC6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC6Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC6Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC6E LSR
    cpu.lsrA();
    goto L_0DDC6F;
L_0DDC6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC6Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC6F LSR
    cpu.lsrA();
    goto L_0DDC70;
L_0DDC70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC70u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC70u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC70 LSR
    cpu.lsrA();
    goto L_0DDC71;
L_0DDC71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC71u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC71u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC71 LSR
    cpu.lsrA();
    goto L_0DDC72;
L_0DDC72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC72u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC72u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC72 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DDC74;
L_0DDC74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC74u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC74u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC74 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DDC76;
L_0DDC76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC76u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC76u, 3u, 3u, cpu.address("abs", 0xDC8Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC76 JMP -> $0DDC8E
    goto L_0DDC8E;
L_0DDC79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC79u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC79u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC79 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDC7Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC7Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDC79u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC7C;
L_0DDC7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC7Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC7Cu,0x0DDC7Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC7Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC7C LDA
    cpu.setA(0xFFu, 8);
    goto L_0DDC7E;
L_0DDC7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC7Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC7Eu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC7E JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xDC80u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC81u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DDC7Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC81;
L_0DDC81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC81u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC81u,0x0DDC81u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC81u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC81u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC81 DEX
    cpu.decReg('X');
    goto L_0DDC82;
L_0DDC82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC82u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC82 CPX
    cpu.compareX(0x1u);
    goto L_0DDC84;
L_0DDC84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC84u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC84 BNE -> $0DDC79
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DDC79; }
    goto L_0DDC86;
L_0DDC86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC86u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC86u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC86 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDC88u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC89u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDC86u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC89;
L_0DDC89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC89u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC89u,0x0DDC89u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC89 LDA
    cpu.setA(0xFEu, 8);
    goto L_0DDC8B;
L_0DDC8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC8Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC8Bu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC8B JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xDC8Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC8Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DDC8Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC8E;
L_0DDC8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC8Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC8Eu,0x0DDC8Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC8Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC8Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC8E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDC90;
L_0DDC90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC90u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC90 BEQ -> $0DDCA8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DDCA8; }
    goto L_0DDC92;
L_0DDC92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC92u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC92u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC92 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDC94u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC95u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDC92u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC95;
L_0DDC95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC95u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC95u,0x0DDC95u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC95u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC95u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC95 LDA
    cpu.setA(0xD7u, 8);
    goto L_0DDC97;
L_0DDC97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC97u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC97u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC97 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xDC99u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC9Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DDC97u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC9A;
L_0DDC9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC9Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC9Au,0x0DDC9Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Au, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC9A JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xDC9Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC9Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DDC9Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC9D;
L_0DDC9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC9Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC9Du,0x0DDC9Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Du, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC9D JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xDC9Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDCA0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DDC9Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDCA0;
L_0DDCA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDCA0u,0x0DDCA0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA0u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDCA0 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DDCA2;
L_0DDCA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA2u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDCA2 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DDCA4;
L_0DDCA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA4u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDCA4 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DDCA6;
L_0DDCA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDCA6 BPL -> $0DDC82
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DDC82; }
    goto L_0DDCA8;
L_0DDCA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDCA8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DDCA8u);return;} hw.unresolvedReturn(0x0DDCA8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DE890_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DE890u: goto L_0DE890;
    case 0x0DE892u: goto L_0DE892;
    case 0x0DE894u: goto L_0DE894;
    case 0x0DE895u: goto L_0DE895;
    case 0x0DE896u: goto L_0DE896;
    case 0x0DE89Au: goto L_0DE89A;
    case 0x0DE89Cu: goto L_0DE89C;
    case 0x0DE89Fu: goto L_0DE89F;
    case 0x0DE8A2u: goto L_0DE8A2;
    case 0x0DE8A5u: goto L_0DE8A5;
    case 0x0DE8A8u: goto L_0DE8A8;
    case 0x0DE8ABu: goto L_0DE8AB;
    case 0x0DE8AEu: goto L_0DE8AE;
    case 0x0DE8B1u: goto L_0DE8B1;
    case 0x0DE8B4u: goto L_0DE8B4;
    case 0x0DE8B7u: goto L_0DE8B7;
    case 0x0DE8BAu: goto L_0DE8BA;
    case 0x0DE8BDu: goto L_0DE8BD;
    case 0x0DE8C0u: goto L_0DE8C0;
    case 0x0DE8C3u: goto L_0DE8C3;
    case 0x0DE8C6u: goto L_0DE8C6;
    case 0x0DE8C9u: goto L_0DE8C9;
    case 0x0DE8CCu: goto L_0DE8CC;
    case 0x0DE8CFu: goto L_0DE8CF;
    case 0x0DE8D2u: goto L_0DE8D2;
    case 0x0DE8D5u: goto L_0DE8D5;
    case 0x0DE8D8u: goto L_0DE8D8;
    case 0x0DE8DBu: goto L_0DE8DB;
    case 0x0DE8DEu: goto L_0DE8DE;
    case 0x0DE8E1u: goto L_0DE8E1;
    case 0x0DE8E4u: goto L_0DE8E4;
    case 0x0DE8E7u: goto L_0DE8E7;
    case 0x0DE8EAu: goto L_0DE8EA;
    case 0x0DE8EDu: goto L_0DE8ED;
    case 0x0DE8F0u: goto L_0DE8F0;
    case 0x0DE8F3u: goto L_0DE8F3;
    case 0x0DE8F6u: goto L_0DE8F6;
    case 0x0DE8F9u: goto L_0DE8F9;
    case 0x0DE8FCu: goto L_0DE8FC;
    case 0x0DE8FFu: goto L_0DE8FF;
    case 0x0DE902u: goto L_0DE902;
    case 0x0DE905u: goto L_0DE905;
    case 0x0DE908u: goto L_0DE908;
    case 0x0DE90Bu: goto L_0DE90B;
    case 0x0DE90Eu: goto L_0DE90E;
    case 0x0DE911u: goto L_0DE911;
    case 0x0DE914u: goto L_0DE914;
    case 0x0DE917u: goto L_0DE917;
    case 0x0DE91Au: goto L_0DE91A;
    case 0x0DE91Du: goto L_0DE91D;
    case 0x0DE920u: goto L_0DE920;
    case 0x0DE923u: goto L_0DE923;
    case 0x0DE926u: goto L_0DE926;
    case 0x0DE929u: goto L_0DE929;
    case 0x0DE92Cu: goto L_0DE92C;
    case 0x0DE92Fu: goto L_0DE92F;
    case 0x0DE932u: goto L_0DE932;
    case 0x0DE935u: goto L_0DE935;
    case 0x0DE938u: goto L_0DE938;
    case 0x0DE93Bu: goto L_0DE93B;
    case 0x0DE93Eu: goto L_0DE93E;
    case 0x0DE941u: goto L_0DE941;
    case 0x0DE944u: goto L_0DE944;
    case 0x0DE947u: goto L_0DE947;
    case 0x0DE94Au: goto L_0DE94A;
    case 0x0DE94Du: goto L_0DE94D;
    case 0x0DE950u: goto L_0DE950;
    case 0x0DE953u: goto L_0DE953;
    case 0x0DE956u: goto L_0DE956;
    case 0x0DE959u: goto L_0DE959;
    case 0x0DE95Bu: goto L_0DE95B;
    case 0x0DE95Du: goto L_0DE95D;
    case 0x0DE95Fu: goto L_0DE95F;
    case 0x0DE961u: goto L_0DE961;
    case 0x0DE963u: goto L_0DE963;
    case 0x0DE964u: goto L_0DE964;
    case 0x0DE966u: goto L_0DE966;
    case 0x0DE967u: goto L_0DE967;
    case 0x0DE96Au: goto L_0DE96A;
    case 0x0DE96Eu: goto L_0DE96E;
    case 0x0DE970u: goto L_0DE970;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DE890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE890u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE890u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE890u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE890 SEP
    cpu.sep(0x30u);
    goto L_0DE892;
L_0DE892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE892u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE892u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE892 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DE894;
L_0DE894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE894u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE894u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE894 DEX
    cpu.decReg('X');
    goto L_0DE895;
L_0DE895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE895u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE895u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE895u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE895 TXA
    cpu.transfer("TXA");
    goto L_0DE896;
L_0DE896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE896u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE896u, 8u, 4u, 0x0086FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0DE896 JSL -> $0086FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE899u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE89Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086FAu, 0x0DE896u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE89A;
L_0DE89A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE89Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE89Au,0x0DE89Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE89Au,cpu,0xC3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE89Au, 4u, 2u, cpu.addressStack(0xA8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE89A CMP
    cpu.compareA(hw.readW(cpu.addressStack(0xA8u), cpu.m8?8:16));
    goto L_0DE89C;
L_0DE89C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE89Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE89Cu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE89Cu, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE89C ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DE89F;
L_0DE89F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE89Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE89Fu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE89Fu, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE89F ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DE8A2;
L_0DE8A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8A2u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8A2u, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8A2 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DE8A5;
L_0DE8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8A5u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8A5u, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8A5 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DE8A8;
L_0DE8A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8A8u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8A8u, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8A8 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DE8AB;
L_0DE8AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8ABu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8ABu, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8AB ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DE8AE;
L_0DE8AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8AEu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8AEu, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8AE ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DE8B1;
L_0DE8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8B1u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8B1u, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8B1 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DE8B4;
L_0DE8B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8B4u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8B4u, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8B4 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DE8B7;
L_0DE8B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8B7u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8B7u, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8B7 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DE8BA;
L_0DE8BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8BAu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8BAu, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8BA ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DE8BD;
L_0DE8BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8BDu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8BDu, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8BD ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DE8C0;
L_0DE8C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8C0u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8C0u, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8C0 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DE8C3;
L_0DE8C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8C3u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8C3u, 4u, 3u, cpu.address("abs", 0xAA26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8C3 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xAA26u), cpu.m8?8:16));
    goto L_0DE8C6;
L_0DE8C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8C6u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8C6u, 4u, 3u, cpu.address("abs", 0xAAB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8C6 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xAAB4u), cpu.m8?8:16));
    goto L_0DE8C9;
L_0DE8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8C9u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8C9u, 4u, 3u, cpu.address("abs", 0xAB0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8C9 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xAB0Du), cpu.m8?8:16));
    goto L_0DE8CC;
L_0DE8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8CCu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8CCu, 4u, 3u, cpu.address("abs", 0xAB3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8CC ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xAB3Eu), cpu.m8?8:16));
    goto L_0DE8CF;
L_0DE8CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8CFu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8CFu, 4u, 3u, cpu.address("abs", 0xB075u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8CF ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB075u), cpu.m8?8:16));
    goto L_0DE8D2;
L_0DE8D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8D2u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8D2u, 4u, 3u, cpu.address("abs", 0xB1D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8D2 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB1D4u), cpu.m8?8:16));
    goto L_0DE8D5;
L_0DE8D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8D5u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8D5u, 4u, 3u, cpu.address("abs", 0xB224u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8D5 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB224u), cpu.m8?8:16));
    goto L_0DE8D8;
L_0DE8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8D8u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8D8u, 4u, 3u, cpu.address("abs", 0xB336u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8D8 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB336u), cpu.m8?8:16));
    goto L_0DE8DB;
L_0DE8DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8DBu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8DBu, 4u, 3u, cpu.address("abs", 0xB3BDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8DB ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3BDu), cpu.m8?8:16));
    goto L_0DE8DE;
L_0DE8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8DEu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8DEu, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8DE ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE8E1;
L_0DE8E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8E1u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8E1u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8E1 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE8E4;
L_0DE8E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8E4u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8E4u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8E4 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE8E7;
L_0DE8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8E7u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8E7u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8E7 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE8EA;
L_0DE8EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8EAu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8EAu, 4u, 3u, cpu.address("abs", 0xB42Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8EA ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB42Du), cpu.m8?8:16));
    goto L_0DE8ED;
L_0DE8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8EDu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8EDu, 4u, 3u, cpu.address("abs", 0xB461u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8ED ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB461u), cpu.m8?8:16));
    goto L_0DE8F0;
L_0DE8F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8F0u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8F0u, 4u, 3u, cpu.address("abs", 0xB49Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8F0 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB49Eu), cpu.m8?8:16));
    goto L_0DE8F3;
L_0DE8F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8F3u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8F3u, 4u, 3u, cpu.address("abs", 0xB51Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8F3 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB51Fu), cpu.m8?8:16));
    goto L_0DE8F6;
L_0DE8F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8F6u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8F6u, 4u, 3u, cpu.address("abs", 0xB547u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8F6 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB547u), cpu.m8?8:16));
    goto L_0DE8F9;
L_0DE8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8F9u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8F9u, 4u, 3u, cpu.address("abs", 0xB1C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8F9 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB1C8u), cpu.m8?8:16));
    goto L_0DE8FC;
L_0DE8FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8FCu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8FCu, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8FC ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE8FF;
L_0DE8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE8FFu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE8FFu, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE8FF ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE902;
L_0DE902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE902u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE902u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE902 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE905;
L_0DE905:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE905u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE905u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE905u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE905 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE908;
L_0DE908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE908u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE908u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE908 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE90B;
L_0DE90B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE90Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE90Bu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE90Bu, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE90B ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE90E;
L_0DE90E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE90Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE90Eu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE90Eu, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE90E ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE911;
L_0DE911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE911u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE911u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE911 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE914;
L_0DE914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE914u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE914u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE914u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE914 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE917;
L_0DE917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE917u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE917u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE917u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE917 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE91A;
L_0DE91A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE91Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE91Au,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE91Au, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE91A ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE91D;
L_0DE91D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE91Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE91Du,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE91Du, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE91D ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DE920;
L_0DE920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE920u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE920u, 4u, 3u, cpu.address("abs", 0xF06Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE920 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xF06Cu), cpu.m8?8:16));
    goto L_0DE923;
L_0DE923:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE923u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE923u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE923u, 4u, 3u, cpu.address("abs", 0xF066u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE923 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xF066u), cpu.m8?8:16));
    goto L_0DE926;
L_0DE926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE926u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE926u, 4u, 3u, cpu.address("abs", 0xF02Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE926 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xF02Bu), cpu.m8?8:16));
    goto L_0DE929;
L_0DE929:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE929u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE929u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE929u, 4u, 3u, cpu.address("abs", 0xEFA8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE929 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xEFA8u), cpu.m8?8:16));
    goto L_0DE92C;
L_0DE92C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE92Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE92Cu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE92Cu, 4u, 3u, cpu.address("abs", 0xEF67u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE92C ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xEF67u), cpu.m8?8:16));
    goto L_0DE92F;
L_0DE92F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE92Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE92Fu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE92Fu, 4u, 3u, cpu.address("abs", 0xEF45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE92F ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xEF45u), cpu.m8?8:16));
    goto L_0DE932;
L_0DE932:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE932u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE932u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE932u, 4u, 3u, cpu.address("abs", 0xEEC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE932 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xEEC0u), cpu.m8?8:16));
    goto L_0DE935;
L_0DE935:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE935u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE935u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE935u, 4u, 3u, cpu.address("abs", 0xECC9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE935 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xECC9u), cpu.m8?8:16));
    goto L_0DE938;
L_0DE938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE938u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE938u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE938u, 4u, 3u, cpu.address("abs", 0xECC9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE938 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xECC9u), cpu.m8?8:16));
    goto L_0DE93B;
L_0DE93B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE93Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE93Bu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE93Bu, 4u, 3u, cpu.address("abs", 0xED12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE93B ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xED12u), cpu.m8?8:16));
    goto L_0DE93E;
L_0DE93E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE93Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE93Eu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE93Eu, 4u, 3u, cpu.address("abs", 0xED43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE93E ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xED43u), cpu.m8?8:16));
    goto L_0DE941;
L_0DE941:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE941u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE941u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE941u, 4u, 3u, cpu.address("abs", 0xED6Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE941 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xED6Bu), cpu.m8?8:16));
    goto L_0DE944;
L_0DE944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE944u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE944u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE944u, 4u, 3u, cpu.address("abs", 0xED99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE944 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xED99u), cpu.m8?8:16));
    goto L_0DE947;
L_0DE947:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE947u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE947u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE947u, 4u, 3u, cpu.address("abs", 0xEDB9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE947 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xEDB9u), cpu.m8?8:16));
    goto L_0DE94A;
L_0DE94A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE94Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE94Au,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE94Au, 4u, 3u, cpu.address("abs", 0xEDDBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE94A ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xEDDBu), cpu.m8?8:16));
    goto L_0DE94D;
L_0DE94D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE94Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE94Du,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE94Du, 4u, 3u, cpu.address("abs", 0xEE17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE94D ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xEE17u), cpu.m8?8:16));
    goto L_0DE950;
L_0DE950:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE950u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE950u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE950u, 4u, 3u, cpu.address("abs", 0xEE52u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE950 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xEE52u), cpu.m8?8:16));
    goto L_0DE953;
L_0DE953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE953u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE953u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE953u, 4u, 3u, cpu.address("abs", 0xEE89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE953 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xEE89u), cpu.m8?8:16));
    goto L_0DE956;
L_0DE956:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE956u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE956u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE956u, 4u, 3u, cpu.address("abs", 0x7473u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE956 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x7473u), cpu.m8?8:16));
    goto L_0DE959;
L_0DE959:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE959u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE959u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE959u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE959 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x76u), cpu.m8?8:16));
    goto L_0DE95B;
L_0DE95B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE95Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE95Bu,cpu,0x93u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE95Bu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x94u) & 0xFFFFu), 2u, 0u);
    // $0DE95B STA
    hw.write(cpu.addressStackIndirectY(hw, 0x94u), cpu.a, cpu.m8?8:16);
    goto L_0DE95D;
L_0DE95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE95Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE95Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE95D STA
    hw.write(cpu.address("dpx", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_0DE95F;
L_0DE95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE95Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE95Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE95F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DE961;
L_0DE961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE961u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE961u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE961 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DE963;
L_0DE963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE963u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE963u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE963 SEC
    cpu.setFlag('C', true);
    goto L_0DE964;
L_0DE964:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE964u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE964u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE964u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE964 SBC
    cpu.sbc(0x57u);
    goto L_0DE966;
L_0DE966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE966 TAX
    cpu.transfer("TAX");
    goto L_0DE967;
L_0DE967:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE967u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE967u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE967u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE967 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xE969u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE96Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DE967u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE96A;
L_0DE96A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE96Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE96Au,0x0DE96Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Au, 5u, 4u, ((0x0DE957u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE96A LDA
    cpu.loadA(hw.readW(((0xDE957u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DE96E;
L_0DE96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Eu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DE96E STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DE970;
L_0DE970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE970u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE970u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE970 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DE970u);return;} hw.unresolvedReturn(0x0DE970u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0E8DAE_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0E8DAEu: goto L_0E8DAE;
    case 0x0E8DB1u: goto L_0E8DB1;
    case 0x0E8DB5u: goto L_0E8DB5;
    case 0x0E8DB7u: goto L_0E8DB7;
    case 0x0E8DB8u: goto L_0E8DB8;
    case 0x0E8DBCu: goto L_0E8DBC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0E8DAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAEu,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAEu, 4u + ((((0x7D6Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x7D6Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DAE EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0x7D6Du), cpu.m8?8:16));
    goto L_0E8DB1;
L_0E8DB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB1u, 5u, 4u, ((0x241708u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DB1 SBC
    cpu.sbc(hw.readW(((0x241708u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0E8DB5;
L_0E8DB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB5u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DB5 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), false);
    goto L_0E8DB7;
L_0E8DB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB7u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0E8DB7 PHP
    cpu.push("PHP", hw);
    goto L_0E8DB8;
L_0E8DB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB8u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB8u, 5u, 4u, ((0x00007Fu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DB8 SBC
    cpu.sbc(hw.readW(((0x7Fu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0E8DBC;
L_0E8DBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBCu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBCu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0E8DBC BRK
    hw.partial(0x0E8DBCu, "BRK"); return;
}

void sub_6080FD_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x6080FDu: goto L_6080FD;
    case 0x6080FFu: goto L_6080FF;
    case 0x608102u: goto L_608102;
    case 0x608104u: goto L_608104;
    case 0x608107u: goto L_608107;
    case 0x608109u: goto L_608109;
    case 0x60810Cu: goto L_60810C;
    case 0x60811Du: goto L_60811D;
    case 0x60811Fu: goto L_60811F;
    case 0x608122u: goto L_608122;
    case 0x608125u: goto L_608125;
    case 0x608127u: goto L_608127;
    case 0x60812Au: goto L_60812A;
    case 0x60812Du: goto L_60812D;
    case 0x608130u: goto L_608130;
    case 0x608131u: goto L_608131;
    case 0x608133u: goto L_608133;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_6080FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6080FD LDA
    cpu.setA(0x0u, 8);
    goto L_6080FF;
L_6080FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FFu, 4u, 3u, cpu.address("abs", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6080FF STA
    hw.write(cpu.address("abs", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_608102;
L_608102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8102u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8102u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608102 LDA
    cpu.setA(0x80u, 8);
    goto L_608104;
L_608104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8104u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8104u, 4u, 3u, cpu.address("abs", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608104 STA
    hw.write(cpu.address("abs", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_608107;
L_608107:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8107u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8107u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8107u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608107 LDA
    cpu.setA(0xFu, 8);
    goto L_608109;
L_608109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u, 4u, 3u, cpu.address("abs", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608109 STA
    hw.write(cpu.address("abs", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_60810C;
L_60810C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60810C BRA -> $60811D
    goto L_60811D;
L_60811D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60811D LDA
    cpu.setA(0xFFu, 8);
    goto L_60811F;
L_60811F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60811F STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_608122;
L_608122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u, 6u, 3u, cpu.address("abs", 0x80F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $608122 JSR -> $6080F7 stack real
    { cpu.push16Value(hw,0x8124u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8125u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80F7u), 0x608122u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_608125;
L_608125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8125u,0x608125u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608125 LDX
    cpu.setX(0x3u, 8);
    goto L_608127;
L_608127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u, 5u, 3u, cpu.address("absx", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608127 STZ
    hw.write(cpu.address("absx", 0x2140u), 0, cpu.m8?8:16);
    goto L_60812A;
L_60812A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au, 5u, 3u, cpu.address("absx", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60812A STZ
    hw.write(cpu.address("absx", 0x1DF9u), 0, cpu.m8?8:16);
    goto L_60812D;
L_60812D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du, 5u, 3u, cpu.address("absx", 0x1DFDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60812D STZ
    hw.write(cpu.address("absx", 0x1DFDu), 0, cpu.m8?8:16);
    goto L_608130;
L_608130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608130 DEX
    cpu.decReg('X');
    goto L_608131;
L_608131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608131 BPL -> $608127
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_608127; }
    goto L_608133;
L_608133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $608133 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x608133u);return;} hw.unresolvedReturn(0x608133u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_608134_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x60811Du: goto L_60811D;
    case 0x60811Fu: goto L_60811F;
    case 0x608122u: goto L_608122;
    case 0x608125u: goto L_608125;
    case 0x608127u: goto L_608127;
    case 0x60812Au: goto L_60812A;
    case 0x60812Du: goto L_60812D;
    case 0x608130u: goto L_608130;
    case 0x608131u: goto L_608131;
    case 0x608133u: goto L_608133;
    case 0x608134u: goto L_608134;
    case 0x608137u: goto L_608137;
    case 0x608139u: goto L_608139;
    case 0x60813Cu: goto L_60813C;
    case 0x60813Eu: goto L_60813E;
    case 0x608140u: goto L_608140;
    case 0x608143u: goto L_608143;
    case 0x608146u: goto L_608146;
    case 0x608148u: goto L_608148;
    case 0x60814Au: goto L_60814A;
    case 0x60814Du: goto L_60814D;
    case 0x60814Fu: goto L_60814F;
    case 0x608152u: goto L_608152;
    case 0x608154u: goto L_608154;
    case 0x608157u: goto L_608157;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_60811D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60811D LDA
    cpu.setA(0xFFu, 8);
    goto L_60811F;
L_60811F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60811F STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_608122;
L_608122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u, 6u, 3u, cpu.address("abs", 0x80F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $608122 JSR -> $6080F7 stack real
    { cpu.push16Value(hw,0x8124u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8125u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80F7u), 0x608122u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_608125;
L_608125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8125u,0x608125u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608125 LDX
    cpu.setX(0x3u, 8);
    goto L_608127;
L_608127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u, 5u, 3u, cpu.address("absx", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608127 STZ
    hw.write(cpu.address("absx", 0x2140u), 0, cpu.m8?8:16);
    goto L_60812A;
L_60812A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au, 5u, 3u, cpu.address("absx", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60812A STZ
    hw.write(cpu.address("absx", 0x1DF9u), 0, cpu.m8?8:16);
    goto L_60812D;
L_60812D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du, 5u, 3u, cpu.address("absx", 0x1DFDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60812D STZ
    hw.write(cpu.address("absx", 0x1DFDu), 0, cpu.m8?8:16);
    goto L_608130;
L_608130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608130 DEX
    cpu.decReg('X');
    goto L_608131;
L_608131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608131 BPL -> $608127
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_608127; }
    goto L_608133;
L_608133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $608133 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x608133u);return;} hw.unresolvedReturn(0x608133u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_608134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8134u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8134u, 4u, 3u, cpu.address("abs", 0x1425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608134 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1425u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_608137;
L_608137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8137u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8137u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608137 BNE -> $608148
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_608148; }
    goto L_608139;
L_608139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8139u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8139u, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608139 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_60813C;
L_60813C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60813C CMP
    cpu.compareA(0xE9u);
    goto L_60813E;
L_60813E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60813E BEQ -> $608148
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_608148; }
    goto L_608140;
L_608140:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8140u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8140u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8140u, 4u, 3u, cpu.address("abs", 0x141Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608140 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x141Au), cpu.m8?8:16));
    goto L_608143;
L_608143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8143u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8143u, 4u, 3u, cpu.address("abs", 0x141Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608143 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x141Du), cpu.m8?8:16));
    goto L_608146;
L_608146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8146u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8146u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608146 BNE -> $608133
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_608133; }
    goto L_608148;
L_608148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8148u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8148u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608148 LDA
    cpu.setA(0xD6u, 8);
    goto L_60814A;
L_60814A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Au, 4u, 3u, cpu.address("abs", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60814A STA
    hw.write(cpu.address("abs", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_60814D;
L_60814D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60814D LDA
    cpu.setA(0xAEu, 8);
    goto L_60814F;
L_60814F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Fu, 4u, 3u, cpu.address("abs", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60814F STA
    hw.write(cpu.address("abs", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_608152;
L_608152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8152u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8152u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608152 LDA
    cpu.setA(0xEu, 8);
    goto L_608154;
L_608154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8154u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8154u, 4u, 3u, cpu.address("abs", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608154 STA
    hw.write(cpu.address("abs", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_608157;
L_608157:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8157u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8157u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8157u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608157 BRA -> $60811D
    goto L_60811D;
}

void sub_E49885_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xE49885u: goto L_E49885;
    case 0xE49887u: goto L_E49887;
    case 0xE4988Au: goto L_E4988A;
    case 0xE4988Cu: goto L_E4988C;
    case 0xE4988Eu: goto L_E4988E;
    case 0xE49891u: goto L_E49891;
    case 0xE49892u: goto L_E49892;
    case 0xE49893u: goto L_E49893;
    case 0xE49894u: goto L_E49894;
    case 0xE49895u: goto L_E49895;
    case 0xE49897u: goto L_E49897;
    case 0xE49899u: goto L_E49899;
    case 0xE4989Bu: goto L_E4989B;
    case 0xE4989Cu: goto L_E4989C;
    case 0xE4989Du: goto L_E4989D;
    case 0xE4989Eu: goto L_E4989E;
    case 0xE4989Fu: goto L_E4989F;
    case 0xE498A2u: goto L_E498A2;
    case 0xE498A4u: goto L_E498A4;
    case 0xE498A6u: goto L_E498A6;
    case 0xE498A8u: goto L_E498A8;
    case 0xE498ABu: goto L_E498AB;
    case 0xE498ADu: goto L_E498AD;
    case 0xE498AFu: goto L_E498AF;
    case 0xE498B0u: goto L_E498B0;
    case 0xE498B3u: goto L_E498B3;
    case 0xE498B5u: goto L_E498B5;
    case 0xE498B8u: goto L_E498B8;
    case 0xE498BBu: goto L_E498BB;
    case 0xE498BDu: goto L_E498BD;
    case 0xE498BFu: goto L_E498BF;
    case 0xE498C0u: goto L_E498C0;
    case 0xE498C3u: goto L_E498C3;
    case 0xE498C5u: goto L_E498C5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_E49885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9885u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9885u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E49885 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E49887;
L_E49887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9887u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9887u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E49887 AND
    cpu.logicAnd(0xFu);
    goto L_E4988A;
L_E4988A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4988A STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_E4988C;
L_E4988C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4988C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4988E;
L_E4988E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4988E AND
    cpu.logicAnd(0x10u);
    goto L_E49891;
L_E49891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9891u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9891u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E49891 ASL
    cpu.aslA();
    goto L_E49892;
L_E49892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9892u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9892u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E49892 ASL
    cpu.aslA();
    goto L_E49893;
L_E49893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9893u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9893u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E49893 ASL
    cpu.aslA();
    goto L_E49894;
L_E49894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E49894 ASL
    cpu.aslA();
    goto L_E49895;
L_E49895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9895u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9895u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9895u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E49895 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_E49897;
L_E49897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9897u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9897u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E49897 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_E49899;
L_E49899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9899u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9899u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E49899 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4989B;
L_E4989B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4989B ASL
    cpu.aslA();
    goto L_E4989C;
L_E4989C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4989C ASL
    cpu.aslA();
    goto L_E4989D;
L_E4989D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4989D ASL
    cpu.aslA();
    goto L_E4989E;
L_E4989E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4989E ASL
    cpu.aslA();
    goto L_E4989F;
L_E4989F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4989F AND
    cpu.logicAnd(0xFFu);
    goto L_E498A2;
L_E498A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A2u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498A2 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_E498A4;
L_E498A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498A4 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_E498A6;
L_E498A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E498A8;
L_E498A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498A8 AND
    cpu.logicAnd(0x10u);
    goto L_E498AB;
L_E498AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ABu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498AB BEQ -> $E498B5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_E498B5; }
    goto L_E498AD;
L_E498AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E498AF;
L_E498AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98AFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498AF CLC
    cpu.setFlag('C', false);
    goto L_E498B0;
L_E498B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498B0 ADC
    cpu.adc(0x200u);
    goto L_E498B3;
L_E498B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498B3 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_E498B5;
L_E498B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B5u, 5u + ((((0x1F11u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498B5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E498B8;
L_E498B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498B8 AND
    cpu.logicAnd(0xFFu);
    goto L_E498BB;
L_E498BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498BB BEQ -> $E498C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_E498C5; }
    goto L_E498BD;
L_E498BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498BD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E498BF;
L_E498BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498BF CLC
    cpu.setFlag('C', false);
    goto L_E498C0;
L_E498C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498C0 ADC
    cpu.adc(0x400u);
    goto L_E498C3;
L_E498C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E498C3 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_E498C5;
L_E498C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E498C5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xE498C5u);return;} hw.unresolvedReturn(0xE498C5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

