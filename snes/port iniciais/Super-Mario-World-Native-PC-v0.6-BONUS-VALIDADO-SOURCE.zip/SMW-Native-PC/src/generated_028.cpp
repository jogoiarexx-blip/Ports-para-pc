#include "generated.hpp"
void sub_0093FD_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0093FDu: goto L_0093FD;
    case 0x009400u: goto L_009400;
    case 0x009402u: goto L_009402;
    case 0x009405u: goto L_009405;
    case 0x009408u: goto L_009408;
    case 0x00940Bu: goto L_00940B;
    case 0x00940Eu: goto L_00940E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0093FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FDu, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093FD STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_009400;
L_009400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9400u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9400u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x40u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009400 STA
    hw.write(cpu.address("dp", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_009402;
L_009402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9402u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9402u, 4u, 3u, cpu.address("abs", 0x212Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009402 STX
    hw.write(cpu.address("abs", 0x212Cu), cpu.x, cpu.x8?8:16);
    goto L_009405;
L_009405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9405u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9405u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9405u, 4u, 3u, cpu.address("abs", 0x212Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009405 STY
    hw.write(cpu.address("abs", 0x212Du), cpu.y, cpu.x8?8:16);
    goto L_009408;
L_009408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9408u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9408u, 4u, 3u, cpu.address("abs", 0x212Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009408 STZ
    hw.write(cpu.address("abs", 0x212Eu), 0, cpu.m8?8:16);
    goto L_00940B;
L_00940B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x940Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x940Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x940Bu, 4u, 3u, cpu.address("abs", 0x212Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00940B STZ
    hw.write(cpu.address("abs", 0x212Fu), 0, cpu.m8?8:16);
    goto L_00940E;
L_00940E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x940Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x940Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x940Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00940E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00940Eu);return;} hw.unresolvedReturn(0x00940Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_009468_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0094E2u: goto L_0094E2;
    case 0x0094E4u: goto L_0094E4;
    case 0x0094E5u: goto L_0094E5;
    case 0x0094E7u: goto L_0094E7;
    case 0x0094E9u: goto L_0094E9;
    case 0x0094EBu: goto L_0094EB;
    case 0x0094EEu: goto L_0094EE;
    case 0x0094F0u: goto L_0094F0;
    case 0x0094F2u: goto L_0094F2;
    case 0x0094F6u: goto L_0094F6;
    case 0x0094F8u: goto L_0094F8;
    case 0x0094FAu: goto L_0094FA;
    case 0x0094FDu: goto L_0094FD;
    case 0x009501u: goto L_009501;
    case 0x009504u: goto L_009504;
    case 0x009506u: goto L_009506;
    case 0x009508u: goto L_009508;
    case 0x00950Au: goto L_00950A;
    case 0x00950Cu: goto L_00950C;
    case 0x00950Eu: goto L_00950E;
    case 0x009510u: goto L_009510;
    case 0x009512u: goto L_009512;
    case 0x009514u: goto L_009514;
    case 0x009516u: goto L_009516;
    case 0x009519u: goto L_009519;
    case 0x00951Au: goto L_00951A;
    case 0x00951Cu: goto L_00951C;
    case 0x00951Eu: goto L_00951E;
    case 0x009520u: goto L_009520;
    case 0x009523u: goto L_009523;
    case 0x009525u: goto L_009525;
    case 0x009528u: goto L_009528;
    case 0x009529u: goto L_009529;
    case 0x00952Du: goto L_00952D;
    case 0x00952Fu: goto L_00952F;
    case 0x009531u: goto L_009531;
    case 0x009532u: goto L_009532;
    case 0x009534u: goto L_009534;
    case 0x009535u: goto L_009535;
    case 0x009537u: goto L_009537;
    case 0x009539u: goto L_009539;
    case 0x00953Bu: goto L_00953B;
    case 0x00953Du: goto L_00953D;
    case 0x00953Fu: goto L_00953F;
    case 0x009543u: goto L_009543;
    case 0x009545u: goto L_009545;
    case 0x009546u: goto L_009546;
    case 0x009548u: goto L_009548;
    case 0x009549u: goto L_009549;
    case 0x00954Bu: goto L_00954B;
    case 0x00954Du: goto L_00954D;
    case 0x00954Fu: goto L_00954F;
    case 0x009551u: goto L_009551;
    case 0x009554u: goto L_009554;
    case 0x009557u: goto L_009557;
    case 0x00955Bu: goto L_00955B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0094E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E2u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094E2 STZ
    hw.write(cpu.address("dpx", 0x1Au), 0, cpu.m8?8:16);
    goto L_0094E4;
L_0094E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E4u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094E4 DEX
    cpu.decReg('X');
    goto L_0094E5;
L_0094E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094E5 BPL -> $0094E2
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0094E2; }
    goto L_0094E7;
L_0094E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094E7 LDA
    cpu.setA(0x20u, 8);
    goto L_0094E9;
L_0094E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094E9 STA
    hw.write(cpu.address("dp", 0x64u), cpu.a, cpu.m8?8:16);
    goto L_0094EB;
L_0094EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EBu, 6u, 3u, cpu.address("abs", 0xA635u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0094EB JSR -> $00A635 stack real
    { cpu.push16Value(hw,0x94EDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94EEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA635u), 0x0094EBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0094EE;
L_0094EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94EEu,0x0094EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094EE STZ
    hw.write(cpu.address("dp", 0x76u), 0, cpu.m8?8:16);
    goto L_0094F0;
L_0094F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094F0 STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_0094F2;
L_0094F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F2u, 8u, 4u, 0x00CEB1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0094F2 JSL -> $00CEB1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x94F5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94F6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00CEB1u, 0x0094F2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0094F6;
L_0094F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94F6u,0x0094F6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094F6 LDX
    cpu.setX(0x17u, 8);
    goto L_0094F8;
L_0094F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094F8 LDY
    cpu.setY(0x0u, 8);
    goto L_0094FA;
L_0094FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FAu, 6u, 3u, cpu.address("abs", 0x9622u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0094FA JSR -> $009622 stack real
    { cpu.push16Value(hw,0x94FCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94FDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9622u), 0x0094FAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0094FD;
L_0094FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94FDu,0x0094FDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FDu, 8u, 4u, 0x7F8000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0094FD JSL -> $7F8000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9500u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9501u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x7F8000u, 0x0094FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009501;
L_009501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9501u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9501u,0x009501u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9501u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9501u, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009501 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009504;
L_009504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009504 CMP
    cpu.compareA(0x8u);
    goto L_009506;
L_009506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009506 BEQ -> $009557
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_009557; }
    goto L_009508;
L_009508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9508u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9508u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009508 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00950A;
L_00950A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00950A AND
    cpu.logicAnd(0x0u);
    goto L_00950C;
L_00950C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00950C CMP
    cpu.compareA(0x30u);
    goto L_00950E;
L_00950E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00950E BNE -> $009529
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009529; }
    goto L_009510;
L_009510:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9510u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9510u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009510 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009512;
L_009512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9512u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009512 AND
    cpu.logicAnd(0x8u);
    goto L_009514;
L_009514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9514u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9514u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009514 BEQ -> $009523
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_009523; }
    goto L_009516;
L_009516:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9516u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9516u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9516u, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009516 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009519;
L_009519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9519u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009519 INC
    cpu.inc('A');
    goto L_00951A;
L_00951A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00951A CMP
    cpu.compareA(0x9u);
    goto L_00951C;
L_00951C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00951C BCC -> $009520
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_009520; }
    goto L_00951E;
L_00951E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00951E LDA
    cpu.setA(0x1u, 8);
    goto L_009520;
L_009520:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9520u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9520u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9520u, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009520 STA
    hw.write(cpu.address("abs", 0x13C6u), cpu.a, cpu.m8?8:16);
    goto L_009523;
L_009523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9523u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9523u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009523 LDA
    cpu.setA(0x18u, 8);
    goto L_009525;
L_009525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9525u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9525u, 4u, 3u, cpu.address("abs", 0x0100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009525 STA
    hw.write(cpu.address("abs", 0x100u), cpu.a, cpu.m8?8:16);
    goto L_009528;
L_009528:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9528u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9528u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9528u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009528 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009528u);return;} hw.unresolvedReturn(0x009528u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_009529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9529u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9529u, 8u, 4u, 0x0CC97Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $009529 JSL -> $0CC97E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x952Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x952Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0CC97Eu, 0x009529u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00952D;
L_00952D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00952D REP
    cpu.rep(0x20u);
    goto L_00952F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00952D REP
    cpu.rep(0x20u);
    goto L_00952F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x952Du,0x00952Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00952F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00952F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009531;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00952F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009531;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x952Fu,0x00952Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9531u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9531u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9531u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009531 PHA
    cpu.push("PHA", hw);
    goto L_009532;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9531u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9531u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009531 PHA
    cpu.push("PHA", hw);
    goto L_009532;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9531u,0x009531u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009532:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9532u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9532u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9532u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009532 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009534;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9532u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9532u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009532 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009534;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9532u,0x009532u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9534u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9534u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9534u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009534 PHA
    cpu.push("PHA", hw);
    goto L_009535;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9534u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9534u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009534 PHA
    cpu.push("PHA", hw);
    goto L_009535;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9534u,0x009534u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009535:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9535u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9535u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9535u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009535 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009537;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9535u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9535u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009535 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009537;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9535u,0x009535u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9537u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9537u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9537u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009537 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_009539;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9537u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9537u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009537 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_009539;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9537u,0x009537u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9539u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9539u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9539u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009539 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00953B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9539u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9539u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009539 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00953B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9539u,0x009539u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00953B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00953B STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_00953D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00953B STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_00953D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x953Bu,0x00953Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00953D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00953D SEP
    cpu.sep(0x20u);
    goto L_00953F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00953D SEP
    cpu.sep(0x20u);
    goto L_00953F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x953Du,0x00953Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00953F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Fu, 8u, 4u, 0x00E2BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00953F JSL -> $00E2BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9542u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9543u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00E2BDu, 0x00953Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009543;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Fu, 8u, 4u, 0x00E2BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00953F JSL -> $00E2BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9542u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9543u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00E2BDu, 0x00953Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009543;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x953Fu,0x00953Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9543u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9543u,0x009543u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9543u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9543u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009543 REP
    cpu.rep(0x20u);
    goto L_009545;
L_009545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9545u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9545u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009545 PLA
    cpu.pop("PLA", hw);
    goto L_009546;
L_009546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9546u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9546u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009546 STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_009548;
L_009548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9548u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9548u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009548 PLA
    cpu.pop("PLA", hw);
    goto L_009549;
L_009549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9549u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9549u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009549 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_00954B;
L_00954B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x954Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x954Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x954Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00954B SEP
    cpu.sep(0x20u);
    goto L_00954D;
L_00954D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x954Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x954Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x954Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00954D LDA
    cpu.setA(0xCu, 8);
    goto L_00954F;
L_00954F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x954Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x954Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x954Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00954F STA
    hw.write(cpu.address("dp", 0x71u), cpu.a, cpu.m8?8:16);
    goto L_009551;
L_009551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9551u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9551u, 6u, 3u, cpu.address("abs", 0xC47Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009551 JSR -> $00C47E stack real
    { cpu.push16Value(hw,0x9553u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9554u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC47Eu), 0x009551u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009554;
L_009554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9554u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9554u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9554u, 3u, 3u, cpu.address("abs", 0x8494u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009554 JMP -> $008494
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8494u),0x009554u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9554u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9554u, 3u, 3u, cpu.address("abs", 0x8494u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009554 JMP -> $008494
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8494u),0x009554u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9554u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9554u, 3u, 3u, cpu.address("abs", 0x8494u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009554 JMP -> $008494
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8494u),0x009554u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9554u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9554u, 3u, 3u, cpu.address("abs", 0x8494u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009554 JMP -> $008494
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8494u),0x009554u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9554u,0x009554u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9557u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9557u, 8u, 4u, 0x0C938Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $009557 JSL -> $0C938D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x955Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x955Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0C938Du, 0x009557u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00955B;
L_00955B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x955Bu,0x00955Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Bu, 3u, 3u, cpu.address("abs", 0x8494u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00955B JMP -> $008494
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8494u),0x00955Bu); return;
}

void sub_00A087_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0093F4u: goto L_0093F4;
    case 0x0093F7u: goto L_0093F7;
    case 0x0093F9u: goto L_0093F9;
    case 0x0093FCu: goto L_0093FC;
    case 0x00A087u: goto L_00A087;
    case 0x00A08Au: goto L_00A08A;
    case 0x00A08Du: goto L_00A08D;
    case 0x00A08Fu: goto L_00A08F;
    case 0x00A093u: goto L_00A093;
    case 0x00A096u: goto L_00A096;
    case 0x00A099u: goto L_00A099;
    case 0x00A09Bu: goto L_00A09B;
    case 0x00A09Du: goto L_00A09D;
    case 0x00A0A0u: goto L_00A0A0;
    case 0x00A0A3u: goto L_00A0A3;
    case 0x00A0A5u: goto L_00A0A5;
    case 0x00A0A8u: goto L_00A0A8;
    case 0x00A0AAu: goto L_00A0AA;
    case 0x00A0ADu: goto L_00A0AD;
    case 0x00A0B0u: goto L_00A0B0;
    case 0x00A0B3u: goto L_00A0B3;
    case 0x00A0B6u: goto L_00A0B6;
    case 0x00A0B9u: goto L_00A0B9;
    case 0x00A0BCu: goto L_00A0BC;
    case 0x00A0BFu: goto L_00A0BF;
    case 0x00A0C2u: goto L_00A0C2;
    case 0x00A0C4u: goto L_00A0C4;
    case 0x00A0C7u: goto L_00A0C7;
    case 0x00A0CAu: goto L_00A0CA;
    case 0x00A0CCu: goto L_00A0CC;
    case 0x00A0CFu: goto L_00A0CF;
    case 0x00A0D2u: goto L_00A0D2;
    case 0x00A0D5u: goto L_00A0D5;
    case 0x00A0D8u: goto L_00A0D8;
    case 0x00A0DAu: goto L_00A0DA;
    case 0x00A0DDu: goto L_00A0DD;
    case 0x00A0E0u: goto L_00A0E0;
    case 0x00A0E3u: goto L_00A0E3;
    case 0x00A0E6u: goto L_00A0E6;
    case 0x00A0E8u: goto L_00A0E8;
    case 0x00A0EAu: goto L_00A0EA;
    case 0x00A0ECu: goto L_00A0EC;
    case 0x00A0EEu: goto L_00A0EE;
    case 0x00A0F1u: goto L_00A0F1;
    case 0x00A0F3u: goto L_00A0F3;
    case 0x00A0F6u: goto L_00A0F6;
    case 0x00A0F9u: goto L_00A0F9;
    case 0x00A0FBu: goto L_00A0FB;
    case 0x00A0FEu: goto L_00A0FE;
    case 0x00A101u: goto L_00A101;
    case 0x00A105u: goto L_00A105;
    case 0x00A107u: goto L_00A107;
    case 0x00A10Au: goto L_00A10A;
    case 0x00A10Du: goto L_00A10D;
    case 0x00A10Fu: goto L_00A10F;
    case 0x00A111u: goto L_00A111;
    case 0x00A113u: goto L_00A113;
    case 0x00A115u: goto L_00A115;
    case 0x00A117u: goto L_00A117;
    case 0x00A119u: goto L_00A119;
    case 0x00A11Bu: goto L_00A11B;
    case 0x00A11Du: goto L_00A11D;
    case 0x00A120u: goto L_00A120;
    case 0x00A123u: goto L_00A123;
    case 0x00A126u: goto L_00A126;
    case 0x00A12Au: goto L_00A12A;
    case 0x00A12Du: goto L_00A12D;
    case 0x00A130u: goto L_00A130;
    case 0x00A131u: goto L_00A131;
    case 0x00A132u: goto L_00A132;
    case 0x00A134u: goto L_00A134;
    case 0x00A137u: goto L_00A137;
    case 0x00A139u: goto L_00A139;
    case 0x00A13Bu: goto L_00A13B;
    case 0x00A13Eu: goto L_00A13E;
    case 0x00A140u: goto L_00A140;
    case 0x00A142u: goto L_00A142;
    case 0x00A144u: goto L_00A144;
    case 0x00A147u: goto L_00A147;
    case 0x00A149u: goto L_00A149;
    case 0x00A14Du: goto L_00A14D;
    case 0x00A150u: goto L_00A150;
    case 0x00A153u: goto L_00A153;
    case 0x00A155u: goto L_00A155;
    case 0x00A157u: goto L_00A157;
    case 0x00A15Au: goto L_00A15A;
    case 0x00A15Eu: goto L_00A15E;
    case 0x00A161u: goto L_00A161;
    case 0x00A165u: goto L_00A165;
    case 0x00A169u: goto L_00A169;
    case 0x00A16Bu: goto L_00A16B;
    case 0x00A16Du: goto L_00A16D;
    case 0x00A170u: goto L_00A170;
    case 0x00A173u: goto L_00A173;
    case 0x00A176u: goto L_00A176;
    case 0x00A179u: goto L_00A179;
    case 0x00A17Bu: goto L_00A17B;
    case 0x00A17Eu: goto L_00A17E;
    case 0x00A180u: goto L_00A180;
    case 0x00A183u: goto L_00A183;
    case 0x00A185u: goto L_00A185;
    case 0x00A188u: goto L_00A188;
    case 0x00A18Bu: goto L_00A18B;
    case 0x00A18Cu: goto L_00A18C;
    case 0x00A18Du: goto L_00A18D;
    case 0x00A18Fu: goto L_00A18F;
    case 0x00A192u: goto L_00A192;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0093F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u, 6u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F4 INC
    cpu.incMem(hw, cpu.address("abs", 0x100u), cpu.m8?8:16);
    goto L_0093F7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u, 6u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F4 INC
    cpu.incMem(hw, cpu.address("abs", 0x100u), cpu.m8?8:16);
    goto L_0093F7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F4u,0x0093F4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0093F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F7 LDA
    cpu.setA(0x81u, 8);
    goto L_0093F9;
L_0093F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F9 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0093FC;
L_0093FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0093FCu);return;} hw.unresolvedReturn(0x0093FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00A087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA087u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA087u, 6u, 3u, cpu.address("abs", 0x937Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A087 JSR -> $00937D stack real
    { cpu.push16Value(hw,0xA089u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA08Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x937Du), 0x00A087u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A08A;
L_00A08A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA08Au,0x00A08Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Au, 4u, 3u, cpu.address("abs", 0x1B9Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A08A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A08D;
L_00A08D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A08D BEQ -> $00A093
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A093; }
    goto L_00A08F;
L_00A08F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Fu, 8u, 4u, 0x04853Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A08F JSL -> $04853B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA092u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA093u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x04853Bu, 0x00A08Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A093;
L_00A093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA093u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA093u,0x00A093u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA093u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA093u, 6u, 3u, cpu.address("abs", 0xA1A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A093 JSR -> $00A1A6 stack real
    { cpu.push16Value(hw,0xA095u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA096u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA1A6u), 0x00A093u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A096;
L_00A096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA096u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA096u,0x00A096u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA096u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA096u, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A096 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A099;
L_00A099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA099u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA099u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A099 BEQ -> $00A0B0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A0B0; }
    goto L_00A09B;
L_00A09B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA09Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A09B LDA
    cpu.setA(0xB0u, 8);
    goto L_00A09D;
L_00A09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA09Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Du, 4u, 3u, cpu.address("abs", 0x1DF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A09D STA
    hw.write(cpu.address("abs", 0x1DF5u), cpu.a, cpu.m8?8:16);
    goto L_00A0A0;
L_00A0A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A0u, 4u, 3u, cpu.address("abs", 0x1F11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0A0 STZ
    hw.write(cpu.address("abs", 0x1F11u), 0, cpu.m8?8:16);
    goto L_00A0A3;
L_00A0A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0A3 LDA
    cpu.setA(0xF0u, 8);
    goto L_00A0A5;
L_00A0A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A5u, 4u, 3u, cpu.address("abs", 0x0DB0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0A5 STA
    hw.write(cpu.address("abs", 0xDB0u), cpu.a, cpu.m8?8:16);
    goto L_00A0A8;
L_00A0A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0A8 LDA
    cpu.setA(0x10u, 8);
    goto L_00A0AA;
L_00A0AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0AAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0AAu, 4u, 3u, cpu.address("abs", 0x0100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0AA STA
    hw.write(cpu.address("abs", 0x100u), cpu.a, cpu.m8?8:16);
    goto L_00A0AD;
L_00A0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ADu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ADu, 3u, 3u, cpu.address("abs", 0x93F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0AD JMP -> $0093F7
    goto L_0093F7;
L_00A0B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B0u, 6u, 3u, cpu.address("abs", 0x85FAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A0B0 JSR -> $0085FA stack real
    { cpu.push16Value(hw,0xA0B2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0B3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85FAu), 0x00A0B0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A0B3;
L_00A0B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0B3u,0x00A0B3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B3u, 6u, 3u, cpu.address("abs", 0x810Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A0B3 JSR -> $00810E stack real
    { cpu.push16Value(hw,0xA0B5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0B6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x810Eu), 0x00A0B3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A0B6;
L_00A0B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0B6u,0x00A0B6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B6u, 6u, 3u, cpu.address("abs", 0x8A79u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A0B6 JSR -> $008A79 stack real
    { cpu.push16Value(hw,0xA0B8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0B9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8A79u), 0x00A0B6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A0B9;
L_00A0B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0B9u,0x00A0B9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B9u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0B9 STZ
    hw.write(cpu.address("abs", 0xDDAu), 0, cpu.m8?8:16);
    goto L_00A0BC;
L_00A0BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BCu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BCu, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0BC LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A0BF;
L_00A0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BFu, 4u, 3u, cpu.address("abs", 0x0DBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0BF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A0C2;
L_00A0C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0C2 BPL -> $00A0C7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00A0C7; }
    goto L_00A0C4;
L_00A0C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C4u, 6u, 3u, cpu.address("abs", 0x1B87u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0C4 INC
    cpu.incMem(hw, cpu.address("abs", 0x1B87u), cpu.m8?8:16);
    goto L_00A0C7;
L_00A0C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C7u, 5u, 3u, cpu.address("absx", 0x0DB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0C7 STA
    hw.write(cpu.address("absx", 0xDB4u), cpu.a, cpu.m8?8:16);
    goto L_00A0CA;
L_00A0CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0CA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A0CC;
L_00A0CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CCu, 5u, 3u, cpu.address("absx", 0x0DB8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0CC STA
    hw.write(cpu.address("absx", 0xDB8u), cpu.a, cpu.m8?8:16);
    goto L_00A0CF;
L_00A0CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CFu, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0CF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A0D2;
L_00A0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D2u, 5u, 3u, cpu.address("absx", 0x0DB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0D2 STA
    hw.write(cpu.address("absx", 0xDB6u), cpu.a, cpu.m8?8:16);
    goto L_00A0D5;
L_00A0D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D5u, 4u, 3u, cpu.address("abs", 0x0DC1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0D5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDC1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A0D8;
L_00A0D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0D8 BEQ -> $00A0DD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A0DD; }
    goto L_00A0DA;
L_00A0DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DAu, 4u, 3u, cpu.address("abs", 0x13C7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0DA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A0DD;
L_00A0DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DDu, 5u, 3u, cpu.address("absx", 0x0DBAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0DD STA
    hw.write(cpu.address("absx", 0xDBAu), cpu.a, cpu.m8?8:16);
    goto L_00A0E0;
L_00A0E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E0u, 4u, 3u, cpu.address("abs", 0x0DC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0E0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A0E3;
L_00A0E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E3u, 5u, 3u, cpu.address("absx", 0x0DBCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0E3 STA
    hw.write(cpu.address("absx", 0xDBCu), cpu.a, cpu.m8?8:16);
    goto L_00A0E6;
L_00A0E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0E6 LDA
    cpu.setA(0x3u, 8);
    goto L_00A0E8;
L_00A0E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0E8 STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_00A0EA;
L_00A0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0EA LDA
    cpu.setA(0x30u, 8);
    goto L_00A0EC;
L_00A0EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ECu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0EC LDX
    cpu.setX(0x15u, 8);
    goto L_00A0EE;
L_00A0EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EEu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EEu, 4u, 3u, cpu.address("abs", 0x13C9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0EE LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13C9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A0F1;
L_00A0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0F1 BEQ -> $00A11B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A11B; }
    goto L_00A0F3;
L_00A0F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F3u, 6u, 3u, cpu.address("abs", 0xA195u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A0F3 JSR -> $00A195 stack real
    { cpu.push16Value(hw,0xA0F5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0F6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA195u), 0x00A0F3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A0F6;
L_00A0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0F6u,0x00A0F6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F6u, 4u, 3u, cpu.address("abs", 0x1F2Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0F6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F2Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A0F9;
L_00A0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0F9 BNE -> $00A101
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A101; }
    goto L_00A0FB;
L_00A0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FBu, 6u, 3u, cpu.address("abs", 0x9C89u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A0FB JSR -> $009C89 stack real
    { cpu.push16Value(hw,0xA0FDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0FEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9C89u), 0x00A0FBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A0FE;
L_00A0FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0FEu,0x00A0FEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FEu, 3u, 3u, cpu.address("abs", 0x93F4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0FE JMP -> $0093F4
    goto L_0093F4;
L_00A101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA101u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA101u, 8u, 4u, 0x04DAADu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A101 JSL -> $04DAAD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA104u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA105u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x04DAADu, 0x00A101u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A105;
L_00A105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA105u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA105u,0x00A105u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA105u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA105u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A105 REP
    cpu.rep(0x20u);
    goto L_00A107;
L_00A107:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA107u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA107u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA107u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A107 LDA
    cpu.setA(0x318Cu, 16);
    goto L_00A10A;
L_00A10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Au, 5u, 3u, cpu.address("abs", 0x0701u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A10A STA
    hw.write(cpu.address("abs", 0x701u), cpu.a, cpu.m8?8:16);
    goto L_00A10D;
L_00A10D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A10D SEP
    cpu.sep(0x20u);
    goto L_00A10F;
L_00A10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A10F LDA
    cpu.setA(0x30u, 8);
    goto L_00A111;
L_00A111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA111u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA111u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A111 STA
    hw.write(cpu.address("dp", 0x43u), cpu.a, cpu.m8?8:16);
    goto L_00A113;
L_00A113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA113u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA113u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA113u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A113 LDA
    cpu.setA(0x20u, 8);
    goto L_00A115;
L_00A115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA115u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA115u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A115 STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_00A117;
L_00A117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA117u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA117u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A117 LDA
    cpu.setA(0xB3u, 8);
    goto L_00A119;
L_00A119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA119u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA119u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A119 LDX
    cpu.setX(0x17u, 8);
    goto L_00A11B;
L_00A11B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A11B LDY
    cpu.setY(0x2u, 8);
    goto L_00A11D;
L_00A11D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Du, 6u, 3u, cpu.address("abs", 0x93FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A11D JSR -> $0093FD stack real
    { cpu.push16Value(hw,0xA11Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA120u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x93FDu), 0x00A11Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A120;
L_00A120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA120u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA120u,0x00A120u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA120u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA120u, 4u, 3u, cpu.address("abs", 0x212Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A120 STX
    hw.write(cpu.address("abs", 0x212Eu), cpu.x, cpu.x8?8:16);
    goto L_00A123;
L_00A123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA123u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA123u, 4u, 3u, cpu.address("abs", 0x212Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A123 STY
    hw.write(cpu.address("abs", 0x212Fu), cpu.y, cpu.x8?8:16);
    goto L_00A126;
L_00A126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA126u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA126u, 8u, 4u, 0x04DC09u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A126 JSL -> $04DC09 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA129u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA12Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x04DC09u, 0x00A126u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A12A;
L_00A12A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA12Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA12Au,0x00A12Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Au, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A12A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A12D;
L_00A12D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA12Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Du, 4u + ((((0x1F11u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A12D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A130;
L_00A130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA130u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA130u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A130 ASL
    cpu.aslA();
    goto L_00A131;
L_00A131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA131u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA131u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A131 TAX
    cpu.transfer("TAX");
    goto L_00A132;
L_00A132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA132u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA132u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA132u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A132 REP
    cpu.rep(0x20u);
    goto L_00A134;
L_00A134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA134u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA134u, 5u + ((((0xA06Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA06Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A134 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA06Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A137;
L_00A137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA137u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA137u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A137 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_00A139;
L_00A139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA139u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA139u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A139 STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_00A13B;
L_00A13B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA13Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Bu, 5u + ((((0xA079u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA079u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A13B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA079u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A13E;
L_00A13E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA13Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A13E STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_00A140;
L_00A140:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA140u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA140u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA140u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A140 STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_00A142;
L_00A142:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA142u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA142u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA142u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A142 SEP
    cpu.sep(0x20u);
    goto L_00A144;
L_00A144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA144u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA144u, 6u, 3u, cpu.address("abs", 0xA9DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A144 JSR -> $00A9DA stack real
    { cpu.push16Value(hw,0xA146u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA147u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA9DAu), 0x00A144u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A147;
L_00A147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA147u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA147u,0x00A147u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA147u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA147u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A147 LDY
    cpu.setY(0x14u, 8);
    goto L_00A149;
L_00A149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA149u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA149u, 8u, 4u, 0x00BA28u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A149 JSL -> $00BA28 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA14Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA14Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00BA28u, 0x00A149u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A14D;
L_00A14D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA14Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA14Du,0x00A14Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Du, 6u, 3u, cpu.address("abs", 0xAD25u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A14D JSR -> $00AD25 stack real
    { cpu.push16Value(hw,0xA14Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA150u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD25u), 0x00A14Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A150;
L_00A150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA150u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA150u,0x00A150u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA150u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA150u, 6u, 3u, cpu.address("abs", 0x922Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A150 JSR -> $00922F stack real
    { cpu.push16Value(hw,0xA152u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA153u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x922Fu), 0x00A150u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A153;
L_00A153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA153u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA153u,0x00A153u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA153u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA153u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A153 LDA
    cpu.setA(0x6u, 8);
    goto L_00A155;
L_00A155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA155u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA155u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A155 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_00A157;
L_00A157:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA157u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA157u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA157u, 6u, 3u, cpu.address("abs", 0x85D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A157 JSR -> $0085D2 stack real
    { cpu.push16Value(hw,0xA159u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA15Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D2u), 0x00A157u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A15A;
L_00A15A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA15Au,0x00A15Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Au, 8u, 4u, 0x05DBF2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A15A JSL -> $05DBF2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA15Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA15Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05DBF2u, 0x00A15Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A15E;
L_00A15E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA15Eu,0x00A15Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Eu, 6u, 3u, cpu.address("abs", 0x85D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A15E JSR -> $0085D2 stack real
    { cpu.push16Value(hw,0xA160u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA161u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D2u), 0x00A15Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A161;
L_00A161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA161u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA161u,0x00A161u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA161u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA161u, 8u, 4u, 0x048D91u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A161 JSL -> $048D91 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA164u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA165u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x048D91u, 0x00A161u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A165;
L_00A165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA165u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA165u,0x00A165u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA165u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA165u, 8u, 4u, 0x04D6E9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A165 JSL -> $04D6E9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA168u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA169u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x04D6E9u, 0x00A165u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A169;
L_00A169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA169u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA169u,0x00A169u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA169u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA169u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A169 LDA
    cpu.setA(0xF0u, 8);
    goto L_00A16B;
L_00A16B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A16B STA
    hw.write(cpu.address("dp", 0x3Fu), cpu.a, cpu.m8?8:16);
    goto L_00A16D;
L_00A16D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Du, 6u, 3u, cpu.address("abs", 0x8494u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A16D JSR -> $008494 stack real
    { cpu.push16Value(hw,0xA16Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA170u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8494u), 0x00A16Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A170;
L_00A170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA170u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA170u,0x00A170u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA170u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA170u, 6u, 3u, cpu.address("abs", 0x85D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A170 JSR -> $0085D2 stack real
    { cpu.push16Value(hw,0xA172u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA173u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D2u), 0x00A170u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A173;
L_00A173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA173u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA173u,0x00A173u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA173u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA173u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A173 STZ
    hw.write(cpu.address("abs", 0x13D9u), 0, cpu.m8?8:16);
    goto L_00A176;
L_00A176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA176u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA176u, 6u, 3u, cpu.address("abs", 0x9F29u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A176 JSR -> $009F29 stack real
    { cpu.push16Value(hw,0xA178u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA179u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F29u), 0x00A176u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A179;
L_00A179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA179u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA179u,0x00A179u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA179u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA179u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A179 LDA
    cpu.setA(0x2u, 8);
    goto L_00A17B;
L_00A17B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Bu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A17B STA
    hw.write(cpu.address("abs", 0xD9Bu), cpu.a, cpu.m8?8:16);
    goto L_00A17E;
L_00A17E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A17E REP
    cpu.rep(0x10u);
    goto L_00A180;
L_00A180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA180u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA180u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A180 LDX
    cpu.setX(0x1BEu, 16);
    goto L_00A183;
L_00A183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA183u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA183u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A183 LDA
    cpu.setA(0xFFu, 8);
    goto L_00A185;
L_00A185:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA185u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA185u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA185u, 5u, 3u, cpu.address("absx", 0x04A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A185 STZ
    hw.write(cpu.address("absx", 0x4A0u), 0, cpu.m8?8:16);
    goto L_00A188;
L_00A188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA188u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA188u, 5u, 3u, cpu.address("absx", 0x04A1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A188 STA
    hw.write(cpu.address("absx", 0x4A1u), cpu.a, cpu.m8?8:16);
    goto L_00A18B;
L_00A18B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A18B DEX
    cpu.decReg('X');
    goto L_00A18C;
L_00A18C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A18C DEX
    cpu.decReg('X');
    goto L_00A18D;
L_00A18D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A18D BPL -> $00A185
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00A185; }
    goto L_00A18F;
L_00A18F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Fu, 6u, 3u, cpu.address("abs", 0x92A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A18F JSR -> $0092A0 stack real
    { cpu.push16Value(hw,0xA191u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA192u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x92A0u), 0x00A18Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A192;
L_00A192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA192u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA192u,0x00A192u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA192u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA192u, 3u, 3u, cpu.address("abs", 0x93F4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A192 JMP -> $0093F4
    goto L_0093F4;
}

void sub_00A087_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0093F4u: goto L_0093F4;
    case 0x0093F7u: goto L_0093F7;
    case 0x0093F9u: goto L_0093F9;
    case 0x0093FCu: goto L_0093FC;
    case 0x00A087u: goto L_00A087;
    case 0x00A08Au: goto L_00A08A;
    case 0x00A08Du: goto L_00A08D;
    case 0x00A08Fu: goto L_00A08F;
    case 0x00A093u: goto L_00A093;
    case 0x00A096u: goto L_00A096;
    case 0x00A099u: goto L_00A099;
    case 0x00A09Bu: goto L_00A09B;
    case 0x00A09Du: goto L_00A09D;
    case 0x00A0A0u: goto L_00A0A0;
    case 0x00A0A3u: goto L_00A0A3;
    case 0x00A0A5u: goto L_00A0A5;
    case 0x00A0A8u: goto L_00A0A8;
    case 0x00A0AAu: goto L_00A0AA;
    case 0x00A0ADu: goto L_00A0AD;
    case 0x00A0B0u: goto L_00A0B0;
    case 0x00A0B3u: goto L_00A0B3;
    case 0x00A0B6u: goto L_00A0B6;
    case 0x00A0B9u: goto L_00A0B9;
    case 0x00A0BCu: goto L_00A0BC;
    case 0x00A0BFu: goto L_00A0BF;
    case 0x00A0C2u: goto L_00A0C2;
    case 0x00A0C4u: goto L_00A0C4;
    case 0x00A0C7u: goto L_00A0C7;
    case 0x00A0CAu: goto L_00A0CA;
    case 0x00A0CCu: goto L_00A0CC;
    case 0x00A0CFu: goto L_00A0CF;
    case 0x00A0D2u: goto L_00A0D2;
    case 0x00A0D5u: goto L_00A0D5;
    case 0x00A0D8u: goto L_00A0D8;
    case 0x00A0DAu: goto L_00A0DA;
    case 0x00A0DDu: goto L_00A0DD;
    case 0x00A0E0u: goto L_00A0E0;
    case 0x00A0E3u: goto L_00A0E3;
    case 0x00A0E6u: goto L_00A0E6;
    case 0x00A0E8u: goto L_00A0E8;
    case 0x00A0EAu: goto L_00A0EA;
    case 0x00A0ECu: goto L_00A0EC;
    case 0x00A0EEu: goto L_00A0EE;
    case 0x00A0F1u: goto L_00A0F1;
    case 0x00A0F3u: goto L_00A0F3;
    case 0x00A0F6u: goto L_00A0F6;
    case 0x00A0F9u: goto L_00A0F9;
    case 0x00A0FBu: goto L_00A0FB;
    case 0x00A0FEu: goto L_00A0FE;
    case 0x00A101u: goto L_00A101;
    case 0x00A105u: goto L_00A105;
    case 0x00A107u: goto L_00A107;
    case 0x00A10Au: goto L_00A10A;
    case 0x00A10Du: goto L_00A10D;
    case 0x00A10Fu: goto L_00A10F;
    case 0x00A111u: goto L_00A111;
    case 0x00A113u: goto L_00A113;
    case 0x00A115u: goto L_00A115;
    case 0x00A117u: goto L_00A117;
    case 0x00A119u: goto L_00A119;
    case 0x00A11Bu: goto L_00A11B;
    case 0x00A11Du: goto L_00A11D;
    case 0x00A120u: goto L_00A120;
    case 0x00A123u: goto L_00A123;
    case 0x00A126u: goto L_00A126;
    case 0x00A12Au: goto L_00A12A;
    case 0x00A12Du: goto L_00A12D;
    case 0x00A130u: goto L_00A130;
    case 0x00A131u: goto L_00A131;
    case 0x00A132u: goto L_00A132;
    case 0x00A134u: goto L_00A134;
    case 0x00A137u: goto L_00A137;
    case 0x00A139u: goto L_00A139;
    case 0x00A13Bu: goto L_00A13B;
    case 0x00A13Eu: goto L_00A13E;
    case 0x00A140u: goto L_00A140;
    case 0x00A142u: goto L_00A142;
    case 0x00A144u: goto L_00A144;
    case 0x00A147u: goto L_00A147;
    case 0x00A149u: goto L_00A149;
    case 0x00A14Du: goto L_00A14D;
    case 0x00A150u: goto L_00A150;
    case 0x00A153u: goto L_00A153;
    case 0x00A155u: goto L_00A155;
    case 0x00A157u: goto L_00A157;
    case 0x00A15Au: goto L_00A15A;
    case 0x00A15Eu: goto L_00A15E;
    case 0x00A161u: goto L_00A161;
    case 0x00A165u: goto L_00A165;
    case 0x00A169u: goto L_00A169;
    case 0x00A16Bu: goto L_00A16B;
    case 0x00A16Du: goto L_00A16D;
    case 0x00A170u: goto L_00A170;
    case 0x00A173u: goto L_00A173;
    case 0x00A176u: goto L_00A176;
    case 0x00A179u: goto L_00A179;
    case 0x00A17Bu: goto L_00A17B;
    case 0x00A17Eu: goto L_00A17E;
    case 0x00A180u: goto L_00A180;
    case 0x00A183u: goto L_00A183;
    case 0x00A185u: goto L_00A185;
    case 0x00A188u: goto L_00A188;
    case 0x00A18Bu: goto L_00A18B;
    case 0x00A18Cu: goto L_00A18C;
    case 0x00A18Du: goto L_00A18D;
    case 0x00A18Fu: goto L_00A18F;
    case 0x00A192u: goto L_00A192;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0093F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u, 6u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F4 INC
    cpu.incMem(hw, cpu.address("abs", 0x100u), cpu.m8?8:16);
    goto L_0093F7;
L_0093F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F7 LDA
    cpu.setA(0x81u, 8);
    goto L_0093F9;
L_0093F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F9 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0093FC;
L_0093FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0093FCu);return;} hw.unresolvedReturn(0x0093FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00A087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA087u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA087u, 6u, 3u, cpu.address("abs", 0x937Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A087 JSR -> $00937D stack real
    { cpu.push16Value(hw,0xA089u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA08Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x937Du), 0x00A087u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A08A;
L_00A08A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA08Au,0x00A08Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Au, 4u, 3u, cpu.address("abs", 0x1B9Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A08A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A08D;
L_00A08D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A08D BEQ -> $00A093
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A093; }
    goto L_00A08F;
L_00A08F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Fu, 8u, 4u, 0x04853Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A08F JSL -> $04853B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA092u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA093u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x04853Bu, 0x00A08Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A093;
L_00A093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA093u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA093u,0x00A093u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA093u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA093u, 6u, 3u, cpu.address("abs", 0xA1A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A093 JSR -> $00A1A6 stack real
    { cpu.push16Value(hw,0xA095u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA096u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA1A6u), 0x00A093u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A096;
L_00A096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA096u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA096u,0x00A096u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA096u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA096u, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A096 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A099;
L_00A099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA099u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA099u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A099 BEQ -> $00A0B0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A0B0; }
    goto L_00A09B;
L_00A09B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA09Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A09B LDA
    cpu.setA(0xB0u, 8);
    goto L_00A09D;
L_00A09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA09Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Du, 4u, 3u, cpu.address("abs", 0x1DF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A09D STA
    hw.write(cpu.address("abs", 0x1DF5u), cpu.a, cpu.m8?8:16);
    goto L_00A0A0;
L_00A0A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A0u, 4u, 3u, cpu.address("abs", 0x1F11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0A0 STZ
    hw.write(cpu.address("abs", 0x1F11u), 0, cpu.m8?8:16);
    goto L_00A0A3;
L_00A0A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0A3 LDA
    cpu.setA(0xF0u, 8);
    goto L_00A0A5;
L_00A0A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A5u, 4u, 3u, cpu.address("abs", 0x0DB0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0A5 STA
    hw.write(cpu.address("abs", 0xDB0u), cpu.a, cpu.m8?8:16);
    goto L_00A0A8;
L_00A0A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0A8 LDA
    cpu.setA(0x10u, 8);
    goto L_00A0AA;
L_00A0AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0AAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0AAu, 4u, 3u, cpu.address("abs", 0x0100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0AA STA
    hw.write(cpu.address("abs", 0x100u), cpu.a, cpu.m8?8:16);
    goto L_00A0AD;
L_00A0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ADu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ADu, 3u, 3u, cpu.address("abs", 0x93F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0AD JMP -> $0093F7
    goto L_0093F7;
L_00A0B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B0u, 6u, 3u, cpu.address("abs", 0x85FAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A0B0 JSR -> $0085FA stack real
    { cpu.push16Value(hw,0xA0B2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0B3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85FAu), 0x00A0B0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A0B3;
L_00A0B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0B3u,0x00A0B3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B3u, 6u, 3u, cpu.address("abs", 0x810Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A0B3 JSR -> $00810E stack real
    { cpu.push16Value(hw,0xA0B5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0B6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x810Eu), 0x00A0B3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A0B6;
L_00A0B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0B6u,0x00A0B6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B6u, 6u, 3u, cpu.address("abs", 0x8A79u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A0B6 JSR -> $008A79 stack real
    { cpu.push16Value(hw,0xA0B8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0B9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8A79u), 0x00A0B6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A0B9;
L_00A0B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0B9u,0x00A0B9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B9u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0B9 STZ
    hw.write(cpu.address("abs", 0xDDAu), 0, cpu.m8?8:16);
    goto L_00A0BC;
L_00A0BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BCu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BCu, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0BC LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A0BF;
L_00A0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BFu, 4u, 3u, cpu.address("abs", 0x0DBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0BF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A0C2;
L_00A0C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0C2 BPL -> $00A0C7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00A0C7; }
    goto L_00A0C4;
L_00A0C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C4u, 6u, 3u, cpu.address("abs", 0x1B87u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0C4 INC
    cpu.incMem(hw, cpu.address("abs", 0x1B87u), cpu.m8?8:16);
    goto L_00A0C7;
L_00A0C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C7u, 5u, 3u, cpu.address("absx", 0x0DB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0C7 STA
    hw.write(cpu.address("absx", 0xDB4u), cpu.a, cpu.m8?8:16);
    goto L_00A0CA;
L_00A0CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0CA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A0CC;
L_00A0CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CCu, 5u, 3u, cpu.address("absx", 0x0DB8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0CC STA
    hw.write(cpu.address("absx", 0xDB8u), cpu.a, cpu.m8?8:16);
    goto L_00A0CF;
L_00A0CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CFu, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0CF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A0D2;
L_00A0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D2u, 5u, 3u, cpu.address("absx", 0x0DB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0D2 STA
    hw.write(cpu.address("absx", 0xDB6u), cpu.a, cpu.m8?8:16);
    goto L_00A0D5;
L_00A0D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D5u, 4u, 3u, cpu.address("abs", 0x0DC1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0D5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDC1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A0D8;
L_00A0D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0D8 BEQ -> $00A0DD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A0DD; }
    goto L_00A0DA;
L_00A0DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DAu, 4u, 3u, cpu.address("abs", 0x13C7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0DA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A0DD;
L_00A0DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DDu, 5u, 3u, cpu.address("absx", 0x0DBAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0DD STA
    hw.write(cpu.address("absx", 0xDBAu), cpu.a, cpu.m8?8:16);
    goto L_00A0E0;
L_00A0E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E0u, 4u, 3u, cpu.address("abs", 0x0DC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0E0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A0E3;
L_00A0E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E3u, 5u, 3u, cpu.address("absx", 0x0DBCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0E3 STA
    hw.write(cpu.address("absx", 0xDBCu), cpu.a, cpu.m8?8:16);
    goto L_00A0E6;
L_00A0E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0E6 LDA
    cpu.setA(0x3u, 8);
    goto L_00A0E8;
L_00A0E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0E8 STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_00A0EA;
L_00A0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0EA LDA
    cpu.setA(0x30u, 8);
    goto L_00A0EC;
L_00A0EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ECu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0EC LDX
    cpu.setX(0x15u, 8);
    goto L_00A0EE;
L_00A0EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EEu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EEu, 4u, 3u, cpu.address("abs", 0x13C9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0EE LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13C9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A0F1;
L_00A0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0F1 BEQ -> $00A11B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A11B; }
    goto L_00A0F3;
L_00A0F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F3u, 6u, 3u, cpu.address("abs", 0xA195u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A0F3 JSR -> $00A195 stack real
    { cpu.push16Value(hw,0xA0F5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0F6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA195u), 0x00A0F3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A0F6;
L_00A0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0F6u,0x00A0F6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F6u, 4u, 3u, cpu.address("abs", 0x1F2Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0F6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F2Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A0F9;
L_00A0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0F9 BNE -> $00A101
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A101; }
    goto L_00A0FB;
L_00A0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FBu, 6u, 3u, cpu.address("abs", 0x9C89u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A0FB JSR -> $009C89 stack real
    { cpu.push16Value(hw,0xA0FDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0FEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9C89u), 0x00A0FBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A0FE;
L_00A0FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0FEu,0x00A0FEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FEu, 3u, 3u, cpu.address("abs", 0x93F4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A0FE JMP -> $0093F4
    goto L_0093F4;
L_00A101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA101u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA101u, 8u, 4u, 0x04DAADu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A101 JSL -> $04DAAD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA104u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA105u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x04DAADu, 0x00A101u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A105;
L_00A105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA105u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA105u,0x00A105u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA105u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA105u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A105 REP
    cpu.rep(0x20u);
    goto L_00A107;
L_00A107:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA107u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA107u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA107u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A107 LDA
    cpu.setA(0x318Cu, 16);
    goto L_00A10A;
L_00A10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Au, 5u, 3u, cpu.address("abs", 0x0701u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A10A STA
    hw.write(cpu.address("abs", 0x701u), cpu.a, cpu.m8?8:16);
    goto L_00A10D;
L_00A10D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A10D SEP
    cpu.sep(0x20u);
    goto L_00A10F;
L_00A10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A10F LDA
    cpu.setA(0x30u, 8);
    goto L_00A111;
L_00A111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA111u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA111u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A111 STA
    hw.write(cpu.address("dp", 0x43u), cpu.a, cpu.m8?8:16);
    goto L_00A113;
L_00A113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA113u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA113u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA113u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A113 LDA
    cpu.setA(0x20u, 8);
    goto L_00A115;
L_00A115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA115u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA115u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A115 STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_00A117;
L_00A117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA117u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA117u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A117 LDA
    cpu.setA(0xB3u, 8);
    goto L_00A119;
L_00A119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA119u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA119u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A119 LDX
    cpu.setX(0x17u, 8);
    goto L_00A11B;
L_00A11B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A11B LDY
    cpu.setY(0x2u, 8);
    goto L_00A11D;
L_00A11D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Du, 6u, 3u, cpu.address("abs", 0x93FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A11D JSR -> $0093FD stack real
    { cpu.push16Value(hw,0xA11Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA120u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x93FDu), 0x00A11Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A120;
L_00A120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA120u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA120u,0x00A120u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA120u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA120u, 4u, 3u, cpu.address("abs", 0x212Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A120 STX
    hw.write(cpu.address("abs", 0x212Eu), cpu.x, cpu.x8?8:16);
    goto L_00A123;
L_00A123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA123u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA123u, 4u, 3u, cpu.address("abs", 0x212Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A123 STY
    hw.write(cpu.address("abs", 0x212Fu), cpu.y, cpu.x8?8:16);
    goto L_00A126;
L_00A126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA126u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA126u, 8u, 4u, 0x04DC09u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A126 JSL -> $04DC09 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA129u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA12Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x04DC09u, 0x00A126u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A12A;
L_00A12A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA12Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA12Au,0x00A12Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Au, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A12A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A12D;
L_00A12D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA12Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Du, 4u + ((((0x1F11u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A12D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A130;
L_00A130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA130u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA130u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A130 ASL
    cpu.aslA();
    goto L_00A131;
L_00A131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA131u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA131u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A131 TAX
    cpu.transfer("TAX");
    goto L_00A132;
L_00A132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA132u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA132u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA132u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A132 REP
    cpu.rep(0x20u);
    goto L_00A134;
L_00A134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA134u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA134u, 5u + ((((0xA06Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA06Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A134 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA06Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A137;
L_00A137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA137u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA137u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A137 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_00A139;
L_00A139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA139u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA139u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A139 STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_00A13B;
L_00A13B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA13Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Bu, 5u + ((((0xA079u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA079u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A13B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA079u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A13E;
L_00A13E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA13Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A13E STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_00A140;
L_00A140:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA140u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA140u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA140u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A140 STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_00A142;
L_00A142:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA142u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA142u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA142u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A142 SEP
    cpu.sep(0x20u);
    goto L_00A144;
L_00A144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA144u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA144u, 6u, 3u, cpu.address("abs", 0xA9DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A144 JSR -> $00A9DA stack real
    { cpu.push16Value(hw,0xA146u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA147u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA9DAu), 0x00A144u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A147;
L_00A147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA147u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA147u,0x00A147u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA147u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA147u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A147 LDY
    cpu.setY(0x14u, 8);
    goto L_00A149;
L_00A149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA149u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA149u, 8u, 4u, 0x00BA28u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A149 JSL -> $00BA28 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA14Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA14Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00BA28u, 0x00A149u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A14D;
L_00A14D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA14Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA14Du,0x00A14Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Du, 6u, 3u, cpu.address("abs", 0xAD25u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A14D JSR -> $00AD25 stack real
    { cpu.push16Value(hw,0xA14Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA150u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD25u), 0x00A14Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A150;
L_00A150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA150u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA150u,0x00A150u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA150u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA150u, 6u, 3u, cpu.address("abs", 0x922Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A150 JSR -> $00922F stack real
    { cpu.push16Value(hw,0xA152u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA153u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x922Fu), 0x00A150u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A153;
L_00A153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA153u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA153u,0x00A153u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA153u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA153u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A153 LDA
    cpu.setA(0x6u, 8);
    goto L_00A155;
L_00A155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA155u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA155u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A155 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_00A157;
L_00A157:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA157u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA157u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA157u, 6u, 3u, cpu.address("abs", 0x85D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A157 JSR -> $0085D2 stack real
    { cpu.push16Value(hw,0xA159u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA15Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D2u), 0x00A157u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A15A;
L_00A15A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA15Au,0x00A15Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Au, 8u, 4u, 0x05DBF2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A15A JSL -> $05DBF2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA15Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA15Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05DBF2u, 0x00A15Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A15E;
L_00A15E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA15Eu,0x00A15Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Eu, 6u, 3u, cpu.address("abs", 0x85D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A15E JSR -> $0085D2 stack real
    { cpu.push16Value(hw,0xA160u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA161u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D2u), 0x00A15Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A161;
L_00A161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA161u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA161u,0x00A161u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA161u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA161u, 8u, 4u, 0x048D91u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A161 JSL -> $048D91 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA164u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA165u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x048D91u, 0x00A161u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A165;
L_00A165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA165u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA165u,0x00A165u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA165u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA165u, 8u, 4u, 0x04D6E9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A165 JSL -> $04D6E9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA168u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA169u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x04D6E9u, 0x00A165u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A169;
L_00A169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA169u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA169u,0x00A169u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA169u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA169u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A169 LDA
    cpu.setA(0xF0u, 8);
    goto L_00A16B;
L_00A16B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A16B STA
    hw.write(cpu.address("dp", 0x3Fu), cpu.a, cpu.m8?8:16);
    goto L_00A16D;
L_00A16D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Du, 6u, 3u, cpu.address("abs", 0x8494u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A16D JSR -> $008494 stack real
    { cpu.push16Value(hw,0xA16Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA170u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8494u), 0x00A16Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A170;
L_00A170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA170u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA170u,0x00A170u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA170u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA170u, 6u, 3u, cpu.address("abs", 0x85D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A170 JSR -> $0085D2 stack real
    { cpu.push16Value(hw,0xA172u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA173u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D2u), 0x00A170u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A173;
L_00A173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA173u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA173u,0x00A173u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA173u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA173u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A173 STZ
    hw.write(cpu.address("abs", 0x13D9u), 0, cpu.m8?8:16);
    goto L_00A176;
L_00A176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA176u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA176u, 6u, 3u, cpu.address("abs", 0x9F29u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A176 JSR -> $009F29 stack real
    { cpu.push16Value(hw,0xA178u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA179u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F29u), 0x00A176u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A179;
L_00A179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA179u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA179u,0x00A179u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA179u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA179u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A179 LDA
    cpu.setA(0x2u, 8);
    goto L_00A17B;
L_00A17B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Bu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A17B STA
    hw.write(cpu.address("abs", 0xD9Bu), cpu.a, cpu.m8?8:16);
    goto L_00A17E;
L_00A17E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A17E REP
    cpu.rep(0x10u);
    goto L_00A180;
L_00A180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA180u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA180u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A180 LDX
    cpu.setX(0x1BEu, 16);
    goto L_00A183;
L_00A183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA183u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA183u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A183 LDA
    cpu.setA(0xFFu, 8);
    goto L_00A185;
L_00A185:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA185u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA185u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA185u, 5u, 3u, cpu.address("absx", 0x04A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A185 STZ
    hw.write(cpu.address("absx", 0x4A0u), 0, cpu.m8?8:16);
    goto L_00A188;
L_00A188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA188u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA188u, 5u, 3u, cpu.address("absx", 0x04A1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A188 STA
    hw.write(cpu.address("absx", 0x4A1u), cpu.a, cpu.m8?8:16);
    goto L_00A18B;
L_00A18B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A18B DEX
    cpu.decReg('X');
    goto L_00A18C;
L_00A18C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A18C DEX
    cpu.decReg('X');
    goto L_00A18D;
L_00A18D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A18D BPL -> $00A185
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00A185; }
    goto L_00A18F;
L_00A18F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Fu, 6u, 3u, cpu.address("abs", 0x92A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A18F JSR -> $0092A0 stack real
    { cpu.push16Value(hw,0xA191u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA192u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x92A0u), 0x00A18Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A192;
L_00A192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA192u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA192u,0x00A192u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA192u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA192u, 3u, 3u, cpu.address("abs", 0x93F4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A192 JMP -> $0093F4
    goto L_0093F4;
}

void sub_00B006_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00B006u: goto L_00B006;
    case 0x00B007u: goto L_00B007;
    case 0x00B008u: goto L_00B008;
    case 0x00B009u: goto L_00B009;
    case 0x00B00Cu: goto L_00B00C;
    case 0x00B00Fu: goto L_00B00F;
    case 0x00B012u: goto L_00B012;
    case 0x00B015u: goto L_00B015;
    case 0x00B017u: goto L_00B017;
    case 0x00B01Au: goto L_00B01A;
    case 0x00B01Bu: goto L_00B01B;
    case 0x00B01Eu: goto L_00B01E;
    case 0x00B01Fu: goto L_00B01F;
    case 0x00B021u: goto L_00B021;
    case 0x00B024u: goto L_00B024;
    case 0x00B027u: goto L_00B027;
    case 0x00B028u: goto L_00B028;
    case 0x00B02Au: goto L_00B02A;
    case 0x00B02Du: goto L_00B02D;
    case 0x00B02Eu: goto L_00B02E;
    case 0x00B02Fu: goto L_00B02F;
    case 0x00B030u: goto L_00B030;
    case 0x00B032u: goto L_00B032;
    case 0x00B033u: goto L_00B033;
    case 0x00B034u: goto L_00B034;
    case 0x00B037u: goto L_00B037;
    case 0x00B038u: goto L_00B038;
    case 0x00B03Au: goto L_00B03A;
    case 0x00B03Cu: goto L_00B03C;
    case 0x00B03Du: goto L_00B03D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00B006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB006u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB006u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B006 PHB
    cpu.push("PHB", hw);
    goto L_00B007;
L_00B007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB007u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB007u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B007 PHK
    cpu.push("PHK", hw);
    goto L_00B008;
L_00B008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB008u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB008u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B008 PLB
    cpu.pop("PLB", hw);
    goto L_00B009;
L_00B009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB009u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB009u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB009u, 6u, 3u, cpu.address("abs", 0xAFA3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B009 JSR -> $00AFA3 stack real
    { cpu.push16Value(hw,0xB00Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB00Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAFA3u), 0x00B009u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B00C;
L_00B00C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB00Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB00Cu,0x00B00Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B00C LDX
    cpu.setX(0x6Eu, 16);
    goto L_00B00F;
L_00B00F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB00Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B00F LDY
    cpu.setY(0x8u, 16);
    goto L_00B012;
L_00B012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB012u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB012u, 5u + 1u, 3u, cpu.address("absx", 0x0907u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B012 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x907u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B015;
L_00B015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB015u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB015u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B015 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_00B017;
L_00B017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB017u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB017u, 5u + 1u, 3u, cpu.address("absx", 0x0783u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B017 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x783u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B01A;
L_00B01A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Au,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B01A PHY
    cpu.push("PHY", hw);
    goto L_00B01B;
L_00B01B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Bu, 6u, 3u, cpu.address("abs", 0xAFC0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B01B JSR -> $00AFC0 stack real
    { cpu.push16Value(hw,0xB01Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB01Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAFC0u), 0x00B01Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B01E;
L_00B01E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB01Eu,0x00B01Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Eu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Eu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B01E PLY
    cpu.pop("PLY", hw);
    goto L_00B01F;
L_00B01F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B01F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B021;
L_00B021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB021u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB021u, 6u, 3u, cpu.address("absx", 0x0907u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B021 STA
    hw.write(cpu.address("absx", 0x907u), cpu.a, cpu.m8?8:16);
    goto L_00B024;
L_00B024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB024u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB024u, 5u + 1u, 3u, cpu.address("absx", 0x0783u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B024 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x783u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B027;
L_00B027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB027u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB027u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B027 SEC
    cpu.setFlag('C', true);
    goto L_00B028;
L_00B028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB028u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB028u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B028 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_00B02A;
L_00B02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB02Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Au, 6u, 3u, cpu.address("absx", 0x0979u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B02A STA
    hw.write(cpu.address("absx", 0x979u), cpu.a, cpu.m8?8:16);
    goto L_00B02D;
L_00B02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB02Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Du,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B02D DEX
    cpu.decReg('X');
    goto L_00B02E;
L_00B02E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB02Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B02E DEX
    cpu.decReg('X');
    goto L_00B02F;
L_00B02F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB02Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Fu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B02F DEY
    cpu.decReg('Y');
    goto L_00B030;
L_00B030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB030u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB030u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B030 BNE -> $00B012
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B012; }
    goto L_00B032;
L_00B032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB032u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB032u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB032u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B032 TXA
    cpu.transfer("TXA");
    goto L_00B033;
L_00B033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB033u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB033u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B033 SEC
    cpu.setFlag('C', true);
    goto L_00B034;
L_00B034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB034u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB034u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B034 SBC
    cpu.sbc(0x10u);
    goto L_00B037;
L_00B037:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB037u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB037u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB037u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B037 TAX
    cpu.transfer("TAX");
    goto L_00B038;
L_00B038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB038u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB038u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B038 BPL -> $00B00F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00B00F; }
    goto L_00B03A;
L_00B03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B03A SEP
    cpu.sep(0x30u);
    goto L_00B03C;
L_00B03C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B03C PLB
    cpu.pop("PLB", hw);
    goto L_00B03D;
L_00B03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00B03D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00B03Du);return;} hw.unresolvedReturn(0x00B03Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_00B006_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00B006u: goto L_00B006;
    case 0x00B007u: goto L_00B007;
    case 0x00B008u: goto L_00B008;
    case 0x00B009u: goto L_00B009;
    case 0x00B00Cu: goto L_00B00C;
    case 0x00B00Fu: goto L_00B00F;
    case 0x00B012u: goto L_00B012;
    case 0x00B015u: goto L_00B015;
    case 0x00B017u: goto L_00B017;
    case 0x00B01Au: goto L_00B01A;
    case 0x00B01Bu: goto L_00B01B;
    case 0x00B01Eu: goto L_00B01E;
    case 0x00B01Fu: goto L_00B01F;
    case 0x00B021u: goto L_00B021;
    case 0x00B024u: goto L_00B024;
    case 0x00B027u: goto L_00B027;
    case 0x00B028u: goto L_00B028;
    case 0x00B02Au: goto L_00B02A;
    case 0x00B02Du: goto L_00B02D;
    case 0x00B02Eu: goto L_00B02E;
    case 0x00B02Fu: goto L_00B02F;
    case 0x00B030u: goto L_00B030;
    case 0x00B032u: goto L_00B032;
    case 0x00B033u: goto L_00B033;
    case 0x00B034u: goto L_00B034;
    case 0x00B037u: goto L_00B037;
    case 0x00B038u: goto L_00B038;
    case 0x00B03Au: goto L_00B03A;
    case 0x00B03Cu: goto L_00B03C;
    case 0x00B03Du: goto L_00B03D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00B006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB006u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB006u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B006 PHB
    cpu.push("PHB", hw);
    goto L_00B007;
L_00B007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB007u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB007u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B007 PHK
    cpu.push("PHK", hw);
    goto L_00B008;
L_00B008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB008u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB008u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B008 PLB
    cpu.pop("PLB", hw);
    goto L_00B009;
L_00B009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB009u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB009u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB009u, 6u, 3u, cpu.address("abs", 0xAFA3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B009 JSR -> $00AFA3 stack real
    { cpu.push16Value(hw,0xB00Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB00Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAFA3u), 0x00B009u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B00C;
L_00B00C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB00Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB00Cu,0x00B00Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B00C LDX
    cpu.setX(0x6Eu, 16);
    goto L_00B00F;
L_00B00F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB00Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B00F LDY
    cpu.setY(0x8u, 16);
    goto L_00B012;
L_00B012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB012u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB012u, 5u + 1u, 3u, cpu.address("absx", 0x0907u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B012 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x907u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B015;
L_00B015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB015u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB015u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B015 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_00B017;
L_00B017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB017u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB017u, 5u + 1u, 3u, cpu.address("absx", 0x0783u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B017 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x783u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B01A;
L_00B01A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Au,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B01A PHY
    cpu.push("PHY", hw);
    goto L_00B01B;
L_00B01B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Bu, 6u, 3u, cpu.address("abs", 0xAFC0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B01B JSR -> $00AFC0 stack real
    { cpu.push16Value(hw,0xB01Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB01Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAFC0u), 0x00B01Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B01E;
L_00B01E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB01Eu,0x00B01Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Eu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Eu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B01E PLY
    cpu.pop("PLY", hw);
    goto L_00B01F;
L_00B01F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B01F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B021;
L_00B021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB021u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB021u, 6u, 3u, cpu.address("absx", 0x0907u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B021 STA
    hw.write(cpu.address("absx", 0x907u), cpu.a, cpu.m8?8:16);
    goto L_00B024;
L_00B024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB024u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB024u, 5u + 1u, 3u, cpu.address("absx", 0x0783u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B024 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x783u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B027;
L_00B027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB027u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB027u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B027 SEC
    cpu.setFlag('C', true);
    goto L_00B028;
L_00B028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB028u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB028u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B028 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_00B02A;
L_00B02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB02Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Au, 6u, 3u, cpu.address("absx", 0x0979u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B02A STA
    hw.write(cpu.address("absx", 0x979u), cpu.a, cpu.m8?8:16);
    goto L_00B02D;
L_00B02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB02Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Du,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B02D DEX
    cpu.decReg('X');
    goto L_00B02E;
L_00B02E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB02Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B02E DEX
    cpu.decReg('X');
    goto L_00B02F;
L_00B02F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB02Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Fu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B02F DEY
    cpu.decReg('Y');
    goto L_00B030;
L_00B030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB030u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB030u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B030 BNE -> $00B012
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B012; }
    goto L_00B032;
L_00B032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB032u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB032u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB032u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B032 TXA
    cpu.transfer("TXA");
    goto L_00B033;
L_00B033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB033u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB033u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B033 SEC
    cpu.setFlag('C', true);
    goto L_00B034;
L_00B034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB034u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB034u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B034 SBC
    cpu.sbc(0x10u);
    goto L_00B037;
L_00B037:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB037u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB037u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB037u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B037 TAX
    cpu.transfer("TAX");
    goto L_00B038;
L_00B038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB038u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB038u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B038 BPL -> $00B00F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00B00F; }
    goto L_00B03A;
L_00B03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B03A SEP
    cpu.sep(0x30u);
    goto L_00B03C;
L_00B03C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B03C PLB
    cpu.pop("PLB", hw);
    goto L_00B03D;
L_00B03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00B03D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00B03Du);return;} hw.unresolvedReturn(0x00B03Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_00B8DE_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00B8DEu: goto L_00B8DE;
    case 0x00B8E0u: goto L_00B8E0;
    case 0x00B8E3u: goto L_00B8E3;
    case 0x00B8E6u: goto L_00B8E6;
    case 0x00B8E8u: goto L_00B8E8;
    case 0x00B8EAu: goto L_00B8EA;
    case 0x00B8ECu: goto L_00B8EC;
    case 0x00B8EDu: goto L_00B8ED;
    case 0x00B8EFu: goto L_00B8EF;
    case 0x00B8F1u: goto L_00B8F1;
    case 0x00B8F3u: goto L_00B8F3;
    case 0x00B8F5u: goto L_00B8F5;
    case 0x00B8F6u: goto L_00B8F6;
    case 0x00B8F8u: goto L_00B8F8;
    case 0x00B8FAu: goto L_00B8FA;
    case 0x00B8FDu: goto L_00B8FD;
    case 0x00B8FFu: goto L_00B8FF;
    case 0x00B901u: goto L_00B901;
    case 0x00B902u: goto L_00B902;
    case 0x00B903u: goto L_00B903;
    case 0x00B904u: goto L_00B904;
    case 0x00B906u: goto L_00B906;
    case 0x00B907u: goto L_00B907;
    case 0x00B909u: goto L_00B909;
    case 0x00B90Bu: goto L_00B90B;
    case 0x00B90Cu: goto L_00B90C;
    case 0x00B90Fu: goto L_00B90F;
    case 0x00B911u: goto L_00B911;
    case 0x00B912u: goto L_00B912;
    case 0x00B914u: goto L_00B914;
    case 0x00B916u: goto L_00B916;
    case 0x00B917u: goto L_00B917;
    case 0x00B919u: goto L_00B919;
    case 0x00B91Bu: goto L_00B91B;
    case 0x00B91Cu: goto L_00B91C;
    case 0x00B91Eu: goto L_00B91E;
    case 0x00B91Fu: goto L_00B91F;
    case 0x00B921u: goto L_00B921;
    case 0x00B924u: goto L_00B924;
    case 0x00B926u: goto L_00B926;
    case 0x00B928u: goto L_00B928;
    case 0x00B929u: goto L_00B929;
    case 0x00B92Au: goto L_00B92A;
    case 0x00B92Bu: goto L_00B92B;
    case 0x00B92Du: goto L_00B92D;
    case 0x00B930u: goto L_00B930;
    case 0x00B933u: goto L_00B933;
    case 0x00B935u: goto L_00B935;
    case 0x00B936u: goto L_00B936;
    case 0x00B938u: goto L_00B938;
    case 0x00B939u: goto L_00B939;
    case 0x00B93Bu: goto L_00B93B;
    case 0x00B93Du: goto L_00B93D;
    case 0x00B93Fu: goto L_00B93F;
    case 0x00B942u: goto L_00B942;
    case 0x00B944u: goto L_00B944;
    case 0x00B946u: goto L_00B946;
    case 0x00B947u: goto L_00B947;
    case 0x00B948u: goto L_00B948;
    case 0x00B94Au: goto L_00B94A;
    case 0x00B94Cu: goto L_00B94C;
    case 0x00B94Fu: goto L_00B94F;
    case 0x00B950u: goto L_00B950;
    case 0x00B953u: goto L_00B953;
    case 0x00B955u: goto L_00B955;
    case 0x00B956u: goto L_00B956;
    case 0x00B958u: goto L_00B958;
    case 0x00B959u: goto L_00B959;
    case 0x00B95Au: goto L_00B95A;
    case 0x00B95Cu: goto L_00B95C;
    case 0x00B95Du: goto L_00B95D;
    case 0x00B95Fu: goto L_00B95F;
    case 0x00B960u: goto L_00B960;
    case 0x00B961u: goto L_00B961;
    case 0x00B963u: goto L_00B963;
    case 0x00B966u: goto L_00B966;
    case 0x00B969u: goto L_00B969;
    case 0x00B96Au: goto L_00B96A;
    case 0x00B96Du: goto L_00B96D;
    case 0x00B96Eu: goto L_00B96E;
    case 0x00B96Fu: goto L_00B96F;
    case 0x00B970u: goto L_00B970;
    case 0x00B972u: goto L_00B972;
    case 0x00B973u: goto L_00B973;
    case 0x00B974u: goto L_00B974;
    case 0x00B976u: goto L_00B976;
    case 0x00B977u: goto L_00B977;
    case 0x00B978u: goto L_00B978;
    case 0x00B97Au: goto L_00B97A;
    case 0x00B97Cu: goto L_00B97C;
    case 0x00B97Eu: goto L_00B97E;
    case 0x00B980u: goto L_00B980;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00B8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8DE REP
    cpu.rep(0x10u);
    goto L_00B8E0;
L_00B8E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8E0 LDY
    cpu.setY(0x0u, 16);
    goto L_00B8E3;
L_00B8E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E3u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B8E3 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB8E5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB8E6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B8E3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B8E6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E3u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B8E3 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB8E5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB8E6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B8E3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B8E6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB8E3u,0x00B8E3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00B8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8E6 CMP
    cpu.compareA(0xFFu);
    goto L_00B8E8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8E6 CMP
    cpu.compareA(0xFFu);
    goto L_00B8E8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB8E6u,0x00B8E6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00B8E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8E8 BNE -> $00B8ED
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B8ED; }
    goto L_00B8EA;
L_00B8EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8EA SEP
    cpu.sep(0x10u);
    goto L_00B8EC;
L_00B8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ECu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ECu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B8EC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00B8ECu);return;} hw.unresolvedReturn(0x00B8ECu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00B8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8ED STA
    hw.write(cpu.address("dp", 0x8Fu), cpu.a, cpu.m8?8:16);
    goto L_00B8EF;
L_00B8EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8EF AND
    cpu.logicAnd(0xE0u);
    goto L_00B8F1;
L_00B8F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F1 CMP
    cpu.compareA(0xE0u);
    goto L_00B8F3;
L_00B8F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F3 BEQ -> $00B8FF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B8FF; }
    goto L_00B8F5;
L_00B8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F5u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F5u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B8F5 PHA
    cpu.push("PHA", hw);
    goto L_00B8F6;
L_00B8F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B8F8;
L_00B8F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F8 REP
    cpu.rep(0x20u);
    goto L_00B8FA;
L_00B8FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8FA AND
    cpu.logicAnd(0x1Fu);
    goto L_00B8FD;
L_00B8FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8FD BRA -> $00B911
    goto L_00B911;
L_00B8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8FF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B901;
L_00B901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B901 ASL
    cpu.aslA();
    goto L_00B902;
L_00B902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB902u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB902u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B902 ASL
    cpu.aslA();
    goto L_00B903;
L_00B903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB903u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB903u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B903 ASL
    cpu.aslA();
    goto L_00B904;
L_00B904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB904u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB904u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B904 AND
    cpu.logicAnd(0xE0u);
    goto L_00B906;
L_00B906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB906u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB906u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B906 PHA
    cpu.push("PHA", hw);
    goto L_00B907;
L_00B907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB907u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB907u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB907u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B907 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B909;
L_00B909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB909u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB909u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B909 AND
    cpu.logicAnd(0x3u);
    goto L_00B90B;
L_00B90B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B90B XBA
    cpu.xba();
    goto L_00B90C;
L_00B90C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Cu, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B90C JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB90Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB90Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B90Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B90F;
L_00B90F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB90Fu,0x00B90Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B90F REP
    cpu.rep(0x20u);
    goto L_00B911;
L_00B911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB911u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB911u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B911 INC
    cpu.inc('A');
    goto L_00B912;
L_00B912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB912u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB912u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B912 STA
    hw.write(cpu.address("dp", 0x8Du), cpu.a, cpu.m8?8:16);
    goto L_00B914;
L_00B914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB914u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB914u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB914u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B914 SEP
    cpu.sep(0x20u);
    goto L_00B916;
L_00B916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB916u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB916u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB916u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B916 PLA
    cpu.pop("PLA", hw);
    goto L_00B917;
L_00B917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB917u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB917u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB917u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B917 BEQ -> $00B930
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B930; }
    goto L_00B919;
L_00B919:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB919u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB919u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB919u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B919 BMI -> $00B966
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00B966; }
    goto L_00B91B;
L_00B91B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91B ASL
    cpu.aslA();
    goto L_00B91C;
L_00B91C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91C BPL -> $00B93F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00B93F; }
    goto L_00B91E;
L_00B91E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91E ASL
    cpu.aslA();
    goto L_00B91F;
L_00B91F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91F BPL -> $00B94C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00B94C; }
    goto L_00B921;
L_00B921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B921 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB923u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB924u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B921u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B924;
L_00B924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB924u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB924u,0x00B924u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B924 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B926;
L_00B926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB926u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB926u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B926 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B928;
L_00B928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB928u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB928u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB928u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B928 INC
    cpu.inc('A');
    goto L_00B929;
L_00B929:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB929u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB929u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB929u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B929 INY
    cpu.inc('Y');
    goto L_00B92A;
L_00B92A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Au,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B92A DEX
    cpu.decReg('X');
    goto L_00B92B;
L_00B92B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B92B BNE -> $00B926
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B926; }
    goto L_00B92D;
L_00B92D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Du, 3u, 3u, cpu.address("abs", 0xB8E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B92D JMP -> $00B8E3
    goto L_00B8E3;
L_00B930:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB930u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB930u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB930u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B930 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB932u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB933u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B930u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B933;
L_00B933:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB933u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB933u,0x00B933u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB933u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB933u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B933 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B935;
L_00B935:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB935u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB935u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB935u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B935 INY
    cpu.inc('Y');
    goto L_00B936;
L_00B936:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB936u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB936u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB936u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B936 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B938;
L_00B938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB938u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB938u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB938u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B938 DEX
    cpu.decReg('X');
    goto L_00B939;
L_00B939:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB939u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB939u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB939u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B939 STX
    hw.write(cpu.address("dp", 0x8Du), cpu.x, cpu.x8?8:16);
    goto L_00B93B;
L_00B93B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B93B BNE -> $00B930
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B930; }
    goto L_00B93D;
L_00B93D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B93D BRA -> $00B8E3
    goto L_00B8E3;
L_00B93F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Fu, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B93F JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB941u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB942u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B93Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B942;
L_00B942:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB942u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB942u,0x00B942u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB942u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB942u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B942 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B944;
L_00B944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB944u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB944u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB944u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B944 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B946;
L_00B946:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB946u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB946u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB946u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B946 INY
    cpu.inc('Y');
    goto L_00B947;
L_00B947:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB947u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB947u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB947u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B947 DEX
    cpu.decReg('X');
    goto L_00B948;
L_00B948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB948u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB948u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB948u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B948 BNE -> $00B944
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B944; }
    goto L_00B94A;
L_00B94A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B94A BRA -> $00B8E3
    goto L_00B8E3;
L_00B94C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B94C JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB94Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB94Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B94Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B94F;
L_00B94F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB94Fu,0x00B94Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B94F XBA
    cpu.xba();
    goto L_00B950;
L_00B950:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB950u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB950u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB950u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B950 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB952u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB953u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B950u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B953;
L_00B953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB953u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB953u,0x00B953u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB953u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB953u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B953 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B955;
L_00B955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB955u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB955u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B955 XBA
    cpu.xba();
    goto L_00B956;
L_00B956:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB956u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB956u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB956u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B956 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B958;
L_00B958:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB958u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB958u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB958u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B958 INY
    cpu.inc('Y');
    goto L_00B959;
L_00B959:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB959u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB959u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB959u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B959 DEX
    cpu.decReg('X');
    goto L_00B95A;
L_00B95A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B95A BEQ -> $00B963
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B963; }
    goto L_00B95C;
L_00B95C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B95C XBA
    cpu.xba();
    goto L_00B95D;
L_00B95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Du,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B95D STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B95F;
L_00B95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B95F INY
    cpu.inc('Y');
    goto L_00B960;
L_00B960:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB960u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB960u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB960u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B960 DEX
    cpu.decReg('X');
    goto L_00B961;
L_00B961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B961 BNE -> $00B955
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B955; }
    goto L_00B963;
L_00B963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB963u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB963u, 3u, 3u, cpu.address("abs", 0xB8E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B963 JMP -> $00B8E3
    goto L_00B8E3;
L_00B966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B966 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB968u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB969u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B966u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B969;
L_00B969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB969u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB969u,0x00B969u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB969u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB969u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B969 XBA
    cpu.xba();
    goto L_00B96A;
L_00B96A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Au, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B96A JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB96Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB96Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B96Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B96D;
L_00B96D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB96Du,0x00B96Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B96D TAX
    cpu.transfer("TAX");
    goto L_00B96E;
L_00B96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B96E PHY
    cpu.push("PHY", hw);
    goto L_00B96F;
L_00B96F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Fu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B96F TXY
    cpu.transfer("TXY");
    goto L_00B970;
L_00B970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B970 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B972;
L_00B972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB972u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B972 TYX
    cpu.transfer("TYX");
    goto L_00B973;
L_00B973:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB973u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB973u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB973u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B973 PLY
    cpu.pop("PLY", hw);
    goto L_00B974;
L_00B974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB974u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB974u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B974 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B976;
L_00B976:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB976u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB976u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB976u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B976 INY
    cpu.inc('Y');
    goto L_00B977;
L_00B977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB977u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB977u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B977 INX
    cpu.inc('X');
    goto L_00B978;
L_00B978:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB978u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB978u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB978u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B978 REP
    cpu.rep(0x20u);
    goto L_00B97A;
L_00B97A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Au,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B97A DEC
    cpu.decMem(hw, cpu.address("dp", 0x8Du), cpu.m8?8:16);
    goto L_00B97C;
L_00B97C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B97C SEP
    cpu.sep(0x20u);
    goto L_00B97E;
L_00B97E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B97E BNE -> $00B96E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B96E; }
    goto L_00B980;
L_00B980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB980u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB980u, 3u, 3u, cpu.address("abs", 0xB8E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B980 JMP -> $00B8E3
    goto L_00B8E3;
}

void sub_00B8DE_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00B8DEu: goto L_00B8DE;
    case 0x00B8E0u: goto L_00B8E0;
    case 0x00B8E3u: goto L_00B8E3;
    case 0x00B8E6u: goto L_00B8E6;
    case 0x00B8E8u: goto L_00B8E8;
    case 0x00B8EAu: goto L_00B8EA;
    case 0x00B8ECu: goto L_00B8EC;
    case 0x00B8EDu: goto L_00B8ED;
    case 0x00B8EFu: goto L_00B8EF;
    case 0x00B8F1u: goto L_00B8F1;
    case 0x00B8F3u: goto L_00B8F3;
    case 0x00B8F5u: goto L_00B8F5;
    case 0x00B8F6u: goto L_00B8F6;
    case 0x00B8F8u: goto L_00B8F8;
    case 0x00B8FAu: goto L_00B8FA;
    case 0x00B8FDu: goto L_00B8FD;
    case 0x00B8FFu: goto L_00B8FF;
    case 0x00B901u: goto L_00B901;
    case 0x00B902u: goto L_00B902;
    case 0x00B903u: goto L_00B903;
    case 0x00B904u: goto L_00B904;
    case 0x00B906u: goto L_00B906;
    case 0x00B907u: goto L_00B907;
    case 0x00B909u: goto L_00B909;
    case 0x00B90Bu: goto L_00B90B;
    case 0x00B90Cu: goto L_00B90C;
    case 0x00B90Fu: goto L_00B90F;
    case 0x00B911u: goto L_00B911;
    case 0x00B912u: goto L_00B912;
    case 0x00B914u: goto L_00B914;
    case 0x00B916u: goto L_00B916;
    case 0x00B917u: goto L_00B917;
    case 0x00B919u: goto L_00B919;
    case 0x00B91Bu: goto L_00B91B;
    case 0x00B91Cu: goto L_00B91C;
    case 0x00B91Eu: goto L_00B91E;
    case 0x00B91Fu: goto L_00B91F;
    case 0x00B921u: goto L_00B921;
    case 0x00B924u: goto L_00B924;
    case 0x00B926u: goto L_00B926;
    case 0x00B928u: goto L_00B928;
    case 0x00B929u: goto L_00B929;
    case 0x00B92Au: goto L_00B92A;
    case 0x00B92Bu: goto L_00B92B;
    case 0x00B92Du: goto L_00B92D;
    case 0x00B930u: goto L_00B930;
    case 0x00B933u: goto L_00B933;
    case 0x00B935u: goto L_00B935;
    case 0x00B936u: goto L_00B936;
    case 0x00B938u: goto L_00B938;
    case 0x00B939u: goto L_00B939;
    case 0x00B93Bu: goto L_00B93B;
    case 0x00B93Du: goto L_00B93D;
    case 0x00B93Fu: goto L_00B93F;
    case 0x00B942u: goto L_00B942;
    case 0x00B944u: goto L_00B944;
    case 0x00B946u: goto L_00B946;
    case 0x00B947u: goto L_00B947;
    case 0x00B948u: goto L_00B948;
    case 0x00B94Au: goto L_00B94A;
    case 0x00B94Cu: goto L_00B94C;
    case 0x00B94Fu: goto L_00B94F;
    case 0x00B950u: goto L_00B950;
    case 0x00B953u: goto L_00B953;
    case 0x00B955u: goto L_00B955;
    case 0x00B956u: goto L_00B956;
    case 0x00B958u: goto L_00B958;
    case 0x00B959u: goto L_00B959;
    case 0x00B95Au: goto L_00B95A;
    case 0x00B95Cu: goto L_00B95C;
    case 0x00B95Du: goto L_00B95D;
    case 0x00B95Fu: goto L_00B95F;
    case 0x00B960u: goto L_00B960;
    case 0x00B961u: goto L_00B961;
    case 0x00B963u: goto L_00B963;
    case 0x00B966u: goto L_00B966;
    case 0x00B969u: goto L_00B969;
    case 0x00B96Au: goto L_00B96A;
    case 0x00B96Du: goto L_00B96D;
    case 0x00B96Eu: goto L_00B96E;
    case 0x00B96Fu: goto L_00B96F;
    case 0x00B970u: goto L_00B970;
    case 0x00B972u: goto L_00B972;
    case 0x00B973u: goto L_00B973;
    case 0x00B974u: goto L_00B974;
    case 0x00B976u: goto L_00B976;
    case 0x00B977u: goto L_00B977;
    case 0x00B978u: goto L_00B978;
    case 0x00B97Au: goto L_00B97A;
    case 0x00B97Cu: goto L_00B97C;
    case 0x00B97Eu: goto L_00B97E;
    case 0x00B980u: goto L_00B980;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00B8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8DE REP
    cpu.rep(0x10u);
    goto L_00B8E0;
L_00B8E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8E0 LDY
    cpu.setY(0x0u, 16);
    goto L_00B8E3;
L_00B8E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E3u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B8E3 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB8E5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB8E6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B8E3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B8E6;
L_00B8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB8E6u,0x00B8E6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8E6 CMP
    cpu.compareA(0xFFu);
    goto L_00B8E8;
L_00B8E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8E8 BNE -> $00B8ED
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B8ED; }
    goto L_00B8EA;
L_00B8EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8EA SEP
    cpu.sep(0x10u);
    goto L_00B8EC;
L_00B8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ECu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ECu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B8EC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00B8ECu);return;} hw.unresolvedReturn(0x00B8ECu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00B8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8ED STA
    hw.write(cpu.address("dp", 0x8Fu), cpu.a, cpu.m8?8:16);
    goto L_00B8EF;
L_00B8EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8EF AND
    cpu.logicAnd(0xE0u);
    goto L_00B8F1;
L_00B8F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F1 CMP
    cpu.compareA(0xE0u);
    goto L_00B8F3;
L_00B8F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F3 BEQ -> $00B8FF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B8FF; }
    goto L_00B8F5;
L_00B8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F5u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F5u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B8F5 PHA
    cpu.push("PHA", hw);
    goto L_00B8F6;
L_00B8F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B8F8;
L_00B8F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F8 REP
    cpu.rep(0x20u);
    goto L_00B8FA;
L_00B8FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8FA AND
    cpu.logicAnd(0x1Fu);
    goto L_00B8FD;
L_00B8FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8FD BRA -> $00B911
    goto L_00B911;
L_00B8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8FF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B901;
L_00B901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B901 ASL
    cpu.aslA();
    goto L_00B902;
L_00B902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB902u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB902u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B902 ASL
    cpu.aslA();
    goto L_00B903;
L_00B903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB903u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB903u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B903 ASL
    cpu.aslA();
    goto L_00B904;
L_00B904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB904u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB904u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B904 AND
    cpu.logicAnd(0xE0u);
    goto L_00B906;
L_00B906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB906u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB906u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B906 PHA
    cpu.push("PHA", hw);
    goto L_00B907;
L_00B907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB907u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB907u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB907u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B907 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B909;
L_00B909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB909u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB909u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B909 AND
    cpu.logicAnd(0x3u);
    goto L_00B90B;
L_00B90B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B90B XBA
    cpu.xba();
    goto L_00B90C;
L_00B90C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Cu, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B90C JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB90Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB90Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B90Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B90F;
L_00B90F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB90Fu,0x00B90Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B90F REP
    cpu.rep(0x20u);
    goto L_00B911;
L_00B911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB911u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB911u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B911 INC
    cpu.inc('A');
    goto L_00B912;
L_00B912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB912u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB912u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B912 STA
    hw.write(cpu.address("dp", 0x8Du), cpu.a, cpu.m8?8:16);
    goto L_00B914;
L_00B914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB914u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB914u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB914u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B914 SEP
    cpu.sep(0x20u);
    goto L_00B916;
L_00B916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB916u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB916u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB916u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B916 PLA
    cpu.pop("PLA", hw);
    goto L_00B917;
L_00B917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB917u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB917u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB917u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B917 BEQ -> $00B930
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B930; }
    goto L_00B919;
L_00B919:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB919u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB919u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB919u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B919 BMI -> $00B966
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00B966; }
    goto L_00B91B;
L_00B91B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91B ASL
    cpu.aslA();
    goto L_00B91C;
L_00B91C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91C BPL -> $00B93F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00B93F; }
    goto L_00B91E;
L_00B91E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91E ASL
    cpu.aslA();
    goto L_00B91F;
L_00B91F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91F BPL -> $00B94C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00B94C; }
    goto L_00B921;
L_00B921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B921 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB923u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB924u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B921u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B924;
L_00B924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB924u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB924u,0x00B924u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B924 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B926;
L_00B926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB926u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB926u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B926 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B928;
L_00B928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB928u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB928u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB928u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B928 INC
    cpu.inc('A');
    goto L_00B929;
L_00B929:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB929u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB929u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB929u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B929 INY
    cpu.inc('Y');
    goto L_00B92A;
L_00B92A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Au,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B92A DEX
    cpu.decReg('X');
    goto L_00B92B;
L_00B92B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B92B BNE -> $00B926
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B926; }
    goto L_00B92D;
L_00B92D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Du, 3u, 3u, cpu.address("abs", 0xB8E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B92D JMP -> $00B8E3
    goto L_00B8E3;
L_00B930:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB930u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB930u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB930u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B930 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB932u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB933u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B930u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B933;
L_00B933:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB933u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB933u,0x00B933u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB933u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB933u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B933 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B935;
L_00B935:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB935u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB935u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB935u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B935 INY
    cpu.inc('Y');
    goto L_00B936;
L_00B936:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB936u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB936u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB936u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B936 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B938;
L_00B938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB938u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB938u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB938u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B938 DEX
    cpu.decReg('X');
    goto L_00B939;
L_00B939:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB939u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB939u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB939u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B939 STX
    hw.write(cpu.address("dp", 0x8Du), cpu.x, cpu.x8?8:16);
    goto L_00B93B;
L_00B93B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B93B BNE -> $00B930
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B930; }
    goto L_00B93D;
L_00B93D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B93D BRA -> $00B8E3
    goto L_00B8E3;
L_00B93F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Fu, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B93F JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB941u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB942u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B93Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B942;
L_00B942:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB942u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB942u,0x00B942u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB942u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB942u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B942 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B944;
L_00B944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB944u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB944u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB944u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B944 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B946;
L_00B946:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB946u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB946u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB946u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B946 INY
    cpu.inc('Y');
    goto L_00B947;
L_00B947:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB947u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB947u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB947u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B947 DEX
    cpu.decReg('X');
    goto L_00B948;
L_00B948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB948u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB948u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB948u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B948 BNE -> $00B944
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B944; }
    goto L_00B94A;
L_00B94A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B94A BRA -> $00B8E3
    goto L_00B8E3;
L_00B94C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B94C JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB94Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB94Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B94Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B94F;
L_00B94F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB94Fu,0x00B94Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B94F XBA
    cpu.xba();
    goto L_00B950;
L_00B950:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB950u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB950u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB950u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B950 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB952u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB953u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B950u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B953;
L_00B953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB953u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB953u,0x00B953u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB953u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB953u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B953 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B955;
L_00B955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB955u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB955u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B955 XBA
    cpu.xba();
    goto L_00B956;
L_00B956:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB956u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB956u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB956u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B956 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B958;
L_00B958:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB958u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB958u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB958u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B958 INY
    cpu.inc('Y');
    goto L_00B959;
L_00B959:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB959u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB959u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB959u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B959 DEX
    cpu.decReg('X');
    goto L_00B95A;
L_00B95A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B95A BEQ -> $00B963
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B963; }
    goto L_00B95C;
L_00B95C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B95C XBA
    cpu.xba();
    goto L_00B95D;
L_00B95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Du,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B95D STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B95F;
L_00B95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B95F INY
    cpu.inc('Y');
    goto L_00B960;
L_00B960:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB960u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB960u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB960u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B960 DEX
    cpu.decReg('X');
    goto L_00B961;
L_00B961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B961 BNE -> $00B955
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B955; }
    goto L_00B963;
L_00B963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB963u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB963u, 3u, 3u, cpu.address("abs", 0xB8E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B963 JMP -> $00B8E3
    goto L_00B8E3;
L_00B966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B966 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB968u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB969u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B966u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B969;
L_00B969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB969u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB969u,0x00B969u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB969u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB969u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B969 XBA
    cpu.xba();
    goto L_00B96A;
L_00B96A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Au, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B96A JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB96Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB96Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B96Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B96D;
L_00B96D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB96Du,0x00B96Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B96D TAX
    cpu.transfer("TAX");
    goto L_00B96E;
L_00B96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B96E PHY
    cpu.push("PHY", hw);
    goto L_00B96F;
L_00B96F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Fu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B96F TXY
    cpu.transfer("TXY");
    goto L_00B970;
L_00B970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B970 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B972;
L_00B972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB972u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B972 TYX
    cpu.transfer("TYX");
    goto L_00B973;
L_00B973:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB973u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB973u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB973u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B973 PLY
    cpu.pop("PLY", hw);
    goto L_00B974;
L_00B974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB974u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB974u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B974 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B976;
L_00B976:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB976u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB976u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB976u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B976 INY
    cpu.inc('Y');
    goto L_00B977;
L_00B977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB977u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB977u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B977 INX
    cpu.inc('X');
    goto L_00B978;
L_00B978:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB978u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB978u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB978u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B978 REP
    cpu.rep(0x20u);
    goto L_00B97A;
L_00B97A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Au,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B97A DEC
    cpu.decMem(hw, cpu.address("dp", 0x8Du), cpu.m8?8:16);
    goto L_00B97C;
L_00B97C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B97C SEP
    cpu.sep(0x20u);
    goto L_00B97E;
L_00B97E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B97E BNE -> $00B96E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B96E; }
    goto L_00B980;
L_00B980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB980u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB980u, 3u, 3u, cpu.address("abs", 0xB8E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B980 JMP -> $00B8E3
    goto L_00B8E3;
}

void sub_00EBDD_E0M1X1C1_part8(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE68u: goto L_00EE68;
    case 0x00EE69u: goto L_00EE69;
    case 0x00EE6Bu: goto L_00EE6B;
    case 0x00EE6Eu: goto L_00EE6E;
    case 0x00EE70u: goto L_00EE70;
    case 0x00EE72u: goto L_00EE72;
    case 0x00EE73u: goto L_00EE73;
    case 0x00EE76u: goto L_00EE76;
    case 0x00EE77u: goto L_00EE77;
    case 0x00EE78u: goto L_00EE78;
    case 0x00EE79u: goto L_00EE79;
    case 0x00EE7Au: goto L_00EE7A;
    case 0x00EE7Bu: goto L_00EE7B;
    case 0x00EE7Cu: goto L_00EE7C;
    case 0x00EE7Du: goto L_00EE7D;
    case 0x00EE7Fu: goto L_00EE7F;
    case 0x00EE80u: goto L_00EE80;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE68u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE68u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE68u, 5u + 1u, 3u, cpu.address("absy", 0x18F0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE68 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x18F0u), cpu.m8?8:16));
    goto L_00EE6B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE68u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE68u, 5u + ((((0x18F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x18F0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE68 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x18F0u), cpu.m8?8:16));
    goto L_00EE6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE68u,0x00EE68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE69u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE69u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE69u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE69 BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE83u,0x00EE69u); return; }
    goto L_00EE6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE69u,0x00EE69u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE6Bu))return;
  // 16 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu, 5u, 3u, cpu.address("abs", 0x140Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x140Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE6E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x140Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE6E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x140Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE6E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE6Bu,0x00EE6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE6Eu))return;
  // 16 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6E BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE83u,0x00EE6Eu); return; }
    goto L_00EE70;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6E BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE83u,0x00EE6Eu); return; }
    goto L_00EE70;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6E BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE83u,0x00EE6Eu); return; }
    goto L_00EE70;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE6Eu,0x00EE6Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE70u))return;
  // 16 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE70 LDA
    cpu.setA(0x2221u, 16);
    goto L_00EE73;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE70 LDA
    cpu.setA(0x2221u, 16);
    goto L_00EE73;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE70 LDA
    cpu.setA(0x21u, 8);
    goto L_00EE72;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE70u,0x00EE70u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE72u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE72u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE72u, 8u, 4u, 0x00F17Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EE72 JSL -> $00F17F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEE75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE76u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F17Fu, 0x00EE72u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE72u,0x00EE72u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE73u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE73u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE73u, 6u, 4u, ((0x8000F1u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE73 ADC
    cpu.adc(hw.readW(((0x8000F1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00EE77;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE73u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE73u, 6u, 4u, ((0x8000F1u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE73 ADC
    cpu.adc(hw.readW(((0x8000F1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00EE77;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE73u,0x00EE73u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE76u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE76u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE76u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE76 BRA -> $00EE1D
    hw.requestDispatch(0x00EE1Du,0x00EE76u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE76u,0x00EE76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE77u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE77u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE77u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE77 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE79;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE77u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE77u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE77 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE79;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE77u,0x00EE77u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE78u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE78u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE78 CMP
    cpu.compareA(0x32u);
    goto L_00EE7A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE78u,0x00EE78u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE79u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE79u,cpu,0x32u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE79u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xD0u) & 0xFFFFu), 2u, 0u);
    // $00EE79 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirect(hw, 0xD0u), cpu.m8?8:16));
    goto L_00EE7B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE79u,cpu,0x32u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE79u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xD0u) & 0xFFFFu), 2u, 0u);
    // $00EE79 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirect(hw, 0xD0u), cpu.m8?8:16));
    goto L_00EE7B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE79u,0x00EE79u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Au))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7A BNE -> $00EE7F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE7F; }
    goto L_00EE7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Au,0x00EE7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Bu))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Bu,cpu,0x03u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Bu, 5u, 2u, cpu.addressStack(0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7B ORA
    cpu.logicOr(hw.readW(cpu.addressStack(0x9Cu), cpu.m8?8:16));
    goto L_00EE7D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Bu,cpu,0x03u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Bu, 5u, 2u, cpu.addressStack(0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7B ORA
    cpu.logicOr(hw.readW(cpu.addressStack(0x9Cu), cpu.m8?8:16));
    goto L_00EE7D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Bu,0x00EE7Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Cu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Cu, 4u, 3u, cpu.address("abs", 0x1909u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7C STZ
    hw.write(cpu.address("abs", 0x1909u), 0, cpu.m8?8:16);
    goto L_00EE7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Cu,0x00EE7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Du))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7D ORA
    cpu.logicOr(0x2219u);
    goto L_00EE80;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7D ORA
    cpu.logicOr(0x2219u);
    goto L_00EE80;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Du,0x00EE7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Fu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Fu, 8u, 4u, 0x00F120u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EE7F JSL -> $00F120 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEE82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE83u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F120u, 0x00EE7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE83u,0x00EE7Fu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Fu,0x00EE7Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE80u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE80u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE80u, 6u, 3u, cpu.address("abs", 0x00F1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE80 JSR -> $0000F1 stack real
    { cpu.push16Value(hw,0xEE82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE83u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x00F1u), 0x00EE80u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE83u,0x00EE80u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE80u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE80u, 6u, 3u, cpu.address("abs", 0x00F1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE80 JSR -> $0000F1 stack real
    { cpu.push16Value(hw,0xEE82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE83u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x00F1u), 0x00EE80u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE83u,0x00EE80u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE80u,0x00EE80u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part8(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE68u: goto L_00EE68;
    case 0x00EE69u: goto L_00EE69;
    case 0x00EE6Bu: goto L_00EE6B;
    case 0x00EE6Eu: goto L_00EE6E;
    case 0x00EE70u: goto L_00EE70;
    case 0x00EE72u: goto L_00EE72;
    case 0x00EE73u: goto L_00EE73;
    case 0x00EE76u: goto L_00EE76;
    case 0x00EE77u: goto L_00EE77;
    case 0x00EE78u: goto L_00EE78;
    case 0x00EE79u: goto L_00EE79;
    case 0x00EE7Au: goto L_00EE7A;
    case 0x00EE7Bu: goto L_00EE7B;
    case 0x00EE7Cu: goto L_00EE7C;
    case 0x00EE7Du: goto L_00EE7D;
    case 0x00EE7Fu: goto L_00EE7F;
    case 0x00EE80u: goto L_00EE80;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE68u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE68u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE68u, 5u + 1u, 3u, cpu.address("absy", 0x18F0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE68 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x18F0u), cpu.m8?8:16));
    goto L_00EE6B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE68u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE68u, 5u + ((((0x18F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x18F0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE68 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x18F0u), cpu.m8?8:16));
    goto L_00EE6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE68u,0x00EE68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE69u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE69u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE69u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE69 BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE83u,0x00EE69u); return; }
    goto L_00EE6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE69u,0x00EE69u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE6Bu))return;
  // 16 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu, 5u, 3u, cpu.address("abs", 0x140Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x140Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE6E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x140Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE6E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x140Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE6E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE6Bu,0x00EE6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE6Eu))return;
  // 16 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6E BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE83u,0x00EE6Eu); return; }
    goto L_00EE70;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6E BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE83u,0x00EE6Eu); return; }
    goto L_00EE70;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6E BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE83u,0x00EE6Eu); return; }
    goto L_00EE70;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE6Eu,0x00EE6Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE70u))return;
  // 16 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE70 LDA
    cpu.setA(0x2221u, 16);
    goto L_00EE73;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE70 LDA
    cpu.setA(0x2221u, 16);
    goto L_00EE73;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE70 LDA
    cpu.setA(0x21u, 8);
    goto L_00EE72;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE70u,0x00EE70u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE72u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE72u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE72u, 8u, 4u, 0x00F17Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EE72 JSL -> $00F17F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEE75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE76u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F17Fu, 0x00EE72u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE72u,0x00EE72u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE73u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE73u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE73u, 6u, 4u, ((0x8000F1u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE73 ADC
    cpu.adc(hw.readW(((0x8000F1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00EE77;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE73u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE73u, 6u, 4u, ((0x8000F1u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE73 ADC
    cpu.adc(hw.readW(((0x8000F1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00EE77;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE73u,0x00EE73u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE76u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE76u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE76u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE76 BRA -> $00EE1D
    hw.requestDispatch(0x00EE1Du,0x00EE76u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE76u,0x00EE76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE77u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE77u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE77u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE77 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE79;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE77u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE77u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE77 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE79;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE77u,0x00EE77u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE78u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE78u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE78 CMP
    cpu.compareA(0x32u);
    goto L_00EE7A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE78u,0x00EE78u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE79u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE79u,cpu,0x32u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE79u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xD0u) & 0xFFFFu), 2u, 0u);
    // $00EE79 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirect(hw, 0xD0u), cpu.m8?8:16));
    goto L_00EE7B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE79u,cpu,0x32u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE79u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xD0u) & 0xFFFFu), 2u, 0u);
    // $00EE79 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirect(hw, 0xD0u), cpu.m8?8:16));
    goto L_00EE7B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE79u,0x00EE79u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Au))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7A BNE -> $00EE7F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE7F; }
    goto L_00EE7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Au,0x00EE7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Bu))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Bu,cpu,0x03u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Bu, 5u, 2u, cpu.addressStack(0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7B ORA
    cpu.logicOr(hw.readW(cpu.addressStack(0x9Cu), cpu.m8?8:16));
    goto L_00EE7D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Bu,cpu,0x03u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Bu, 5u, 2u, cpu.addressStack(0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7B ORA
    cpu.logicOr(hw.readW(cpu.addressStack(0x9Cu), cpu.m8?8:16));
    goto L_00EE7D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Bu,0x00EE7Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Cu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Cu, 4u, 3u, cpu.address("abs", 0x1909u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7C STZ
    hw.write(cpu.address("abs", 0x1909u), 0, cpu.m8?8:16);
    goto L_00EE7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Cu,0x00EE7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Du))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7D ORA
    cpu.logicOr(0x2219u);
    goto L_00EE80;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7D ORA
    cpu.logicOr(0x2219u);
    goto L_00EE80;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Du,0x00EE7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Fu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Fu, 8u, 4u, 0x00F120u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EE7F JSL -> $00F120 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEE82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE83u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F120u, 0x00EE7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE83u,0x00EE7Fu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Fu,0x00EE7Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE80u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE80u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE80u, 6u, 3u, cpu.address("abs", 0x00F1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE80 JSR -> $0000F1 stack real
    { cpu.push16Value(hw,0xEE82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE83u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x00F1u), 0x00EE80u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE83u,0x00EE80u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE80u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE80u, 6u, 3u, cpu.address("abs", 0x00F1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE80 JSR -> $0000F1 stack real
    { cpu.push16Value(hw,0xEE82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE83u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x00F1u), 0x00EE80u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE83u,0x00EE80u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE80u,0x00EE80u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1C1_part12(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EEBBu: goto L_00EEBB;
    case 0x00EEBEu: goto L_00EEBE;
    case 0x00EEC1u: goto L_00EEC1;
    case 0x00EEC2u: goto L_00EEC2;
    case 0x00EEC4u: goto L_00EEC4;
    case 0x00EEC7u: goto L_00EEC7;
    case 0x00EEC9u: goto L_00EEC9;
    case 0x00EECCu: goto L_00EECC;
    case 0x00EECEu: goto L_00EECE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EEBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBBu))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu, 5u, 3u, cpu.address("abs", 0x191Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEBB STX
    hw.write(cpu.address("abs", 0x191Eu), cpu.x, cpu.x8?8:16);
    goto L_00EEBE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu, 4u, 3u, cpu.address("abs", 0x191Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEBB STX
    hw.write(cpu.address("abs", 0x191Eu), cpu.x, cpu.x8?8:16);
    goto L_00EEBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBBu,0x00EEBBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBEu))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu, 6u, 3u, cpu.address("abs", 0xFA45u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EEBE JSR -> $00FA45 stack real
    { cpu.push16Value(hw,0xEEC0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEC1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFA45u), 0x00EEBEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEC1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu, 6u, 3u, cpu.address("abs", 0xFA45u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EEBE JSR -> $00FA45 stack real
    { cpu.push16Value(hw,0xEEC0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEC1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFA45u), 0x00EEBEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBEu,0x00EEBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC1u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EEC1 PLY
    cpu.pop("PLY", hw);
    goto L_00EEC2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EEC1 PLY
    cpu.pop("PLY", hw);
    goto L_00EEC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC1u,0x00EEC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC2u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC2 LDA
    cpu.setA(0xCu, 8);
    goto L_00EEC4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC2 LDA
    cpu.setA(0xCu, 8);
    goto L_00EEC4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC2u,0x00EEC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC4u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC4 STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_00EEC7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC4 STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_00EEC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC4u,0x00EEC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC7u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC7 LDA
    cpu.setA(0xFFu, 8);
    goto L_00EEC9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC7 LDA
    cpu.setA(0xFFu, 8);
    goto L_00EEC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC7u,0x00EEC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC9u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC9 STA
    hw.write(cpu.address("abs", 0xDDAu), cpu.a, cpu.m8?8:16);
    goto L_00EECC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC9 STA
    hw.write(cpu.address("abs", 0xDDAu), cpu.a, cpu.m8?8:16);
    goto L_00EECC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC9u,0x00EEC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EECC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEECCu))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EECC LDA
    cpu.setA(0x8u, 8);
    goto L_00EECE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EECC LDA
    cpu.setA(0x8u, 8);
    goto L_00EECE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEECCu,0x00EECCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EECE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEECEu))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECEu, 4u, 3u, cpu.address("abs", 0x1493u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EECE STA
    hw.write(cpu.address("abs", 0x1493u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED1u,0x00EECEu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECEu, 4u, 3u, cpu.address("abs", 0x1493u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EECE STA
    hw.write(cpu.address("abs", 0x1493u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED1u,0x00EECEu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEECEu,0x00EECEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part12(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EEBBu: goto L_00EEBB;
    case 0x00EEBEu: goto L_00EEBE;
    case 0x00EEC1u: goto L_00EEC1;
    case 0x00EEC2u: goto L_00EEC2;
    case 0x00EEC4u: goto L_00EEC4;
    case 0x00EEC7u: goto L_00EEC7;
    case 0x00EEC9u: goto L_00EEC9;
    case 0x00EECCu: goto L_00EECC;
    case 0x00EECEu: goto L_00EECE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EEBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBBu))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu, 5u, 3u, cpu.address("abs", 0x191Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEBB STX
    hw.write(cpu.address("abs", 0x191Eu), cpu.x, cpu.x8?8:16);
    goto L_00EEBE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu, 4u, 3u, cpu.address("abs", 0x191Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEBB STX
    hw.write(cpu.address("abs", 0x191Eu), cpu.x, cpu.x8?8:16);
    goto L_00EEBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBBu,0x00EEBBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBEu))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu, 6u, 3u, cpu.address("abs", 0xFA45u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EEBE JSR -> $00FA45 stack real
    { cpu.push16Value(hw,0xEEC0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEC1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFA45u), 0x00EEBEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEC1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu, 6u, 3u, cpu.address("abs", 0xFA45u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EEBE JSR -> $00FA45 stack real
    { cpu.push16Value(hw,0xEEC0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEC1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFA45u), 0x00EEBEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBEu,0x00EEBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC1u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EEC1 PLY
    cpu.pop("PLY", hw);
    goto L_00EEC2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EEC1 PLY
    cpu.pop("PLY", hw);
    goto L_00EEC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC1u,0x00EEC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC2u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC2 LDA
    cpu.setA(0xCu, 8);
    goto L_00EEC4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC2 LDA
    cpu.setA(0xCu, 8);
    goto L_00EEC4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC2u,0x00EEC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC4u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC4 STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_00EEC7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC4 STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_00EEC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC4u,0x00EEC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC7u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC7 LDA
    cpu.setA(0xFFu, 8);
    goto L_00EEC9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC7 LDA
    cpu.setA(0xFFu, 8);
    goto L_00EEC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC7u,0x00EEC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC9u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC9 STA
    hw.write(cpu.address("abs", 0xDDAu), cpu.a, cpu.m8?8:16);
    goto L_00EECC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC9 STA
    hw.write(cpu.address("abs", 0xDDAu), cpu.a, cpu.m8?8:16);
    goto L_00EECC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC9u,0x00EEC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EECC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEECCu))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EECC LDA
    cpu.setA(0x8u, 8);
    goto L_00EECE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EECC LDA
    cpu.setA(0x8u, 8);
    goto L_00EECE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEECCu,0x00EECCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EECE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEECEu))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECEu, 4u, 3u, cpu.address("abs", 0x1493u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EECE STA
    hw.write(cpu.address("abs", 0x1493u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED1u,0x00EECEu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECEu, 4u, 3u, cpu.address("abs", 0x1493u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EECE STA
    hw.write(cpu.address("abs", 0x1493u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED1u,0x00EECEu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEECEu,0x00EECEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00F44D_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F44Du: goto L_00F44D;
    case 0x00F44Eu: goto L_00F44E;
    case 0x00F44Fu: goto L_00F44F;
    case 0x00F451u: goto L_00F451;
    case 0x00F453u: goto L_00F453;
    case 0x00F454u: goto L_00F454;
    case 0x00F457u: goto L_00F457;
    case 0x00F459u: goto L_00F459;
    case 0x00F45Bu: goto L_00F45B;
    case 0x00F45Cu: goto L_00F45C;
    case 0x00F45Fu: goto L_00F45F;
    case 0x00F461u: goto L_00F461;
    case 0x00F464u: goto L_00F464;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F44D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF44Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF44Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF44Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F44D INX
    cpu.inc('X');
    goto L_00F44E;
L_00F44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF44Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF44Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF44Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F44E INX
    cpu.inc('X');
    goto L_00F44F;
L_00F44F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF44Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF44Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF44Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F44F REP
    cpu.rep(0x20u);
    goto L_00F451;
L_00F451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF451u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF451u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F451 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F453;
L_00F453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF453u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF453u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F453 CLC
    cpu.setFlag('C', false);
    goto L_00F454;
L_00F454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF454u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF454u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF454u, 5u + ((((0xE830u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE830u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F454 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE830u), cpu.m8?8:16));
    goto L_00F457;
L_00F457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF457u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF457u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF457u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F457 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_00F459;
L_00F459:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF459u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF459u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF459u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F459 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F45B;
L_00F45B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF45Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF45Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF45Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F45B CLC
    cpu.setFlag('C', false);
    goto L_00F45C;
L_00F45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF45Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF45Cu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF45Cu, 5u + ((((0xE89Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE89Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F45C ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE89Cu), cpu.m8?8:16));
    goto L_00F45F;
L_00F45F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF45Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF45Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF45Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F45F STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_00F461;
L_00F461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF461u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF461u, 6u, 3u, cpu.address("abs", 0xF465u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F461 JSR -> $00F465 stack real
    { cpu.push16Value(hw,0xF463u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF464u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF465u), 0x00F461u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F464;
L_00F464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF464u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF464u,0x00F464u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF464u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF464u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F464 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F464u);return;} hw.unresolvedReturn(0x00F464u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00F44D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F44Du: goto L_00F44D;
    case 0x00F44Eu: goto L_00F44E;
    case 0x00F44Fu: goto L_00F44F;
    case 0x00F451u: goto L_00F451;
    case 0x00F453u: goto L_00F453;
    case 0x00F454u: goto L_00F454;
    case 0x00F457u: goto L_00F457;
    case 0x00F459u: goto L_00F459;
    case 0x00F45Bu: goto L_00F45B;
    case 0x00F45Cu: goto L_00F45C;
    case 0x00F45Fu: goto L_00F45F;
    case 0x00F461u: goto L_00F461;
    case 0x00F464u: goto L_00F464;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F44D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF44Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF44Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF44Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F44D INX
    cpu.inc('X');
    goto L_00F44E;
L_00F44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF44Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF44Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF44Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F44E INX
    cpu.inc('X');
    goto L_00F44F;
L_00F44F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF44Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF44Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF44Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F44F REP
    cpu.rep(0x20u);
    goto L_00F451;
L_00F451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF451u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF451u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F451 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F453;
L_00F453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF453u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF453u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F453 CLC
    cpu.setFlag('C', false);
    goto L_00F454;
L_00F454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF454u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF454u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF454u, 5u + ((((0xE830u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE830u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F454 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE830u), cpu.m8?8:16));
    goto L_00F457;
L_00F457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF457u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF457u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF457u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F457 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_00F459;
L_00F459:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF459u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF459u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF459u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F459 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F45B;
L_00F45B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF45Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF45Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF45Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F45B CLC
    cpu.setFlag('C', false);
    goto L_00F45C;
L_00F45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF45Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF45Cu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF45Cu, 5u + ((((0xE89Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE89Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F45C ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE89Cu), cpu.m8?8:16));
    goto L_00F45F;
L_00F45F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF45Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF45Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF45Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F45F STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_00F461;
L_00F461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF461u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF461u, 6u, 3u, cpu.address("abs", 0xF465u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F461 JSR -> $00F465 stack real
    { cpu.push16Value(hw,0xF463u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF464u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF465u), 0x00F461u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F464;
L_00F464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF464u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF464u,0x00F464u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF464u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF464u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F464 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F464u);return;} hw.unresolvedReturn(0x00F464u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_018008_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018008u: goto L_018008;
    case 0x01800Bu: goto L_01800B;
    case 0x01800Du: goto L_01800D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8008u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8008u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018008 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01800B;
L_01800B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01800B AND
    cpu.logicAnd(0x3u);
    goto L_01800D;
L_01800D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01800D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01800Du);return;} hw.unresolvedReturn(0x01800Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_018008_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018008u: goto L_018008;
    case 0x01800Bu: goto L_01800B;
    case 0x01800Du: goto L_01800D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8008u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8008u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018008 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01800B;
L_01800B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01800B AND
    cpu.logicAnd(0x3u);
    goto L_01800D;
L_01800D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01800D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01800Du);return;} hw.unresolvedReturn(0x01800Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01EA70_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01EA70u: goto L_01EA70;
    case 0x01EA73u: goto L_01EA73;
    case 0x01EA75u: goto L_01EA75;
    case 0x01EA78u: goto L_01EA78;
    case 0x01EA7Bu: goto L_01EA7B;
    case 0x01EA7Eu: goto L_01EA7E;
    case 0x01EA7Fu: goto L_01EA7F;
    case 0x01EA80u: goto L_01EA80;
    case 0x01EA83u: goto L_01EA83;
    case 0x01EA84u: goto L_01EA84;
    case 0x01EA85u: goto L_01EA85;
    case 0x01EA86u: goto L_01EA86;
    case 0x01EA89u: goto L_01EA89;
    case 0x01EA8Au: goto L_01EA8A;
    case 0x01EA8Bu: goto L_01EA8B;
    case 0x01EA8Eu: goto L_01EA8E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01EA70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA70u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA70u, 4u, 3u, cpu.address("abs", 0x18E2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA70 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x18E2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EA73;
L_01EA73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA73u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA73u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA73 BEQ -> $01EA8E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EA8E; }
    goto L_01EA75;
L_01EA75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA75u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA75u, 4u, 3u, cpu.address("abs", 0x188Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA75 STZ
    hw.write(cpu.address("abs", 0x188Bu), 0, cpu.m8?8:16);
    goto L_01EA78;
L_01EA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA78u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA78u, 4u, 3u, cpu.address("abs", 0x191Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA78 STZ
    hw.write(cpu.address("abs", 0x191Cu), 0, cpu.m8?8:16);
    goto L_01EA7B;
L_01EA7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Bu, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA7B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x15E9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EA7E;
L_01EA7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Eu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EA7E PHA
    cpu.push("PHA", hw);
    goto L_01EA7F;
L_01EA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA7F DEX
    cpu.decReg('X');
    goto L_01EA80;
L_01EA80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA80u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA80u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA80 STX
    hw.write(cpu.address("abs", 0x15E9u), cpu.x, cpu.x8?8:16);
    goto L_01EA83;
L_01EA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA83u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA83u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EA83 PHB
    cpu.push("PHB", hw);
    goto L_01EA84;
L_01EA84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA84u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA84u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EA84 PHK
    cpu.push("PHK", hw);
    goto L_01EA85;
L_01EA85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA85u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA85u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EA85 PLB
    cpu.pop("PLB", hw);
    goto L_01EA86;
L_01EA86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA86u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA86u, 6u, 3u, cpu.address("abs", 0xEA8Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01EA86 JSR -> $01EA8F stack real
    { cpu.push16Value(hw,0xEA88u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA89u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEA8Fu), 0x01EA86u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01EA89;
L_01EA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA89u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA89u,0x01EA89u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA89u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA89u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EA89 PLB
    cpu.pop("PLB", hw);
    goto L_01EA8A;
L_01EA8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EA8A PLA
    cpu.pop("PLA", hw);
    goto L_01EA8B;
L_01EA8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Bu, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA8B STA
    hw.write(cpu.address("abs", 0x15E9u), cpu.a, cpu.m8?8:16);
    goto L_01EA8E;
L_01EA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01EA8E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x01EA8Eu);return;} hw.unresolvedReturn(0x01EA8Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_029BE4_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x029BE4u: goto L_029BE4;
    case 0x029BE6u: goto L_029BE6;
    case 0x029BE9u: goto L_029BE9;
    case 0x029BEBu: goto L_029BEB;
    case 0x029BEEu: goto L_029BEE;
    case 0x029BF0u: goto L_029BF0;
    case 0x029BF3u: goto L_029BF3;
    case 0x029BF5u: goto L_029BF5;
    case 0x029BF7u: goto L_029BF7;
    case 0x029BFAu: goto L_029BFA;
    case 0x029BFCu: goto L_029BFC;
    case 0x029BFDu: goto L_029BFD;
    case 0x029BFFu: goto L_029BFF;
    case 0x029C00u: goto L_029C00;
    case 0x029C02u: goto L_029C02;
    case 0x029C05u: goto L_029C05;
    case 0x029C07u: goto L_029C07;
    case 0x029C08u: goto L_029C08;
    case 0x029C0Au: goto L_029C0A;
    case 0x029C0Du: goto L_029C0D;
    case 0x029C0Fu: goto L_029C0F;
    case 0x029C11u: goto L_029C11;
    case 0x029C14u: goto L_029C14;
    case 0x029C16u: goto L_029C16;
    case 0x029C18u: goto L_029C18;
    case 0x029C19u: goto L_029C19;
    case 0x029C1Cu: goto L_029C1C;
    case 0x029C1Fu: goto L_029C1F;
    case 0x029C21u: goto L_029C21;
    case 0x029C24u: goto L_029C24;
    case 0x029C27u: goto L_029C27;
    case 0x029C2Au: goto L_029C2A;
    case 0x029C2Du: goto L_029C2D;
    case 0x029C2Fu: goto L_029C2F;
    case 0x029C32u: goto L_029C32;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_029BE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BE4 LDA
    cpu.setA(0x5u, 8);
    goto L_029BE6;
L_029BE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE6u, 4u, 3u, cpu.address("abs", 0x1887u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BE6 STA
    hw.write(cpu.address("abs", 0x1887u), cpu.a, cpu.m8?8:16);
    goto L_029BE9;
L_029BE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BE9 LDA
    cpu.setA(0x9u, 8);
    goto L_029BEB;
L_029BEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEBu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BEB STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_029BEE;
L_029BEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BEE STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_029BF0;
L_029BF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF0u, 6u, 3u, cpu.address("abs", 0x9BF5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029BF0 JSR -> $029BF5 stack real
    { cpu.push16Value(hw,0x9BF2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9BF3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9BF5u), 0x029BF0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_029BF3;
L_029BF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BF3u,0x029BF3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF3u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BF3 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_029BF5;
L_029BF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BF5 LDY
    cpu.setY(0x7u, 8);
    goto L_029BF7;
L_029BF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF7u, 4u + ((((0x170Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BF7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x170Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029BFA;
L_029BFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BFA BEQ -> $029C00
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_029C00; }
    goto L_029BFC;
L_029BFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFCu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BFC DEY
    cpu.decReg('Y');
    goto L_029BFD;
L_029BFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFDu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BFD BPL -> $029BF7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_029BF7; }
    goto L_029BFF;
L_029BFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029BFF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x029BFFu);return;} hw.unresolvedReturn(0x029BFFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_029C00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C00u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C00 LDA
    cpu.setA(0xFu, 8);
    goto L_029C02;
L_029C02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C02u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C02u, 5u, 3u, cpu.address("absy", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C02 STA
    hw.write(cpu.address("absy", 0x170Bu), cpu.a, cpu.m8?8:16);
    goto L_029C05;
L_029C05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C05u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C05u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C05 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029C07;
L_029C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C07u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C07 CLC
    cpu.setFlag('C', false);
    goto L_029C08;
L_029C08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C08u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C08 ADC
    cpu.adc(0x28u);
    goto L_029C0A;
L_029C0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Au, 5u, 3u, cpu.address("absy", 0x1715u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C0A STA
    hw.write(cpu.address("absy", 0x1715u), cpu.a, cpu.m8?8:16);
    goto L_029C0D;
L_029C0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C0D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029C0F;
L_029C0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C0F ADC
    cpu.adc(0x0u);
    goto L_029C11;
L_029C11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C11u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C11u, 5u, 3u, cpu.address("absy", 0x1729u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C11 STA
    hw.write(cpu.address("absy", 0x1729u), cpu.a, cpu.m8?8:16);
    goto L_029C14;
L_029C14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C14u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C14u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C14 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_029C16;
L_029C16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C16u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C16u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C16 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029C18;
L_029C18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C18u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C18 CLC
    cpu.setFlag('C', false);
    goto L_029C19;
L_029C19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C19u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C19u, 4u + ((((0x9BDEu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9BDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C19 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x9BDEu), cpu.m8?8:16));
    goto L_029C1C;
L_029C1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Cu, 5u, 3u, cpu.address("absy", 0x171Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C1C STA
    hw.write(cpu.address("absy", 0x171Fu), cpu.a, cpu.m8?8:16);
    goto L_029C1F;
L_029C1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029C21;
L_029C21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C21u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C21u, 4u + ((((0x9BE0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9BE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C21 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x9BE0u), cpu.m8?8:16));
    goto L_029C24;
L_029C24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u, 5u, 3u, cpu.address("absy", 0x1733u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C24 STA
    hw.write(cpu.address("absy", 0x1733u), cpu.a, cpu.m8?8:16);
    goto L_029C27;
L_029C27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C27u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C27u, 4u + ((((0x9BE2u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9BE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C27 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9BE2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029C2A;
L_029C2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Au, 5u, 3u, cpu.address("absy", 0x1747u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C2A STA
    hw.write(cpu.address("absy", 0x1747u), cpu.a, cpu.m8?8:16);
    goto L_029C2D;
L_029C2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C2D LDA
    cpu.setA(0x15u, 8);
    goto L_029C2F;
L_029C2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Fu, 5u, 3u, cpu.address("absy", 0x176Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C2F STA
    hw.write(cpu.address("absy", 0x176Fu), cpu.a, cpu.m8?8:16);
    goto L_029C32;
L_029C32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C32u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C32u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029C32 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x029C32u);return;} hw.unresolvedReturn(0x029C32u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0498F6_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0498F6u: goto L_0498F6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0498F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F6u, 8u, 4u, 0x009BC9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0498F6 JSL -> $009BC9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x98F9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x98FAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x009BC9u, 0x0498F6u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98FAu,0x0498F6u); return;
}

void sub_04F675_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04F675u: goto L_04F675;
    case 0x04F676u: goto L_04F676;
    case 0x04F677u: goto L_04F677;
    case 0x04F678u: goto L_04F678;
    case 0x04F67Au: goto L_04F67A;
    case 0x04F67Cu: goto L_04F67C;
    case 0x04F67Fu: goto L_04F67F;
    case 0x04F682u: goto L_04F682;
    case 0x04F684u: goto L_04F684;
    case 0x04F686u: goto L_04F686;
    case 0x04F688u: goto L_04F688;
    case 0x04F68Au: goto L_04F68A;
    case 0x04F68Cu: goto L_04F68C;
    case 0x04F68Fu: goto L_04F68F;
    case 0x04F692u: goto L_04F692;
    case 0x04F695u: goto L_04F695;
    case 0x04F698u: goto L_04F698;
    case 0x04F69Bu: goto L_04F69B;
    case 0x04F69Eu: goto L_04F69E;
    case 0x04F6A1u: goto L_04F6A1;
    case 0x04F6A4u: goto L_04F6A4;
    case 0x04F6A7u: goto L_04F6A7;
    case 0x04F6A8u: goto L_04F6A8;
    case 0x04F6A9u: goto L_04F6A9;
    case 0x04F6ABu: goto L_04F6AB;
    case 0x04F6ACu: goto L_04F6AC;
    case 0x04F6ADu: goto L_04F6AD;
    case 0x04F6AFu: goto L_04F6AF;
    case 0x04F6B1u: goto L_04F6B1;
    case 0x04F6B4u: goto L_04F6B4;
    case 0x04F6B7u: goto L_04F6B7;
    case 0x04F6B8u: goto L_04F6B8;
    case 0x04F6BBu: goto L_04F6BB;
    case 0x04F6BEu: goto L_04F6BE;
    case 0x04F6BFu: goto L_04F6BF;
    case 0x04F6C2u: goto L_04F6C2;
    case 0x04F6C5u: goto L_04F6C5;
    case 0x04F6C6u: goto L_04F6C6;
    case 0x04F6C7u: goto L_04F6C7;
    case 0x04F6C9u: goto L_04F6C9;
    case 0x04F6CAu: goto L_04F6CA;
    case 0x04F6CCu: goto L_04F6CC;
    case 0x04F6CEu: goto L_04F6CE;
    case 0x04F6CFu: goto L_04F6CF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04F675:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF675u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF675u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF675u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F675 PHB
    cpu.push("PHB", hw);
    goto L_04F676;
L_04F676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF676u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF676u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F676 PHK
    cpu.push("PHK", hw);
    goto L_04F677;
L_04F677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF677u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF677u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F677 PLB
    cpu.pop("PLB", hw);
    goto L_04F678;
L_04F678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF678u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF678u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F678 LDX
    cpu.setX(0xCu, 8);
    goto L_04F67A;
L_04F67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F67A LDY
    cpu.setY(0x4Bu, 8);
    goto L_04F67C;
L_04F67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF67Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Cu, 4u + ((((0xF616u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF616u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F67C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF616u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F67F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Cu, 4u + ((((0xF616u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF616u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F67C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF616u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F67F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF67Cu,0x04F67Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F67F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF67Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Fu, 5u, 3u, cpu.address("absx", 0x0DE8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F67F STA
    hw.write(cpu.address("absx", 0xDE8u), cpu.a, cpu.m8?8:16);
    goto L_04F682;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Fu, 5u, 3u, cpu.address("absx", 0x0DE8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F67F STA
    hw.write(cpu.address("absx", 0xDE8u), cpu.a, cpu.m8?8:16);
    goto L_04F682;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF67Fu,0x04F67Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF682u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF682u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF682u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F682 CMP
    cpu.compareA(0x1u);
    goto L_04F684;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF682u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF682u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F682 CMP
    cpu.compareA(0x1u);
    goto L_04F684;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF682u,0x04F682u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF684u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF684u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F684 BEQ -> $04F68A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F68A; }
    goto L_04F686;
L_04F686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF686u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF686u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F686 CMP
    cpu.compareA(0x2u);
    goto L_04F688;
L_04F688:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF688u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF688u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF688u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F688 BNE -> $04F68F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F68F; }
    goto L_04F68A;
L_04F68A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF68Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F68A LDA
    cpu.setA(0x40u, 8);
    goto L_04F68C;
L_04F68C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF68Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Cu, 5u, 3u, cpu.address("absx", 0x0E58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F68C STA
    hw.write(cpu.address("absx", 0xE58u), cpu.a, cpu.m8?8:16);
    goto L_04F68F;
L_04F68F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF68Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Fu, 4u + ((((0xF617u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF617u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F68F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF617u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F692;
L_04F692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF692u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF692u, 5u, 3u, cpu.address("absx", 0x0E38u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F692 STA
    hw.write(cpu.address("absx", 0xE38u), cpu.a, cpu.m8?8:16);
    goto L_04F695;
L_04F695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF695u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF695u, 4u + ((((0xF618u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF618u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F695 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF618u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F698;
L_04F698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF698u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF698u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF698u, 5u, 3u, cpu.address("absx", 0x0E68u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F698 STA
    hw.write(cpu.address("absx", 0xE68u), cpu.a, cpu.m8?8:16);
    goto L_04F69B;
L_04F69B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF69Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Bu, 4u + ((((0xF619u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF619u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F69B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF619u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F69E;
L_04F69E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF69Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Eu, 5u, 3u, cpu.address("absx", 0x0E48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F69E STA
    hw.write(cpu.address("absx", 0xE48u), cpu.a, cpu.m8?8:16);
    goto L_04F6A1;
L_04F6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A1u, 4u + ((((0xF61Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF61Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6A1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF61Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F6A4;
L_04F6A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A4u, 5u, 3u, cpu.address("absx", 0x0E78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6A4 STA
    hw.write(cpu.address("absx", 0xE78u), cpu.a, cpu.m8?8:16);
    goto L_04F6A7;
L_04F6A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A7u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6A7 TYA
    cpu.transfer("TYA");
    goto L_04F6A8;
L_04F6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A8u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6A8 SEC
    cpu.setFlag('C', true);
    goto L_04F6A9;
L_04F6A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6A9 SBC
    cpu.sbc(0x5u);
    goto L_04F6AB;
L_04F6AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ABu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6AB TAY
    cpu.transfer("TAY");
    goto L_04F6AC;
L_04F6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ACu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6AC DEX
    cpu.decReg('X');
    goto L_04F6AD;
L_04F6AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ADu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6AD BPL -> $04F67C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F67C; }
    goto L_04F6AF;
L_04F6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6AFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6AF LDX
    cpu.setX(0xDu, 8);
    goto L_04F6B1;
L_04F6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B1u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B1u, 5u, 3u, cpu.address("absx", 0x0E25u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B1 STZ
    hw.write(cpu.address("absx", 0xE25u), 0, cpu.m8?8:16);
    goto L_04F6B4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B1u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B1u, 5u, 3u, cpu.address("absx", 0x0E25u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B1 STZ
    hw.write(cpu.address("absx", 0xE25u), 0, cpu.m8?8:16);
    goto L_04F6B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6B1u,0x04F6B1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B4u, 4u, 3u, cpu.address("abs", 0xFD22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xFD22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F6B7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B4u, 4u, 3u, cpu.address("abs", 0xFD22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xFD22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F6B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6B4u,0x04F6B4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B7 DEC
    cpu.decReg('A');
    goto L_04F6B8;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B7 DEC
    cpu.decReg('A');
    goto L_04F6B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6B7u,0x04F6B7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B8u, 5u, 3u, cpu.address("absx", 0x0EB5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B8 STA
    hw.write(cpu.address("absx", 0xEB5u), cpu.a, cpu.m8?8:16);
    goto L_04F6BB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B8u, 5u, 3u, cpu.address("absx", 0x0EB5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B8 STA
    hw.write(cpu.address("absx", 0xEB5u), cpu.a, cpu.m8?8:16);
    goto L_04F6BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6B8u,0x04F6B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6BBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BBu, 4u + ((((0xF665u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF665u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF665u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F6BE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BBu, 4u + ((((0xF665u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF665u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF665u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F6BE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6BBu,0x04F6BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6BEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BEu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F6BE PHA
    cpu.push("PHA", hw);
    goto L_04F6BF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BEu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F6BE PHA
    cpu.push("PHA", hw);
    goto L_04F6BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6BEu,0x04F6BEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6BFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BFu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BFu, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6BF STX
    hw.write(cpu.address("abs", 0xDDEu), cpu.x, cpu.x8?8:16);
    goto L_04F6C2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BFu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BFu, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6BF STX
    hw.write(cpu.address("abs", 0xDDEu), cpu.x, cpu.x8?8:16);
    goto L_04F6C2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6BFu,0x04F6BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C2u, 6u, 3u, cpu.address("abs", 0xF853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F6C2 JSR -> $04F853 stack real
    { cpu.push16Value(hw,0xF6C4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF6C5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF853u), 0x04F6C2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F6C5;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C2u, 6u, 3u, cpu.address("abs", 0xF853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F6C2 JSR -> $04F853 stack real
    { cpu.push16Value(hw,0xF6C4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF6C5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF853u), 0x04F6C2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F6C5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6C2u,0x04F6C2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C5u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F6C5 PLA
    cpu.pop("PLA", hw);
    goto L_04F6C6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C5u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F6C5 PLA
    cpu.pop("PLA", hw);
    goto L_04F6C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6C5u,0x04F6C5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C6u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6C6 DEC
    cpu.decReg('A');
    goto L_04F6C7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C6u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6C6 DEC
    cpu.decReg('A');
    goto L_04F6C7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6C6u,0x04F6C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6C7 BNE -> $04F6BE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F6BE; }
    goto L_04F6C9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6C7 BNE -> $04F6BE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F6BE; }
    goto L_04F6C9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6C7u,0x04F6C7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6C9 INX
    cpu.inc('X');
    goto L_04F6CA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6C9 INX
    cpu.inc('X');
    goto L_04F6CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6C9u,0x04F6C9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6CAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CAu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6CA CPX
    cpu.compareX(0x10u);
    goto L_04F6CC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CAu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6CA CPX
    cpu.compareX(0x10u);
    goto L_04F6CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6CAu,0x04F6CAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6CCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CCu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6CC BCC -> $04F6B1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F6B1; }
    goto L_04F6CE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CCu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6CC BCC -> $04F6B1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F6B1; }
    goto L_04F6CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6CCu,0x04F6CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6CEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CEu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F6CE PLB
    cpu.pop("PLB", hw);
    goto L_04F6CF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CEu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F6CE PLB
    cpu.pop("PLB", hw);
    goto L_04F6CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6CEu,0x04F6CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6CFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $04F6CF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x04F6CFu);return;} hw.unresolvedReturn(0x04F6CFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $04F6CF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x04F6CFu);return;} hw.unresolvedReturn(0x04F6CFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6CFu,0x04F6CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_04F675_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04F675u: goto L_04F675;
    case 0x04F676u: goto L_04F676;
    case 0x04F677u: goto L_04F677;
    case 0x04F678u: goto L_04F678;
    case 0x04F67Au: goto L_04F67A;
    case 0x04F67Cu: goto L_04F67C;
    case 0x04F67Fu: goto L_04F67F;
    case 0x04F682u: goto L_04F682;
    case 0x04F684u: goto L_04F684;
    case 0x04F686u: goto L_04F686;
    case 0x04F688u: goto L_04F688;
    case 0x04F68Au: goto L_04F68A;
    case 0x04F68Cu: goto L_04F68C;
    case 0x04F68Fu: goto L_04F68F;
    case 0x04F692u: goto L_04F692;
    case 0x04F695u: goto L_04F695;
    case 0x04F698u: goto L_04F698;
    case 0x04F69Bu: goto L_04F69B;
    case 0x04F69Eu: goto L_04F69E;
    case 0x04F6A1u: goto L_04F6A1;
    case 0x04F6A4u: goto L_04F6A4;
    case 0x04F6A7u: goto L_04F6A7;
    case 0x04F6A8u: goto L_04F6A8;
    case 0x04F6A9u: goto L_04F6A9;
    case 0x04F6ABu: goto L_04F6AB;
    case 0x04F6ACu: goto L_04F6AC;
    case 0x04F6ADu: goto L_04F6AD;
    case 0x04F6AFu: goto L_04F6AF;
    case 0x04F6B1u: goto L_04F6B1;
    case 0x04F6B4u: goto L_04F6B4;
    case 0x04F6B7u: goto L_04F6B7;
    case 0x04F6B8u: goto L_04F6B8;
    case 0x04F6BBu: goto L_04F6BB;
    case 0x04F6BEu: goto L_04F6BE;
    case 0x04F6BFu: goto L_04F6BF;
    case 0x04F6C2u: goto L_04F6C2;
    case 0x04F6C5u: goto L_04F6C5;
    case 0x04F6C6u: goto L_04F6C6;
    case 0x04F6C7u: goto L_04F6C7;
    case 0x04F6C9u: goto L_04F6C9;
    case 0x04F6CAu: goto L_04F6CA;
    case 0x04F6CCu: goto L_04F6CC;
    case 0x04F6CEu: goto L_04F6CE;
    case 0x04F6CFu: goto L_04F6CF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04F675:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF675u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF675u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF675u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F675 PHB
    cpu.push("PHB", hw);
    goto L_04F676;
L_04F676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF676u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF676u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F676 PHK
    cpu.push("PHK", hw);
    goto L_04F677;
L_04F677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF677u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF677u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F677 PLB
    cpu.pop("PLB", hw);
    goto L_04F678;
L_04F678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF678u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF678u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F678 LDX
    cpu.setX(0xCu, 8);
    goto L_04F67A;
L_04F67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F67A LDY
    cpu.setY(0x4Bu, 8);
    goto L_04F67C;
L_04F67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Cu, 4u + ((((0xF616u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF616u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F67C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF616u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F67F;
L_04F67F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF67Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Fu, 5u, 3u, cpu.address("absx", 0x0DE8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F67F STA
    hw.write(cpu.address("absx", 0xDE8u), cpu.a, cpu.m8?8:16);
    goto L_04F682;
L_04F682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF682u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF682u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F682 CMP
    cpu.compareA(0x1u);
    goto L_04F684;
L_04F684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF684u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF684u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F684 BEQ -> $04F68A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F68A; }
    goto L_04F686;
L_04F686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF686u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF686u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F686 CMP
    cpu.compareA(0x2u);
    goto L_04F688;
L_04F688:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF688u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF688u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF688u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F688 BNE -> $04F68F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F68F; }
    goto L_04F68A;
L_04F68A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF68Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F68A LDA
    cpu.setA(0x40u, 8);
    goto L_04F68C;
L_04F68C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF68Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Cu, 5u, 3u, cpu.address("absx", 0x0E58u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F68C STA
    hw.write(cpu.address("absx", 0xE58u), cpu.a, cpu.m8?8:16);
    goto L_04F68F;
L_04F68F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF68Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Fu, 4u + ((((0xF617u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF617u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F68F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF617u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F692;
L_04F692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF692u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF692u, 5u, 3u, cpu.address("absx", 0x0E38u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F692 STA
    hw.write(cpu.address("absx", 0xE38u), cpu.a, cpu.m8?8:16);
    goto L_04F695;
L_04F695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF695u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF695u, 4u + ((((0xF618u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF618u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F695 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF618u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F698;
L_04F698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF698u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF698u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF698u, 5u, 3u, cpu.address("absx", 0x0E68u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F698 STA
    hw.write(cpu.address("absx", 0xE68u), cpu.a, cpu.m8?8:16);
    goto L_04F69B;
L_04F69B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF69Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Bu, 4u + ((((0xF619u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF619u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F69B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF619u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F69E;
L_04F69E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF69Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Eu, 5u, 3u, cpu.address("absx", 0x0E48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F69E STA
    hw.write(cpu.address("absx", 0xE48u), cpu.a, cpu.m8?8:16);
    goto L_04F6A1;
L_04F6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A1u, 4u + ((((0xF61Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF61Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6A1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF61Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F6A4;
L_04F6A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A4u, 5u, 3u, cpu.address("absx", 0x0E78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6A4 STA
    hw.write(cpu.address("absx", 0xE78u), cpu.a, cpu.m8?8:16);
    goto L_04F6A7;
L_04F6A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A7u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6A7 TYA
    cpu.transfer("TYA");
    goto L_04F6A8;
L_04F6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A8u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6A8 SEC
    cpu.setFlag('C', true);
    goto L_04F6A9;
L_04F6A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6A9 SBC
    cpu.sbc(0x5u);
    goto L_04F6AB;
L_04F6AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ABu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6AB TAY
    cpu.transfer("TAY");
    goto L_04F6AC;
L_04F6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ACu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6AC DEX
    cpu.decReg('X');
    goto L_04F6AD;
L_04F6AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ADu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6AD BPL -> $04F67C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F67C; }
    goto L_04F6AF;
L_04F6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6AFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6AF LDX
    cpu.setX(0xDu, 8);
    goto L_04F6B1;
L_04F6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B1u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B1u, 5u, 3u, cpu.address("absx", 0x0E25u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B1 STZ
    hw.write(cpu.address("absx", 0xE25u), 0, cpu.m8?8:16);
    goto L_04F6B4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B1u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B1u, 5u, 3u, cpu.address("absx", 0x0E25u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B1 STZ
    hw.write(cpu.address("absx", 0xE25u), 0, cpu.m8?8:16);
    goto L_04F6B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6B1u,0x04F6B1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B4u, 4u, 3u, cpu.address("abs", 0xFD22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xFD22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F6B7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B4u, 4u, 3u, cpu.address("abs", 0xFD22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xFD22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F6B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6B4u,0x04F6B4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B7 DEC
    cpu.decReg('A');
    goto L_04F6B8;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B7 DEC
    cpu.decReg('A');
    goto L_04F6B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6B7u,0x04F6B7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B8u, 5u, 3u, cpu.address("absx", 0x0EB5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B8 STA
    hw.write(cpu.address("absx", 0xEB5u), cpu.a, cpu.m8?8:16);
    goto L_04F6BB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B8u, 5u, 3u, cpu.address("absx", 0x0EB5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6B8 STA
    hw.write(cpu.address("absx", 0xEB5u), cpu.a, cpu.m8?8:16);
    goto L_04F6BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6B8u,0x04F6B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6BBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BBu, 4u + ((((0xF665u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF665u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF665u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F6BE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BBu, 4u + ((((0xF665u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF665u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF665u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F6BE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6BBu,0x04F6BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6BEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BEu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F6BE PHA
    cpu.push("PHA", hw);
    goto L_04F6BF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BEu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F6BE PHA
    cpu.push("PHA", hw);
    goto L_04F6BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6BEu,0x04F6BEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6BFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BFu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BFu, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6BF STX
    hw.write(cpu.address("abs", 0xDDEu), cpu.x, cpu.x8?8:16);
    goto L_04F6C2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BFu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BFu, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6BF STX
    hw.write(cpu.address("abs", 0xDDEu), cpu.x, cpu.x8?8:16);
    goto L_04F6C2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6BFu,0x04F6BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C2u, 6u, 3u, cpu.address("abs", 0xF853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F6C2 JSR -> $04F853 stack real
    { cpu.push16Value(hw,0xF6C4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF6C5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF853u), 0x04F6C2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F6C5;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C2u, 6u, 3u, cpu.address("abs", 0xF853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F6C2 JSR -> $04F853 stack real
    { cpu.push16Value(hw,0xF6C4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF6C5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF853u), 0x04F6C2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F6C5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6C2u,0x04F6C2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C5u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F6C5 PLA
    cpu.pop("PLA", hw);
    goto L_04F6C6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C5u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F6C5 PLA
    cpu.pop("PLA", hw);
    goto L_04F6C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6C5u,0x04F6C5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C6u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6C6 DEC
    cpu.decReg('A');
    goto L_04F6C7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C6u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6C6 DEC
    cpu.decReg('A');
    goto L_04F6C7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6C6u,0x04F6C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6C7 BNE -> $04F6BE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F6BE; }
    goto L_04F6C9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6C7 BNE -> $04F6BE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F6BE; }
    goto L_04F6C9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6C7u,0x04F6C7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6C9 INX
    cpu.inc('X');
    goto L_04F6CA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6C9 INX
    cpu.inc('X');
    goto L_04F6CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6C9u,0x04F6C9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6CAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CAu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6CA CPX
    cpu.compareX(0x10u);
    goto L_04F6CC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CAu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6CA CPX
    cpu.compareX(0x10u);
    goto L_04F6CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6CAu,0x04F6CAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6CCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CCu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6CC BCC -> $04F6B1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F6B1; }
    goto L_04F6CE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CCu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F6CC BCC -> $04F6B1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F6B1; }
    goto L_04F6CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6CCu,0x04F6CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6CEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CEu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F6CE PLB
    cpu.pop("PLB", hw);
    goto L_04F6CF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CEu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F6CE PLB
    cpu.pop("PLB", hw);
    goto L_04F6CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6CEu,0x04F6CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6CFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $04F6CF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x04F6CFu);return;} hw.unresolvedReturn(0x04F6CFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $04F6CF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x04F6CFu);return;} hw.unresolvedReturn(0x04F6CFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6CFu,0x04F6CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_04FE4E_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04FE4Eu: goto L_04FE4E;
    case 0x04FE50u: goto L_04FE50;
    case 0x04FE51u: goto L_04FE51;
    case 0x04FE54u: goto L_04FE54;
    case 0x04FE56u: goto L_04FE56;
    case 0x04FE58u: goto L_04FE58;
    case 0x04FE5Au: goto L_04FE5A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04FE4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE4Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE4Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE4E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FE50;
L_04FE50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE50u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE50 CLC
    cpu.setFlag('C', false);
    goto L_04FE51;
L_04FE51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE51u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE51u, 4u + ((((0x0E55u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E55u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE51 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE55u), cpu.m8?8:16));
    goto L_04FE54;
L_04FE54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE54u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE54u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE54 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04FE56;
L_04FE56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE56u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE56 BCC -> $04FE5A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04FE5A; }
    goto L_04FE58;
L_04FE58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE58u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE58u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE58 INC
    cpu.incMem(hw, cpu.address("dp", 0x3u), cpu.m8?8:16);
    goto L_04FE5A;
L_04FE5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FE5A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FE5Au);return;} hw.unresolvedReturn(0x04FE5Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04FEEF_E1M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04FEEFu: goto L_04FEEF;
    case 0x04FEF2u: goto L_04FEF2;
    case 0x04FEF3u: goto L_04FEF3;
    case 0x04FEF6u: goto L_04FEF6;
    case 0x04FEF8u: goto L_04FEF8;
    case 0x04FEF9u: goto L_04FEF9;
    case 0x04FEFCu: goto L_04FEFC;
    case 0x04FEFFu: goto L_04FEFF;
    case 0x04FF00u: goto L_04FF00;
    case 0x04FF03u: goto L_04FF03;
    case 0x04FF05u: goto L_04FF05;
    case 0x04FF07u: goto L_04FF07;
    case 0x04FF0Au: goto L_04FF0A;
    case 0x04FF0Bu: goto L_04FF0B;
    case 0x04FF0Du: goto L_04FF0D;
    case 0x04FF0Fu: goto L_04FF0F;
    case 0x04FF12u: goto L_04FF12;
    case 0x04FF13u: goto L_04FF13;
    case 0x04FF16u: goto L_04FF16;
    case 0x04FF18u: goto L_04FF18;
    case 0x04FF19u: goto L_04FF19;
    case 0x04FF1Cu: goto L_04FF1C;
    case 0x04FF1Fu: goto L_04FF1F;
    case 0x04FF20u: goto L_04FF20;
    case 0x04FF23u: goto L_04FF23;
    case 0x04FF25u: goto L_04FF25;
    case 0x04FF27u: goto L_04FF27;
    case 0x04FF2Au: goto L_04FF2A;
    case 0x04FF2Bu: goto L_04FF2B;
    case 0x04FF2Du: goto L_04FF2D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04FEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEEFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEEFu, 4u + ((((0x0E65u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEEF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FEF2;
L_04FEF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF2u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEF2 XBA
    cpu.xba();
    goto L_04FEF3;
L_04FEF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF3u, 4u + ((((0x0E35u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEF3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE35u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FEF6;
L_04FEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEF6 REP
    cpu.rep(0x20u);
    goto L_04FEF8;
L_04FEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEF8 CLC
    cpu.setFlag('C', false);
    goto L_04FEF9;
L_04FEF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEF9 ADC
    cpu.adc(0x8u);
    goto L_04FEFC;
L_04FEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEFCu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEFCu, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEFC LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04FEFF;
L_04FEFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEFFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEFFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEFF SEC
    cpu.setFlag('C', true);
    goto L_04FF00;
L_04FF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF00u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF00u, 5u + ((((0x1F17u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF00 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1F17u), cpu.m8?8:16));
    goto L_04FF03;
L_04FF03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF03u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF03u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF03 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04FF05;
L_04FF05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF05u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF05u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF05 BPL -> $04FF0B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04FF0B; }
    goto L_04FF07;
L_04FF07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF07u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF07 EOR
    cpu.logicXor(0xFFFFu);
    goto L_04FF0A;
L_04FF0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF0A INC
    cpu.inc('A');
    goto L_04FF0B;
L_04FF0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF0B STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_04FF0D;
L_04FF0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF0D SEP
    cpu.sep(0x20u);
    goto L_04FF0F;
L_04FF0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Fu, 4u + ((((0x0E75u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF0F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FF12;
L_04FF12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF12u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF12u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF12 XBA
    cpu.xba();
    goto L_04FF13;
L_04FF13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF13u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF13u, 4u + ((((0x0E45u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF13 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FF16;
L_04FF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF16u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF16 REP
    cpu.rep(0x20u);
    goto L_04FF18;
L_04FF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF18u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF18 CLC
    cpu.setFlag('C', false);
    goto L_04FF19;
L_04FF19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF19u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF19 ADC
    cpu.adc(0x8u);
    goto L_04FF1C;
L_04FF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF1Cu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF1Cu, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF1C LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04FF1F;
L_04FF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF1Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF1F SEC
    cpu.setFlag('C', true);
    goto L_04FF20;
L_04FF20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF20u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF20u, 5u + ((((0x1F19u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF20 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1F19u), cpu.m8?8:16));
    goto L_04FF23;
L_04FF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF23u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF23u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF23 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04FF25;
L_04FF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF25u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF25 BPL -> $04FF2B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04FF2B; }
    goto L_04FF27;
L_04FF27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF27u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF27 EOR
    cpu.logicXor(0xFFFFu);
    goto L_04FF2A;
L_04FF2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF2Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF2A INC
    cpu.inc('A');
    goto L_04FF2B;
L_04FF2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF2Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF2Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF2B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_04FF2D;
L_04FF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF2Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF2Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FF2D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FF2Du);return;} hw.unresolvedReturn(0x04FF2Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04FEEF_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04FEEFu: goto L_04FEEF;
    case 0x04FEF2u: goto L_04FEF2;
    case 0x04FEF3u: goto L_04FEF3;
    case 0x04FEF6u: goto L_04FEF6;
    case 0x04FEF8u: goto L_04FEF8;
    case 0x04FEF9u: goto L_04FEF9;
    case 0x04FEFCu: goto L_04FEFC;
    case 0x04FEFFu: goto L_04FEFF;
    case 0x04FF00u: goto L_04FF00;
    case 0x04FF03u: goto L_04FF03;
    case 0x04FF05u: goto L_04FF05;
    case 0x04FF07u: goto L_04FF07;
    case 0x04FF0Au: goto L_04FF0A;
    case 0x04FF0Bu: goto L_04FF0B;
    case 0x04FF0Du: goto L_04FF0D;
    case 0x04FF0Fu: goto L_04FF0F;
    case 0x04FF12u: goto L_04FF12;
    case 0x04FF13u: goto L_04FF13;
    case 0x04FF16u: goto L_04FF16;
    case 0x04FF18u: goto L_04FF18;
    case 0x04FF19u: goto L_04FF19;
    case 0x04FF1Cu: goto L_04FF1C;
    case 0x04FF1Fu: goto L_04FF1F;
    case 0x04FF20u: goto L_04FF20;
    case 0x04FF23u: goto L_04FF23;
    case 0x04FF25u: goto L_04FF25;
    case 0x04FF27u: goto L_04FF27;
    case 0x04FF2Au: goto L_04FF2A;
    case 0x04FF2Bu: goto L_04FF2B;
    case 0x04FF2Du: goto L_04FF2D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04FEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEEFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEEFu, 4u + ((((0x0E65u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEEF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FEF2;
L_04FEF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF2u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEF2 XBA
    cpu.xba();
    goto L_04FEF3;
L_04FEF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF3u, 4u + ((((0x0E35u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEF3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE35u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FEF6;
L_04FEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEF6 REP
    cpu.rep(0x20u);
    goto L_04FEF8;
L_04FEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEF8 CLC
    cpu.setFlag('C', false);
    goto L_04FEF9;
L_04FEF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEF9 ADC
    cpu.adc(0x8u);
    goto L_04FEFC;
L_04FEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEFCu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEFCu, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEFC LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04FEFF;
L_04FEFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEFFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEFFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEFF SEC
    cpu.setFlag('C', true);
    goto L_04FF00;
L_04FF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF00u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF00u, 5u + ((((0x1F17u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF00 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1F17u), cpu.m8?8:16));
    goto L_04FF03;
L_04FF03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF03u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF03u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF03 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04FF05;
L_04FF05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF05u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF05u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF05 BPL -> $04FF0B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04FF0B; }
    goto L_04FF07;
L_04FF07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF07u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF07 EOR
    cpu.logicXor(0xFFFFu);
    goto L_04FF0A;
L_04FF0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF0A INC
    cpu.inc('A');
    goto L_04FF0B;
L_04FF0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF0B STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_04FF0D;
L_04FF0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF0D SEP
    cpu.sep(0x20u);
    goto L_04FF0F;
L_04FF0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Fu, 4u + ((((0x0E75u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF0F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FF12;
L_04FF12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF12u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF12u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF12 XBA
    cpu.xba();
    goto L_04FF13;
L_04FF13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF13u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF13u, 4u + ((((0x0E45u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF13 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FF16;
L_04FF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF16u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF16 REP
    cpu.rep(0x20u);
    goto L_04FF18;
L_04FF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF18u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF18 CLC
    cpu.setFlag('C', false);
    goto L_04FF19;
L_04FF19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF19u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF19 ADC
    cpu.adc(0x8u);
    goto L_04FF1C;
L_04FF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF1Cu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF1Cu, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF1C LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04FF1F;
L_04FF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF1Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF1F SEC
    cpu.setFlag('C', true);
    goto L_04FF20;
L_04FF20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF20u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF20u, 5u + ((((0x1F19u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF20 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1F19u), cpu.m8?8:16));
    goto L_04FF23;
L_04FF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF23u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF23u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF23 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04FF25;
L_04FF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF25u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF25 BPL -> $04FF2B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04FF2B; }
    goto L_04FF27;
L_04FF27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF27u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF27 EOR
    cpu.logicXor(0xFFFFu);
    goto L_04FF2A;
L_04FF2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF2Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF2A INC
    cpu.inc('A');
    goto L_04FF2B;
L_04FF2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF2Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF2Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FF2B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_04FF2D;
L_04FF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF2Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF2Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FF2D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FF2Du);return;} hw.unresolvedReturn(0x04FF2Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_05BC72_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05BC72u: goto L_05BC72;
    case 0x05BC75u: goto L_05BC75;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05BC72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC72u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC72u, 6u, 3u, cpu.address("abs", 0xBC4Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05BC72 JSR -> $05BC4A stack real
    { cpu.push16Value(hw,0xBC74u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC75u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBC4Au), 0x05BC72u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05BC75;
L_05BC75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC75u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC75u,0x05BC75u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC75u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC75u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05BC75 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x05BC75u);return;} hw.unresolvedReturn(0x05BC75u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_05CBFF_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05CBFFu: goto L_05CBFF;
    case 0x05CC00u: goto L_05CC00;
    case 0x05CC01u: goto L_05CC01;
    case 0x05CC02u: goto L_05CC02;
    case 0x05CC05u: goto L_05CC05;
    case 0x05CC06u: goto L_05CC06;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05CBFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBFFu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBFFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05CBFF PHB
    cpu.push("PHB", hw);
    goto L_05CC00;
L_05CC00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC00u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC00u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05CC00 PHK
    cpu.push("PHK", hw);
    goto L_05CC01;
L_05CC01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC01u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC01u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05CC01 PLB
    cpu.pop("PLB", hw);
    goto L_05CC02;
L_05CC02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC02u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC02u, 6u, 3u, cpu.address("abs", 0xCC07u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05CC02 JSR -> $05CC07 stack real
    { cpu.push16Value(hw,0xCC04u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCC05u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCC07u), 0x05CC02u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05CC05;
L_05CC05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC05u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCC05u,0x05CC05u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC05u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC05u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05CC05 PLB
    cpu.pop("PLB", hw);
    goto L_05CC06;
L_05CC06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC06u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC06u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05CC06 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x05CC06u);return;} hw.unresolvedReturn(0x05CC06u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0CCAFD_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CCAFDu: goto L_0CCAFD;
    case 0x0CCAFFu: goto L_0CCAFF;
    case 0x0CCB02u: goto L_0CCB02;
    case 0x0CCB05u: goto L_0CCB05;
    case 0x0CCB08u: goto L_0CCB08;
    case 0x0CCB0Au: goto L_0CCB0A;
    case 0x0CCB0Du: goto L_0CCB0D;
    case 0x0CCB0Fu: goto L_0CCB0F;
    case 0x0CCB12u: goto L_0CCB12;
    case 0x0CCB13u: goto L_0CCB13;
    case 0x0CCB14u: goto L_0CCB14;
    case 0x0CCB15u: goto L_0CCB15;
    case 0x0CCB16u: goto L_0CCB16;
    case 0x0CCB18u: goto L_0CCB18;
    case 0x0CCB1Bu: goto L_0CCB1B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CCAFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAFD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCAFF;
L_0CCAFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFFu, 5u, 3u, cpu.address("absx", 0x0380u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAFF STA
    hw.write(cpu.address("absx", 0x380u), cpu.a, cpu.m8?8:16);
    goto L_0CCB02;
L_0CCB02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB02u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB02u, 4u, 3u, cpu.address("abs", 0x0B51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB02 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xB51u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCB05;
L_0CCB05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB05u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB05u, 5u, 3u, cpu.address("absx", 0x0381u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB05 STA
    hw.write(cpu.address("absx", 0x381u), cpu.a, cpu.m8?8:16);
    goto L_0CCB08;
L_0CCB08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB08u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB08 LDA
    cpu.setA(0xE6u, 8);
    goto L_0CCB0A;
L_0CCB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Au, 5u, 3u, cpu.address("absx", 0x0382u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB0A STA
    hw.write(cpu.address("absx", 0x382u), cpu.a, cpu.m8?8:16);
    goto L_0CCB0D;
L_0CCB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB0D LDA
    cpu.setA(0x21u, 8);
    goto L_0CCB0F;
L_0CCB0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Fu, 5u, 3u, cpu.address("absx", 0x0383u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB0F STA
    hw.write(cpu.address("absx", 0x383u), cpu.a, cpu.m8?8:16);
    goto L_0CCB12;
L_0CCB12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB12u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB12 TXA
    cpu.transfer("TXA");
    goto L_0CCB13;
L_0CCB13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB13u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB13u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB13 LSR
    cpu.lsrA();
    goto L_0CCB14;
L_0CCB14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB14u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB14u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB14 LSR
    cpu.lsrA();
    goto L_0CCB15;
L_0CCB15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB15u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB15 TAX
    cpu.transfer("TAX");
    goto L_0CCB16;
L_0CCB16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB16u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB16 LDA
    cpu.setA(0x2u, 8);
    goto L_0CCB18;
L_0CCB18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB18u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB18u, 5u, 3u, cpu.address("absx", 0x0480u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB18 STA
    hw.write(cpu.address("absx", 0x480u), cpu.a, cpu.m8?8:16);
    goto L_0CCB1B;
L_0CCB1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CCB1B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CCB1Bu);return;} hw.unresolvedReturn(0x0CCB1Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB42D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB42Du: goto L_0DB42D;
    case 0x0DB42Fu: goto L_0DB42F;
    case 0x0DB431u: goto L_0DB431;
    case 0x0DB433u: goto L_0DB433;
    case 0x0DB435u: goto L_0DB435;
    case 0x0DB437u: goto L_0DB437;
    case 0x0DB43Au: goto L_0DB43A;
    case 0x0DB43Cu: goto L_0DB43C;
    case 0x0DB43Fu: goto L_0DB43F;
    case 0x0DB441u: goto L_0DB441;
    case 0x0DB443u: goto L_0DB443;
    case 0x0DB446u: goto L_0DB446;
    case 0x0DB44Au: goto L_0DB44A;
    case 0x0DB44Du: goto L_0DB44D;
    case 0x0DB44Fu: goto L_0DB44F;
    case 0x0DB451u: goto L_0DB451;
    case 0x0DB454u: goto L_0DB454;
    case 0x0DB457u: goto L_0DB457;
    case 0x0DB459u: goto L_0DB459;
    case 0x0DB45Bu: goto L_0DB45B;
    case 0x0DB45Cu: goto L_0DB45C;
    case 0x0DB45Eu: goto L_0DB45E;
    case 0x0DB460u: goto L_0DB460;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB42D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB42D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB42F;
L_0DB42F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB42F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB431;
L_0DB431:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB431u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB431u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB431u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB431 AND
    cpu.logicAnd(0xFu);
    goto L_0DB433;
L_0DB433:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB433u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB433u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB433u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB433 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB435;
L_0DB435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB435u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB435u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB435 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DB437;
L_0DB437:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB437u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB437u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB437u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB437 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xB439u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB43Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DB437u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB43A;
L_0DB43A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB43Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB43Au,0x0DB43Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB43A LDX
    cpu.setX(0x0u, 8);
    goto L_0DB43C;
L_0DB43C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB43Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Cu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB43C JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB43Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB43Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB43Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB43F;
L_0DB43F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB43Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB43Fu,0x0DB43Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Fu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB43Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB43F CPX
    cpu.compareX(0x0u);
    goto L_0DB441;
L_0DB441:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB441u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB441u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB441u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB441 BEQ -> $0DB446
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB446; }
    goto L_0DB443;
L_0DB443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB443u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB443u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB443u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB443 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xB445u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB446u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DB443u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB446;
L_0DB446:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB446u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB446u,0x0DB446u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB446u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB446u, 5u, 4u, ((0x0DB42Bu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB446 LDA
    cpu.loadA(hw.readW(((0xDB42Bu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB44A;
L_0DB44A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB44Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB44Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB44Au, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB44A JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB44Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB44Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB44Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB44D;
L_0DB44D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB44Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB44Du,0x0DB44Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB44Du,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB44Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB44D DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DB44F;
L_0DB44F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB44Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB44Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB44Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB44F BPL -> $0DB43C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB43C; }
    goto L_0DB451;
L_0DB451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB451u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB451u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB451 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xB453u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB454u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DB451u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB454;
L_0DB454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB454u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB454u,0x0DB454u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB454u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB454u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB454 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xB456u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB457u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DB454u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB457;
L_0DB457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB457u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB457u,0x0DB457u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB457u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB457u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB457 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB459;
L_0DB459:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB459u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB459u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB459u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB459 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DB45B;
L_0DB45B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB45Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB45B INX
    cpu.inc('X');
    goto L_0DB45C;
L_0DB45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB45Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Cu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB45C CPX
    cpu.compareX(0x2u);
    goto L_0DB45E;
L_0DB45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB45E BNE -> $0DB43C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB43C; }
    goto L_0DB460;
L_0DB460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB460u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB460u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB460 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB460u);return;} hw.unresolvedReturn(0x0DB460u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DCEA6_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DCEA6u: goto L_0DCEA6;
    case 0x0DCEA8u: goto L_0DCEA8;
    case 0x0DCEAAu: goto L_0DCEAA;
    case 0x0DCEABu: goto L_0DCEAB;
    case 0x0DCEADu: goto L_0DCEAD;
    case 0x0DCEAEu: goto L_0DCEAE;
    case 0x0DCEB1u: goto L_0DCEB1;
    case 0x0DCEB3u: goto L_0DCEB3;
    case 0x0DCEB6u: goto L_0DCEB6;
    case 0x0DCEB9u: goto L_0DCEB9;
    case 0x0DCEBBu: goto L_0DCEBB;
    case 0x0DCEBDu: goto L_0DCEBD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DCEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA6u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCEA6 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DCEA8;
L_0DCEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCEA8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCEAA;
L_0DCEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEAAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCEAA SEC
    cpu.setFlag('C', true);
    goto L_0DCEAB;
L_0DCEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEABu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCEAB SBC
    cpu.sbc(0x51u);
    goto L_0DCEAD;
L_0DCEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEADu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCEAD TAX
    cpu.transfer("TAX");
    goto L_0DCEAE;
L_0DCEAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEAEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEAEu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCEAE JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xCEB0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCEB1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DCEAEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCEB1;
L_0DCEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEB1u,0x0DCEB1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCEB1 LDA
    cpu.setA(0x84u, 8);
    goto L_0DCEB3;
L_0DCEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB3u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCEB3 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xCEB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCEB6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DCEB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCEB6;
L_0DCEB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEB6u,0x0DCEB6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB6u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCEB6 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xCEB8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCEB9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DCEB6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCEB9;
L_0DCEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEB9u,0x0DCEB9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCEB9 LDA
    cpu.setA(0x85u, 8);
    goto L_0DCEBB;
L_0DCEBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBBu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBBu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DCEBB STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DCEBD;
L_0DCEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCEBD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DCEBDu);return;} hw.unresolvedReturn(0x0DCEBDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_E48172_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xE48172u: goto L_E48172;
    case 0xE48174u: goto L_E48174;
    case 0xE48176u: goto L_E48176;
    case 0xE48177u: goto L_E48177;
    case 0xE48178u: goto L_E48178;
    case 0xE48179u: goto L_E48179;
    case 0xE4817Cu: goto L_E4817C;
    case 0xE4817Du: goto L_E4817D;
    case 0xE48180u: goto L_E48180;
    case 0xE48182u: goto L_E48182;
    case 0xE48183u: goto L_E48183;
    case 0xE48186u: goto L_E48186;
    case 0xE48188u: goto L_E48188;
    case 0xE4818Au: goto L_E4818A;
    case 0xE4818Du: goto L_E4818D;
    case 0xE4818Fu: goto L_E4818F;
    case 0xE48191u: goto L_E48191;
    case 0xE48192u: goto L_E48192;
    case 0xE48193u: goto L_E48193;
    case 0xE48194u: goto L_E48194;
    case 0xE48196u: goto L_E48196;
    case 0xE48198u: goto L_E48198;
    case 0xE4819Au: goto L_E4819A;
    case 0xE4819Cu: goto L_E4819C;
    case 0xE4819Eu: goto L_E4819E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_E48172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8172u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8172u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48172 REP
    cpu.rep(0x20u);
    goto L_E48174;
L_E48174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48174 LDY
    cpu.setY(0x0u, 8);
    goto L_E48176;
L_E48176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8176u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8176u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $E48176 PHX
    cpu.push("PHX", hw);
    goto L_E48177;
L_E48177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8177u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8177u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48177 TXA
    cpu.transfer("TXA");
    goto L_E48178;
L_E48178:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8178u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8178u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8178u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48178 CLC
    cpu.setFlag('C', false);
    goto L_E48179;
L_E48179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8179u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8179u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48179 ADC
    cpu.adc(0xEu);
    goto L_E4817C;
L_E4817C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4817C TAX
    cpu.transfer("TAX");
    goto L_E4817D;
L_E4817D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Du, 5u + ((((0x0AF6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0AF6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4817D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xAF6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48180;
L_E48180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8180u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8180u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48180 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_E48182;
L_E48182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8182u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8182u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $E48182 PLX
    cpu.pop("PLX", hw);
    goto L_E48183;
L_E48183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8183u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8183u, 5u + ((((0x0AF6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0AF6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48183 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xAF6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48186;
L_E48186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8186u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8186u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48186 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_E48188;
L_E48188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8188u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8188u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48188 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4818A;
L_E4818A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Au, 6u, 3u, cpu.address("absx", 0x0AF6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4818A STA
    hw.write(cpu.address("absx", 0xAF6u), cpu.a, cpu.m8?8:16);
    goto L_E4818D;
L_E4818D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4818D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4818F;
L_E4818F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4818F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_E48191;
L_E48191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8191u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8191u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48191 INX
    cpu.inc('X');
    goto L_E48192;
L_E48192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8192u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8192u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48192 INX
    cpu.inc('X');
    goto L_E48193;
L_E48193:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8193u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8193u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8193u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48193 INY
    cpu.inc('Y');
    goto L_E48194;
L_E48194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8194u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8194u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48194 CPY
    cpu.compareY(0x8u);
    goto L_E48196;
L_E48196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8196u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8196u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8196u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48196 BEQ -> $E48176
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_E48176; }
    goto L_E48198;
L_E48198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8198u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8198u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48198 CPY
    cpu.compareY(0x10u);
    goto L_E4819A;
L_E4819A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4819A BNE -> $E48183
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_E48183; }
    goto L_E4819C;
L_E4819C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4819C SEP
    cpu.sep(0x20u);
    goto L_E4819E;
L_E4819E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E4819E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xE4819Eu);return;} hw.unresolvedReturn(0xE4819Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

