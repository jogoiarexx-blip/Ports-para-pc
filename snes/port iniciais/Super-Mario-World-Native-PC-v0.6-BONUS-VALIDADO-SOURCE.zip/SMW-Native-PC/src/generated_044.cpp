#include "generated.hpp"
void sub_0082C3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0082C3u: goto L_0082C3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0082C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0082C3 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x0082C3u);return;}
}

void sub_009045_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009045u: goto L_009045;
    case 0x009047u: goto L_009047;
    case 0x009049u: goto L_009049;
    case 0x00904Bu: goto L_00904B;
    case 0x00904Du: goto L_00904D;
    case 0x00904Eu: goto L_00904E;
    case 0x009050u: goto L_009050;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009045 LDX
    cpu.setX(0x0u, 8);
    goto L_009047;
L_009047:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9047u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9047u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9047u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009047 CMP
    cpu.compareA(0xAu);
    goto L_009049;
L_009049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9049u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9049u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009049 BCC -> $009050
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_009050; }
    goto L_00904B;
L_00904B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00904B SBC
    cpu.sbc(0xAu);
    goto L_00904D;
L_00904D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00904D INX
    cpu.inc('X');
    goto L_00904E;
L_00904E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00904E BRA -> $009047
    goto L_009047;
L_009050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9050u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9050u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009050 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009050u);return;} hw.unresolvedReturn(0x009050u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00A1A6_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A1A6u: goto L_00A1A6;
    case 0x00A1A8u: goto L_00A1A8;
    case 0x00A1AAu: goto L_00A1AA;
    case 0x00A1ADu: goto L_00A1AD;
    case 0x00A1AFu: goto L_00A1AF;
    case 0x00A1B0u: goto L_00A1B0;
    case 0x00A1B2u: goto L_00A1B2;
    case 0x00A1B5u: goto L_00A1B5;
    case 0x00A1B8u: goto L_00A1B8;
    case 0x00A1B9u: goto L_00A1B9;
    case 0x00A1BBu: goto L_00A1BB;
    case 0x00A1BDu: goto L_00A1BD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A1A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A1A6 REP
    cpu.rep(0x10u);
    goto L_00A1A8;
L_00A1A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A1A8 SEP
    cpu.sep(0x20u);
    goto L_00A1AA;
L_00A1AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AAu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A1AA LDX
    cpu.setX(0xBDu, 16);
    goto L_00A1AD;
L_00A1AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1ADu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A1AD STZ
    hw.write(cpu.address("dpx", 0x1Au), 0, cpu.m8?8:16);
    goto L_00A1AF;
L_00A1AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AFu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A1AF DEX
    cpu.decReg('X');
    goto L_00A1B0;
L_00A1B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A1B0 BPL -> $00A1AD
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00A1AD; }
    goto L_00A1B2;
L_00A1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A1B2 LDX
    cpu.setX(0x7CEu, 16);
    goto L_00A1B5;
L_00A1B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B5u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B5u, 5u, 3u, cpu.address("absx", 0x13D3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A1B5 STZ
    hw.write(cpu.address("absx", 0x13D3u), 0, cpu.m8?8:16);
    goto L_00A1B8;
L_00A1B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B8u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A1B8 DEX
    cpu.decReg('X');
    goto L_00A1B9;
L_00A1B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A1B9 BPL -> $00A1B5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00A1B5; }
    goto L_00A1BB;
L_00A1BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BBu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A1BB SEP
    cpu.sep(0x10u);
    goto L_00A1BD;
L_00A1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A1BD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A1BDu);return;} hw.unresolvedReturn(0x00A1BDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00A9DA_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A9DAu: goto L_00A9DA;
    case 0x00A9DCu: goto L_00A9DC;
    case 0x00A9DFu: goto L_00A9DF;
    case 0x00A9E1u: goto L_00A9E1;
    case 0x00A9E4u: goto L_00A9E4;
    case 0x00A9E5u: goto L_00A9E5;
    case 0x00A9E6u: goto L_00A9E6;
    case 0x00A9E7u: goto L_00A9E7;
    case 0x00A9EAu: goto L_00A9EA;
    case 0x00A9ECu: goto L_00A9EC;
    case 0x00A9EDu: goto L_00A9ED;
    case 0x00A9EEu: goto L_00A9EE;
    case 0x00A9F0u: goto L_00A9F0;
    case 0x00A9F2u: goto L_00A9F2;
    case 0x00A9F4u: goto L_00A9F4;
    case 0x00A9F6u: goto L_00A9F6;
    case 0x00A9F9u: goto L_00A9F9;
    case 0x00A9FCu: goto L_00A9FC;
    case 0x00A9FFu: goto L_00A9FF;
    case 0x00AA01u: goto L_00AA01;
    case 0x00AA04u: goto L_00AA04;
    case 0x00AA06u: goto L_00AA06;
    case 0x00AA08u: goto L_00AA08;
    case 0x00AA0Bu: goto L_00AA0B;
    case 0x00AA0Du: goto L_00AA0D;
    case 0x00AA0Fu: goto L_00AA0F;
    case 0x00AA11u: goto L_00AA11;
    case 0x00AA13u: goto L_00AA13;
    case 0x00AA16u: goto L_00AA16;
    case 0x00AA17u: goto L_00AA17;
    case 0x00AA19u: goto L_00AA19;
    case 0x00AA1Cu: goto L_00AA1C;
    case 0x00AA1Eu: goto L_00AA1E;
    case 0x00AA20u: goto L_00AA20;
    case 0x00AA22u: goto L_00AA22;
    case 0x00AA25u: goto L_00AA25;
    case 0x00AA26u: goto L_00AA26;
    case 0x00AA27u: goto L_00AA27;
    case 0x00AA28u: goto L_00AA28;
    case 0x00AA2Bu: goto L_00AA2B;
    case 0x00AA2Du: goto L_00AA2D;
    case 0x00AA2Eu: goto L_00AA2E;
    case 0x00AA2Fu: goto L_00AA2F;
    case 0x00AA31u: goto L_00AA31;
    case 0x00AA33u: goto L_00AA33;
    case 0x00AA35u: goto L_00AA35;
    case 0x00AA37u: goto L_00AA37;
    case 0x00AA3Au: goto L_00AA3A;
    case 0x00AA3Du: goto L_00AA3D;
    case 0x00AA40u: goto L_00AA40;
    case 0x00AA42u: goto L_00AA42;
    case 0x00AA45u: goto L_00AA45;
    case 0x00AA47u: goto L_00AA47;
    case 0x00AA49u: goto L_00AA49;
    case 0x00AA4Cu: goto L_00AA4C;
    case 0x00AA4Eu: goto L_00AA4E;
    case 0x00AA50u: goto L_00AA50;
    case 0x00AA52u: goto L_00AA52;
    case 0x00AA54u: goto L_00AA54;
    case 0x00AA57u: goto L_00AA57;
    case 0x00AA58u: goto L_00AA58;
    case 0x00AA5Au: goto L_00AA5A;
    case 0x00AA5Bu: goto L_00AA5B;
    case 0x00AA5Du: goto L_00AA5D;
    case 0x00AA60u: goto L_00AA60;
    case 0x00AA62u: goto L_00AA62;
    case 0x00AA64u: goto L_00AA64;
    case 0x00AA67u: goto L_00AA67;
    case 0x00AA68u: goto L_00AA68;
    case 0x00AA6Au: goto L_00AA6A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A9DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9DA LDA
    cpu.setA(0x80u, 8);
    goto L_00A9DC;
L_00A9DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DCu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9DC STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_00A9DF;
L_00A9DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9DF LDX
    cpu.setX(0x3u, 8);
    goto L_00A9E1;
L_00A9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E1u, 4u, 3u, cpu.address("abs", 0x192Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9E1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x192Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A9E4;
L_00A9E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9E4 ASL
    cpu.aslA();
    goto L_00A9E5;
L_00A9E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9E5 ASL
    cpu.aslA();
    goto L_00A9E6;
L_00A9E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9E6 TAY
    cpu.transfer("TAY");
    goto L_00A9E7;
L_00A9E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u, 4u + ((((0xA8C3u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9E7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA8C3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A9EA;
L_00A9EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9EA STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00A9EC;
L_00A9EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ECu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9EC INY
    cpu.inc('Y');
    goto L_00A9ED;
L_00A9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9ED DEX
    cpu.decReg('X');
    goto L_00A9EE;
L_00A9EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9EE BPL -> $00A9E7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00A9E7; }
    goto L_00A9F0;
L_00A9F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9F0 LDA
    cpu.setA(0x3u, 8);
    goto L_00A9F2;
L_00A9F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9F2 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_00A9F4;
L_00A9F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F4u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9F4 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A9F6;
L_00A9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9F6 STZ
    hw.write(cpu.address("abs", 0x2116u), 0, cpu.m8?8:16);
    goto L_00A9F9;
L_00A9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u, 4u + ((((0xA9D2u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA9D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9F9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA9D2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A9FC;
L_00A9FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FCu, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9FC STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_00A9FF;
L_00A9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9FF LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00AA01;
L_00AA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u, 4u + ((((0x0101u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0101u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA01 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x101u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA04;
L_00AA04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA04 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16));
    goto L_00AA06;
L_00AA06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA06u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA06 BEQ -> $00AA0B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00AA0B; }
    goto L_00AA08;
L_00AA08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA08u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA08u, 6u, 3u, cpu.address("abs", 0xAA6Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AA08 JSR -> $00AA6B stack real
    { cpu.push16Value(hw,0xAA0Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA0Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA6Bu), 0x00AA08u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AA0B;
L_00AA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA0Bu,0x00AA0Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Bu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA0B DEC
    cpu.decMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_00AA0D;
L_00AA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA0D BPL -> $00A9F4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00A9F4; }
    goto L_00AA0F;
L_00AA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA0F LDX
    cpu.setX(0x3u, 8);
    goto L_00AA11;
L_00AA11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA11u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA11 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA13;
L_00AA13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA13u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA13u, 5u, 3u, cpu.address("absx", 0x0101u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA13 STA
    hw.write(cpu.address("absx", 0x101u), cpu.a, cpu.m8?8:16);
    goto L_00AA16;
L_00AA16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA16u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA16 DEX
    cpu.decReg('X');
    goto L_00AA17;
L_00AA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA17 BPL -> $00AA11
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AA11; }
    goto L_00AA19;
L_00AA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA19 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA1C;
L_00AA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA1C CMP
    cpu.compareA(0xFEu);
    goto L_00AA1E;
L_00AA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA1E BCS -> $00AA5B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00AA5B; }
    goto L_00AA20;
L_00AA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA20 LDX
    cpu.setX(0x3u, 8);
    goto L_00AA22;
L_00AA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA22 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA25;
L_00AA25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA25u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA25 ASL
    cpu.aslA();
    goto L_00AA26;
L_00AA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA26u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA26 ASL
    cpu.aslA();
    goto L_00AA27;
L_00AA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA27u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA27u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA27 TAY
    cpu.transfer("TAY");
    goto L_00AA28;
L_00AA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA28u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA28u, 4u + ((((0xA92Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA92Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA28 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA92Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA2B;
L_00AA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA2B STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00AA2D;
L_00AA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA2D INY
    cpu.inc('Y');
    goto L_00AA2E;
L_00AA2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA2E DEX
    cpu.decReg('X');
    goto L_00AA2F;
L_00AA2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA2F BPL -> $00AA28
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AA28; }
    goto L_00AA31;
L_00AA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA31 LDA
    cpu.setA(0x3u, 8);
    goto L_00AA33;
L_00AA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA33u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA33u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA33 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_00AA35;
L_00AA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA35 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00AA37;
L_00AA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA37 STZ
    hw.write(cpu.address("abs", 0x2116u), 0, cpu.m8?8:16);
    goto L_00AA3A;
L_00AA3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Au, 4u + ((((0xA9D6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA9D6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA3A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA9D6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA3D;
L_00AA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA3D STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_00AA40;
L_00AA40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA40u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA40u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA40 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00AA42;
L_00AA42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA42u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA42u, 4u + ((((0x0105u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA42 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x105u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA45;
L_00AA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA45u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA45u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA45 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16));
    goto L_00AA47;
L_00AA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA47u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA47 BEQ -> $00AA4C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00AA4C; }
    goto L_00AA49;
L_00AA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u, 6u, 3u, cpu.address("abs", 0xAA6Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AA49 JSR -> $00AA6B stack real
    { cpu.push16Value(hw,0xAA4Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA4Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA6Bu), 0x00AA49u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AA4C;
L_00AA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA4Cu,0x00AA4Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA4C DEC
    cpu.decMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_00AA4E;
L_00AA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA4E BPL -> $00AA35
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AA35; }
    goto L_00AA50;
L_00AA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA50u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA50 LDX
    cpu.setX(0x3u, 8);
    goto L_00AA52;
L_00AA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA52u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA52 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA54;
L_00AA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u, 5u, 3u, cpu.address("absx", 0x0105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA54 STA
    hw.write(cpu.address("absx", 0x105u), cpu.a, cpu.m8?8:16);
    goto L_00AA57;
L_00AA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA57u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA57u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA57 DEX
    cpu.decReg('X');
    goto L_00AA58;
L_00AA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA58 BPL -> $00AA52
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AA52; }
    goto L_00AA5A;
L_00AA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AA5A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00AA5Au);return;} hw.unresolvedReturn(0x00AA5Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00AA5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA5B BEQ -> $00AA60
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00AA60; }
    goto L_00AA5D;
L_00AA5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Du, 6u, 3u, cpu.address("abs", 0xAB42u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AA5D JSR -> $00AB42 stack real
    { cpu.push16Value(hw,0xAA5Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA60u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAB42u), 0x00AA5Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AA60;
L_00AA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA60u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA60u,0x00AA60u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA60u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA60 LDX
    cpu.setX(0x3u, 8);
    goto L_00AA62;
L_00AA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA62u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA62 LDA
    cpu.setA(0x80u, 8);
    goto L_00AA64;
L_00AA64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA64u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA64u, 5u, 3u, cpu.address("absx", 0x0105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA64 STA
    hw.write(cpu.address("absx", 0x105u), cpu.a, cpu.m8?8:16);
    goto L_00AA67;
L_00AA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA67u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA67 DEX
    cpu.decReg('X');
    goto L_00AA68;
L_00AA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA68u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA68 BPL -> $00AA64
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AA64; }
    goto L_00AA6A;
L_00AA6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AA6A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00AA6Au);return;} hw.unresolvedReturn(0x00AA6Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00D044_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00D044u: goto L_00D044;
    case 0x00D046u: goto L_00D046;
    case 0x00D049u: goto L_00D049;
    case 0x00D04Au: goto L_00D04A;
    case 0x00D04Bu: goto L_00D04B;
    case 0x00D04Du: goto L_00D04D;
    case 0x00D04Fu: goto L_00D04F;
    case 0x00D050u: goto L_00D050;
    case 0x00D053u: goto L_00D053;
    case 0x00D056u: goto L_00D056;
    case 0x00D058u: goto L_00D058;
    case 0x00D059u: goto L_00D059;
    case 0x00D05Cu: goto L_00D05C;
    case 0x00D05Fu: goto L_00D05F;
    case 0x00D061u: goto L_00D061;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00D044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD044u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD044u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D044 LDY
    cpu.setY(0x1u, 8);
    goto L_00D046;
L_00D046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD046u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD046u, 4u, 3u, cpu.address("abs", 0x13E8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D046 STY
    hw.write(cpu.address("abs", 0x13E8u), cpu.y, cpu.x8?8:16);
    goto L_00D049;
L_00D049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD049u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD049u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D049 ASL
    cpu.aslA();
    goto L_00D04A;
L_00D04A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD04Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D04A TAY
    cpu.transfer("TAY");
    goto L_00D04B;
L_00D04B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD04Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D04B REP
    cpu.rep(0x20u);
    goto L_00D04D;
L_00D04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD04Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D04D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D04F;
L_00D04F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD04Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D04F CLC
    cpu.setFlag('C', false);
    goto L_00D050;
L_00D050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD050u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD050u, 5u + ((((0xD034u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD034u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D050 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD034u), cpu.m8?8:16));
    goto L_00D053;
L_00D053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD053u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD053u, 5u, 3u, cpu.address("abs", 0x13E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D053 STA
    hw.write(cpu.address("abs", 0x13E9u), cpu.a, cpu.m8?8:16);
    goto L_00D056;
L_00D056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD056u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD056u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD056u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D056 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D058;
L_00D058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD058u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD058u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D058 CLC
    cpu.setFlag('C', false);
    goto L_00D059;
L_00D059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD059u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD059u, 5u + ((((0xD03Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD03Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D059 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD03Cu), cpu.m8?8:16));
    goto L_00D05C;
L_00D05C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD05Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Cu, 5u, 3u, cpu.address("abs", 0x13EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D05C STA
    hw.write(cpu.address("abs", 0x13EBu), cpu.a, cpu.m8?8:16);
    goto L_00D05F;
L_00D05F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD05Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D05F SEP
    cpu.sep(0x20u);
    goto L_00D061;
L_00D061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD061u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD061u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD061u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D061 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00D061u);return;} hw.unresolvedReturn(0x00D061u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00EADB_E1M1X1CQ_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE1Du: goto L_00EE1D;
    case 0x00EE20u: goto L_00EE20;
    case 0x00EE22u: goto L_00EE22;
    case 0x00EE24u: goto L_00EE24;
    case 0x00EE26u: goto L_00EE26;
    case 0x00EE28u: goto L_00EE28;
    case 0x00EE2Au: goto L_00EE2A;
    case 0x00EE2Bu: goto L_00EE2B;
    case 0x00EE2Du: goto L_00EE2D;
    case 0x00EE2Fu: goto L_00EE2F;
    case 0x00EE31u: goto L_00EE31;
    case 0x00EE32u: goto L_00EE32;
    case 0x00EE33u: goto L_00EE33;
    case 0x00EE34u: goto L_00EE34;
    case 0x00EE35u: goto L_00EE35;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE1Du))return;
  // 14 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 5u, 3u, cpu.address("abs", 0x1471u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE20;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 5u, 3u, cpu.address("abs", 0x1471u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE20;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE20;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE1Du,0x00EE1Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE20u))return;
  // 14 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE20 BEQ -> $00EE2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE2D; }
    goto L_00EE22;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE20 BEQ -> $00EE2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE2D; }
    goto L_00EE22;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE20 BEQ -> $00EE2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE2D; }
    goto L_00EE22;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE20 BEQ -> $00EE2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE2D; }
    goto L_00EE22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE20u,0x00EE20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE22u))return;
  // 14 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE24;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE24;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE24;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE24;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE22u,0x00EE22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE24u))return;
  // 14 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE24 BMI -> $00EE2D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EE2D; }
    goto L_00EE26;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE24 BMI -> $00EE2D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EE2D; }
    goto L_00EE26;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE24 BMI -> $00EE2D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EE2D; }
    goto L_00EE26;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE24 BMI -> $00EE2D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EE2D; }
    goto L_00EE26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE24u,0x00EE24u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE26u))return;
  // 14 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE26 STZ
    hw.write(cpu.address("dp", 0x8Eu), 0, cpu.m8?8:16);
    goto L_00EE28;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE26 STZ
    hw.write(cpu.address("dp", 0x8Eu), 0, cpu.m8?8:16);
    goto L_00EE28;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE26 STZ
    hw.write(cpu.address("dp", 0x8Eu), 0, cpu.m8?8:16);
    goto L_00EE28;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE26 STZ
    hw.write(cpu.address("dp", 0x8Eu), 0, cpu.m8?8:16);
    goto L_00EE28;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE26u,0x00EE26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE28u))return;
  // 14 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE28u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE28u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE28 LDY
    cpu.setY(0x4C20u, 16);
    goto L_00EE2B;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE28u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE28 LDY
    cpu.setY(0x20u, 8);
    goto L_00EE2A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE28u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE28u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE28 LDY
    cpu.setY(0x4C20u, 16);
    goto L_00EE2B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE28u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE28 LDY
    cpu.setY(0x20u, 8);
    goto L_00EE2A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE28u,0x00EE28u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Au, 3u, 3u, cpu.address("abs", 0xEEE1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2A JMP -> $00EEE1
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xEEE1u),0x00EE2Au); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Au, 3u, 3u, cpu.address("abs", 0xEEE1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2A JMP -> $00EEE1
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xEEE1u),0x00EE2Au); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE2Au,0x00EE2Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Bu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Bu,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xEEu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00EE2B SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0xEEu), cpu.m8?8:16));
    goto L_00EE2D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Bu,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xEEu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00EE2B SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0xEEu), cpu.m8?8:16));
    goto L_00EE2D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE2Bu,0x00EE2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Du))return;
  // 14 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE2F;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE2F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE2F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE2F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE2Du,0x00EE2Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Fu))return;
  // 14 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2F AND
    cpu.logicAnd(0x504u);
    goto L_00EE32;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2F AND
    cpu.logicAnd(0x504u);
    goto L_00EE32;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2F AND
    cpu.logicAnd(0x4u);
    goto L_00EE31;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2F AND
    cpu.logicAnd(0x4u);
    goto L_00EE31;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE2Fu,0x00EE2Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE31u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE31u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE31 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16));
    goto L_00EE33;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE31u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE31 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16));
    goto L_00EE33;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE31u,0x00EE31u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE32u))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE32u,cpu,0x72u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE32u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xD0u) & 0xFFFFu), 2u, 0u);
    // $00EE32 ADC
    cpu.adc(hw.readW(cpu.addressDpIndirect(hw, 0xD0u), cpu.m8?8:16));
    goto L_00EE34;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE32u,cpu,0x72u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE32u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xD0u) & 0xFFFFu), 2u, 0u);
    // $00EE32 ADC
    cpu.adc(hw.readW(cpu.addressDpIndirect(hw, 0xD0u), cpu.m8?8:16));
    goto L_00EE34;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE32u,0x00EE32u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE33u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE33u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE33 BNE -> $00EE39
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE39u,0x00EE33u); return; }
    goto L_00EE35;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE33u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE33 BNE -> $00EE39
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE39u,0x00EE33u); return; }
    goto L_00EE35;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE33u,0x00EE33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE34u))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE34u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE34u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE34 TSB
    cpu.tsb(hw, cpu.address("dp", 0xA9u), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE36u,0x00EE34u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE34u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE34u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE34 TSB
    cpu.tsb(hw, cpu.address("dp", 0xA9u), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE36u,0x00EE34u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE34u,0x00EE34u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE35u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE35u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE35 LDA
    cpu.setA(0x24u, 8);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE37u,0x00EE35u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE35u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE35 LDA
    cpu.setA(0x24u, 8);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE37u,0x00EE35u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE35u,0x00EE35u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E0M1X1CQ_part8(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE3Au: goto L_00EE3A;
    case 0x00EE3Du: goto L_00EE3D;
    case 0x00EE40u: goto L_00EE40;
    case 0x00EE42u: goto L_00EE42;
    case 0x00EE43u: goto L_00EE43;
    case 0x00EE44u: goto L_00EE44;
    case 0x00EE45u: goto L_00EE45;
    case 0x00EE46u: goto L_00EE46;
    case 0x00EE48u: goto L_00EE48;
    case 0x00EE49u: goto L_00EE49;
    case 0x00EE4Au: goto L_00EE4A;
    case 0x00EE4Cu: goto L_00EE4C;
    case 0x00EE4Du: goto L_00EE4D;
    case 0x00EE4Eu: goto L_00EE4E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE3Au))return;
  // 15 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Au, 5u, 3u, cpu.address("abs", 0x1693u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE3A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE3D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Au, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE3A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE3D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Au, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE3A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE3D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE3Au,0x00EE3Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE3Du))return;
  // 15 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Du, 5u, 3u, cpu.address("abs", 0x1931u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE3D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE40;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Du, 5u, 3u, cpu.address("abs", 0x1931u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE3D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE40;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Du, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE3D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE40;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE3Du,0x00EE3Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE40u))return;
  // 15 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE40u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE40u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE40 CMP
    cpu.compareA(0xF002u);
    goto L_00EE43;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE40u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE40u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE40 CMP
    cpu.compareA(0xF002u);
    goto L_00EE43;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE40u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE40 CMP
    cpu.compareA(0x2u);
    goto L_00EE42;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE40u,0x00EE40u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE42u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE42u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE42 BEQ -> $00EE48
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE48; }
    goto L_00EE44;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE42u,0x00EE42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE43u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE43u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE43u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE43 TSB
    cpu.tsb(hw, cpu.address("dp", 0xC9u), cpu.m8?8:16);
    goto L_00EE45;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE43u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE43u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE43 TSB
    cpu.tsb(hw, cpu.address("dp", 0xC9u), cpu.m8?8:16);
    goto L_00EE45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE43u,0x00EE43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE44u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE44u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE44 CMP
    cpu.compareA(0x8u);
    goto L_00EE46;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE44u,0x00EE44u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE45u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE45u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE45u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EE45 PHP
    cpu.push("PHP", hw);
    goto L_00EE46;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE45u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE45u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EE45 PHP
    cpu.push("PHP", hw);
    goto L_00EE46;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE45u,0x00EE45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE46u))return;
  // 15 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE46u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE46u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE46 BNE -> $00EE57
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE57u,0x00EE46u); return; }
    goto L_00EE48;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE46u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE46u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE46 BNE -> $00EE57
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE57u,0x00EE46u); return; }
    goto L_00EE48;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE46u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE46u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE46 BNE -> $00EE57
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE57u,0x00EE46u); return; }
    goto L_00EE48;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE46u,0x00EE46u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE48u))return;
  // 15 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE48u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE48 TYA
    cpu.transfer("TYA");
    goto L_00EE49;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE48u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE48 TYA
    cpu.transfer("TYA");
    goto L_00EE49;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE48u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE48 TYA
    cpu.transfer("TYA");
    goto L_00EE49;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE48u,0x00EE48u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE49u))return;
  // 15 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE49u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE49 SEC
    cpu.setFlag('C', true);
    goto L_00EE4A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE49u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE49 SEC
    cpu.setFlag('C', true);
    goto L_00EE4A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE49u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE49 SEC
    cpu.setFlag('C', true);
    goto L_00EE4A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE49u,0x00EE49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE4Au))return;
  // 15 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE4A SBC
    cpu.sbc(0xC90Cu);
    goto L_00EE4D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE4A SBC
    cpu.sbc(0xC90Cu);
    goto L_00EE4D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE4A SBC
    cpu.sbc(0xCu);
    goto L_00EE4C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Au,0x00EE4Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE4Cu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE4C CMP
    cpu.compareA(0x2u);
    goto L_00EE4E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Cu,0x00EE4Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE4Du))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Du,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE4Fu,true);
    hw.requestDispatch(0x0082C3u,0x00EE4Du);return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Du,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE4Fu,true);
    hw.requestDispatch(0x0082C3u,0x00EE4Du);return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Du,0x00EE4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE4Eu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE4E BCS -> $00EE57
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE57u,0x00EE4Eu); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE50u,0x00EE4Eu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Eu,0x00EE4Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E1M1X1CQ_part6(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE4Du: goto L_00EE4D;
    case 0x00EE4Eu: goto L_00EE4E;
    case 0x00EE4Fu: goto L_00EE4F;
    case 0x00EE50u: goto L_00EE50;
    case 0x00EE51u: goto L_00EE51;
    case 0x00EE52u: goto L_00EE52;
    case 0x00EE55u: goto L_00EE55;
    case 0x00EE57u: goto L_00EE57;
    case 0x00EE5Au: goto L_00EE5A;
    case 0x00EE5Cu: goto L_00EE5C;
    case 0x00EE5Du: goto L_00EE5D;
    case 0x00EE5Fu: goto L_00EE5F;
    case 0x00EE61u: goto L_00EE61;
    case 0x00EE62u: goto L_00EE62;
    case 0x00EE63u: goto L_00EE63;
    case 0x00EE64u: goto L_00EE64;
    case 0x00EE65u: goto L_00EE65;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE4Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Du,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Du, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE4Fu,true);
    hw.requestDispatch(0x0082C3u,0x00EE4Du);return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Du,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Du, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE4Fu,true);
    hw.requestDispatch(0x0082C3u,0x00EE4Du);return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Du,0x00EE4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE4Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE4E BCS -> $00EE57
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EE57; }
    goto L_00EE50;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Eu,0x00EE4Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE4Fu))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Fu,cpu,0x07u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $00EE4F ORA
    cpu.logicOr(hw.readW(cpu.addressDpLong(hw, 0xAu), cpu.m8?8:16));
    goto L_00EE51;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Fu,cpu,0x07u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $00EE4F ORA
    cpu.logicOr(hw.readW(cpu.addressDpLong(hw, 0xAu), cpu.m8?8:16));
    goto L_00EE51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Fu,0x00EE4Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE50u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE50u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE50 ASL
    cpu.aslA();
    goto L_00EE51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE50u,0x00EE50u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE51u))return;
  // 13 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE51u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE51 TAX
    cpu.transfer("TAX");
    goto L_00EE52;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE51u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE51 TAX
    cpu.transfer("TAX");
    goto L_00EE52;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE51u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE51 TAX
    cpu.transfer("TAX");
    goto L_00EE52;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE51u,0x00EE51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE52u))return;
  // 13 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE52u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE52u, 6u, 3u, cpu.address("abs", 0xEFCDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE52 JSR -> $00EFCD stack real
    { cpu.push16Value(hw,0xEE54u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE55u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEFCDu), 0x00EE52u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE55;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE52u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE52u, 6u, 3u, cpu.address("abs", 0xEFCDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE52 JSR -> $00EFCD stack real
    { cpu.push16Value(hw,0xEE54u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE55u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEFCDu), 0x00EE52u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE55;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE52u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE52u, 6u, 3u, cpu.address("abs", 0xEFCDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE52 JSR -> $00EFCD stack real
    { cpu.push16Value(hw,0xEE54u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE55u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEFCDu), 0x00EE52u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE52u,0x00EE52u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE55u))return;
  // 13 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE55u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE55u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE55 BRA -> $00EE83
    hw.requestDispatch(0x00EE83u,0x00EE55u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE55u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE55u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE55 BRA -> $00EE83
    hw.requestDispatch(0x00EE83u,0x00EE55u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE55u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE55u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE55 BRA -> $00EE83
    hw.requestDispatch(0x00EE83u,0x00EE55u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE55u,0x00EE55u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE57u))return;
  // 12 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE57u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE57u, 6u, 3u, cpu.address("abs", 0xF267u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE57 JSR -> $00F267 stack real
    { cpu.push16Value(hw,0xEE59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE5Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF267u), 0x00EE57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE5A;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE57u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE57u, 6u, 3u, cpu.address("abs", 0xF267u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE57 JSR -> $00F267 stack real
    { cpu.push16Value(hw,0xEE59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE5Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF267u), 0x00EE57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE5A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE57u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE57u, 6u, 3u, cpu.address("abs", 0xF267u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE57 JSR -> $00F267 stack real
    { cpu.push16Value(hw,0xEE59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE5Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF267u), 0x00EE57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE5A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE57u,0x00EE57u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE5Au))return;
  // 20 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5A LDY
    cpu.setY(0xAD03u, 16);
    goto L_00EE5D;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5A LDY
    cpu.setY(0x3u, 8);
    goto L_00EE5C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5A LDY
    cpu.setY(0xAD03u, 16);
    goto L_00EE5D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5A LDY
    cpu.setY(0x3u, 8);
    goto L_00EE5C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE5Au,0x00EE5Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE5Cu))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Cu, 5u, 3u, cpu.address("abs", 0x1693u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE5F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Cu, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE5Cu,0x00EE5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE5Du))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Du,cpu,0x93u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x16u) & 0xFFFFu), 2u, 0u);
    // $00EE5D STA
    hw.write(cpu.addressStackIndirectY(hw, 0x16u), cpu.a, cpu.m8?8:16);
    goto L_00EE5F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Du,cpu,0x93u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Du, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x16u) & 0xFFFFu), 2u, 0u);
    // $00EE5D STA
    hw.write(cpu.addressStackIndirectY(hw, 0x16u), cpu.a, cpu.m8?8:16);
    goto L_00EE5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE5Du,0x00EE5Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE5Fu))return;
  // 11 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5F CMP
    cpu.compareA(0xD01Eu);
    goto L_00EE62;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5F CMP
    cpu.compareA(0xD01Eu);
    goto L_00EE62;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5F CMP
    cpu.compareA(0x1Eu);
    goto L_00EE61;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5F CMP
    cpu.compareA(0x1Eu);
    goto L_00EE61;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE5Fu,0x00EE5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE61u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE61u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE61 BNE -> $00EE78
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE78u,0x00EE61u); return; }
    goto L_00EE63;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE61u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE61 BNE -> $00EE78
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE78u,0x00EE61u); return; }
    goto L_00EE63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE61u,0x00EE61u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE62u))return;
  // 6 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE62u,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE62u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE62 ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0xA6u), cpu.m8?8:16));
    goto L_00EE64;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE62u,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE62u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE62 ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0xA6u), cpu.m8?8:16));
    goto L_00EE64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE62u,0x00EE62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE63u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE63u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE63u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE63 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE65;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE63u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE63u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE63 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE65;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE63u,0x00EE63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE64u))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE64u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE64u, 6u, 4u, 0xA61CF0u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE64 STA
    hw.write(0xA61CF0u, cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE68u,0x00EE64u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE64u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE64u, 6u, 4u, 0xA61CF0u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE64 STA
    hw.write(0xA61CF0u, cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE68u,0x00EE64u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE64u,0x00EE64u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE65u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE65u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE65 BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE83u,0x00EE65u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE67u,0x00EE65u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE65u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE65 BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE83u,0x00EE65u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE67u,0x00EE65u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE65u,0x00EE65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EC35_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE76u: goto L_00EE76;
    case 0x00EE78u: goto L_00EE78;
    case 0x00EE7Au: goto L_00EE7A;
    case 0x00EE7Cu: goto L_00EE7C;
    case 0x00EE7Fu: goto L_00EE7F;
    case 0x00EE83u: goto L_00EE83;
    case 0x00EE85u: goto L_00EE85;
    case 0x00EE87u: goto L_00EE87;
    case 0x00EE89u: goto L_00EE89;
    case 0x00EE8Bu: goto L_00EE8B;
    case 0x00EE8Du: goto L_00EE8D;
    case 0x00EE8Fu: goto L_00EE8F;
    case 0x00EE92u: goto L_00EE92;
    case 0x00EE94u: goto L_00EE94;
    case 0x00EE95u: goto L_00EE95;
    case 0x00EE96u: goto L_00EE96;
    case 0x00EE98u: goto L_00EE98;
    case 0x00EE9Au: goto L_00EE9A;
    case 0x00EE9Cu: goto L_00EE9C;
    case 0x00EE9Eu: goto L_00EE9E;
    case 0x00EEA0u: goto L_00EEA0;
    case 0x00EEA2u: goto L_00EEA2;
    case 0x00EEA3u: goto L_00EEA3;
    case 0x00EEA6u: goto L_00EEA6;
    case 0x00EEA8u: goto L_00EEA8;
    case 0x00EEAAu: goto L_00EEAA;
    case 0x00EEABu: goto L_00EEAB;
    case 0x00EEACu: goto L_00EEAC;
    case 0x00EEADu: goto L_00EEAD;
    case 0x00EEAEu: goto L_00EEAE;
    case 0x00EEB1u: goto L_00EEB1;
    case 0x00EEB3u: goto L_00EEB3;
    case 0x00EEB4u: goto L_00EEB4;
    case 0x00EEB7u: goto L_00EEB7;
    case 0x00EEBAu: goto L_00EEBA;
    case 0x00EEBBu: goto L_00EEBB;
    case 0x00EEBEu: goto L_00EEBE;
    case 0x00EEC1u: goto L_00EEC1;
    case 0x00EEC2u: goto L_00EEC2;
    case 0x00EEC4u: goto L_00EEC4;
    case 0x00EEC7u: goto L_00EEC7;
    case 0x00EEC9u: goto L_00EEC9;
    case 0x00EECCu: goto L_00EECC;
    case 0x00EECEu: goto L_00EECE;
    case 0x00EED1u: goto L_00EED1;
    case 0x00EED4u: goto L_00EED4;
    case 0x00EED6u: goto L_00EED6;
    case 0x00EED7u: goto L_00EED7;
    case 0x00EED9u: goto L_00EED9;
    case 0x00EEDBu: goto L_00EEDB;
    case 0x00EEDDu: goto L_00EEDD;
    case 0x00EEDFu: goto L_00EEDF;
    case 0x00EEE1u: goto L_00EEE1;
    case 0x00EEE4u: goto L_00EEE4;
    case 0x00EEE6u: goto L_00EEE6;
    case 0x00EEE9u: goto L_00EEE9;
    case 0x00EEEBu: goto L_00EEEB;
    case 0x00EEEDu: goto L_00EEED;
    case 0x00EEEFu: goto L_00EEEF;
    case 0x00EEF2u: goto L_00EEF2;
    case 0x00EEF4u: goto L_00EEF4;
    case 0x00EEF6u: goto L_00EEF6;
    case 0x00EEF8u: goto L_00EEF8;
    case 0x00EEFBu: goto L_00EEFB;
    case 0x00EEFEu: goto L_00EEFE;
    case 0x00EF00u: goto L_00EF00;
    case 0x00EF02u: goto L_00EF02;
    case 0x00EF05u: goto L_00EF05;
    case 0x00EF08u: goto L_00EF08;
    case 0x00EF0Bu: goto L_00EF0B;
    case 0x00EF0Du: goto L_00EF0D;
    case 0x00EF0Fu: goto L_00EF0F;
    case 0x00EF11u: goto L_00EF11;
    case 0x00EF13u: goto L_00EF13;
    case 0x00EF16u: goto L_00EF16;
    case 0x00EF18u: goto L_00EF18;
    case 0x00EF1Au: goto L_00EF1A;
    case 0x00EF1Cu: goto L_00EF1C;
    case 0x00EF1Fu: goto L_00EF1F;
    case 0x00EF21u: goto L_00EF21;
    case 0x00EF23u: goto L_00EF23;
    case 0x00EF25u: goto L_00EF25;
    case 0x00EF26u: goto L_00EF26;
    case 0x00EF28u: goto L_00EF28;
    case 0x00EF2Au: goto L_00EF2A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE76u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE76u,0x00EE76u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE76u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE76u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE76 BRA -> $00EE1D
    hw.requestDispatch(0x00EE1Du,0x00EE76u); return;
L_00EE78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE78u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE78 CMP
    cpu.compareA(0x32u);
    goto L_00EE7A;
L_00EE7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7A BNE -> $00EE7F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE7F; }
    goto L_00EE7C;
L_00EE7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Cu, 4u, 3u, cpu.address("abs", 0x1909u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7C STZ
    hw.write(cpu.address("abs", 0x1909u), 0, cpu.m8?8:16);
    goto L_00EE7F;
L_00EE7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Fu, 8u, 4u, 0x00F120u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EE7F JSL -> $00F120 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEE82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE83u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F120u, 0x00EE7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE83;
L_00EE83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE83u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE83u,0x00EE83u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE83u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE83 LDY
    cpu.setY(0x20u, 8);
    goto L_00EE85;
L_00EE85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE85u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE85u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE85u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE85 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE85u,0x00EE85u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE87u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE87 BPL -> $00EE8F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EE8F; }
    goto L_00EE89;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE87u,0x00EE87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE89u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE89 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE8B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE89u,0x00EE89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8B CMP
    cpu.compareA(0x2u);
    goto L_00EE8D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Bu,0x00EE8Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8D BCC -> $00EE39
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE39u,0x00EE8Du); return; }
    goto L_00EE8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Du,0x00EE8Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu, 4u, 3u, cpu.address("abs", 0x1423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1423u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE92;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,0x00EE8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE92u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE92 BEQ -> $00EED1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EED1; }
    goto L_00EE94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE92u,0x00EE92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE94u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE94 DEX
    cpu.decReg('X');
    goto L_00EE95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE94u,0x00EE94u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE95u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE95 TXA
    cpu.transfer("TXA");
    goto L_00EE96;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE95u,0x00EE95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE96u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0x3u);
    goto L_00EE98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE96u,0x00EE96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE98u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE98 BEQ -> $00EEAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EEAA; }
    goto L_00EE9A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE98u,0x00EE98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9A CMP
    cpu.compareA(0x2u);
    goto L_00EE9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Au,0x00EE9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9C BCS -> $00EED1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EED1; }
    goto L_00EE9E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,0x00EE9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9E REP
    cpu.rep(0x20u);
    goto L_00EEA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,0x00EE9Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA0u,0x00EEA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA2 SEC
    cpu.setFlag('C', true);
    goto L_00EEA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA2u,0x00EEA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA3 SBC
    cpu.sbc(0x10u);
    goto L_00EEA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA3u,0x00EEA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA6 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_00EEA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA6u,0x00EEA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA8 SEP
    cpu.sep(0x20u);
    goto L_00EEAA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA8u,0x00EEA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEAAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAA TXA
    cpu.transfer("TXA");
    goto L_00EEAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAAu,0x00EEAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAB LSR
    cpu.lsrA();
    goto L_00EEAC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEABu,0x00EEABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEACu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAC LSR
    cpu.lsrA();
    goto L_00EEAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEACu,0x00EEACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEADu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAD TAX
    cpu.transfer("TAX");
    goto L_00EEAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEADu,0x00EEADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEAEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAEu, 4u + ((((0x1F27u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F27u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F27u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEB1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAEu,0x00EEAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB1 BNE -> $00EED1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EED1; }
    goto L_00EEB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB1u,0x00EEB1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB3 INC
    cpu.inc('A');
    goto L_00EEB4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB3u,0x00EEB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB4u, 5u, 3u, cpu.address("absx", 0x1F27u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB4 STA
    hw.write(cpu.address("absx", 0x1F27u), cpu.a, cpu.m8?8:16);
    goto L_00EEB7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB4u,0x00EEB4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB7u, 4u, 3u, cpu.address("abs", 0x13D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB7 STA
    hw.write(cpu.address("abs", 0x13D2u), cpu.a, cpu.m8?8:16);
    goto L_00EEBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB7u,0x00EEB7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBAu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EEBA PHY
    cpu.push("PHY", hw);
    goto L_00EEBB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBAu,0x00EEBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu, 4u, 3u, cpu.address("abs", 0x191Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEBB STX
    hw.write(cpu.address("abs", 0x191Eu), cpu.x, cpu.x8?8:16);
    goto L_00EEBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBBu,0x00EEBBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu, 6u, 3u, cpu.address("abs", 0xFA45u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EEBE JSR -> $00FA45 stack real
    { cpu.push16Value(hw,0xEEC0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEC1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFA45u), 0x00EEBEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBEu,0x00EEBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EEC1 PLY
    cpu.pop("PLY", hw);
    goto L_00EEC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC1u,0x00EEC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC2 LDA
    cpu.setA(0xCu, 8);
    goto L_00EEC4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC2u,0x00EEC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC4 STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_00EEC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC4u,0x00EEC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC7 LDA
    cpu.setA(0xFFu, 8);
    goto L_00EEC9;
L_00EEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC9 STA
    hw.write(cpu.address("abs", 0xDDAu), cpu.a, cpu.m8?8:16);
    goto L_00EECC;
L_00EECC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEECCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EECC LDA
    cpu.setA(0x8u, 8);
    goto L_00EECE;
L_00EECE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEECEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECEu, 4u, 3u, cpu.address("abs", 0x1493u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EECE STA
    hw.write(cpu.address("abs", 0x1493u), cpu.a, cpu.m8?8:16);
    goto L_00EED1;
L_00EED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED1u,0x00EED1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED4u,0x00EED4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    goto L_00EED7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED6u,0x00EED6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED7u,0x00EED7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED9u,0x00EED9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEDBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDBu,0x00EEDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEDDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16));
    goto L_00EEDF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEDFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDF STA
    hw.write(cpu.address("dp", 0x97u), cpu.a, cpu.m8?8:16);
    goto L_00EEE1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDFu,0x00EEDFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u, 4u + ((((0xE53Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE53Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEE4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE1u,0x00EEE1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE4 BNE -> $00EEEF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EEEF; }
    goto L_00EEE6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE4u,0x00EEE4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE6 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13EDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEE9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE6u,0x00EEE6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF05; }
    goto L_00EEEB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE9u,0x00EEE9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEBu,0x00EEEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF02; }
    goto L_00EEEF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEDu,0x00EEEDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEFu,0x00EEEFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEF4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF2u,0x00EEF2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF4 AND
    cpu.logicAnd(0x4u);
    goto L_00EEF6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF4u,0x00EEF4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF6 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF05; }
    goto L_00EEF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF6u,0x00EEF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF8u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEFB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF8u,0x00EEF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFBu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFBu, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEFB ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13EDu), cpu.m8?8:16));
    goto L_00EEFE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEFBu,0x00EEFBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEFE BNE -> $00EF05
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF05; }
    goto L_00EF00;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEFEu,0x00EEFEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF00u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF00u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF00 LDX
    cpu.setX(0x1Cu, 8);
    goto L_00EF02;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF00u,0x00EF00u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF02u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF02 STX
    hw.write(cpu.address("abs", 0x13EDu), cpu.x, cpu.x8?8:16);
    goto L_00EF05;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF02u,0x00EF02u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF05u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u, 4u + ((((0xE4B9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4B9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF05 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xE4B9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF08;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF05u,0x00EF05u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF08u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF08 STX
    hw.write(cpu.address("abs", 0x13E1u), cpu.x, cpu.x8?8:16);
    goto L_00EF0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF08u,0x00EF08u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0B CPY
    cpu.compareY(0x1Cu);
    goto L_00EF0D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,0x00EF0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0D BCS -> $00EF38
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF38u,0x00EF0Du); return; }
    goto L_00EF0F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Du,0x00EF0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF11;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Fu,0x00EF0Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF11u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF11 BEQ -> $00EF31
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF11u); return; }
    goto L_00EF13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF11u,0x00EF11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF13u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u, 4u + ((((0xE53Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE53Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF13 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF16;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF13u,0x00EF13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF16u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF16u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF16 BEQ -> $00EF31
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF16u); return; }
    goto L_00EF18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF16u,0x00EF16u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF18u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF18u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF18 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00EF1A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF18u,0x00EF18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1A BPL -> $00EF31
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF1Au); return; }
    goto L_00EF1C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF1Au,0x00EF1Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1C STX
    hw.write(cpu.address("abs", 0x13E5u), cpu.x, cpu.x8?8:16);
    goto L_00EF1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,0x00EF1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,0x00EF1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF21u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF21 BPL -> $00EF26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF26; }
    goto L_00EF23;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF21u,0x00EF21u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF23u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF23 EOR
    cpu.logicXor(0xFFu);
    goto L_00EF25;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF23u,0x00EF23u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF25u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF25 INC
    cpu.inc('A');
    goto L_00EF26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF25u,0x00EF25u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF26u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF26 CMP
    cpu.compareA(0x28u);
    goto L_00EF28;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF26u,0x00EF26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF28u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF28u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF28 BCC -> $00EF2F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF2Fu,0x00EF28u); return; }
    goto L_00EF2A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF28u,0x00EF28u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Au, 4u + ((((0xE4FBu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4FBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE4FBu), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF2Du,0x00EF2Au); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF2Au,0x00EF2Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1C1_part27(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF60u: goto L_00EF60;
    case 0x00EF62u: goto L_00EF62;
    case 0x00EF63u: goto L_00EF63;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF60u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF60 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EF62;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF60 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EF62;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF60 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EF62;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF60 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EF62;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF60 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EF62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF60u,0x00EF60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF62u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF62u,0x00EF62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF63u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF63u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF63u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF63u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF63u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF63u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF63u,0x00EF63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part27(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF60u: goto L_00EF60;
    case 0x00EF62u: goto L_00EF62;
    case 0x00EF63u: goto L_00EF63;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF60u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF60 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EF62;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF60 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EF62;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF60 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EF62;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF60 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EF62;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF60 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EF62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF60u,0x00EF60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF62u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF62u,0x00EF62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF63u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF63u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF63u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF63u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF63u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF63u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF63u,0x00EF63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00F3C4_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F376u: goto L_00F376;
    case 0x00F3C4u: goto L_00F3C4;
    case 0x00F3C6u: goto L_00F3C6;
    case 0x00F3C8u: goto L_00F3C8;
    case 0x00F3CAu: goto L_00F3CA;
    case 0x00F3CCu: goto L_00F3CC;
    case 0x00F3CFu: goto L_00F3CF;
    case 0x00F3D0u: goto L_00F3D0;
    case 0x00F3D1u: goto L_00F3D1;
    case 0x00F3D3u: goto L_00F3D3;
    case 0x00F3D4u: goto L_00F3D4;
    case 0x00F3D6u: goto L_00F3D6;
    case 0x00F3D8u: goto L_00F3D8;
    case 0x00F3D9u: goto L_00F3D9;
    case 0x00F3DBu: goto L_00F3DB;
    case 0x00F3DCu: goto L_00F3DC;
    case 0x00F3DDu: goto L_00F3DD;
    case 0x00F3DFu: goto L_00F3DF;
    case 0x00F3E1u: goto L_00F3E1;
    case 0x00F40Au: goto L_00F40A;
    case 0x00F40Cu: goto L_00F40C;
    case 0x00F40Eu: goto L_00F40E;
    case 0x00F411u: goto L_00F411;
    case 0x00F413u: goto L_00F413;
    case 0x00F415u: goto L_00F415;
    case 0x00F417u: goto L_00F417;
    case 0x00F419u: goto L_00F419;
    case 0x00F41Bu: goto L_00F41B;
    case 0x00F41Cu: goto L_00F41C;
    case 0x00F41Du: goto L_00F41D;
    case 0x00F41Eu: goto L_00F41E;
    case 0x00F420u: goto L_00F420;
    case 0x00F423u: goto L_00F423;
    case 0x00F425u: goto L_00F425;
    case 0x00F427u: goto L_00F427;
    case 0x00F429u: goto L_00F429;
    case 0x00F42Bu: goto L_00F42B;
    case 0x00F42Du: goto L_00F42D;
    case 0x00F430u: goto L_00F430;
    case 0x00F431u: goto L_00F431;
    case 0x00F434u: goto L_00F434;
    case 0x00F436u: goto L_00F436;
    case 0x00F439u: goto L_00F439;
    case 0x00F43Bu: goto L_00F43B;
    case 0x00F43Eu: goto L_00F43E;
    case 0x00F43Fu: goto L_00F43F;
    case 0x00F442u: goto L_00F442;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF376u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF376u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F376 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F376u);return;} hw.unresolvedReturn(0x00F376u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00F3C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3C4u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3C4 CPY
    cpu.compareY(0x3Fu);
    goto L_00F3C6;
L_00F3C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3C6 BNE -> $00F376
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F376; }
    goto L_00F3C8;
L_00F3C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3C8u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3C8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3C8 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00F3CA;
L_00F3CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3CAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3CA BEQ -> $00F3CF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F3CF; }
    goto L_00F3CC;
L_00F3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3CCu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3CCu, 3u, 3u, cpu.address("abs", 0xF43Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3CC JMP -> $00F43F
    goto L_00F43F;
L_00F3CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3CFu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3CFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F3CF PHX
    cpu.push("PHX", hw);
    goto L_00F3D0;
L_00F3D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3D0 TAX
    cpu.transfer("TAX");
    goto L_00F3D1;
L_00F3D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3D1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F3D3;
L_00F3D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D3u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3D3 TXY
    cpu.transfer("TXY");
    goto L_00F3D4;
L_00F3D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3D4 BEQ -> $00F3D9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F3D9; }
    goto L_00F3D6;
L_00F3D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D6u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3D6 EOR
    cpu.logicXor(0xFFu);
    goto L_00F3D8;
L_00F3D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D8u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3D8 INC
    cpu.inc('A');
    goto L_00F3D9;
L_00F3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3D9 AND
    cpu.logicAnd(0xFu);
    goto L_00F3DB;
L_00F3DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3DBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3DB ASL
    cpu.aslA();
    goto L_00F3DC;
L_00F3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3DCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3DC CLC
    cpu.setFlag('C', false);
    goto L_00F3DD;
L_00F3DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3DDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3DD ADC
    cpu.adc(0x20u);
    goto L_00F3DF;
L_00F3DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3DFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3DF LDY
    cpu.setY(0x5u, 8);
    goto L_00F3E1;
L_00F3E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3E1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3E1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3E1 BRA -> $00F40A
    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao
    goto L_00F40A;
L_00F40A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF40Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF40Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF40Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F40A STA
    hw.write(cpu.address("dp", 0x88u), cpu.a, cpu.m8?8:16);
    goto L_00F40C;
L_00F40C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF40Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF40Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF40Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F40C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F40E;
L_00F40E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF40Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF40Eu,cpu,0x3Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF40Eu, 4u + ((((0xF3E5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF3E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F40E AND
    cpu.logicAnd(hw.readW(cpu.address("absx", 0xF3E5u), cpu.m8?8:16));
    goto L_00F411;
L_00F411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF411u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF411u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F411 BEQ -> $00F43E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F43E; }
    goto L_00F413;
L_00F413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF413u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF413u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF413u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F413 STA
    hw.write(cpu.address("dp", 0x9Du), cpu.a, cpu.m8?8:16);
    goto L_00F415;
L_00F415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF415u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF415u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F415 AND
    cpu.logicAnd(0x1u);
    goto L_00F417;
L_00F417:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF417u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF417u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF417u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F417 STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00F419;
L_00F419:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF419u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF419u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF419u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F419 STX
    hw.write(cpu.address("dp", 0x89u), cpu.x, cpu.x8?8:16);
    goto L_00F41B;
L_00F41B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF41Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF41Bu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF41Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F41B TXA
    cpu.transfer("TXA");
    goto L_00F41C;
L_00F41C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF41Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF41Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF41Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F41C LSR
    cpu.lsrA();
    goto L_00F41D;
L_00F41D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF41Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF41Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF41Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F41D TAX
    cpu.transfer("TAX");
    goto L_00F41E;
L_00F41E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF41Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF41Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF41Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F41E BNE -> $00F430
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F430; }
    goto L_00F420;
L_00F420:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF420u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF420u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF420u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F420 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F423;
L_00F423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF423u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF423u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F423 BEQ -> $00F430
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F430; }
    goto L_00F425;
L_00F425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF425u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF425u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F425 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F427;
L_00F427:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF427u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF427u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF427u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F427 EOR
    cpu.logicXor(0x1u);
    goto L_00F429;
L_00F429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF429u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF429u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF429u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F429 STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00F42B;
L_00F42B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF42Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF42Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF42Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F42B LDA
    cpu.setA(0x8u, 8);
    goto L_00F42D;
L_00F42D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF42Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF42Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF42Du, 4u, 3u, cpu.address("abs", 0x1499u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F42D STA
    hw.write(cpu.address("abs", 0x1499u), cpu.a, cpu.m8?8:16);
    goto L_00F430;
L_00F430:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF430u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF430u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF430u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F430 INX
    cpu.inc('X');
    goto L_00F431;
L_00F431:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF431u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF431u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF431u, 4u, 3u, cpu.address("abs", 0x1419u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F431 STX
    hw.write(cpu.address("abs", 0x1419u), cpu.x, cpu.x8?8:16);
    goto L_00F434;
L_00F434:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF434u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF434u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF434u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F434 STY
    hw.write(cpu.address("dp", 0x71u), cpu.y, cpu.x8?8:16);
    goto L_00F436;
L_00F436:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF436u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF436u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF436u, 6u, 3u, cpu.address("abs", 0xF62Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F436 JSR -> $00F62D stack real
    { cpu.push16Value(hw,0xF438u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF439u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF62Du), 0x00F436u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F439;
L_00F439:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF439u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF439u,0x00F439u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF439u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF439u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F439 LDA
    cpu.setA(0x4u, 8);
    goto L_00F43B;
L_00F43B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF43Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF43Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF43Bu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F43B STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_00F43E;
L_00F43E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF43Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF43Eu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF43Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F43E PLX
    cpu.pop("PLX", hw);
    goto L_00F43F;
L_00F43F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF43Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF43Fu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF43Fu, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F43F LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00F442;
L_00F442:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF442u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF442u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF442u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F442 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F442u);return;} hw.unresolvedReturn(0x00F442u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0180CB_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0180CBu: goto L_0180CB;
    case 0x0180CEu: goto L_0180CE;
    case 0x0180D1u: goto L_0180D1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0180CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180CB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180CE;
L_0180CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CEu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CEu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180CE ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16));
    goto L_0180D1;
L_0180D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0180D1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0180D1u);return;} hw.unresolvedReturn(0x0180D1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0180CB_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0180CBu: goto L_0180CB;
    case 0x0180CEu: goto L_0180CE;
    case 0x0180D1u: goto L_0180D1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0180CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180CB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180CE;
L_0180CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CEu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CEu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180CE ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16));
    goto L_0180D1;
L_0180D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0180D1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0180D1u);return;} hw.unresolvedReturn(0x0180D1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0180CB_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0180CBu: goto L_0180CB;
    case 0x0180CEu: goto L_0180CE;
    case 0x0180D1u: goto L_0180D1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0180CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180CB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180CE;
L_0180CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CEu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CEu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180CE ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16));
    goto L_0180D1;
L_0180D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0180D1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0180D1u);return;} hw.unresolvedReturn(0x0180D1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_018AFC_E0M1X1C0_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018BD5u: goto L_018BD5;
    case 0x018BD7u: goto L_018BD7;
    case 0x018BD8u: goto L_018BD8;
    case 0x018BDBu: goto L_018BDB;
    case 0x018BDEu: goto L_018BDE;
    case 0x018BE0u: goto L_018BE0;
    case 0x018BE3u: goto L_018BE3;
    case 0x018BE5u: goto L_018BE5;
    case 0x018BE7u: goto L_018BE7;
    case 0x018BEAu: goto L_018BEA;
    case 0x018BECu: goto L_018BEC;
    case 0x018BEFu: goto L_018BEF;
    case 0x018BF0u: goto L_018BF0;
    case 0x018BF2u: goto L_018BF2;
    case 0x018BF3u: goto L_018BF3;
    case 0x018BF5u: goto L_018BF5;
    case 0x018BF7u: goto L_018BF7;
    case 0x018BFAu: goto L_018BFA;
    case 0x018BFBu: goto L_018BFB;
    case 0x018BFDu: goto L_018BFD;
    case 0x018C00u: goto L_018C00;
    case 0x018C03u: goto L_018C03;
    case 0x018C04u: goto L_018C04;
    case 0x018C07u: goto L_018C07;
    case 0x018C08u: goto L_018C08;
    case 0x018C0Au: goto L_018C0A;
    case 0x018C0Cu: goto L_018C0C;
    case 0x018C0Eu: goto L_018C0E;
    case 0x018C10u: goto L_018C10;
    case 0x018C13u: goto L_018C13;
    case 0x018C14u: goto L_018C14;
    case 0x018C17u: goto L_018C17;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018BD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD5u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BD5 BCC -> $018BD8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_018BD8; }
    goto L_018BD7;
L_018BD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD7u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BD7 INC
    cpu.inc('A');
    goto L_018BD8;
L_018BD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD8u,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD8u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BD8 EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16));
    goto L_018BDB;
L_018BDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDBu, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BDB STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_018BDE;
L_018BDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BDE LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018BE0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BDE LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018BE0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BDEu,0x018BDEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BE0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BE3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BE0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BE3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BE0u,0x018BE0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BE3 AND
    cpu.logicAnd(0x40u);
    goto L_018BE5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BE3 AND
    cpu.logicAnd(0x40u);
    goto L_018BE5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BE3u,0x018BE3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BE5 BNE -> $018BEC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_018BEC; }
    goto L_018BE7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BE5 BNE -> $018BEC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_018BEC; }
    goto L_018BE7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BE5u,0x018BE5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BE7 JSR -> $019F0D stack real
    { cpu.push16Value(hw,0x8BE9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BEAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x018BE7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BEA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BE7 JSR -> $019F0D stack real
    { cpu.push16Value(hw,0x8BE9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BEAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x018BE7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BEA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BE7u,0x018BE7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BEA BRA -> $018C13
    goto L_018C13;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BEA BRA -> $018C13
    goto L_018C13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BEAu,0x018BEAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BECu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BEC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BEF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BEC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BEF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BECu,0x018BECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BEF LSR
    cpu.lsrA();
    goto L_018BF0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BEF LSR
    cpu.lsrA();
    goto L_018BF0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BEFu,0x018BEFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BF0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BF2;
L_018BF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF2u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018BF2 PHA
    cpu.push("PHA", hw);
    goto L_018BF3;
L_018BF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BF3 SBC
    cpu.sbc(0xFu);
    goto L_018BF5;
L_018BF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BF5 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_018BF7;
L_018BF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF7u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BF7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BFA;
L_018BFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018BFA PHA
    cpu.push("PHA", hw);
    goto L_018BFB;
L_018BFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BFB SBC
    cpu.sbc(0x0u);
    goto L_018BFD;
L_018BFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFDu, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BFD STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_018C00;
L_018C00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C00u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C00u, 6u, 3u, cpu.address("abs", 0x9D67u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018C00 JSR -> $019D67 stack real
    { cpu.push16Value(hw,0x8C02u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C03u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D67u), 0x018C00u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018C03;
L_018C03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C03u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C03u,0x018C03u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018C03 PLA
    cpu.pop("PLA", hw);
    goto L_018C04;
L_018C04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018C04 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_018C07;
L_018C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018C07 PLA
    cpu.pop("PLA", hw);
    goto L_018C08;
L_018C08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C08u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C08u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018C08 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_018C0A;
L_018C0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018C0A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018C0C;
L_018C0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018C0C CMP
    cpu.compareA(0x8u);
    goto L_018C0E;
L_018C0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018C0E BCC -> $018C13
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_018C13; }
    goto L_018C10;
L_018C10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C10u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C10u, 6u, 3u, cpu.address("abs", 0x9E28u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018C10 JSR -> $019E28 stack real
    { cpu.push16Value(hw,0x8C12u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C13u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E28u), 0x018C10u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018C13;
L_018C13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C13u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018C13 PLA
    cpu.pop("PLA", hw);
    goto L_018C14;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018C13 PLA
    cpu.pop("PLA", hw);
    goto L_018C14;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C13u,0x018C13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018C14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C14u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C14u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C14u, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018C14 STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_018C17;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C14u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C14u, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018C14 STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_018C17;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C14u,0x018C14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018C17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C17u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018C17 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018C17u);return;} hw.unresolvedReturn(0x018C17u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018C17 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018C17u);return;} hw.unresolvedReturn(0x018C17u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C17u,0x018C17u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_019523_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019523u: goto L_019523;
    case 0x019525u: goto L_019525;
    case 0x019527u: goto L_019527;
    case 0x01952Au: goto L_01952A;
    case 0x01952Cu: goto L_01952C;
    case 0x01952Fu: goto L_01952F;
    case 0x019531u: goto L_019531;
    case 0x019533u: goto L_019533;
    case 0x019537u: goto L_019537;
    case 0x019539u: goto L_019539;
    case 0x01953Bu: goto L_01953B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9523u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9523u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019523 LDA
    cpu.setA(0x7Eu, 8);
    goto L_019525;
L_019525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9525u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9525u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019525 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_019527;
L_019527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9527u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9527u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9527u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019527 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01952A;
L_01952A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Au,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x05u) & 0xFFFFu), 3u, 0u);
    // $01952A LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01952C;
L_01952C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Cu, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01952C STA
    hw.write(cpu.address("abs", 0x1693u), cpu.a, cpu.m8?8:16);
    goto L_01952F;
L_01952F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01952F INC
    cpu.incMem(hw, cpu.address("dp", 0x7u), cpu.m8?8:16);
    goto L_019531;
L_019531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9531u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9531u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x05u) & 0xFFFFu), 3u, 0u);
    // $019531 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019533;
L_019533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9533u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9533u, 8u, 4u, 0x00F545u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $019533 JSL -> $00F545 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9536u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9537u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F545u, 0x019533u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019537;
L_019537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9537u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9537u,0x019537u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9537u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9537u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019537 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019539;
L_019539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9539u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9539u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9539u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019539 CMP
    cpu.compareA(0x0u);
    goto L_01953B;
L_01953B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01953B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01953Bu);return;} hw.unresolvedReturn(0x01953Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01ACF9_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01ACF9u: goto L_01ACF9;
    case 0x01ACFAu: goto L_01ACFA;
    case 0x01ACFCu: goto L_01ACFC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01ACF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF9u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01ACF9 PHY
    cpu.push("PHY", hw);
    goto L_01ACFA;
L_01ACFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ACFA LDY
    cpu.setY(0x1u, 8);
    goto L_01ACFC;
L_01ACFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFCu, 8u, 4u, 0x01AD07u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01ACFC JSL -> $01AD07 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xACFFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD00u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AD07u, 0x01ACFCu); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD00u,0x01ACFCu); return;
}

void sub_01ACF9_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01ACF9u: goto L_01ACF9;
    case 0x01ACFAu: goto L_01ACFA;
    case 0x01ACFCu: goto L_01ACFC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01ACF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF9u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01ACF9 PHY
    cpu.push("PHY", hw);
    goto L_01ACFA;
L_01ACFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ACFA LDY
    cpu.setY(0x1u, 8);
    goto L_01ACFC;
L_01ACFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFCu, 8u, 4u, 0x01AD07u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01ACFC JSL -> $01AD07 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xACFFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD00u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AD07u, 0x01ACFCu); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD00u,0x01ACFCu); return;
}

void sub_01ACF9_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01ACF9u: goto L_01ACF9;
    case 0x01ACFAu: goto L_01ACFA;
    case 0x01ACFCu: goto L_01ACFC;
    case 0x01AD00u: goto L_01AD00;
    case 0x01AD01u: goto L_01AD01;
    case 0x01AD05u: goto L_01AD05;
    case 0x01AD06u: goto L_01AD06;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01ACF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF9u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01ACF9 PHY
    cpu.push("PHY", hw);
    goto L_01ACFA;
L_01ACFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ACFA LDY
    cpu.setY(0x1u, 8);
    goto L_01ACFC;
L_01ACFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFCu, 8u, 4u, 0x01AD07u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01ACFC JSL -> $01AD07 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xACFFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD00u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AD07u, 0x01ACFCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01AD00;
L_01AD00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD00u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD00u,0x01AD00u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD00u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD00u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD00 DEY
    cpu.decReg('Y');
    goto L_01AD01;
L_01AD01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD01u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD01u, 8u, 4u, 0x01AD07u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01AD01 JSL -> $01AD07 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAD04u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD05u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AD07u, 0x01AD01u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01AD05;
L_01AD05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD05u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD05u,0x01AD05u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD05u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD05u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AD05 PLY
    cpu.pop("PLY", hw);
    goto L_01AD06;
L_01AD06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD06u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD06u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01AD06 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x01AD06u);return;} hw.unresolvedReturn(0x01AD06u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_01C9BF_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01C9BFu: goto L_01C9BF;
    case 0x01C9C1u: goto L_01C9C1;
    case 0x01C9C3u: goto L_01C9C3;
    case 0x01C9C4u: goto L_01C9C4;
    case 0x01C9C5u: goto L_01C9C5;
    case 0x01C9C8u: goto L_01C9C8;
    case 0x01C9CAu: goto L_01C9CA;
    case 0x01C9CBu: goto L_01C9CB;
    case 0x01C9CDu: goto L_01C9CD;
    case 0x01C9D0u: goto L_01C9D0;
    case 0x01C9D1u: goto L_01C9D1;
    case 0x01C9D3u: goto L_01C9D3;
    case 0x01C9D5u: goto L_01C9D5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01C9BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9BFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C9BF REP
    cpu.rep(0x20u);
    goto L_01C9C1;
L_01C9C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C9C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01C9C3;
L_01C9C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C3u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01C9C3 PHA
    cpu.push("PHA", hw);
    goto L_01C9C4;
L_01C9C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C9C4 CLC
    cpu.setFlag('C', false);
    goto L_01C9C5;
L_01C9C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C9C5 ADC
    cpu.adc(0x10u);
    goto L_01C9C8;
L_01C9C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C9C8 STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_01C9CA;
L_01C9CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C9CA SEC
    cpu.setFlag('C', true);
    goto L_01C9CB;
L_01C9CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CBu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C9CB SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_01C9CD;
L_01C9CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C9CD CMP
    cpu.compareA(0x100u);
    goto L_01C9D0;
L_01C9D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D0u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01C9D0 PLA
    cpu.pop("PLA", hw);
    goto L_01C9D1;
L_01C9D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C9D1 STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_01C9D3;
L_01C9D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C9D3 SEP
    cpu.sep(0x20u);
    goto L_01C9D5;
L_01C9D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01C9D5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01C9D5u);return;} hw.unresolvedReturn(0x01C9D5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_028752_E0M1X1CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x028A40u: goto L_028A40;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_028A40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A40u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A40u,0x028A40u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A40u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A40u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A40 BRA -> $028A0D
    hw.requestDispatch(0x028A0Du,0x028A40u); return;
}

void sub_029631_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x029631u: goto L_029631;
    case 0x029633u: goto L_029633;
    case 0x029636u: goto L_029636;
    case 0x029639u: goto L_029639;
    case 0x02963Bu: goto L_02963B;
    case 0x02963Du: goto L_02963D;
    case 0x029640u: goto L_029640;
    case 0x029643u: goto L_029643;
    case 0x029647u: goto L_029647;
    case 0x029649u: goto L_029649;
    case 0x02964Cu: goto L_02964C;
    case 0x02964Eu: goto L_02964E;
    case 0x029650u: goto L_029650;
    case 0x029653u: goto L_029653;
    case 0x029654u: goto L_029654;
    case 0x029656u: goto L_029656;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_029631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9631u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9631u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9631u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029631 LDX
    cpu.setX(0x7u, 8);
    goto L_029633;
L_029633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9633u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9633u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029633 STX
    hw.write(cpu.address("abs", 0x15E9u), cpu.x, cpu.x8?8:16);
    goto L_029636;
L_029636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9636u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9636u, 4u + ((((0x170Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029636 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x170Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029639;
L_029639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9639u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9639u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029639 CMP
    cpu.compareA(0x2u);
    goto L_02963B;
L_02963B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02963B BCC -> $029653
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_029653; }
    goto L_02963D;
L_02963D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Du, 6u, 3u, cpu.address("abs", 0xA519u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02963D JSR -> $02A519 stack real
    { cpu.push16Value(hw,0x963Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9640u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA519u), 0x02963Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_029640;
L_029640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9640u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9640u,0x029640u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9640u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9640u, 6u, 3u, cpu.address("abs", 0x9696u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029640 JSR -> $029696 stack real
    { cpu.push16Value(hw,0x9642u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9643u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9696u), 0x029640u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_029643;
L_029643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9643u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9643u,0x029643u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9643u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9643u, 8u, 4u, 0x03B72Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $029643 JSL -> $03B72B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9646u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9647u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03B72Bu, 0x029643u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_029647;
L_029647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9647u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9647u,0x029647u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9647u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9647u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029647 BCC -> $029653
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_029653; }
    goto L_029649;
L_029649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9649u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9649u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9649u, 4u + ((((0x170Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029649 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x170Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02964C;
L_02964C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02964C CMP
    cpu.compareA(0x12u);
    goto L_02964E;
L_02964E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02964E BEQ -> $029653
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_029653; }
    goto L_029650;
L_029650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9650u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9650u, 6u, 3u, cpu.address("abs", 0xA4DEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029650 JSR -> $02A4DE stack real
    { cpu.push16Value(hw,0x9652u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9653u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA4DEu), 0x029650u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_029653;
L_029653:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9653u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9653u,0x029653u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9653u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9653u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029653 DEX
    cpu.decReg('X');
    goto L_029654;
L_029654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9654u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9654u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029654 BPL -> $029633
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_029633; }
    goto L_029656;
L_029656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9656u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9656u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9656u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029656 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x029656u);return;} hw.unresolvedReturn(0x029656u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02A751_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02A751u: goto L_02A751;
    case 0x02A752u: goto L_02A752;
    case 0x02A753u: goto L_02A753;
    case 0x02A754u: goto L_02A754;
    case 0x02A757u: goto L_02A757;
    case 0x02A75Au: goto L_02A75A;
    case 0x02A75Du: goto L_02A75D;
    case 0x02A75Fu: goto L_02A75F;
    case 0x02A763u: goto L_02A763;
    case 0x02A766u: goto L_02A766;
    case 0x02A768u: goto L_02A768;
    case 0x02A76Bu: goto L_02A76B;
    case 0x02A76Du: goto L_02A76D;
    case 0x02A771u: goto L_02A771;
    case 0x02A772u: goto L_02A772;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02A751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA751u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA751u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02A751 PHB
    cpu.push("PHB", hw);
    goto L_02A752;
L_02A752:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA752u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA752u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA752u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02A752 PHK
    cpu.push("PHK", hw);
    goto L_02A753;
L_02A753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA753u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA753u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02A753 PLB
    cpu.pop("PLB", hw);
    goto L_02A754;
L_02A754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA754u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA754u, 6u, 3u, cpu.address("abs", 0xABF2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02A754 JSR -> $02ABF2 stack real
    { cpu.push16Value(hw,0xA756u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA757u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABF2u), 0x02A754u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02A757;
L_02A757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA757u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA757u,0x02A757u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA757u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA757u, 6u, 3u, cpu.address("abs", 0xAC5Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02A757 JSR -> $02AC5C stack real
    { cpu.push16Value(hw,0xA759u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA75Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC5Cu), 0x02A757u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02A75A;
L_02A75A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA75Au,0x02A75Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Au, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02A75A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02A75D;
L_02A75D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02A75D BMI -> $02A763
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_02A763; }
    goto L_02A75F;
L_02A75F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Fu, 8u, 4u, 0x01808Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02A75F JSL -> $01808C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA762u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA763u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01808Cu, 0x02A75Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02A763;
L_02A763:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA763u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA763u,0x02A763u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA763u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA763u, 4u, 3u, cpu.address("abs", 0x0DC1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02A763 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDC1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02A766;
L_02A766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA766u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA766u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02A766 BEQ -> $02A771
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02A771; }
    goto L_02A768;
L_02A768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA768u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA768u, 4u, 3u, cpu.address("abs", 0x1B9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02A768 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02A76B;
L_02A76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02A76B BNE -> $02A771
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02A771; }
    goto L_02A76D;
L_02A76D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Du, 8u, 4u, 0x00FC7Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02A76D JSL -> $00FC7A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA770u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA771u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00FC7Au, 0x02A76Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02A771;
L_02A771:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA771u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA771u,0x02A771u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA771u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA771u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02A771 PLB
    cpu.pop("PLB", hw);
    goto L_02A772;
L_02A772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA772u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA772u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02A772 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02A772u);return;} hw.unresolvedReturn(0x02A772u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_049D07_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x049D07u: goto L_049D07;
    case 0x049D0Bu: goto L_049D0B;
    case 0x049D0Cu: goto L_049D0C;
    case 0x049D0Du: goto L_049D0D;
    case 0x049D10u: goto L_049D10;
    case 0x049D12u: goto L_049D12;
    case 0x049D13u: goto L_049D13;
    case 0x049D16u: goto L_049D16;
    case 0x049D1Au: goto L_049D1A;
    case 0x049D1Du: goto L_049D1D;
    case 0x049D21u: goto L_049D21;
    case 0x049D24u: goto L_049D24;
    case 0x049D28u: goto L_049D28;
    case 0x049D2Au: goto L_049D2A;
    case 0x049D2Du: goto L_049D2D;
    case 0x049D2Eu: goto L_049D2E;
    case 0x049D2Fu: goto L_049D2F;
    case 0x049D32u: goto L_049D32;
    case 0x049D33u: goto L_049D33;
    case 0x049D35u: goto L_049D35;
    case 0x049D38u: goto L_049D38;
    case 0x049D3Au: goto L_049D3A;
    case 0x049D3Du: goto L_049D3D;
    case 0x049D3Fu: goto L_049D3F;
    case 0x049D41u: goto L_049D41;
    case 0x049D44u: goto L_049D44;
    case 0x049D45u: goto L_049D45;
    case 0x049D46u: goto L_049D46;
    case 0x049D47u: goto L_049D47;
    case 0x049D48u: goto L_049D48;
    case 0x049D4Bu: goto L_049D4B;
    case 0x049D4Cu: goto L_049D4C;
    case 0x049D4Eu: goto L_049D4E;
    case 0x049D51u: goto L_049D51;
    case 0x049D53u: goto L_049D53;
    case 0x049D55u: goto L_049D55;
    case 0x049D58u: goto L_049D58;
    case 0x049D5Au: goto L_049D5A;
    case 0x049D5Cu: goto L_049D5C;
    case 0x049D5Fu: goto L_049D5F;
    case 0x049D60u: goto L_049D60;
    case 0x049D61u: goto L_049D61;
    case 0x049D64u: goto L_049D64;
    case 0x049D65u: goto L_049D65;
    case 0x049D67u: goto L_049D67;
    case 0x049D6Au: goto L_049D6A;
    case 0x049D6Cu: goto L_049D6C;
    case 0x049D6Eu: goto L_049D6E;
    case 0x049D71u: goto L_049D71;
    case 0x049D74u: goto L_049D74;
    case 0x049D76u: goto L_049D76;
    case 0x049D78u: goto L_049D78;
    case 0x049D7Cu: goto L_049D7C;
    case 0x049D7Eu: goto L_049D7E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_049D07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D07u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D07u, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D07 LDA
    cpu.loadA(hw.readW(0x7F837Bu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_049D0B;
L_049D0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D0B TAX
    cpu.transfer("TAX");
    goto L_049D0C;
L_049D0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D0C CLC
    cpu.setFlag('C', false);
    goto L_049D0D;
L_049D0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D0D ADC
    cpu.adc(0x26u);
    goto L_049D10;
L_049D10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D10u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D10u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D10 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_049D12;
L_049D12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D12u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D12 CLC
    cpu.setFlag('C', false);
    goto L_049D13;
L_049D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D13u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D13u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D13 ADC
    cpu.adc(0x4u);
    goto L_049D16;
L_049D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D16u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D16u, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D16 STA
    hw.write(0x7F837Bu, cpu.a, cpu.m8?8:16);
    goto L_049D1A;
L_049D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D1A LDA
    cpu.setA(0x2500u, 16);
    goto L_049D1D;
L_049D1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Du, 6u, 4u, ((0x7F837Fu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D1D STA
    hw.write(((0x7F837Fu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_049D21;
L_049D21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D21u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D21 LDA
    cpu.setA(0x8B50u, 16);
    goto L_049D24;
L_049D24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D24u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D24u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D24 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_049D28;
L_049D28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D28u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D28u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D28 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049D2A;
L_049D2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D2A AND
    cpu.logicAnd(0x7Fu);
    goto L_049D2D;
L_049D2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D2D ASL
    cpu.aslA();
    goto L_049D2E;
L_049D2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D2E TAY
    cpu.transfer("TAY");
    goto L_049D2F;
L_049D2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Fu, 5u + 1u, 3u, cpu.address("absy", 0x9C91u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D2F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9C91u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049D32;
L_049D32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D32u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D32 TAY
    cpu.transfer("TAY");
    goto L_049D33;
L_049D33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D33u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D33u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D33 SEP
    cpu.sep(0x20u);
    goto L_049D35;
L_049D35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D35u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D35u, 4u + 1u, 3u, cpu.address("absy", 0x9AC5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D35 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9AC5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049D38;
L_049D38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D38u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D38 BMI -> $049D3D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_049D3D; }
    goto L_049D3A;
L_049D3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Au, 6u, 3u, cpu.address("abs", 0x9D7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049D3A JSR -> $049D7F stack real
    { cpu.push16Value(hw,0x9D3Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D3Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D7Fu), 0x049D3Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_049D3D;
L_049D3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D3Du,0x049D3Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D3D REP
    cpu.rep(0x20u);
    goto L_049D3F;
L_049D3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D3F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049D41;
L_049D41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D41u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D41u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D41 AND
    cpu.logicAnd(0xF0u);
    goto L_049D44;
L_049D44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D44u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D44u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D44 LSR
    cpu.lsrA();
    goto L_049D45;
L_049D45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D45u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D45 LSR
    cpu.lsrA();
    goto L_049D46;
L_049D46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D46u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D46 LSR
    cpu.lsrA();
    goto L_049D47;
L_049D47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D47u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D47 TAY
    cpu.transfer("TAY");
    goto L_049D48;
L_049D48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D48u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D48u, 5u + 1u, 3u, cpu.address("absy", 0x9CCFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D48 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9CCFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049D4B;
L_049D4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D4B TAY
    cpu.transfer("TAY");
    goto L_049D4C;
L_049D4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D4C SEP
    cpu.sep(0x20u);
    goto L_049D4E;
L_049D4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Eu, 4u + 1u, 3u, cpu.address("absy", 0x9AC5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D4E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9AC5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049D51;
L_049D51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D51u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D51u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D51 CMP
    cpu.compareA(0x9Fu);
    goto L_049D53;
L_049D53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D53u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D53 BEQ -> $049D58
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_049D58; }
    goto L_049D55;
L_049D55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D55u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D55u, 6u, 3u, cpu.address("abs", 0x9D7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049D55 JSR -> $049D7F stack real
    { cpu.push16Value(hw,0x9D57u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D58u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D7Fu), 0x049D55u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_049D58;
L_049D58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D58u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D58u,0x049D58u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D58u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D58u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D58 REP
    cpu.rep(0x20u);
    goto L_049D5A;
L_049D5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D5A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049D5C;
L_049D5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D5C AND
    cpu.logicAnd(0xFu);
    goto L_049D5F;
L_049D5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D5F ASL
    cpu.aslA();
    goto L_049D60;
L_049D60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D60u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D60u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D60 TAY
    cpu.transfer("TAY");
    goto L_049D61;
L_049D61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D61u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D61u, 5u + 1u, 3u, cpu.address("absy", 0x9CEDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D61 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9CEDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049D64;
L_049D64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D64u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D64u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D64 TAY
    cpu.transfer("TAY");
    goto L_049D65;
L_049D65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D65u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D65u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D65 SEP
    cpu.sep(0x20u);
    goto L_049D67;
L_049D67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D67u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D67u, 6u, 3u, cpu.address("abs", 0x9D7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049D67 JSR -> $049D7F stack real
    { cpu.push16Value(hw,0x9D69u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D6Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D7Fu), 0x049D67u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_049D6A;
L_049D6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D6Au,0x049D6Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Au,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D6A CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16));
    goto L_049D6C;
L_049D6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D6C BCS -> $049D76
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_049D76; }
    goto L_049D6E;
L_049D6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D6E LDY
    cpu.setY(0x1CBu, 16);
    goto L_049D71;
L_049D71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D71u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D71u, 6u, 3u, cpu.address("abs", 0x9D7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049D71 JSR -> $049D7F stack real
    { cpu.push16Value(hw,0x9D73u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D74u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D7Fu), 0x049D71u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_049D74;
L_049D74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D74u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D74u,0x049D74u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D74 BRA -> $049D6A
    goto L_049D6A;
L_049D76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D76 LDA
    cpu.setA(0xFFu, 8);
    goto L_049D78;
L_049D78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D78u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D78u, 5u, 4u, ((0x7F8381u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D78 STA
    hw.write(((0x7F8381u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_049D7C;
L_049D7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049D7C REP
    cpu.rep(0x20u);
    goto L_049D7E;
L_049D7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049D7E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x049D7Eu);return;} hw.unresolvedReturn(0x049D7Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04ED83_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04ED83u: goto L_04ED83;
    case 0x04ED85u: goto L_04ED85;
    case 0x04ED87u: goto L_04ED87;
    case 0x04ED89u: goto L_04ED89;
    case 0x04ED8Cu: goto L_04ED8C;
    case 0x04ED8Eu: goto L_04ED8E;
    case 0x04ED91u: goto L_04ED91;
    case 0x04ED94u: goto L_04ED94;
    case 0x04ED95u: goto L_04ED95;
    case 0x04ED96u: goto L_04ED96;
    case 0x04ED9Au: goto L_04ED9A;
    case 0x04ED9Bu: goto L_04ED9B;
    case 0x04ED9Eu: goto L_04ED9E;
    case 0x04EDA0u: goto L_04EDA0;
    case 0x04EDA2u: goto L_04EDA2;
    case 0x04EDA6u: goto L_04EDA6;
    case 0x04EDA8u: goto L_04EDA8;
    case 0x04EDA9u: goto L_04EDA9;
    case 0x04EDABu: goto L_04EDAB;
    case 0x04EDADu: goto L_04EDAD;
    case 0x04EDAFu: goto L_04EDAF;
    case 0x04EDB2u: goto L_04EDB2;
    case 0x04EDB5u: goto L_04EDB5;
    case 0x04EDB6u: goto L_04EDB6;
    case 0x04EDB7u: goto L_04EDB7;
    case 0x04EDBBu: goto L_04EDBB;
    case 0x04EDBDu: goto L_04EDBD;
    case 0x04EDC1u: goto L_04EDC1;
    case 0x04EDC2u: goto L_04EDC2;
    case 0x04EDC3u: goto L_04EDC3;
    case 0x04EDC5u: goto L_04EDC5;
    case 0x04EDC7u: goto L_04EDC7;
    case 0x04EDCBu: goto L_04EDCB;
    case 0x04EDCCu: goto L_04EDCC;
    case 0x04EDD0u: goto L_04EDD0;
    case 0x04EDD2u: goto L_04EDD2;
    case 0x04EDD4u: goto L_04EDD4;
    case 0x04EDD6u: goto L_04EDD6;
    case 0x04EDD9u: goto L_04EDD9;
    case 0x04EDDBu: goto L_04EDDB;
    case 0x04EDDDu: goto L_04EDDD;
    case 0x04EDDEu: goto L_04EDDE;
    case 0x04EDDFu: goto L_04EDDF;
    case 0x04EDE0u: goto L_04EDE0;
    case 0x04EDE1u: goto L_04EDE1;
    case 0x04EDE5u: goto L_04EDE5;
    case 0x04EDE6u: goto L_04EDE6;
    case 0x04EDE8u: goto L_04EDE8;
    case 0x04EDECu: goto L_04EDEC;
    case 0x04EDEDu: goto L_04EDED;
    case 0x04EDF0u: goto L_04EDF0;
    case 0x04EDF4u: goto L_04EDF4;
    case 0x04EDF7u: goto L_04EDF7;
    case 0x04EDFBu: goto L_04EDFB;
    case 0x04EDFFu: goto L_04EDFF;
    case 0x04EE01u: goto L_04EE01;
    case 0x04EE05u: goto L_04EE05;
    case 0x04EE06u: goto L_04EE06;
    case 0x04EE07u: goto L_04EE07;
    case 0x04EE09u: goto L_04EE09;
    case 0x04EE0Du: goto L_04EE0D;
    case 0x04EE0Eu: goto L_04EE0E;
    case 0x04EE0Fu: goto L_04EE0F;
    case 0x04EE11u: goto L_04EE11;
    case 0x04EE15u: goto L_04EE15;
    case 0x04EE16u: goto L_04EE16;
    case 0x04EE17u: goto L_04EE17;
    case 0x04EE19u: goto L_04EE19;
    case 0x04EE1Du: goto L_04EE1D;
    case 0x04EE20u: goto L_04EE20;
    case 0x04EE24u: goto L_04EE24;
    case 0x04EE25u: goto L_04EE25;
    case 0x04EE26u: goto L_04EE26;
    case 0x04EE29u: goto L_04EE29;
    case 0x04EE2Du: goto L_04EE2D;
    case 0x04EE2Fu: goto L_04EE2F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04ED83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED83u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED83 LDA
    cpu.setA(0x7Eu, 8);
    goto L_04ED85;
L_04ED85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED85u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED85u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED85 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_04ED87;
L_04ED87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED87u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED87u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED87 REP
    cpu.rep(0x30u);
    goto L_04ED89;
L_04ED89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED89 LDA
    cpu.setA(0xC800u, 16);
    goto L_04ED8C;
L_04ED8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED8C STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_04ED8E;
L_04ED8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Eu, 5u, 3u, cpu.address("abs", 0x1DEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED8E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DEAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04ED91;
L_04ED91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED91 AND
    cpu.logicAnd(0xFFu);
    goto L_04ED94;
L_04ED94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED94u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED94 ASL
    cpu.aslA();
    goto L_04ED95;
L_04ED95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED95 TAX
    cpu.transfer("TAX");
    goto L_04ED96;
L_04ED96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u, 6u, 4u, ((0x04D85Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED96 LDA
    cpu.loadA(hw.readW(((0x4D85Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04ED9A;
L_04ED9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED9A TAY
    cpu.transfer("TAY");
    goto L_04ED9B;
L_04ED9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED9B LDX
    cpu.setX(0x15u, 16);
    goto L_04ED9E;
L_04ED9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED9E SEP
    cpu.sep(0x20u);
    goto L_04EDA0;
L_04EDA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA0u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA0u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Du) & 0xFFFFu), 3u, 0u);
    // $04EDA0 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDA2;
L_04EDA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u, 5u, 4u, ((0x04DA1Du + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDA2 CMP
    cpu.compareA(hw.readW(((0x4DA1Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_04EDA6;
L_04EDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDA6 BEQ -> $04EDAB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04EDAB; }
    goto L_04EDA8;
L_04EDA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDA8 DEX
    cpu.decReg('X');
    goto L_04EDA9;
L_04EDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDA9 BNE -> $04EDA2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04EDA2; }
    goto L_04EDAB;
L_04EDAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDAB REP
    cpu.rep(0x30u);
    goto L_04EDAD;
L_04EDAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDADu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDAD STX
    hw.write(cpu.address("dp", 0xEu), cpu.x, cpu.x8?8:16);
    goto L_04EDAF;
L_04EDAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAFu, 5u, 3u, cpu.address("abs", 0x1DEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDAF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DEAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDB2;
L_04EDB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDB2 AND
    cpu.logicAnd(0xFFu);
    goto L_04EDB5;
L_04EDB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDB5 ASL
    cpu.aslA();
    goto L_04EDB6;
L_04EDB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDB6 TAX
    cpu.transfer("TAX");
    goto L_04EDB7;
L_04EDB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB7u, 6u, 4u, ((0x04D93Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDB7 LDA
    cpu.loadA(hw.readW(((0x4D93Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDBB;
L_04EDBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDBB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04EDBD;
L_04EDBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBDu, 6u, 4u, ((0x04D85Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDBD LDA
    cpu.loadA(hw.readW(((0x4D85Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDC1;
L_04EDC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDC1 TAX
    cpu.transfer("TAX");
    goto L_04EDC2;
L_04EDC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC2u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EDC2 PHX
    cpu.push("PHX", hw);
    goto L_04EDC3;
L_04EDC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDC3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04EDC5;
L_04EDC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDC5 SEP
    cpu.sep(0x20u);
    goto L_04EDC7;
L_04EDC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC7u, 5u, 4u, ((0x04DA33u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDC7 LDA
    cpu.loadA(hw.readW(((0x4DA33u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDCB;
L_04EDCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCBu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCBu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EDCB PLX
    cpu.pop("PLX", hw);
    goto L_04EDCC;
L_04EDCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCCu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCCu, 5u, 4u, ((0x7EC800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDCC STA
    hw.write(((0x7EC800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EDD0;
L_04EDD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDD0 LDA
    cpu.setA(0x4u, 8);
    goto L_04EDD2;
L_04EDD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDD2 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_04EDD4;
L_04EDD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDD4 REP
    cpu.rep(0x20u);
    goto L_04EDD6;
L_04EDD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDD6 LDA
    cpu.setA(0xECD3u, 16);
    goto L_04EDD9;
L_04EDD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDD9 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_04EDDB;
L_04EDDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDDD;
L_04EDDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDDD ASL
    cpu.aslA();
    goto L_04EDDE;
L_04EDDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDDE ASL
    cpu.aslA();
    goto L_04EDDF;
L_04EDDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDDF ASL
    cpu.aslA();
    goto L_04EDE0;
L_04EDE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDE0 TAY
    cpu.transfer("TAY");
    goto L_04EDE1;
L_04EDE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE1u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE1u, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDE1 LDA
    cpu.loadA(hw.readW(0x7F837Bu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDE5;
L_04EDE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDE5 TAX
    cpu.transfer("TAX");
    goto L_04EDE6;
L_04EDE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDE6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDE8;
L_04EDE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE8u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDE8 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EDEC;
L_04EDEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDECu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDEC CLC
    cpu.setFlag('C', false);
    goto L_04EDED;
L_04EDED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDED ADC
    cpu.adc(0x2000u);
    goto L_04EDF0;
L_04EDF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF0u, 6u, 4u, ((0x7F8385u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDF0 STA
    hw.write(((0x7F8385u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EDF4;
L_04EDF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDF4 LDA
    cpu.setA(0x300u, 16);
    goto L_04EDF7;
L_04EDF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF7u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF7u, 6u, 4u, ((0x7F837Fu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDF7 STA
    hw.write(((0x7F837Fu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EDFB;
L_04EDFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu, 6u, 4u, ((0x7F8387u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDFB STA
    hw.write(((0x7F8387u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EDFF;
L_04EDFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFFu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $04EDFF LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EE01;
L_04EE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE01u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE01u, 6u, 4u, ((0x7F8381u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE01 STA
    hw.write(((0x7F8381u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EE05;
L_04EE05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE05u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE05 INY
    cpu.inc('Y');
    goto L_04EE06;
L_04EE06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE06 INY
    cpu.inc('Y');
    goto L_04EE07;
L_04EE07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE07u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE07u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $04EE07 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EE09;
L_04EE09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u, 6u, 4u, ((0x7F8389u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE09 STA
    hw.write(((0x7F8389u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EE0D;
L_04EE0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE0D INY
    cpu.inc('Y');
    goto L_04EE0E;
L_04EE0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE0E INY
    cpu.inc('Y');
    goto L_04EE0F;
L_04EE0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Fu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $04EE0F LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EE11;
L_04EE11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE11u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE11u, 6u, 4u, ((0x7F8383u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE11 STA
    hw.write(((0x7F8383u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EE15;
L_04EE15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE15u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE15 INY
    cpu.inc('Y');
    goto L_04EE16;
L_04EE16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE16u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE16 INY
    cpu.inc('Y');
    goto L_04EE17;
L_04EE17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE17u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE17u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $04EE17 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EE19;
L_04EE19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u, 6u, 4u, ((0x7F838Bu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE19 STA
    hw.write(((0x7F838Bu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EE1D;
L_04EE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE1D LDA
    cpu.setA(0xFFu, 16);
    goto L_04EE20;
L_04EE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 6u, 4u, ((0x7F838Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE20 STA
    hw.write(((0x7F838Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EE24;
L_04EE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE24 TXA
    cpu.transfer("TXA");
    goto L_04EE25;
L_04EE25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE25u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE25 CLC
    cpu.setFlag('C', false);
    goto L_04EE26;
L_04EE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE26 ADC
    cpu.adc(0x10u);
    goto L_04EE29;
L_04EE29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE29u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE29u, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE29 STA
    hw.write(0x7F837Bu, cpu.a, cpu.m8?8:16);
    goto L_04EE2D;
L_04EE2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE2D SEP
    cpu.sep(0x30u);
    goto L_04EE2F;
L_04EE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EE2F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04EE2Fu);return;} hw.unresolvedReturn(0x04EE2Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04ED83_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04ED83u: goto L_04ED83;
    case 0x04ED85u: goto L_04ED85;
    case 0x04ED87u: goto L_04ED87;
    case 0x04ED89u: goto L_04ED89;
    case 0x04ED8Cu: goto L_04ED8C;
    case 0x04ED8Eu: goto L_04ED8E;
    case 0x04ED91u: goto L_04ED91;
    case 0x04ED94u: goto L_04ED94;
    case 0x04ED95u: goto L_04ED95;
    case 0x04ED96u: goto L_04ED96;
    case 0x04ED9Au: goto L_04ED9A;
    case 0x04ED9Bu: goto L_04ED9B;
    case 0x04ED9Eu: goto L_04ED9E;
    case 0x04EDA0u: goto L_04EDA0;
    case 0x04EDA2u: goto L_04EDA2;
    case 0x04EDA6u: goto L_04EDA6;
    case 0x04EDA8u: goto L_04EDA8;
    case 0x04EDA9u: goto L_04EDA9;
    case 0x04EDABu: goto L_04EDAB;
    case 0x04EDADu: goto L_04EDAD;
    case 0x04EDAFu: goto L_04EDAF;
    case 0x04EDB2u: goto L_04EDB2;
    case 0x04EDB5u: goto L_04EDB5;
    case 0x04EDB6u: goto L_04EDB6;
    case 0x04EDB7u: goto L_04EDB7;
    case 0x04EDBBu: goto L_04EDBB;
    case 0x04EDBDu: goto L_04EDBD;
    case 0x04EDC1u: goto L_04EDC1;
    case 0x04EDC2u: goto L_04EDC2;
    case 0x04EDC3u: goto L_04EDC3;
    case 0x04EDC5u: goto L_04EDC5;
    case 0x04EDC7u: goto L_04EDC7;
    case 0x04EDCBu: goto L_04EDCB;
    case 0x04EDCCu: goto L_04EDCC;
    case 0x04EDD0u: goto L_04EDD0;
    case 0x04EDD2u: goto L_04EDD2;
    case 0x04EDD4u: goto L_04EDD4;
    case 0x04EDD6u: goto L_04EDD6;
    case 0x04EDD9u: goto L_04EDD9;
    case 0x04EDDBu: goto L_04EDDB;
    case 0x04EDDDu: goto L_04EDDD;
    case 0x04EDDEu: goto L_04EDDE;
    case 0x04EDDFu: goto L_04EDDF;
    case 0x04EDE0u: goto L_04EDE0;
    case 0x04EDE1u: goto L_04EDE1;
    case 0x04EDE5u: goto L_04EDE5;
    case 0x04EDE6u: goto L_04EDE6;
    case 0x04EDE8u: goto L_04EDE8;
    case 0x04EDECu: goto L_04EDEC;
    case 0x04EDEDu: goto L_04EDED;
    case 0x04EDF0u: goto L_04EDF0;
    case 0x04EDF4u: goto L_04EDF4;
    case 0x04EDF7u: goto L_04EDF7;
    case 0x04EDFBu: goto L_04EDFB;
    case 0x04EDFFu: goto L_04EDFF;
    case 0x04EE01u: goto L_04EE01;
    case 0x04EE05u: goto L_04EE05;
    case 0x04EE06u: goto L_04EE06;
    case 0x04EE07u: goto L_04EE07;
    case 0x04EE09u: goto L_04EE09;
    case 0x04EE0Du: goto L_04EE0D;
    case 0x04EE0Eu: goto L_04EE0E;
    case 0x04EE0Fu: goto L_04EE0F;
    case 0x04EE11u: goto L_04EE11;
    case 0x04EE15u: goto L_04EE15;
    case 0x04EE16u: goto L_04EE16;
    case 0x04EE17u: goto L_04EE17;
    case 0x04EE19u: goto L_04EE19;
    case 0x04EE1Du: goto L_04EE1D;
    case 0x04EE20u: goto L_04EE20;
    case 0x04EE24u: goto L_04EE24;
    case 0x04EE25u: goto L_04EE25;
    case 0x04EE26u: goto L_04EE26;
    case 0x04EE29u: goto L_04EE29;
    case 0x04EE2Du: goto L_04EE2D;
    case 0x04EE2Fu: goto L_04EE2F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04ED83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED83u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED83 LDA
    cpu.setA(0x7Eu, 8);
    goto L_04ED85;
L_04ED85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED85u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED85u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED85 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_04ED87;
L_04ED87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED87u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED87u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED87 REP
    cpu.rep(0x30u);
    goto L_04ED89;
L_04ED89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED89 LDA
    cpu.setA(0xC800u, 16);
    goto L_04ED8C;
L_04ED8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED8C STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_04ED8E;
L_04ED8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Eu, 5u, 3u, cpu.address("abs", 0x1DEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED8E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DEAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04ED91;
L_04ED91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED91 AND
    cpu.logicAnd(0xFFu);
    goto L_04ED94;
L_04ED94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED94u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED94 ASL
    cpu.aslA();
    goto L_04ED95;
L_04ED95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED95 TAX
    cpu.transfer("TAX");
    goto L_04ED96;
L_04ED96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u, 6u, 4u, ((0x04D85Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED96 LDA
    cpu.loadA(hw.readW(((0x4D85Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04ED9A;
L_04ED9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED9A TAY
    cpu.transfer("TAY");
    goto L_04ED9B;
L_04ED9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED9B LDX
    cpu.setX(0x15u, 16);
    goto L_04ED9E;
L_04ED9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04ED9E SEP
    cpu.sep(0x20u);
    goto L_04EDA0;
L_04EDA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA0u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA0u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Du) & 0xFFFFu), 3u, 0u);
    // $04EDA0 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDA2;
L_04EDA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u, 5u, 4u, ((0x04DA1Du + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDA2 CMP
    cpu.compareA(hw.readW(((0x4DA1Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_04EDA6;
L_04EDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDA6 BEQ -> $04EDAB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04EDAB; }
    goto L_04EDA8;
L_04EDA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDA8 DEX
    cpu.decReg('X');
    goto L_04EDA9;
L_04EDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDA9 BNE -> $04EDA2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04EDA2; }
    goto L_04EDAB;
L_04EDAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDAB REP
    cpu.rep(0x30u);
    goto L_04EDAD;
L_04EDAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDADu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDAD STX
    hw.write(cpu.address("dp", 0xEu), cpu.x, cpu.x8?8:16);
    goto L_04EDAF;
L_04EDAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAFu, 5u, 3u, cpu.address("abs", 0x1DEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDAF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DEAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDB2;
L_04EDB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDB2 AND
    cpu.logicAnd(0xFFu);
    goto L_04EDB5;
L_04EDB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDB5 ASL
    cpu.aslA();
    goto L_04EDB6;
L_04EDB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDB6 TAX
    cpu.transfer("TAX");
    goto L_04EDB7;
L_04EDB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB7u, 6u, 4u, ((0x04D93Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDB7 LDA
    cpu.loadA(hw.readW(((0x4D93Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDBB;
L_04EDBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDBB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04EDBD;
L_04EDBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBDu, 6u, 4u, ((0x04D85Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDBD LDA
    cpu.loadA(hw.readW(((0x4D85Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDC1;
L_04EDC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDC1 TAX
    cpu.transfer("TAX");
    goto L_04EDC2;
L_04EDC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC2u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EDC2 PHX
    cpu.push("PHX", hw);
    goto L_04EDC3;
L_04EDC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDC3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04EDC5;
L_04EDC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDC5 SEP
    cpu.sep(0x20u);
    goto L_04EDC7;
L_04EDC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC7u, 5u, 4u, ((0x04DA33u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDC7 LDA
    cpu.loadA(hw.readW(((0x4DA33u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDCB;
L_04EDCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCBu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCBu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EDCB PLX
    cpu.pop("PLX", hw);
    goto L_04EDCC;
L_04EDCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCCu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCCu, 5u, 4u, ((0x7EC800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDCC STA
    hw.write(((0x7EC800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EDD0;
L_04EDD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDD0 LDA
    cpu.setA(0x4u, 8);
    goto L_04EDD2;
L_04EDD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDD2 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_04EDD4;
L_04EDD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDD4 REP
    cpu.rep(0x20u);
    goto L_04EDD6;
L_04EDD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDD6 LDA
    cpu.setA(0xECD3u, 16);
    goto L_04EDD9;
L_04EDD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDD9 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_04EDDB;
L_04EDDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDDD;
L_04EDDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDDD ASL
    cpu.aslA();
    goto L_04EDDE;
L_04EDDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDDE ASL
    cpu.aslA();
    goto L_04EDDF;
L_04EDDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDDF ASL
    cpu.aslA();
    goto L_04EDE0;
L_04EDE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDE0 TAY
    cpu.transfer("TAY");
    goto L_04EDE1;
L_04EDE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE1u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE1u, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDE1 LDA
    cpu.loadA(hw.readW(0x7F837Bu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDE5;
L_04EDE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDE5 TAX
    cpu.transfer("TAX");
    goto L_04EDE6;
L_04EDE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDE6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EDE8;
L_04EDE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE8u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDE8 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EDEC;
L_04EDEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDECu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDEC CLC
    cpu.setFlag('C', false);
    goto L_04EDED;
L_04EDED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDED ADC
    cpu.adc(0x2000u);
    goto L_04EDF0;
L_04EDF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF0u, 6u, 4u, ((0x7F8385u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDF0 STA
    hw.write(((0x7F8385u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EDF4;
L_04EDF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDF4 LDA
    cpu.setA(0x300u, 16);
    goto L_04EDF7;
L_04EDF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF7u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF7u, 6u, 4u, ((0x7F837Fu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDF7 STA
    hw.write(((0x7F837Fu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EDFB;
L_04EDFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu, 6u, 4u, ((0x7F8387u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EDFB STA
    hw.write(((0x7F8387u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EDFF;
L_04EDFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFFu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $04EDFF LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EE01;
L_04EE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE01u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE01u, 6u, 4u, ((0x7F8381u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE01 STA
    hw.write(((0x7F8381u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EE05;
L_04EE05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE05u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE05 INY
    cpu.inc('Y');
    goto L_04EE06;
L_04EE06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE06 INY
    cpu.inc('Y');
    goto L_04EE07;
L_04EE07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE07u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE07u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $04EE07 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EE09;
L_04EE09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u, 6u, 4u, ((0x7F8389u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE09 STA
    hw.write(((0x7F8389u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EE0D;
L_04EE0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE0D INY
    cpu.inc('Y');
    goto L_04EE0E;
L_04EE0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE0E INY
    cpu.inc('Y');
    goto L_04EE0F;
L_04EE0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Fu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $04EE0F LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EE11;
L_04EE11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE11u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE11u, 6u, 4u, ((0x7F8383u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE11 STA
    hw.write(((0x7F8383u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EE15;
L_04EE15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE15u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE15 INY
    cpu.inc('Y');
    goto L_04EE16;
L_04EE16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE16u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE16 INY
    cpu.inc('Y');
    goto L_04EE17;
L_04EE17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE17u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE17u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $04EE17 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EE19;
L_04EE19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u, 6u, 4u, ((0x7F838Bu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE19 STA
    hw.write(((0x7F838Bu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EE1D;
L_04EE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE1D LDA
    cpu.setA(0xFFu, 16);
    goto L_04EE20;
L_04EE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 6u, 4u, ((0x7F838Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE20 STA
    hw.write(((0x7F838Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04EE24;
L_04EE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE24 TXA
    cpu.transfer("TXA");
    goto L_04EE25;
L_04EE25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE25u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE25 CLC
    cpu.setFlag('C', false);
    goto L_04EE26;
L_04EE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE26 ADC
    cpu.adc(0x10u);
    goto L_04EE29;
L_04EE29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE29u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE29u, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE29 STA
    hw.write(0x7F837Bu, cpu.a, cpu.m8?8:16);
    goto L_04EE2D;
L_04EE2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EE2D SEP
    cpu.sep(0x30u);
    goto L_04EE2F;
L_04EE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EE2F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04EE2Fu);return;} hw.unresolvedReturn(0x04EE2Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04FB06_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04FB06u: goto L_04FB06;
    case 0x04FB07u: goto L_04FB07;
    case 0x04FB0Au: goto L_04FB0A;
    case 0x04FB0Du: goto L_04FB0D;
    case 0x04FB0Eu: goto L_04FB0E;
    case 0x04FB11u: goto L_04FB11;
    case 0x04FB13u: goto L_04FB13;
    case 0x04FB15u: goto L_04FB15;
    case 0x04FB17u: goto L_04FB17;
    case 0x04FB1Au: goto L_04FB1A;
    case 0x04FB1Cu: goto L_04FB1C;
    case 0x04FB1Eu: goto L_04FB1E;
    case 0x04FB1Fu: goto L_04FB1F;
    case 0x04FB21u: goto L_04FB21;
    case 0x04FB24u: goto L_04FB24;
    case 0x04FB25u: goto L_04FB25;
    case 0x04FB26u: goto L_04FB26;
    case 0x04FB27u: goto L_04FB27;
    case 0x04FB28u: goto L_04FB28;
    case 0x04FB29u: goto L_04FB29;
    case 0x04FB2Au: goto L_04FB2A;
    case 0x04FB2Bu: goto L_04FB2B;
    case 0x04FB2Cu: goto L_04FB2C;
    case 0x04FB2Eu: goto L_04FB2E;
    case 0x04FB31u: goto L_04FB31;
    case 0x04FB32u: goto L_04FB32;
    case 0x04FB33u: goto L_04FB33;
    case 0x04FB34u: goto L_04FB34;
    case 0x04FB35u: goto L_04FB35;
    case 0x04FB36u: goto L_04FB36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04FB06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB06u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB06 SEC
    cpu.setFlag('C', true);
    goto L_04FB07;
L_04FB07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB07u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB07u, 4u + ((((0xF843u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF843u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB07 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xF843u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04FB0A;
L_04FB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Au, 5u, 3u, cpu.address("absy", 0x0242u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB0A STA
    hw.write(cpu.address("absy", 0x242u), cpu.a, cpu.m8?8:16);
    goto L_04FB0D;
L_04FB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Du,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB0D XBA
    cpu.xba();
    goto L_04FB0E;
L_04FB0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Eu, 5u, 3u, cpu.address("absy", 0x0243u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB0E STA
    hw.write(cpu.address("absy", 0x243u), cpu.a, cpu.m8?8:16);
    goto L_04FB11;
L_04FB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB11u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB13;
L_04FB13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB13u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB13 BNE -> $04FB36
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04FB36; }
    goto L_04FB15;
L_04FB15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB15u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB15 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB17;
L_04FB17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB17u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB17u, 5u, 3u, cpu.address("absy", 0x0240u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB17 STA
    hw.write(cpu.address("absy", 0x240u), cpu.a, cpu.m8?8:16);
    goto L_04FB1A;
L_04FB1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB1A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB1C;
L_04FB1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB1C BNE -> $04FB36
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04FB36; }
    goto L_04FB1E;
L_04FB1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB1E PHP
    cpu.push("PHP", hw);
    goto L_04FB1F;
L_04FB1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB21;
L_04FB21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB21u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB21u, 5u, 3u, cpu.address("absy", 0x0241u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB21 STA
    hw.write(cpu.address("absy", 0x241u), cpu.a, cpu.m8?8:16);
    goto L_04FB24;
L_04FB24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB24u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB24 TYA
    cpu.transfer("TYA");
    goto L_04FB25;
L_04FB25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB25u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB25 LSR
    cpu.lsrA();
    goto L_04FB26;
L_04FB26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB26u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB26 LSR
    cpu.lsrA();
    goto L_04FB27;
L_04FB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB27u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB27u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB27 PLP
    cpu.pop("PLP", hw);
    goto L_04FB28;
L_04FB28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB28u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFB28u,0x04FB28u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB28u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB28u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB28 PHY
    cpu.push("PHY", hw);
    goto L_04FB29;
L_04FB29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB29 TAY
    cpu.transfer("TAY");
    goto L_04FB2A;
L_04FB2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Au,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2A ROL
    cpu.rolA();
    goto L_04FB2B;
L_04FB2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2B ASL
    cpu.aslA();
    goto L_04FB2C;
L_04FB2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2C AND
    cpu.logicAnd(0x3u);
    goto L_04FB2E;
L_04FB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Eu, 5u, 3u, cpu.address("absy", 0x0430u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2E STA
    hw.write(cpu.address("absy", 0x430u), cpu.a, cpu.m8?8:16);
    goto L_04FB31;
L_04FB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB31 PLY
    cpu.pop("PLY", hw);
    goto L_04FB32;
L_04FB32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB32u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB32 DEY
    cpu.decReg('Y');
    goto L_04FB33;
L_04FB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB33u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB33 DEY
    cpu.decReg('Y');
    goto L_04FB34;
L_04FB34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB34u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB34 DEY
    cpu.decReg('Y');
    goto L_04FB35;
L_04FB35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB35u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB35 DEY
    cpu.decReg('Y');
    goto L_04FB36;
L_04FB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB36u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FB36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FB36u);return;} hw.unresolvedReturn(0x04FB36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FB36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FB36u);return;} hw.unresolvedReturn(0x04FB36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFB36u,0x04FB36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_04FB06_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04FB06u: goto L_04FB06;
    case 0x04FB07u: goto L_04FB07;
    case 0x04FB0Au: goto L_04FB0A;
    case 0x04FB0Du: goto L_04FB0D;
    case 0x04FB0Eu: goto L_04FB0E;
    case 0x04FB11u: goto L_04FB11;
    case 0x04FB13u: goto L_04FB13;
    case 0x04FB15u: goto L_04FB15;
    case 0x04FB17u: goto L_04FB17;
    case 0x04FB1Au: goto L_04FB1A;
    case 0x04FB1Cu: goto L_04FB1C;
    case 0x04FB1Eu: goto L_04FB1E;
    case 0x04FB1Fu: goto L_04FB1F;
    case 0x04FB21u: goto L_04FB21;
    case 0x04FB24u: goto L_04FB24;
    case 0x04FB25u: goto L_04FB25;
    case 0x04FB26u: goto L_04FB26;
    case 0x04FB27u: goto L_04FB27;
    case 0x04FB28u: goto L_04FB28;
    case 0x04FB29u: goto L_04FB29;
    case 0x04FB2Au: goto L_04FB2A;
    case 0x04FB2Bu: goto L_04FB2B;
    case 0x04FB2Cu: goto L_04FB2C;
    case 0x04FB2Eu: goto L_04FB2E;
    case 0x04FB31u: goto L_04FB31;
    case 0x04FB32u: goto L_04FB32;
    case 0x04FB33u: goto L_04FB33;
    case 0x04FB34u: goto L_04FB34;
    case 0x04FB35u: goto L_04FB35;
    case 0x04FB36u: goto L_04FB36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04FB06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB06u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB06 SEC
    cpu.setFlag('C', true);
    goto L_04FB07;
L_04FB07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB07u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB07u, 4u + ((((0xF843u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF843u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB07 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xF843u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04FB0A;
L_04FB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Au, 5u, 3u, cpu.address("absy", 0x0242u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB0A STA
    hw.write(cpu.address("absy", 0x242u), cpu.a, cpu.m8?8:16);
    goto L_04FB0D;
L_04FB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Du,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB0D XBA
    cpu.xba();
    goto L_04FB0E;
L_04FB0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Eu, 5u, 3u, cpu.address("absy", 0x0243u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB0E STA
    hw.write(cpu.address("absy", 0x243u), cpu.a, cpu.m8?8:16);
    goto L_04FB11;
L_04FB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB11u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB13;
L_04FB13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB13u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB13 BNE -> $04FB36
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04FB36; }
    goto L_04FB15;
L_04FB15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB15u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB15 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB17;
L_04FB17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB17u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB17u, 5u, 3u, cpu.address("absy", 0x0240u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB17 STA
    hw.write(cpu.address("absy", 0x240u), cpu.a, cpu.m8?8:16);
    goto L_04FB1A;
L_04FB1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB1A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB1C;
L_04FB1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB1C BNE -> $04FB36
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04FB36; }
    goto L_04FB1E;
L_04FB1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB1E PHP
    cpu.push("PHP", hw);
    goto L_04FB1F;
L_04FB1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB21;
L_04FB21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB21u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB21u, 5u, 3u, cpu.address("absy", 0x0241u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB21 STA
    hw.write(cpu.address("absy", 0x241u), cpu.a, cpu.m8?8:16);
    goto L_04FB24;
L_04FB24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB24u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB24 TYA
    cpu.transfer("TYA");
    goto L_04FB25;
L_04FB25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB25u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB25 LSR
    cpu.lsrA();
    goto L_04FB26;
L_04FB26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB26u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB26 LSR
    cpu.lsrA();
    goto L_04FB27;
L_04FB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB27u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB27u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB27 PLP
    cpu.pop("PLP", hw);
    goto L_04FB28;
L_04FB28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB28u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFB28u,0x04FB28u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB28u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB28u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB28 PHY
    cpu.push("PHY", hw);
    goto L_04FB29;
L_04FB29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB29 TAY
    cpu.transfer("TAY");
    goto L_04FB2A;
L_04FB2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Au,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2A ROL
    cpu.rolA();
    goto L_04FB2B;
L_04FB2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2B ASL
    cpu.aslA();
    goto L_04FB2C;
L_04FB2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2C AND
    cpu.logicAnd(0x3u);
    goto L_04FB2E;
L_04FB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Eu, 5u, 3u, cpu.address("absy", 0x0430u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2E STA
    hw.write(cpu.address("absy", 0x430u), cpu.a, cpu.m8?8:16);
    goto L_04FB31;
L_04FB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB31 PLY
    cpu.pop("PLY", hw);
    goto L_04FB32;
L_04FB32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB32u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB32 DEY
    cpu.decReg('Y');
    goto L_04FB33;
L_04FB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB33u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB33 DEY
    cpu.decReg('Y');
    goto L_04FB34;
L_04FB34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB34u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB34 DEY
    cpu.decReg('Y');
    goto L_04FB35;
L_04FB35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB35u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB35 DEY
    cpu.decReg('Y');
    goto L_04FB36;
L_04FB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB36u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FB36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FB36u);return;} hw.unresolvedReturn(0x04FB36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FB36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FB36u);return;} hw.unresolvedReturn(0x04FB36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFB36u,0x04FB36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_058883_E0M0X0C0_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05881Au: goto L_05881A;
    case 0x05881Cu: goto L_05881C;
    case 0x05881Fu: goto L_05881F;
    case 0x058823u: goto L_058823;
    case 0x058826u: goto L_058826;
    case 0x058829u: goto L_058829;
    case 0x05882Cu: goto L_05882C;
    case 0x05882Du: goto L_05882D;
    case 0x05882Eu: goto L_05882E;
    case 0x058830u: goto L_058830;
    case 0x058831u: goto L_058831;
    case 0x058833u: goto L_058833;
    case 0x058835u: goto L_058835;
    case 0x058838u: goto L_058838;
    case 0x058839u: goto L_058839;
    case 0x05883Au: goto L_05883A;
    case 0x05883Cu: goto L_05883C;
    case 0x05883Du: goto L_05883D;
    case 0x05883Fu: goto L_05883F;
    case 0x058840u: goto L_058840;
    case 0x058842u: goto L_058842;
    case 0x058843u: goto L_058843;
    case 0x058845u: goto L_058845;
    case 0x058846u: goto L_058846;
    case 0x058848u: goto L_058848;
    case 0x05884Au: goto L_05884A;
    case 0x05884Bu: goto L_05884B;
    case 0x05884Cu: goto L_05884C;
    case 0x05884Eu: goto L_05884E;
    case 0x058850u: goto L_058850;
    case 0x058853u: goto L_058853;
    case 0x058854u: goto L_058854;
    case 0x058855u: goto L_058855;
    case 0x058857u: goto L_058857;
    case 0x058859u: goto L_058859;
    case 0x05885Au: goto L_05885A;
    case 0x05885Bu: goto L_05885B;
    case 0x05885Du: goto L_05885D;
    case 0x05885Eu: goto L_05885E;
    case 0x058860u: goto L_058860;
    case 0x058861u: goto L_058861;
    case 0x058863u: goto L_058863;
    case 0x058864u: goto L_058864;
    case 0x058866u: goto L_058866;
    case 0x058867u: goto L_058867;
    case 0x058869u: goto L_058869;
    case 0x05886Au: goto L_05886A;
    case 0x05886Cu: goto L_05886C;
    case 0x05886Du: goto L_05886D;
    case 0x05886Fu: goto L_05886F;
    case 0x058870u: goto L_058870;
    case 0x058872u: goto L_058872;
    case 0x058873u: goto L_058873;
    case 0x058875u: goto L_058875;
    case 0x058876u: goto L_058876;
    case 0x058878u: goto L_058878;
    case 0x058879u: goto L_058879;
    case 0x05887Bu: goto L_05887B;
    case 0x05887Cu: goto L_05887C;
    case 0x05887Eu: goto L_05887E;
    case 0x058880u: goto L_058880;
    case 0x058883u: goto L_058883;
    case 0x058885u: goto L_058885;
    case 0x058888u: goto L_058888;
    case 0x05888Cu: goto L_05888C;
    case 0x05888Eu: goto L_05888E;
    case 0x058890u: goto L_058890;
    case 0x058891u: goto L_058891;
    case 0x058893u: goto L_058893;
    case 0x058894u: goto L_058894;
    case 0x058896u: goto L_058896;
    case 0x058897u: goto L_058897;
    case 0x058899u: goto L_058899;
    case 0x05889Au: goto L_05889A;
    case 0x05889Cu: goto L_05889C;
    case 0x05889Fu: goto L_05889F;
    case 0x0588A2u: goto L_0588A2;
    case 0x0588A5u: goto L_0588A5;
    case 0x0588A8u: goto L_0588A8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05881A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05881A SEP
    cpu.sep(0x30u);
    goto L_05881C;
L_05881C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Cu, 4u, 3u, cpu.address("abs", 0x1925u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05881C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1925u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05881F;
L_05881F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Fu, 8u, 4u, 0x0086FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05881F JSL -> $0086FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8822u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8823u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086FAu, 0x05881Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_058823;
L_058823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8823u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8823u,0x058823u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8823u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8823u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058823 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_058826;
L_058826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8826u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058826 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_058829;
L_058829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8829u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8829u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058829 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_05882C;
L_05882C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Cu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05882C TXY
    cpu.transfer("TXY");
    goto L_05882D;
L_05882D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05882D TXA
    cpu.transfer("TXA");
    goto L_05882E;
L_05882E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05882E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16));
    goto L_058830;
L_058830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058830 TXA
    cpu.transfer("TXA");
    goto L_058831;
L_058831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8831u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8831u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058831 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCEu), cpu.m8?8:16));
    goto L_058833;
L_058833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8833u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8833u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058833 BIT
    cpu.bit(0x5u, true);
    goto L_058835;
L_058835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8835u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8835u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058835 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_058838;
L_058838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8838u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8838u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058838 TXY
    cpu.transfer("TXY");
    goto L_058839;
L_058839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8839u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8839u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058839 TXA
    cpu.transfer("TXA");
    goto L_05883A;
L_05883A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Au,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05883A ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16));
    goto L_05883C;
L_05883C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05883C TXA
    cpu.transfer("TXA");
    goto L_05883D;
L_05883D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Du,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05883D ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05883F;
L_05883F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05883F TXA
    cpu.transfer("TXA");
    goto L_058840;
L_058840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8840u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8840u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058840 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16));
    goto L_058842;
L_058842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8842u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8842u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058842 TXA
    cpu.transfer("TXA");
    goto L_058843;
L_058843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058843 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058845;
L_058845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8845u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8845u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058845 TXA
    cpu.transfer("TXA");
    goto L_058846;
L_058846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058846 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCEu), cpu.m8?8:16));
    goto L_058848;
L_058848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058848 BIT
    cpu.bit(0x5u, true);
    goto L_05884A;
L_05884A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05884A TXY
    cpu.transfer("TXY");
    goto L_05884B;
L_05884B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Bu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05884B TXA
    cpu.transfer("TXA");
    goto L_05884C;
L_05884C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05884C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCEu), cpu.m8?8:16));
    goto L_05884E;
L_05884E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05884E BIT
    cpu.bit(0x5u, true);
    goto L_058850;
L_058850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8850u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8850u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058850 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_058853;
L_058853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8853u,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8853u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058853 TXS
    cpu.transfer("TXS");
    goto L_058854;
L_058854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058854 TXA
    cpu.transfer("TXA");
    goto L_058855;
L_058855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8855u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8855u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058855 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCEu), cpu.m8?8:16));
    goto L_058857;
L_058857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058857 BIT
    cpu.bit(0x5u, true);
    goto L_058859;
L_058859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8859u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058859 TXS
    cpu.transfer("TXS");
    goto L_05885A;
L_05885A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05885A TXA
    cpu.transfer("TXA");
    goto L_05885B;
L_05885B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05885B ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05885D;
L_05885D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05885D TXA
    cpu.transfer("TXA");
    goto L_05885E;
L_05885E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05885E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058860;
L_058860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8860u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8860u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058860 TXA
    cpu.transfer("TXA");
    goto L_058861;
L_058861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058861 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058863;
L_058863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8863u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8863u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058863 TXA
    cpu.transfer("TXA");
    goto L_058864;
L_058864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058864 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058866;
L_058866:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8866u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8866u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8866u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058866 TXA
    cpu.transfer("TXA");
    goto L_058867;
L_058867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8867u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8867u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058867 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058869;
L_058869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058869 TXA
    cpu.transfer("TXA");
    goto L_05886A;
L_05886A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Au,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05886A ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05886C;
L_05886C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05886C TXA
    cpu.transfer("TXA");
    goto L_05886D;
L_05886D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05886D ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05886F;
L_05886F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05886F TXA
    cpu.transfer("TXA");
    goto L_058870;
L_058870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8870u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8870u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058870 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058872;
L_058872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8872u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8872u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058872 TXA
    cpu.transfer("TXA");
    goto L_058873;
L_058873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8873u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8873u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058873 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058875;
L_058875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8875u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8875u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058875 TXA
    cpu.transfer("TXA");
    goto L_058876;
L_058876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8876u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8876u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058876 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058878;
L_058878:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8878u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8878u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8878u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058878 TXA
    cpu.transfer("TXA");
    goto L_058879;
L_058879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8879u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8879u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058879 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05887B;
L_05887B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Bu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05887B TXA
    cpu.transfer("TXA");
    goto L_05887C;
L_05887C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05887C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCEu), cpu.m8?8:16));
    goto L_05887E;
L_05887E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Eu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05887E BIT
    cpu.bit(0x5u, true);
    goto L_058880;
L_058880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8880u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8880u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058880 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_058883;
L_058883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8883u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8883u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8883u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058883 SEP
    cpu.sep(0x30u);
    goto L_058885;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8883u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8883u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058883 SEP
    cpu.sep(0x30u);
    goto L_058885;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8883u,0x058883u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8885u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8885u, 4u, 3u, cpu.address("abs", 0x1925u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058885 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1925u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058888;
L_058888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8888u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8888u, 8u, 4u, 0x0086FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058888 JSL -> $0086FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x888Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x888Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086FAu, 0x058888u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05888C;
L_05888C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x888Cu,0x05888Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Cu,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05888C BVS -> $05881A
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_05881A; }
    goto L_05888E;
L_05888E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05888E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_058890;
L_058890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8890u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8890u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8890u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058890 PHB
    cpu.push("PHB", hw);
    goto L_058891;
L_058891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058891 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_058893;
L_058893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058893 PHB
    cpu.push("PHB", hw);
    goto L_058894;
L_058894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8894u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8894u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058894 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_058896;
L_058896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058896 PHB
    cpu.push("PHB", hw);
    goto L_058897;
L_058897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8897u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8897u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058897 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_058899;
L_058899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8899u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8899u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058899 PHB
    cpu.push("PHB", hw);
    goto L_05889A;
L_05889A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Au,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05889A ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16));
    goto L_05889C;
L_05889C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Cu))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Cu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Cu, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05889C STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_05889F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x889Cu,0x05889Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05889F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Fu))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Fu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Fu, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05889F STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_0588A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x889Fu,0x05889Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A2u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A2u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A2u, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588A2 STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_0588A5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88A2u,0x0588A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A5u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A5u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A5u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588A5 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588A8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88A5u,0x0588A5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A8u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588A8 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88ABu,0x0588A8u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88A8u,0x0588A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_058883_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x058883u: goto L_058883;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_058883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8883u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8883u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058883 SEP
    cpu.sep(0x30u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8885u,0x058883u); return;
}

void sub_058883_E0M0X0C0_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0588C6u: goto L_0588C6;
    case 0x0588C9u: goto L_0588C9;
    case 0x0588CCu: goto L_0588CC;
    case 0x0588CFu: goto L_0588CF;
    case 0x0588D2u: goto L_0588D2;
    case 0x0588D5u: goto L_0588D5;
    case 0x0588D8u: goto L_0588D8;
    case 0x0588DBu: goto L_0588DB;
    case 0x0588DEu: goto L_0588DE;
    case 0x0588E1u: goto L_0588E1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0588C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C6u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588C6 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588C9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88C6u,0x0588C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C9u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C9u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C9u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588C9 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88C9u,0x0588C9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CCu))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CCu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CCu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588CC STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88CCu,0x0588CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CFu))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CFu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CFu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588CF STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588D2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88CFu,0x0588CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D2u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D2u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D2u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588D2 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588D5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88D2u,0x0588D2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D5u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D5u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D5u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588D5 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588D8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88D5u,0x0588D5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D8u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D8u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D8u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588D8 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588DB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88D8u,0x0588D8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DBu))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DBu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DBu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588DB STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588DE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88DBu,0x0588DBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DEu))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DEu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DEu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588DE STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588E1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88DEu,0x0588DEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E1u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E1u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E1u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588E1 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88E4u,0x0588E1u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88E1u,0x0588E1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_05881A_E0M0X0CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0588C6u: goto L_0588C6;
    case 0x0588C9u: goto L_0588C9;
    case 0x0588CCu: goto L_0588CC;
    case 0x0588CFu: goto L_0588CF;
    case 0x0588D2u: goto L_0588D2;
    case 0x0588D5u: goto L_0588D5;
    case 0x0588D8u: goto L_0588D8;
    case 0x0588DBu: goto L_0588DB;
    case 0x0588DEu: goto L_0588DE;
    case 0x0588E1u: goto L_0588E1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0588C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C6u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588C6 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588C9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88C6u,0x0588C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C9u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C9u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C9u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588C9 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88C9u,0x0588C9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CCu))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CCu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CCu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588CC STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88CCu,0x0588CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CFu))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CFu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CFu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588CF STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588D2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88CFu,0x0588CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D2u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D2u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D2u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588D2 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588D5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88D2u,0x0588D2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D5u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D5u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D5u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588D5 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588D8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88D5u,0x0588D5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D8u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D8u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D8u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588D8 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588DB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88D8u,0x0588D8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DBu))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DBu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DBu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588DB STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588DE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88DBu,0x0588DBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DEu))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DEu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DEu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588DE STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588E1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88DEu,0x0588DEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E1u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E1u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E1u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588E1 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88E4u,0x0588E1u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88E1u,0x0588E1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_05B329_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05B329u: goto L_05B329;
    case 0x05B32Au: goto L_05B32A;
    case 0x05B32Cu: goto L_05B32C;
    case 0x05B32Fu: goto L_05B32F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05B329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB329u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB329u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05B329 PHA
    cpu.push("PHA", hw);
    goto L_05B32A;
L_05B32A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB32Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B32A LDA
    cpu.setA(0x1u, 8);
    goto L_05B32C;
L_05B32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Cu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B32C STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_05B32F;
L_05B32F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB32Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Fu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05B32F PLA
    cpu.pop("PLA", hw);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB330u,0x05B32Fu); return;
}

void sub_0CC97E_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CC97Eu: goto L_0CC97E;
    case 0x0CC97Fu: goto L_0CC97F;
    case 0x0CC980u: goto L_0CC980;
    case 0x0CC981u: goto L_0CC981;
    case 0x0CC984u: goto L_0CC984;
    case 0x0CC987u: goto L_0CC987;
    case 0x0CC98Au: goto L_0CC98A;
    case 0x0CC98Bu: goto L_0CC98B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CC97E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC97Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Eu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CC97E PHB
    cpu.push("PHB", hw);
    goto L_0CC97F;
L_0CC97F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC97Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Fu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CC97F PHK
    cpu.push("PHK", hw);
    goto L_0CC980;
L_0CC980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC980u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC980u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CC980 PLB
    cpu.pop("PLB", hw);
    goto L_0CC981;
L_0CC981:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC981u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC981u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC981u, 6u, 3u, cpu.address("abs", 0xC94Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CC981 JSR -> $0CC94E stack real
    { cpu.push16Value(hw,0xC983u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC984u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC94Eu), 0x0CC981u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0CC984;
L_0CC984:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC984u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC984u,0x0CC984u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC984u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC984u, 6u, 3u, cpu.address("abs", 0xCA8Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CC984 JSR -> $0CCA8F stack real
    { cpu.push16Value(hw,0xC986u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC987u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA8Fu), 0x0CC984u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0CC987;
L_0CC987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC987u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC987u,0x0CC987u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC987u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC987u, 6u, 3u, cpu.address("abs", 0xC98Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CC987 JSR -> $0CC98C stack real
    { cpu.push16Value(hw,0xC989u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC98Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC98Cu), 0x0CC987u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0CC98A;
L_0CC98A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC98Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CC98A PLB
    cpu.pop("PLB", hw);
    goto L_0CC98B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CC98A PLB
    cpu.pop("PLB", hw);
    goto L_0CC98B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC98Au,0x0CC98Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0CC98B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC98Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0CC98B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x0CC98Bu);return;} hw.unresolvedReturn(0x0CC98Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0CC98B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x0CC98Bu);return;} hw.unresolvedReturn(0x0CC98Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC98Bu,0x0CC98Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_0CCA8F_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CCA8Fu: goto L_0CCA8F;
    case 0x0CCA92u: goto L_0CCA92;
    case 0x0CCA94u: goto L_0CCA94;
    case 0x0CCA96u: goto L_0CCA96;
    case 0x0CCA97u: goto L_0CCA97;
    case 0x0CCA9Au: goto L_0CCA9A;
    case 0x0CCA9Du: goto L_0CCA9D;
    case 0x0CCAA0u: goto L_0CCAA0;
    case 0x0CCAA3u: goto L_0CCAA3;
    case 0x0CCAA6u: goto L_0CCAA6;
    case 0x0CCAA9u: goto L_0CCAA9;
    case 0x0CCAACu: goto L_0CCAAC;
    case 0x0CCAAEu: goto L_0CCAAE;
    case 0x0CCAB0u: goto L_0CCAB0;
    case 0x0CCAB3u: goto L_0CCAB3;
    case 0x0CCAB4u: goto L_0CCAB4;
    case 0x0CCAB5u: goto L_0CCAB5;
    case 0x0CCAB6u: goto L_0CCAB6;
    case 0x0CCAB7u: goto L_0CCAB7;
    case 0x0CCAB8u: goto L_0CCAB8;
    case 0x0CCABBu: goto L_0CCABB;
    case 0x0CCABDu: goto L_0CCABD;
    case 0x0CCABEu: goto L_0CCABE;
    case 0x0CCABFu: goto L_0CCABF;
    case 0x0CCAC0u: goto L_0CCAC0;
    case 0x0CCAC3u: goto L_0CCAC3;
    case 0x0CCAC4u: goto L_0CCAC4;
    case 0x0CCAC5u: goto L_0CCAC5;
    case 0x0CCAC6u: goto L_0CCAC6;
    case 0x0CCAC7u: goto L_0CCAC7;
    case 0x0CCAC8u: goto L_0CCAC8;
    case 0x0CCAC9u: goto L_0CCAC9;
    case 0x0CCACBu: goto L_0CCACB;
    case 0x0CCACDu: goto L_0CCACD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CCA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Fu, 4u, 3u, cpu.address("abs", 0x144Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCA8F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x144Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCA92;
L_0CCA92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCA92 BEQ -> $0CCACD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CCACD; }
    goto L_0CCA94;
L_0CCA94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA94u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCA94 LDY
    cpu.setY(0x0u, 8);
    goto L_0CCA96;
L_0CCA96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA96u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCA96 TYX
    cpu.transfer("TYX");
    goto L_0CCA97;
L_0CCA97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA97u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA97u, 4u + ((((0xCA83u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCA83u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCA97 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCA83u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCA9A;
L_0CCA9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Au, 5u, 3u, cpu.address("absx", 0x03E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCA9A STA
    hw.write(cpu.address("absx", 0x3E0u), cpu.a, cpu.m8?8:16);
    goto L_0CCA9D;
L_0CCA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du, 4u + ((((0xCA84u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCA84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCA9D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCA84u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCAA0;
L_0CCAA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA0u, 5u, 3u, cpu.address("absx", 0x03E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAA0 STA
    hw.write(cpu.address("absx", 0x3E1u), cpu.a, cpu.m8?8:16);
    goto L_0CCAA3;
L_0CCAA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA3u, 4u + ((((0xCA85u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCA85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAA3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCA85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCAA6;
L_0CCAA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA6u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA6u, 5u, 3u, cpu.address("absx", 0x03E2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAA6 STA
    hw.write(cpu.address("absx", 0x3E2u), cpu.a, cpu.m8?8:16);
    goto L_0CCAA9;
L_0CCAA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA9u, 4u + ((((0xCA86u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCA86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAA9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCA86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCAAC;
L_0CCAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAACu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAAC AND
    cpu.logicAnd(0xCFu);
    goto L_0CCAAE;
L_0CCAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAEu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAAE ORA
    cpu.logicOr(0x20u);
    goto L_0CCAB0;
L_0CCAB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB0u, 5u, 3u, cpu.address("absx", 0x03E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAB0 STA
    hw.write(cpu.address("absx", 0x3E3u), cpu.a, cpu.m8?8:16);
    goto L_0CCAB3;
L_0CCAB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB3u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CCAB3 PHX
    cpu.push("PHX", hw);
    goto L_0CCAB4;
L_0CCAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAB4 TXA
    cpu.transfer("TXA");
    goto L_0CCAB5;
L_0CCAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAB5 LSR
    cpu.lsrA();
    goto L_0CCAB6;
L_0CCAB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAB6 LSR
    cpu.lsrA();
    goto L_0CCAB7;
L_0CCAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAB7 TAX
    cpu.transfer("TAX");
    goto L_0CCAB8;
L_0CCAB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u, 4u + ((((0xCA86u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCA86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAB8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCA86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCABB;
L_0CCABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCABB AND
    cpu.logicAnd(0x10u);
    goto L_0CCABD;
L_0CCABD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCABD LSR
    cpu.lsrA();
    goto L_0CCABE;
L_0CCABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCABE LSR
    cpu.lsrA();
    goto L_0CCABF;
L_0CCABF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCABF LSR
    cpu.lsrA();
    goto L_0CCAC0;
L_0CCAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u, 5u, 3u, cpu.address("absx", 0x0498u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAC0 STA
    hw.write(cpu.address("absx", 0x498u), cpu.a, cpu.m8?8:16);
    goto L_0CCAC3;
L_0CCAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC3u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CCAC3 PLX
    cpu.pop("PLX", hw);
    goto L_0CCAC4;
L_0CCAC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAC4 INX
    cpu.inc('X');
    goto L_0CCAC5;
L_0CCAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAC5 INX
    cpu.inc('X');
    goto L_0CCAC6;
L_0CCAC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC6u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAC6 INX
    cpu.inc('X');
    goto L_0CCAC7;
L_0CCAC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAC7 INX
    cpu.inc('X');
    goto L_0CCAC8;
L_0CCAC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC8u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAC8 TXY
    cpu.transfer("TXY");
    goto L_0CCAC9;
L_0CCAC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC9u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAC9 CPY
    cpu.compareY(0xCu);
    goto L_0CCACB;
L_0CCACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCACB BNE -> $0CCA97
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CCA97; }
    goto L_0CCACD;
L_0CCACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CCACD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CCACDu);return;} hw.unresolvedReturn(0x0CCACDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DC4C9_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DC4C9u: goto L_0DC4C9;
    case 0x0DC4CBu: goto L_0DC4CB;
    case 0x0DC4CDu: goto L_0DC4CD;
    case 0x0DC4CFu: goto L_0DC4CF;
    case 0x0DC4D1u: goto L_0DC4D1;
    case 0x0DC4D3u: goto L_0DC4D3;
    case 0x0DC4D6u: goto L_0DC4D6;
    case 0x0DC4D8u: goto L_0DC4D8;
    case 0x0DC4DBu: goto L_0DC4DB;
    case 0x0DC4DCu: goto L_0DC4DC;
    case 0x0DC4DEu: goto L_0DC4DE;
    case 0x0DC4E1u: goto L_0DC4E1;
    case 0x0DC4E3u: goto L_0DC4E3;
    case 0x0DC4E6u: goto L_0DC4E6;
    case 0x0DC4E8u: goto L_0DC4E8;
    case 0x0DC4EBu: goto L_0DC4EB;
    case 0x0DC4ECu: goto L_0DC4EC;
    case 0x0DC4EEu: goto L_0DC4EE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DC4C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C9u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4C9 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DC4CB;
L_0DC4CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4CB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DC4CD;
L_0DC4CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4CD AND
    cpu.logicAnd(0xFu);
    goto L_0DC4CF;
L_0DC4CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4CF STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DC4D1;
L_0DC4D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D1u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4D1 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DC4D3;
L_0DC4D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D3u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC4D3 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xC4D5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC4D6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DC4D3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC4D6;
L_0DC4D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4D6u,0x0DC4D6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4D6 LDA
    cpu.setA(0x9u, 8);
    goto L_0DC4D8;
L_0DC4D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D8u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC4D8 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC4DAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC4DBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC4D8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC4DB;
L_0DC4DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4DBu,0x0DC4DBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4DB DEX
    cpu.decReg('X');
    goto L_0DC4DC;
L_0DC4DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4DC BPL -> $0DC4D3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DC4D3; }
    goto L_0DC4DE;
L_0DC4DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DEu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC4DE JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xC4E0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC4E1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DC4DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC4E1;
L_0DC4E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4E1u,0x0DC4E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E1u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4E1 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DC4E3;
L_0DC4E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E3u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC4E3 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xC4E5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC4E6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DC4E3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC4E6;
L_0DC4E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4E6u,0x0DC4E6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4E6 LDA
    cpu.setA(0x86u, 8);
    goto L_0DC4E8;
L_0DC4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E8u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC4E8 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC4EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC4EBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC4E8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC4EB;
L_0DC4EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4EBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4EBu,0x0DC4EBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4EB DEX
    cpu.decReg('X');
    goto L_0DC4EC;
L_0DC4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4ECu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4EC BPL -> $0DC4E3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DC4E3; }
    goto L_0DC4EE;
L_0DC4EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC4EE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DC4EEu);return;} hw.unresolvedReturn(0x0DC4EEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B18FC1_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB18FC1u: goto L_B18FC1;
    case 0xB18FC4u: goto L_B18FC4;
    case 0xB1A7E4u: goto L_B1A7E4;
    case 0xB1A7E7u: goto L_B1A7E7;
    case 0xB1A7E9u: goto L_B1A7E9;
    case 0xB1A7EBu: goto L_B1A7EB;
    case 0xB1A7ECu: goto L_B1A7EC;
    case 0xB1A7EEu: goto L_B1A7EE;
    case 0xB1A7F0u: goto L_B1A7F0;
    case 0xB1A7F3u: goto L_B1A7F3;
    case 0xB1A7F5u: goto L_B1A7F5;
    case 0xB1A7F6u: goto L_B1A7F6;
    case 0xB1A7F7u: goto L_B1A7F7;
    case 0xB1A7FAu: goto L_B1A7FA;
    case 0xB1A7FCu: goto L_B1A7FC;
    case 0xB1A7FDu: goto L_B1A7FD;
    case 0xB1A7FFu: goto L_B1A7FF;
    case 0xB1A801u: goto L_B1A801;
    case 0xB1A803u: goto L_B1A803;
    case 0xB1A806u: goto L_B1A806;
    case 0xB1A808u: goto L_B1A808;
    case 0xB1A809u: goto L_B1A809;
    case 0xB1A80Bu: goto L_B1A80B;
    case 0xB1A80Du: goto L_B1A80D;
    case 0xB1A80Fu: goto L_B1A80F;
    case 0xB1A811u: goto L_B1A811;
    case 0xB1A813u: goto L_B1A813;
    case 0xB1A815u: goto L_B1A815;
    case 0xB1A817u: goto L_B1A817;
    case 0xB1A81Au: goto L_B1A81A;
    case 0xB1A81Cu: goto L_B1A81C;
    case 0xB1A81Fu: goto L_B1A81F;
    case 0xB1A822u: goto L_B1A822;
    case 0xB1A824u: goto L_B1A824;
    case 0xB1A828u: goto L_B1A828;
    case 0xB1A82Cu: goto L_B1A82C;
    case 0xB1A830u: goto L_B1A830;
    case 0xB1A832u: goto L_B1A832;
    case 0xB1A835u: goto L_B1A835;
    case 0xB1A837u: goto L_B1A837;
    case 0xB1A838u: goto L_B1A838;
    case 0xB1A83Bu: goto L_B1A83B;
    case 0xB1A83Eu: goto L_B1A83E;
    case 0xB1A840u: goto L_B1A840;
    case 0xB1A843u: goto L_B1A843;
    case 0xB1A845u: goto L_B1A845;
    case 0xB1A847u: goto L_B1A847;
    case 0xB1A84Bu: goto L_B1A84B;
    case 0xB1A84Eu: goto L_B1A84E;
    case 0xB1A851u: goto L_B1A851;
    case 0xB1A853u: goto L_B1A853;
    case 0xB1A855u: goto L_B1A855;
    case 0xB1A857u: goto L_B1A857;
    case 0xB1A85Au: goto L_B1A85A;
    case 0xB1A85Eu: goto L_B1A85E;
    case 0xB1A861u: goto L_B1A861;
    case 0xB1A863u: goto L_B1A863;
    case 0xB1A865u: goto L_B1A865;
    case 0xB1A868u: goto L_B1A868;
    case 0xB1A86Bu: goto L_B1A86B;
    case 0xB1A86Du: goto L_B1A86D;
    case 0xB1A870u: goto L_B1A870;
    case 0xB1A872u: goto L_B1A872;
    case 0xB1A874u: goto L_B1A874;
    case 0xB1A877u: goto L_B1A877;
    case 0xB1A87Au: goto L_B1A87A;
    case 0xB1A87Cu: goto L_B1A87C;
    case 0xB1A87Du: goto L_B1A87D;
    case 0xB1A87Eu: goto L_B1A87E;
    case 0xB1A881u: goto L_B1A881;
    case 0xB1A884u: goto L_B1A884;
    case 0xB1A886u: goto L_B1A886;
    case 0xB1A888u: goto L_B1A888;
    case 0xB1A88Bu: goto L_B1A88B;
    case 0xB1A88Eu: goto L_B1A88E;
    case 0xB1A890u: goto L_B1A890;
    case 0xB1A892u: goto L_B1A892;
    case 0xB1A895u: goto L_B1A895;
    case 0xB1A896u: goto L_B1A896;
    case 0xB1A897u: goto L_B1A897;
    case 0xB1A899u: goto L_B1A899;
    case 0xB1A89Bu: goto L_B1A89B;
    case 0xB1A89Du: goto L_B1A89D;
    case 0xB1A89Eu: goto L_B1A89E;
    case 0xB1A8A0u: goto L_B1A8A0;
    case 0xB1A8A2u: goto L_B1A8A2;
    case 0xB1A8A4u: goto L_B1A8A4;
    case 0xB1A8A5u: goto L_B1A8A5;
    case 0xB1A8A7u: goto L_B1A8A7;
    case 0xB1A8A9u: goto L_B1A8A9;
    case 0xB1A8ABu: goto L_B1A8AB;
    case 0xB1A8ACu: goto L_B1A8AC;
    case 0xB1A8AEu: goto L_B1A8AE;
    case 0xB1A8B0u: goto L_B1A8B0;
    case 0xB1A8B2u: goto L_B1A8B2;
    case 0xB1A8B4u: goto L_B1A8B4;
    case 0xB1A8B7u: goto L_B1A8B7;
    case 0xB1A8B9u: goto L_B1A8B9;
    case 0xB1A8BBu: goto L_B1A8BB;
    case 0xB1A8BEu: goto L_B1A8BE;
    case 0xB1A8C0u: goto L_B1A8C0;
    case 0xB1A8C3u: goto L_B1A8C3;
    case 0xB1A8C5u: goto L_B1A8C5;
    case 0xB1A8C7u: goto L_B1A8C7;
    case 0xB1A8C9u: goto L_B1A8C9;
    case 0xB1A8CCu: goto L_B1A8CC;
    case 0xB1A8CEu: goto L_B1A8CE;
    case 0xB1A8D0u: goto L_B1A8D0;
    case 0xB1A8D3u: goto L_B1A8D3;
    case 0xB1A8D6u: goto L_B1A8D6;
    case 0xB1A8D8u: goto L_B1A8D8;
    case 0xB1A8DAu: goto L_B1A8DA;
    case 0xB1A8DDu: goto L_B1A8DD;
    case 0xB1A8E1u: goto L_B1A8E1;
    case 0xB1A8E5u: goto L_B1A8E5;
    case 0xB1A8E6u: goto L_B1A8E6;
    case 0xB1A8E9u: goto L_B1A8E9;
    case 0xB1A8EBu: goto L_B1A8EB;
    case 0xB1A8EEu: goto L_B1A8EE;
    case 0xB1A8F0u: goto L_B1A8F0;
    case 0xB1A8F2u: goto L_B1A8F2;
    case 0xB1A8F5u: goto L_B1A8F5;
    case 0xB1A8F8u: goto L_B1A8F8;
    case 0xB1A8F9u: goto L_B1A8F9;
    case 0xB1A8FCu: goto L_B1A8FC;
    case 0xB1A8FEu: goto L_B1A8FE;
    case 0xB1A901u: goto L_B1A901;
    case 0xB1A903u: goto L_B1A903;
    case 0xB1A906u: goto L_B1A906;
    case 0xB1A908u: goto L_B1A908;
    case 0xB1A90Au: goto L_B1A90A;
    case 0xB1A90Du: goto L_B1A90D;
    case 0xB1A90Eu: goto L_B1A90E;
    case 0xB1A911u: goto L_B1A911;
    case 0xB1A913u: goto L_B1A913;
    case 0xB1A915u: goto L_B1A915;
    case 0xB1A917u: goto L_B1A917;
    case 0xB1A91Bu: goto L_B1A91B;
    case 0xB1A91Cu: goto L_B1A91C;
    case 0xB1A91Fu: goto L_B1A91F;
    case 0xB1A922u: goto L_B1A922;
    case 0xB1A924u: goto L_B1A924;
    case 0xB1A928u: goto L_B1A928;
    case 0xB1A92Au: goto L_B1A92A;
    case 0xB1A92Cu: goto L_B1A92C;
    case 0xB1A92Fu: goto L_B1A92F;
    case 0xB1A931u: goto L_B1A931;
    case 0xB1A935u: goto L_B1A935;
    case 0xB1A938u: goto L_B1A938;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B18FC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u, 6u, 3u, cpu.address("abs", 0xA40Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18FC1 JSR -> $B1A40D stack real
    { cpu.push16Value(hw,0x8FC3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8FC4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA40Du), 0xB18FC1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18FC4;
L_B18FC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC4u, 3u, 3u, cpu.address("abs", 0xA7E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18FC4 JMP -> $B1A7E4
    goto L_B1A7E4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC4u, 3u, 3u, cpu.address("abs", 0xA7E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18FC4 JMP -> $B1A7E4
    goto L_B1A7E4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FC4u,0xB18FC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E4u, 4u + ((((0x167Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x167Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7E4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x167Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A7E7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E4u, 4u + ((((0x167Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x167Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7E4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x167Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A7E7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7E4u,0xB1A7E4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A7E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7E7 AND
    cpu.logicAnd(0x20u);
    goto L_B1A7E9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7E7 AND
    cpu.logicAnd(0x20u);
    goto L_B1A7E9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7E7u,0xB1A7E7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7E9 BNE -> $B1A7F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A7F7; }
    goto L_B1A7EB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7E9 BNE -> $B1A7F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A7F7; }
    goto L_B1A7EB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7E9u,0xB1A7E9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EBu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7EB TXA
    cpu.transfer("TXA");
    goto L_B1A7EC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EBu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7EB TXA
    cpu.transfer("TXA");
    goto L_B1A7EC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7EBu,0xB1A7EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7ECu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ECu,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7EC EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_B1A7EE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ECu,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7EC EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_B1A7EE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7ECu,0xB1A7ECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7EE AND
    cpu.logicAnd(0x1u);
    goto L_B1A7F0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7EE AND
    cpu.logicAnd(0x1u);
    goto L_B1A7F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7EEu,0xB1A7EEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A7F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F0u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F0u, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7F0 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16));
    goto L_B1A7F3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F0u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F0u, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7F0 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16));
    goto L_B1A7F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7F0u,0xB1A7F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7F3 BEQ -> $B1A7F7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A7F7; }
    goto L_B1A7F5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7F3 BEQ -> $B1A7F7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A7F7; }
    goto L_B1A7F5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7F3u,0xB1A7F3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7F5 CLC
    cpu.setFlag('C', false);
    goto L_B1A7F6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7F5 CLC
    cpu.setFlag('C', false);
    goto L_B1A7F6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7F5u,0xB1A7F5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A7F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A7F6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A7F6u);return;} hw.unresolvedReturn(0xB1A7F6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F7u, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A7F7 JSR -> $B1AD30 stack real
    { cpu.push16Value(hw,0xA7F9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7FAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0xB1A7F7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A7FA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F7u, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A7F7 JSR -> $B1AD30 stack real
    { cpu.push16Value(hw,0xA7F9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7FAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0xB1A7F7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A7FA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7F7u,0xB1A7F7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7FAu,0xB1A7FAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7FA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A7FC;
L_B1A7FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7FC CLC
    cpu.setFlag('C', false);
    goto L_B1A7FD;
L_B1A7FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7FD ADC
    cpu.adc(0x50u);
    goto L_B1A7FF;
L_B1A7FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7FF CMP
    cpu.compareA(0xA0u);
    goto L_B1A801;
L_B1A801:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA801u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA801u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA801u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A801 BCS -> $B1A7F5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A7F5; }
    goto L_B1A803;
L_B1A803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA803u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA803u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA803u, 6u, 3u, cpu.address("abs", 0xAD42u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A803 JSR -> $B1AD42 stack real
    { cpu.push16Value(hw,0xA805u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA806u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD42u), 0xB1A803u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A806;
L_B1A806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA806u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA806u,0xB1A806u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA806u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA806u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A806 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A808;
L_B1A808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA808u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA808u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A808 CLC
    cpu.setFlag('C', false);
    goto L_B1A809;
L_B1A809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA809u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA809u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A809 ADC
    cpu.adc(0x60u);
    goto L_B1A80B;
L_B1A80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A80B CMP
    cpu.compareA(0xC0u);
    goto L_B1A80D;
L_B1A80D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA80Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A80D BCS -> $B1A7F5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A7F5; }
    goto L_B1A80F;
L_B1A80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A80F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A811;
L_B1A811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA811u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA811u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A811 CMP
    cpu.compareA(0x1u);
    goto L_B1A813;
L_B1A813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA813u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA813u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A813 BCS -> $B1A7F5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A7F5; }
    goto L_B1A815;
L_B1A815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA815u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA815u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A815 LDA
    cpu.setA(0x0u, 8);
    goto L_B1A817;
L_B1A817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA817u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA817u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A817 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), false);
    goto L_B1A81A;
L_B1A81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Au,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A81A BVS -> $B1A822
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_B1A822; }
    goto L_B1A81C;
L_B1A81C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA81Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Cu, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A81C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13F9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A81F;
L_B1A81F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA81Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Fu,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Fu, 4u + ((((0x1632u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1632u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A81F EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0x1632u), cpu.m8?8:16));
    goto L_B1A822;
L_B1A822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA822u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA822u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A822 BNE -> $B1A87C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A87C; }
    goto L_B1A824;
L_B1A824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA824u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA824u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA824u, 8u, 4u, 0x03B664u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A824 JSL -> $03B664 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA827u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA828u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03B664u, 0xB1A824u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A828;
L_B1A828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA828u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA828u,0xB1A828u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA828u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA828u, 8u, 4u, 0x03B69Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A828 JSL -> $03B69F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA82Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA82Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03B69Fu, 0xB1A828u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A82C;
L_B1A82C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA82Cu,0xB1A82Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Cu, 8u, 4u, 0x03B72Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A82C JSL -> $03B72B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA82Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA830u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03B72Bu, 0xB1A82Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A830;
L_B1A830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA830u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA830u,0xB1A830u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA830u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA830u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A830 BCC -> $B1A87C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A87C; }
    goto L_B1A832;
L_B1A832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA832u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA832u, 4u + ((((0x167Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x167Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A832 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x167Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A835;
L_B1A835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA835u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA835u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A835 BPL -> $B1A83B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_B1A83B; }
    goto L_B1A837;
L_B1A837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA837u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA837u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A837 SEC
    cpu.setFlag('C', true);
    goto L_B1A838;
L_B1A838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA838u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA838u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A838 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A838u);return;} hw.unresolvedReturn(0xB1A838u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A83B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA83Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Bu, 4u, 3u, cpu.address("abs", 0x1490u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A83B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1490u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A83E;
L_B1A83E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA83Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A83E BEQ -> $B1A87E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A87E; }
    goto L_B1A840;
L_B1A840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA840u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA840u, 4u + ((((0x167Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x167Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A840 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x167Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A843;
L_B1A843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA843u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA843u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A843 AND
    cpu.logicAnd(0x2u);
    goto L_B1A845;
L_B1A845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA845u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA845u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A845 BNE -> $B1A87E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A87E; }
    goto L_B1A847;
L_B1A847:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA847u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA847u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA847u, 8u, 4u, 0x01AB6Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A847 JSL -> $01AB6F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA84Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA84Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB6Fu, 0xB1A847u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A84B;
L_B1A84B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA84Bu,0xB1A84Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Bu, 6u, 3u, cpu.address("abs", 0x18D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A84B INC
    cpu.incMem(hw, cpu.address("abs", 0x18D2u), cpu.m8?8:16);
    goto L_B1A84E;
L_B1A84E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Eu, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A84E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18D2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A851;
L_B1A851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA851u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA851u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A851 CMP
    cpu.compareA(0x8u);
    goto L_B1A853;
L_B1A853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA853u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA853u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A853 BCC -> $B1A85A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A85A; }
    goto L_B1A855;
L_B1A855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A855 LDA
    cpu.setA(0x8u, 8);
    goto L_B1A857;
L_B1A857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA857u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA857u, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A857 STA
    hw.write(cpu.address("abs", 0x18D2u), cpu.a, cpu.m8?8:16);
    goto L_B1A85A;
L_B1A85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Au, 8u, 4u, 0x02ACE5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A85A JSL -> $02ACE5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA85Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA85Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACE5u, 0xB1A85Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A85E;
L_B1A85E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA85Eu,0xB1A85Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Eu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Eu, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A85E LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x18D2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A861;
L_B1A861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA861u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA861u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A861 CPY
    cpu.compareY(0x8u);
    goto L_B1A863;
L_B1A863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A863 BCS -> $B1A86B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A86B; }
    goto L_B1A865;
L_B1A865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u, 4u + ((((0xA61Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA61Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A865 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA61Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A868;
L_B1A868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A868 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_B1A86B;
L_B1A86B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A86B LDA
    cpu.setA(0x2u, 8);
    goto L_B1A86D;
L_B1A86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Du, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A86D STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A870;
L_B1A870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA870u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA870u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A870 LDA
    cpu.setA(0xD0u, 8);
    goto L_B1A872;
L_B1A872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA872u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA872u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A872 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A874;
L_B1A874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A874 JSR -> $B1AD30 stack real
    { cpu.push16Value(hw,0xA876u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA877u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0xB1A874u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A877;
L_B1A877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA877u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA877u,0xB1A877u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u, 4u + ((((0xA839u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA839u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A877 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA839u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A87A;
L_B1A87A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A87A STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B1A87C;
L_B1A87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A87C CLC
    cpu.setFlag('C', false);
    goto L_B1A87D;
L_B1A87D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A87D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A87Du);return;} hw.unresolvedReturn(0xB1A87Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A87E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Eu, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A87E STZ
    hw.write(cpu.address("abs", 0x18D2u), 0, cpu.m8?8:16);
    goto L_B1A881;
L_B1A881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u, 4u + ((((0x154Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A881 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x154Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A884;
L_B1A884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A884 BNE -> $B1A895
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A895; }
    goto L_B1A886;
L_B1A886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA886u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA886u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A886 LDA
    cpu.setA(0x8u, 8);
    goto L_B1A888;
L_B1A888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA888u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA888u, 5u, 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A888 STA
    hw.write(cpu.address("absx", 0x154Cu), cpu.a, cpu.m8?8:16);
    goto L_B1A88B;
L_B1A88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Bu, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A88B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A88E;
L_B1A88E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A88E CMP
    cpu.compareA(0x9u);
    goto L_B1A890;
L_B1A890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA890u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA890u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA890u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A890 BNE -> $B1A897
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A897; }
    goto L_B1A892;
L_B1A892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA892u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA892u, 6u, 3u, cpu.address("abs", 0xAA42u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A892 JSR -> $B1AA42 stack real
    { cpu.push16Value(hw,0xA894u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA895u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA42u), 0xB1A892u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A895;
L_B1A895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA895u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA895u,0xB1A895u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA895u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA895u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A895 CLC
    cpu.setFlag('C', false);
    goto L_B1A896;
L_B1A896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA896u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA896u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A896 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A896u);return;} hw.unresolvedReturn(0xB1A896u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A897 LDA
    cpu.setA(0x14u, 8);
    goto L_B1A899;
L_B1A899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A899 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_B1A89B;
L_B1A89B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A89B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A89D;
L_B1A89D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A89D SEC
    cpu.setFlag('C', true);
    goto L_B1A89E;
L_B1A89E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Eu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A89E SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16));
    goto L_B1A8A0;
L_B1A8A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A0u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8A0 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_B1A8A2;
L_B1A8A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A2u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8A2 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xD3u), cpu.m8?8:16));
    goto L_B1A8A4;
L_B1A8A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A4u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A8A4 PHP
    cpu.push("PHP", hw);
    goto L_B1A8A5;
L_B1A8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A5u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8A5 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_B1A8A7;
L_B1A8A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8A7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8A9;
L_B1A8A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8A9 SBC
    cpu.sbc(0x0u);
    goto L_B1A8AB;
L_B1A8AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ABu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ABu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A8AB PLP
    cpu.pop("PLP", hw);
    goto L_B1A8AC;
L_B1A8AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8ACu,0xB1A8ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ACu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8AC SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xD4u), cpu.m8?8:16));
    goto L_B1A8AE;
L_B1A8AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8AEu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8AE BMI -> $B1A8E6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_B1A8E6; }
    goto L_B1A8B0;
L_B1A8B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8B0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8B2;
L_B1A8B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8B2 BPL -> $B1A8C0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_B1A8C0; }
    goto L_B1A8B4;
L_B1A8B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B4u, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8B4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8B7;
L_B1A8B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8B7 AND
    cpu.logicAnd(0x10u);
    goto L_B1A8B9;
L_B1A8B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8B9 BNE -> $B1A8C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A8C0; }
    goto L_B1A8BB;
L_B1A8BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BBu, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8BB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1697u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8BE;
L_B1A8BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8BE BEQ -> $B1A8E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A8E6; }
    goto L_B1A8C0;
L_B1A8C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C0u, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A8C0 JSR -> $B1800E stack real
    { cpu.push16Value(hw,0xA8C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8C3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0xB1A8C0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A8C3;
L_B1A8C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8C3u,0xB1A8C3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8C3 BEQ -> $B1A8C9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A8C9; }
    goto L_B1A8C5;
L_B1A8C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8C7;
L_B1A8C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8C7 BEQ -> $B1A8E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A8E6; }
    goto L_B1A8C9;
L_B1A8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C9u, 4u + ((((0x1656u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1656u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8C9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1656u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8CC;
L_B1A8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8CC AND
    cpu.logicAnd(0x10u);
    goto L_B1A8CE;
L_B1A8CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8CE BNE -> $B1A91C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A91C; }
    goto L_B1A8D0;
L_B1A8D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D0u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8D0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x140Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8D3;
L_B1A8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D3u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D3u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8D3 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16));
    goto L_B1A8D6;
L_B1A8D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8D6 BEQ -> $B1A8E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A8E6; }
    goto L_B1A8D8;
L_B1A8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8D8 LDA
    cpu.setA(0x2u, 8);
    goto L_B1A8DA;
L_B1A8DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8DA STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_B1A8DD;
L_B1A8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DDu, 8u, 4u, 0x01AA33u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A8DD JSL -> $01AA33 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA8E0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8E1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AA33u, 0xB1A8DDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A8E1;
L_B1A8E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8E1u,0xB1A8E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E1u, 8u, 4u, 0x01AB99u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A8E1 JSL -> $01AB99 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA8E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8E5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB99u, 0xB1A8E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A8E5;
L_B1A8E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8E5u,0xB1A8E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A8E5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A8E5u);return;} hw.unresolvedReturn(0xB1A8E5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E6u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8E6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13EDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8E9;
L_B1A8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8E9 BEQ -> $B1A8F9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A8F9; }
    goto L_B1A8EB;
L_B1A8EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EBu, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8EB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8EE;
L_B1A8EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8EE AND
    cpu.logicAnd(0x4u);
    goto L_B1A8F0;
L_B1A8F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8F0 BNE -> $B1A8F9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A8F9; }
    goto L_B1A8F2;
L_B1A8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u, 6u, 3u, cpu.address("abs", 0xA728u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A8F2 JSR -> $B1A728 stack real
    { cpu.push16Value(hw,0xA8F4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8F5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA728u), 0xB1A8F2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A8F5;
L_B1A8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8F5u,0xB1A8F5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F5u, 6u, 3u, cpu.address("abs", 0xA847u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A8F5 JSR -> $B1A847 stack real
    { cpu.push16Value(hw,0xA8F7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8F8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA847u), 0xB1A8F5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A8F8;
L_B1A8F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8F8u,0xB1A8F8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A8F8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A8F8u);return;} hw.unresolvedReturn(0xB1A8F8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u, 4u, 3u, cpu.address("abs", 0x1497u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8F9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1497u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8FC;
L_B1A8FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8FC BNE -> $B1A91B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A91B; }
    goto L_B1A8FE;
L_B1A8FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FEu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A901;
L_B1A901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA901u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA901u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A901 BNE -> $B1A91B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A91B; }
    goto L_B1A903;
L_B1A903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u, 4u + ((((0x1686u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A903 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1686u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A906;
L_B1A906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA906u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA906u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A906 AND
    cpu.logicAnd(0x10u);
    goto L_B1A908;
L_B1A908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A908 BNE -> $B1A911
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A911; }
    goto L_B1A90A;
L_B1A90A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Au, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A90A JSR -> $B1AD30 stack real
    { cpu.push16Value(hw,0xA90Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA90Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0xB1A90Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A90D;
L_B1A90D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA90Du,0xB1A90Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A90D TYA
    cpu.transfer("TYA");
    goto L_B1A90E;
L_B1A90E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A90E STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_B1A911;
L_B1A911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA911u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA911u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A911 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A913;
L_B1A913:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA913u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A913 CMP
    cpu.compareA(0x53u);
    goto L_B1A915;
L_B1A915:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA915u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA915u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA915u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A915 BEQ -> $B1A91B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A91B; }
    goto L_B1A917;
L_B1A917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA917u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA917u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA917u, 8u, 4u, 0x00F5B7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A917 JSL -> $00F5B7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA91Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA91Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F5B7u, 0xB1A917u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A91B;
L_B1A91B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA91Bu,0xB1A91Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A91B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A91Bu);return;} hw.unresolvedReturn(0xB1A91Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A91C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Cu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A91C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x140Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A91F;
L_B1A91F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Fu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Fu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A91F ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16));
    goto L_B1A922;
L_B1A922:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA922u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA922u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA922u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A922 BEQ -> $B1A947
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0xB1A947u,0xB1A922u); return; }
    goto L_B1A924;
L_B1A924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA924u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA924u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA924u, 8u, 4u, 0x01AB99u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A924 JSL -> $01AB99 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA927u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA928u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB99u, 0xB1A924u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A928;
L_B1A928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA928u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA928u,0xB1A928u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA928u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA928u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A928 LDA
    cpu.setA(0xF8u, 8);
    goto L_B1A92A;
L_B1A92A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A92A STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_B1A92C;
L_B1A92C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Cu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A92C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A92F;
L_B1A92F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A92F BEQ -> $B1A935
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A935; }
    goto L_B1A931;
L_B1A931:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA931u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA931u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA931u, 8u, 4u, 0x01AA33u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A931 JSL -> $01AA33 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA934u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA935u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AA33u, 0xB1A931u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A935;
L_B1A935:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA935u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA935u,0xB1A935u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA935u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA935u, 6u, 3u, cpu.address("abs", 0x9ACBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A935 JSR -> $B19ACB stack real
    { cpu.push16Value(hw,0xA937u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA938u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9ACBu), 0xB1A935u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A938;
L_B1A938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA938u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA938u,0xB1A938u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA938u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA938u, 8u, 4u, 0x07FC3Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A938 JSL -> $07FC3B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA93Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA93Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07FC3Bu, 0xB1A938u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA93Cu,0xB1A938u); return;
}

void sub_B1928E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1928Eu: goto L_B1928E;
    case 0xB19290u: goto L_B19290;
    case 0xB19291u: goto L_B19291;
    case 0xB19294u: goto L_B19294;
    case 0xB19297u: goto L_B19297;
    case 0xB19299u: goto L_B19299;
    case 0xB1929Cu: goto L_B1929C;
    case 0xB1929Eu: goto L_B1929E;
    case 0xB192A0u: goto L_B192A0;
    case 0xB192A2u: goto L_B192A2;
    case 0xB192A4u: goto L_B192A4;
    case 0xB192A7u: goto L_B192A7;
    case 0xB192AAu: goto L_B192AA;
    case 0xB192ADu: goto L_B192AD;
    case 0xB192B0u: goto L_B192B0;
    case 0xB192B2u: goto L_B192B2;
    case 0xB192B5u: goto L_B192B5;
    case 0xB192B7u: goto L_B192B7;
    case 0xB192BAu: goto L_B192BA;
    case 0xB192BDu: goto L_B192BD;
    case 0xB192C0u: goto L_B192C0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1928E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1928E AND
    cpu.logicAnd(0x1u);
    goto L_B19290;
L_B19290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9290u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9290u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19290 TAY
    cpu.transfer("TAY");
    goto L_B19291;
L_B19291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9291u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9291u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9291u, 6u, 3u, cpu.address("abs", 0x9441u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19291 JSR -> $B19441 stack real
    { cpu.push16Value(hw,0x9293u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9294u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9441u), 0xB19291u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19294;
L_B19294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9294u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9294u,0xB19294u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9294u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9294u, 4u, 3u, cpu.address("abs", 0x1862u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19294 STA
    hw.write(cpu.address("abs", 0x1862u), cpu.a, cpu.m8?8:16);
    goto L_B19297;
L_B19297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9297u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9297u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19297 BEQ -> $B192BA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B192BA; }
    goto L_B19299;
L_B19299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19299 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1929C;
L_B1929C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1929C CMP
    cpu.compareA(0x11u);
    goto L_B1929E;
L_B1929E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1929E BCC -> $B192BA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B192BA; }
    goto L_B192A0;
L_B192A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192A0 CMP
    cpu.compareA(0x6Eu);
    goto L_B192A2;
L_B192A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192A2 BCS -> $B192BA
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B192BA; }
    goto L_B192A4;
L_B192A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A4u, 6u, 3u, cpu.address("abs", 0x9425u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B192A4 JSR -> $B19425 stack real
    { cpu.push16Value(hw,0x92A6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x92A7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9425u), 0xB192A4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B192A7;
L_B192A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92A7u,0xB192A7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A7u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192A7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B192AA;
L_B192AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92AAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92AAu, 4u, 3u, cpu.address("abs", 0x18A7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192AA STA
    hw.write(cpu.address("abs", 0x18A7u), cpu.a, cpu.m8?8:16);
    goto L_B192AD;
L_B192AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ADu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ADu, 4u, 3u, cpu.address("abs", 0x185Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192AD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x185Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B192B0;
L_B192B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192B0 BEQ -> $B192BA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B192BA; }
    goto L_B192B2;
L_B192B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B2u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192B2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B192B5;
L_B192B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B5u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192B5 ORA
    cpu.logicOr(0x40u);
    goto L_B192B7;
L_B192B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B7u, 5u, 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192B7 STA
    hw.write(cpu.address("absx", 0x1588u), cpu.a, cpu.m8?8:16);
    goto L_B192BA;
L_B192BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BAu, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192BA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B192BD;
L_B192BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BDu, 4u, 3u, cpu.address("abs", 0x1860u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192BD STA
    hw.write(cpu.address("abs", 0x1860u), cpu.a, cpu.m8?8:16);
    goto L_B192C0;
L_B192C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B192C0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB192C0u);return;} hw.unresolvedReturn(0xB192C0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A365_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A365u: goto L_B1A365;
    case 0xB1A368u: goto L_B1A368;
    case 0xB1A36Bu: goto L_B1A36B;
    case 0xB1A36Du: goto L_B1A36D;
    case 0xB1A36Fu: goto L_B1A36F;
    case 0xB1A372u: goto L_B1A372;
    case 0xB1A374u: goto L_B1A374;
    case 0xB1A376u: goto L_B1A376;
    case 0xB1A379u: goto L_B1A379;
    case 0xB1A37Cu: goto L_B1A37C;
    case 0xB1A37Du: goto L_B1A37D;
    case 0xB1A37Fu: goto L_B1A37F;
    case 0xB1A381u: goto L_B1A381;
    case 0xB1A382u: goto L_B1A382;
    case 0xB1A384u: goto L_B1A384;
    case 0xB1A385u: goto L_B1A385;
    case 0xB1A388u: goto L_B1A388;
    case 0xB1A38Bu: goto L_B1A38B;
    case 0xB1A38Du: goto L_B1A38D;
    case 0xB1A38Eu: goto L_B1A38E;
    case 0xB1A390u: goto L_B1A390;
    case 0xB1A393u: goto L_B1A393;
    case 0xB1A395u: goto L_B1A395;
    case 0xB1A397u: goto L_B1A397;
    case 0xB1A39Au: goto L_B1A39A;
    case 0xB1A39Cu: goto L_B1A39C;
    case 0xB1A39Eu: goto L_B1A39E;
    case 0xB1A3A1u: goto L_B1A3A1;
    case 0xB1A3A3u: goto L_B1A3A3;
    case 0xB1A3A5u: goto L_B1A3A5;
    case 0xB1A3A6u: goto L_B1A3A6;
    case 0xB1A3A8u: goto L_B1A3A8;
    case 0xB1A3A9u: goto L_B1A3A9;
    case 0xB1A3ACu: goto L_B1A3AC;
    case 0xB1A3ADu: goto L_B1A3AD;
    case 0xB1A3AFu: goto L_B1A3AF;
    case 0xB1A3B1u: goto L_B1A3B1;
    case 0xB1A3B2u: goto L_B1A3B2;
    case 0xB1A3B5u: goto L_B1A3B5;
    case 0xB1A3B7u: goto L_B1A3B7;
    case 0xB1A3B9u: goto L_B1A3B9;
    case 0xB1A3BBu: goto L_B1A3BB;
    case 0xB1A3BDu: goto L_B1A3BD;
    case 0xB1A3C0u: goto L_B1A3C0;
    case 0xB1A3C3u: goto L_B1A3C3;
    case 0xB1A3C6u: goto L_B1A3C6;
    case 0xB1A3C7u: goto L_B1A3C7;
    case 0xB1A3C9u: goto L_B1A3C9;
    case 0xB1A3CBu: goto L_B1A3CB;
    case 0xB1A3CCu: goto L_B1A3CC;
    case 0xB1A3CDu: goto L_B1A3CD;
    case 0xB1A3D0u: goto L_B1A3D0;
    case 0xB1A3D2u: goto L_B1A3D2;
    case 0xB1A3D3u: goto L_B1A3D3;
    case 0xB1A3D5u: goto L_B1A3D5;
    case 0xB1A3D7u: goto L_B1A3D7;
    case 0xB1A3D9u: goto L_B1A3D9;
    case 0xB1A3DAu: goto L_B1A3DA;
    case 0xB1A3DCu: goto L_B1A3DC;
    case 0xB1A3DEu: goto L_B1A3DE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u, 5u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A365 STZ
    hw.write(cpu.address("absx", 0x186Cu), 0, cpu.m8?8:16);
    goto L_B1A368;
L_B1A368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u, 5u, 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A368 STZ
    hw.write(cpu.address("absx", 0x15A0u), 0, cpu.m8?8:16);
    goto L_B1A36B;
L_B1A36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A36B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A36D;
L_B1A36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A36D CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_B1A36F;
L_B1A36F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Fu, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A36F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A372;
L_B1A372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA372u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA372u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA372u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A372 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16));
    goto L_B1A374;
L_B1A374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA374u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA374u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A374 BEQ -> $B1A379
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A379; }
    goto L_B1A376;
L_B1A376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA376u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA376u, 7u, 3u, cpu.address("absx", 0x15A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A376 INC
    cpu.incMem(hw, cpu.address("absx", 0x15A0u), cpu.m8?8:16);
    goto L_B1A379;
L_B1A379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA379u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA379u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A379 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A37C;
L_B1A37C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A37C XBA
    cpu.xba();
    goto L_B1A37D;
L_B1A37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A37D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A37F;
L_B1A37F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A37F REP
    cpu.rep(0x20u);
    goto L_B1A381;
L_B1A381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA381u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA381u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A381 SEC
    cpu.setFlag('C', true);
    goto L_B1A382;
L_B1A382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA382u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA382u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A382 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_B1A384;
L_B1A384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA384u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA384u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A384 CLC
    cpu.setFlag('C', false);
    goto L_B1A385;
L_B1A385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA385u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA385u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A385 ADC
    cpu.adc(0x40u);
    goto L_B1A388;
L_B1A388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA388u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA388u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A388 CMP
    cpu.compareA(0x180u);
    goto L_B1A38B;
L_B1A38B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A38B SEP
    cpu.sep(0x20u);
    goto L_B1A38D;
L_B1A38D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A38D ROL
    cpu.rolA();
    goto L_B1A38E;
L_B1A38E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A38E AND
    cpu.logicAnd(0x1u);
    goto L_B1A390;
L_B1A390:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA390u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA390u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA390u, 5u, 3u, cpu.address("absx", 0x15C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A390 STA
    hw.write(cpu.address("absx", 0x15C4u), cpu.a, cpu.m8?8:16);
    goto L_B1A393;
L_B1A393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA393u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA393u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A393 BNE -> $B1A3CB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A3CB; }
    goto L_B1A395;
L_B1A395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA395u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA395u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A395 LDY
    cpu.setY(0x0u, 8);
    goto L_B1A397;
L_B1A397:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA397u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA397u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA397u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A397 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A39A;
L_B1A39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A39A CMP
    cpu.compareA(0x9u);
    goto L_B1A39C;
L_B1A39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A39C BEQ -> $B1A3A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A3A6; }
    goto L_B1A39E;
L_B1A39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Eu, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A39E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3A1;
L_B1A3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A1 AND
    cpu.logicAnd(0x20u);
    goto L_B1A3A3;
L_B1A3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A3 BEQ -> $B1A3A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A3A6; }
    goto L_B1A3A5;
L_B1A3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A5 INY
    cpu.inc('Y');
    goto L_B1A3A6;
L_B1A3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3A8;
L_B1A3A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A8 CLC
    cpu.setFlag('C', false);
    goto L_B1A3A9;
L_B1A3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A9u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A9u, 4u + ((((0xA361u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA361u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A9 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xA361u), cpu.m8?8:16));
    goto L_B1A3AC;
L_B1A3AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ACu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ACu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3AC PHP
    cpu.push("PHP", hw);
    goto L_B1A3AD;
L_B1A3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3AD CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_B1A3AF;
L_B1A3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AFu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3AF ROL
    cpu.rolMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_B1A3B1;
L_B1A3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B1u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3B1 PLP
    cpu.pop("PLP", hw);
    goto L_B1A3B2;
L_B1A3B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3B2u,0xB1A3B2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B2u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3B2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3B5;
L_B1A3B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3B5 ADC
    cpu.adc(0x0u);
    goto L_B1A3B7;
L_B1A3B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3B7 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_B1A3B9;
L_B1A3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B9u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3B9 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Du), cpu.m8?8:16));
    goto L_B1A3BB;
L_B1A3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3BB BEQ -> $B1A3C6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A3C6; }
    goto L_B1A3BD;
L_B1A3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BDu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3BD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3C0;
L_B1A3C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u, 4u + ((((0xA363u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA363u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C0 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xA363u), cpu.m8?8:16));
    goto L_B1A3C3;
L_B1A3C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C3u, 5u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C3 STA
    hw.write(cpu.address("absx", 0x186Cu), cpu.a, cpu.m8?8:16);
    goto L_B1A3C6;
L_B1A3C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C6 DEY
    cpu.decReg('Y');
    goto L_B1A3C7;
L_B1A3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C7 BPL -> $B1A3A6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_B1A3A6; }
    goto L_B1A3C9;
L_B1A3C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C9 BRA -> $B1A3CD
    goto L_B1A3CD;
L_B1A3CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CBu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3CB PLA
    cpu.pop("PLA", hw);
    goto L_B1A3CC;
L_B1A3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3CC PLA
    cpu.pop("PLA", hw);
    goto L_B1A3CD;
L_B1A3CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CDu, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3CD LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A3D0;
L_B1A3D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3D2;
L_B1A3D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D2 SEC
    cpu.setFlag('C', true);
    goto L_B1A3D3;
L_B1A3D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D3u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D3 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_B1A3D5;
L_B1A3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_B1A3D7;
L_B1A3D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3D9;
L_B1A3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D9 SEC
    cpu.setFlag('C', true);
    goto L_B1A3DA;
L_B1A3DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DAu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3DA SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_B1A3DC;
L_B1A3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3DC STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_B1A3DE;
L_B1A3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A3DE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A3DEu);return;} hw.unresolvedReturn(0xB1A3DEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A365_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A365u: goto L_B1A365;
    case 0xB1A368u: goto L_B1A368;
    case 0xB1A36Bu: goto L_B1A36B;
    case 0xB1A36Du: goto L_B1A36D;
    case 0xB1A36Fu: goto L_B1A36F;
    case 0xB1A372u: goto L_B1A372;
    case 0xB1A374u: goto L_B1A374;
    case 0xB1A376u: goto L_B1A376;
    case 0xB1A379u: goto L_B1A379;
    case 0xB1A37Cu: goto L_B1A37C;
    case 0xB1A37Du: goto L_B1A37D;
    case 0xB1A37Fu: goto L_B1A37F;
    case 0xB1A381u: goto L_B1A381;
    case 0xB1A382u: goto L_B1A382;
    case 0xB1A384u: goto L_B1A384;
    case 0xB1A385u: goto L_B1A385;
    case 0xB1A388u: goto L_B1A388;
    case 0xB1A38Bu: goto L_B1A38B;
    case 0xB1A38Du: goto L_B1A38D;
    case 0xB1A38Eu: goto L_B1A38E;
    case 0xB1A390u: goto L_B1A390;
    case 0xB1A393u: goto L_B1A393;
    case 0xB1A395u: goto L_B1A395;
    case 0xB1A397u: goto L_B1A397;
    case 0xB1A39Au: goto L_B1A39A;
    case 0xB1A39Cu: goto L_B1A39C;
    case 0xB1A39Eu: goto L_B1A39E;
    case 0xB1A3A1u: goto L_B1A3A1;
    case 0xB1A3A3u: goto L_B1A3A3;
    case 0xB1A3A5u: goto L_B1A3A5;
    case 0xB1A3A6u: goto L_B1A3A6;
    case 0xB1A3A8u: goto L_B1A3A8;
    case 0xB1A3A9u: goto L_B1A3A9;
    case 0xB1A3ACu: goto L_B1A3AC;
    case 0xB1A3ADu: goto L_B1A3AD;
    case 0xB1A3AFu: goto L_B1A3AF;
    case 0xB1A3B1u: goto L_B1A3B1;
    case 0xB1A3B2u: goto L_B1A3B2;
    case 0xB1A3B5u: goto L_B1A3B5;
    case 0xB1A3B7u: goto L_B1A3B7;
    case 0xB1A3B9u: goto L_B1A3B9;
    case 0xB1A3BBu: goto L_B1A3BB;
    case 0xB1A3BDu: goto L_B1A3BD;
    case 0xB1A3C0u: goto L_B1A3C0;
    case 0xB1A3C3u: goto L_B1A3C3;
    case 0xB1A3C6u: goto L_B1A3C6;
    case 0xB1A3C7u: goto L_B1A3C7;
    case 0xB1A3C9u: goto L_B1A3C9;
    case 0xB1A3CBu: goto L_B1A3CB;
    case 0xB1A3CCu: goto L_B1A3CC;
    case 0xB1A3CDu: goto L_B1A3CD;
    case 0xB1A3D0u: goto L_B1A3D0;
    case 0xB1A3D2u: goto L_B1A3D2;
    case 0xB1A3D3u: goto L_B1A3D3;
    case 0xB1A3D5u: goto L_B1A3D5;
    case 0xB1A3D7u: goto L_B1A3D7;
    case 0xB1A3D9u: goto L_B1A3D9;
    case 0xB1A3DAu: goto L_B1A3DA;
    case 0xB1A3DCu: goto L_B1A3DC;
    case 0xB1A3DEu: goto L_B1A3DE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u, 5u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A365 STZ
    hw.write(cpu.address("absx", 0x186Cu), 0, cpu.m8?8:16);
    goto L_B1A368;
L_B1A368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u, 5u, 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A368 STZ
    hw.write(cpu.address("absx", 0x15A0u), 0, cpu.m8?8:16);
    goto L_B1A36B;
L_B1A36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A36B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A36D;
L_B1A36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A36D CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_B1A36F;
L_B1A36F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Fu, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A36F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A372;
L_B1A372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA372u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA372u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA372u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A372 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16));
    goto L_B1A374;
L_B1A374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA374u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA374u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A374 BEQ -> $B1A379
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A379; }
    goto L_B1A376;
L_B1A376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA376u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA376u, 7u, 3u, cpu.address("absx", 0x15A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A376 INC
    cpu.incMem(hw, cpu.address("absx", 0x15A0u), cpu.m8?8:16);
    goto L_B1A379;
L_B1A379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA379u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA379u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A379 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A37C;
L_B1A37C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A37C XBA
    cpu.xba();
    goto L_B1A37D;
L_B1A37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A37D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A37F;
L_B1A37F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A37F REP
    cpu.rep(0x20u);
    goto L_B1A381;
L_B1A381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA381u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA381u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A381 SEC
    cpu.setFlag('C', true);
    goto L_B1A382;
L_B1A382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA382u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA382u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A382 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_B1A384;
L_B1A384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA384u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA384u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A384 CLC
    cpu.setFlag('C', false);
    goto L_B1A385;
L_B1A385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA385u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA385u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A385 ADC
    cpu.adc(0x40u);
    goto L_B1A388;
L_B1A388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA388u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA388u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A388 CMP
    cpu.compareA(0x180u);
    goto L_B1A38B;
L_B1A38B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A38B SEP
    cpu.sep(0x20u);
    goto L_B1A38D;
L_B1A38D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A38D ROL
    cpu.rolA();
    goto L_B1A38E;
L_B1A38E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A38E AND
    cpu.logicAnd(0x1u);
    goto L_B1A390;
L_B1A390:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA390u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA390u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA390u, 5u, 3u, cpu.address("absx", 0x15C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A390 STA
    hw.write(cpu.address("absx", 0x15C4u), cpu.a, cpu.m8?8:16);
    goto L_B1A393;
L_B1A393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA393u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA393u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A393 BNE -> $B1A3CB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A3CB; }
    goto L_B1A395;
L_B1A395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA395u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA395u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A395 LDY
    cpu.setY(0x0u, 8);
    goto L_B1A397;
L_B1A397:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA397u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA397u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA397u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A397 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A39A;
L_B1A39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A39A CMP
    cpu.compareA(0x9u);
    goto L_B1A39C;
L_B1A39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A39C BEQ -> $B1A3A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A3A6; }
    goto L_B1A39E;
L_B1A39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Eu, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A39E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3A1;
L_B1A3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A1 AND
    cpu.logicAnd(0x20u);
    goto L_B1A3A3;
L_B1A3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A3 BEQ -> $B1A3A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A3A6; }
    goto L_B1A3A5;
L_B1A3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A5 INY
    cpu.inc('Y');
    goto L_B1A3A6;
L_B1A3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3A8;
L_B1A3A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A8 CLC
    cpu.setFlag('C', false);
    goto L_B1A3A9;
L_B1A3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A9u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A9u, 4u + ((((0xA361u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA361u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A9 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xA361u), cpu.m8?8:16));
    goto L_B1A3AC;
L_B1A3AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ACu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ACu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3AC PHP
    cpu.push("PHP", hw);
    goto L_B1A3AD;
L_B1A3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3AD CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_B1A3AF;
L_B1A3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AFu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3AF ROL
    cpu.rolMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_B1A3B1;
L_B1A3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B1u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3B1 PLP
    cpu.pop("PLP", hw);
    goto L_B1A3B2;
L_B1A3B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3B2u,0xB1A3B2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B2u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3B2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3B5;
L_B1A3B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3B5 ADC
    cpu.adc(0x0u);
    goto L_B1A3B7;
L_B1A3B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3B7 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_B1A3B9;
L_B1A3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B9u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3B9 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Du), cpu.m8?8:16));
    goto L_B1A3BB;
L_B1A3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3BB BEQ -> $B1A3C6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A3C6; }
    goto L_B1A3BD;
L_B1A3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BDu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3BD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3C0;
L_B1A3C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u, 4u + ((((0xA363u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA363u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C0 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xA363u), cpu.m8?8:16));
    goto L_B1A3C3;
L_B1A3C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C3u, 5u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C3 STA
    hw.write(cpu.address("absx", 0x186Cu), cpu.a, cpu.m8?8:16);
    goto L_B1A3C6;
L_B1A3C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C6 DEY
    cpu.decReg('Y');
    goto L_B1A3C7;
L_B1A3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C7 BPL -> $B1A3A6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_B1A3A6; }
    goto L_B1A3C9;
L_B1A3C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C9 BRA -> $B1A3CD
    goto L_B1A3CD;
L_B1A3CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CBu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3CB PLA
    cpu.pop("PLA", hw);
    goto L_B1A3CC;
L_B1A3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3CC PLA
    cpu.pop("PLA", hw);
    goto L_B1A3CD;
L_B1A3CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CDu, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3CD LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A3D0;
L_B1A3D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3D2;
L_B1A3D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D2 SEC
    cpu.setFlag('C', true);
    goto L_B1A3D3;
L_B1A3D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D3u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D3 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_B1A3D5;
L_B1A3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_B1A3D7;
L_B1A3D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3D9;
L_B1A3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D9 SEC
    cpu.setFlag('C', true);
    goto L_B1A3DA;
L_B1A3DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DAu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3DA SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_B1A3DC;
L_B1A3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3DC STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_B1A3DE;
L_B1A3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A3DE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A3DEu);return;} hw.unresolvedReturn(0xB1A3DEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A365_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A365u: goto L_B1A365;
    case 0xB1A368u: goto L_B1A368;
    case 0xB1A36Bu: goto L_B1A36B;
    case 0xB1A36Du: goto L_B1A36D;
    case 0xB1A36Fu: goto L_B1A36F;
    case 0xB1A372u: goto L_B1A372;
    case 0xB1A374u: goto L_B1A374;
    case 0xB1A376u: goto L_B1A376;
    case 0xB1A379u: goto L_B1A379;
    case 0xB1A37Cu: goto L_B1A37C;
    case 0xB1A37Du: goto L_B1A37D;
    case 0xB1A37Fu: goto L_B1A37F;
    case 0xB1A381u: goto L_B1A381;
    case 0xB1A382u: goto L_B1A382;
    case 0xB1A384u: goto L_B1A384;
    case 0xB1A385u: goto L_B1A385;
    case 0xB1A388u: goto L_B1A388;
    case 0xB1A38Bu: goto L_B1A38B;
    case 0xB1A38Du: goto L_B1A38D;
    case 0xB1A38Eu: goto L_B1A38E;
    case 0xB1A390u: goto L_B1A390;
    case 0xB1A393u: goto L_B1A393;
    case 0xB1A395u: goto L_B1A395;
    case 0xB1A397u: goto L_B1A397;
    case 0xB1A39Au: goto L_B1A39A;
    case 0xB1A39Cu: goto L_B1A39C;
    case 0xB1A39Eu: goto L_B1A39E;
    case 0xB1A3A1u: goto L_B1A3A1;
    case 0xB1A3A3u: goto L_B1A3A3;
    case 0xB1A3A5u: goto L_B1A3A5;
    case 0xB1A3A6u: goto L_B1A3A6;
    case 0xB1A3A8u: goto L_B1A3A8;
    case 0xB1A3A9u: goto L_B1A3A9;
    case 0xB1A3ACu: goto L_B1A3AC;
    case 0xB1A3ADu: goto L_B1A3AD;
    case 0xB1A3AFu: goto L_B1A3AF;
    case 0xB1A3B1u: goto L_B1A3B1;
    case 0xB1A3B2u: goto L_B1A3B2;
    case 0xB1A3B5u: goto L_B1A3B5;
    case 0xB1A3B7u: goto L_B1A3B7;
    case 0xB1A3B9u: goto L_B1A3B9;
    case 0xB1A3BBu: goto L_B1A3BB;
    case 0xB1A3BDu: goto L_B1A3BD;
    case 0xB1A3C0u: goto L_B1A3C0;
    case 0xB1A3C3u: goto L_B1A3C3;
    case 0xB1A3C6u: goto L_B1A3C6;
    case 0xB1A3C7u: goto L_B1A3C7;
    case 0xB1A3C9u: goto L_B1A3C9;
    case 0xB1A3CBu: goto L_B1A3CB;
    case 0xB1A3CCu: goto L_B1A3CC;
    case 0xB1A3CDu: goto L_B1A3CD;
    case 0xB1A3D0u: goto L_B1A3D0;
    case 0xB1A3D2u: goto L_B1A3D2;
    case 0xB1A3D3u: goto L_B1A3D3;
    case 0xB1A3D5u: goto L_B1A3D5;
    case 0xB1A3D7u: goto L_B1A3D7;
    case 0xB1A3D9u: goto L_B1A3D9;
    case 0xB1A3DAu: goto L_B1A3DA;
    case 0xB1A3DCu: goto L_B1A3DC;
    case 0xB1A3DEu: goto L_B1A3DE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u, 5u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A365 STZ
    hw.write(cpu.address("absx", 0x186Cu), 0, cpu.m8?8:16);
    goto L_B1A368;
L_B1A368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u, 5u, 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A368 STZ
    hw.write(cpu.address("absx", 0x15A0u), 0, cpu.m8?8:16);
    goto L_B1A36B;
L_B1A36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A36B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A36D;
L_B1A36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A36D CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_B1A36F;
L_B1A36F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Fu, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A36F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A372;
L_B1A372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA372u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA372u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA372u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A372 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16));
    goto L_B1A374;
L_B1A374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA374u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA374u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A374 BEQ -> $B1A379
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A379; }
    goto L_B1A376;
L_B1A376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA376u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA376u, 7u, 3u, cpu.address("absx", 0x15A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A376 INC
    cpu.incMem(hw, cpu.address("absx", 0x15A0u), cpu.m8?8:16);
    goto L_B1A379;
L_B1A379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA379u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA379u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A379 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A37C;
L_B1A37C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A37C XBA
    cpu.xba();
    goto L_B1A37D;
L_B1A37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A37D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A37F;
L_B1A37F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A37F REP
    cpu.rep(0x20u);
    goto L_B1A381;
L_B1A381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA381u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA381u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A381 SEC
    cpu.setFlag('C', true);
    goto L_B1A382;
L_B1A382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA382u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA382u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A382 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_B1A384;
L_B1A384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA384u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA384u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A384 CLC
    cpu.setFlag('C', false);
    goto L_B1A385;
L_B1A385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA385u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA385u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A385 ADC
    cpu.adc(0x40u);
    goto L_B1A388;
L_B1A388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA388u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA388u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A388 CMP
    cpu.compareA(0x180u);
    goto L_B1A38B;
L_B1A38B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A38B SEP
    cpu.sep(0x20u);
    goto L_B1A38D;
L_B1A38D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A38D ROL
    cpu.rolA();
    goto L_B1A38E;
L_B1A38E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A38E AND
    cpu.logicAnd(0x1u);
    goto L_B1A390;
L_B1A390:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA390u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA390u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA390u, 5u, 3u, cpu.address("absx", 0x15C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A390 STA
    hw.write(cpu.address("absx", 0x15C4u), cpu.a, cpu.m8?8:16);
    goto L_B1A393;
L_B1A393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA393u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA393u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A393 BNE -> $B1A3CB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A3CB; }
    goto L_B1A395;
L_B1A395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA395u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA395u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A395 LDY
    cpu.setY(0x0u, 8);
    goto L_B1A397;
L_B1A397:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA397u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA397u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA397u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A397 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A39A;
L_B1A39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A39A CMP
    cpu.compareA(0x9u);
    goto L_B1A39C;
L_B1A39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A39C BEQ -> $B1A3A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A3A6; }
    goto L_B1A39E;
L_B1A39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Eu, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A39E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3A1;
L_B1A3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A1 AND
    cpu.logicAnd(0x20u);
    goto L_B1A3A3;
L_B1A3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A3 BEQ -> $B1A3A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A3A6; }
    goto L_B1A3A5;
L_B1A3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A5 INY
    cpu.inc('Y');
    goto L_B1A3A6;
L_B1A3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3A8;
L_B1A3A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A8 CLC
    cpu.setFlag('C', false);
    goto L_B1A3A9;
L_B1A3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A9u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A9u, 4u + ((((0xA361u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA361u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3A9 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xA361u), cpu.m8?8:16));
    goto L_B1A3AC;
L_B1A3AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ACu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ACu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3AC PHP
    cpu.push("PHP", hw);
    goto L_B1A3AD;
L_B1A3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3AD CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_B1A3AF;
L_B1A3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AFu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3AF ROL
    cpu.rolMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_B1A3B1;
L_B1A3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B1u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3B1 PLP
    cpu.pop("PLP", hw);
    goto L_B1A3B2;
L_B1A3B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3B2u,0xB1A3B2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B2u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3B2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3B5;
L_B1A3B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3B5 ADC
    cpu.adc(0x0u);
    goto L_B1A3B7;
L_B1A3B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3B7 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_B1A3B9;
L_B1A3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B9u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3B9 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Du), cpu.m8?8:16));
    goto L_B1A3BB;
L_B1A3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3BB BEQ -> $B1A3C6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A3C6; }
    goto L_B1A3BD;
L_B1A3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BDu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3BD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3C0;
L_B1A3C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u, 4u + ((((0xA363u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA363u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C0 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xA363u), cpu.m8?8:16));
    goto L_B1A3C3;
L_B1A3C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C3u, 5u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C3 STA
    hw.write(cpu.address("absx", 0x186Cu), cpu.a, cpu.m8?8:16);
    goto L_B1A3C6;
L_B1A3C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C6 DEY
    cpu.decReg('Y');
    goto L_B1A3C7;
L_B1A3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C7 BPL -> $B1A3A6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_B1A3A6; }
    goto L_B1A3C9;
L_B1A3C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3C9 BRA -> $B1A3CD
    goto L_B1A3CD;
L_B1A3CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CBu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3CB PLA
    cpu.pop("PLA", hw);
    goto L_B1A3CC;
L_B1A3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3CC PLA
    cpu.pop("PLA", hw);
    goto L_B1A3CD;
L_B1A3CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CDu, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3CD LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A3D0;
L_B1A3D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3D2;
L_B1A3D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D2 SEC
    cpu.setFlag('C', true);
    goto L_B1A3D3;
L_B1A3D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D3u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D3 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_B1A3D5;
L_B1A3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_B1A3D7;
L_B1A3D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3D9;
L_B1A3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3D9 SEC
    cpu.setFlag('C', true);
    goto L_B1A3DA;
L_B1A3DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DAu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3DA SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_B1A3DC;
L_B1A3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3DC STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_B1A3DE;
L_B1A3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A3DE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A3DEu);return;} hw.unresolvedReturn(0xB1A3DEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

