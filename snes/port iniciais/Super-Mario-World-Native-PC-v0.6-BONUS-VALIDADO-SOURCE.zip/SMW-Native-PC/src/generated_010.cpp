#include "generated.hpp"
void sub_009AA4_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0093F7u: goto L_0093F7;
    case 0x0093F9u: goto L_0093F9;
    case 0x0093FCu: goto L_0093FC;
    case 0x009AA4u: goto L_009AA4;
    case 0x009AA8u: goto L_009AA8;
    case 0x009AAAu: goto L_009AAA;
    case 0x009AADu: goto L_009AAD;
    case 0x009AAFu: goto L_009AAF;
    case 0x009AB1u: goto L_009AB1;
    case 0x009AB3u: goto L_009AB3;
    case 0x009AB5u: goto L_009AB5;
    case 0x009AB7u: goto L_009AB7;
    case 0x009AB9u: goto L_009AB9;
    case 0x009ABBu: goto L_009ABB;
    case 0x009ABDu: goto L_009ABD;
    case 0x009AC0u: goto L_009AC0;
    case 0x009AC2u: goto L_009AC2;
    case 0x009AC5u: goto L_009AC5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0093F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F7 LDA
    cpu.setA(0x81u, 8);
    goto L_0093F9;
L_0093F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F9 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0093FC;
L_0093FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0093FCu);return;} hw.unresolvedReturn(0x0093FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_009AA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA4u, 8u, 4u, 0x04F675u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $009AA4 JSL -> $04F675 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9AA7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9AA8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x04F675u, 0x009AA4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009AA8;
L_009AA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AA8u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AA8u,0x009AA8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009AA8 LDA
    cpu.setA(0x1u, 8);
    goto L_009AAA;
L_009AAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AAAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AAAu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009AAA STA
    hw.write(cpu.address("abs", 0xD9Bu), cpu.a, cpu.m8?8:16);
    goto L_009AAD;
L_009AAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AADu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009AAD LDA
    cpu.setA(0x33u, 8);
    goto L_009AAF;
L_009AAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AAFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AAFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009AAF STA
    hw.write(cpu.address("dp", 0x41u), cpu.a, cpu.m8?8:16);
    goto L_009AB1;
L_009AB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009AB1 LDA
    cpu.setA(0x0u, 8);
    goto L_009AB3;
L_009AB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009AB3 STA
    hw.write(cpu.address("dp", 0x42u), cpu.a, cpu.m8?8:16);
    goto L_009AB5;
L_009AB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009AB5 LDA
    cpu.setA(0x23u, 8);
    goto L_009AB7;
L_009AB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009AB7 STA
    hw.write(cpu.address("dp", 0x43u), cpu.a, cpu.m8?8:16);
    goto L_009AB9;
L_009AB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009AB9 LDA
    cpu.setA(0x12u, 8);
    goto L_009ABB;
L_009ABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009ABB STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_009ABD;
L_009ABD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABDu, 6u, 3u, cpu.address("abs", 0x9443u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009ABD JSR -> $009443 stack real
    { cpu.push16Value(hw,0x9ABFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9AC0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9443u), 0x009ABDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009AC0;
L_009AC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC0u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AC0u,0x009AC0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009AC0 LDA
    cpu.setA(0x10u, 8);
    goto L_009AC2;
L_009AC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC2u, 4u, 3u, cpu.address("abs", 0x1DF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009AC2 STA
    hw.write(cpu.address("abs", 0x1DF5u), cpu.a, cpu.m8?8:16);
    goto L_009AC5;
L_009AC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC5u, 3u, 3u, cpu.address("abs", 0x93F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009AC5 JMP -> $0093F7
    goto L_0093F7;
}

void sub_009DB5_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009DB5u: goto L_009DB5;
    case 0x009DB8u: goto L_009DB8;
    case 0x009DB9u: goto L_009DB9;
    case 0x009DBCu: goto L_009DBC;
    case 0x009DBEu: goto L_009DBE;
    case 0x009DBFu: goto L_009DBF;
    case 0x009DC0u: goto L_009DC0;
    case 0x009DC3u: goto L_009DC3;
    case 0x009DC4u: goto L_009DC4;
    case 0x009DC5u: goto L_009DC5;
    case 0x009DC6u: goto L_009DC6;
    case 0x009DCAu: goto L_009DCA;
    case 0x009DCCu: goto L_009DCC;
    case 0x009DCEu: goto L_009DCE;
    case 0x009DD1u: goto L_009DD1;
    case 0x009DD5u: goto L_009DD5;
    case 0x009DD6u: goto L_009DD6;
    case 0x009DD8u: goto L_009DD8;
    case 0x009DDAu: goto L_009DDA;
    case 0x009DDCu: goto L_009DDC;
    case 0x009DDEu: goto L_009DDE;
    case 0x009DDFu: goto L_009DDF;
    case 0x009DE0u: goto L_009DE0;
    case 0x009DE2u: goto L_009DE2;
    case 0x009DE4u: goto L_009DE4;
    case 0x009DE5u: goto L_009DE5;
    case 0x009DE6u: goto L_009DE6;
    case 0x009DE8u: goto L_009DE8;
    case 0x009DEBu: goto L_009DEB;
    case 0x009DEDu: goto L_009DED;
    case 0x009DF0u: goto L_009DF0;
    case 0x009DF2u: goto L_009DF2;
    case 0x009DF3u: goto L_009DF3;
    case 0x009DF4u: goto L_009DF4;
    case 0x009DF5u: goto L_009DF5;
    case 0x009DF7u: goto L_009DF7;
    case 0x009DF9u: goto L_009DF9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009DB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB5u, 4u + ((((0x9CCBu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9CCBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DB5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9CCBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009DB8;
L_009DB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB8u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DB8 XBA
    cpu.xba();
    goto L_009DB9;
L_009DB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB9u, 4u + ((((0x9CCEu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9CCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DB9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9CCEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009DBC;
L_009DBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DBC REP
    cpu.rep(0x30u);
    goto L_009DBE;
L_009DBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBEu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DBE TAX
    cpu.transfer("TAX");
    goto L_009DBF;
L_009DBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DBF CLC
    cpu.setFlag('C', false);
    goto L_009DC0;
L_009DC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DC0 ADC
    cpu.adc(0x1ADu);
    goto L_009DC3;
L_009DC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DC3 TAY
    cpu.transfer("TAY");
    goto L_009DC4;
L_009DC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC4u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009DC4 PHX
    cpu.push("PHX", hw);
    goto L_009DC5;
L_009DC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC5u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009DC5 PHY
    cpu.push("PHY", hw);
    goto L_009DC6;
L_009DC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC6u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC6u, 6u, 4u, ((0x70008Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DC6 LDA
    cpu.loadA(hw.readW(((0x70008Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009DCA;
L_009DCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DCA STA
    hw.write(cpu.address("dp", 0x8Au), cpu.a, cpu.m8?8:16);
    goto L_009DCC;
L_009DCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DCC SEP
    cpu.sep(0x20u);
    goto L_009DCE;
L_009DCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DCE LDY
    cpu.setY(0x8Du, 16);
    goto L_009DD1;
L_009DD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD1u, 5u, 4u, ((0x700000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DD1 LDA
    cpu.loadA(hw.readW(((0x700000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009DD5;
L_009DD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DD5 CLC
    cpu.setFlag('C', false);
    goto L_009DD6;
L_009DD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD6u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DD6 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16));
    goto L_009DD8;
L_009DD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DD8 STA
    hw.write(cpu.address("dp", 0x8Au), cpu.a, cpu.m8?8:16);
    goto L_009DDA;
L_009DDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DDA BCC -> $009DDE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_009DDE; }
    goto L_009DDC;
L_009DDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DDC INC
    cpu.incMem(hw, cpu.address("dp", 0x8Bu), cpu.m8?8:16);
    goto L_009DDE;
L_009DDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DDE INX
    cpu.inc('X');
    goto L_009DDF;
L_009DDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDFu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DDF DEY
    cpu.decReg('Y');
    goto L_009DE0;
L_009DE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DE0 BNE -> $009DD1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009DD1; }
    goto L_009DE2;
L_009DE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DE2 REP
    cpu.rep(0x20u);
    goto L_009DE4;
L_009DE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE4u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE4u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009DE4 PLY
    cpu.pop("PLY", hw);
    goto L_009DE5;
L_009DE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE5u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE5u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009DE5 PLX
    cpu.pop("PLX", hw);
    goto L_009DE6;
L_009DE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DE6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009DE8;
L_009DE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DE8 CMP
    cpu.compareA(0x5A5Au);
    goto L_009DEB;
L_009DEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DEB BEQ -> $009DF7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_009DF7; }
    goto L_009DED;
L_009DED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DED CPX
    cpu.compareX(0x1ACu);
    goto L_009DF0;
L_009DF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DF0 BCS -> $009DF7
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_009DF7; }
    goto L_009DF2;
L_009DF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF2u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009DF2 PHX
    cpu.push("PHX", hw);
    goto L_009DF3;
L_009DF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF3u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DF3 TYX
    cpu.transfer("TYX");
    goto L_009DF4;
L_009DF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF4u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF4u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009DF4 PLY
    cpu.pop("PLY", hw);
    goto L_009DF5;
L_009DF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DF5 BRA -> $009DC4
    goto L_009DC4;
L_009DF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DF7 SEP
    cpu.sep(0x20u);
    goto L_009DF9;
L_009DF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009DF9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009DF9u);return;} hw.unresolvedReturn(0x009DF9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CC14_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CC14u: goto L_00CC14;
    case 0x00CC15u: goto L_00CC15;
    case 0x00CC17u: goto L_00CC17;
    case 0x00CC1Au: goto L_00CC1A;
    case 0x00CC1Du: goto L_00CC1D;
    case 0x00CC20u: goto L_00CC20;
    case 0x00CC23u: goto L_00CC23;
    case 0x00CC24u: goto L_00CC24;
    case 0x00CC25u: goto L_00CC25;
    case 0x00CC26u: goto L_00CC26;
    case 0x00CC27u: goto L_00CC27;
    case 0x00CC28u: goto L_00CC28;
    case 0x00CC29u: goto L_00CC29;
    case 0x00CC2Bu: goto L_00CC2B;
    case 0x00CC2Eu: goto L_00CC2E;
    case 0x00CC2Fu: goto L_00CC2F;
    case 0x00CC30u: goto L_00CC30;
    case 0x00CC32u: goto L_00CC32;
    case 0x00CC34u: goto L_00CC34;
    case 0x00CC37u: goto L_00CC37;
    case 0x00CC3Au: goto L_00CC3A;
    case 0x00CC3Du: goto L_00CC3D;
    case 0x00CC3Eu: goto L_00CC3E;
    case 0x00CC3Fu: goto L_00CC3F;
    case 0x00CC40u: goto L_00CC40;
    case 0x00CC41u: goto L_00CC41;
    case 0x00CC44u: goto L_00CC44;
    case 0x00CC46u: goto L_00CC46;
    case 0x00CC48u: goto L_00CC48;
    case 0x00CC4Bu: goto L_00CC4B;
    case 0x00CC4Eu: goto L_00CC4E;
    case 0x00CC51u: goto L_00CC51;
    case 0x00CC52u: goto L_00CC52;
    case 0x00CC53u: goto L_00CC53;
    case 0x00CC54u: goto L_00CC54;
    case 0x00CC55u: goto L_00CC55;
    case 0x00CC58u: goto L_00CC58;
    case 0x00CC5Au: goto L_00CC5A;
    case 0x00CC5Bu: goto L_00CC5B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC14u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC14u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CC14 PHY
    cpu.push("PHY", hw);
    goto L_00CC15;
L_00CC15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC15u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC15 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC17;
L_00CC17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC17u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC17u, 4u, 3u, cpu.address("abs", 0x4205u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC17 STA
    hw.write(cpu.address("abs", 0x4205u), cpu.a, cpu.m8?8:16);
    goto L_00CC1A;
L_00CC1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC1Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC1Au, 4u, 3u, cpu.address("abs", 0x4204u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC1A STZ
    hw.write(cpu.address("abs", 0x4204u), 0, cpu.m8?8:16);
    goto L_00CC1D;
L_00CC1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC1Du, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1433u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC20;
L_00CC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC20u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC20u, 4u, 3u, cpu.address("abs", 0x4206u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC20 STA
    hw.write(cpu.address("abs", 0x4206u), cpu.a, cpu.m8?8:16);
    goto L_00CC23;
L_00CC23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC23u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC23 NOP
    ;
    goto L_00CC24;
L_00CC24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC24u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC24 NOP
    ;
    goto L_00CC25;
L_00CC25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC25u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC25 NOP
    ;
    goto L_00CC26;
L_00CC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC26u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC26 NOP
    ;
    goto L_00CC27;
L_00CC27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC27u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC27u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC27 NOP
    ;
    goto L_00CC28;
L_00CC28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC28u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC28u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC28 NOP
    ;
    goto L_00CC29;
L_00CC29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC29u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC29u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC29 REP
    cpu.rep(0x20u);
    goto L_00CC2B;
L_00CC2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC2Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC2Bu, 5u, 3u, cpu.address("abs", 0x4214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC2B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4214u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC2E;
L_00CC2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC2Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC2E LSR
    cpu.lsrA();
    goto L_00CC2F;
L_00CC2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC2Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC2F TAY
    cpu.transfer("TAY");
    goto L_00CC30;
L_00CC30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC30u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC30u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC30 SEP
    cpu.sep(0x20u);
    goto L_00CC32;
L_00CC32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC32u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC32u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x06u) & 0xFFFFu), 2u, 0u);
    // $00CC32 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC34;
L_00CC34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC34u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC34u, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC34 STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_00CC37;
L_00CC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC37u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC37u, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC37 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1433u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC3A;
L_00CC3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Au, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC3A STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_00CC3D;
L_00CC3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Du,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC3D NOP
    ;
    goto L_00CC3E;
L_00CC3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Eu,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC3E NOP
    ;
    goto L_00CC3F;
L_00CC3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Fu,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC3F NOP
    ;
    goto L_00CC40;
L_00CC40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC40u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC40 NOP
    ;
    goto L_00CC41;
L_00CC41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC41u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC41u, 4u, 3u, cpu.address("abs", 0x4217u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC41 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4217u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC44;
L_00CC44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC44u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC44u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC44 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_00CC46;
L_00CC46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC46u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC46u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 2u, 0u);
    // $00CC46 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC48;
L_00CC48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC48u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC48u, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC48 STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_00CC4B;
L_00CC4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC4Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC4Bu, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC4B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1433u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC4E;
L_00CC4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC4Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC4Eu, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC4E STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_00CC51;
L_00CC51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC51u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC51 NOP
    ;
    goto L_00CC52;
L_00CC52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC52u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC52 NOP
    ;
    goto L_00CC53;
L_00CC53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC53u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC53 NOP
    ;
    goto L_00CC54;
L_00CC54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC54u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC54 NOP
    ;
    goto L_00CC55;
L_00CC55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC55u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC55u, 4u, 3u, cpu.address("abs", 0x4217u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC55 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4217u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC58;
L_00CC58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC58u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC58 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_00CC5A;
L_00CC5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC5Au,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC5Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CC5A PLY
    cpu.pop("PLY", hw);
    goto L_00CC5B;
L_00CC5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC5Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC5Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CC5B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CC5Bu);return;} hw.unresolvedReturn(0x00CC5Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00EADB_E0M1X1CQ_part17(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EEE9u: goto L_00EEE9;
    case 0x00EEEBu: goto L_00EEEB;
    case 0x00EEEDu: goto L_00EEED;
    case 0x00EEEFu: goto L_00EEEF;
    case 0x00EEF2u: goto L_00EEF2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE9u))return;
  // 28 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEE9u); return; }
    goto L_00EEEB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEE9u); return; }
    goto L_00EEEB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEE9u); return; }
    goto L_00EEEB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEE9u); return; }
    goto L_00EEEB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEE9u); return; }
    goto L_00EEEB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE9u,0x00EEE9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEBu))return;
  // 28 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEBu,0x00EEEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEDu))return;
  // 28 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEDu,0x00EEEDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEFu))return;
  // 28 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 5u, 3u, cpu.address("abs", 0x13EEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 5u, 3u, cpu.address("abs", 0x13EEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEFu,0x00EEEFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF2u))return;
  // 28 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF4u,0x00EEF2u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF4u,0x00EEF2u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF4u,0x00EEF2u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF4u,0x00EEF2u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF4u,0x00EEF2u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF2u,0x00EEF2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1C1_part25(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF54u: goto L_00EF54;
    case 0x00EF55u: goto L_00EF55;
    case 0x00EF56u: goto L_00EF56;
    case 0x00EF58u: goto L_00EF58;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF54u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF54 INC
    cpu.inc('A');
    goto L_00EF55;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF54 INC
    cpu.inc('A');
    goto L_00EF55;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF54 INC
    cpu.inc('A');
    goto L_00EF55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF54u,0x00EF54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF55u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF55 CLC
    cpu.setFlag('C', false);
    goto L_00EF56;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF55 CLC
    cpu.setFlag('C', false);
    goto L_00EF56;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF55 CLC
    cpu.setFlag('C', false);
    goto L_00EF56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF55u,0x00EF55u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF56u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF56 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_00EF58;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF56 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_00EF58;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF56 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_00EF58;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF56u,0x00EF56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF58u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF58 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF5Au,0x00EF58u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF58 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF5Au,0x00EF58u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF58 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF5Au,0x00EF58u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF58u,0x00EF58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part25(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF54u: goto L_00EF54;
    case 0x00EF55u: goto L_00EF55;
    case 0x00EF56u: goto L_00EF56;
    case 0x00EF58u: goto L_00EF58;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF54u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF54 INC
    cpu.inc('A');
    goto L_00EF55;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF54 INC
    cpu.inc('A');
    goto L_00EF55;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF54 INC
    cpu.inc('A');
    goto L_00EF55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF54u,0x00EF54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF55u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF55 CLC
    cpu.setFlag('C', false);
    goto L_00EF56;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF55 CLC
    cpu.setFlag('C', false);
    goto L_00EF56;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF55 CLC
    cpu.setFlag('C', false);
    goto L_00EF56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF55u,0x00EF55u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF56u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF56 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_00EF58;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF56 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_00EF58;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF56 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_00EF58;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF56u,0x00EF56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF58u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF58 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF5Au,0x00EF58u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF58 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF5Au,0x00EF58u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF58 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF5Au,0x00EF58u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF58u,0x00EF58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E1M1X1CQ_part28(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF6Fu: goto L_00EF6F;
    case 0x00EF72u: goto L_00EF72;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF6Fu))return;
  // 57 variantes de decodificacao M/X para este endereco; 8 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu, 5u, 3u, cpu.address("abs", 0x1406u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6F STZ
    hw.write(cpu.address("abs", 0x1406u), 0, cpu.m8?8:16);
    goto L_00EF72;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu, 5u, 3u, cpu.address("abs", 0x1406u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6F STZ
    hw.write(cpu.address("abs", 0x1406u), 0, cpu.m8?8:16);
    goto L_00EF72;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu, 4u, 3u, cpu.address("abs", 0x1406u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6F STZ
    hw.write(cpu.address("abs", 0x1406u), 0, cpu.m8?8:16);
    goto L_00EF72;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu, 4u, 3u, cpu.address("abs", 0x1406u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6F STZ
    hw.write(cpu.address("abs", 0x1406u), 0, cpu.m8?8:16);
    goto L_00EF72;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu, 5u, 3u, cpu.address("abs", 0x1406u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6F STZ
    hw.write(cpu.address("abs", 0x1406u), 0, cpu.m8?8:16);
    goto L_00EF72;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu, 5u, 3u, cpu.address("abs", 0x1406u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6F STZ
    hw.write(cpu.address("abs", 0x1406u), 0, cpu.m8?8:16);
    goto L_00EF72;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu, 4u, 3u, cpu.address("abs", 0x1406u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6F STZ
    hw.write(cpu.address("abs", 0x1406u), 0, cpu.m8?8:16);
    goto L_00EF72;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu, 4u, 3u, cpu.address("abs", 0x1406u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6F STZ
    hw.write(cpu.address("abs", 0x1406u), 0, cpu.m8?8:16);
    goto L_00EF72;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,0x00EF6Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF72u))return;
  // 57 variantes de decodificacao M/X para este endereco; 8 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u, 5u, 3u, cpu.address("abs", 0x140Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF72 STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF75u,0x00EF72u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u, 5u, 3u, cpu.address("abs", 0x140Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF72 STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF75u,0x00EF72u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF72 STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF75u,0x00EF72u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF72 STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF75u,0x00EF72u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u, 5u, 3u, cpu.address("abs", 0x140Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF72 STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF75u,0x00EF72u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u, 5u, 3u, cpu.address("abs", 0x140Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF72 STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF75u,0x00EF72u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF72 STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF75u,0x00EF72u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF72 STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF75u,0x00EF72u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF72u,0x00EF72u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00F606_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F606u: goto L_00F606;
    case 0x00F608u: goto L_00F608;
    case 0x00F60Au: goto L_00F60A;
    case 0x00F60Cu: goto L_00F60C;
    case 0x00F60Fu: goto L_00F60F;
    case 0x00F611u: goto L_00F611;
    case 0x00F614u: goto L_00F614;
    case 0x00F616u: goto L_00F616;
    case 0x00F618u: goto L_00F618;
    case 0x00F61Bu: goto L_00F61B;
    case 0x00F61Du: goto L_00F61D;
    case 0x00F620u: goto L_00F620;
    case 0x00F622u: goto L_00F622;
    case 0x00F625u: goto L_00F625;
    case 0x00F628u: goto L_00F628;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF606u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF606u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F606 LDA
    cpu.setA(0x90u, 8);
    goto L_00F608;
L_00F608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF608u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF608u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F608 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00F60A;
L_00F60A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF60Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF60Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF60Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F60A LDA
    cpu.setA(0x9u, 8);
    goto L_00F60C;
L_00F60C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF60Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF60Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF60Cu, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F60C STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_00F60F;
L_00F60F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF60Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF60Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF60Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F60F LDA
    cpu.setA(0xFFu, 8);
    goto L_00F611;
L_00F611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF611u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF611u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F611 STA
    hw.write(cpu.address("abs", 0xDDAu), cpu.a, cpu.m8?8:16);
    goto L_00F614;
L_00F614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF614u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF614u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F614 LDA
    cpu.setA(0x9u, 8);
    goto L_00F616;
L_00F616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF616u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF616u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F616 STA
    hw.write(cpu.address("dp", 0x71u), cpu.a, cpu.m8?8:16);
    goto L_00F618;
L_00F618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF618u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF618u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F618 STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    goto L_00F61B;
L_00F61B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF61Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF61Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF61Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F61B LDA
    cpu.setA(0x30u, 8);
    goto L_00F61D;
L_00F61D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF61Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF61Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF61Du, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F61D STA
    hw.write(cpu.address("abs", 0x1496u), cpu.a, cpu.m8?8:16);
    goto L_00F620;
L_00F620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF620u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF620u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F620 STA
    hw.write(cpu.address("dp", 0x9Du), cpu.a, cpu.m8?8:16);
    goto L_00F622;
L_00F622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF622u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF622u, 4u, 3u, cpu.address("abs", 0x1407u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F622 STZ
    hw.write(cpu.address("abs", 0x1407u), 0, cpu.m8?8:16);
    goto L_00F625;
L_00F625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF625u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF625u, 4u, 3u, cpu.address("abs", 0x188Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F625 STZ
    hw.write(cpu.address("abs", 0x188Au), 0, cpu.m8?8:16);
    goto L_00F628;
L_00F628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF628u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF628u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF628u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F628 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00F628u);return;} hw.unresolvedReturn(0x00F628u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_01808C_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01808Cu: goto L_01808C;
    case 0x01808Du: goto L_01808D;
    case 0x01808Eu: goto L_01808E;
    case 0x01808Fu: goto L_01808F;
    case 0x018092u: goto L_018092;
    case 0x018095u: goto L_018095;
    case 0x018098u: goto L_018098;
    case 0x01809Bu: goto L_01809B;
    case 0x01809Eu: goto L_01809E;
    case 0x0180A1u: goto L_0180A1;
    case 0x0180A4u: goto L_0180A4;
    case 0x0180A7u: goto L_0180A7;
    case 0x0180A9u: goto L_0180A9;
    case 0x0180ACu: goto L_0180AC;
    case 0x0180AFu: goto L_0180AF;
    case 0x0180B2u: goto L_0180B2;
    case 0x0180B3u: goto L_0180B3;
    case 0x0180B5u: goto L_0180B5;
    case 0x0180B8u: goto L_0180B8;
    case 0x0180BAu: goto L_0180BA;
    case 0x0180BEu: goto L_0180BE;
    case 0x0180C1u: goto L_0180C1;
    case 0x0180C3u: goto L_0180C3;
    case 0x0180C6u: goto L_0180C6;
    case 0x0180C9u: goto L_0180C9;
    case 0x0180CAu: goto L_0180CA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01808C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01808C PHB
    cpu.push("PHB", hw);
    goto L_01808D;
L_01808D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01808D PHK
    cpu.push("PHK", hw);
    goto L_01808E;
L_01808E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01808E PLB
    cpu.pop("PLB", hw);
    goto L_01808F;
L_01808F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Fu, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01808F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018092;
L_018092:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8092u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8092u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8092u, 4u, 3u, cpu.address("abs", 0x1470u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018092 STA
    hw.write(cpu.address("abs", 0x1470u), cpu.a, cpu.m8?8:16);
    goto L_018095;
L_018095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018095 STZ
    hw.write(cpu.address("abs", 0x148Fu), 0, cpu.m8?8:16);
    goto L_018098;
L_018098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8098u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8098u, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018098 STZ
    hw.write(cpu.address("abs", 0x1471u), 0, cpu.m8?8:16);
    goto L_01809B;
L_01809B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Bu, 4u, 3u, cpu.address("abs", 0x18C2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01809B STZ
    hw.write(cpu.address("abs", 0x18C2u), 0, cpu.m8?8:16);
    goto L_01809E;
L_01809E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Eu, 4u, 3u, cpu.address("abs", 0x18DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01809E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18DFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180A1;
L_0180A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u, 4u, 3u, cpu.address("abs", 0x18E2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180A1 STA
    hw.write(cpu.address("abs", 0x18E2u), cpu.a, cpu.m8?8:16);
    goto L_0180A4;
L_0180A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A4u, 4u, 3u, cpu.address("abs", 0x18DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180A4 STZ
    hw.write(cpu.address("abs", 0x18DFu), 0, cpu.m8?8:16);
    goto L_0180A7;
L_0180A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180A7 LDX
    cpu.setX(0xBu, 8);
    goto L_0180A9;
L_0180A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A9u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A9u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180A9 STX
    hw.write(cpu.address("abs", 0x15E9u), cpu.x, cpu.x8?8:16);
    goto L_0180AC;
L_0180AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ACu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ACu, 6u, 3u, cpu.address("abs", 0x80D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0180AC JSR -> $0180D2 stack real
    { cpu.push16Value(hw,0x80AEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80D2u), 0x0180ACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0180AF;
L_0180AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AFu,0x0180AFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AFu, 6u, 3u, cpu.address("abs", 0x8127u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0180AF JSR -> $018127 stack real
    { cpu.push16Value(hw,0x80B1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80B2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8127u), 0x0180AFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0180B2;
L_0180B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80B2u,0x0180B2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180B2 DEX
    cpu.decReg('X');
    goto L_0180B3;
L_0180B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B3u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180B3 BPL -> $0180A9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0180A9; }
    goto L_0180B5;
L_0180B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B5u, 4u, 3u, cpu.address("abs", 0x18B8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180B5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18B8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180B8;
L_0180B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180B8 BEQ -> $0180BE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0180BE; }
    goto L_0180BA;
L_0180BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BAu, 8u, 4u, 0x02F808u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0180BA JSL -> $02F808 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80BDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80BEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02F808u, 0x0180BAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0180BE;
L_0180BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80BEu,0x0180BEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BEu, 4u, 3u, cpu.address("abs", 0x18DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180BE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18DFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180C1;
L_0180C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180C1 BNE -> $0180C9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0180C9; }
    goto L_0180C3;
L_0180C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180C3 STZ
    hw.write(cpu.address("abs", 0x187Au), 0, cpu.m8?8:16);
    goto L_0180C6;
L_0180C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C6u, 4u, 3u, cpu.address("abs", 0x188Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180C6 STZ
    hw.write(cpu.address("abs", 0x188Bu), 0, cpu.m8?8:16);
    goto L_0180C9;
L_0180C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0180C9 PLB
    cpu.pop("PLB", hw);
    goto L_0180CA;
L_0180CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0180CA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x0180CAu);return;} hw.unresolvedReturn(0x0180CAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_01E393_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01E393u: goto L_01E393;
    case 0x01E396u: goto L_01E396;
    case 0x01E399u: goto L_01E399;
    case 0x01E39Bu: goto L_01E39B;
    case 0x01E39Eu: goto L_01E39E;
    case 0x01E3A1u: goto L_01E3A1;
    case 0x01E3A5u: goto L_01E3A5;
    case 0x01E3A7u: goto L_01E3A7;
    case 0x01E3A9u: goto L_01E3A9;
    case 0x01E3ACu: goto L_01E3AC;
    case 0x01E3AEu: goto L_01E3AE;
    case 0x01E3B1u: goto L_01E3B1;
    case 0x01E3B3u: goto L_01E3B3;
    case 0x01E3B4u: goto L_01E3B4;
    case 0x01E3B7u: goto L_01E3B7;
    case 0x01E3B9u: goto L_01E3B9;
    case 0x01E3BAu: goto L_01E3BA;
    case 0x01E3BBu: goto L_01E3BB;
    case 0x01E3BCu: goto L_01E3BC;
    case 0x01E3BEu: goto L_01E3BE;
    case 0x01E3C0u: goto L_01E3C0;
    case 0x01E3C3u: goto L_01E3C3;
    case 0x01E3C6u: goto L_01E3C6;
    case 0x01E3C7u: goto L_01E3C7;
    case 0x01E3CAu: goto L_01E3CA;
    case 0x01E3CCu: goto L_01E3CC;
    case 0x01E3CFu: goto L_01E3CF;
    case 0x01E3D2u: goto L_01E3D2;
    case 0x01E3D5u: goto L_01E3D5;
    case 0x01E3D8u: goto L_01E3D8;
    case 0x01E3DAu: goto L_01E3DA;
    case 0x01E3DDu: goto L_01E3DD;
    case 0x01E3DFu: goto L_01E3DF;
    case 0x01E3E1u: goto L_01E3E1;
    case 0x01E3E4u: goto L_01E3E4;
    case 0x01E3E6u: goto L_01E3E6;
    case 0x01E3E8u: goto L_01E3E8;
    case 0x01E3E9u: goto L_01E3E9;
    case 0x01E3EBu: goto L_01E3EB;
    case 0x01E3EEu: goto L_01E3EE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01E393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE393u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE393u, 6u, 3u, cpu.address("abs", 0xE3EFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E393 JSR -> $01E3EF stack real
    { cpu.push16Value(hw,0xE395u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE396u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE3EFu), 0x01E393u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E396;
L_01E396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE396u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE396u,0x01E396u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE396u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE396u, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E396 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E399;
L_01E399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE399u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE399u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E399 BNE -> $01E3C7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E3C7; }
    goto L_01E39B;
L_01E39B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE39Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Bu, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E39B JSR -> $018E5F stack real
    { cpu.push16Value(hw,0xE39Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE39Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x01E39Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E39E;
L_01E39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE39Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE39Eu,0x01E39Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Eu, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E39E JSR -> $018E5F stack real
    { cpu.push16Value(hw,0xE3A0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3A1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x01E39Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3A1;
L_01E3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3A1u,0x01E3A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A1u, 8u, 4u, 0x01ACF9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01E3A1 JSL -> $01ACF9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE3A4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3A5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01ACF9u, 0x01E3A1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3A5;
L_01E3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3A5u,0x01E3A5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3A5 AND
    cpu.logicAnd(0x1u);
    goto L_01E3A7;
L_01E3A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3A7 BNE -> $01E3C6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E3C6; }
    goto L_01E3A9;
L_01E3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A9u, 6u, 3u, cpu.address("abs", 0x857Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3A9 JSR -> $01857C stack real
    { cpu.push16Value(hw,0xE3ABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3ACu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x857Cu), 0x01E3A9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3AC;
L_01E3AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3ACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3ACu,0x01E3ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ACu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3AC LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E3AE;
L_01E3AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3AEu,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3AEu, 4u + ((((0xE391u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE391u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3AE CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE391u), cpu.m8?8:16));
    goto L_01E3B1;
L_01E3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3B1 BEQ -> $01E3C6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E3C6; }
    goto L_01E3B3;
L_01E3B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3B3 CLC
    cpu.setFlag('C', false);
    goto L_01E3B4;
L_01E3B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B4u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B4u, 4u + ((((0xEBB4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEBB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3B4 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xEBB4u), cpu.m8?8:16));
    goto L_01E3B7;
L_01E3B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3B7 STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_01E3B9;
L_01E3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B9u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3B9 TYA
    cpu.transfer("TYA");
    goto L_01E3BA;
L_01E3BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3BA LSR
    cpu.lsrA();
    goto L_01E3BB;
L_01E3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BBu,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3BB ROR
    cpu.rorA();
    goto L_01E3BC;
L_01E3BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BCu,cpu,0x55u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3BC EOR
    cpu.logicXor(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16));
    goto L_01E3BE;
L_01E3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3BE BPL -> $01E3C6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01E3C6; }
    goto L_01E3C0;
L_01E3C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C0u, 6u, 3u, cpu.address("abs", 0x804Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3C0 JSR -> $01804E stack real
    { cpu.push16Value(hw,0xE3C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3C3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x804Eu), 0x01E3C0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3C3;
L_01E3C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3C3u,0x01E3C3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C3u, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3C3 JSR -> $018E5F stack real
    { cpu.push16Value(hw,0xE3C5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3C6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x01E3C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3C6;
L_01E3C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3C6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01E3C6u);return;} hw.unresolvedReturn(0x01E3C6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3C6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01E3C6u);return;} hw.unresolvedReturn(0x01E3C6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3C6u,0x01E3C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01E3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C7u, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3C7 JSR -> $01800E stack real
    { cpu.push16Value(hw,0xE3C9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3CAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0x01E3C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3CA;
L_01E3CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3CAu,0x01E3CAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3CA BEQ -> $01E3E9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E3E9; }
    goto L_01E3CC;
L_01E3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CCu, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3CC JSR -> $018E5F stack real
    { cpu.push16Value(hw,0xE3CEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3CFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x01E3CCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3CF;
L_01E3CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3CFu,0x01E3CFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CFu, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3CF JSR -> $018E5F stack real
    { cpu.push16Value(hw,0xE3D1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3D2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x01E3CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3D2;
L_01E3D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3D2u,0x01E3D2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D2u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D2u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3D2 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x157Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01E3D5;
L_01E3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D5u, 4u + ((((0xE38Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE38Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3D5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE38Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E3D8;
L_01E3D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D8u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3D8 STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_01E3DA;
L_01E3DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DAu, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3DA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E3DD;
L_01E3DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3DD BNE -> $01E3E8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E3E8; }
    goto L_01E3DF;
L_01E3DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3DF LDA
    cpu.setA(0x50u, 8);
    goto L_01E3E1;
L_01E3E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E1u, 5u, 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3E1 STA
    hw.write(cpu.address("absx", 0x1558u), cpu.a, cpu.m8?8:16);
    goto L_01E3E4;
L_01E3E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3E4 LDA
    cpu.setA(0xD8u, 8);
    goto L_01E3E6;
L_01E3E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E6u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3E6 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_01E3E8;
L_01E3E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3E8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01E3E8u);return;} hw.unresolvedReturn(0x01E3E8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01E3E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3E9 LDA
    cpu.setA(0x1u, 8);
    goto L_01E3EB;
L_01E3EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EBu, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3EB STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_01E3EE;
L_01E3EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3EE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01E3EEu);return;} hw.unresolvedReturn(0x01E3EEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01E393_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01E393u: goto L_01E393;
    case 0x01E396u: goto L_01E396;
    case 0x01E399u: goto L_01E399;
    case 0x01E39Bu: goto L_01E39B;
    case 0x01E39Eu: goto L_01E39E;
    case 0x01E3A1u: goto L_01E3A1;
    case 0x01E3A5u: goto L_01E3A5;
    case 0x01E3A7u: goto L_01E3A7;
    case 0x01E3A9u: goto L_01E3A9;
    case 0x01E3ACu: goto L_01E3AC;
    case 0x01E3AEu: goto L_01E3AE;
    case 0x01E3B1u: goto L_01E3B1;
    case 0x01E3B3u: goto L_01E3B3;
    case 0x01E3B4u: goto L_01E3B4;
    case 0x01E3B7u: goto L_01E3B7;
    case 0x01E3B9u: goto L_01E3B9;
    case 0x01E3BAu: goto L_01E3BA;
    case 0x01E3BBu: goto L_01E3BB;
    case 0x01E3BCu: goto L_01E3BC;
    case 0x01E3BEu: goto L_01E3BE;
    case 0x01E3C0u: goto L_01E3C0;
    case 0x01E3C3u: goto L_01E3C3;
    case 0x01E3C6u: goto L_01E3C6;
    case 0x01E3C7u: goto L_01E3C7;
    case 0x01E3CAu: goto L_01E3CA;
    case 0x01E3CCu: goto L_01E3CC;
    case 0x01E3CFu: goto L_01E3CF;
    case 0x01E3D2u: goto L_01E3D2;
    case 0x01E3D5u: goto L_01E3D5;
    case 0x01E3D8u: goto L_01E3D8;
    case 0x01E3DAu: goto L_01E3DA;
    case 0x01E3DDu: goto L_01E3DD;
    case 0x01E3DFu: goto L_01E3DF;
    case 0x01E3E1u: goto L_01E3E1;
    case 0x01E3E4u: goto L_01E3E4;
    case 0x01E3E6u: goto L_01E3E6;
    case 0x01E3E8u: goto L_01E3E8;
    case 0x01E3E9u: goto L_01E3E9;
    case 0x01E3EBu: goto L_01E3EB;
    case 0x01E3EEu: goto L_01E3EE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01E393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE393u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE393u, 6u, 3u, cpu.address("abs", 0xE3EFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E393 JSR -> $01E3EF stack real
    { cpu.push16Value(hw,0xE395u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE396u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE3EFu), 0x01E393u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E396;
L_01E396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE396u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE396u,0x01E396u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE396u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE396u, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E396 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E399;
L_01E399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE399u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE399u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E399 BNE -> $01E3C7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E3C7; }
    goto L_01E39B;
L_01E39B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE39Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Bu, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E39B JSR -> $018E5F stack real
    { cpu.push16Value(hw,0xE39Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE39Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x01E39Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E39E;
L_01E39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE39Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE39Eu,0x01E39Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Eu, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E39E JSR -> $018E5F stack real
    { cpu.push16Value(hw,0xE3A0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3A1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x01E39Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3A1;
L_01E3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3A1u,0x01E3A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A1u, 8u, 4u, 0x01ACF9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01E3A1 JSL -> $01ACF9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE3A4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3A5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01ACF9u, 0x01E3A1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3A5;
L_01E3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3A5u,0x01E3A5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3A5 AND
    cpu.logicAnd(0x1u);
    goto L_01E3A7;
L_01E3A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3A7 BNE -> $01E3C6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E3C6; }
    goto L_01E3A9;
L_01E3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A9u, 6u, 3u, cpu.address("abs", 0x857Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3A9 JSR -> $01857C stack real
    { cpu.push16Value(hw,0xE3ABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3ACu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x857Cu), 0x01E3A9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3AC;
L_01E3AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3ACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3ACu,0x01E3ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ACu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3AC LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E3AE;
L_01E3AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3AEu,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3AEu, 4u + ((((0xE391u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE391u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3AE CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE391u), cpu.m8?8:16));
    goto L_01E3B1;
L_01E3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3B1 BEQ -> $01E3C6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E3C6; }
    goto L_01E3B3;
L_01E3B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3B3 CLC
    cpu.setFlag('C', false);
    goto L_01E3B4;
L_01E3B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B4u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B4u, 4u + ((((0xEBB4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEBB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3B4 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xEBB4u), cpu.m8?8:16));
    goto L_01E3B7;
L_01E3B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3B7 STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_01E3B9;
L_01E3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B9u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3B9 TYA
    cpu.transfer("TYA");
    goto L_01E3BA;
L_01E3BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3BA LSR
    cpu.lsrA();
    goto L_01E3BB;
L_01E3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BBu,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3BB ROR
    cpu.rorA();
    goto L_01E3BC;
L_01E3BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BCu,cpu,0x55u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3BC EOR
    cpu.logicXor(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16));
    goto L_01E3BE;
L_01E3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3BE BPL -> $01E3C6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01E3C6; }
    goto L_01E3C0;
L_01E3C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C0u, 6u, 3u, cpu.address("abs", 0x804Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3C0 JSR -> $01804E stack real
    { cpu.push16Value(hw,0xE3C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3C3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x804Eu), 0x01E3C0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3C3;
L_01E3C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3C3u,0x01E3C3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C3u, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3C3 JSR -> $018E5F stack real
    { cpu.push16Value(hw,0xE3C5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3C6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x01E3C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3C6;
L_01E3C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3C6u,0x01E3C6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3C6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01E3C6u);return;} hw.unresolvedReturn(0x01E3C6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01E3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C7u, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3C7 JSR -> $01800E stack real
    { cpu.push16Value(hw,0xE3C9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3CAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0x01E3C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3CA;
L_01E3CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3CAu,0x01E3CAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3CA BEQ -> $01E3E9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E3E9; }
    goto L_01E3CC;
L_01E3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CCu, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3CC JSR -> $018E5F stack real
    { cpu.push16Value(hw,0xE3CEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3CFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x01E3CCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3CF;
L_01E3CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3CFu,0x01E3CFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CFu, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3CF JSR -> $018E5F stack real
    { cpu.push16Value(hw,0xE3D1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3D2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x01E3CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E3D2;
L_01E3D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3D2u,0x01E3D2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D2u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D2u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3D2 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x157Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01E3D5;
L_01E3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D5u, 4u + ((((0xE38Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE38Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3D5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE38Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E3D8;
L_01E3D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D8u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3D8 STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_01E3DA;
L_01E3DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DAu, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3DA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E3DD;
L_01E3DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3DD BNE -> $01E3E8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E3E8; }
    goto L_01E3DF;
L_01E3DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3DF LDA
    cpu.setA(0x50u, 8);
    goto L_01E3E1;
L_01E3E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E1u, 5u, 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3E1 STA
    hw.write(cpu.address("absx", 0x1558u), cpu.a, cpu.m8?8:16);
    goto L_01E3E4;
L_01E3E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3E4 LDA
    cpu.setA(0xD8u, 8);
    goto L_01E3E6;
L_01E3E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E6u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3E6 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_01E3E8;
L_01E3E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3E8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01E3E8u);return;} hw.unresolvedReturn(0x01E3E8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01E3E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3E9 LDA
    cpu.setA(0x1u, 8);
    goto L_01E3EB;
L_01E3EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EBu, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E3EB STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_01E3EE;
L_01E3EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E3EE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01E3EEu);return;} hw.unresolvedReturn(0x01E3EEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01EA8F_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01EA8Fu: goto L_01EA8F;
    case 0x01EA92u: goto L_01EA92;
    case 0x01EA95u: goto L_01EA95;
    case 0x01EA97u: goto L_01EA97;
    case 0x01EA9Au: goto L_01EA9A;
    case 0x01EA9Du: goto L_01EA9D;
    case 0x01EA9Fu: goto L_01EA9F;
    case 0x01EAA1u: goto L_01EAA1;
    case 0x01EAA3u: goto L_01EAA3;
    case 0x01EAA5u: goto L_01EAA5;
    case 0x01EAA7u: goto L_01EAA7;
    case 0x01EAA9u: goto L_01EAA9;
    case 0x01EAABu: goto L_01EAAB;
    case 0x01EAADu: goto L_01EAAD;
    case 0x01EAAFu: goto L_01EAAF;
    case 0x01EAB1u: goto L_01EAB1;
    case 0x01EAB2u: goto L_01EAB2;
    case 0x01EAB3u: goto L_01EAB3;
    case 0x01EAB4u: goto L_01EAB4;
    case 0x01EAB5u: goto L_01EAB5;
    case 0x01EAB6u: goto L_01EAB6;
    case 0x01EAB7u: goto L_01EAB7;
    case 0x01EAB9u: goto L_01EAB9;
    case 0x01EABBu: goto L_01EABB;
    case 0x01EABEu: goto L_01EABE;
    case 0x01EAC0u: goto L_01EAC0;
    case 0x01EAC3u: goto L_01EAC3;
    case 0x01EAC6u: goto L_01EAC6;
    case 0x01EAC9u: goto L_01EAC9;
    case 0x01EACBu: goto L_01EACB;
    case 0x01EACDu: goto L_01EACD;
    case 0x01EAD0u: goto L_01EAD0;
    case 0x01EAD3u: goto L_01EAD3;
    case 0x01EAD6u: goto L_01EAD6;
    case 0x01EAD7u: goto L_01EAD7;
    case 0x01EAD9u: goto L_01EAD9;
    case 0x01EADBu: goto L_01EADB;
    case 0x01EADDu: goto L_01EADD;
    case 0x01EADFu: goto L_01EADF;
    case 0x01EAE2u: goto L_01EAE2;
    case 0x01EAE4u: goto L_01EAE4;
    case 0x01EAE6u: goto L_01EAE6;
    case 0x01EAE8u: goto L_01EAE8;
    case 0x01EAEAu: goto L_01EAEA;
    case 0x01EAECu: goto L_01EAEC;
    case 0x01EAEEu: goto L_01EAEE;
    case 0x01EAF0u: goto L_01EAF0;
    case 0x01EAF3u: goto L_01EAF3;
    case 0x01EAF5u: goto L_01EAF5;
    case 0x01EAF7u: goto L_01EAF7;
    case 0x01EAF9u: goto L_01EAF9;
    case 0x01EAFBu: goto L_01EAFB;
    case 0x01EAFEu: goto L_01EAFE;
    case 0x01EB00u: goto L_01EB00;
    case 0x01EB02u: goto L_01EB02;
    case 0x01EB04u: goto L_01EB04;
    case 0x01EB06u: goto L_01EB06;
    case 0x01EB08u: goto L_01EB08;
    case 0x01EB0Au: goto L_01EB0A;
    case 0x01EB0Cu: goto L_01EB0C;
    case 0x01EB0Fu: goto L_01EB0F;
    case 0x01EB11u: goto L_01EB11;
    case 0x01EB14u: goto L_01EB14;
    case 0x01EB16u: goto L_01EB16;
    case 0x01EB18u: goto L_01EB18;
    case 0x01EB1Au: goto L_01EB1A;
    case 0x01EB1Cu: goto L_01EB1C;
    case 0x01EB1Eu: goto L_01EB1E;
    case 0x01EB21u: goto L_01EB21;
    case 0x01EB23u: goto L_01EB23;
    case 0x01EB25u: goto L_01EB25;
    case 0x01EB27u: goto L_01EB27;
    case 0x01EB2Au: goto L_01EB2A;
    case 0x01EB2Cu: goto L_01EB2C;
    case 0x01EB2Eu: goto L_01EB2E;
    case 0x01EB31u: goto L_01EB31;
    case 0x01EB33u: goto L_01EB33;
    case 0x01EB36u: goto L_01EB36;
    case 0x01EB38u: goto L_01EB38;
    case 0x01EB3Au: goto L_01EB3A;
    case 0x01EB3Cu: goto L_01EB3C;
    case 0x01EB3Eu: goto L_01EB3E;
    case 0x01EB3Fu: goto L_01EB3F;
    case 0x01EB40u: goto L_01EB40;
    case 0x01EB41u: goto L_01EB41;
    case 0x01EB43u: goto L_01EB43;
    case 0x01EB44u: goto L_01EB44;
    case 0x01EB45u: goto L_01EB45;
    case 0x01EB48u: goto L_01EB48;
    case 0x01EB4Au: goto L_01EB4A;
    case 0x01EB4Cu: goto L_01EB4C;
    case 0x01EB4Eu: goto L_01EB4E;
    case 0x01EB51u: goto L_01EB51;
    case 0x01EB53u: goto L_01EB53;
    case 0x01EB54u: goto L_01EB54;
    case 0x01EB57u: goto L_01EB57;
    case 0x01EB59u: goto L_01EB59;
    case 0x01EB5Bu: goto L_01EB5B;
    case 0x01EB5Eu: goto L_01EB5E;
    case 0x01EB61u: goto L_01EB61;
    case 0x01EB64u: goto L_01EB64;
    case 0x01EB66u: goto L_01EB66;
    case 0x01EB67u: goto L_01EB67;
    case 0x01EB69u: goto L_01EB69;
    case 0x01EB6Bu: goto L_01EB6B;
    case 0x01EB6Du: goto L_01EB6D;
    case 0x01EB6Fu: goto L_01EB6F;
    case 0x01EB72u: goto L_01EB72;
    case 0x01EB75u: goto L_01EB75;
    case 0x01EB78u: goto L_01EB78;
    case 0x01EB7Au: goto L_01EB7A;
    case 0x01EB7Du: goto L_01EB7D;
    case 0x01EB7Fu: goto L_01EB7F;
    case 0x01EB81u: goto L_01EB81;
    case 0x01EB82u: goto L_01EB82;
    case 0x01EB85u: goto L_01EB85;
    case 0x01EB87u: goto L_01EB87;
    case 0x01EB8Au: goto L_01EB8A;
    case 0x01EB8Du: goto L_01EB8D;
    case 0x01EB90u: goto L_01EB90;
    case 0x01EB93u: goto L_01EB93;
    case 0x01EB95u: goto L_01EB95;
    case 0x01EB97u: goto L_01EB97;
    case 0x01EB99u: goto L_01EB99;
    case 0x01EB9Au: goto L_01EB9A;
    case 0x01EB9Du: goto L_01EB9D;
    case 0x01EB9Fu: goto L_01EB9F;
    case 0x01EBA2u: goto L_01EBA2;
    case 0x01EBA4u: goto L_01EBA4;
    case 0x01EBA7u: goto L_01EBA7;
    case 0x01EBA9u: goto L_01EBA9;
    case 0x01EBABu: goto L_01EBAB;
    case 0x01EBADu: goto L_01EBAD;
    case 0x01EBB0u: goto L_01EBB0;
    case 0x01EBB1u: goto L_01EBB1;
    case 0x01EBB3u: goto L_01EBB3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01EA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Fu, 4u, 3u, cpu.address("abs", 0x18E8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA8F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EA92;
L_01EA92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA92u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA92u, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA92 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13C6u), cpu.m8?8:16));
    goto L_01EA95;
L_01EA95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA95u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA95u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA95 BEQ -> $01EA9A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EA9A; }
    goto L_01EA97;
L_01EA97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA97u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA97u, 3u, 3u, cpu.address("abs", 0xEB48u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA97 JMP -> $01EB48
    goto L_01EB48;
L_01EA9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Au, 4u, 3u, cpu.address("abs", 0x18DCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA9A STZ
    hw.write(cpu.address("abs", 0x18DCu), 0, cpu.m8?8:16);
    goto L_01EA9D;
L_01EA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA9D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EA9F;
L_01EA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA9F CMP
    cpu.compareA(0x2u);
    goto L_01EAA1;
L_01EAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAA1 BCC -> $01EAA7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01EAA7; }
    goto L_01EAA3;
L_01EAA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAA3 LDA
    cpu.setA(0x30u, 8);
    goto L_01EAA5;
L_01EAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAA5 BRA -> $01EAB2
    goto L_01EAB2;
L_01EAA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAA7 LDY
    cpu.setY(0x0u, 8);
    goto L_01EAA9;
L_01EAA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAA9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAAB;
L_01EAAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAABu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAAB BEQ -> $01EADF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EADF; }
    goto L_01EAAD;
L_01EAAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAADu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAAD BPL -> $01EAB2
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01EAB2; }
    goto L_01EAAF;
L_01EAAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAAFu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAAF EOR
    cpu.logicXor(0xFFu);
    goto L_01EAB1;
L_01EAB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB1u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB1 INC
    cpu.inc('A');
    goto L_01EAB2;
L_01EAB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB2 LSR
    cpu.lsrA();
    goto L_01EAB3;
L_01EAB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB3 LSR
    cpu.lsrA();
    goto L_01EAB4;
L_01EAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB4 LSR
    cpu.lsrA();
    goto L_01EAB5;
L_01EAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB5 LSR
    cpu.lsrA();
    goto L_01EAB6;
L_01EAB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB6 TAY
    cpu.transfer("TAY");
    goto L_01EAB7;
L_01EAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAB9;
L_01EAB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB9 BNE -> $01EAD0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EAD0; }
    goto L_01EABB;
L_01EABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEABBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEABBu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEABBu, 7u, 3u, cpu.address("absx", 0x1570u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EABB DEC
    cpu.decMem(hw, cpu.address("absx", 0x1570u), cpu.m8?8:16);
    goto L_01EABE;
L_01EABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEABEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEABEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EABE BPL -> $01EAD0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01EAD0; }
    goto L_01EAC0;
L_01EAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC0u, 4u + ((((0xEDF5u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEDF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAC0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEDF5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAC3;
L_01EAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC3u, 5u, 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAC3 STA
    hw.write(cpu.address("absx", 0x1570u), cpu.a, cpu.m8?8:16);
    goto L_01EAC6;
L_01EAC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC6u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC6u, 6u, 3u, cpu.address("abs", 0x18ADu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAC6 DEC
    cpu.decMem(hw, cpu.address("abs", 0x18ADu), cpu.m8?8:16);
    goto L_01EAC9;
L_01EAC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAC9 BPL -> $01EAD0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01EAD0; }
    goto L_01EACB;
L_01EACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEACBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEACBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EACB LDA
    cpu.setA(0x2u, 8);
    goto L_01EACD;
L_01EACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEACDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEACDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEACDu, 4u, 3u, cpu.address("abs", 0x18ADu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EACD STA
    hw.write(cpu.address("abs", 0x18ADu), cpu.a, cpu.m8?8:16);
    goto L_01EAD0;
L_01EAD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD0u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD0u, 4u, 3u, cpu.address("abs", 0x18ADu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAD0 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x18ADu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EAD3;
L_01EAD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD3u, 4u + ((((0xEDEEu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEDEEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAD3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEDEEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAD6;
L_01EAD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAD6 TAY
    cpu.transfer("TAY");
    goto L_01EAD7;
L_01EAD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAD7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAD9;
L_01EAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAD9 CMP
    cpu.compareA(0x2u);
    goto L_01EADB;
L_01EADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEADBu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEADBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EADB BCS -> $01EB2E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01EB2E; }
    goto L_01EADD;
L_01EADD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEADDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEADDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEADDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EADD BRA -> $01EAE2
    goto L_01EAE2;
L_01EADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEADFu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEADFu, 5u, 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EADF STZ
    hw.write(cpu.address("absx", 0x1570u), 0, cpu.m8?8:16);
    goto L_01EAE2;
L_01EAE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAE2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAE4;
L_01EAE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAE4 BEQ -> $01EAF0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EAF0; }
    goto L_01EAE6;
L_01EAE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAE6 LDY
    cpu.setY(0x2u, 8);
    goto L_01EAE8;
L_01EAE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAE8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAEA;
L_01EAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAEAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAEA BPL -> $01EAF0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01EAF0; }
    goto L_01EAEC;
L_01EAEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAECu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAEC LDY
    cpu.setY(0x5u, 8);
    goto L_01EAEE;
L_01EAEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAEEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAEEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAEE BRA -> $01EAF0
    goto L_01EAF0;
L_01EAF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF0u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAF0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAF3;
L_01EAF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAF3 BEQ -> $01EAF7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EAF7; }
    goto L_01EAF5;
L_01EAF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAF5 LDY
    cpu.setY(0x3u, 8);
    goto L_01EAF7;
L_01EAF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAF7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAF9;
L_01EAF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAF9 BNE -> $01EB21
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB21; }
    goto L_01EAFB;
L_01EAFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAFBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAFBu, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAFB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAFE;
L_01EAFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAFEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAFE BEQ -> $01EB0C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB0C; }
    goto L_01EB00;
L_01EB00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB00u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB00 LDY
    cpu.setY(0x7u, 8);
    goto L_01EB02;
L_01EB02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB02u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB02u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB02 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB04;
L_01EB04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB04u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB04 AND
    cpu.logicAnd(0x8u);
    goto L_01EB06;
L_01EB06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB06u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB06 BEQ -> $01EB0A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB0A; }
    goto L_01EB08;
L_01EB08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB08u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB08 LDY
    cpu.setY(0x6u, 8);
    goto L_01EB0A;
L_01EB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB0A BRA -> $01EB21
    goto L_01EB21;
L_01EB0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Cu, 4u, 3u, cpu.address("abs", 0x18AFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB0C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18AFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB0F;
L_01EB0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB0F BEQ -> $01EB16
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB16; }
    goto L_01EB11;
L_01EB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB11u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB11u, 6u, 3u, cpu.address("abs", 0x18AFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB11 DEC
    cpu.decMem(hw, cpu.address("abs", 0x18AFu), cpu.m8?8:16);
    goto L_01EB14;
L_01EB14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB14u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB14u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB14 BRA -> $01EB1C
    goto L_01EB1C;
L_01EB16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB16u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB16u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB16 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB18;
L_01EB18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB18u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB18 AND
    cpu.logicAnd(0x4u);
    goto L_01EB1A;
L_01EB1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB1A BEQ -> $01EB21
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB21; }
    goto L_01EB1C;
L_01EB1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB1C LDY
    cpu.setY(0x4u, 8);
    goto L_01EB1E;
L_01EB1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Eu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Eu, 6u, 3u, cpu.address("abs", 0x18DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB1E INC
    cpu.incMem(hw, cpu.address("abs", 0x18DCu), cpu.m8?8:16);
    goto L_01EB21;
L_01EB21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB21u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB21u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB21 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB23;
L_01EB23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB23u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB23 CMP
    cpu.compareA(0x1u);
    goto L_01EB25;
L_01EB25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB25u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB25 BEQ -> $01EB2E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB2E; }
    goto L_01EB27;
L_01EB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB27u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB27u, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB27 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB2A;
L_01EB2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB2Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB2A BNE -> $01EB2E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB2E; }
    goto L_01EB2C;
L_01EB2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB2Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB2C LDY
    cpu.setY(0x4u, 8);
    goto L_01EB2E;
L_01EB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB2Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB2Eu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB2E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB31;
L_01EB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB31u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB31 BEQ -> $01EB44
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB44; }
    goto L_01EB33;
L_01EB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB33u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB33u, 4u, 3u, cpu.address("abs", 0x1419u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB33 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1419u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB36;
L_01EB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB36u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB36 CMP
    cpu.compareA(0x1u);
    goto L_01EB38;
L_01EB38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB38u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB38 BNE -> $01EB44
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB44; }
    goto L_01EB3A;
L_01EB3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB3A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB3C;
L_01EB3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB3C AND
    cpu.logicAnd(0x8u);
    goto L_01EB3E;
L_01EB3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB3E LSR
    cpu.lsrA();
    goto L_01EB3F;
L_01EB3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB3F LSR
    cpu.lsrA();
    goto L_01EB40;
L_01EB40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB40u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB40 LSR
    cpu.lsrA();
    goto L_01EB41;
L_01EB41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB41u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB41 ADC
    cpu.adc(0x8u);
    goto L_01EB43;
L_01EB43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB43u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB43 TAY
    cpu.transfer("TAY");
    goto L_01EB44;
L_01EB44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB44u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB44u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB44 TYA
    cpu.transfer("TYA");
    goto L_01EB45;
L_01EB45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB45u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB45u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB45 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_01EB48;
L_01EB48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB48u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB48u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB48 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB4A;
L_01EB4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB4A CMP
    cpu.compareA(0x1u);
    goto L_01EB4C;
L_01EB4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB4C BNE -> $01EB97
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB97; }
    goto L_01EB4E;
L_01EB4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Eu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Eu, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB4E LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x157Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EB51;
L_01EB51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB51u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB51u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB51 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB53;
L_01EB53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB53u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB53 CLC
    cpu.setFlag('C', false);
    goto L_01EB54;
L_01EB54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB54u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB54u, 4u + ((((0xEDF1u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEDF1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB54 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xEDF1u), cpu.m8?8:16));
    goto L_01EB57;
L_01EB57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB57u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB57u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB57 STA
    hw.write(cpu.address("dpx", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_01EB59;
L_01EB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB59u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB59u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB59 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB5B;
L_01EB5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB5Bu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB5Bu, 4u + ((((0xEDF3u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEDF3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB5B ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xEDF3u), cpu.m8?8:16));
    goto L_01EB5E;
L_01EB5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB5Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB5Eu, 5u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB5E STA
    hw.write(cpu.address("absx", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_01EB61;
L_01EB61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB61u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB61u, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB61 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1602u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EB64;
L_01EB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB64u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB64u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB64 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB66;
L_01EB66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB66u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB66 CLC
    cpu.setFlag('C', false);
    goto L_01EB67;
L_01EB67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB67u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB67 ADC
    cpu.adc(0x10u);
    goto L_01EB69;
L_01EB69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB69u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB69u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB69 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_01EB6B;
L_01EB6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB6B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB6D;
L_01EB6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB6D ADC
    cpu.adc(0x0u);
    goto L_01EB6F;
L_01EB6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Fu, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB6F STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_01EB72;
L_01EB72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB72u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB72u, 4u + ((((0xEDE4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEDE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB72 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEDE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB75;
L_01EB75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB75u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB75u, 4u, 3u, cpu.address("abs", 0x188Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB75 STA
    hw.write(cpu.address("abs", 0x188Bu), cpu.a, cpu.m8?8:16);
    goto L_01EB78;
L_01EB78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB78u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB78 LDA
    cpu.setA(0x1u, 8);
    goto L_01EB7A;
L_01EB7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB7Au,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB7Au, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB7A LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1602u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EB7D;
L_01EB7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB7Du,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB7D CPY
    cpu.compareY(0x3u);
    goto L_01EB7F;
L_01EB7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB7Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB7F BNE -> $01EB82
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB82; }
    goto L_01EB81;
L_01EB81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB81u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB81u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB81 INC
    cpu.inc('A');
    goto L_01EB82;
L_01EB82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB82u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB82u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB82 STA
    hw.write(cpu.address("abs", 0x187Au), cpu.a, cpu.m8?8:16);
    goto L_01EB85;
L_01EB85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB85u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB85 LDA
    cpu.setA(0x1u, 8);
    goto L_01EB87;
L_01EB87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB87u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB87u, 4u, 3u, cpu.address("abs", 0x0DC1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB87 STA
    hw.write(cpu.address("abs", 0xDC1u), cpu.a, cpu.m8?8:16);
    goto L_01EB8A;
L_01EB8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB8Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB8Au, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB8A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB8D;
L_01EB8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB8Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB8Du, 4u, 3u, cpu.address("abs", 0x13C7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB8D STA
    hw.write(cpu.address("abs", 0x13C7u), cpu.a, cpu.m8?8:16);
    goto L_01EB90;
L_01EB90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB90u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB90u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB90 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB93;
L_01EB93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB93u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB93 EOR
    cpu.logicXor(0x1u);
    goto L_01EB95;
L_01EB95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB95u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB95u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB95 STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_01EB97;
L_01EB97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB97u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB97u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB97 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB99;
L_01EB99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB99u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB99u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EB99 PHA
    cpu.push("PHA", hw);
    goto L_01EB9A;
L_01EB9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB9Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB9Au, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB9A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB9D;
L_01EB9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB9Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB9D BEQ -> $01EBAD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EBAD; }
    goto L_01EB9F;
L_01EB9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB9Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB9Fu, 4u, 3u, cpu.address("abs", 0x1419u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB9F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1419u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EBA2;
L_01EBA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EBA2 BEQ -> $01EBAD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EBAD; }
    goto L_01EBA4;
L_01EBA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA4u, 4u, 3u, cpu.address("abs", 0x1405u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EBA4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1405u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EBA7;
L_01EBA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EBA7 BNE -> $01EBB0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EBB0; }
    goto L_01EBA9;
L_01EBA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EBA9 LDA
    cpu.setA(0x10u, 8);
    goto L_01EBAB;
L_01EBAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBABu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBABu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EBAB STA
    hw.write(cpu.address("dp", 0x64u), cpu.a, cpu.m8?8:16);
    goto L_01EBAD;
L_01EBAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBADu, 6u, 3u, cpu.address("abs", 0xEE61u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01EBAD JSR -> $01EE61 stack real
    { cpu.push16Value(hw,0xEBAFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEBB0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEE61u), 0x01EBADu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01EBB0;
L_01EBB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBB0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEBB0u,0x01EBB0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB0u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EBB0 PLA
    cpu.pop("PLA", hw);
    goto L_01EBB1;
L_01EBB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EBB1 STA
    hw.write(cpu.address("dp", 0x64u), cpu.a, cpu.m8?8:16);
    goto L_01EBB3;
L_01EBB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01EBB3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01EBB3u);return;} hw.unresolvedReturn(0x01EBB3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02C202_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02C202u: goto L_02C202;
    case 0x02C205u: goto L_02C205;
    case 0x02C207u: goto L_02C207;
    case 0x02C20Au: goto L_02C20A;
    case 0x02C20Cu: goto L_02C20C;
    case 0x02C20Eu: goto L_02C20E;
    case 0x02C211u: goto L_02C211;
    case 0x02C212u: goto L_02C212;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02C202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC202u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC202u, 4u + ((((0x187Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x187Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C202 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x187Bu), cpu.m8?8:16));
    goto L_02C205;
L_02C205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC205u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC205u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C205 BEQ -> $02C211
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02C211; }
    goto L_02C207;
L_02C207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC207u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC207u, 4u + ((((0x163Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C207 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x163Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C20A;
L_02C20A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C20A BNE -> $02C211
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02C211; }
    goto L_02C20C;
L_02C20C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C20C LDA
    cpu.setA(0x28u, 8);
    goto L_02C20E;
L_02C20E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Eu, 5u, 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C20E STA
    hw.write(cpu.address("absx", 0x163Eu), cpu.a, cpu.m8?8:16);
    goto L_02C211;
L_02C211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC211u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC211u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02C211 PLB
    cpu.pop("PLB", hw);
    goto L_02C212;
L_02C212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC212u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC212u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02C212 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02C212u);return;} hw.unresolvedReturn(0x02C212u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_02C202_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02C202u: goto L_02C202;
    case 0x02C205u: goto L_02C205;
    case 0x02C207u: goto L_02C207;
    case 0x02C20Au: goto L_02C20A;
    case 0x02C20Cu: goto L_02C20C;
    case 0x02C20Eu: goto L_02C20E;
    case 0x02C211u: goto L_02C211;
    case 0x02C212u: goto L_02C212;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02C202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC202u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC202u, 4u + ((((0x187Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x187Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C202 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x187Bu), cpu.m8?8:16));
    goto L_02C205;
L_02C205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC205u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC205u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C205 BEQ -> $02C211
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02C211; }
    goto L_02C207;
L_02C207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC207u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC207u, 4u + ((((0x163Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C207 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x163Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C20A;
L_02C20A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C20A BNE -> $02C211
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02C211; }
    goto L_02C20C;
L_02C20C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C20C LDA
    cpu.setA(0x28u, 8);
    goto L_02C20E;
L_02C20E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Eu, 5u, 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C20E STA
    hw.write(cpu.address("absx", 0x163Eu), cpu.a, cpu.m8?8:16);
    goto L_02C211;
L_02C211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC211u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC211u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02C211 PLB
    cpu.pop("PLB", hw);
    goto L_02C212;
L_02C212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC212u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC212u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02C212 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02C212u);return;} hw.unresolvedReturn(0x02C212u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0584E3_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0584E3u: goto L_0584E3;
    case 0x0584E5u: goto L_0584E5;
    case 0x0584E7u: goto L_0584E7;
    case 0x0584E8u: goto L_0584E8;
    case 0x0584EAu: goto L_0584EA;
    case 0x0584EBu: goto L_0584EB;
    case 0x0584EDu: goto L_0584ED;
    case 0x0584EEu: goto L_0584EE;
    case 0x0584EFu: goto L_0584EF;
    case 0x0584F0u: goto L_0584F0;
    case 0x0584F1u: goto L_0584F1;
    case 0x0584F2u: goto L_0584F2;
    case 0x0584F3u: goto L_0584F3;
    case 0x0584F6u: goto L_0584F6;
    case 0x0584F7u: goto L_0584F7;
    case 0x0584F9u: goto L_0584F9;
    case 0x0584FBu: goto L_0584FB;
    case 0x0584FEu: goto L_0584FE;
    case 0x0584FFu: goto L_0584FF;
    case 0x058503u: goto L_058503;
    case 0x058505u: goto L_058505;
    case 0x058509u: goto L_058509;
    case 0x05850Cu: goto L_05850C;
    case 0x058510u: goto L_058510;
    case 0x058513u: goto L_058513;
    case 0x058517u: goto L_058517;
    case 0x058519u: goto L_058519;
    case 0x05851Du: goto L_05851D;
    case 0x058520u: goto L_058520;
    case 0x058524u: goto L_058524;
    case 0x058526u: goto L_058526;
    case 0x058527u: goto L_058527;
    case 0x058529u: goto L_058529;
    case 0x05852Bu: goto L_05852B;
    case 0x05852Du: goto L_05852D;
    case 0x05852Eu: goto L_05852E;
    case 0x058530u: goto L_058530;
    case 0x058532u: goto L_058532;
    case 0x058534u: goto L_058534;
    case 0x058536u: goto L_058536;
    case 0x058537u: goto L_058537;
    case 0x058538u: goto L_058538;
    case 0x058539u: goto L_058539;
    case 0x05853Au: goto L_05853A;
    case 0x05853Bu: goto L_05853B;
    case 0x05853Eu: goto L_05853E;
    case 0x05853Fu: goto L_05853F;
    case 0x058541u: goto L_058541;
    case 0x058543u: goto L_058543;
    case 0x058544u: goto L_058544;
    case 0x058546u: goto L_058546;
    case 0x058549u: goto L_058549;
    case 0x05854Au: goto L_05854A;
    case 0x05854Bu: goto L_05854B;
    case 0x05854Cu: goto L_05854C;
    case 0x05854Du: goto L_05854D;
    case 0x05854Eu: goto L_05854E;
    case 0x058550u: goto L_058550;
    case 0x058551u: goto L_058551;
    case 0x058555u: goto L_058555;
    case 0x058558u: goto L_058558;
    case 0x05855Au: goto L_05855A;
    case 0x05855Cu: goto L_05855C;
    case 0x05855Fu: goto L_05855F;
    case 0x058561u: goto L_058561;
    case 0x058563u: goto L_058563;
    case 0x058566u: goto L_058566;
    case 0x058568u: goto L_058568;
    case 0x05856Au: goto L_05856A;
    case 0x05856Bu: goto L_05856B;
    case 0x05856Cu: goto L_05856C;
    case 0x05856Du: goto L_05856D;
    case 0x05856Eu: goto L_05856E;
    case 0x058570u: goto L_058570;
    case 0x058572u: goto L_058572;
    case 0x058573u: goto L_058573;
    case 0x058575u: goto L_058575;
    case 0x058577u: goto L_058577;
    case 0x058578u: goto L_058578;
    case 0x058579u: goto L_058579;
    case 0x05857Au: goto L_05857A;
    case 0x05857Bu: goto L_05857B;
    case 0x05857Cu: goto L_05857C;
    case 0x05857Du: goto L_05857D;
    case 0x05857Eu: goto L_05857E;
    case 0x058581u: goto L_058581;
    case 0x058583u: goto L_058583;
    case 0x058587u: goto L_058587;
    case 0x05858Au: goto L_05858A;
    case 0x05858Du: goto L_05858D;
    case 0x058590u: goto L_058590;
    case 0x058592u: goto L_058592;
    case 0x058594u: goto L_058594;
    case 0x058597u: goto L_058597;
    case 0x058599u: goto L_058599;
    case 0x05859Bu: goto L_05859B;
    case 0x05859Cu: goto L_05859C;
    case 0x05859Du: goto L_05859D;
    case 0x05859Eu: goto L_05859E;
    case 0x0585A1u: goto L_0585A1;
    case 0x0585A2u: goto L_0585A2;
    case 0x0585A4u: goto L_0585A4;
    case 0x0585A6u: goto L_0585A6;
    case 0x0585A9u: goto L_0585A9;
    case 0x0585ACu: goto L_0585AC;
    case 0x0585AEu: goto L_0585AE;
    case 0x0585B0u: goto L_0585B0;
    case 0x0585B1u: goto L_0585B1;
    case 0x0585B2u: goto L_0585B2;
    case 0x0585B3u: goto L_0585B3;
    case 0x0585B6u: goto L_0585B6;
    case 0x0585B8u: goto L_0585B8;
    case 0x0585BAu: goto L_0585BA;
    case 0x0585BBu: goto L_0585BB;
    case 0x0585BCu: goto L_0585BC;
    case 0x0585BDu: goto L_0585BD;
    case 0x0585BEu: goto L_0585BE;
    case 0x0585C0u: goto L_0585C0;
    case 0x0585C2u: goto L_0585C2;
    case 0x0585C5u: goto L_0585C5;
    case 0x0585C7u: goto L_0585C7;
    case 0x0585CAu: goto L_0585CA;
    case 0x0585CCu: goto L_0585CC;
    case 0x0585CDu: goto L_0585CD;
    case 0x0585CFu: goto L_0585CF;
    case 0x0585D1u: goto L_0585D1;
    case 0x0585D3u: goto L_0585D3;
    case 0x0585D5u: goto L_0585D5;
    case 0x0585D7u: goto L_0585D7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0584E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584E3 LDY
    cpu.setY(0x0u, 8);
    goto L_0584E5;
L_0584E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E5u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E5u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $0584E5 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0584E7;
L_0584E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584E7 TAX
    cpu.transfer("TAX");
    goto L_0584E8;
L_0584E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584E8 AND
    cpu.logicAnd(0x1Fu);
    goto L_0584EA;
L_0584EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84EAu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584EA INC
    cpu.inc('A');
    goto L_0584EB;
L_0584EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84EBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584EB STA
    hw.write(cpu.address("dp", 0x5Du), cpu.a, cpu.m8?8:16);
    goto L_0584ED;
L_0584ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84EDu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584ED TXA
    cpu.transfer("TXA");
    goto L_0584EE;
L_0584EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84EEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584EE LSR
    cpu.lsrA();
    goto L_0584EF;
L_0584EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84EFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584EF LSR
    cpu.lsrA();
    goto L_0584F0;
L_0584F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584F0 LSR
    cpu.lsrA();
    goto L_0584F1;
L_0584F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584F1 LSR
    cpu.lsrA();
    goto L_0584F2;
L_0584F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584F2 LSR
    cpu.lsrA();
    goto L_0584F3;
L_0584F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F3u, 4u, 3u, cpu.address("abs", 0x1930u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584F3 STA
    hw.write(cpu.address("abs", 0x1930u), cpu.a, cpu.m8?8:16);
    goto L_0584F6;
L_0584F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F6u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584F6 INY
    cpu.inc('Y');
    goto L_0584F7;
L_0584F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F7u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F7u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $0584F7 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0584F9;
L_0584F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584F9 AND
    cpu.logicAnd(0x1Fu);
    goto L_0584FB;
L_0584FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FBu, 4u, 3u, cpu.address("abs", 0x1925u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584FB STA
    hw.write(cpu.address("abs", 0x1925u), cpu.a, cpu.m8?8:16);
    goto L_0584FE;
L_0584FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FEu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584FE TAX
    cpu.transfer("TAX");
    goto L_0584FF;
L_0584FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FFu, 5u, 4u, ((0x0584B7u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0584FF LDA
    cpu.loadA(hw.readW(((0x584B7u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058503;
L_058503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8503u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8503u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8503u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058503 STA
    hw.write(cpu.address("dp", 0x64u), cpu.a, cpu.m8?8:16);
    goto L_058505;
L_058505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8505u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8505u, 5u, 4u, ((0x058437u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058505 LDA
    cpu.loadA(hw.readW(((0x58437u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058509;
L_058509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8509u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8509u, 4u, 3u, cpu.address("abs", 0x0D9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058509 STA
    hw.write(cpu.address("abs", 0xD9Du), cpu.a, cpu.m8?8:16);
    goto L_05850C;
L_05850C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Cu, 5u, 4u, ((0x058457u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05850C LDA
    cpu.loadA(hw.readW(((0x58457u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058510;
L_058510:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8510u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8510u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8510u, 4u, 3u, cpu.address("abs", 0x0D9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058510 STA
    hw.write(cpu.address("abs", 0xD9Eu), cpu.a, cpu.m8?8:16);
    goto L_058513;
L_058513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8513u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8513u, 5u, 4u, ((0x058477u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058513 LDA
    cpu.loadA(hw.readW(((0x58477u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058517;
L_058517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8517u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8517u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x40u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058517 STA
    hw.write(cpu.address("dp", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_058519;
L_058519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8519u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8519u, 5u, 4u, ((0x058497u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058519 LDA
    cpu.loadA(hw.readW(((0x58497u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05851D;
L_05851D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Du, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05851D STA
    hw.write(cpu.address("abs", 0xD9Bu), cpu.a, cpu.m8?8:16);
    goto L_058520;
L_058520:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8520u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8520u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8520u, 5u, 4u, ((0x058417u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058520 LDA
    cpu.loadA(hw.readW(((0x58417u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058524;
L_058524:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8524u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8524u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8524u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058524 STA
    hw.write(cpu.address("dp", 0x5Bu), cpu.a, cpu.m8?8:16);
    goto L_058526;
L_058526:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8526u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8526u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8526u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058526 LSR
    cpu.lsrA();
    goto L_058527;
L_058527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8527u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8527u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8527u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058527 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058529;
L_058529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8529u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8529u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058529 LDX
    cpu.setX(0x1u, 8);
    goto L_05852B;
L_05852B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05852B BCC -> $058530
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_058530; }
    goto L_05852D;
L_05852D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05852D TAX
    cpu.transfer("TAX");
    goto L_05852E;
L_05852E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05852E LDA
    cpu.setA(0x1u, 8);
    goto L_058530;
L_058530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8530u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8530u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8530u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058530 STA
    hw.write(cpu.address("dp", 0x5Eu), cpu.a, cpu.m8?8:16);
    goto L_058532;
L_058532:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8532u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8532u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8532u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058532 STX
    hw.write(cpu.address("dp", 0x5Fu), cpu.x, cpu.x8?8:16);
    goto L_058534;
L_058534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8534u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8534u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $058534 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058536;
L_058536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8536u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8536u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058536 LSR
    cpu.lsrA();
    goto L_058537;
L_058537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8537u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8537u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8537u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058537 LSR
    cpu.lsrA();
    goto L_058538;
L_058538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8538u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8538u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8538u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058538 LSR
    cpu.lsrA();
    goto L_058539;
L_058539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8539u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8539u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8539u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058539 LSR
    cpu.lsrA();
    goto L_05853A;
L_05853A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x853Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x853Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x853Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05853A LSR
    cpu.lsrA();
    goto L_05853B;
L_05853B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x853Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x853Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x853Bu, 4u, 3u, cpu.address("abs", 0x192Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05853B STA
    hw.write(cpu.address("abs", 0x192Fu), cpu.a, cpu.m8?8:16);
    goto L_05853E;
L_05853E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x853Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x853Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x853Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05853E INY
    cpu.inc('Y');
    goto L_05853F;
L_05853F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x853Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x853Fu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x853Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $05853F LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058541;
L_058541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8541u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8541u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058541 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_058543;
L_058543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8543u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8543u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8543u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058543 TAX
    cpu.transfer("TAX");
    goto L_058544;
L_058544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8544u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8544u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058544 AND
    cpu.logicAnd(0xFu);
    goto L_058546;
L_058546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8546u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8546u, 4u, 3u, cpu.address("abs", 0x192Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058546 STA
    hw.write(cpu.address("abs", 0x192Bu), cpu.a, cpu.m8?8:16);
    goto L_058549;
L_058549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8549u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8549u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058549 TXA
    cpu.transfer("TXA");
    goto L_05854A;
L_05854A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05854A LSR
    cpu.lsrA();
    goto L_05854B;
L_05854B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05854B LSR
    cpu.lsrA();
    goto L_05854C;
L_05854C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05854C LSR
    cpu.lsrA();
    goto L_05854D;
L_05854D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05854D LSR
    cpu.lsrA();
    goto L_05854E;
L_05854E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05854E AND
    cpu.logicAnd(0x7u);
    goto L_058550;
L_058550:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8550u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8550u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8550u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058550 TAX
    cpu.transfer("TAX");
    goto L_058551;
L_058551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8551u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8551u, 5u, 4u, ((0x0584DBu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058551 LDA
    cpu.loadA(hw.readW(((0x584DBu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058555;
L_058555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8555u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8555u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058555 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDDAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_058558;
L_058558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8558u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8558u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058558 BPL -> $05855C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_05855C; }
    goto L_05855A;
L_05855A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Au,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05855A ORA
    cpu.logicOr(0x80u);
    goto L_05855C;
L_05855C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Cu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Cu, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05855C CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0xDDAu), cpu.m8?8:16));
    goto L_05855F;
L_05855F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05855F BNE -> $058563
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_058563; }
    goto L_058561;
L_058561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8561u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8561u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058561 ORA
    cpu.logicOr(0x40u);
    goto L_058563;
L_058563:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8563u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8563u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8563u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058563 STA
    hw.write(cpu.address("abs", 0xDDAu), cpu.a, cpu.m8?8:16);
    goto L_058566;
L_058566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8566u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8566u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8566u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058566 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058568;
L_058568:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8568u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8568u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8568u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058568 AND
    cpu.logicAnd(0x80u);
    goto L_05856A;
L_05856A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05856A LSR
    cpu.lsrA();
    goto L_05856B;
L_05856B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05856B LSR
    cpu.lsrA();
    goto L_05856C;
L_05856C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05856C LSR
    cpu.lsrA();
    goto L_05856D;
L_05856D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05856D LSR
    cpu.lsrA();
    goto L_05856E;
L_05856E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Eu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05856E ORA
    cpu.logicOr(0x1u);
    goto L_058570;
L_058570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8570u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8570u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8570u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058570 STA
    hw.write(cpu.address("dp", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_058572;
L_058572:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8572u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8572u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8572u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058572 INY
    cpu.inc('Y');
    goto L_058573;
L_058573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8573u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8573u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $058573 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058575;
L_058575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8575u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8575u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058575 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_058577;
L_058577:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8577u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8577u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8577u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058577 LSR
    cpu.lsrA();
    goto L_058578;
L_058578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8578u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8578u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8578u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058578 LSR
    cpu.lsrA();
    goto L_058579;
L_058579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8579u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8579u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058579 LSR
    cpu.lsrA();
    goto L_05857A;
L_05857A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05857A LSR
    cpu.lsrA();
    goto L_05857B;
L_05857B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05857B LSR
    cpu.lsrA();
    goto L_05857C;
L_05857C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05857C LSR
    cpu.lsrA();
    goto L_05857D;
L_05857D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05857D TAX
    cpu.transfer("TAX");
    goto L_05857E;
L_05857E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Eu, 4u, 3u, cpu.address("abs", 0x141Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05857E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058581;
L_058581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058581 BNE -> $058590
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_058590; }
    goto L_058583;
L_058583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8583u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8583u, 5u, 4u, ((0x0584D7u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058583 LDA
    cpu.loadA(hw.readW(((0x584D7u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058587;
L_058587:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8587u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8587u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8587u, 4u, 3u, cpu.address("abs", 0x0F31u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058587 STA
    hw.write(cpu.address("abs", 0xF31u), cpu.a, cpu.m8?8:16);
    goto L_05858A;
L_05858A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Au, 4u, 3u, cpu.address("abs", 0x0F32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05858A STZ
    hw.write(cpu.address("abs", 0xF32u), 0, cpu.m8?8:16);
    goto L_05858D;
L_05858D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Du, 4u, 3u, cpu.address("abs", 0x0F33u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05858D STZ
    hw.write(cpu.address("abs", 0xF33u), 0, cpu.m8?8:16);
    goto L_058590;
L_058590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8590u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8590u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058590 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058592;
L_058592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8592u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8592u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8592u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058592 AND
    cpu.logicAnd(0x7u);
    goto L_058594;
L_058594:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8594u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8594u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8594u, 4u, 3u, cpu.address("abs", 0x192Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058594 STA
    hw.write(cpu.address("abs", 0x192Du), cpu.a, cpu.m8?8:16);
    goto L_058597;
L_058597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8597u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8597u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058597 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058599;
L_058599:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8599u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8599u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8599u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058599 AND
    cpu.logicAnd(0x38u);
    goto L_05859B;
L_05859B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x859Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x859Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x859Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05859B LSR
    cpu.lsrA();
    goto L_05859C;
L_05859C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x859Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x859Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x859Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05859C LSR
    cpu.lsrA();
    goto L_05859D;
L_05859D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x859Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x859Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x859Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05859D LSR
    cpu.lsrA();
    goto L_05859E;
L_05859E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x859Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x859Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x859Eu, 4u, 3u, cpu.address("abs", 0x192Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05859E STA
    hw.write(cpu.address("abs", 0x192Eu), cpu.a, cpu.m8?8:16);
    goto L_0585A1;
L_0585A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A1u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585A1 INY
    cpu.inc('Y');
    goto L_0585A2;
L_0585A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A2u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A2u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $0585A2 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0585A4;
L_0585A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585A4 AND
    cpu.logicAnd(0xFu);
    goto L_0585A6;
L_0585A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A6u, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585A6 STA
    hw.write(cpu.address("abs", 0x1931u), cpu.a, cpu.m8?8:16);
    goto L_0585A9;
L_0585A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A9u, 4u, 3u, cpu.address("abs", 0x1932u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585A9 STA
    hw.write(cpu.address("abs", 0x1932u), cpu.a, cpu.m8?8:16);
    goto L_0585AC;
L_0585AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ACu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ACu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $0585AC LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0585AE;
L_0585AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85AEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585AE AND
    cpu.logicAnd(0xC0u);
    goto L_0585B0;
L_0585B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585B0 ASL
    cpu.aslA();
    goto L_0585B1;
L_0585B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B1u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585B1 ROL
    cpu.rolA();
    goto L_0585B2;
L_0585B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B2u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585B2 ROL
    cpu.rolA();
    goto L_0585B3;
L_0585B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B3u, 4u, 3u, cpu.address("abs", 0x13BEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585B3 STA
    hw.write(cpu.address("abs", 0x13BEu), cpu.a, cpu.m8?8:16);
    goto L_0585B6;
L_0585B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B6u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B6u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $0585B6 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0585B8;
L_0585B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585B8 AND
    cpu.logicAnd(0x30u);
    goto L_0585BA;
L_0585BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585BA LSR
    cpu.lsrA();
    goto L_0585BB;
L_0585BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BBu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585BB LSR
    cpu.lsrA();
    goto L_0585BC;
L_0585BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BCu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585BC LSR
    cpu.lsrA();
    goto L_0585BD;
L_0585BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585BD LSR
    cpu.lsrA();
    goto L_0585BE;
L_0585BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585BE CMP
    cpu.compareA(0x3u);
    goto L_0585C0;
L_0585C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585C0 BNE -> $0585C7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0585C7; }
    goto L_0585C2;
L_0585C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C2u, 4u, 3u, cpu.address("abs", 0x1411u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585C2 STZ
    hw.write(cpu.address("abs", 0x1411u), 0, cpu.m8?8:16);
    goto L_0585C5;
L_0585C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585C5 LDA
    cpu.setA(0x0u, 8);
    goto L_0585C7;
L_0585C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C7u, 4u, 3u, cpu.address("abs", 0x1412u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585C7 STA
    hw.write(cpu.address("abs", 0x1412u), cpu.a, cpu.m8?8:16);
    goto L_0585CA;
L_0585CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585CA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0585CC;
L_0585CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585CC CLC
    cpu.setFlag('C', false);
    goto L_0585CD;
L_0585CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585CD ADC
    cpu.adc(0x5u);
    goto L_0585CF;
L_0585CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585CF STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_0585D1;
L_0585D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585D1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x66u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0585D3;
L_0585D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585D3 ADC
    cpu.adc(0x0u);
    goto L_0585D5;
L_0585D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585D5 STA
    hw.write(cpu.address("dp", 0x66u), cpu.a, cpu.m8?8:16);
    goto L_0585D7;
L_0585D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0585D7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0585D7u);return;} hw.unresolvedReturn(0x0585D7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_058883_E0M0X0C0_part6(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x058922u: goto L_058922;
    case 0x058925u: goto L_058925;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_058922:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8922u))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8922u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8922u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058922 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_058925;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8922u,0x058922u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058925:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8925u))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8925u,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8925u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058925 TXS
    cpu.transfer("TXS");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8926u,0x058925u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8925u,0x058925u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_05881A_E0M0X0CQ_part6(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x058922u: goto L_058922;
    case 0x058925u: goto L_058925;
    case 0x058926u: goto L_058926;
    case 0x058927u: goto L_058927;
    case 0x058929u: goto L_058929;
    case 0x05892Bu: goto L_05892B;
    case 0x05892Cu: goto L_05892C;
    case 0x05892Du: goto L_05892D;
    case 0x05892Fu: goto L_05892F;
    case 0x058930u: goto L_058930;
    case 0x058932u: goto L_058932;
    case 0x058933u: goto L_058933;
    case 0x058935u: goto L_058935;
    case 0x058936u: goto L_058936;
    case 0x058938u: goto L_058938;
    case 0x058939u: goto L_058939;
    case 0x05893Bu: goto L_05893B;
    case 0x05893Cu: goto L_05893C;
    case 0x05893Eu: goto L_05893E;
    case 0x05893Fu: goto L_05893F;
    case 0x058941u: goto L_058941;
    case 0x058942u: goto L_058942;
    case 0x058944u: goto L_058944;
    case 0x058945u: goto L_058945;
    case 0x058947u: goto L_058947;
    case 0x058948u: goto L_058948;
    case 0x05894Au: goto L_05894A;
    case 0x05894Bu: goto L_05894B;
    case 0x05894Du: goto L_05894D;
    case 0x05894Eu: goto L_05894E;
    case 0x058950u: goto L_058950;
    case 0x058952u: goto L_058952;
    case 0x058955u: goto L_058955;
    case 0x058957u: goto L_058957;
    case 0x05895Au: goto L_05895A;
    case 0x05895Eu: goto L_05895E;
    case 0x05895Fu: goto L_05895F;
    case 0x058962u: goto L_058962;
    case 0x058963u: goto L_058963;
    case 0x058965u: goto L_058965;
    case 0x058966u: goto L_058966;
    case 0x058968u: goto L_058968;
    case 0x058969u: goto L_058969;
    case 0x05896Bu: goto L_05896B;
    case 0x05896Cu: goto L_05896C;
    case 0x05896Eu: goto L_05896E;
    case 0x058971u: goto L_058971;
    case 0x058974u: goto L_058974;
    case 0x058977u: goto L_058977;
    case 0x05897Au: goto L_05897A;
    case 0x05897Du: goto L_05897D;
    case 0x058980u: goto L_058980;
    case 0x058983u: goto L_058983;
    case 0x058986u: goto L_058986;
    case 0x058989u: goto L_058989;
    case 0x05898Cu: goto L_05898C;
    case 0x05898Du: goto L_05898D;
    case 0x05898Fu: goto L_05898F;
    case 0x058992u: goto L_058992;
    case 0x058995u: goto L_058995;
    case 0x058998u: goto L_058998;
    case 0x05899Bu: goto L_05899B;
    case 0x05899Eu: goto L_05899E;
    case 0x0589A1u: goto L_0589A1;
    case 0x0589A4u: goto L_0589A4;
    case 0x0589A7u: goto L_0589A7;
    case 0x0589AAu: goto L_0589AA;
    case 0x0589ADu: goto L_0589AD;
    case 0x0589B0u: goto L_0589B0;
    case 0x0589B3u: goto L_0589B3;
    case 0x0589B6u: goto L_0589B6;
    case 0x0589B9u: goto L_0589B9;
    case 0x0589BCu: goto L_0589BC;
    case 0x0589BDu: goto L_0589BD;
    case 0x0589BFu: goto L_0589BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_058922:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8922u))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8922u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8922u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058922 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_058925;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8922u,0x058922u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058925:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8925u))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8925u,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8925u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058925 TXS
    cpu.transfer("TXS");
    goto L_058926;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8925u,0x058925u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8926u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8926u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058926 TXA
    cpu.transfer("TXA");
    goto L_058927;
L_058927:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8927u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8927u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8927u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058927 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCEu), cpu.m8?8:16));
    goto L_058929;
L_058929:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8929u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8929u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8929u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058929 BIT
    cpu.bit(0x5u, true);
    goto L_05892B;
L_05892B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x892Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x892Bu,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x892Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05892B TXS
    cpu.transfer("TXS");
    goto L_05892C;
L_05892C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x892Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x892Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x892Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05892C TXA
    cpu.transfer("TXA");
    goto L_05892D;
L_05892D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x892Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x892Du,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x892Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05892D ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05892F;
L_05892F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x892Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x892Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x892Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05892F TXA
    cpu.transfer("TXA");
    goto L_058930;
L_058930:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8930u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8930u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8930u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058930 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058932;
L_058932:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8932u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8932u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8932u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058932 TXA
    cpu.transfer("TXA");
    goto L_058933;
L_058933:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8933u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8933u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8933u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058933 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058935;
L_058935:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8935u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8935u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8935u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058935 TXA
    cpu.transfer("TXA");
    goto L_058936;
L_058936:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8936u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8936u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8936u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058936 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058938;
L_058938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8938u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8938u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8938u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058938 TXA
    cpu.transfer("TXA");
    goto L_058939;
L_058939:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8939u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8939u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8939u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058939 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05893B;
L_05893B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x893Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x893Bu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x893Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05893B TXA
    cpu.transfer("TXA");
    goto L_05893C;
L_05893C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x893Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x893Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x893Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05893C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05893E;
L_05893E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x893Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x893Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x893Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05893E TXA
    cpu.transfer("TXA");
    goto L_05893F;
L_05893F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x893Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x893Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x893Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05893F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058941;
L_058941:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8941u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8941u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8941u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058941 TXA
    cpu.transfer("TXA");
    goto L_058942;
L_058942:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8942u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8942u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8942u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058942 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058944;
L_058944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8944u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8944u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8944u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058944 TXA
    cpu.transfer("TXA");
    goto L_058945;
L_058945:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8945u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8945u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8945u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058945 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058947;
L_058947:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8947u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8947u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8947u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058947 TXA
    cpu.transfer("TXA");
    goto L_058948;
L_058948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8948u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8948u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8948u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058948 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05894A;
L_05894A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x894Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x894Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x894Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05894A TXA
    cpu.transfer("TXA");
    goto L_05894B;
L_05894B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x894Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x894Bu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x894Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05894B ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05894D;
L_05894D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x894Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x894Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x894Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05894D TXA
    cpu.transfer("TXA");
    goto L_05894E;
L_05894E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x894Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x894Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x894Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05894E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCEu), cpu.m8?8:16));
    goto L_058950;
L_058950:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8950u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8950u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8950u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058950 BIT
    cpu.bit(0x5u, true);
    goto L_058952;
L_058952:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8952u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8952u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8952u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058952 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_058955;
L_058955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8955u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8955u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058955 SEP
    cpu.sep(0x30u);
    goto L_058957;
L_058957:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8957u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8957u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8957u, 4u, 3u, cpu.address("abs", 0x1925u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058957 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1925u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05895A;
L_05895A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x895Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x895Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x895Au, 8u, 4u, 0x0086FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05895A JSL -> $0086FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x895Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x895Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086FAu, 0x05895Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05895E;
L_05895E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x895Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x895Eu,0x05895Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x895Eu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x895Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05895E PLY
    cpu.pop("PLY", hw);
    goto L_05895F;
L_05895F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x895Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x895Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x895Fu, 4u, 3u, cpu.address("abs", 0x8D05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05895F STA
    hw.write(cpu.address("abs", 0x8D05u), cpu.a, cpu.m8?8:16);
    goto L_058962;
L_058962:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8962u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8962u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8962u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058962 PHB
    cpu.push("PHB", hw);
    goto L_058963;
L_058963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8963u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8963u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058963 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_058965;
L_058965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8965u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8965u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058965 PHB
    cpu.push("PHB", hw);
    goto L_058966;
L_058966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8966u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8966u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058966 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_058968;
L_058968:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8968u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8968u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8968u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058968 PHB
    cpu.push("PHB", hw);
    goto L_058969;
L_058969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8969u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8969u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8969u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058969 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_05896B;
L_05896B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x896Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x896Bu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x896Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05896B PHB
    cpu.push("PHB", hw);
    goto L_05896C;
L_05896C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x896Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x896Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x896Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05896C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16));
    goto L_05896E;
L_05896E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x896Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x896Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x896Eu, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05896E STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_058971;
L_058971:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8971u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8971u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8971u, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058971 STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_058974;
L_058974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8974u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8974u, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058974 STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_058977;
L_058977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8977u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8977u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058977 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_05897A;
L_05897A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x897Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x897Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x897Au, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05897A STY
    hw.write(cpu.address("abs", 0x7A05u), cpu.y, cpu.x8?8:16);
    goto L_05897D;
L_05897D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x897Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x897Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x897Du, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05897D STA
    hw.write(cpu.address("abs", 0x7005u), cpu.a, cpu.m8?8:16);
    goto L_058980;
L_058980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8980u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8980u, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058980 STY
    hw.write(cpu.address("abs", 0x7A05u), cpu.y, cpu.x8?8:16);
    goto L_058983;
L_058983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8983u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8983u, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058983 STA
    hw.write(cpu.address("abs", 0x7A05u), cpu.a, cpu.m8?8:16);
    goto L_058986;
L_058986:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8986u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8986u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8986u, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058986 STA
    hw.write(cpu.address("abs", 0x7A05u), cpu.a, cpu.m8?8:16);
    goto L_058989;
L_058989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8989u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8989u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8989u, 4u, 3u, cpu.address("abs", 0x8D05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058989 STA
    hw.write(cpu.address("abs", 0x8D05u), cpu.a, cpu.m8?8:16);
    goto L_05898C;
L_05898C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x898Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x898Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x898Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05898C PHB
    cpu.push("PHB", hw);
    goto L_05898D;
L_05898D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x898Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x898Du,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x898Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x70u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05898D ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x70u), cpu.m8?8:16));
    goto L_05898F;
L_05898F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x898Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x898Fu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x898Fu, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05898F STY
    hw.write(cpu.address("abs", 0x7A05u), cpu.y, cpu.x8?8:16);
    goto L_058992;
L_058992:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8992u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8992u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8992u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058992 STA
    hw.write(cpu.address("abs", 0x7005u), cpu.a, cpu.m8?8:16);
    goto L_058995;
L_058995:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8995u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8995u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8995u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058995 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_058998;
L_058998:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8998u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8998u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8998u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058998 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_05899B;
L_05899B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x899Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x899Bu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x899Bu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05899B STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_05899E;
L_05899E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x899Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x899Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x899Eu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05899E STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589A1;
L_0589A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A1u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A1u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589A1 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589A4;
L_0589A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A4u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A4u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589A4 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589A7;
L_0589A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A7u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A7u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589A7 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589AA;
L_0589AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89AAu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89AAu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589AA STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589AD;
L_0589AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89ADu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89ADu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589AD STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589B0;
L_0589B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B0u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B0u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589B0 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589B3;
L_0589B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B3u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B3u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589B3 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589B6;
L_0589B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B6u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B6u, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589B6 STY
    hw.write(cpu.address("abs", 0x7A05u), cpu.y, cpu.x8?8:16);
    goto L_0589B9;
L_0589B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B9u, 4u, 3u, cpu.address("abs", 0x8D05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589B9 STA
    hw.write(cpu.address("abs", 0x8D05u), cpu.a, cpu.m8?8:16);
    goto L_0589BC;
L_0589BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89BCu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89BCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0589BC PHB
    cpu.push("PHB", hw);
    goto L_0589BD;
L_0589BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89BDu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89BDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589BD ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16));
    goto L_0589BF;
L_0589BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89BFu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89BFu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0589BF BRK
    hw.partial(0x0589BFu, "BRK"); return;
}

void sub_0CA721_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CA721u: goto L_0CA721;
    case 0x0CA724u: goto L_0CA724;
    case 0x0CA725u: goto L_0CA725;
    case 0x0CA726u: goto L_0CA726;
    case 0x0CA727u: goto L_0CA727;
    case 0x0CA728u: goto L_0CA728;
    case 0x0CA729u: goto L_0CA729;
    case 0x0CA72Cu: goto L_0CA72C;
    case 0x0CA72Fu: goto L_0CA72F;
    case 0x0CA730u: goto L_0CA730;
    case 0x0CA733u: goto L_0CA733;
    case 0x0CA734u: goto L_0CA734;
    case 0x0CA735u: goto L_0CA735;
    case 0x0CA736u: goto L_0CA736;
    case 0x0CA737u: goto L_0CA737;
    case 0x0CA739u: goto L_0CA739;
    case 0x0CA73Bu: goto L_0CA73B;
    case 0x0CA73Du: goto L_0CA73D;
    case 0x0CA73Fu: goto L_0CA73F;
    case 0x0CA740u: goto L_0CA740;
    case 0x0CA741u: goto L_0CA741;
    case 0x0CA744u: goto L_0CA744;
    case 0x0CA747u: goto L_0CA747;
    case 0x0CA748u: goto L_0CA748;
    case 0x0CA74Bu: goto L_0CA74B;
    case 0x0CA74Eu: goto L_0CA74E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CA721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u, 4u + ((((0x0B05u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0B05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA721 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB05u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CA724;
L_0CA724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA724u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA724u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA724 ASL
    cpu.aslA();
    goto L_0CA725;
L_0CA725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA725u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA725u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA725 ASL
    cpu.aslA();
    goto L_0CA726;
L_0CA726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA726u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA726u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA726 ASL
    cpu.aslA();
    goto L_0CA727;
L_0CA727:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA727u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA727u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA727u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA727 ASL
    cpu.aslA();
    goto L_0CA728;
L_0CA728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA728u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA728u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA728 CLC
    cpu.setFlag('C', false);
    goto L_0CA729;
L_0CA729:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA729u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA729u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA729u, 4u + ((((0x0B23u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0B23u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA729 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xB23u), cpu.m8?8:16));
    goto L_0CA72C;
L_0CA72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Cu, 5u, 3u, cpu.address("absx", 0x0B23u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA72C STA
    hw.write(cpu.address("absx", 0xB23u), cpu.a, cpu.m8?8:16);
    goto L_0CA72F;
L_0CA72F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Fu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CA72F PHP
    cpu.push("PHP", hw);
    goto L_0CA730;
L_0CA730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA730u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA730u, 4u + ((((0x0B05u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0B05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA730 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB05u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CA733;
L_0CA733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA733u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA733u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA733 LSR
    cpu.lsrA();
    goto L_0CA734;
L_0CA734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA734 LSR
    cpu.lsrA();
    goto L_0CA735;
L_0CA735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA735u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA735u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA735 LSR
    cpu.lsrA();
    goto L_0CA736;
L_0CA736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA736 LSR
    cpu.lsrA();
    goto L_0CA737;
L_0CA737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA737u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA737u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA737 CMP
    cpu.compareA(0x8u);
    goto L_0CA739;
L_0CA739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA739u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA739u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA739 LDY
    cpu.setY(0x0u, 8);
    goto L_0CA73B;
L_0CA73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA73B BCC -> $0CA740
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0CA740; }
    goto L_0CA73D;
L_0CA73D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA73Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA73D ORA
    cpu.logicOr(0xF0u);
    goto L_0CA73F;
L_0CA73F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA73Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Fu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA73F DEY
    cpu.decReg('Y');
    goto L_0CA740;
L_0CA740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA740u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA740u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CA740 PLP
    cpu.pop("PLP", hw);
    goto L_0CA741;
L_0CA741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA741u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA741u,0x0CA741u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA741u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA741u, 4u + ((((0x0B41u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0B41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA741 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xB41u), cpu.m8?8:16));
    goto L_0CA744;
L_0CA744:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA744u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA744u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA744u, 5u, 3u, cpu.address("absx", 0x0B41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA744 STA
    hw.write(cpu.address("absx", 0xB41u), cpu.a, cpu.m8?8:16);
    goto L_0CA747;
L_0CA747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA747u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA747u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA747 TYA
    cpu.transfer("TYA");
    goto L_0CA748;
L_0CA748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA748u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA748u, 4u + ((((0x0B5Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0B5Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA748 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xB5Fu), cpu.m8?8:16));
    goto L_0CA74B;
L_0CA74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Bu, 5u, 3u, cpu.address("absx", 0x0B5Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA74B STA
    hw.write(cpu.address("absx", 0xB5Fu), cpu.a, cpu.m8?8:16);
    goto L_0CA74E;
L_0CA74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CA74E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CA74Eu);return;} hw.unresolvedReturn(0x0CA74Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0CC94E_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CC94Eu: goto L_0CC94E;
    case 0x0CC951u: goto L_0CC951;
    case 0x0CC953u: goto L_0CC953;
    case 0x0CC956u: goto L_0CC956;
    case 0x0CC959u: goto L_0CC959;
    case 0x0CC95Bu: goto L_0CC95B;
    case 0x0CC95Du: goto L_0CC95D;
    case 0x0CC960u: goto L_0CC960;
    case 0x0CC961u: goto L_0CC961;
    case 0x0CC962u: goto L_0CC962;
    case 0x0CC963u: goto L_0CC963;
    case 0x0CC964u: goto L_0CC964;
    case 0x0CC966u: goto L_0CC966;
    case 0x0CC969u: goto L_0CC969;
    case 0x0CC96Bu: goto L_0CC96B;
    case 0x0CC96Cu: goto L_0CC96C;
    case 0x0CC96Du: goto L_0CC96D;
    case 0x0CC96Eu: goto L_0CC96E;
    case 0x0CC96Fu: goto L_0CC96F;
    case 0x0CC970u: goto L_0CC970;
    case 0x0CC972u: goto L_0CC972;
    case 0x0CC974u: goto L_0CC974;
    case 0x0CC975u: goto L_0CC975;
    case 0x0CC976u: goto L_0CC976;
    case 0x0CC978u: goto L_0CC978;
    case 0x0CC979u: goto L_0CC979;
    case 0x0CC97Bu: goto L_0CC97B;
    case 0x0CC97Du: goto L_0CC97D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CC94E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC94Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Eu, 4u, 3u, cpu.address("abs", 0x1443u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC94E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1443u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CC951;
L_0CC951:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC951u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC951u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC951u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC951 BEQ -> $0CC97D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CC97D; }
    goto L_0CC953;
L_0CC953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC953u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC953u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC953u, 6u, 3u, cpu.address("abs", 0x1443u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC953 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1443u), cpu.m8?8:16);
    goto L_0CC956;
L_0CC956:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC956u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC956u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC956u, 4u, 3u, cpu.address("abs", 0x1443u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC956 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1443u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CC959;
L_0CC959:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC959u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC959u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC959u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC959 AND
    cpu.logicAnd(0x1Fu);
    goto L_0CC95B;
L_0CC95B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC95Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC95B BNE -> $0CC97D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CC97D; }
    goto L_0CC95D;
L_0CC95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Du, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC95D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CC960;
L_0CC960:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC960u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC960u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC960u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC960 DEC
    cpu.decReg('A');
    goto L_0CC961;
L_0CC961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC961u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC961u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC961 ASL
    cpu.aslA();
    goto L_0CC962;
L_0CC962:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC962u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC962u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC962u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC962 ASL
    cpu.aslA();
    goto L_0CC963;
L_0CC963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC963u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC963u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC963 ASL
    cpu.aslA();
    goto L_0CC964;
L_0CC964:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC964u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC964u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC964u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC964 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0CC966;
L_0CC966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC966u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC966u, 4u, 3u, cpu.address("abs", 0x1443u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC966 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1443u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CC969;
L_0CC969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC969u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC969u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC969u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC969 AND
    cpu.logicAnd(0xE0u);
    goto L_0CC96B;
L_0CC96B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC96B LSR
    cpu.lsrA();
    goto L_0CC96C;
L_0CC96C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC96C LSR
    cpu.lsrA();
    goto L_0CC96D;
L_0CC96D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC96D LSR
    cpu.lsrA();
    goto L_0CC96E;
L_0CC96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC96E LSR
    cpu.lsrA();
    goto L_0CC96F;
L_0CC96F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC96F LSR
    cpu.lsrA();
    goto L_0CC970;
L_0CC970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC970u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC970u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC970 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_0CC972;
L_0CC972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC972u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC972u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC972u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC972 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0CC974;
L_0CC974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC974u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC974u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC974 ASL
    cpu.aslA();
    goto L_0CC975;
L_0CC975:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC975u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC975u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC975u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC975 CLC
    cpu.setFlag('C', false);
    goto L_0CC976;
L_0CC976:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC976u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC976u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC976u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC976 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_0CC978;
L_0CC978:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC978u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC978u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC978u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC978 CLC
    cpu.setFlag('C', false);
    goto L_0CC979;
L_0CC979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC979u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC979u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC979 ADC
    cpu.adc(0x21u);
    goto L_0CC97B;
L_0CC97B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC97Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC97B STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_0CC97D;
L_0CC97D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC97Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CC97D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CC97Du);return;} hw.unresolvedReturn(0x0CC97Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DAA08_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DAA08u: goto L_0DAA08;
    case 0x0DAA0Au: goto L_0DAA0A;
    case 0x0DAA0Cu: goto L_0DAA0C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DAA08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA08u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAA08 LDA
    cpu.setA(0x1u, 8);
    goto L_0DAA0A;
L_0DAA0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Au,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Eu) & 0xFFFFu), 3u, 0u);
    // $0DAA0A STA
    hw.write(cpu.addressDpLongY(hw, 0x6Eu), cpu.a, cpu.m8?8:16);
    goto L_0DAA0C;
L_0DAA0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAA0C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DAA0Cu);return;} hw.unresolvedReturn(0x0DAA0Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DAA08_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DAA08u: goto L_0DAA08;
    case 0x0DAA0Au: goto L_0DAA0A;
    case 0x0DAA0Cu: goto L_0DAA0C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DAA08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA08u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAA08 LDA
    cpu.setA(0x1u, 8);
    goto L_0DAA0A;
L_0DAA0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Au,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Eu) & 0xFFFFu), 3u, 0u);
    // $0DAA0A STA
    hw.write(cpu.addressDpLongY(hw, 0x6Eu), cpu.a, cpu.m8?8:16);
    goto L_0DAA0C;
L_0DAA0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAA0C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DAA0Cu);return;} hw.unresolvedReturn(0x0DAA0Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DAA12_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DAA12u: goto L_0DAA12;
    case 0x0DAA14u: goto L_0DAA14;
    case 0x0DAA17u: goto L_0DAA17;
    case 0x0DAA19u: goto L_0DAA19;
    case 0x0DAA1Au: goto L_0DAA1A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DAA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x37u) & 0xFFFFu), 2u, 0u);
    // $0DAA12 AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0x37u), cpu.m8?8:16));
    goto L_0DAA14;
L_0DAA14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA14u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA14u, 4u + ((((0x0000u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAA14 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16));
    goto L_0DAA17;
L_0DAA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAA17 BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0x38u), cpu.m8?8:16), false);
    goto L_0DAA19;
L_0DAA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAA19 DEC
    cpu.decReg('A');
    goto L_0DAA1A;
L_0DAA1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Au,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Au, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0DAA1A BRK
    hw.partial(0x0DAA1Au, "BRK"); return;
}

void sub_0DB6E3_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB6E3u: goto L_0DB6E3;
    case 0x0DB6E5u: goto L_0DB6E5;
    case 0x0DB6E7u: goto L_0DB6E7;
    case 0x0DB6E8u: goto L_0DB6E8;
    case 0x0DB6EAu: goto L_0DB6EA;
    case 0x0DB6EBu: goto L_0DB6EB;
    case 0x0DB6EEu: goto L_0DB6EE;
    case 0x0DB6F2u: goto L_0DB6F2;
    case 0x0DB6F4u: goto L_0DB6F4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB6E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E3u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6E3 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB6E5;
L_0DB6E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6E5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB6E7;
L_0DB6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6E7 SEC
    cpu.setFlag('C', true);
    goto L_0DB6E8;
L_0DB6E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6E8 SBC
    cpu.sbc(0x88u);
    goto L_0DB6EA;
L_0DB6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6EA TAX
    cpu.transfer("TAX");
    goto L_0DB6EB;
L_0DB6EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EBu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB6EB JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB6EDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6EEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB6EBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB6EE;
L_0DB6EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6EEu,0x0DB6EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EEu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EEu, 5u, 4u, ((0x0DB6E1u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6EE LDA
    cpu.loadA(hw.readW(((0xDB6E1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB6F2;
L_0DB6F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F2u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F2u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB6F2 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DB6F4;
L_0DB6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB6F4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB6F4u);return;} hw.unresolvedReturn(0x0DB6F4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A52E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A52Eu: goto L_B1A52E;
    case 0xB1A625u: goto L_B1A625;
    case 0xB1A627u: goto L_B1A627;
    case 0xB1A628u: goto L_B1A628;
    case 0xB1A62Au: goto L_B1A62A;
    case 0xB1A62Cu: goto L_B1A62C;
    case 0xB1A62Eu: goto L_B1A62E;
    case 0xB1A62Fu: goto L_B1A62F;
    case 0xB1A630u: goto L_B1A630;
    case 0xB1A633u: goto L_B1A633;
    case 0xB1A634u: goto L_B1A634;
    case 0xB1A636u: goto L_B1A636;
    case 0xB1A639u: goto L_B1A639;
    case 0xB1A63Cu: goto L_B1A63C;
    case 0xB1A63Du: goto L_B1A63D;
    case 0xB1A640u: goto L_B1A640;
    case 0xB1A64Au: goto L_B1A64A;
    case 0xB1A64Bu: goto L_B1A64B;
    case 0xB1A64Eu: goto L_B1A64E;
    case 0xB1A64Fu: goto L_B1A64F;
    case 0xB1A652u: goto L_B1A652;
    case 0xB1A655u: goto L_B1A655;
    case 0xB1A657u: goto L_B1A657;
    case 0xB1A659u: goto L_B1A659;
    case 0xB1A65Cu: goto L_B1A65C;
    case 0xB1A65Fu: goto L_B1A65F;
    case 0xB1A660u: goto L_B1A660;
    case 0xB1A662u: goto L_B1A662;
    case 0xB1A664u: goto L_B1A664;
    case 0xB1A666u: goto L_B1A666;
    case 0xB1A667u: goto L_B1A667;
    case 0xB1A66Bu: goto L_B1A66B;
    case 0xB1A66Du: goto L_B1A66D;
    case 0xB1A670u: goto L_B1A670;
    case 0xB1A674u: goto L_B1A674;
    case 0xB1A677u: goto L_B1A677;
    case 0xB1A678u: goto L_B1A678;
    case 0xB1A67Au: goto L_B1A67A;
    case 0xB1A67Cu: goto L_B1A67C;
    case 0xB1A67Eu: goto L_B1A67E;
    case 0xB1A680u: goto L_B1A680;
    case 0xB1A682u: goto L_B1A682;
    case 0xB1A684u: goto L_B1A684;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A52E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Eu, 3u, 3u, cpu.address("abs", 0xA625u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A52E JMP -> $B1A625
    goto L_B1A625;
L_B1A625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A625 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A627;
L_B1A627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA627u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA627u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A627 SEC
    cpu.setFlag('C', true);
    goto L_B1A628;
L_B1A628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA628u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA628u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA628u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A628 SBC
    cpu.sbc(0x83u);
    goto L_B1A62A;
L_B1A62A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A62A CMP
    cpu.compareA(0x2u);
    goto L_B1A62C;
L_B1A62C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A62C BCS -> $B1A63D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A63D; }
    goto L_B1A62E;
L_B1A62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A62E PHX
    cpu.push("PHX", hw);
    goto L_B1A62F;
L_B1A62F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Fu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A62F TYX
    cpu.transfer("TYX");
    goto L_B1A630;
L_B1A630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u, 6u, 3u, cpu.address("abs", 0x9098u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A630 JSR -> $B19098 stack real
    { cpu.push16Value(hw,0xA632u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA633u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9098u), 0xB1A630u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A633;
L_B1A633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA633u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA633u,0xB1A633u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA633u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA633u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A633 PLX
    cpu.pop("PLX", hw);
    goto L_B1A634;
L_B1A634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A634 LDA
    cpu.setA(0x0u, 8);
    goto L_B1A636;
L_B1A636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA636u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA636u, 5u, 3u, cpu.address("absy", 0x00AAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A636 STA
    hw.write(cpu.address("absy", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A639;
L_B1A639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA639u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA639u, 6u, 3u, cpu.address("abs", 0xB4E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A639 JSR -> $B1B4E2 stack real
    { cpu.push16Value(hw,0xA63Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA63Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB4E2u), 0xB1A639u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A63C;
L_B1A63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA63Cu,0xB1A63Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A63C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A63Cu);return;} hw.unresolvedReturn(0xB1A63Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A63D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Du, 6u, 3u, cpu.address("abs", 0xA77Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A63D JSR -> $B1A77C stack real
    { cpu.push16Value(hw,0xA63Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA640u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA77Cu), 0xB1A63Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A640;
L_B1A640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA640u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA640u,0xB1A640u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA640u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA640u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A640 BRA -> $B1A64A
    goto L_B1A64A;
L_B1A64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Au,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A64A PHX
    cpu.push("PHX", hw);
    goto L_B1A64B;
L_B1A64B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu, 4u + ((((0x1626u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A64B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1626u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A64E;
L_B1A64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A64E INC
    cpu.inc('A');
    goto L_B1A64F;
L_B1A64F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Fu, 5u, 3u, cpu.address("absy", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A64F STA
    hw.write(cpu.address("absy", 0x1626u), cpu.a, cpu.m8?8:16);
    goto L_B1A652;
L_B1A652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u, 4u + ((((0x1626u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A652 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x1626u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A655;
L_B1A655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA655u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA655u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A655 CPX
    cpu.compareX(0x8u);
    goto L_B1A657;
L_B1A657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA657u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA657u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A657 BCS -> $B1A65F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A65F; }
    goto L_B1A659;
L_B1A659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA659u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA659u, 4u + ((((0xA61Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA61Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A659 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA61Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A65C;
L_B1A65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Cu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A65C STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_B1A65F;
L_B1A65F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A65F TXA
    cpu.transfer("TXA");
    goto L_B1A660;
L_B1A660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A660 CMP
    cpu.compareA(0x8u);
    goto L_B1A662;
L_B1A662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA662u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA662u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA662u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A662 BCC -> $B1A666
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A666; }
    goto L_B1A664;
L_B1A664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA664u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA664u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA664u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A664 LDA
    cpu.setA(0x8u, 8);
    goto L_B1A666;
L_B1A666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA666u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA666u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A666 PLX
    cpu.pop("PLX", hw);
    goto L_B1A667;
L_B1A667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u, 8u, 4u, 0x02ACE5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A667 JSL -> $02ACE5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA66Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA66Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACE5u, 0xB1A667u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A66B;
L_B1A66B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA66Bu,0xB1A66Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A66B LDA
    cpu.setA(0x2u, 8);
    goto L_B1A66D;
L_B1A66D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Du, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A66D STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A670;
L_B1A670:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA670u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA670u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA670u, 8u, 4u, 0x01AB72u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A670 JSL -> $01AB72 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA673u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA674u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB72u, 0xB1A670u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A674;
L_B1A674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA674u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA674u,0xB1A674u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA674u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA674u, 4u + ((((0x00B6u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x00B6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A674 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A677;
L_B1A677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA677u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA677u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A677 ASL
    cpu.aslA();
    goto L_B1A678;
L_B1A678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A678 LDA
    cpu.setA(0x10u, 8);
    goto L_B1A67A;
L_B1A67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A67A BCC -> $B1A67E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A67E; }
    goto L_B1A67C;
L_B1A67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A67C LDA
    cpu.setA(0xF0u, 8);
    goto L_B1A67E;
L_B1A67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A67E STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B1A680;
L_B1A680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA680u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA680u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A680 LDA
    cpu.setA(0xD0u, 8);
    goto L_B1A682;
L_B1A682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A682 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A684;
L_B1A684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A684 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A684u);return;} hw.unresolvedReturn(0xB1A684u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

