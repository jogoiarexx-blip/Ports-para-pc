#include "generated.hpp"
void sub_008D00_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008C8Fu: goto L_008C8F;
    case 0x008C91u: goto L_008C91;
    case 0x008C93u: goto L_008C93;
    case 0x008C96u: goto L_008C96;
    case 0x008C99u: goto L_008C99;
    case 0x008C9Cu: goto L_008C9C;
    case 0x008C9Fu: goto L_008C9F;
    case 0x008CA2u: goto L_008CA2;
    case 0x008CA3u: goto L_008CA3;
    case 0x008CA6u: goto L_008CA6;
    case 0x008CA7u: goto L_008CA7;
    case 0x008CA8u: goto L_008CA8;
    case 0x008CA9u: goto L_008CA9;
    case 0x008CACu: goto L_008CAC;
    case 0x008CAFu: goto L_008CAF;
    case 0x008CB3u: goto L_008CB3;
    case 0x008CB6u: goto L_008CB6;
    case 0x008CB7u: goto L_008CB7;
    case 0x008CBAu: goto L_008CBA;
    case 0x008CBBu: goto L_008CBB;
    case 0x008CBEu: goto L_008CBE;
    case 0x008CBFu: goto L_008CBF;
    case 0x008D00u: goto L_008D00;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008C8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x28u) & 0xFFFFu), 2u, 0u);
    // $008C8F AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0x28u), cpu.m8?8:16));
    goto L_008C91;
L_008C91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008C91 BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0x28u), cpu.m8?8:16), false);
    goto L_008C93;
L_008C93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C93u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C93u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008C93 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8C95u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C96u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008C93u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008C96;
L_008C96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C96u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C96u,0x008C96u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C96u,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C96u, 4u + ((((0x3CFCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x3CFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008C96 BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x3CFCu), cpu.m8?8:16), false);
    goto L_008C99;
L_008C99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C99u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C99u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC3Cu + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008C99 JSR (FC3C,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC3Cu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8C9Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C9Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008C99u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008C9C;
L_008C9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C9Cu,0x008C9Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Cu,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Cu, 4u + ((((0x38FCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x38FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008C9C BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x38FCu), cpu.m8?8:16), false);
    goto L_008C9F;
L_008C9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Fu,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Fu, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x4A38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008C9F JSR (4A38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x4A38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CA1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CA2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008C9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CA2;
L_008CA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CA2u,0x008CA2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CA2 SEC
    cpu.setFlag('C', true);
    goto L_008CA3;
L_008CA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CA3 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CA5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CA6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CA3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CA6;
L_008CA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CA6u,0x008CA6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CA6 SEC
    cpu.setFlag('C', true);
    goto L_008CA7;
L_008CA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CA7 LSR
    cpu.lsrA();
    goto L_008CA8;
L_008CA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u,cpu,0x78u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CA8 SEI
    cpu.setFlag('I', true);
    goto L_008CA9;
L_008CA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x3D38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CA9 JSR (3D38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x3D38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CACu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CA9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CAC;
L_008CAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CACu,0x008CACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu, 4u + ((((0x3C3Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x3C3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CAC BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x3C3Eu), cpu.m8?8:16), false);
    goto L_008CAF;
L_008CAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu, 5u, 4u, ((0x38FC3Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CAF AND
    cpu.logicAnd(hw.readW(((0x38FC3Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_008CB3;
L_008CB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB3u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB3u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CB3 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CB6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CB6;
L_008CB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CB6u,0x008CB6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CB6 SEC
    cpu.setFlag('C', true);
    goto L_008CB7;
L_008CB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u,cpu,0x2Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u, 6u, 3u, cpu.address("abs", 0x263Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CB7 ROL
    cpu.rolMem(hw, cpu.address("abs", 0x263Cu), cpu.m8?8:16);
    goto L_008CBA;
L_008CBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CBA SEC
    cpu.setFlag('C', true);
    goto L_008CBB;
L_008CBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBBu,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBBu, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CBB JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CBDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CBEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CBBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CBE;
L_008CBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CBEu,0x008CBEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CBE SEC
    cpu.setFlag('C', true);
    goto L_008CBF;
L_008CBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBFu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBFu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $008CBF BRK
    hw.partial(0x008CBFu, "BRK"); return;
L_008D00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D00u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D00u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D00 BRA -> $008C8F
    goto L_008C8F;
}

void sub_00A59C_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0093F4u: goto L_0093F4;
    case 0x0093F7u: goto L_0093F7;
    case 0x0093F9u: goto L_0093F9;
    case 0x0093FCu: goto L_0093FC;
    case 0x00A59Cu: goto L_00A59C;
    case 0x00A59Fu: goto L_00A59F;
    case 0x00A5A2u: goto L_00A5A2;
    case 0x00A5A5u: goto L_00A5A5;
    case 0x00A5A8u: goto L_00A5A8;
    case 0x00A5ABu: goto L_00A5AB;
    case 0x00A5AFu: goto L_00A5AF;
    case 0x00A5B2u: goto L_00A5B2;
    case 0x00A5B4u: goto L_00A5B4;
    case 0x00A5B7u: goto L_00A5B7;
    case 0x00A5B9u: goto L_00A5B9;
    case 0x00A5BCu: goto L_00A5BC;
    case 0x00A5BFu: goto L_00A5BF;
    case 0x00A5C3u: goto L_00A5C3;
    case 0x00A5C6u: goto L_00A5C6;
    case 0x00A5C9u: goto L_00A5C9;
    case 0x00A5CCu: goto L_00A5CC;
    case 0x00A5CFu: goto L_00A5CF;
    case 0x00A5D2u: goto L_00A5D2;
    case 0x00A5D5u: goto L_00A5D5;
    case 0x00A5D8u: goto L_00A5D8;
    case 0x00A5DAu: goto L_00A5DA;
    case 0x00A5DBu: goto L_00A5DB;
    case 0x00A5DEu: goto L_00A5DE;
    case 0x00A5E1u: goto L_00A5E1;
    case 0x00A5E4u: goto L_00A5E4;
    case 0x00A5E7u: goto L_00A5E7;
    case 0x00A5E8u: goto L_00A5E8;
    case 0x00A5EBu: goto L_00A5EB;
    case 0x00A5EEu: goto L_00A5EE;
    case 0x00A5F0u: goto L_00A5F0;
    case 0x00A5F3u: goto L_00A5F3;
    case 0x00A5F6u: goto L_00A5F6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0093F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u, 6u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F4 INC
    cpu.incMem(hw, cpu.address("abs", 0x100u), cpu.m8?8:16);
    goto L_0093F7;
L_0093F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F7 LDA
    cpu.setA(0x81u, 8);
    goto L_0093F9;
L_0093F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F9 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0093FC;
L_0093FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0093FCu);return;} hw.unresolvedReturn(0x0093FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00A59C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu, 6u, 3u, cpu.address("abs", 0x85FAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A59C JSR -> $0085FA stack real
    { cpu.push16Value(hw,0xA59Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA59Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85FAu), 0x00A59Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A59F;
L_00A59F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA59Fu,0x00A59Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Fu, 6u, 3u, cpu.address("abs", 0xF62Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A59F JSR -> $00F62D stack real
    { cpu.push16Value(hw,0xA5A1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5A2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF62Du), 0x00A59Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5A2;
L_00A5A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5A2u,0x00A5A2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A2u, 4u, 3u, cpu.address("abs", 0x143Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5A2 STZ
    hw.write(cpu.address("abs", 0x143Au), 0, cpu.m8?8:16);
    goto L_00A5A5;
L_00A5A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A5u, 6u, 3u, cpu.address("abs", 0x8A79u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5A5 JSR -> $008A79 stack real
    { cpu.push16Value(hw,0xA5A7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5A8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8A79u), 0x00A5A5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5A8;
L_00A5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5A8u,0x00A5A8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u, 6u, 3u, cpu.address("abs", 0x8CFFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5A8 JSR -> $008CFF stack real
    { cpu.push16Value(hw,0xA5AAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5ABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8CFFu), 0x00A5A8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5AB;
L_00A5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5ABu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5ABu,0x00A5ABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu, 8u, 4u, 0x05809Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A5AB JSL -> $05809E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA5AEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5AFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05809Eu, 0x00A5ABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5AF;
L_00A5AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5AFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5AFu,0x00A5AFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AFu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5AF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A5B2;
L_00A5B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5B2 BPL -> $00A5B9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00A5B9; }
    goto L_00A5B4;
L_00A5B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B4u, 6u, 3u, cpu.address("abs", 0x97BCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5B4 JSR -> $0097BC stack real
    { cpu.push16Value(hw,0xA5B6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5B7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x97BCu), 0x00A5B4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5B7;
L_00A5B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5B7u,0x00A5B7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5B7 BRA -> $00A5CF
    goto L_00A5CF;
L_00A5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u, 6u, 3u, cpu.address("abs", 0xA9DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5B9 JSR -> $00A9DA stack real
    { cpu.push16Value(hw,0xA5BBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5BCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA9DAu), 0x00A5B9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5BC;
L_00A5BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5BCu,0x00A5BCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BCu, 6u, 3u, cpu.address("abs", 0xABEDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5BC JSR -> $00ABED stack real
    { cpu.push16Value(hw,0xA5BEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5BFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABEDu), 0x00A5BCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5BF;
L_00A5BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5BFu,0x00A5BFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BFu, 8u, 4u, 0x05BE8Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A5BF JSL -> $05BE8A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA5C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5C3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05BE8Au, 0x00A5BFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5C3;
L_00A5C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5C3u,0x00A5C3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u, 6u, 3u, cpu.address("abs", 0x9FB8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5C3 JSR -> $009FB8 stack real
    { cpu.push16Value(hw,0xA5C5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5C6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9FB8u), 0x00A5C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5C6;
L_00A5C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5C6u,0x00A5C6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C6u, 6u, 3u, cpu.address("abs", 0xA5F9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5C6 JSR -> $00A5F9 stack real
    { cpu.push16Value(hw,0xA5C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5C9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5F9u), 0x00A5C6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5C9;
L_00A5C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5C9u,0x00A5C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C9u, 6u, 3u, cpu.address("abs", 0x9260u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5C9 JSR -> $009260 stack real
    { cpu.push16Value(hw,0xA5CBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5CCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9260u), 0x00A5C9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5CC;
L_00A5CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5CCu,0x00A5CCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CCu, 6u, 3u, cpu.address("abs", 0x9860u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5CC JSR -> $009860 stack real
    { cpu.push16Value(hw,0xA5CEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5CFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9860u), 0x00A5CCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5CF;
L_00A5CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5CFu,0x00A5CFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CFu, 6u, 3u, cpu.address("abs", 0x922Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5CF JSR -> $00922F stack real
    { cpu.push16Value(hw,0xA5D1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5D2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x922Fu), 0x00A5CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5D2;
L_00A5D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5D2u,0x00A5D2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D2u, 6u, 3u, cpu.address("abs", 0x9F29u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5D2 JSR -> $009F29 stack real
    { cpu.push16Value(hw,0xA5D4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5D5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F29u), 0x00A5D2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5D5;
L_00A5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5D5u,0x00A5D5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u, 6u, 3u, cpu.address("abs", 0x8E1Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5D5 JSR -> $008E1A stack real
    { cpu.push16Value(hw,0xA5D7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5D8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E1Au), 0x00A5D5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5D8;
L_00A5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5D8u,0x00A5D8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5D8 REP
    cpu.rep(0x30u);
    goto L_00A5DA;
L_00A5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DAu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00A5DA PHB
    cpu.push("PHB", hw);
    goto L_00A5DB;
L_00A5DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5DB LDX
    cpu.setX(0x703u, 16);
    goto L_00A5DE;
L_00A5DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5DE LDY
    cpu.setY(0x905u, 16);
    goto L_00A5E1;
L_00A5E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5E1 LDA
    cpu.setA(0x1EFu, 16);
    goto L_00A5E4;
L_00A5E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E4u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA5E4u, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $00A5E4 MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_00A5E7;
L_00A5E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00A5E7 PLB
    cpu.pop("PLB", hw);
    goto L_00A5E8;
L_00A5E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u, 5u, 3u, cpu.address("abs", 0x0701u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5E8 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x701u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A5EB;
L_00A5EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EBu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EBu, 5u, 3u, cpu.address("abs", 0x0903u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5EB STX
    hw.write(cpu.address("abs", 0x903u), cpu.x, cpu.x8?8:16);
    goto L_00A5EE;
L_00A5EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5EE SEP
    cpu.sep(0x30u);
    goto L_00A5F0;
L_00A5F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F0u, 6u, 3u, cpu.address("abs", 0x919Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5F0 JSR -> $00919B stack real
    { cpu.push16Value(hw,0xA5F2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5F3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x919Bu), 0x00A5F0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5F3;
L_00A5F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5F3u,0x00A5F3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F3u, 6u, 3u, cpu.address("abs", 0x8494u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5F3 JSR -> $008494 stack real
    { cpu.push16Value(hw,0xA5F5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5F6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8494u), 0x00A5F3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5F6;
L_00A5F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5F6u,0x00A5F6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F6u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F6u, 3u, 3u, cpu.address("abs", 0x93F4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5F6 JMP -> $0093F4
    goto L_0093F4;
}

void sub_00A59C_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0093F4u: goto L_0093F4;
    case 0x0093F7u: goto L_0093F7;
    case 0x0093F9u: goto L_0093F9;
    case 0x0093FCu: goto L_0093FC;
    case 0x00A59Cu: goto L_00A59C;
    case 0x00A59Fu: goto L_00A59F;
    case 0x00A5A2u: goto L_00A5A2;
    case 0x00A5A5u: goto L_00A5A5;
    case 0x00A5A8u: goto L_00A5A8;
    case 0x00A5ABu: goto L_00A5AB;
    case 0x00A5AFu: goto L_00A5AF;
    case 0x00A5B2u: goto L_00A5B2;
    case 0x00A5B4u: goto L_00A5B4;
    case 0x00A5B7u: goto L_00A5B7;
    case 0x00A5B9u: goto L_00A5B9;
    case 0x00A5BCu: goto L_00A5BC;
    case 0x00A5BFu: goto L_00A5BF;
    case 0x00A5C3u: goto L_00A5C3;
    case 0x00A5C6u: goto L_00A5C6;
    case 0x00A5C9u: goto L_00A5C9;
    case 0x00A5CCu: goto L_00A5CC;
    case 0x00A5CFu: goto L_00A5CF;
    case 0x00A5D2u: goto L_00A5D2;
    case 0x00A5D5u: goto L_00A5D5;
    case 0x00A5D8u: goto L_00A5D8;
    case 0x00A5DAu: goto L_00A5DA;
    case 0x00A5DBu: goto L_00A5DB;
    case 0x00A5DEu: goto L_00A5DE;
    case 0x00A5E1u: goto L_00A5E1;
    case 0x00A5E4u: goto L_00A5E4;
    case 0x00A5E7u: goto L_00A5E7;
    case 0x00A5E8u: goto L_00A5E8;
    case 0x00A5EBu: goto L_00A5EB;
    case 0x00A5EEu: goto L_00A5EE;
    case 0x00A5F0u: goto L_00A5F0;
    case 0x00A5F3u: goto L_00A5F3;
    case 0x00A5F6u: goto L_00A5F6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0093F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u, 6u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F4 INC
    cpu.incMem(hw, cpu.address("abs", 0x100u), cpu.m8?8:16);
    goto L_0093F7;
L_0093F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F7 LDA
    cpu.setA(0x81u, 8);
    goto L_0093F9;
L_0093F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F9 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0093FC;
L_0093FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0093FCu);return;} hw.unresolvedReturn(0x0093FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00A59C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu, 6u, 3u, cpu.address("abs", 0x85FAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A59C JSR -> $0085FA stack real
    { cpu.push16Value(hw,0xA59Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA59Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85FAu), 0x00A59Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A59F;
L_00A59F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA59Fu,0x00A59Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Fu, 6u, 3u, cpu.address("abs", 0xF62Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A59F JSR -> $00F62D stack real
    { cpu.push16Value(hw,0xA5A1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5A2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF62Du), 0x00A59Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5A2;
L_00A5A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5A2u,0x00A5A2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A2u, 4u, 3u, cpu.address("abs", 0x143Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5A2 STZ
    hw.write(cpu.address("abs", 0x143Au), 0, cpu.m8?8:16);
    goto L_00A5A5;
L_00A5A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A5u, 6u, 3u, cpu.address("abs", 0x8A79u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5A5 JSR -> $008A79 stack real
    { cpu.push16Value(hw,0xA5A7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5A8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8A79u), 0x00A5A5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5A8;
L_00A5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5A8u,0x00A5A8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u, 6u, 3u, cpu.address("abs", 0x8CFFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5A8 JSR -> $008CFF stack real
    { cpu.push16Value(hw,0xA5AAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5ABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8CFFu), 0x00A5A8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5AB;
L_00A5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5ABu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5ABu,0x00A5ABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu, 8u, 4u, 0x05809Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A5AB JSL -> $05809E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA5AEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5AFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05809Eu, 0x00A5ABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5AF;
L_00A5AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5AFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5AFu,0x00A5AFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AFu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5AF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A5B2;
L_00A5B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5B2 BPL -> $00A5B9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00A5B9; }
    goto L_00A5B4;
L_00A5B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B4u, 6u, 3u, cpu.address("abs", 0x97BCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5B4 JSR -> $0097BC stack real
    { cpu.push16Value(hw,0xA5B6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5B7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x97BCu), 0x00A5B4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5B7;
L_00A5B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5B7u,0x00A5B7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5B7 BRA -> $00A5CF
    goto L_00A5CF;
L_00A5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u, 6u, 3u, cpu.address("abs", 0xA9DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5B9 JSR -> $00A9DA stack real
    { cpu.push16Value(hw,0xA5BBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5BCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA9DAu), 0x00A5B9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5BC;
L_00A5BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5BCu,0x00A5BCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BCu, 6u, 3u, cpu.address("abs", 0xABEDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5BC JSR -> $00ABED stack real
    { cpu.push16Value(hw,0xA5BEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5BFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABEDu), 0x00A5BCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5BF;
L_00A5BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5BFu,0x00A5BFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BFu, 8u, 4u, 0x05BE8Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A5BF JSL -> $05BE8A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA5C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5C3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05BE8Au, 0x00A5BFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5C3;
L_00A5C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5C3u,0x00A5C3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u, 6u, 3u, cpu.address("abs", 0x9FB8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5C3 JSR -> $009FB8 stack real
    { cpu.push16Value(hw,0xA5C5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5C6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9FB8u), 0x00A5C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5C6;
L_00A5C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5C6u,0x00A5C6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C6u, 6u, 3u, cpu.address("abs", 0xA5F9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5C6 JSR -> $00A5F9 stack real
    { cpu.push16Value(hw,0xA5C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5C9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5F9u), 0x00A5C6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5C9;
L_00A5C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5C9u,0x00A5C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C9u, 6u, 3u, cpu.address("abs", 0x9260u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5C9 JSR -> $009260 stack real
    { cpu.push16Value(hw,0xA5CBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5CCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9260u), 0x00A5C9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5CC;
L_00A5CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5CCu,0x00A5CCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CCu, 6u, 3u, cpu.address("abs", 0x9860u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5CC JSR -> $009860 stack real
    { cpu.push16Value(hw,0xA5CEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5CFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9860u), 0x00A5CCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5CF;
L_00A5CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5CFu,0x00A5CFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CFu, 6u, 3u, cpu.address("abs", 0x922Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5CF JSR -> $00922F stack real
    { cpu.push16Value(hw,0xA5D1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5D2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x922Fu), 0x00A5CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5D2;
L_00A5D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5D2u,0x00A5D2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D2u, 6u, 3u, cpu.address("abs", 0x9F29u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5D2 JSR -> $009F29 stack real
    { cpu.push16Value(hw,0xA5D4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5D5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F29u), 0x00A5D2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5D5;
L_00A5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5D5u,0x00A5D5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u, 6u, 3u, cpu.address("abs", 0x8E1Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5D5 JSR -> $008E1A stack real
    { cpu.push16Value(hw,0xA5D7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5D8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E1Au), 0x00A5D5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5D8;
L_00A5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5D8u,0x00A5D8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5D8 REP
    cpu.rep(0x30u);
    goto L_00A5DA;
L_00A5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DAu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00A5DA PHB
    cpu.push("PHB", hw);
    goto L_00A5DB;
L_00A5DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5DB LDX
    cpu.setX(0x703u, 16);
    goto L_00A5DE;
L_00A5DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5DE LDY
    cpu.setY(0x905u, 16);
    goto L_00A5E1;
L_00A5E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5E1 LDA
    cpu.setA(0x1EFu, 16);
    goto L_00A5E4;
L_00A5E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E4u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA5E4u, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $00A5E4 MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_00A5E7;
L_00A5E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00A5E7 PLB
    cpu.pop("PLB", hw);
    goto L_00A5E8;
L_00A5E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u, 5u, 3u, cpu.address("abs", 0x0701u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5E8 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x701u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A5EB;
L_00A5EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EBu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EBu, 5u, 3u, cpu.address("abs", 0x0903u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5EB STX
    hw.write(cpu.address("abs", 0x903u), cpu.x, cpu.x8?8:16);
    goto L_00A5EE;
L_00A5EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5EE SEP
    cpu.sep(0x30u);
    goto L_00A5F0;
L_00A5F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F0u, 6u, 3u, cpu.address("abs", 0x919Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5F0 JSR -> $00919B stack real
    { cpu.push16Value(hw,0xA5F2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5F3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x919Bu), 0x00A5F0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5F3;
L_00A5F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5F3u,0x00A5F3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F3u, 6u, 3u, cpu.address("abs", 0x8494u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5F3 JSR -> $008494 stack real
    { cpu.push16Value(hw,0xA5F5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5F6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8494u), 0x00A5F3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5F6;
L_00A5F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5F6u,0x00A5F6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F6u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F6u, 3u, 3u, cpu.address("abs", 0x93F4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5F6 JMP -> $0093F4
    goto L_0093F4;
}

void sub_00A6C7_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A6C7u: goto L_00A6C7;
    case 0x00A6C9u: goto L_00A6C9;
    case 0x00A6CBu: goto L_00A6CB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6C7 STX
    hw.write(cpu.address("dp", 0x71u), cpu.x, cpu.x8?8:16);
    goto L_00A6C9;
L_00A6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C9u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6C9 STY
    hw.write(cpu.address("dp", 0x88u), cpu.y, cpu.x8?8:16);
    goto L_00A6CB;
L_00A6CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A6CB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A6CBu);return;} hw.unresolvedReturn(0x00A6CBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00BA28_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00BA28u: goto L_00BA28;
    case 0x00BA29u: goto L_00BA29;
    case 0x00BA2Au: goto L_00BA2A;
    case 0x00BA2Bu: goto L_00BA2B;
    case 0x00BA2Cu: goto L_00BA2C;
    case 0x00BA2Fu: goto L_00BA2F;
    case 0x00BA31u: goto L_00BA31;
    case 0x00BA34u: goto L_00BA34;
    case 0x00BA36u: goto L_00BA36;
    case 0x00BA39u: goto L_00BA39;
    case 0x00BA3Bu: goto L_00BA3B;
    case 0x00BA3Du: goto L_00BA3D;
    case 0x00BA3Fu: goto L_00BA3F;
    case 0x00BA41u: goto L_00BA41;
    case 0x00BA43u: goto L_00BA43;
    case 0x00BA45u: goto L_00BA45;
    case 0x00BA47u: goto L_00BA47;
    case 0x00BA4Au: goto L_00BA4A;
    case 0x00BA4Bu: goto L_00BA4B;
    case 0x00BA4Cu: goto L_00BA4C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00BA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA28u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA28u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BA28 PHB
    cpu.push("PHB", hw);
    goto L_00BA29;
L_00BA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA29u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA29u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BA29 PHY
    cpu.push("PHY", hw);
    goto L_00BA2A;
L_00BA2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Au,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BA2A PHK
    cpu.push("PHK", hw);
    goto L_00BA2B;
L_00BA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BA2B PLB
    cpu.pop("PLB", hw);
    goto L_00BA2C;
L_00BA2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Cu, 4u + ((((0xB992u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xB992u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA2C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB992u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BA2F;
L_00BA2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA2F STA
    hw.write(cpu.address("dp", 0x8Au), cpu.a, cpu.m8?8:16);
    goto L_00BA31;
L_00BA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA31u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA31u, 4u + ((((0xB9C4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xB9C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA31 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB9C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BA34;
L_00BA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA34u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA34u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA34 STA
    hw.write(cpu.address("dp", 0x8Bu), cpu.a, cpu.m8?8:16);
    goto L_00BA36;
L_00BA36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA36u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA36u, 4u + ((((0xB9F6u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xB9F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA36 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB9F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BA39;
L_00BA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA39u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA39u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA39 STA
    hw.write(cpu.address("dp", 0x8Cu), cpu.a, cpu.m8?8:16);
    goto L_00BA3B;
L_00BA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA3B LDA
    cpu.setA(0x0u, 8);
    goto L_00BA3D;
L_00BA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA3D STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00BA3F;
L_00BA3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA3F LDA
    cpu.setA(0xADu, 8);
    goto L_00BA41;
L_00BA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA41u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA41u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA41 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_00BA43;
L_00BA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA43 LDA
    cpu.setA(0x7Eu, 8);
    goto L_00BA45;
L_00BA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA45u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA45u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA45 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_00BA47;
L_00BA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA47u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA47u, 6u, 3u, cpu.address("abs", 0xB8DEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00BA47 JSR -> $00B8DE stack real
    { cpu.push16Value(hw,0xBA49u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBA4Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB8DEu), 0x00BA47u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00BA4A;
L_00BA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA4Au,0x00BA4Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Au,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BA4A PLY
    cpu.pop("PLY", hw);
    goto L_00BA4B;
L_00BA4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BA4B PLB
    cpu.pop("PLB", hw);
    goto L_00BA4C;
L_00BA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00BA4C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00BA4Cu);return;} hw.unresolvedReturn(0x00BA4Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_00BA28_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00BA28u: goto L_00BA28;
    case 0x00BA29u: goto L_00BA29;
    case 0x00BA2Au: goto L_00BA2A;
    case 0x00BA2Bu: goto L_00BA2B;
    case 0x00BA2Cu: goto L_00BA2C;
    case 0x00BA2Fu: goto L_00BA2F;
    case 0x00BA31u: goto L_00BA31;
    case 0x00BA34u: goto L_00BA34;
    case 0x00BA36u: goto L_00BA36;
    case 0x00BA39u: goto L_00BA39;
    case 0x00BA3Bu: goto L_00BA3B;
    case 0x00BA3Du: goto L_00BA3D;
    case 0x00BA3Fu: goto L_00BA3F;
    case 0x00BA41u: goto L_00BA41;
    case 0x00BA43u: goto L_00BA43;
    case 0x00BA45u: goto L_00BA45;
    case 0x00BA47u: goto L_00BA47;
    case 0x00BA4Au: goto L_00BA4A;
    case 0x00BA4Bu: goto L_00BA4B;
    case 0x00BA4Cu: goto L_00BA4C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00BA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA28u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA28u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BA28 PHB
    cpu.push("PHB", hw);
    goto L_00BA29;
L_00BA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA29u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA29u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BA29 PHY
    cpu.push("PHY", hw);
    goto L_00BA2A;
L_00BA2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Au,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BA2A PHK
    cpu.push("PHK", hw);
    goto L_00BA2B;
L_00BA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BA2B PLB
    cpu.pop("PLB", hw);
    goto L_00BA2C;
L_00BA2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Cu, 4u + ((((0xB992u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xB992u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA2C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB992u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BA2F;
L_00BA2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA2F STA
    hw.write(cpu.address("dp", 0x8Au), cpu.a, cpu.m8?8:16);
    goto L_00BA31;
L_00BA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA31u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA31u, 4u + ((((0xB9C4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xB9C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA31 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB9C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BA34;
L_00BA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA34u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA34u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA34 STA
    hw.write(cpu.address("dp", 0x8Bu), cpu.a, cpu.m8?8:16);
    goto L_00BA36;
L_00BA36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA36u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA36u, 4u + ((((0xB9F6u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xB9F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA36 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB9F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00BA39;
L_00BA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA39u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA39u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA39 STA
    hw.write(cpu.address("dp", 0x8Cu), cpu.a, cpu.m8?8:16);
    goto L_00BA3B;
L_00BA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA3B LDA
    cpu.setA(0x0u, 8);
    goto L_00BA3D;
L_00BA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA3D STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00BA3F;
L_00BA3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA3F LDA
    cpu.setA(0xADu, 8);
    goto L_00BA41;
L_00BA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA41u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA41u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA41 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_00BA43;
L_00BA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA43 LDA
    cpu.setA(0x7Eu, 8);
    goto L_00BA45;
L_00BA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA45u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA45u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BA45 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_00BA47;
L_00BA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA47u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA47u, 6u, 3u, cpu.address("abs", 0xB8DEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00BA47 JSR -> $00B8DE stack real
    { cpu.push16Value(hw,0xBA49u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBA4Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB8DEu), 0x00BA47u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00BA4A;
L_00BA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA4Au,0x00BA4Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Au,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BA4A PLY
    cpu.pop("PLY", hw);
    goto L_00BA4B;
L_00BA4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00BA4B PLB
    cpu.pop("PLB", hw);
    goto L_00BA4C;
L_00BA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00BA4C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00BA4Cu);return;} hw.unresolvedReturn(0x00BA4Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_00C9FE_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00C9FEu: goto L_00C9FE;
    case 0x00CA01u: goto L_00CA01;
    case 0x00CA04u: goto L_00CA04;
    case 0x00CA06u: goto L_00CA06;
    case 0x00CA08u: goto L_00CA08;
    case 0x00CA0Bu: goto L_00CA0B;
    case 0x00CA0Du: goto L_00CA0D;
    case 0x00CA0Fu: goto L_00CA0F;
    case 0x00CA12u: goto L_00CA12;
    case 0x00CA14u: goto L_00CA14;
    case 0x00CA16u: goto L_00CA16;
    case 0x00CA19u: goto L_00CA19;
    case 0x00CA1Bu: goto L_00CA1B;
    case 0x00CA1Cu: goto L_00CA1C;
    case 0x00CA1Eu: goto L_00CA1E;
    case 0x00CA20u: goto L_00CA20;
    case 0x00CA23u: goto L_00CA23;
    case 0x00CA25u: goto L_00CA25;
    case 0x00CA28u: goto L_00CA28;
    case 0x00CA2Bu: goto L_00CA2B;
    case 0x00CA2Du: goto L_00CA2D;
    case 0x00CA30u: goto L_00CA30;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00C9FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FEu, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C9FE STA
    hw.write(cpu.address("abs", 0xDD5u), cpu.a, cpu.m8?8:16);
    goto L_00CA01;
L_00CA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA01u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA01u, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA01 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CA04;
L_00CA04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA04u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA04 BEQ -> $00CA25
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA25; }
    goto L_00CA06;
L_00CA06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA06u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA06 LDX
    cpu.setX(0x8u, 8);
    goto L_00CA08;
L_00CA08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA08u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA08u, 4u, 3u, cpu.address("abs", 0x13BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA08 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13BFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CA0B;
L_00CA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA0B CMP
    cpu.compareA(0x13u);
    goto L_00CA0D;
L_00CA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA0D BNE -> $00CA12
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA12; }
    goto L_00CA0F;
L_00CA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Fu, 6u, 3u, cpu.address("abs", 0x0DD5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA0F INC
    cpu.incMem(hw, cpu.address("abs", 0xDD5u), cpu.m8?8:16);
    goto L_00CA12;
L_00CA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA12u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA12 CMP
    cpu.compareA(0x31u);
    goto L_00CA14;
L_00CA14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA14u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA14u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA14 BEQ -> $00CA20
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA20; }
    goto L_00CA16;
L_00CA16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA16u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA16u, 4u + ((((0xC9A6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xC9A6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA16 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0xC9A6u), cpu.m8?8:16));
    goto L_00CA19;
L_00CA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA19u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA19 BEQ -> $00CA20
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA20; }
    goto L_00CA1B;
L_00CA1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA1B DEX
    cpu.decReg('X');
    goto L_00CA1C;
L_00CA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA1C BNE -> $00CA16
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA16; }
    goto L_00CA1E;
L_00CA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA1E BRA -> $00CA25
    goto L_00CA25;
L_00CA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA20u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA20u, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA20 STX
    hw.write(cpu.address("abs", 0x13C6u), cpu.x, cpu.x8?8:16);
    goto L_00CA23;
L_00CA23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA23u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA23 LDY
    cpu.setY(0x18u, 8);
    goto L_00CA25;
L_00CA25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA25u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA25u, 4u, 3u, cpu.address("abs", 0x0100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA25 STY
    hw.write(cpu.address("abs", 0x100u), cpu.y, cpu.x8?8:16);
    goto L_00CA28;
L_00CA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA28u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA28u, 6u, 3u, cpu.address("abs", 0x1DE9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA28 INC
    cpu.incMem(hw, cpu.address("abs", 0x1DE9u), cpu.m8?8:16);
    goto L_00CA2B;
L_00CA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA2B LDA
    cpu.setA(0x1u, 8);
    goto L_00CA2D;
L_00CA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du, 4u, 3u, cpu.address("abs", 0x13CEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA2D STA
    hw.write(cpu.address("abs", 0x13CEu), cpu.a, cpu.m8?8:16);
    goto L_00CA30;
L_00CA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA30u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA30u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA30 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CA30u);return;} hw.unresolvedReturn(0x00CA30u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CEB1_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CFF7u: goto L_00CFF7;
    case 0x00CFF8u: goto L_00CFF8;
    case 0x00CFFBu: goto L_00CFFB;
    case 0x00CFFCu: goto L_00CFFC;
    case 0x00CFFFu: goto L_00CFFF;
    case 0x00D002u: goto L_00D002;
    case 0x00D003u: goto L_00D003;
    case 0x00D006u: goto L_00D006;
    case 0x00D007u: goto L_00D007;
    case 0x00D00Au: goto L_00D00A;
    case 0x00D00Du: goto L_00D00D;
    case 0x00D00Fu: goto L_00D00F;
    case 0x00D010u: goto L_00D010;
    case 0x00D012u: goto L_00D012;
    case 0x00D014u: goto L_00D014;
    case 0x00D016u: goto L_00D016;
    case 0x00D018u: goto L_00D018;
    case 0x00D01Au: goto L_00D01A;
    case 0x00D01Du: goto L_00D01D;
    case 0x00D01Fu: goto L_00D01F;
    case 0x00D020u: goto L_00D020;
    case 0x00D022u: goto L_00D022;
    case 0x00D024u: goto L_00D024;
    case 0x00D026u: goto L_00D026;
    case 0x00D028u: goto L_00D028;
    case 0x00D02Au: goto L_00D02A;
    case 0x00D02Du: goto L_00D02D;
    case 0x00D02Eu: goto L_00D02E;
    case 0x00D030u: goto L_00D030;
    case 0x00D033u: goto L_00D033;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CFF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFF7 LSR
    cpu.lsrA();
    goto L_00CFF8;
L_00CFF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF8u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF8u, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFF8 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13E5u), cpu.m8?8:16));
    goto L_00CFFB;
L_00CFFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFFB TAY
    cpu.transfer("TAY");
    goto L_00CFFC;
L_00CFFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFCu, 4u + ((((0xDC7Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDC7Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFFC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDC7Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFFF;
L_00CFFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFFu, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFFF STA
    hw.write(cpu.address("abs", 0x1496u), cpu.a, cpu.m8?8:16);
    goto L_00D002;
L_00D002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD002u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD002u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D002 XBA
    cpu.xba();
    goto L_00D003;
L_00D003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD003u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD003u, 4u, 3u, cpu.address("abs", 0x13DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D003 STA
    hw.write(cpu.address("abs", 0x13DBu), cpu.a, cpu.m8?8:16);
    goto L_00D006;
L_00D006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD006u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD006u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D006 CLC
    cpu.setFlag('C', false);
    goto L_00D007;
L_00D007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD007u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD007u, 4u, 3u, cpu.address("abs", 0x13DEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D007 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x13DEu), cpu.m8?8:16));
    goto L_00D00A;
L_00D00A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD00Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Au, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D00A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x148Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D00D;
L_00D00D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD00Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D00D BEQ -> $00D014
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D014; }
    goto L_00D00F;
L_00D00F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD00Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D00F CLC
    cpu.setFlag('C', false);
    goto L_00D010;
L_00D010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD010u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD010u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D010 ADC
    cpu.adc(0x7u);
    goto L_00D012;
L_00D012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD012u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD012u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D012 BRA -> $00D01A
    goto L_00D01A;
L_00D014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD014u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD014u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D014 CPX
    cpu.compareX(0x2Fu);
    goto L_00D016;
L_00D016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD016u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD016u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D016 BCC -> $00D01A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00D01A; }
    goto L_00D018;
L_00D018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD018u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD018u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D018 ADC
    cpu.adc(0x3u);
    goto L_00D01A;
L_00D01A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Au, 4u, 3u, cpu.address("abs", 0x13E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D01A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13E3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D01D;
L_00D01D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D01D BEQ -> $00D030
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D030; }
    goto L_00D01F;
L_00D01F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Fu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D01F TYA
    cpu.transfer("TYA");
    goto L_00D020;
L_00D020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD020u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD020u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D020 AND
    cpu.logicAnd(0x1u);
    goto L_00D022;
L_00D022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD022u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD022u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D022 STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00D024;
L_00D024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD024u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD024u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D024 LDA
    cpu.setA(0x10u, 8);
    goto L_00D026;
L_00D026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD026u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD026u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D026 CPY
    cpu.compareY(0x6u);
    goto L_00D028;
L_00D028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D028 BCC -> $00D030
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00D030; }
    goto L_00D02A;
L_00D02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Au, 4u, 3u, cpu.address("abs", 0x13DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D02A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13DBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D02D;
L_00D02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D02D CLC
    cpu.setFlag('C', false);
    goto L_00D02E;
L_00D02E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D02E ADC
    cpu.adc(0x11u);
    goto L_00D030;
L_00D030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD030u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD030u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D030 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00D033;
L_00D033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD033u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD033u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00D033 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00D033u);return;} hw.unresolvedReturn(0x00D033u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_00E2BD_E0M1X1C0_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00E415u: goto L_00E415;
    case 0x00E417u: goto L_00E417;
    case 0x00E41Au: goto L_00E41A;
    case 0x00E41Cu: goto L_00E41C;
    case 0x00E41Eu: goto L_00E41E;
    case 0x00E420u: goto L_00E420;
    case 0x00E423u: goto L_00E423;
    case 0x00E424u: goto L_00E424;
    case 0x00E425u: goto L_00E425;
    case 0x00E427u: goto L_00E427;
    case 0x00E428u: goto L_00E428;
    case 0x00E42Bu: goto L_00E42B;
    case 0x00E42Du: goto L_00E42D;
    case 0x00E430u: goto L_00E430;
    case 0x00E432u: goto L_00E432;
    case 0x00E435u: goto L_00E435;
    case 0x00E437u: goto L_00E437;
    case 0x00E438u: goto L_00E438;
    case 0x00E43Bu: goto L_00E43B;
    case 0x00E43Du: goto L_00E43D;
    case 0x00E43Eu: goto L_00E43E;
    case 0x00E441u: goto L_00E441;
    case 0x00E443u: goto L_00E443;
    case 0x00E445u: goto L_00E445;
    case 0x00E448u: goto L_00E448;
    case 0x00E44Bu: goto L_00E44B;
    case 0x00E44Eu: goto L_00E44E;
    case 0x00E451u: goto L_00E451;
    case 0x00E453u: goto L_00E453;
    case 0x00E455u: goto L_00E455;
    case 0x00E458u: goto L_00E458;
    case 0x00E45Bu: goto L_00E45B;
    case 0x00E45Cu: goto L_00E45C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00E415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE415u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE415u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E415 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_00E417;
L_00E417:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE417u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE417u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE417u, 4u + ((((0xE1D5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE1D5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E417 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE1D5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E41A;
L_00E41A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E41A STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_00E41C;
L_00E41C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E41C CMP
    cpu.compareA(0x4u);
    goto L_00E41E;
L_00E41E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E41E BCS -> $00E432
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00E432; }
    goto L_00E420;
L_00E420:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE420u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE420u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE420u, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E420 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13DFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E423;
L_00E423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE423u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE423u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E423 ASL
    cpu.aslA();
    goto L_00E424;
L_00E424:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE424u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE424u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE424u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E424 ASL
    cpu.aslA();
    goto L_00E425;
L_00E425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE425u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE425u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E425 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_00E427;
L_00E427:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE427u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE427u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE427u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E427 TAY
    cpu.transfer("TAY");
    goto L_00E428;
L_00E428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE428u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE428u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE428u, 4u + ((((0xE23Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE23Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E428 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE23Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E42B;
L_00E42B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE42Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E42B STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_00E42D;
L_00E42D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE42Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Du, 4u + ((((0xE266u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE266u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E42D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE266u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E430;
L_00E430:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE430u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE430u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE430u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E430 BRA -> $00E435
    goto L_00E435;
L_00E432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE432u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE432u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE432u, 4u + ((((0xE1D6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE1D6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E432 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE1D6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E435;
L_00E435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE435u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE435u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E435 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16));
    goto L_00E437;
L_00E437:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE437u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE437u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE437u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E437 TAY
    cpu.transfer("TAY");
    goto L_00E438;
L_00E438:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE438u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE438u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE438u, 4u + ((((0xE21Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE21Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E438 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE21Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E43B;
L_00E43B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE43Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E43B STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_00E43D;
L_00E43D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE43Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Du,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00E43D PLY
    cpu.pop("PLY", hw);
    goto L_00E43E;
L_00E43E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE43Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Eu, 4u + ((((0xE1D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE1D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E43E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE1D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E441;
L_00E441:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE441u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE441u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE441u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E441 TSB
    cpu.tsb(hw, cpu.address("dp", 0x78u), cpu.m8?8:16);
    goto L_00E443;
L_00E443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE443u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE443u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE443u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E443 BMI -> $00E448
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E448; }
    goto L_00E445;
L_00E445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE445u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE445u, 6u, 3u, cpu.address("abs", 0xE45Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E445 JSR -> $00E45D stack real
    { cpu.push16Value(hw,0xE447u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE448u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE45Du), 0x00E445u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E448;
L_00E448:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE448u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE448u,0x00E448u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE448u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE448u, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E448 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13F9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00E44B;
L_00E44B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE44Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Bu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Bu, 4u + ((((0xE2B6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE2B6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E44B LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xE2B6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00E44E;
L_00E44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE44Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Eu, 6u, 3u, cpu.address("abs", 0xE45Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E44E JSR -> $00E45D stack real
    { cpu.push16Value(hw,0xE450u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE451u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE45Du), 0x00E44Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E451;
L_00E451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE451u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE451u,0x00E451u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE451u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE451u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E451 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E453;
L_00E453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE453u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE453u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E453 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_00E455;
L_00E455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE455u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE455u, 6u, 3u, cpu.address("abs", 0xE45Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E455 JSR -> $00E45D stack real
    { cpu.push16Value(hw,0xE457u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE458u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE45Du), 0x00E455u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E458;
L_00E458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE458u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE458u,0x00E458u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE458u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE458u, 6u, 3u, cpu.address("abs", 0xF636u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E458 JSR -> $00F636 stack real
    { cpu.push16Value(hw,0xE45Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE45Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF636u), 0x00E458u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E45B;
L_00E45B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE45Bu,0x00E45Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00E45B PLB
    cpu.pop("PLB", hw);
    goto L_00E45C;
L_00E45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00E45C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00E45Cu);return;} hw.unresolvedReturn(0x00E45Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_00E2BD_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00E415u: goto L_00E415;
    case 0x00E417u: goto L_00E417;
    case 0x00E41Au: goto L_00E41A;
    case 0x00E41Cu: goto L_00E41C;
    case 0x00E41Eu: goto L_00E41E;
    case 0x00E420u: goto L_00E420;
    case 0x00E423u: goto L_00E423;
    case 0x00E424u: goto L_00E424;
    case 0x00E425u: goto L_00E425;
    case 0x00E427u: goto L_00E427;
    case 0x00E428u: goto L_00E428;
    case 0x00E42Bu: goto L_00E42B;
    case 0x00E42Du: goto L_00E42D;
    case 0x00E430u: goto L_00E430;
    case 0x00E432u: goto L_00E432;
    case 0x00E435u: goto L_00E435;
    case 0x00E437u: goto L_00E437;
    case 0x00E438u: goto L_00E438;
    case 0x00E43Bu: goto L_00E43B;
    case 0x00E43Du: goto L_00E43D;
    case 0x00E43Eu: goto L_00E43E;
    case 0x00E441u: goto L_00E441;
    case 0x00E443u: goto L_00E443;
    case 0x00E445u: goto L_00E445;
    case 0x00E448u: goto L_00E448;
    case 0x00E44Bu: goto L_00E44B;
    case 0x00E44Eu: goto L_00E44E;
    case 0x00E451u: goto L_00E451;
    case 0x00E453u: goto L_00E453;
    case 0x00E455u: goto L_00E455;
    case 0x00E458u: goto L_00E458;
    case 0x00E45Bu: goto L_00E45B;
    case 0x00E45Cu: goto L_00E45C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00E415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE415u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE415u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E415 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_00E417;
L_00E417:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE417u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE417u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE417u, 4u + ((((0xE1D5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE1D5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E417 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE1D5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E41A;
L_00E41A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E41A STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_00E41C;
L_00E41C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E41C CMP
    cpu.compareA(0x4u);
    goto L_00E41E;
L_00E41E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE41Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE41Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E41E BCS -> $00E432
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00E432; }
    goto L_00E420;
L_00E420:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE420u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE420u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE420u, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E420 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13DFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E423;
L_00E423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE423u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE423u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E423 ASL
    cpu.aslA();
    goto L_00E424;
L_00E424:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE424u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE424u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE424u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E424 ASL
    cpu.aslA();
    goto L_00E425;
L_00E425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE425u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE425u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E425 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_00E427;
L_00E427:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE427u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE427u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE427u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E427 TAY
    cpu.transfer("TAY");
    goto L_00E428;
L_00E428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE428u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE428u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE428u, 4u + ((((0xE23Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE23Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E428 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE23Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E42B;
L_00E42B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE42Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E42B STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_00E42D;
L_00E42D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE42Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE42Du, 4u + ((((0xE266u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE266u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E42D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE266u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E430;
L_00E430:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE430u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE430u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE430u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E430 BRA -> $00E435
    goto L_00E435;
L_00E432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE432u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE432u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE432u, 4u + ((((0xE1D6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE1D6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E432 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE1D6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E435;
L_00E435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE435u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE435u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E435 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16));
    goto L_00E437;
L_00E437:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE437u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE437u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE437u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E437 TAY
    cpu.transfer("TAY");
    goto L_00E438;
L_00E438:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE438u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE438u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE438u, 4u + ((((0xE21Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE21Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E438 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE21Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E43B;
L_00E43B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE43Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E43B STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_00E43D;
L_00E43D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE43Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Du,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00E43D PLY
    cpu.pop("PLY", hw);
    goto L_00E43E;
L_00E43E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE43Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE43Eu, 4u + ((((0xE1D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE1D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E43E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE1D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E441;
L_00E441:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE441u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE441u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE441u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E441 TSB
    cpu.tsb(hw, cpu.address("dp", 0x78u), cpu.m8?8:16);
    goto L_00E443;
L_00E443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE443u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE443u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE443u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E443 BMI -> $00E448
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E448; }
    goto L_00E445;
L_00E445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE445u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE445u, 6u, 3u, cpu.address("abs", 0xE45Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E445 JSR -> $00E45D stack real
    { cpu.push16Value(hw,0xE447u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE448u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE45Du), 0x00E445u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E448;
L_00E448:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE448u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE448u,0x00E448u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE448u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE448u, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E448 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13F9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00E44B;
L_00E44B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE44Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Bu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Bu, 4u + ((((0xE2B6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE2B6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E44B LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xE2B6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00E44E;
L_00E44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE44Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE44Eu, 6u, 3u, cpu.address("abs", 0xE45Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E44E JSR -> $00E45D stack real
    { cpu.push16Value(hw,0xE450u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE451u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE45Du), 0x00E44Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E451;
L_00E451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE451u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE451u,0x00E451u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE451u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE451u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E451 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E453;
L_00E453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE453u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE453u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E453 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_00E455;
L_00E455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE455u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE455u, 6u, 3u, cpu.address("abs", 0xE45Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E455 JSR -> $00E45D stack real
    { cpu.push16Value(hw,0xE457u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE458u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE45Du), 0x00E455u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E458;
L_00E458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE458u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE458u,0x00E458u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE458u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE458u, 6u, 3u, cpu.address("abs", 0xF636u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E458 JSR -> $00F636 stack real
    { cpu.push16Value(hw,0xE45Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE45Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF636u), 0x00E458u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E45B;
L_00E45B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE45Bu,0x00E45Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00E45B PLB
    cpu.pop("PLB", hw);
    goto L_00E45C;
L_00E45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00E45C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00E45Cu);return;} hw.unresolvedReturn(0x00E45Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_00E92B_E1M1X1CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00E9E4u: goto L_00E9E4;
    case 0x00E9E5u: goto L_00E9E5;
    case 0x00E9E7u: goto L_00E9E7;
    case 0x00E9EAu: goto L_00E9EA;
    case 0x00E9ECu: goto L_00E9EC;
    case 0x00E9EEu: goto L_00E9EE;
    case 0x00E9F0u: goto L_00E9F0;
    case 0x00E9F3u: goto L_00E9F3;
    case 0x00E9F6u: goto L_00E9F6;
    case 0x00E9F9u: goto L_00E9F9;
    case 0x00E9FBu: goto L_00E9FB;
    case 0x00E9FDu: goto L_00E9FD;
    case 0x00E9FFu: goto L_00E9FF;
    case 0x00EA01u: goto L_00EA01;
    case 0x00EA03u: goto L_00EA03;
    case 0x00EA06u: goto L_00EA06;
    case 0x00EA08u: goto L_00EA08;
    case 0x00EA0Bu: goto L_00EA0B;
    case 0x00EA0Du: goto L_00EA0D;
    case 0x00EA0Fu: goto L_00EA0F;
    case 0x00EA11u: goto L_00EA11;
    case 0x00EA13u: goto L_00EA13;
    case 0x00EA15u: goto L_00EA15;
    case 0x00EA16u: goto L_00EA16;
    case 0x00EA18u: goto L_00EA18;
    case 0x00EA1Au: goto L_00EA1A;
    case 0x00EA1Bu: goto L_00EA1B;
    case 0x00EA1Eu: goto L_00EA1E;
    case 0x00EA20u: goto L_00EA20;
    case 0x00EA22u: goto L_00EA22;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00E9E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9E4u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E4 SEC
    cpu.setFlag('C', true);
    goto L_00E9E5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E4 SEC
    cpu.setFlag('C', true);
    goto L_00E9E5;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E4 SEC
    cpu.setFlag('C', true);
    goto L_00E9E5;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E4 SEC
    cpu.setFlag('C', true);
    goto L_00E9E5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9E4u,0x00E9E4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9E5u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00E9E7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00E9E7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00E9E7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00E9E7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9E5u,0x00E9E5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9E7u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E7u,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E7u, 4u + 1u, 3u, cpu.address("absy", 0xE90Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E7 EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xE90Eu), cpu.m8?8:16));
    goto L_00E9EA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E7u,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E7u, 4u + ((((0xE90Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E7 EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xE90Eu), cpu.m8?8:16));
    goto L_00E9EA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E7u,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E7u, 4u + 1u, 3u, cpu.address("absy", 0xE90Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E7 EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xE90Eu), cpu.m8?8:16));
    goto L_00E9EA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E7u,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E7u, 4u + ((((0xE90Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E7 EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xE90Eu), cpu.m8?8:16));
    goto L_00E9EA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9E7u,0x00E9E7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9EAu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EA BMI -> $00E9F6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E9F6; }
    goto L_00E9EC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EA BMI -> $00E9F6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E9F6; }
    goto L_00E9EC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EA BMI -> $00E9F6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E9F6; }
    goto L_00E9EC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EA BMI -> $00E9F6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E9F6; }
    goto L_00E9EC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9EAu,0x00E9EAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9ECu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9EE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9EE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9EE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9EE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9ECu,0x00E9ECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9EEu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EE STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00E9F0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EE STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00E9F0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EE STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00E9F0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EE STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00E9F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9EEu,0x00E9EEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F0u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u, 4u, 3u, cpu.address("abs", 0x144Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x144Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9F3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u, 4u, 3u, cpu.address("abs", 0x144Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x144Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9F3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u, 4u, 3u, cpu.address("abs", 0x144Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x144Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9F3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u, 4u, 3u, cpu.address("abs", 0x144Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x144Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9F0u,0x00E9F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F3u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u, 4u, 3u, cpu.address("abs", 0x13DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F3 STA
    hw.write(cpu.address("abs", 0x13DAu), cpu.a, cpu.m8?8:16);
    goto L_00E9F6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u, 4u, 3u, cpu.address("abs", 0x13DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F3 STA
    hw.write(cpu.address("abs", 0x13DAu), cpu.a, cpu.m8?8:16);
    goto L_00E9F6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u, 4u, 3u, cpu.address("abs", 0x13DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F3 STA
    hw.write(cpu.address("abs", 0x13DAu), cpu.a, cpu.m8?8:16);
    goto L_00E9F6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u, 4u, 3u, cpu.address("abs", 0x13DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F3 STA
    hw.write(cpu.address("abs", 0x13DAu), cpu.a, cpu.m8?8:16);
    goto L_00E9F6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9F3u,0x00E9F3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F6u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F6u, 4u + 1u, 3u, cpu.address("absy", 0xE90Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE90Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9F9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F6u, 4u + ((((0xE90Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE90Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9F9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F6u, 4u + 1u, 3u, cpu.address("absy", 0xE90Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE90Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9F9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F6u, 4u + ((((0xE90Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE90Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9F6u,0x00E9F6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F9u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F9 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00E9FB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F9 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00E9FB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F9 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00E9FB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F9 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00E9FB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9F9u,0x00E9F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9FBu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9FD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9FD;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9FD;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9FD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9FBu,0x00E9FBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9FDu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FD AND
    cpu.logicAnd(0x1Cu);
    goto L_00E9FF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FD AND
    cpu.logicAnd(0x1Cu);
    goto L_00E9FF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FD AND
    cpu.logicAnd(0x1Cu);
    goto L_00E9FF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FD AND
    cpu.logicAnd(0x1Cu);
    goto L_00E9FF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9FDu,0x00E9FDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9FFu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FF CMP
    cpu.compareA(0x1Cu);
    goto L_00EA01;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FF CMP
    cpu.compareA(0x1Cu);
    goto L_00EA01;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FF CMP
    cpu.compareA(0x1Cu);
    goto L_00EA01;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FF CMP
    cpu.compareA(0x1Cu);
    goto L_00EA01;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9FFu,0x00E9FFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA01u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA01u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA01 BNE -> $00EA0D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA0D; }
    goto L_00EA03;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA01u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA01 BNE -> $00EA0D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA0D; }
    goto L_00EA03;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA01u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA01 BNE -> $00EA0D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA0D; }
    goto L_00EA03;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA01u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA01 BNE -> $00EA0D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA0D; }
    goto L_00EA03;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA01u,0x00EA01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA03u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA03 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA06;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA03 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA06;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA03 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA06;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA03 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA03u,0x00EA03u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA06u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA06u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA06 BNE -> $00EA0D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA0D; }
    goto L_00EA08;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA06u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA06 BNE -> $00EA0D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA0D; }
    goto L_00EA08;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA06u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA06 BNE -> $00EA0D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA0D; }
    goto L_00EA08;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA06u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA06 BNE -> $00EA0D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA0D; }
    goto L_00EA08;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA06u,0x00EA06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA08u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA08u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA08u, 6u, 3u, cpu.address("abs", 0xF629u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA08 JSR -> $00F629 stack real
    { cpu.push16Value(hw,0xEA0Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF629u), 0x00EA08u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA08u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA08u, 6u, 3u, cpu.address("abs", 0xF629u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA08 JSR -> $00F629 stack real
    { cpu.push16Value(hw,0xEA0Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF629u), 0x00EA08u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA0B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA08u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA08u, 6u, 3u, cpu.address("abs", 0xF629u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA08 JSR -> $00F629 stack real
    { cpu.push16Value(hw,0xEA0Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF629u), 0x00EA08u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA0B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA08u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA08u, 6u, 3u, cpu.address("abs", 0xF629u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA08 JSR -> $00F629 stack real
    { cpu.push16Value(hw,0xEA0Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF629u), 0x00EA08u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA08u,0x00EA08u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA0Bu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0B BRA -> $00EA32
    hw.requestDispatch(0x00EA32u,0x00EA0Bu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0B BRA -> $00EA32
    hw.requestDispatch(0x00EA32u,0x00EA0Bu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0B BRA -> $00EA32
    hw.requestDispatch(0x00EA32u,0x00EA0Bu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0B BRA -> $00EA32
    hw.requestDispatch(0x00EA32u,0x00EA0Bu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,0x00EA0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA0Du))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA0F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA0F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA0F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA0F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA0Du,0x00EA0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA0Fu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0F AND
    cpu.logicAnd(0x3u);
    goto L_00EA11;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0F AND
    cpu.logicAnd(0x3u);
    goto L_00EA11;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0F AND
    cpu.logicAnd(0x3u);
    goto L_00EA11;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0F AND
    cpu.logicAnd(0x3u);
    goto L_00EA11;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA0Fu,0x00EA0Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA11u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA11 BEQ -> $00EA34
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA34u,0x00EA11u); return; }
    goto L_00EA13;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA11 BEQ -> $00EA34
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA34u,0x00EA11u); return; }
    goto L_00EA13;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA11 BEQ -> $00EA34
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA34u,0x00EA11u); return; }
    goto L_00EA13;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA11 BEQ -> $00EA34
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA34u,0x00EA11u); return; }
    goto L_00EA13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA11u,0x00EA11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA13u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA13u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA13 AND
    cpu.logicAnd(0x2u);
    goto L_00EA15;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA13u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA13 AND
    cpu.logicAnd(0x2u);
    goto L_00EA15;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA13u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA13 AND
    cpu.logicAnd(0x2u);
    goto L_00EA15;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA13u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA13 AND
    cpu.logicAnd(0x2u);
    goto L_00EA15;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA13u,0x00EA13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA15u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA15 TAY
    cpu.transfer("TAY");
    goto L_00EA16;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA15 TAY
    cpu.transfer("TAY");
    goto L_00EA16;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA15 TAY
    cpu.transfer("TAY");
    goto L_00EA16;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA15 TAY
    cpu.transfer("TAY");
    goto L_00EA16;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA15u,0x00EA15u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA16u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA16u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA16 REP
    cpu.rep(0x20u);
    goto L_00EA18;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA16u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA16 REP
    cpu.rep(0x20u);
    goto L_00EA18;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA16u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA16 REP
    cpu.rep(0x20u);
    goto L_00EA18;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA16u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA16 REP
    cpu.rep(0x20u);
    goto L_00EA18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA16u,0x00EA16u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA18u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA18u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA18 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA1A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA18u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA18 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA1A;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA18u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA18 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA1A;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA18u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA18 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA1A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA18u,0x00EA18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA1Au))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1A CLC
    cpu.setFlag('C', false);
    goto L_00EA1B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1A CLC
    cpu.setFlag('C', false);
    goto L_00EA1B;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1A CLC
    cpu.setFlag('C', false);
    goto L_00EA1B;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1A CLC
    cpu.setFlag('C', false);
    goto L_00EA1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA1Au,0x00EA1Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA1Bu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu, 5u + 1u, 3u, cpu.address("absy", 0xE90Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1B ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xE90Du), cpu.m8?8:16));
    goto L_00EA1E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu, 5u + ((((0xE90Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1B ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xE90Du), cpu.m8?8:16));
    goto L_00EA1E;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu, 5u + 1u, 3u, cpu.address("absy", 0xE90Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1B ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xE90Du), cpu.m8?8:16));
    goto L_00EA1E;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu, 5u + ((((0xE90Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1B ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xE90Du), cpu.m8?8:16));
    goto L_00EA1E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA1Bu,0x00EA1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA1Eu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1E STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00EA20;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1E STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00EA20;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1E STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00EA20;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1E STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00EA20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA1Eu,0x00EA1Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA20u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA20u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA20u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA20 SEP
    cpu.sep(0x20u);
    goto L_00EA22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA20u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA20u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA20 SEP
    cpu.sep(0x20u);
    goto L_00EA22;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA20u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA20u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA20 SEP
    cpu.sep(0x20u);
    goto L_00EA22;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA20u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA20u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA20 SEP
    cpu.sep(0x20u);
    goto L_00EA22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA20u,0x00EA20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA22u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA24u,0x00EA22u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA24u,0x00EA22u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA24u,0x00EA22u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA24u,0x00EA22u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA22u,0x00EA22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E0M1X1CQ_part15(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EED1u: goto L_00EED1;
    case 0x00EED4u: goto L_00EED4;
    case 0x00EED6u: goto L_00EED6;
    case 0x00EED7u: goto L_00EED7;
    case 0x00EED9u: goto L_00EED9;
    case 0x00EEDBu: goto L_00EEDB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED1u))return;
  // 27 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED1u,0x00EED1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED4u))return;
  // 27 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED4u,0x00EED4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED6u))return;
  // 27 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    goto L_00EED7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    goto L_00EED7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    goto L_00EED7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    goto L_00EED7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    goto L_00EED7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED6u,0x00EED6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED7u))return;
  // 26 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED7u,0x00EED7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED9u))return;
  // 26 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED9u,0x00EED9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEDBu))return;
  // 26 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDBu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDBu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDBu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDBu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDBu,0x00EEDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1C1_part15(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EEEBu: goto L_00EEEB;
    case 0x00EEEDu: goto L_00EEED;
    case 0x00EEEFu: goto L_00EEEF;
    case 0x00EEF2u: goto L_00EEF2;
    case 0x00EEF4u: goto L_00EEF4;
    case 0x00EEF6u: goto L_00EEF6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEBu))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEBu,0x00EEEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEDu))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEDu,0x00EEEDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEFu))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 5u, 3u, cpu.address("abs", 0x13EEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 5u, 3u, cpu.address("abs", 0x13EEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEFu,0x00EEEFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF2u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEF4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEF4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEF4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEF4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF2u,0x00EEF2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF4u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF4 AND
    cpu.logicAnd(0xF004u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF7u,0x00EEF4u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF4 AND
    cpu.logicAnd(0xF004u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF7u,0x00EEF4u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF4 AND
    cpu.logicAnd(0x4u);
    goto L_00EEF6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF4 AND
    cpu.logicAnd(0x4u);
    goto L_00EEF6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF4u,0x00EEF4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF6u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF6 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEF6u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF8u,0x00EEF6u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF6 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEF6u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF8u,0x00EEF6u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF6u,0x00EEF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part15(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EEEBu: goto L_00EEEB;
    case 0x00EEEDu: goto L_00EEED;
    case 0x00EEEFu: goto L_00EEEF;
    case 0x00EEF2u: goto L_00EEF2;
    case 0x00EEF4u: goto L_00EEF4;
    case 0x00EEF6u: goto L_00EEF6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEBu))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEBu,0x00EEEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEDu))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEDu,0x00EEEDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEFu))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 5u, 3u, cpu.address("abs", 0x13EEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 5u, 3u, cpu.address("abs", 0x13EEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEFu,0x00EEEFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF2u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEF4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEF4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEF4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEF4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF2u,0x00EEF2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF4u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF4 AND
    cpu.logicAnd(0xF004u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF7u,0x00EEF4u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF4 AND
    cpu.logicAnd(0xF004u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF7u,0x00EEF4u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF4 AND
    cpu.logicAnd(0x4u);
    goto L_00EEF6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF4 AND
    cpu.logicAnd(0x4u);
    goto L_00EEF6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF4u,0x00EEF4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF6u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF6 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEF6u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF8u,0x00EEF6u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF6 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEF6u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF8u,0x00EEF6u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF6u,0x00EEF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_018869_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018869u: goto L_018869;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018869 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018869u);return;} hw.unresolvedReturn(0x018869u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_018869_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018869u: goto L_018869;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018869 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018869u);return;} hw.unresolvedReturn(0x018869u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_028F8B_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x028F8Bu: goto L_028F8B;
    case 0x028F8Du: goto L_028F8D;
    case 0x028F8Fu: goto L_028F8F;
    case 0x028F91u: goto L_028F91;
    case 0x028F93u: goto L_028F93;
    case 0x028F95u: goto L_028F95;
    case 0x028F97u: goto L_028F97;
    case 0x028F9Au: goto L_028F9A;
    case 0x028F9Cu: goto L_028F9C;
    case 0x028F9Du: goto L_028F9D;
    case 0x028F9Eu: goto L_028F9E;
    case 0x028FA1u: goto L_028FA1;
    case 0x028FA4u: goto L_028FA4;
    case 0x028FA5u: goto L_028FA5;
    case 0x028FA8u: goto L_028FA8;
    case 0x028FABu: goto L_028FAB;
    case 0x028FADu: goto L_028FAD;
    case 0x028FB0u: goto L_028FB0;
    case 0x028FB2u: goto L_028FB2;
    case 0x028FB3u: goto L_028FB3;
    case 0x028FB4u: goto L_028FB4;
    case 0x028FB7u: goto L_028FB7;
    case 0x028FBAu: goto L_028FBA;
    case 0x028FBBu: goto L_028FBB;
    case 0x028FBEu: goto L_028FBE;
    case 0x028FC1u: goto L_028FC1;
    case 0x028FC3u: goto L_028FC3;
    case 0x028FC5u: goto L_028FC5;
    case 0x028FC7u: goto L_028FC7;
    case 0x028FCAu: goto L_028FCA;
    case 0x028FCDu: goto L_028FCD;
    case 0x028FCEu: goto L_028FCE;
    case 0x028FD0u: goto L_028FD0;
    case 0x028FD2u: goto L_028FD2;
    case 0x028FD5u: goto L_028FD5;
    case 0x028FD7u: goto L_028FD7;
    case 0x028FD9u: goto L_028FD9;
    case 0x028FDBu: goto L_028FDB;
    case 0x028FDDu: goto L_028FDD;
    case 0x028FE0u: goto L_028FE0;
    case 0x028FE3u: goto L_028FE3;
    case 0x028FE4u: goto L_028FE4;
    case 0x028FE6u: goto L_028FE6;
    case 0x028FE8u: goto L_028FE8;
    case 0x028FEBu: goto L_028FEB;
    case 0x028FEDu: goto L_028FED;
    case 0x028FEFu: goto L_028FEF;
    case 0x028FF1u: goto L_028FF1;
    case 0x028FF4u: goto L_028FF4;
    case 0x028FF6u: goto L_028FF6;
    case 0x028FF8u: goto L_028FF8;
    case 0x028FFAu: goto L_028FFA;
    case 0x028FFDu: goto L_028FFD;
    case 0x029000u: goto L_029000;
    case 0x029001u: goto L_029001;
    case 0x029003u: goto L_029003;
    case 0x029004u: goto L_029004;
    case 0x029005u: goto L_029005;
    case 0x029008u: goto L_029008;
    case 0x02900Au: goto L_02900A;
    case 0x02900Bu: goto L_02900B;
    case 0x02900Eu: goto L_02900E;
    case 0x029011u: goto L_029011;
    case 0x029012u: goto L_029012;
    case 0x029014u: goto L_029014;
    case 0x029016u: goto L_029016;
    case 0x029018u: goto L_029018;
    case 0x02901Bu: goto L_02901B;
    case 0x02901Du: goto L_02901D;
    case 0x029020u: goto L_029020;
    case 0x029023u: goto L_029023;
    case 0x029024u: goto L_029024;
    case 0x029025u: goto L_029025;
    case 0x029026u: goto L_029026;
    case 0x029027u: goto L_029027;
    case 0x029029u: goto L_029029;
    case 0x02902Cu: goto L_02902C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_028F8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F8B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028F8D;
L_028F8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F8D BNE -> $028FCA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_028FCA; }
    goto L_028F8F;
L_028F8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F8F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028F91;
L_028F91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F91u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F91 AND
    cpu.logicAnd(0x3u);
    goto L_028F93;
L_028F93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F93u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F93 BEQ -> $028FAB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_028FAB; }
    goto L_028F95;
L_028F95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F95u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F95u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F95 LDY
    cpu.setY(0x0u, 8);
    goto L_028F97;
L_028F97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F97u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F97u, 4u + ((((0x182Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x182Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F97 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x182Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028F9A;
L_028F9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F9A BPL -> $028F9D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_028F9D; }
    goto L_028F9C;
L_028F9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F9C DEY
    cpu.decReg('Y');
    goto L_028F9D;
L_028F9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F9D CLC
    cpu.setFlag('C', false);
    goto L_028F9E;
L_028F9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Eu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Eu, 4u + ((((0x1808u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1808u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F9E ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x1808u), cpu.m8?8:16));
    goto L_028FA1;
L_028FA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA1u, 5u, 3u, cpu.address("absx", 0x1808u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FA1 STA
    hw.write(cpu.address("absx", 0x1808u), cpu.a, cpu.m8?8:16);
    goto L_028FA4;
L_028FA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FA4 TYA
    cpu.transfer("TYA");
    goto L_028FA5;
L_028FA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA5u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA5u, 4u + ((((0x18EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x18EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FA5 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x18EAu), cpu.m8?8:16));
    goto L_028FA8;
L_028FA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA8u, 5u, 3u, cpu.address("absx", 0x18EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FA8 STA
    hw.write(cpu.address("absx", 0x18EAu), cpu.a, cpu.m8?8:16);
    goto L_028FAB;
L_028FAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FABu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FAB LDY
    cpu.setY(0x0u, 8);
    goto L_028FAD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FABu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FAB LDY
    cpu.setY(0x0u, 8);
    goto L_028FAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FABu,0x028FABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028FAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FADu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FADu, 4u + ((((0x1820u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1820u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FAD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1820u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FB0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FADu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FADu, 4u + ((((0x1820u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1820u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FAD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1820u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FADu,0x028FADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028FB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FB0 BPL -> $028FB3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_028FB3; }
    goto L_028FB2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FB0 BPL -> $028FB3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_028FB3; }
    goto L_028FB2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FB0u,0x028FB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028FB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FB2 DEY
    cpu.decReg('Y');
    goto L_028FB3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FB2 DEY
    cpu.decReg('Y');
    goto L_028FB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FB2u,0x028FB2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028FB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FB3 CLC
    cpu.setFlag('C', false);
    goto L_028FB4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FB3 CLC
    cpu.setFlag('C', false);
    goto L_028FB4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FB3u,0x028FB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028FB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB4u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB4u, 4u + ((((0x17FCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x17FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FB4 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x17FCu), cpu.m8?8:16));
    goto L_028FB7;
L_028FB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB7u, 5u, 3u, cpu.address("absx", 0x17FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FB7 STA
    hw.write(cpu.address("absx", 0x17FCu), cpu.a, cpu.m8?8:16);
    goto L_028FBA;
L_028FBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBAu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FBA TYA
    cpu.transfer("TYA");
    goto L_028FBB;
L_028FBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBBu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBBu, 4u + ((((0x1814u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1814u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FBB ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x1814u), cpu.m8?8:16));
    goto L_028FBE;
L_028FBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBEu, 5u, 3u, cpu.address("absx", 0x1814u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FBE STA
    hw.write(cpu.address("absx", 0x1814u), cpu.a, cpu.m8?8:16);
    goto L_028FC1;
L_028FC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FC1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FC3;
L_028FC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FC3 AND
    cpu.logicAnd(0x3u);
    goto L_028FC5;
L_028FC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FC5 BNE -> $028FCA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_028FCA; }
    goto L_028FC7;
L_028FC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC7u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC7u, 7u, 3u, cpu.address("absx", 0x1820u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FC7 INC
    cpu.incMem(hw, cpu.address("absx", 0x1820u), cpu.m8?8:16);
    goto L_028FCA;
L_028FCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCAu, 4u + ((((0x17FCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x17FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FCA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x17FCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FCD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCAu, 4u + ((((0x17FCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x17FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FCA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x17FCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FCD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FCAu,0x028FCAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028FCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FCD SEC
    cpu.setFlag('C', true);
    goto L_028FCE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FCD SEC
    cpu.setFlag('C', true);
    goto L_028FCE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FCDu,0x028FCDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028FCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCEu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FCE SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_028FD0;
L_028FD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FD0 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_028FD2;
L_028FD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD2u, 4u + ((((0x1814u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1814u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FD2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1814u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FD5;
L_028FD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FD5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Du), cpu.m8?8:16));
    goto L_028FD7;
L_028FD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FD7 BEQ -> $028FDD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_028FDD; }
    goto L_028FD9;
L_028FD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FD9 BPL -> $028F87
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x028F87u,0x028FD9u); return; }
    goto L_028FDB;
L_028FDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDBu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FDB BMI -> $02902C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_02902C; }
    goto L_028FDD;
L_028FDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDDu, 4u + ((((0x8B78u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8B78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FDD LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x8B78u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_028FE0;
L_028FE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE0u, 4u + ((((0x1808u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1808u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FE0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1808u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FE3;
L_028FE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE3u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FE3 SEC
    cpu.setFlag('C', true);
    goto L_028FE4;
L_028FE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE4u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FE4 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_028FE6;
L_028FE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FE6 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_028FE8;
L_028FE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u, 4u + ((((0x18EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x18EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FE8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x18EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FEB;
L_028FEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEBu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FEB SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16));
    goto L_028FED;
L_028FED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FED BNE -> $028F87
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x028F87u,0x028FEDu); return; }
    goto L_028FEF;
L_028FEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FEF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FF1;
L_028FF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF1u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF1u, 5u, 3u, cpu.address("absy", 0x0200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FF1 STA
    hw.write(cpu.address("absy", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_028FF4;
L_028FF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FF4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FF6;
L_028FF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FF6 CMP
    cpu.compareA(0xF0u);
    goto L_028FF8;
L_028FF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FF8 BCS -> $028F87
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x028F87u,0x028FF8u); return; }
    goto L_028FFA;
L_028FFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFAu, 5u, 3u, cpu.address("absy", 0x0201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FFA STA
    hw.write(cpu.address("absy", 0x201u), cpu.a, cpu.m8?8:16);
    goto L_028FFD;
L_028FFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFDu, 4u + ((((0x1850u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1850u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FFD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1850u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029000;
L_029000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $029000 PHA
    cpu.push("PHA", hw);
    goto L_029001;
L_029001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9001u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9001u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029001 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029003;
L_029003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9003u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9003u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029003 LSR
    cpu.lsrA();
    goto L_029004;
L_029004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9004u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9004u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9004u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029004 CLC
    cpu.setFlag('C', false);
    goto L_029005;
L_029005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9005u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9005u, 4u, 3u, cpu.address("abs", 0x1698u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029005 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1698u), cpu.m8?8:16));
    goto L_029008;
L_029008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9008u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9008u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029008 AND
    cpu.logicAnd(0x7u);
    goto L_02900A;
L_02900A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02900A TAX
    cpu.transfer("TAX");
    goto L_02900B;
L_02900B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Bu, 4u + ((((0x8B84u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8B84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02900B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8B84u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02900E;
L_02900E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Eu, 5u, 3u, cpu.address("absy", 0x0202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02900E STA
    hw.write(cpu.address("absy", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_029011;
L_029011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9011u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9011u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $029011 PLA
    cpu.pop("PLA", hw);
    goto L_029012;
L_029012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029012 BEQ -> $029018
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_029018; }
    goto L_029014;
L_029014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029014 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029016;
L_029016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9016u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9016u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029016 AND
    cpu.logicAnd(0xEu);
    goto L_029018;
L_029018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9018u,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9018u, 4u + ((((0x8B8Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8B8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029018 EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0x8B8Cu), cpu.m8?8:16));
    goto L_02901B;
L_02901B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Bu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02901B ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16));
    goto L_02901D;
L_02901D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du, 5u, 3u, cpu.address("absy", 0x0203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02901D STA
    hw.write(cpu.address("absy", 0x203u), cpu.a, cpu.m8?8:16);
    goto L_029020;
L_029020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9020u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9020u, 4u, 3u, cpu.address("abs", 0x1698u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029020 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1698u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_029023;
L_029023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029023 TYA
    cpu.transfer("TYA");
    goto L_029024;
L_029024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9024u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9024u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029024 LSR
    cpu.lsrA();
    goto L_029025;
L_029025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9025u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9025u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029025 LSR
    cpu.lsrA();
    goto L_029026;
L_029026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029026 TAY
    cpu.transfer("TAY");
    goto L_029027;
L_029027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9027u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9027u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029027 LDA
    cpu.setA(0x0u, 8);
    goto L_029029;
L_029029:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9029u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9029u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9029u, 5u, 3u, cpu.address("absy", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029029 STA
    hw.write(cpu.address("absy", 0x420u), cpu.a, cpu.m8?8:16);
    goto L_02902C;
L_02902C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02902C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02902Cu);return;} hw.unresolvedReturn(0x02902Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_028F8B_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x028F8Bu: goto L_028F8B;
    case 0x028F8Du: goto L_028F8D;
    case 0x028F8Fu: goto L_028F8F;
    case 0x028F91u: goto L_028F91;
    case 0x028F93u: goto L_028F93;
    case 0x028F95u: goto L_028F95;
    case 0x028F97u: goto L_028F97;
    case 0x028F9Au: goto L_028F9A;
    case 0x028F9Cu: goto L_028F9C;
    case 0x028F9Du: goto L_028F9D;
    case 0x028F9Eu: goto L_028F9E;
    case 0x028FA1u: goto L_028FA1;
    case 0x028FA4u: goto L_028FA4;
    case 0x028FA5u: goto L_028FA5;
    case 0x028FA8u: goto L_028FA8;
    case 0x028FABu: goto L_028FAB;
    case 0x028FADu: goto L_028FAD;
    case 0x028FB0u: goto L_028FB0;
    case 0x028FB2u: goto L_028FB2;
    case 0x028FB3u: goto L_028FB3;
    case 0x028FB4u: goto L_028FB4;
    case 0x028FB7u: goto L_028FB7;
    case 0x028FBAu: goto L_028FBA;
    case 0x028FBBu: goto L_028FBB;
    case 0x028FBEu: goto L_028FBE;
    case 0x028FC1u: goto L_028FC1;
    case 0x028FC3u: goto L_028FC3;
    case 0x028FC5u: goto L_028FC5;
    case 0x028FC7u: goto L_028FC7;
    case 0x028FCAu: goto L_028FCA;
    case 0x028FCDu: goto L_028FCD;
    case 0x028FCEu: goto L_028FCE;
    case 0x028FD0u: goto L_028FD0;
    case 0x028FD2u: goto L_028FD2;
    case 0x028FD5u: goto L_028FD5;
    case 0x028FD7u: goto L_028FD7;
    case 0x028FD9u: goto L_028FD9;
    case 0x028FDBu: goto L_028FDB;
    case 0x028FDDu: goto L_028FDD;
    case 0x028FE0u: goto L_028FE0;
    case 0x028FE3u: goto L_028FE3;
    case 0x028FE4u: goto L_028FE4;
    case 0x028FE6u: goto L_028FE6;
    case 0x028FE8u: goto L_028FE8;
    case 0x028FEBu: goto L_028FEB;
    case 0x028FEDu: goto L_028FED;
    case 0x028FEFu: goto L_028FEF;
    case 0x028FF1u: goto L_028FF1;
    case 0x028FF4u: goto L_028FF4;
    case 0x028FF6u: goto L_028FF6;
    case 0x028FF8u: goto L_028FF8;
    case 0x028FFAu: goto L_028FFA;
    case 0x028FFDu: goto L_028FFD;
    case 0x029000u: goto L_029000;
    case 0x029001u: goto L_029001;
    case 0x029003u: goto L_029003;
    case 0x029004u: goto L_029004;
    case 0x029005u: goto L_029005;
    case 0x029008u: goto L_029008;
    case 0x02900Au: goto L_02900A;
    case 0x02900Bu: goto L_02900B;
    case 0x02900Eu: goto L_02900E;
    case 0x029011u: goto L_029011;
    case 0x029012u: goto L_029012;
    case 0x029014u: goto L_029014;
    case 0x029016u: goto L_029016;
    case 0x029018u: goto L_029018;
    case 0x02901Bu: goto L_02901B;
    case 0x02901Du: goto L_02901D;
    case 0x029020u: goto L_029020;
    case 0x029023u: goto L_029023;
    case 0x029024u: goto L_029024;
    case 0x029025u: goto L_029025;
    case 0x029026u: goto L_029026;
    case 0x029027u: goto L_029027;
    case 0x029029u: goto L_029029;
    case 0x02902Cu: goto L_02902C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_028F8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F8B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028F8D;
L_028F8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F8D BNE -> $028FCA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_028FCA; }
    goto L_028F8F;
L_028F8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F8F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028F91;
L_028F91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F91u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F91 AND
    cpu.logicAnd(0x3u);
    goto L_028F93;
L_028F93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F93u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F93 BEQ -> $028FAB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_028FAB; }
    goto L_028F95;
L_028F95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F95u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F95u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F95 LDY
    cpu.setY(0x0u, 8);
    goto L_028F97;
L_028F97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F97u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F97u, 4u + ((((0x182Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x182Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F97 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x182Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028F9A;
L_028F9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F9A BPL -> $028F9D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_028F9D; }
    goto L_028F9C;
L_028F9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F9C DEY
    cpu.decReg('Y');
    goto L_028F9D;
L_028F9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F9D CLC
    cpu.setFlag('C', false);
    goto L_028F9E;
L_028F9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Eu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Eu, 4u + ((((0x1808u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1808u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F9E ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x1808u), cpu.m8?8:16));
    goto L_028FA1;
L_028FA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA1u, 5u, 3u, cpu.address("absx", 0x1808u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FA1 STA
    hw.write(cpu.address("absx", 0x1808u), cpu.a, cpu.m8?8:16);
    goto L_028FA4;
L_028FA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FA4 TYA
    cpu.transfer("TYA");
    goto L_028FA5;
L_028FA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA5u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA5u, 4u + ((((0x18EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x18EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FA5 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x18EAu), cpu.m8?8:16));
    goto L_028FA8;
L_028FA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA8u, 5u, 3u, cpu.address("absx", 0x18EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FA8 STA
    hw.write(cpu.address("absx", 0x18EAu), cpu.a, cpu.m8?8:16);
    goto L_028FAB;
L_028FAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FABu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FAB LDY
    cpu.setY(0x0u, 8);
    goto L_028FAD;
L_028FAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FADu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FADu, 4u + ((((0x1820u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1820u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FAD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1820u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FB0;
L_028FB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FB0 BPL -> $028FB3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_028FB3; }
    goto L_028FB2;
L_028FB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FB2 DEY
    cpu.decReg('Y');
    goto L_028FB3;
L_028FB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FB3 CLC
    cpu.setFlag('C', false);
    goto L_028FB4;
L_028FB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB4u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB4u, 4u + ((((0x17FCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x17FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FB4 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x17FCu), cpu.m8?8:16));
    goto L_028FB7;
L_028FB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB7u, 5u, 3u, cpu.address("absx", 0x17FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FB7 STA
    hw.write(cpu.address("absx", 0x17FCu), cpu.a, cpu.m8?8:16);
    goto L_028FBA;
L_028FBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBAu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FBA TYA
    cpu.transfer("TYA");
    goto L_028FBB;
L_028FBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBBu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBBu, 4u + ((((0x1814u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1814u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FBB ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x1814u), cpu.m8?8:16));
    goto L_028FBE;
L_028FBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBEu, 5u, 3u, cpu.address("absx", 0x1814u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FBE STA
    hw.write(cpu.address("absx", 0x1814u), cpu.a, cpu.m8?8:16);
    goto L_028FC1;
L_028FC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FC1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FC3;
L_028FC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FC3 AND
    cpu.logicAnd(0x3u);
    goto L_028FC5;
L_028FC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FC5 BNE -> $028FCA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_028FCA; }
    goto L_028FC7;
L_028FC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC7u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC7u, 7u, 3u, cpu.address("absx", 0x1820u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FC7 INC
    cpu.incMem(hw, cpu.address("absx", 0x1820u), cpu.m8?8:16);
    goto L_028FCA;
L_028FCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCAu, 4u + ((((0x17FCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x17FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FCA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x17FCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FCD;
L_028FCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FCD SEC
    cpu.setFlag('C', true);
    goto L_028FCE;
L_028FCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCEu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FCE SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_028FD0;
L_028FD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FD0 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_028FD2;
L_028FD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD2u, 4u + ((((0x1814u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1814u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FD2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1814u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FD5;
L_028FD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FD5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Du), cpu.m8?8:16));
    goto L_028FD7;
L_028FD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FD7 BEQ -> $028FDD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_028FDD; }
    goto L_028FD9;
L_028FD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FD9 BPL -> $028F87
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x028F87u,0x028FD9u); return; }
    goto L_028FDB;
L_028FDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDBu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FDB BMI -> $02902C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_02902C; }
    goto L_028FDD;
L_028FDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDDu, 4u + ((((0x8B78u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8B78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FDD LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x8B78u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_028FE0;
L_028FE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE0u, 4u + ((((0x1808u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1808u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FE0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1808u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FE3;
L_028FE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE3u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FE3 SEC
    cpu.setFlag('C', true);
    goto L_028FE4;
L_028FE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE4u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FE4 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_028FE6;
L_028FE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FE6 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_028FE8;
L_028FE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u, 4u + ((((0x18EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x18EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FE8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x18EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FEB;
L_028FEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEBu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FEB SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16));
    goto L_028FED;
L_028FED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FED BNE -> $028F87
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x028F87u,0x028FEDu); return; }
    goto L_028FEF;
L_028FEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FEF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FF1;
L_028FF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF1u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF1u, 5u, 3u, cpu.address("absy", 0x0200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FF1 STA
    hw.write(cpu.address("absy", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_028FF4;
L_028FF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FF4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028FF6;
L_028FF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FF6 CMP
    cpu.compareA(0xF0u);
    goto L_028FF8;
L_028FF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FF8 BCS -> $028F87
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x028F87u,0x028FF8u); return; }
    goto L_028FFA;
L_028FFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFAu, 5u, 3u, cpu.address("absy", 0x0201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FFA STA
    hw.write(cpu.address("absy", 0x201u), cpu.a, cpu.m8?8:16);
    goto L_028FFD;
L_028FFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFDu, 4u + ((((0x1850u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1850u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028FFD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1850u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029000;
L_029000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $029000 PHA
    cpu.push("PHA", hw);
    goto L_029001;
L_029001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9001u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9001u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029001 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029003;
L_029003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9003u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9003u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029003 LSR
    cpu.lsrA();
    goto L_029004;
L_029004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9004u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9004u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9004u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029004 CLC
    cpu.setFlag('C', false);
    goto L_029005;
L_029005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9005u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9005u, 4u, 3u, cpu.address("abs", 0x1698u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029005 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1698u), cpu.m8?8:16));
    goto L_029008;
L_029008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9008u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9008u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029008 AND
    cpu.logicAnd(0x7u);
    goto L_02900A;
L_02900A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02900A TAX
    cpu.transfer("TAX");
    goto L_02900B;
L_02900B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Bu, 4u + ((((0x8B84u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8B84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02900B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8B84u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02900E;
L_02900E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Eu, 5u, 3u, cpu.address("absy", 0x0202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02900E STA
    hw.write(cpu.address("absy", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_029011;
L_029011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9011u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9011u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $029011 PLA
    cpu.pop("PLA", hw);
    goto L_029012;
L_029012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029012 BEQ -> $029018
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_029018; }
    goto L_029014;
L_029014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029014 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029016;
L_029016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9016u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9016u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029016 AND
    cpu.logicAnd(0xEu);
    goto L_029018;
L_029018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9018u,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9018u, 4u + ((((0x8B8Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8B8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029018 EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0x8B8Cu), cpu.m8?8:16));
    goto L_02901B;
L_02901B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Bu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02901B ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16));
    goto L_02901D;
L_02901D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du, 5u, 3u, cpu.address("absy", 0x0203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02901D STA
    hw.write(cpu.address("absy", 0x203u), cpu.a, cpu.m8?8:16);
    goto L_029020;
L_029020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9020u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9020u, 4u, 3u, cpu.address("abs", 0x1698u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029020 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1698u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_029023;
L_029023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029023 TYA
    cpu.transfer("TYA");
    goto L_029024;
L_029024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9024u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9024u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029024 LSR
    cpu.lsrA();
    goto L_029025;
L_029025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9025u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9025u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029025 LSR
    cpu.lsrA();
    goto L_029026;
L_029026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029026 TAY
    cpu.transfer("TAY");
    goto L_029027;
L_029027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9027u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9027u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029027 LDA
    cpu.setA(0x0u, 8);
    goto L_029029;
L_029029:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9029u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9029u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9029u, 5u, 3u, cpu.address("absy", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029029 STA
    hw.write(cpu.address("absy", 0x420u), cpu.a, cpu.m8?8:16);
    goto L_02902C;
L_02902C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02902C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02902Cu);return;} hw.unresolvedReturn(0x02902Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02C726_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02C726u: goto L_02C726;
    case 0x02C728u: goto L_02C728;
    case 0x02C72Bu: goto L_02C72B;
    case 0x02C72Eu: goto L_02C72E;
    case 0x02C730u: goto L_02C730;
    case 0x02C733u: goto L_02C733;
    case 0x02C735u: goto L_02C735;
    case 0x02C737u: goto L_02C737;
    case 0x02C739u: goto L_02C739;
    case 0x02C73Cu: goto L_02C73C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02C726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC726u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC726u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C726 LDA
    cpu.setA(0x3u, 8);
    goto L_02C728;
L_02C728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC728u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC728u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C728 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_02C72B;
L_02C72B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Bu, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C72B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C72E;
L_02C72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C72E BNE -> $02C73C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02C73C; }
    goto L_02C730;
L_02C730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC730u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC730u, 6u, 3u, cpu.address("abs", 0xC628u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02C730 JSR -> $02C628 stack real
    { cpu.push16Value(hw,0xC732u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC733u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC628u), 0x02C730u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02C733;
L_02C733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC733u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC733u,0x02C733u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC733u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC733u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C733 LDA
    cpu.setA(0x1u, 8);
    goto L_02C735;
L_02C735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC735u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC735u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C735 STA
    hw.write(cpu.address("dpx", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_02C737;
L_02C737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC737u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC737u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C737 LDA
    cpu.setA(0x40u, 8);
    goto L_02C739;
L_02C739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC739u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC739u, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C739 STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_02C73C;
L_02C73C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02C73C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02C73Cu);return;} hw.unresolvedReturn(0x02C73Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02C726_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02C726u: goto L_02C726;
    case 0x02C728u: goto L_02C728;
    case 0x02C72Bu: goto L_02C72B;
    case 0x02C72Eu: goto L_02C72E;
    case 0x02C730u: goto L_02C730;
    case 0x02C733u: goto L_02C733;
    case 0x02C735u: goto L_02C735;
    case 0x02C737u: goto L_02C737;
    case 0x02C739u: goto L_02C739;
    case 0x02C73Cu: goto L_02C73C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02C726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC726u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC726u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C726 LDA
    cpu.setA(0x3u, 8);
    goto L_02C728;
L_02C728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC728u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC728u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C728 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_02C72B;
L_02C72B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Bu, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C72B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C72E;
L_02C72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C72E BNE -> $02C73C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02C73C; }
    goto L_02C730;
L_02C730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC730u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC730u, 6u, 3u, cpu.address("abs", 0xC628u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02C730 JSR -> $02C628 stack real
    { cpu.push16Value(hw,0xC732u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC733u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC628u), 0x02C730u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02C733;
L_02C733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC733u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC733u,0x02C733u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC733u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC733u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C733 LDA
    cpu.setA(0x1u, 8);
    goto L_02C735;
L_02C735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC735u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC735u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C735 STA
    hw.write(cpu.address("dpx", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_02C737;
L_02C737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC737u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC737u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C737 LDA
    cpu.setA(0x40u, 8);
    goto L_02C739;
L_02C739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC739u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC739u, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C739 STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_02C73C;
L_02C73C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02C73C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02C73Cu);return;} hw.unresolvedReturn(0x02C73Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02D1F3_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02D1F3u: goto L_02D1F3;
    case 0x02D1F6u: goto L_02D1F6;
    case 0x02D1F8u: goto L_02D1F8;
    case 0x02D1FBu: goto L_02D1FB;
    case 0x02D1FDu: goto L_02D1FD;
    case 0x02D200u: goto L_02D200;
    case 0x02D202u: goto L_02D202;
    case 0x02D205u: goto L_02D205;
    case 0x02D207u: goto L_02D207;
    case 0x02D209u: goto L_02D209;
    case 0x02D20Bu: goto L_02D20B;
    case 0x02D20Fu: goto L_02D20F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02D1F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F3u, 4u, 3u, cpu.address("abs", 0x18B0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1F3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18B0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D1F6;
L_02D1F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1F6 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_02D1F8;
L_02D1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F8u, 4u, 3u, cpu.address("abs", 0x18B1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1F8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18B1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D1FB;
L_02D1FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1FB STA
    hw.write(cpu.address("dp", 0x9Bu), cpu.a, cpu.m8?8:16);
    goto L_02D1FD;
L_02D1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FDu, 4u, 3u, cpu.address("abs", 0x18B2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1FD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18B2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D200;
L_02D200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD200u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD200u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D200 STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_02D202;
L_02D202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD202u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD202u, 4u, 3u, cpu.address("abs", 0x18B3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D202 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18B3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D205;
L_02D205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD205u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD205u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D205 STA
    hw.write(cpu.address("dp", 0x99u), cpu.a, cpu.m8?8:16);
    goto L_02D207;
L_02D207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD207u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD207u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D207 LDA
    cpu.setA(0x4u, 8);
    goto L_02D209;
L_02D209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD209u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD209u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D209 STA
    hw.write(cpu.address("dp", 0x9Cu), cpu.a, cpu.m8?8:16);
    goto L_02D20B;
L_02D20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD20Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD20Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD20Bu, 8u, 4u, 0x00BEB0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02D20B JSL -> $00BEB0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD20Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD20Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00BEB0u, 0x02D20Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02D20F;
L_02D20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD20Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD20Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD20Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02D20F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02D20Fu);return;} hw.unresolvedReturn(0x02D20Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD20Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD20Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02D20F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02D20Fu);return;} hw.unresolvedReturn(0x02D20Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD20Fu,0x02D20Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_03C2D9_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x03C2D9u: goto L_03C2D9;
    case 0x03C2DAu: goto L_03C2DA;
    case 0x03C2DCu: goto L_03C2DC;
    case 0x03C2DFu: goto L_03C2DF;
    case 0x03C2E1u: goto L_03C2E1;
    case 0x03C2E2u: goto L_03C2E2;
    case 0x03C2E4u: goto L_03C2E4;
    case 0x03C2E5u: goto L_03C2E5;
    case 0x03C2E6u: goto L_03C2E6;
    case 0x03C2E8u: goto L_03C2E8;
    case 0x03C2EBu: goto L_03C2EB;
    case 0x03C2EDu: goto L_03C2ED;
    case 0x03C2EFu: goto L_03C2EF;
    case 0x03C2F1u: goto L_03C2F1;
    case 0x03C2F3u: goto L_03C2F3;
    case 0x03C2F5u: goto L_03C2F5;
    case 0x03C2F8u: goto L_03C2F8;
    case 0x03C2FAu: goto L_03C2FA;
    case 0x03C2FCu: goto L_03C2FC;
    case 0x03C2FEu: goto L_03C2FE;
    case 0x03C301u: goto L_03C301;
    case 0x03C305u: goto L_03C305;
    case 0x03C307u: goto L_03C307;
    case 0x03C30Au: goto L_03C30A;
    case 0x03C30Du: goto L_03C30D;
    case 0x03C30Eu: goto L_03C30E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_03C2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2D9u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2D9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $03C2D9 PHX
    cpu.push("PHX", hw);
    goto L_03C2DA;
L_03C2DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2DAu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2DA LDX
    cpu.setX(0xBu, 8);
    goto L_03C2DC;
L_03C2DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2DCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2DCu, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2DC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C2DF;
L_03C2DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2DFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2DF BEQ -> $03C2E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_03C2E6; }
    goto L_03C2E1;
L_03C2E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2E1u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2E1 DEX
    cpu.decReg('X');
    goto L_03C2E2;
L_03C2E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2E2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2E2 BPL -> $03C2DC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_03C2DC; }
    goto L_03C2E4;
L_03C2E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2E4u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2E4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $03C2E4 PLX
    cpu.pop("PLX", hw);
    goto L_03C2E5;
L_03C2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2E5u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $03C2E5 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x03C2E5u);return;} hw.unresolvedReturn(0x03C2E5u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_03C2E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2E6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2E6 LDA
    cpu.setA(0x8u, 8);
    goto L_03C2E8;
L_03C2E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2E8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2E8u, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2E8 STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_03C2EB;
L_03C2EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2EB LDA
    cpu.setA(0x78u, 8);
    goto L_03C2ED;
L_03C2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2EDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2ED STA
    hw.write(cpu.address("dpx", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_03C2EF;
L_03C2EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2EFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2EFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2EF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C2F1;
L_03C2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2F1u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2F1 STA
    hw.write(cpu.address("dpx", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_03C2F3;
L_03C2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2F3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2F3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2F3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C2F5;
L_03C2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2F5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2F5u, 5u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2F5 STA
    hw.write(cpu.address("absx", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_03C2F8;
L_03C2F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2F8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2F8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2F8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C2FA;
L_03C2FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2FAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2FAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2FA STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_03C2FC;
L_03C2FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2FCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2FC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C2FE;
L_03C2FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2FEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2FEu, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C2FE STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_03C301;
L_03C301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC301u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC301u, 8u, 4u, 0x07F7D2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $03C301 JSL -> $07F7D2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC304u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC305u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F7D2u, 0x03C301u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_03C305;
L_03C305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC305u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC305u,0x03C305u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC305u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC305u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C305 LDA
    cpu.setA(0x10u, 8);
    goto L_03C307;
L_03C307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC307u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC307u, 5u, 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C307 STA
    hw.write(cpu.address("absx", 0x154Cu), cpu.a, cpu.m8?8:16);
    goto L_03C30A;
L_03C30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Au, 6u, 3u, cpu.address("abs", 0xC334u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $03C30A JSR -> $03C334 stack real
    { cpu.push16Value(hw,0xC30Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC30Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC334u), 0x03C30Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_03C30D;
L_03C30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC30Du,0x03C30Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Du,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $03C30D PLX
    cpu.pop("PLX", hw);
    goto L_03C30E;
L_03C30E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $03C30E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x03C30Eu);return;} hw.unresolvedReturn(0x03C30Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0DA95B_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA95Bu: goto L_0DA95B;
    case 0x0DA95Du: goto L_0DA95D;
    case 0x0DA95Eu: goto L_0DA95E;
    case 0x0DA95Fu: goto L_0DA95F;
    case 0x0DA961u: goto L_0DA961;
    case 0x0DA963u: goto L_0DA963;
    case 0x0DA965u: goto L_0DA965;
    case 0x0DA966u: goto L_0DA966;
    case 0x0DA968u: goto L_0DA968;
    case 0x0DA96Au: goto L_0DA96A;
    case 0x0DA96Cu: goto L_0DA96C;
    case 0x0DA96Eu: goto L_0DA96E;
    case 0x0DA970u: goto L_0DA970;
    case 0x0DA972u: goto L_0DA972;
    case 0x0DA974u: goto L_0DA974;
    case 0x0DA977u: goto L_0DA977;
    case 0x0DA979u: goto L_0DA979;
    case 0x0DA97Bu: goto L_0DA97B;
    case 0x0DA97Cu: goto L_0DA97C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA95B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Bu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DA95B STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA95D;
L_0DA95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA95D INY
    cpu.inc('Y');
    goto L_0DA95E;
L_0DA95E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA95E TYA
    cpu.transfer("TYA");
    goto L_0DA95F;
L_0DA95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA95F AND
    cpu.logicAnd(0xFu);
    goto L_0DA961;
L_0DA961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA961u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA961u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA961 BNE -> $0DA97C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA97C; }
    goto L_0DA963;
L_0DA963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA963u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA963u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA963 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA965;
L_0DA965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA965u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA965u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA965 CLC
    cpu.setFlag('C', false);
    goto L_0DA966;
L_0DA966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA966u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA966u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA966 ADC
    cpu.adc(0xB0u);
    goto L_0DA968;
L_0DA968:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA968u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA968u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA968u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA968 STA
    hw.write(cpu.address("dp", 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA96A;
L_0DA96A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA96A STA
    hw.write(cpu.address("dp", 0x6Eu), cpu.a, cpu.m8?8:16);
    goto L_0DA96C;
L_0DA96C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA96C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA96E;
L_0DA96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA96E ADC
    cpu.adc(0x1u);
    goto L_0DA970;
L_0DA970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA970u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA970u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA970 STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0DA972;
L_0DA972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA972u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA972u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA972u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA972 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0DA974;
L_0DA974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA974u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA974u, 6u, 3u, cpu.address("abs", 0x1BA1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA974 INC
    cpu.incMem(hw, cpu.address("abs", 0x1BA1u), cpu.m8?8:16);
    goto L_0DA977;
L_0DA977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA977u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA977u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA977 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA979;
L_0DA979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA979u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA979u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA979 AND
    cpu.logicAnd(0xF0u);
    goto L_0DA97B;
L_0DA97B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA97B TAY
    cpu.transfer("TAY");
    goto L_0DA97C;
L_0DA97C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA97C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA97Cu);return;} hw.unresolvedReturn(0x0DA97Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA97C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA97Cu);return;} hw.unresolvedReturn(0x0DA97Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA97Cu,0x0DA97Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_0DA95B_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA95Bu: goto L_0DA95B;
    case 0x0DA95Du: goto L_0DA95D;
    case 0x0DA95Eu: goto L_0DA95E;
    case 0x0DA95Fu: goto L_0DA95F;
    case 0x0DA961u: goto L_0DA961;
    case 0x0DA963u: goto L_0DA963;
    case 0x0DA965u: goto L_0DA965;
    case 0x0DA966u: goto L_0DA966;
    case 0x0DA968u: goto L_0DA968;
    case 0x0DA96Au: goto L_0DA96A;
    case 0x0DA96Cu: goto L_0DA96C;
    case 0x0DA96Eu: goto L_0DA96E;
    case 0x0DA970u: goto L_0DA970;
    case 0x0DA972u: goto L_0DA972;
    case 0x0DA974u: goto L_0DA974;
    case 0x0DA977u: goto L_0DA977;
    case 0x0DA979u: goto L_0DA979;
    case 0x0DA97Bu: goto L_0DA97B;
    case 0x0DA97Cu: goto L_0DA97C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA95B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Bu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DA95B STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA95D;
L_0DA95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA95D INY
    cpu.inc('Y');
    goto L_0DA95E;
L_0DA95E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA95E TYA
    cpu.transfer("TYA");
    goto L_0DA95F;
L_0DA95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA95F AND
    cpu.logicAnd(0xFu);
    goto L_0DA961;
L_0DA961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA961u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA961u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA961 BNE -> $0DA97C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA97C; }
    goto L_0DA963;
L_0DA963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA963u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA963u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA963 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA965;
L_0DA965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA965u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA965u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA965 CLC
    cpu.setFlag('C', false);
    goto L_0DA966;
L_0DA966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA966u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA966u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA966 ADC
    cpu.adc(0xB0u);
    goto L_0DA968;
L_0DA968:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA968u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA968u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA968u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA968 STA
    hw.write(cpu.address("dp", 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA96A;
L_0DA96A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA96A STA
    hw.write(cpu.address("dp", 0x6Eu), cpu.a, cpu.m8?8:16);
    goto L_0DA96C;
L_0DA96C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA96C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA96E;
L_0DA96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA96E ADC
    cpu.adc(0x1u);
    goto L_0DA970;
L_0DA970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA970u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA970u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA970 STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0DA972;
L_0DA972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA972u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA972u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA972u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA972 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0DA974;
L_0DA974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA974u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA974u, 6u, 3u, cpu.address("abs", 0x1BA1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA974 INC
    cpu.incMem(hw, cpu.address("abs", 0x1BA1u), cpu.m8?8:16);
    goto L_0DA977;
L_0DA977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA977u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA977u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA977 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA979;
L_0DA979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA979u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA979u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA979 AND
    cpu.logicAnd(0xF0u);
    goto L_0DA97B;
L_0DA97B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA97B TAY
    cpu.transfer("TAY");
    goto L_0DA97C;
L_0DA97C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA97C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA97Cu);return;} hw.unresolvedReturn(0x0DA97Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DA97D_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA97Du: goto L_0DA97D;
    case 0x0DA97Fu: goto L_0DA97F;
    case 0x0DA980u: goto L_0DA980;
    case 0x0DA982u: goto L_0DA982;
    case 0x0DA984u: goto L_0DA984;
    case 0x0DA985u: goto L_0DA985;
    case 0x0DA987u: goto L_0DA987;
    case 0x0DA989u: goto L_0DA989;
    case 0x0DA98Bu: goto L_0DA98B;
    case 0x0DA98Du: goto L_0DA98D;
    case 0x0DA98Fu: goto L_0DA98F;
    case 0x0DA991u: goto L_0DA991;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA97D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA97D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA97F;
L_0DA97F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA97F CLC
    cpu.setFlag('C', false);
    goto L_0DA980;
L_0DA980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA980u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA980u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA980 ADC
    cpu.adc(0x10u);
    goto L_0DA982;
L_0DA982:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA982u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA982u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA982u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA982 STA
    hw.write(cpu.address("dp", 0x57u), cpu.a, cpu.m8?8:16);
    goto L_0DA984;
L_0DA984:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA984u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA984u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA984u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA984 TAY
    cpu.transfer("TAY");
    goto L_0DA985;
L_0DA985:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA985u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA985u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA985u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA985 BCC -> $0DA991
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DA991; }
    goto L_0DA987;
L_0DA987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA987u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA987u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA987u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA987 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA989;
L_0DA989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA989u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA989u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA989u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA989 ADC
    cpu.adc(0x0u);
    goto L_0DA98B;
L_0DA98B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA98B STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0DA98D;
L_0DA98D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA98D STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0DA98F;
L_0DA98F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA98F STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_0DA991;
L_0DA991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA991u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA991u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA991u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA991 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA991u);return;} hw.unresolvedReturn(0x0DA991u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DA97D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA97Du: goto L_0DA97D;
    case 0x0DA97Fu: goto L_0DA97F;
    case 0x0DA980u: goto L_0DA980;
    case 0x0DA982u: goto L_0DA982;
    case 0x0DA984u: goto L_0DA984;
    case 0x0DA985u: goto L_0DA985;
    case 0x0DA987u: goto L_0DA987;
    case 0x0DA989u: goto L_0DA989;
    case 0x0DA98Bu: goto L_0DA98B;
    case 0x0DA98Du: goto L_0DA98D;
    case 0x0DA98Fu: goto L_0DA98F;
    case 0x0DA991u: goto L_0DA991;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA97D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA97D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA97F;
L_0DA97F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA97F CLC
    cpu.setFlag('C', false);
    goto L_0DA980;
L_0DA980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA980u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA980u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA980 ADC
    cpu.adc(0x10u);
    goto L_0DA982;
L_0DA982:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA982u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA982u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA982u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA982 STA
    hw.write(cpu.address("dp", 0x57u), cpu.a, cpu.m8?8:16);
    goto L_0DA984;
L_0DA984:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA984u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA984u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA984u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA984 TAY
    cpu.transfer("TAY");
    goto L_0DA985;
L_0DA985:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA985u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA985u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA985u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA985 BCC -> $0DA991
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DA991; }
    goto L_0DA987;
L_0DA987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA987u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA987u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA987u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA987 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA989;
L_0DA989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA989u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA989u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA989u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA989 ADC
    cpu.adc(0x0u);
    goto L_0DA98B;
L_0DA98B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA98B STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0DA98D;
L_0DA98D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA98D STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0DA98F;
L_0DA98F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA98F STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_0DA991;
L_0DA991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA991u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA991u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA991u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA991 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA991u);return;} hw.unresolvedReturn(0x0DA991u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0E8DD6_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0E8DD6u: goto L_0E8DD6;
    case 0x0E8DD7u: goto L_0E8DD7;
    case 0x0E8DD9u: goto L_0E8DD9;
    case 0x0E8DDAu: goto L_0E8DDA;
    case 0x0E8DDBu: goto L_0E8DDB;
    case 0x0E8DDDu: goto L_0E8DDD;
    case 0x0E8DE0u: goto L_0E8DE0;
    case 0x0E8DE2u: goto L_0E8DE2;
    case 0x0E8DE4u: goto L_0E8DE4;
    case 0x0E8DE6u: goto L_0E8DE6;
    case 0x0E8DE8u: goto L_0E8DE8;
    case 0x0E8DEAu: goto L_0E8DEA;
    case 0x0E8DECu: goto L_0E8DEC;
    case 0x0E8DEFu: goto L_0E8DEF;
    case 0x0E8DF0u: goto L_0E8DF0;
    case 0x0E8DF3u: goto L_0E8DF3;
    case 0x0E8DF4u: goto L_0E8DF4;
    case 0x0E8DF8u: goto L_0E8DF8;
    case 0x0E8DFAu: goto L_0E8DFA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0E8DD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DD6 INY
    cpu.inc('Y');
    goto L_0E8DD7;
L_0E8DD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD7u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DD7 ASL
    cpu.aslMem(hw, cpu.address("dp", 0xD0u), cpu.m8?8:16);
    goto L_0E8DD9;
L_0E8DD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD9u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DD9 SED
    cpu.setFlag('D', true);
    goto L_0E8DDA;
L_0E8DDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDAu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DDA XBA
    cpu.xba();
    goto L_0E8DDB;
L_0E8DDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDBu,cpu,0x16u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDBu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DDB ASL
    cpu.aslMem(hw, cpu.address("dpx", 0x6Fu), cpu.m8?8:16);
    goto L_0E8DDD;
L_0E8DDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDDu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDDu, 4u + ((((0xBD10u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xBD10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DDD LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xBD10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0E8DE0;
L_0E8DE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE0u,cpu,0x11u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xCBu) & 0xFFFFu), 2u, 0u);
    // $0E8DE0 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectY(hw, 0xCBu), cpu.m8?8:16));
    goto L_0E8DE2;
L_0E8DE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE2u,cpu,0x12u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xE9u) & 0xFFFFu), 2u, 0u);
    // $0E8DE2 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirect(hw, 0xE9u), cpu.m8?8:16));
    goto L_0E8DE4;
L_0E8DE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE4u,cpu,0x13u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE4u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x18u) & 0xFFFFu), 2u, 0u);
    // $0E8DE4 ORA
    cpu.logicOr(hw.readW(cpu.addressStackIndirectY(hw, 0x18u), cpu.m8?8:16));
    goto L_0E8DE6;
L_0E8DE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DE6 ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0x59u), cpu.m8?8:16));
    goto L_0E8DE8;
L_0E8DE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE8u,cpu,0x16u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xADu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DE8 ASL
    cpu.aslMem(hw, cpu.address("dpx", 0xADu), cpu.m8?8:16);
    goto L_0E8DEA;
L_0E8DEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEAu,cpu,0x17u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEAu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x16u) & 0xFFFFu), 3u, 0u);
    // $0E8DEA ORA
    cpu.logicOr(hw.readW(cpu.addressDpLongY(hw, 0x16u), cpu.m8?8:16));
    goto L_0E8DEC;
L_0E8DEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DECu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DECu, 4u + ((((0x1A94u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1A94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DEC ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x1A94u), cpu.m8?8:16));
    goto L_0E8DEF;
L_0E8DEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0E8DEF PLP
    cpu.pop("PLP", hw);
    goto L_0E8DF0;
L_0E8DF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF0u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u, 8u, 3u, cpu.address("abs", 0x1DD5u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF0 TRB
    cpu.trb(hw, cpu.address("abs", 0x1DD5u), cpu.m8?8:16);
    goto L_0E8DF3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u, 8u, 3u, cpu.address("abs", 0x1DD5u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF0 TRB
    cpu.trb(hw, cpu.address("abs", 0x1DD5u), cpu.m8?8:16);
    goto L_0E8DF3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u, 6u, 3u, cpu.address("abs", 0x1DD5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF0 TRB
    cpu.trb(hw, cpu.address("abs", 0x1DD5u), cpu.m8?8:16);
    goto L_0E8DF3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u, 6u, 3u, cpu.address("abs", 0x1DD5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF0 TRB
    cpu.trb(hw, cpu.address("abs", 0x1DD5u), cpu.m8?8:16);
    goto L_0E8DF3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DF0u,0x0E8DF0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0E8DF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF3u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF3 TXY
    cpu.transfer("TXY");
    goto L_0E8DF4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF3 TXY
    cpu.transfer("TXY");
    goto L_0E8DF4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF3 TXY
    cpu.transfer("TXY");
    goto L_0E8DF4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF3 TXY
    cpu.transfer("TXY");
    goto L_0E8DF4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DF3u,0x0E8DF3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0E8DF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF4u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u, 6u, 4u, ((0xAAE800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF4 ORA
    cpu.logicOr(hw.readW(((0xAAE800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0E8DF8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u, 6u, 4u, ((0xAAE800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF4 ORA
    cpu.logicOr(hw.readW(((0xAAE800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0E8DF8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u, 5u, 4u, ((0xAAE800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF4 ORA
    cpu.logicOr(hw.readW(((0xAAE800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0E8DF8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u, 5u, 4u, ((0xAAE800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF4 ORA
    cpu.logicOr(hw.readW(((0xAAE800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0E8DF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DF4u,0x0E8DF4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0E8DF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF8u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xF4u), cpu.m8?8:16));
    goto L_0E8DFA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xF4u), cpu.m8?8:16));
    goto L_0E8DFA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xF4u), cpu.m8?8:16));
    goto L_0E8DFA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8DF8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xF4u), cpu.m8?8:16));
    goto L_0E8DFA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DF8u,0x0E8DF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0E8DFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFAu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0E8DFA BRK
    hw.partial(0x0E8DFAu, "BRK"); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0E8DFA BRK
    hw.partial(0x0E8DFAu, "BRK"); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0E8DFA BRK
    hw.partial(0x0E8DFAu, "BRK"); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0E8DFA BRK
    hw.partial(0x0E8DFAu, "BRK"); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DFAu,0x0E8DFAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_808D80_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808D7Fu: goto L_808D7F;
    case 0x808D80u: goto L_808D80;
    case 0x808D82u: goto L_808D82;
    case 0x808D85u: goto L_808D85;
    case 0x808D86u: goto L_808D86;
    case 0x808D87u: goto L_808D87;
    case 0x808D88u: goto L_808D88;
    case 0x808D8Au: goto L_808D8A;
    case 0x808D8Cu: goto L_808D8C;
    case 0x808D8Fu: goto L_808D8F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808D7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu, 4u + ((((0x8C89u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8C89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D7F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8C89u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D82;
L_808D80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D80u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D80u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D80 BIT
    cpu.bit(0x8Cu, true);
    goto L_808D82;
L_808D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 5u, 3u, cpu.address("absx", 0x0EF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D82 STA
    hw.write(cpu.address("absx", 0xEF9u), cpu.a, cpu.m8?8:16);
    goto L_808D85;
L_808D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D85 DEY
    cpu.decReg('Y');
    goto L_808D86;
L_808D86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D86u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D86u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D86 DEY
    cpu.decReg('Y');
    goto L_808D87;
L_808D87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D87 DEX
    cpu.decReg('X');
    goto L_808D88;
L_808D88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D88 BPL -> $808D7F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808D7F; }
    goto L_808D8A;
L_808D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D8A LDA
    cpu.setA(0x28u, 8);
    goto L_808D8C;
L_808D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu, 4u, 3u, cpu.address("abs", 0x0F30u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D8C STA
    hw.write(cpu.address("abs", 0xF30u), cpu.a, cpu.m8?8:16);
    goto L_808D8F;
L_808D8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808D8F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x808D8Fu);return;} hw.unresolvedReturn(0x808D8Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B18CB7_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB18BC3u: goto L_B18BC3;
    case 0xB18BC6u: goto L_B18BC6;
    case 0xB18BC7u: goto L_B18BC7;
    case 0xB18BCAu: goto L_B18BCA;
    case 0xB18BCCu: goto L_B18BCC;
    case 0xB18BCEu: goto L_B18BCE;
    case 0xB18BD1u: goto L_B18BD1;
    case 0xB18BD3u: goto L_B18BD3;
    case 0xB18BD5u: goto L_B18BD5;
    case 0xB18BD7u: goto L_B18BD7;
    case 0xB18BD8u: goto L_B18BD8;
    case 0xB18BDBu: goto L_B18BDB;
    case 0xB18BDEu: goto L_B18BDE;
    case 0xB18BE0u: goto L_B18BE0;
    case 0xB18BE3u: goto L_B18BE3;
    case 0xB18BE5u: goto L_B18BE5;
    case 0xB18BE7u: goto L_B18BE7;
    case 0xB18BEAu: goto L_B18BEA;
    case 0xB18BECu: goto L_B18BEC;
    case 0xB18BEFu: goto L_B18BEF;
    case 0xB18BF0u: goto L_B18BF0;
    case 0xB18BF2u: goto L_B18BF2;
    case 0xB18BF3u: goto L_B18BF3;
    case 0xB18BF5u: goto L_B18BF5;
    case 0xB18BF7u: goto L_B18BF7;
    case 0xB18BFAu: goto L_B18BFA;
    case 0xB18BFBu: goto L_B18BFB;
    case 0xB18BFDu: goto L_B18BFD;
    case 0xB18C00u: goto L_B18C00;
    case 0xB18C03u: goto L_B18C03;
    case 0xB18C04u: goto L_B18C04;
    case 0xB18C07u: goto L_B18C07;
    case 0xB18C08u: goto L_B18C08;
    case 0xB18C0Au: goto L_B18C0A;
    case 0xB18C0Cu: goto L_B18C0C;
    case 0xB18C0Eu: goto L_B18C0E;
    case 0xB18C10u: goto L_B18C10;
    case 0xB18C13u: goto L_B18C13;
    case 0xB18C14u: goto L_B18C14;
    case 0xB18C17u: goto L_B18C17;
    case 0xB18CB7u: goto L_B18CB7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B18BC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BC3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BC6;
L_B18BC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18BC6 PHA
    cpu.push("PHA", hw);
    goto L_B18BC7;
L_B18BC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BC7 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15ACu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B18BCA;
L_B18BCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BCA BEQ -> $B18BDE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18BDE; }
    goto L_B18BCC;
L_B18BCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BCC LDA
    cpu.setA(0x2u, 8);
    goto L_B18BCE;
L_B18BCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BCE STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_B18BD1;
L_B18BD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD1 LDA
    cpu.setA(0x0u, 8);
    goto L_B18BD3;
L_B18BD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD3 CPY
    cpu.compareY(0x5u);
    goto L_B18BD5;
L_B18BD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD5u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD5 BCC -> $B18BD8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B18BD8; }
    goto L_B18BD7;
L_B18BD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD7u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD7 INC
    cpu.inc('A');
    goto L_B18BD8;
L_B18BD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD8u,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD8u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD8 EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16));
    goto L_B18BDB;
L_B18BDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDBu, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BDB STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_B18BDE;
L_B18BDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BDE LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B18BE0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BDE LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B18BE0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BDEu,0xB18BDEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18BE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BE3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BE3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BE0u,0xB18BE0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18BE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE3 AND
    cpu.logicAnd(0x40u);
    goto L_B18BE5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE3 AND
    cpu.logicAnd(0x40u);
    goto L_B18BE5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BE3u,0xB18BE3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18BE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE5 BNE -> $B18BEC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18BEC; }
    goto L_B18BE7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE5 BNE -> $B18BEC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18BEC; }
    goto L_B18BE7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BE5u,0xB18BE5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18BE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18BE7 JSR -> $B19F0D stack real
    { cpu.push16Value(hw,0x8BE9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BEAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0xB18BE7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18BEA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18BE7 JSR -> $B19F0D stack real
    { cpu.push16Value(hw,0x8BE9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BEAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0xB18BE7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18BEA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BE7u,0xB18BE7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18BEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BEAu,0xB18BEAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BEA BRA -> $B18C13
    goto L_B18C13;
L_B18BEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BECu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BEC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BEF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BEC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BEF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BECu,0xB18BECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18BEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BEF LSR
    cpu.lsrA();
    goto L_B18BF0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BEF LSR
    cpu.lsrA();
    goto L_B18BF0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BEFu,0xB18BEFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18BF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BF0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BF2;
L_B18BF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF2u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18BF2 PHA
    cpu.push("PHA", hw);
    goto L_B18BF3;
L_B18BF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BF3 SBC
    cpu.sbc(0xFu);
    goto L_B18BF5;
L_B18BF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BF5 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_B18BF7;
L_B18BF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF7u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BF7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BFA;
L_B18BFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18BFA PHA
    cpu.push("PHA", hw);
    goto L_B18BFB;
L_B18BFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BFB SBC
    cpu.sbc(0x0u);
    goto L_B18BFD;
L_B18BFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFDu, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BFD STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_B18C00;
L_B18C00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C00u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C00u, 6u, 3u, cpu.address("abs", 0x9D67u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18C00 JSR -> $B19D67 stack real
    { cpu.push16Value(hw,0x8C02u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C03u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D67u), 0xB18C00u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18C03;
L_B18C03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C03u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C03u,0xB18C03u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18C03 PLA
    cpu.pop("PLA", hw);
    goto L_B18C04;
L_B18C04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C04 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_B18C07;
L_B18C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18C07 PLA
    cpu.pop("PLA", hw);
    goto L_B18C08;
L_B18C08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C08u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C08u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C08 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_B18C0A;
L_B18C0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C0A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18C0C;
L_B18C0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C0C CMP
    cpu.compareA(0x8u);
    goto L_B18C0E;
L_B18C0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C0E BCC -> $B18C13
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B18C13; }
    goto L_B18C10;
L_B18C10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C10u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C10u, 6u, 3u, cpu.address("abs", 0x9E28u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18C10 JSR -> $B19E28 stack real
    { cpu.push16Value(hw,0x8C12u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C13u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E28u), 0xB18C10u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18C13;
L_B18C13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C13u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C13u,0xB18C13u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18C13 PLA
    cpu.pop("PLA", hw);
    goto L_B18C14;
L_B18C14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C14u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C14u, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C14 STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_B18C17;
L_B18C17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18C17 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB18C17u);return;} hw.unresolvedReturn(0xB18C17u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B18CB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u, 3u, 3u, cpu.address("abs", 0x8BC3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18CB7 JMP -> $B18BC3
    goto L_B18BC3;
}

void sub_B18CB7_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB18BC3u: goto L_B18BC3;
    case 0xB18BC6u: goto L_B18BC6;
    case 0xB18BC7u: goto L_B18BC7;
    case 0xB18BCAu: goto L_B18BCA;
    case 0xB18BCCu: goto L_B18BCC;
    case 0xB18BCEu: goto L_B18BCE;
    case 0xB18BD1u: goto L_B18BD1;
    case 0xB18BD3u: goto L_B18BD3;
    case 0xB18BD5u: goto L_B18BD5;
    case 0xB18BD7u: goto L_B18BD7;
    case 0xB18BD8u: goto L_B18BD8;
    case 0xB18BDBu: goto L_B18BDB;
    case 0xB18BDEu: goto L_B18BDE;
    case 0xB18BE0u: goto L_B18BE0;
    case 0xB18BE3u: goto L_B18BE3;
    case 0xB18BE5u: goto L_B18BE5;
    case 0xB18BE7u: goto L_B18BE7;
    case 0xB18BEAu: goto L_B18BEA;
    case 0xB18BECu: goto L_B18BEC;
    case 0xB18BEFu: goto L_B18BEF;
    case 0xB18BF0u: goto L_B18BF0;
    case 0xB18BF2u: goto L_B18BF2;
    case 0xB18BF3u: goto L_B18BF3;
    case 0xB18BF5u: goto L_B18BF5;
    case 0xB18BF7u: goto L_B18BF7;
    case 0xB18BFAu: goto L_B18BFA;
    case 0xB18BFBu: goto L_B18BFB;
    case 0xB18BFDu: goto L_B18BFD;
    case 0xB18C00u: goto L_B18C00;
    case 0xB18C03u: goto L_B18C03;
    case 0xB18C04u: goto L_B18C04;
    case 0xB18C07u: goto L_B18C07;
    case 0xB18C08u: goto L_B18C08;
    case 0xB18C0Au: goto L_B18C0A;
    case 0xB18C0Cu: goto L_B18C0C;
    case 0xB18C0Eu: goto L_B18C0E;
    case 0xB18C10u: goto L_B18C10;
    case 0xB18C13u: goto L_B18C13;
    case 0xB18C14u: goto L_B18C14;
    case 0xB18C17u: goto L_B18C17;
    case 0xB18CB7u: goto L_B18CB7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B18BC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BC3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BC6;
L_B18BC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18BC6 PHA
    cpu.push("PHA", hw);
    goto L_B18BC7;
L_B18BC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BC7 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15ACu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B18BCA;
L_B18BCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BCA BEQ -> $B18BDE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18BDE; }
    goto L_B18BCC;
L_B18BCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BCC LDA
    cpu.setA(0x2u, 8);
    goto L_B18BCE;
L_B18BCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BCE STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_B18BD1;
L_B18BD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD1 LDA
    cpu.setA(0x0u, 8);
    goto L_B18BD3;
L_B18BD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD3 CPY
    cpu.compareY(0x5u);
    goto L_B18BD5;
L_B18BD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD5u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD5 BCC -> $B18BD8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B18BD8; }
    goto L_B18BD7;
L_B18BD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD7u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD7 INC
    cpu.inc('A');
    goto L_B18BD8;
L_B18BD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD8u,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD8u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD8 EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16));
    goto L_B18BDB;
L_B18BDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDBu, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BDB STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_B18BDE;
L_B18BDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BDE LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B18BE0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BDE LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B18BE0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BDEu,0xB18BDEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18BE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BE3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BE3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BE0u,0xB18BE0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18BE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE3 AND
    cpu.logicAnd(0x40u);
    goto L_B18BE5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE3 AND
    cpu.logicAnd(0x40u);
    goto L_B18BE5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BE3u,0xB18BE3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18BE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE5 BNE -> $B18BEC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18BEC; }
    goto L_B18BE7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE5 BNE -> $B18BEC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18BEC; }
    goto L_B18BE7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BE5u,0xB18BE5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18BE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18BE7 JSR -> $B19F0D stack real
    { cpu.push16Value(hw,0x8BE9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BEAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0xB18BE7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18BEA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18BE7 JSR -> $B19F0D stack real
    { cpu.push16Value(hw,0x8BE9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BEAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0xB18BE7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18BEA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BE7u,0xB18BE7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18BEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BEAu,0xB18BEAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BEA BRA -> $B18C13
    goto L_B18C13;
L_B18BEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BECu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BEC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BEF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BEC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BEF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BECu,0xB18BECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18BEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BEF LSR
    cpu.lsrA();
    goto L_B18BF0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BEF LSR
    cpu.lsrA();
    goto L_B18BF0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BEFu,0xB18BEFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18BF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BF0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BF2;
L_B18BF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF2u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18BF2 PHA
    cpu.push("PHA", hw);
    goto L_B18BF3;
L_B18BF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BF3 SBC
    cpu.sbc(0xFu);
    goto L_B18BF5;
L_B18BF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BF5 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_B18BF7;
L_B18BF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF7u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BF7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BFA;
L_B18BFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18BFA PHA
    cpu.push("PHA", hw);
    goto L_B18BFB;
L_B18BFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BFB SBC
    cpu.sbc(0x0u);
    goto L_B18BFD;
L_B18BFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFDu, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BFD STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_B18C00;
L_B18C00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C00u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C00u, 6u, 3u, cpu.address("abs", 0x9D67u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18C00 JSR -> $B19D67 stack real
    { cpu.push16Value(hw,0x8C02u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C03u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D67u), 0xB18C00u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18C03;
L_B18C03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C03u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C03u,0xB18C03u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18C03 PLA
    cpu.pop("PLA", hw);
    goto L_B18C04;
L_B18C04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C04 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_B18C07;
L_B18C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18C07 PLA
    cpu.pop("PLA", hw);
    goto L_B18C08;
L_B18C08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C08u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C08u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C08 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_B18C0A;
L_B18C0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C0A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18C0C;
L_B18C0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C0C CMP
    cpu.compareA(0x8u);
    goto L_B18C0E;
L_B18C0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C0E BCC -> $B18C13
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B18C13; }
    goto L_B18C10;
L_B18C10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C10u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C10u, 6u, 3u, cpu.address("abs", 0x9E28u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18C10 JSR -> $B19E28 stack real
    { cpu.push16Value(hw,0x8C12u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C13u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E28u), 0xB18C10u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18C13;
L_B18C13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C13u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C13u,0xB18C13u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18C13 PLA
    cpu.pop("PLA", hw);
    goto L_B18C14;
L_B18C14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C14u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C14u, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C14 STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_B18C17;
L_B18C17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18C17 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB18C17u);return;} hw.unresolvedReturn(0xB18C17u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B18CB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u, 3u, 3u, cpu.address("abs", 0x8BC3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18CB7 JMP -> $B18BC3
    goto L_B18BC3;
}

void sub_B18CB7_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB18BC3u: goto L_B18BC3;
    case 0xB18BC6u: goto L_B18BC6;
    case 0xB18BC7u: goto L_B18BC7;
    case 0xB18BCAu: goto L_B18BCA;
    case 0xB18BCCu: goto L_B18BCC;
    case 0xB18BCEu: goto L_B18BCE;
    case 0xB18BD1u: goto L_B18BD1;
    case 0xB18BD3u: goto L_B18BD3;
    case 0xB18BD5u: goto L_B18BD5;
    case 0xB18BD7u: goto L_B18BD7;
    case 0xB18BD8u: goto L_B18BD8;
    case 0xB18BDBu: goto L_B18BDB;
    case 0xB18BDEu: goto L_B18BDE;
    case 0xB18BE0u: goto L_B18BE0;
    case 0xB18BE3u: goto L_B18BE3;
    case 0xB18BE5u: goto L_B18BE5;
    case 0xB18BE7u: goto L_B18BE7;
    case 0xB18BEAu: goto L_B18BEA;
    case 0xB18BECu: goto L_B18BEC;
    case 0xB18BEFu: goto L_B18BEF;
    case 0xB18BF0u: goto L_B18BF0;
    case 0xB18BF2u: goto L_B18BF2;
    case 0xB18BF3u: goto L_B18BF3;
    case 0xB18BF5u: goto L_B18BF5;
    case 0xB18BF7u: goto L_B18BF7;
    case 0xB18BFAu: goto L_B18BFA;
    case 0xB18BFBu: goto L_B18BFB;
    case 0xB18BFDu: goto L_B18BFD;
    case 0xB18C00u: goto L_B18C00;
    case 0xB18C03u: goto L_B18C03;
    case 0xB18C04u: goto L_B18C04;
    case 0xB18C07u: goto L_B18C07;
    case 0xB18C08u: goto L_B18C08;
    case 0xB18C0Au: goto L_B18C0A;
    case 0xB18C0Cu: goto L_B18C0C;
    case 0xB18C0Eu: goto L_B18C0E;
    case 0xB18C10u: goto L_B18C10;
    case 0xB18C13u: goto L_B18C13;
    case 0xB18C14u: goto L_B18C14;
    case 0xB18C17u: goto L_B18C17;
    case 0xB18CB7u: goto L_B18CB7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B18BC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BC3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BC6;
L_B18BC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18BC6 PHA
    cpu.push("PHA", hw);
    goto L_B18BC7;
L_B18BC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BC7 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15ACu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B18BCA;
L_B18BCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BCA BEQ -> $B18BDE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18BDE; }
    goto L_B18BCC;
L_B18BCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BCC LDA
    cpu.setA(0x2u, 8);
    goto L_B18BCE;
L_B18BCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BCE STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_B18BD1;
L_B18BD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD1 LDA
    cpu.setA(0x0u, 8);
    goto L_B18BD3;
L_B18BD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD3 CPY
    cpu.compareY(0x5u);
    goto L_B18BD5;
L_B18BD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD5u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD5 BCC -> $B18BD8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B18BD8; }
    goto L_B18BD7;
L_B18BD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD7u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD7 INC
    cpu.inc('A');
    goto L_B18BD8;
L_B18BD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD8u,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD8u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BD8 EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16));
    goto L_B18BDB;
L_B18BDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDBu, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BDB STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_B18BDE;
L_B18BDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BDE LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B18BE0;
L_B18BE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BE3;
L_B18BE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE3 AND
    cpu.logicAnd(0x40u);
    goto L_B18BE5;
L_B18BE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BE5 BNE -> $B18BEC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18BEC; }
    goto L_B18BE7;
L_B18BE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18BE7 JSR -> $B19F0D stack real
    { cpu.push16Value(hw,0x8BE9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BEAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0xB18BE7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18BEA;
L_B18BEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BEAu,0xB18BEAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BEA BRA -> $B18C13
    goto L_B18C13;
L_B18BEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BEC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BEF;
L_B18BEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BEF LSR
    cpu.lsrA();
    goto L_B18BF0;
L_B18BF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BF0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BF2;
L_B18BF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF2u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18BF2 PHA
    cpu.push("PHA", hw);
    goto L_B18BF3;
L_B18BF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BF3 SBC
    cpu.sbc(0xFu);
    goto L_B18BF5;
L_B18BF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BF5 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_B18BF7;
L_B18BF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF7u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BF7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18BFA;
L_B18BFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18BFA PHA
    cpu.push("PHA", hw);
    goto L_B18BFB;
L_B18BFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BFB SBC
    cpu.sbc(0x0u);
    goto L_B18BFD;
L_B18BFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFDu, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18BFD STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_B18C00;
L_B18C00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C00u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C00u, 6u, 3u, cpu.address("abs", 0x9D67u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18C00 JSR -> $B19D67 stack real
    { cpu.push16Value(hw,0x8C02u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C03u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D67u), 0xB18C00u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18C03;
L_B18C03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C03u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C03u,0xB18C03u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18C03 PLA
    cpu.pop("PLA", hw);
    goto L_B18C04;
L_B18C04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C04 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_B18C07;
L_B18C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18C07 PLA
    cpu.pop("PLA", hw);
    goto L_B18C08;
L_B18C08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C08u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C08u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C08 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_B18C0A;
L_B18C0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C0A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18C0C;
L_B18C0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C0C CMP
    cpu.compareA(0x8u);
    goto L_B18C0E;
L_B18C0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C0E BCC -> $B18C13
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B18C13; }
    goto L_B18C10;
L_B18C10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C10u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C10u, 6u, 3u, cpu.address("abs", 0x9E28u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18C10 JSR -> $B19E28 stack real
    { cpu.push16Value(hw,0x8C12u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C13u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E28u), 0xB18C10u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18C13;
L_B18C13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C13u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C13u,0xB18C13u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B18C13 PLA
    cpu.pop("PLA", hw);
    goto L_B18C14;
L_B18C14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C14u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C14u, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18C14 STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_B18C17;
L_B18C17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18C17 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB18C17u);return;} hw.unresolvedReturn(0xB18C17u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B18CB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u, 3u, 3u, cpu.address("abs", 0x8BC3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18CB7 JMP -> $B18BC3
    goto L_B18BC3;
}

void sub_B18D80_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB18D80u: goto L_B18D80;
    case 0xB18D82u: goto L_B18D82;
    case 0xB18D85u: goto L_B18D85;
    case 0xB18D87u: goto L_B18D87;
    case 0xB18D8Au: goto L_B18D8A;
    case 0xB18D8Cu: goto L_B18D8C;
    case 0xB18D8Fu: goto L_B18D8F;
    case 0xB18D91u: goto L_B18D91;
    case 0xB18D93u: goto L_B18D93;
    case 0xB18D96u: goto L_B18D96;
    case 0xB18D97u: goto L_B18D97;
    case 0xB18D9Au: goto L_B18D9A;
    case 0xB18D9Cu: goto L_B18D9C;
    case 0xB18D9Eu: goto L_B18D9E;
    case 0xB18DA1u: goto L_B18DA1;
    case 0xB18DA3u: goto L_B18DA3;
    case 0xB18DA5u: goto L_B18DA5;
    case 0xB18DA8u: goto L_B18DA8;
    case 0xB18DABu: goto L_B18DAB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B18D80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D80u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D80u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D80 BVS -> $B18D97
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_B18D97; }
    goto L_B18D82;
L_B18D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D82 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D85;
L_B18D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D85 BNE -> $B18DA5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18DA5; }
    goto L_B18D87;
L_B18D87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u, 7u, 3u, cpu.address("absx", 0x151Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D87 INC
    cpu.incMem(hw, cpu.address("absx", 0x151Cu), cpu.m8?8:16);
    goto L_B18D8A;
L_B18D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D8A LDY
    cpu.setY(0xF0u, 8);
    goto L_B18D8C;
L_B18D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D8C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D8F;
L_B18D8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D8F CMP
    cpu.compareA(0x4u);
    goto L_B18D91;
L_B18D91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D91u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D91 BNE -> $B18DA3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18DA3; }
    goto L_B18D93;
L_B18D93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D93u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D93u, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D93 STZ
    hw.write(cpu.address("absx", 0x151Cu), 0, cpu.m8?8:16);
    goto L_B18D96;
L_B18D96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D96u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D96u, 8u, 4u, 0x01ACF9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B18D96 JSL -> $01ACF9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D99u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D9Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01ACF9u, 0xB18D96u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D9A;
L_B18D97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D97u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D97u, 4u + ((((0x01ACu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x01ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D97 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1ACu), cpu.m8?8:16));
    goto L_B18D9A;
L_B18D9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D9Au,0xB18D9Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D9A AND
    cpu.logicAnd(0x3Fu);
    goto L_B18D9C;
L_B18D9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Cu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D9C ORA
    cpu.logicOr(0x50u);
    goto L_B18D9E;
L_B18D9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Eu, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D9E STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B18DA1;
L_B18DA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18DA1 LDY
    cpu.setY(0xD0u, 8);
    goto L_B18DA3;
L_B18DA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA3u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18DA3 STY
    hw.write(cpu.address("dpx", 0xAAu), cpu.y, cpu.x8?8:16);
    goto L_B18DA5;
L_B18DA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA5u, 6u, 3u, cpu.address("abs", 0x9089u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18DA5 JSR -> $B19089 stack real
    { cpu.push16Value(hw,0x8DA7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8DA8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9089u), 0xB18DA5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18DA8;
L_B18DA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DA8u,0xB18DA8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA8u, 6u, 3u, cpu.address("abs", 0x8FC1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18DA8 JSR -> $B18FC1 stack real
    { cpu.push16Value(hw,0x8DAAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8DABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8FC1u), 0xB18DA8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18DAB;
L_B18DAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DABu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18DAB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB18DABu);return;} hw.unresolvedReturn(0xB18DABu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18DAB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB18DABu);return;} hw.unresolvedReturn(0xB18DABu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18DAB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB18DABu);return;} hw.unresolvedReturn(0xB18DABu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DABu,0xB18DABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_B19A04_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB19A04u: goto L_B19A04;
    case 0xB19A07u: goto L_B19A07;
    case 0xB19A09u: goto L_B19A09;
    case 0xB19A0Bu: goto L_B19A0B;
    case 0xB19A0Eu: goto L_B19A0E;
    case 0xB19A10u: goto L_B19A10;
    case 0xB19A12u: goto L_B19A12;
    case 0xB19A14u: goto L_B19A14;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B19A04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A04u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A04u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19A04 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19A07;
L_B19A07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A07u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19A07 BMI -> $B19A10
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_B19A10; }
    goto L_B19A09;
L_B19A09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A09u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19A09 LDA
    cpu.setA(0x0u, 8);
    goto L_B19A0B;
L_B19A0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A0Bu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A0Bu, 4u + ((((0x15B8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15B8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19A0B LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15B8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B19A0E;
L_B19A0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A0Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19A0E BEQ -> $B19A12
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B19A12; }
    goto L_B19A10;
L_B19A10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A10u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19A10 LDA
    cpu.setA(0x18u, 8);
    goto L_B19A12;
L_B19A12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A12u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A12u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19A12 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B19A14;
L_B19A14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A14u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A14u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19A14 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB19A14u);return;} hw.unresolvedReturn(0xB19A14u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B19AD6_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB19AD6u: goto L_B19AD6;
    case 0xB19AD8u: goto L_B19AD8;
    case 0xB19ADAu: goto L_B19ADA;
    case 0xB19ADDu: goto L_B19ADD;
    case 0xB19AE0u: goto L_B19AE0;
    case 0xB19AE3u: goto L_B19AE3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B19AD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19AD6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19AD8;
L_B19AD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19AD8 BNE -> $B19ADD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B19ADD; }
    goto L_B19ADA;
L_B19ADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADAu, 6u, 3u, cpu.address("abs", 0x9032u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19ADA JSR -> $B19032 stack real
    { cpu.push16Value(hw,0x9ADCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9ADDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9032u), 0xB19ADAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19ADD;
L_B19ADD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADDu, 6u, 3u, cpu.address("abs", 0xAC31u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19ADD JSR -> $B1AC31 stack real
    { cpu.push16Value(hw,0x9ADFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9AE0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC31u), 0xB19ADDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19AE0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADDu, 6u, 3u, cpu.address("abs", 0xAC31u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19ADD JSR -> $B1AC31 stack real
    { cpu.push16Value(hw,0x9ADFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9AE0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC31u), 0xB19ADDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19AE0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ADDu,0xB19ADDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B19AE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u, 6u, 3u, cpu.address("abs", 0x9B13u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19AE0 JSR -> $B19B13 stack real
    { cpu.push16Value(hw,0x9AE2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9AE3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9B13u), 0xB19AE0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19AE3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u, 6u, 3u, cpu.address("abs", 0x9B13u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19AE0 JSR -> $B19B13 stack real
    { cpu.push16Value(hw,0x9AE2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9AE3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9B13u), 0xB19AE0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19AE3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AE0u,0xB19AE0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B19AE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AE3u,0xB19AE3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19AE3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB19AE3u);return;} hw.unresolvedReturn(0xB19AE3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A40D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A40Au: goto L_B1A40A;
    case 0xB1A40Du: goto L_B1A40D;
    case 0xB1A40Eu: goto L_B1A40E;
    case 0xB1A410u: goto L_B1A410;
    case 0xB1A411u: goto L_B1A411;
    case 0xB1A413u: goto L_B1A413;
    case 0xB1A414u: goto L_B1A414;
    case 0xB1A416u: goto L_B1A416;
    case 0xB1A417u: goto L_B1A417;
    case 0xB1A41Au: goto L_B1A41A;
    case 0xB1A41Cu: goto L_B1A41C;
    case 0xB1A41Eu: goto L_B1A41E;
    case 0xB1A421u: goto L_B1A421;
    case 0xB1A424u: goto L_B1A424;
    case 0xB1A427u: goto L_B1A427;
    case 0xB1A429u: goto L_B1A429;
    case 0xB1A42Cu: goto L_B1A42C;
    case 0xB1A42Fu: goto L_B1A42F;
    case 0xB1A432u: goto L_B1A432;
    case 0xB1A435u: goto L_B1A435;
    case 0xB1A438u: goto L_B1A438;
    case 0xB1A43Au: goto L_B1A43A;
    case 0xB1A43Du: goto L_B1A43D;
    case 0xB1A43Fu: goto L_B1A43F;
    case 0xB1A441u: goto L_B1A441;
    case 0xB1A444u: goto L_B1A444;
    case 0xB1A446u: goto L_B1A446;
    case 0xB1A449u: goto L_B1A449;
    case 0xB1A44Bu: goto L_B1A44B;
    case 0xB1A44Eu: goto L_B1A44E;
    case 0xB1A450u: goto L_B1A450;
    case 0xB1A452u: goto L_B1A452;
    case 0xB1A454u: goto L_B1A454;
    case 0xB1A455u: goto L_B1A455;
    case 0xB1A457u: goto L_B1A457;
    case 0xB1A458u: goto L_B1A458;
    case 0xB1A45Bu: goto L_B1A45B;
    case 0xB1A45Eu: goto L_B1A45E;
    case 0xB1A460u: goto L_B1A460;
    case 0xB1A462u: goto L_B1A462;
    case 0xB1A464u: goto L_B1A464;
    case 0xB1A467u: goto L_B1A467;
    case 0xB1A469u: goto L_B1A469;
    case 0xB1A46Bu: goto L_B1A46B;
    case 0xB1A46Cu: goto L_B1A46C;
    case 0xB1A46Eu: goto L_B1A46E;
    case 0xB1A46Fu: goto L_B1A46F;
    case 0xB1A472u: goto L_B1A472;
    case 0xB1A474u: goto L_B1A474;
    case 0xB1A477u: goto L_B1A477;
    case 0xB1A479u: goto L_B1A479;
    case 0xB1A47Bu: goto L_B1A47B;
    case 0xB1A47Eu: goto L_B1A47E;
    case 0xB1A480u: goto L_B1A480;
    case 0xB1A483u: goto L_B1A483;
    case 0xB1A485u: goto L_B1A485;
    case 0xB1A487u: goto L_B1A487;
    case 0xB1A488u: goto L_B1A488;
    case 0xB1A48Bu: goto L_B1A48B;
    case 0xB1A48Cu: goto L_B1A48C;
    case 0xB1A48Fu: goto L_B1A48F;
    case 0xB1A491u: goto L_B1A491;
    case 0xB1A494u: goto L_B1A494;
    case 0xB1A496u: goto L_B1A496;
    case 0xB1A498u: goto L_B1A498;
    case 0xB1A49Bu: goto L_B1A49B;
    case 0xB1A49Du: goto L_B1A49D;
    case 0xB1A49Fu: goto L_B1A49F;
    case 0xB1A4A0u: goto L_B1A4A0;
    case 0xB1A4A2u: goto L_B1A4A2;
    case 0xB1A4A3u: goto L_B1A4A3;
    case 0xB1A4A6u: goto L_B1A4A6;
    case 0xB1A4A9u: goto L_B1A4A9;
    case 0xB1A4ABu: goto L_B1A4AB;
    case 0xB1A4ADu: goto L_B1A4AD;
    case 0xB1A4B0u: goto L_B1A4B0;
    case 0xB1A4B1u: goto L_B1A4B1;
    case 0xB1A4B3u: goto L_B1A4B3;
    case 0xB1A4B6u: goto L_B1A4B6;
    case 0xB1A4B9u: goto L_B1A4B9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A40A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A40A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A40Au);return;} hw.unresolvedReturn(0xB1A40Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A40D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A40D TXA
    cpu.transfer("TXA");
    goto L_B1A40E;
L_B1A40E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A40E BEQ -> $B1A40A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A40A; }
    goto L_B1A410;
L_B1A410:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA410u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA410u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA410u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A410 TAY
    cpu.transfer("TAY");
    goto L_B1A411;
L_B1A411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA411u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA411u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A411 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_B1A413;
L_B1A413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA413u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA413u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA413u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A413 LSR
    cpu.lsrA();
    goto L_B1A414;
L_B1A414:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA414u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA414u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA414u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A414 BCC -> $B1A40A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A40A; }
    goto L_B1A416;
L_B1A416:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA416u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA416u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA416u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A416 DEX
    cpu.decReg('X');
    goto L_B1A417;
L_B1A417:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA417u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA417u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA417u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A417 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A41A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA417u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA417u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A417 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A41A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA417u,0xB1A417u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A41A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A41A CMP
    cpu.compareA(0x8u);
    goto L_B1A41C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A41A CMP
    cpu.compareA(0x8u);
    goto L_B1A41C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA41Au,0xB1A41Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A41C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A41C BCS -> $B1A421
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A421; }
    goto L_B1A41E;
L_B1A41E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Eu, 3u, 3u, cpu.address("abs", 0xA4B0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A41E JMP -> $B1A4B0
    goto L_B1A4B0;
L_B1A421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA421u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA421u, 4u + ((((0x1686u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A421 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1686u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A424;
L_B1A424:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA424u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA424u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA424u, 4u + ((((0x1686u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A424 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x1686u), cpu.m8?8:16));
    goto L_B1A427;
L_B1A427:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA427u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA427u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA427u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A427 AND
    cpu.logicAnd(0x8u);
    goto L_B1A429;
L_B1A429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA429u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA429u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA429u, 4u + ((((0x1564u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A429 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1564u), cpu.m8?8:16));
    goto L_B1A42C;
L_B1A42C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Cu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Cu, 4u + ((((0x1564u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A42C ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x1564u), cpu.m8?8:16));
    goto L_B1A42F;
L_B1A42F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Fu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Fu, 4u + ((((0x15D0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A42F ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15D0u), cpu.m8?8:16));
    goto L_B1A432;
L_B1A432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA432u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA432u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA432u, 4u + ((((0x1632u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1632u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A432 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1632u), cpu.m8?8:16));
    goto L_B1A435;
L_B1A435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA435u,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA435u, 4u + ((((0x1632u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1632u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A435 EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0x1632u), cpu.m8?8:16));
    goto L_B1A438;
L_B1A438:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA438u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA438u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA438u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A438 BNE -> $B1A4B0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A4B0; }
    goto L_B1A43A;
L_B1A43A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Au,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Au, 4u, 3u, cpu.address("abs", 0x1695u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A43A STX
    hw.write(cpu.address("abs", 0x1695u), cpu.x, cpu.x8?8:16);
    goto L_B1A43D;
L_B1A43D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A43D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A43F;
L_B1A43F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A43F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_B1A441;
L_B1A441:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA441u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA441u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA441u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A441 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A444;
L_B1A444:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA444u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA444u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA444u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A444 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_B1A446;
L_B1A446:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA446u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA446u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA446u, 4u + ((((0x00E4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x00E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A446 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A449;
L_B1A449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA449u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA449u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA449u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A449 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_B1A44B;
L_B1A44B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Bu, 4u + ((((0x14E0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A44B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A44E;
L_B1A44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A44E STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_B1A450;
L_B1A450:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA450u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA450u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA450u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A450 REP
    cpu.rep(0x20u);
    goto L_B1A452;
L_B1A452:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA452u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA452u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA452u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A452 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A454;
L_B1A454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA454u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA454u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA454u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A454 SEC
    cpu.setFlag('C', true);
    goto L_B1A455;
L_B1A455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA455u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA455u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A455 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_B1A457;
L_B1A457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA457u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA457u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA457u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A457 CLC
    cpu.setFlag('C', false);
    goto L_B1A458;
L_B1A458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA458u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA458u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A458 ADC
    cpu.adc(0x10u);
    goto L_B1A45B;
L_B1A45B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A45B CMP
    cpu.compareA(0x20u);
    goto L_B1A45E;
L_B1A45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A45E SEP
    cpu.sep(0x20u);
    goto L_B1A460;
L_B1A460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA460u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA460u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A460 BCS -> $B1A4B0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A4B0; }
    goto L_B1A462;
L_B1A462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA462u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA462u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A462 LDY
    cpu.setY(0x0u, 8);
    goto L_B1A464;
L_B1A464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA464u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA464u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA464u, 4u + ((((0x1662u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1662u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A464 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1662u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A467;
L_B1A467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA467u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA467u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A467 AND
    cpu.logicAnd(0xFu);
    goto L_B1A469;
L_B1A469:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA469u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA469u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA469u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A469 BEQ -> $B1A46C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A46C; }
    goto L_B1A46B;
L_B1A46B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A46B INY
    cpu.inc('Y');
    goto L_B1A46C;
L_B1A46C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A46C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A46E;
L_B1A46E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A46E CLC
    cpu.setFlag('C', false);
    goto L_B1A46F;
L_B1A46F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Fu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Fu, 4u + ((((0xA40Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA40Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A46F ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xA40Bu), cpu.m8?8:16));
    goto L_B1A472;
L_B1A472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA472u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA472u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A472 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_B1A474;
L_B1A474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA474u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA474u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A474 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A477;
L_B1A477:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA477u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA477u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA477u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A477 ADC
    cpu.adc(0x0u);
    goto L_B1A479;
L_B1A479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A479 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_B1A47B;
L_B1A47B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Bu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Bu, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A47B LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A47E;
L_B1A47E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A47E LDX
    cpu.setX(0x0u, 8);
    goto L_B1A480;
L_B1A480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA480u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA480u, 4u + ((((0x1662u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1662u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A480 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1662u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A483;
L_B1A483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA483u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA483u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A483 AND
    cpu.logicAnd(0xFu);
    goto L_B1A485;
L_B1A485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA485u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA485u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A485 BEQ -> $B1A488
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A488; }
    goto L_B1A487;
L_B1A487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA487u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA487u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A487 INX
    cpu.inc('X');
    goto L_B1A488;
L_B1A488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA488u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA488u, 4u + ((((0x00D8u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x00D8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A488 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A48B;
L_B1A48B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A48B CLC
    cpu.setFlag('C', false);
    goto L_B1A48C;
L_B1A48C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Cu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Cu, 4u + ((((0xA40Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA40Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A48C ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xA40Bu), cpu.m8?8:16));
    goto L_B1A48F;
L_B1A48F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A48F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_B1A491;
L_B1A491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA491u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA491u, 4u + ((((0x14D4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A491 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A494;
L_B1A494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A494 ADC
    cpu.adc(0x0u);
    goto L_B1A496;
L_B1A496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA496u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA496u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A496 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_B1A498;
L_B1A498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA498u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA498u, 4u, 3u, cpu.address("abs", 0x1695u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A498 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1695u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A49B;
L_B1A49B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A49B REP
    cpu.rep(0x20u);
    goto L_B1A49D;
L_B1A49D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A49D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A49F;
L_B1A49F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A49F SEC
    cpu.setFlag('C', true);
    goto L_B1A4A0;
L_B1A4A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A0u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4A0 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_B1A4A2;
L_B1A4A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4A2 CLC
    cpu.setFlag('C', false);
    goto L_B1A4A3;
L_B1A4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4A3 ADC
    cpu.adc(0xCu);
    goto L_B1A4A6;
L_B1A4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4A6 CMP
    cpu.compareA(0x18u);
    goto L_B1A4A9;
L_B1A4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4A9 SEP
    cpu.sep(0x20u);
    goto L_B1A4AB;
L_B1A4AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ABu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4AB BCS -> $B1A4B0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A4B0; }
    goto L_B1A4AD;
L_B1A4AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ADu, 6u, 3u, cpu.address("abs", 0xA4BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A4AD JSR -> $B1A4BA stack real
    { cpu.push16Value(hw,0xA4AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA4B0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA4BAu), 0xB1A4ADu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A4B0;
L_B1A4B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4B0 DEX
    cpu.decReg('X');
    goto L_B1A4B1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4B0 DEX
    cpu.decReg('X');
    goto L_B1A4B1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4B0u,0xB1A4B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A4B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B1u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4B1 BMI -> $B1A4B6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_B1A4B6; }
    goto L_B1A4B3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B1u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4B1 BMI -> $B1A4B6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_B1A4B6; }
    goto L_B1A4B3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4B1u,0xB1A4B1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B3u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B3u, 3u, 3u, cpu.address("abs", 0xA417u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4B3 JMP -> $B1A417
    goto L_B1A417;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B3u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B3u, 3u, 3u, cpu.address("abs", 0xA417u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4B3 JMP -> $B1A417
    goto L_B1A417;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4B3u,0xB1A4B3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A4B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B6u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B6u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4B6 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A4B9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B6u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B6u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4B6 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A4B9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4B6u,0xB1A4B6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A4B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A4B9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A4B9u);return;} hw.unresolvedReturn(0xB1A4B9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A4B9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A4B9u);return;} hw.unresolvedReturn(0xB1A4B9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4B9u,0xB1A4B9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_B1A4CE_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A4CEu: goto L_B1A4CE;
    case 0xB1A4D1u: goto L_B1A4D1;
    case 0xB1A4D3u: goto L_B1A4D3;
    case 0xB1A4D5u: goto L_B1A4D5;
    case 0xB1A4D7u: goto L_B1A4D7;
    case 0xB1A4D9u: goto L_B1A4D9;
    case 0xB1A4DBu: goto L_B1A4DB;
    case 0xB1A4DDu: goto L_B1A4DD;
    case 0xB1A4DFu: goto L_B1A4DF;
    case 0xB1A4E1u: goto L_B1A4E1;
    case 0xB1A534u: goto L_B1A534;
    case 0xB1A537u: goto L_B1A537;
    case 0xB1A53Du: goto L_B1A53D;
    case 0xB1A540u: goto L_B1A540;
    case 0xB1A543u: goto L_B1A543;
    case 0xB1A544u: goto L_B1A544;
    case 0xB1A545u: goto L_B1A545;
    case 0xB1A546u: goto L_B1A546;
    case 0xB1A547u: goto L_B1A547;
    case 0xB1A548u: goto L_B1A548;
    case 0xB1A54Bu: goto L_B1A54B;
    case 0xB1A54Cu: goto L_B1A54C;
    case 0xB1A54Du: goto L_B1A54D;
    case 0xB1A550u: goto L_B1A550;
    case 0xB1A553u: goto L_B1A553;
    case 0xB1A555u: goto L_B1A555;
    case 0xB1A558u: goto L_B1A558;
    case 0xB1A55Au: goto L_B1A55A;
    case 0xB1A55Cu: goto L_B1A55C;
    case 0xB1A55Fu: goto L_B1A55F;
    case 0xB1A561u: goto L_B1A561;
    case 0xB1A563u: goto L_B1A563;
    case 0xB1A565u: goto L_B1A565;
    case 0xB1A567u: goto L_B1A567;
    case 0xB1A56Au: goto L_B1A56A;
    case 0xB1A56Du: goto L_B1A56D;
    case 0xB1A56Fu: goto L_B1A56F;
    case 0xB1A570u: goto L_B1A570;
    case 0xB1A573u: goto L_B1A573;
    case 0xB1A576u: goto L_B1A576;
    case 0xB1A579u: goto L_B1A579;
    case 0xB1A57Au: goto L_B1A57A;
    case 0xB1A57Cu: goto L_B1A57C;
    case 0xB1A57Eu: goto L_B1A57E;
    case 0xB1A581u: goto L_B1A581;
    case 0xB1A583u: goto L_B1A583;
    case 0xB1A585u: goto L_B1A585;
    case 0xB1A588u: goto L_B1A588;
    case 0xB1A58Bu: goto L_B1A58B;
    case 0xB1A58Cu: goto L_B1A58C;
    case 0xB1A58Eu: goto L_B1A58E;
    case 0xB1A591u: goto L_B1A591;
    case 0xB1A592u: goto L_B1A592;
    case 0xB1A595u: goto L_B1A595;
    case 0xB1A597u: goto L_B1A597;
    case 0xB1A59Au: goto L_B1A59A;
    case 0xB1A59Cu: goto L_B1A59C;
    case 0xB1A59Eu: goto L_B1A59E;
    case 0xB1A5A1u: goto L_B1A5A1;
    case 0xB1A5A4u: goto L_B1A5A4;
    case 0xB1A5A6u: goto L_B1A5A6;
    case 0xB1A5A8u: goto L_B1A5A8;
    case 0xB1A5ABu: goto L_B1A5AB;
    case 0xB1A5ACu: goto L_B1A5AC;
    case 0xB1A5AEu: goto L_B1A5AE;
    case 0xB1A5B0u: goto L_B1A5B0;
    case 0xB1A5B3u: goto L_B1A5B3;
    case 0xB1A5B4u: goto L_B1A5B4;
    case 0xB1A5B7u: goto L_B1A5B7;
    case 0xB1A5B9u: goto L_B1A5B9;
    case 0xB1A5BCu: goto L_B1A5BC;
    case 0xB1A5BEu: goto L_B1A5BE;
    case 0xB1A5C0u: goto L_B1A5C0;
    case 0xB1A5C3u: goto L_B1A5C3;
    case 0xB1A5C4u: goto L_B1A5C4;
    case 0xB1A5C7u: goto L_B1A5C7;
    case 0xB1A5C8u: goto L_B1A5C8;
    case 0xB1A5CAu: goto L_B1A5CA;
    case 0xB1A5CCu: goto L_B1A5CC;
    case 0xB1A5CEu: goto L_B1A5CE;
    case 0xB1A5D1u: goto L_B1A5D1;
    case 0xB1A5D3u: goto L_B1A5D3;
    case 0xB1A5D4u: goto L_B1A5D4;
    case 0xB1A5D5u: goto L_B1A5D5;
    case 0xB1A5D8u: goto L_B1A5D8;
    case 0xB1A5D9u: goto L_B1A5D9;
    case 0xB1A5DAu: goto L_B1A5DA;
    case 0xB1A5DDu: goto L_B1A5DD;
    case 0xB1A5E0u: goto L_B1A5E0;
    case 0xB1A5E3u: goto L_B1A5E3;
    case 0xB1A5E5u: goto L_B1A5E5;
    case 0xB1A5E8u: goto L_B1A5E8;
    case 0xB1A5E9u: goto L_B1A5E9;
    case 0xB1A5EAu: goto L_B1A5EA;
    case 0xB1A5EEu: goto L_B1A5EE;
    case 0xB1A5EFu: goto L_B1A5EF;
    case 0xB1A5F1u: goto L_B1A5F1;
    case 0xB1A5F2u: goto L_B1A5F2;
    case 0xB1A5F4u: goto L_B1A5F4;
    case 0xB1A5F6u: goto L_B1A5F6;
    case 0xB1A5F8u: goto L_B1A5F8;
    case 0xB1A5FBu: goto L_B1A5FB;
    case 0xB1A5FDu: goto L_B1A5FD;
    case 0xB1A600u: goto L_B1A600;
    case 0xB1A601u: goto L_B1A601;
    case 0xB1A604u: goto L_B1A604;
    case 0xB1A607u: goto L_B1A607;
    case 0xB1A609u: goto L_B1A609;
    case 0xB1A60Bu: goto L_B1A60B;
    case 0xB1A60Eu: goto L_B1A60E;
    case 0xB1A611u: goto L_B1A611;
    case 0xB1A612u: goto L_B1A612;
    case 0xB1A614u: goto L_B1A614;
    case 0xB1A616u: goto L_B1A616;
    case 0xB1A618u: goto L_B1A618;
    case 0xB1A619u: goto L_B1A619;
    case 0xB1A61Du: goto L_B1A61D;
    case 0xB1A685u: goto L_B1A685;
    case 0xB1A687u: goto L_B1A687;
    case 0xB1A689u: goto L_B1A689;
    case 0xB1A68Bu: goto L_B1A68B;
    case 0xB1A68Du: goto L_B1A68D;
    case 0xB1A68Fu: goto L_B1A68F;
    case 0xB1A691u: goto L_B1A691;
    case 0xB1A694u: goto L_B1A694;
    case 0xB1A696u: goto L_B1A696;
    case 0xB1A698u: goto L_B1A698;
    case 0xB1A69Au: goto L_B1A69A;
    case 0xB1A69Du: goto L_B1A69D;
    case 0xB1A6A0u: goto L_B1A6A0;
    case 0xB1A6A2u: goto L_B1A6A2;
    case 0xB1A6A4u: goto L_B1A6A4;
    case 0xB1A6A6u: goto L_B1A6A6;
    case 0xB1A6A8u: goto L_B1A6A8;
    case 0xB1A6AAu: goto L_B1A6AA;
    case 0xB1A6ACu: goto L_B1A6AC;
    case 0xB1A6AEu: goto L_B1A6AE;
    case 0xB1A6B1u: goto L_B1A6B1;
    case 0xB1A6B3u: goto L_B1A6B3;
    case 0xB1A6B6u: goto L_B1A6B6;
    case 0xB1A6B8u: goto L_B1A6B8;
    case 0xB1A6BBu: goto L_B1A6BB;
    case 0xB1A6BFu: goto L_B1A6BF;
    case 0xB1A6C1u: goto L_B1A6C1;
    case 0xB1A6C5u: goto L_B1A6C5;
    case 0xB1A6C7u: goto L_B1A6C7;
    case 0xB1A6C8u: goto L_B1A6C8;
    case 0xB1A6CAu: goto L_B1A6CA;
    case 0xB1A6CCu: goto L_B1A6CC;
    case 0xB1A6CEu: goto L_B1A6CE;
    case 0xB1A6D0u: goto L_B1A6D0;
    case 0xB1A6D2u: goto L_B1A6D2;
    case 0xB1A6D3u: goto L_B1A6D3;
    case 0xB1A6D6u: goto L_B1A6D6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A4CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CEu, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4CE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A4D1;
L_B1A4D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4D1 CMP
    cpu.compareA(0x8u);
    goto L_B1A4D3;
L_B1A4D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4D3 BEQ -> $B1A53D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A53D; }
    goto L_B1A4D5;
L_B1A4D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4D5 CMP
    cpu.compareA(0x9u);
    goto L_B1A4D7;
L_B1A4D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4D7 BEQ -> $B1A540
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A540; }
    goto L_B1A4D9;
L_B1A4D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4D9 CMP
    cpu.compareA(0xAu);
    goto L_B1A4DB;
L_B1A4DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4DB BEQ -> $B1A537
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A537; }
    goto L_B1A4DD;
L_B1A4DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4DD CMP
    cpu.compareA(0xBu);
    goto L_B1A4DF;
L_B1A4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4DF BEQ -> $B1A534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A534; }
    goto L_B1A4E1;
L_B1A4E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A4E1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A4E1u);return;} hw.unresolvedReturn(0xB1A4E1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u, 3u, 3u, cpu.address("abs", 0xA685u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A534 JMP -> $B1A685
    goto L_B1A685;
L_B1A537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA537u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA537u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA537u, 3u, 3u, cpu.address("abs", 0xA5C4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A537 JMP -> $B1A5C4
    goto L_B1A5C4;
L_B1A53D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Du, 3u, 3u, cpu.address("abs", 0xA56Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A53D JMP -> $B1A56D
    goto L_B1A56D;
L_B1A540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA540u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA540u, 6u, 3u, cpu.address("abs", 0xA6D9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A540 JSR -> $B1A6D9 stack real
    { cpu.push16Value(hw,0xA542u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA543u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6D9u), 0xB1A540u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A543;
L_B1A543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA543u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA543u,0xB1A543u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A543 PHX
    cpu.push("PHX", hw);
    goto L_B1A544;
L_B1A544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA544u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA544u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A544 PHY
    cpu.push("PHY", hw);
    goto L_B1A545;
L_B1A545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA545u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA545u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A545 TYA
    cpu.transfer("TYA");
    goto L_B1A546;
L_B1A546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA546u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA546u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A546 TXY
    cpu.transfer("TXY");
    goto L_B1A547;
L_B1A547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA547u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA547u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A547 TAX
    cpu.transfer("TAX");
    goto L_B1A548;
L_B1A548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA548u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA548u, 6u, 3u, cpu.address("abs", 0xA6D9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A548 JSR -> $B1A6D9 stack real
    { cpu.push16Value(hw,0xA54Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA54Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6D9u), 0xB1A548u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A54B;
L_B1A54B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA54Bu,0xB1A54Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Bu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A54B PLY
    cpu.pop("PLY", hw);
    goto L_B1A54C;
L_B1A54C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Cu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A54C PLX
    cpu.pop("PLX", hw);
    goto L_B1A54D;
L_B1A54D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Du, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A54D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A550;
L_B1A550:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA550u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA550u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA550u, 4u + ((((0x1558u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A550 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x1558u), cpu.m8?8:16));
    goto L_B1A553;
L_B1A553:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA553u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA553u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA553u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A553 BNE -> $B1A5C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A5C3; }
    goto L_B1A555;
L_B1A555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA555u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA555u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A555 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A558;
L_B1A558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA558u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA558u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A558 CMP
    cpu.compareA(0x9u);
    goto L_B1A55A;
L_B1A55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A55A BNE -> $B1A56D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A56D; }
    goto L_B1A55C;
L_B1A55C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Cu, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A55C JSR -> $B1800E stack real
    { cpu.push16Value(hw,0xA55Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA55Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0xB1A55Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A55F;
L_B1A55F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA55Fu,0xB1A55Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A55F BNE -> $B1A56D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A56D; }
    goto L_B1A561;
L_B1A561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA561u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA561u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A561 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A563;
L_B1A563:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA563u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA563u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA563u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A563 CMP
    cpu.compareA(0xFu);
    goto L_B1A565;
L_B1A565:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA565u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA565u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA565u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A565 BNE -> $B1A56A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A56A; }
    goto L_B1A567;
L_B1A567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 3u, 3u, cpu.address("abs", 0xA685u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A567 JMP -> $B1A685
    goto L_B1A685;
L_B1A56A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Au, 3u, 3u, cpu.address("abs", 0xA5C4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A56A JMP -> $B1A5C4
    goto L_B1A5C4;
L_B1A56D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A56D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A56F;
L_B1A56F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A56F SEC
    cpu.setFlag('C', true);
    goto L_B1A570;
L_B1A570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA570u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u, 4u + ((((0x00E4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x00E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A570 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0xE4u), cpu.m8?8:16));
    goto L_B1A573;
L_B1A573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A573 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A576;
L_B1A576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA576u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA576u, 4u + ((((0x14E0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A576 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x14E0u), cpu.m8?8:16));
    goto L_B1A579;
L_B1A579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA579u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA579u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A579 ROL
    cpu.rolA();
    goto L_B1A57A;
L_B1A57A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A57A AND
    cpu.logicAnd(0x1u);
    goto L_B1A57C;
L_B1A57C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A57C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_B1A57E;
L_B1A57E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu, 4u + ((((0x1686u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A57E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1686u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A581;
L_B1A581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA581u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA581u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A581 AND
    cpu.logicAnd(0x10u);
    goto L_B1A583;
L_B1A583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA583u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA583u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A583 BNE -> $B1A5A1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A5A1; }
    goto L_B1A585;
L_B1A585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA585u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA585u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A585 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A588;
L_B1A588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA588u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA588u, 4u + ((((0x157Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A588 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A58B;
L_B1A58B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A58B PHA
    cpu.push("PHA", hw);
    goto L_B1A58C;
L_B1A58C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A58C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A58E;
L_B1A58E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Eu, 5u, 3u, cpu.address("absy", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A58E STA
    hw.write(cpu.address("absy", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_B1A591;
L_B1A591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA591u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A591 PLA
    cpu.pop("PLA", hw);
    goto L_B1A592;
L_B1A592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA592u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA592u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA592u, 4u + ((((0x157Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A592 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x157Cu), cpu.m8?8:16));
    goto L_B1A595;
L_B1A595:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA595u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA595u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA595u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A595 BEQ -> $B1A5A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A5A1; }
    goto L_B1A597;
L_B1A597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA597u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA597u, 4u + ((((0x15ACu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A597 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x15ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A59A;
L_B1A59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A59A BNE -> $B1A5A1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A5A1; }
    goto L_B1A59C;
L_B1A59C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A59C LDA
    cpu.setA(0x8u, 8);
    goto L_B1A59E;
L_B1A59E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Eu, 5u, 3u, cpu.address("absy", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A59E STA
    hw.write(cpu.address("absy", 0x15ACu), cpu.a, cpu.m8?8:16);
    goto L_B1A5A1;
L_B1A5A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A1u, 4u + ((((0x1686u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5A1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1686u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A5A4;
L_B1A5A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5A4 AND
    cpu.logicAnd(0x10u);
    goto L_B1A5A6;
L_B1A5A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5A6 BNE -> $B1A5C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A5C3; }
    goto L_B1A5A8;
L_B1A5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5A8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A5AB;
L_B1A5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A5AB PHA
    cpu.push("PHA", hw);
    goto L_B1A5AC;
L_B1A5AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A5AE;
L_B1A5AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5AE EOR
    cpu.logicXor(0x1u);
    goto L_B1A5B0;
L_B1A5B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B0u, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5B0 STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_B1A5B3;
L_B1A5B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B3u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A5B3 PLA
    cpu.pop("PLA", hw);
    goto L_B1A5B4;
L_B1A5B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B4u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B4u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5B4 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16));
    goto L_B1A5B7;
L_B1A5B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5B7 BEQ -> $B1A5C3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A5C3; }
    goto L_B1A5B9;
L_B1A5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5B9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A5BC;
L_B1A5BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5BC BNE -> $B1A5C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A5C3; }
    goto L_B1A5BE;
L_B1A5BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5BE LDA
    cpu.setA(0x8u, 8);
    goto L_B1A5C0;
L_B1A5C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C0u, 5u, 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5C0 STA
    hw.write(cpu.address("absx", 0x15ACu), cpu.a, cpu.m8?8:16);
    goto L_B1A5C3;
L_B1A5C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A5C3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A5C3u);return;} hw.unresolvedReturn(0xB1A5C3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A5C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C4u, 4u + ((((0x009Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x009Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5C4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A5C7;
L_B1A5C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5C7 SEC
    cpu.setFlag('C', true);
    goto L_B1A5C8;
L_B1A5C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C8u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5C8 SBC
    cpu.sbc(0x83u);
    goto L_B1A5CA;
L_B1A5CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5CA CMP
    cpu.compareA(0x2u);
    goto L_B1A5CC;
L_B1A5CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CCu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5CC BCS -> $B1A5DA
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A5DA; }
    goto L_B1A5CE;
L_B1A5CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CEu, 6u, 3u, cpu.address("abs", 0x9098u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A5CE JSR -> $B19098 stack real
    { cpu.push16Value(hw,0xA5D0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5D1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9098u), 0xB1A5CEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A5D1;
L_B1A5D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5D1u,0xB1A5D1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D1u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5D1 STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_B1A5D3;
L_B1A5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D3u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A5D3 PHX
    cpu.push("PHX", hw);
    goto L_B1A5D4;
L_B1A5D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D4u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5D4 TYX
    cpu.transfer("TYX");
    goto L_B1A5D5;
L_B1A5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u, 6u, 3u, cpu.address("abs", 0xB4E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A5D5 JSR -> $B1B4E2 stack real
    { cpu.push16Value(hw,0xA5D7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5D8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB4E2u), 0xB1A5D5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A5D8;
L_B1A5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5D8u,0xB1A5D8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A5D8 PLX
    cpu.pop("PLX", hw);
    goto L_B1A5D9;
L_B1A5D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A5D9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A5D9u);return;} hw.unresolvedReturn(0xB1A5D9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DAu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DAu, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5DA LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A5DD;
L_B1A5DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DDu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DDu, 4u, 3u, cpu.address("abs", 0x1695u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5DD LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1695u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A5E0;
L_B1A5E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E0u, 6u, 3u, cpu.address("abs", 0xA77Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A5E0 JSR -> $B1A77C stack real
    { cpu.push16Value(hw,0xA5E2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5E3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA77Cu), 0xB1A5E0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A5E3;
L_B1A5E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5E3u,0xB1A5E3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5E3 LDA
    cpu.setA(0x2u, 8);
    goto L_B1A5E5;
L_B1A5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E5u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E5u, 5u, 3u, cpu.address("absy", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5E5 STA
    hw.write(cpu.address("absy", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A5E8;
L_B1A5E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A5E8 PHX
    cpu.push("PHX", hw);
    goto L_B1A5E9;
L_B1A5E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E9u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5E9 TYX
    cpu.transfer("TYX");
    goto L_B1A5EA;
L_B1A5EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EAu, 8u, 4u, 0x01AB72u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A5EA JSL -> $01AB72 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA5EDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5EEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB72u, 0xB1A5EAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A5EE;
L_B1A5EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5EEu,0xB1A5EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EEu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A5EE PLX
    cpu.pop("PLX", hw);
    goto L_B1A5EF;
L_B1A5EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EFu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5EF LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A5F1;
L_B1A5F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F1 ASL
    cpu.aslA();
    goto L_B1A5F2;
L_B1A5F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F2 LDA
    cpu.setA(0x10u, 8);
    goto L_B1A5F4;
L_B1A5F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F4 BCC -> $B1A5F8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A5F8; }
    goto L_B1A5F6;
L_B1A5F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F6 LDA
    cpu.setA(0xF0u, 8);
    goto L_B1A5F8;
L_B1A5F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F8u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F8u, 5u, 3u, cpu.address("absy", 0x00B6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F8 STA
    hw.write(cpu.address("absy", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B1A5FB;
L_B1A5FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5FB LDA
    cpu.setA(0xD0u, 8);
    goto L_B1A5FD;
L_B1A5FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FDu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FDu, 5u, 3u, cpu.address("absy", 0x00AAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5FD STA
    hw.write(cpu.address("absy", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A600;
L_B1A600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A600 PHY
    cpu.push("PHY", hw);
    goto L_B1A601;
L_B1A601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA601u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA601u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA601u, 7u, 3u, cpu.address("absx", 0x1626u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A601 INC
    cpu.incMem(hw, cpu.address("absx", 0x1626u), cpu.m8?8:16);
    goto L_B1A604;
L_B1A604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA604u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA604u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA604u, 4u + ((((0x1626u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A604 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1626u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A607;
L_B1A607:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA607u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA607u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA607u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A607 CPY
    cpu.compareY(0x8u);
    goto L_B1A609;
L_B1A609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A609 BCS -> $B1A611
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A611; }
    goto L_B1A60B;
L_B1A60B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Bu, 4u + ((((0xA61Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA61Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A60B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA61Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A60E;
L_B1A60E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A60E STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_B1A611;
L_B1A611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA611u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA611u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A611 TYA
    cpu.transfer("TYA");
    goto L_B1A612;
L_B1A612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA612u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA612u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A612 CMP
    cpu.compareA(0x8u);
    goto L_B1A614;
L_B1A614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA614u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA614u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A614 BCC -> $B1A618
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A618; }
    goto L_B1A616;
L_B1A616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA616u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA616u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A616 LDA
    cpu.setA(0x8u, 8);
    goto L_B1A618;
L_B1A618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA618u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA618u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A618 PLY
    cpu.pop("PLY", hw);
    goto L_B1A619;
L_B1A619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u, 8u, 4u, 0x02ACE1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A619 JSL -> $02ACE1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA61Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA61Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACE1u, 0xB1A619u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A61D;
L_B1A61D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA61Du,0xB1A61Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A61D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A61Du);return;} hw.unresolvedReturn(0xB1A61Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA685u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA685u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A685 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A687;
L_B1A687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA687u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA687u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA687u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A687 CMP
    cpu.compareA(0x83u);
    goto L_B1A689;
L_B1A689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A689 BEQ -> $B1A69A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A69A; }
    goto L_B1A68B;
L_B1A68B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A68B CMP
    cpu.compareA(0x84u);
    goto L_B1A68D;
L_B1A68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A68D BEQ -> $B1A69A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A69A; }
    goto L_B1A68F;
L_B1A68F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A68F LDA
    cpu.setA(0x2u, 8);
    goto L_B1A691;
L_B1A691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA691u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA691u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA691u, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A691 STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A694;
L_B1A694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA694u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA694u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A694 LDA
    cpu.setA(0xD0u, 8);
    goto L_B1A696;
L_B1A696:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA696u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA696u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA696u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A696 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A698;
L_B1A698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA698u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA698u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA698u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A698 BRA -> $B1A69D
    goto L_B1A69D;
L_B1A69A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Au, 6u, 3u, cpu.address("abs", 0xB4E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A69A JSR -> $B1B4E2 stack real
    { cpu.push16Value(hw,0xA69Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA69Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB4E2u), 0xB1A69Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A69D;
L_B1A69D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du, 4u + ((((0x009Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x009Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A69D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A6A0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du, 4u + ((((0x009Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x009Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A69D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A6A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA69Du,0xB1A69Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6A0 CMP
    cpu.compareA(0x80u);
    goto L_B1A6A2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6A0 CMP
    cpu.compareA(0x80u);
    goto L_B1A6A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6A0u,0xB1A6A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A6A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6A2 BEQ -> $B1A6BB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A6BB; }
    goto L_B1A6A4;
L_B1A6A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6A4 CMP
    cpu.compareA(0x83u);
    goto L_B1A6A6;
L_B1A6A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6A6 BEQ -> $B1A6B8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A6B8; }
    goto L_B1A6A8;
L_B1A6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6A8 CMP
    cpu.compareA(0x84u);
    goto L_B1A6AA;
L_B1A6AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6AA BEQ -> $B1A6B8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A6B8; }
    goto L_B1A6AC;
L_B1A6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6AC LDA
    cpu.setA(0x2u, 8);
    goto L_B1A6AE;
L_B1A6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu, 5u, 3u, cpu.address("absy", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6AE STA
    hw.write(cpu.address("absy", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A6B1;
L_B1A6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6B1 LDA
    cpu.setA(0xD0u, 8);
    goto L_B1A6B3;
L_B1A6B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B3u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B3u, 5u, 3u, cpu.address("absy", 0x00AAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6B3 STA
    hw.write(cpu.address("absy", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A6B6;
L_B1A6B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6B6 BRA -> $B1A6BB
    goto L_B1A6BB;
L_B1A6B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B8u, 6u, 3u, cpu.address("abs", 0xA5D3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A6B8 JSR -> $B1A5D3 stack real
    { cpu.push16Value(hw,0xA6BAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6BBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5D3u), 0xB1A6B8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A6BB;
L_B1A6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu, 8u, 4u, 0x01AB6Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A6BB JSL -> $01AB6F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6BEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6BFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB6Fu, 0xB1A6BBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A6BF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu, 8u, 4u, 0x01AB6Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A6BB JSL -> $01AB6F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6BEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6BFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB6Fu, 0xB1A6BBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A6BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6BBu,0xB1A6BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6BF LDA
    cpu.setA(0x4u, 8);
    goto L_B1A6C1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6BF LDA
    cpu.setA(0x4u, 8);
    goto L_B1A6C1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6BFu,0xB1A6BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A6C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C1u, 8u, 4u, 0x02ACE5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A6C1 JSL -> $02ACE5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6C4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6C5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACE5u, 0xB1A6C1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A6C5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C1u, 8u, 4u, 0x02ACE5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A6C1 JSL -> $02ACE5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6C4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6C5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACE5u, 0xB1A6C1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A6C5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6C1u,0xB1A6C1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6C5u,0xB1A6C5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6C5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A6C7;
L_B1A6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6C7 ASL
    cpu.aslA();
    goto L_B1A6C8;
L_B1A6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6C8 LDA
    cpu.setA(0x10u, 8);
    goto L_B1A6CA;
L_B1A6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CAu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6CA BCS -> $B1A6CE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A6CE; }
    goto L_B1A6CC;
L_B1A6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6CC LDA
    cpu.setA(0xF0u, 8);
    goto L_B1A6CE;
L_B1A6CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CEu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6CE STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B1A6D0;
L_B1A6D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D0u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6D0 EOR
    cpu.logicXor(0xFFu);
    goto L_B1A6D2;
L_B1A6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D2u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6D2 INC
    cpu.inc('A');
    goto L_B1A6D3;
L_B1A6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u, 5u, 3u, cpu.address("absy", 0x00B6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6D3 STA
    hw.write(cpu.address("absy", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B1A6D6;
L_B1A6D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A6D6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A6D6u);return;} hw.unresolvedReturn(0xB1A6D6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A63D_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A63Du: goto L_B1A63D;
    case 0xB1A640u: goto L_B1A640;
    case 0xB1A64Au: goto L_B1A64A;
    case 0xB1A64Bu: goto L_B1A64B;
    case 0xB1A64Eu: goto L_B1A64E;
    case 0xB1A64Fu: goto L_B1A64F;
    case 0xB1A652u: goto L_B1A652;
    case 0xB1A655u: goto L_B1A655;
    case 0xB1A657u: goto L_B1A657;
    case 0xB1A659u: goto L_B1A659;
    case 0xB1A65Cu: goto L_B1A65C;
    case 0xB1A65Fu: goto L_B1A65F;
    case 0xB1A660u: goto L_B1A660;
    case 0xB1A662u: goto L_B1A662;
    case 0xB1A664u: goto L_B1A664;
    case 0xB1A666u: goto L_B1A666;
    case 0xB1A667u: goto L_B1A667;
    case 0xB1A66Bu: goto L_B1A66B;
    case 0xB1A66Du: goto L_B1A66D;
    case 0xB1A670u: goto L_B1A670;
    case 0xB1A674u: goto L_B1A674;
    case 0xB1A677u: goto L_B1A677;
    case 0xB1A678u: goto L_B1A678;
    case 0xB1A67Au: goto L_B1A67A;
    case 0xB1A67Cu: goto L_B1A67C;
    case 0xB1A67Eu: goto L_B1A67E;
    case 0xB1A680u: goto L_B1A680;
    case 0xB1A682u: goto L_B1A682;
    case 0xB1A684u: goto L_B1A684;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A63D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Du, 6u, 3u, cpu.address("abs", 0xA77Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A63D JSR -> $B1A77C stack real
    { cpu.push16Value(hw,0xA63Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA640u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA77Cu), 0xB1A63Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A640;
L_B1A640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA640u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA640u,0xB1A640u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA640u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA640u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A640 BRA -> $B1A64A
    goto L_B1A64A;
L_B1A64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Au,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A64A PHX
    cpu.push("PHX", hw);
    goto L_B1A64B;
L_B1A64B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu, 4u + ((((0x1626u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A64B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1626u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A64E;
L_B1A64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A64E INC
    cpu.inc('A');
    goto L_B1A64F;
L_B1A64F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Fu, 5u, 3u, cpu.address("absy", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A64F STA
    hw.write(cpu.address("absy", 0x1626u), cpu.a, cpu.m8?8:16);
    goto L_B1A652;
L_B1A652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u, 4u + ((((0x1626u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A652 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x1626u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A655;
L_B1A655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA655u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA655u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A655 CPX
    cpu.compareX(0x8u);
    goto L_B1A657;
L_B1A657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA657u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA657u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A657 BCS -> $B1A65F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A65F; }
    goto L_B1A659;
L_B1A659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA659u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA659u, 4u + ((((0xA61Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA61Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A659 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA61Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A65C;
L_B1A65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Cu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A65C STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_B1A65F;
L_B1A65F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A65F TXA
    cpu.transfer("TXA");
    goto L_B1A660;
L_B1A660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A660 CMP
    cpu.compareA(0x8u);
    goto L_B1A662;
L_B1A662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA662u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA662u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA662u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A662 BCC -> $B1A666
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A666; }
    goto L_B1A664;
L_B1A664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA664u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA664u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA664u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A664 LDA
    cpu.setA(0x8u, 8);
    goto L_B1A666;
L_B1A666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA666u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA666u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A666 PLX
    cpu.pop("PLX", hw);
    goto L_B1A667;
L_B1A667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u, 8u, 4u, 0x02ACE5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A667 JSL -> $02ACE5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA66Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA66Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACE5u, 0xB1A667u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A66B;
L_B1A66B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA66Bu,0xB1A66Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A66B LDA
    cpu.setA(0x2u, 8);
    goto L_B1A66D;
L_B1A66D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Du, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A66D STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A670;
L_B1A670:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA670u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA670u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA670u, 8u, 4u, 0x01AB72u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A670 JSL -> $01AB72 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA673u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA674u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB72u, 0xB1A670u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A674;
L_B1A674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA674u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA674u,0xB1A674u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA674u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA674u, 4u + ((((0x00B6u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x00B6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A674 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A677;
L_B1A677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA677u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA677u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A677 ASL
    cpu.aslA();
    goto L_B1A678;
L_B1A678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A678 LDA
    cpu.setA(0x10u, 8);
    goto L_B1A67A;
L_B1A67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A67A BCC -> $B1A67E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A67E; }
    goto L_B1A67C;
L_B1A67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A67C LDA
    cpu.setA(0xF0u, 8);
    goto L_B1A67E;
L_B1A67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A67E STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B1A680;
L_B1A680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA680u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA680u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A680 LDA
    cpu.setA(0xD0u, 8);
    goto L_B1A682;
L_B1A682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A682 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A684;
L_B1A684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A684 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A684u);return;} hw.unresolvedReturn(0xB1A684u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_F1CE3E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xF1CE3Du: goto L_F1CE3D;
    case 0xF1CE3Eu: goto L_F1CE3E;
    case 0xF1CE40u: goto L_F1CE40;
    case 0xF1CE43u: goto L_F1CE43;
    case 0xF1CE45u: goto L_F1CE45;
    case 0xF1CE47u: goto L_F1CE47;
    case 0xF1CE49u: goto L_F1CE49;
    case 0xF1CE4Au: goto L_F1CE4A;
    case 0xF1CE4Cu: goto L_F1CE4C;
    case 0xF1CE4Eu: goto L_F1CE4E;
    case 0xF1CE51u: goto L_F1CE51;
    case 0xF1CE53u: goto L_F1CE53;
    case 0xF1CE56u: goto L_F1CE56;
    case 0xF1CE58u: goto L_F1CE58;
    case 0xF1CE5Au: goto L_F1CE5A;
    case 0xF1CE5Cu: goto L_F1CE5C;
    case 0xF1CEA8u: goto L_F1CEA8;
    case 0xF1CEAAu: goto L_F1CEAA;
    case 0xF1CEADu: goto L_F1CEAD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_F1CE3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE3Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE3Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE3Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $F1CE3D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xF1CE3Du);return;} hw.unresolvedReturn(0xF1CE3Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE3Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE3Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $F1CE3D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xF1CE3Du);return;} hw.unresolvedReturn(0xF1CE3Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE3Du,0xF1CE3Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_F1CE3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE3Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE3E STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_F1CE40;
L_F1CE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE40u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE40u, 6u, 3u, cpu.address("abs", 0xABD8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $F1CE40 JSR -> $F1ABD8 stack real
    { cpu.push16Value(hw,0xCE42u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCE43u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABD8u), 0xF1CE40u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_F1CE43;
L_F1CE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE43u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE43u,0xF1CE43u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE43u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE43u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE43 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_F1CE45;
L_F1CE45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE45u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE45 CMP
    cpu.compareA(0x40u);
    goto L_F1CE47;
L_F1CE47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE47u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE47 BPL -> $F1CE4C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_F1CE4C; }
    goto L_F1CE49;
L_F1CE49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE49u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE49 CLC
    cpu.setFlag('C', false);
    goto L_F1CE4A;
L_F1CE4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE4Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE4A ADC
    cpu.adc(0x3u);
    goto L_F1CE4C;
L_F1CE4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE4Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE4C STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_F1CE4E;
L_F1CE4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE4Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE4Eu, 6u, 3u, cpu.address("abs", 0xD0C0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $F1CE4E JSR -> $F1D0C0 stack real
    { cpu.push16Value(hw,0xCE50u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCE51u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD0C0u), 0xF1CE4Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_F1CE51;
L_F1CE51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE51u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE51u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE51u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE51 BCC -> $F1CE3D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_F1CE3D; }
    goto L_F1CE53;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE51u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE51u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE51 BCC -> $F1CE3D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_F1CE3D; }
    goto L_F1CE53;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE51u,0xF1CE51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_F1CE53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE53u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE53u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE53u, 7u, 3u, cpu.address("absx", 0x151Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE53 INC
    cpu.incMem(hw, cpu.address("absx", 0x151Cu), cpu.m8?8:16);
    goto L_F1CE56;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE53u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE53u, 7u, 3u, cpu.address("absx", 0x151Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE53 INC
    cpu.incMem(hw, cpu.address("absx", 0x151Cu), cpu.m8?8:16);
    goto L_F1CE56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE53u,0xF1CE53u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_F1CE56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE56u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE56u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE56 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_F1CE58;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE56u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE56 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_F1CE58;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE56u,0xF1CE56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_F1CE58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE58u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE58u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE58 CMP
    cpu.compareA(0x2u);
    goto L_F1CE5A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE58u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE58 CMP
    cpu.compareA(0x2u);
    goto L_F1CE5A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE58u,0xF1CE58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_F1CE5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE5Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE5Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE5A BCC -> $F1CE3D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_F1CE3D; }
    goto L_F1CE5C;
L_F1CE5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE5Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE5Cu, 3u, 3u, cpu.address("abs", 0xCEA8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CE5C JMP -> $F1CEA8
    goto L_F1CEA8;
L_F1CEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CEA8 LDA
    cpu.setA(0xFFu, 8);
    goto L_F1CEAA;
L_F1CEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEAAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEAAu, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F1CEAA STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_F1CEAD;
L_F1CEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEADu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $F1CEAD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xF1CEADu);return;} hw.unresolvedReturn(0xF1CEADu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

