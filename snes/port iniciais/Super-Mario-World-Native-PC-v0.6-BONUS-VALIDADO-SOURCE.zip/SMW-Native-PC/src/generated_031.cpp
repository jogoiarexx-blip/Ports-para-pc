#include "generated.hpp"
void sub_00816A_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00816Au: goto L_00816A;
    case 0x00816Bu: goto L_00816B;
    case 0x00816Cu: goto L_00816C;
    case 0x00816Eu: goto L_00816E;
    case 0x00816Fu: goto L_00816F;
    case 0x008170u: goto L_008170;
    case 0x008171u: goto L_008171;
    case 0x008172u: goto L_008172;
    case 0x008173u: goto L_008173;
    case 0x008174u: goto L_008174;
    case 0x008176u: goto L_008176;
    case 0x008179u: goto L_008179;
    case 0x00817Cu: goto L_00817C;
    case 0x00817Eu: goto L_00817E;
    case 0x008181u: goto L_008181;
    case 0x008184u: goto L_008184;
    case 0x008186u: goto L_008186;
    case 0x008189u: goto L_008189;
    case 0x00818Cu: goto L_00818C;
    case 0x00818Fu: goto L_00818F;
    case 0x008192u: goto L_008192;
    case 0x008195u: goto L_008195;
    case 0x008198u: goto L_008198;
    case 0x00819Bu: goto L_00819B;
    case 0x00819Eu: goto L_00819E;
    case 0x0081A1u: goto L_0081A1;
    case 0x0081A4u: goto L_0081A4;
    case 0x0081A7u: goto L_0081A7;
    case 0x0081AAu: goto L_0081AA;
    case 0x0081ACu: goto L_0081AC;
    case 0x0081AFu: goto L_0081AF;
    case 0x0081B2u: goto L_0081B2;
    case 0x0081B4u: goto L_0081B4;
    case 0x0081B7u: goto L_0081B7;
    case 0x0081B9u: goto L_0081B9;
    case 0x0081BCu: goto L_0081BC;
    case 0x0081BEu: goto L_0081BE;
    case 0x0081C1u: goto L_0081C1;
    case 0x0081C3u: goto L_0081C3;
    case 0x0081C6u: goto L_0081C6;
    case 0x0081C9u: goto L_0081C9;
    case 0x0081CBu: goto L_0081CB;
    case 0x0081CEu: goto L_0081CE;
    case 0x0081D0u: goto L_0081D0;
    case 0x0081D2u: goto L_0081D2;
    case 0x0081D5u: goto L_0081D5;
    case 0x0081D7u: goto L_0081D7;
    case 0x0081DAu: goto L_0081DA;
    case 0x0081DCu: goto L_0081DC;
    case 0x0081DEu: goto L_0081DE;
    case 0x0081E1u: goto L_0081E1;
    case 0x0081E2u: goto L_0081E2;
    case 0x0081E4u: goto L_0081E4;
    case 0x0081E7u: goto L_0081E7;
    case 0x0081E9u: goto L_0081E9;
    case 0x0081ECu: goto L_0081EC;
    case 0x0081EFu: goto L_0081EF;
    case 0x0081F0u: goto L_0081F0;
    case 0x0081F2u: goto L_0081F2;
    case 0x0081F4u: goto L_0081F4;
    case 0x0081F7u: goto L_0081F7;
    case 0x0081FAu: goto L_0081FA;
    case 0x0081FCu: goto L_0081FC;
    case 0x0081FEu: goto L_0081FE;
    case 0x008201u: goto L_008201;
    case 0x008203u: goto L_008203;
    case 0x008207u: goto L_008207;
    case 0x008209u: goto L_008209;
    case 0x00820Du: goto L_00820D;
    case 0x008210u: goto L_008210;
    case 0x008212u: goto L_008212;
    case 0x008215u: goto L_008215;
    case 0x008217u: goto L_008217;
    case 0x00821Au: goto L_00821A;
    case 0x00821Du: goto L_00821D;
    case 0x008220u: goto L_008220;
    case 0x008222u: goto L_008222;
    case 0x008225u: goto L_008225;
    case 0x008227u: goto L_008227;
    case 0x008229u: goto L_008229;
    case 0x00822Cu: goto L_00822C;
    case 0x00822Du: goto L_00822D;
    case 0x00822Eu: goto L_00822E;
    case 0x008230u: goto L_008230;
    case 0x008232u: goto L_008232;
    case 0x008235u: goto L_008235;
    case 0x008237u: goto L_008237;
    case 0x00823Au: goto L_00823A;
    case 0x00823Du: goto L_00823D;
    case 0x008240u: goto L_008240;
    case 0x008243u: goto L_008243;
    case 0x008246u: goto L_008246;
    case 0x008248u: goto L_008248;
    case 0x00824Bu: goto L_00824B;
    case 0x00824Du: goto L_00824D;
    case 0x008250u: goto L_008250;
    case 0x008252u: goto L_008252;
    case 0x008253u: goto L_008253;
    case 0x008256u: goto L_008256;
    case 0x008259u: goto L_008259;
    case 0x00825Bu: goto L_00825B;
    case 0x00825Eu: goto L_00825E;
    case 0x008261u: goto L_008261;
    case 0x008263u: goto L_008263;
    case 0x008266u: goto L_008266;
    case 0x008268u: goto L_008268;
    case 0x00826Bu: goto L_00826B;
    case 0x00826Du: goto L_00826D;
    case 0x008270u: goto L_008270;
    case 0x008272u: goto L_008272;
    case 0x008275u: goto L_008275;
    case 0x008278u: goto L_008278;
    case 0x00827Au: goto L_00827A;
    case 0x00827Cu: goto L_00827C;
    case 0x00827Fu: goto L_00827F;
    case 0x008281u: goto L_008281;
    case 0x008283u: goto L_008283;
    case 0x008286u: goto L_008286;
    case 0x008289u: goto L_008289;
    case 0x00828Cu: goto L_00828C;
    case 0x00828Fu: goto L_00828F;
    case 0x008292u: goto L_008292;
    case 0x008294u: goto L_008294;
    case 0x008297u: goto L_008297;
    case 0x00829Au: goto L_00829A;
    case 0x00829Du: goto L_00829D;
    case 0x00829Fu: goto L_00829F;
    case 0x0082A1u: goto L_0082A1;
    case 0x0082A4u: goto L_0082A4;
    case 0x0082A7u: goto L_0082A7;
    case 0x0082AAu: goto L_0082AA;
    case 0x0082ADu: goto L_0082AD;
    case 0x0082B0u: goto L_0082B0;
    case 0x0082B3u: goto L_0082B3;
    case 0x0082B6u: goto L_0082B6;
    case 0x0082B9u: goto L_0082B9;
    case 0x0082BCu: goto L_0082BC;
    case 0x0082BEu: goto L_0082BE;
    case 0x0082BFu: goto L_0082BF;
    case 0x0082C0u: goto L_0082C0;
    case 0x0082C1u: goto L_0082C1;
    case 0x0082C2u: goto L_0082C2;
    case 0x0082C3u: goto L_0082C3;
    case 0x0082C4u: goto L_0082C4;
    case 0x0082C6u: goto L_0082C6;
    case 0x0082C8u: goto L_0082C8;
    case 0x0082CAu: goto L_0082CA;
    case 0x0082CDu: goto L_0082CD;
    case 0x0082CFu: goto L_0082CF;
    case 0x0082D2u: goto L_0082D2;
    case 0x0082D4u: goto L_0082D4;
    case 0x0082D7u: goto L_0082D7;
    case 0x0082DAu: goto L_0082DA;
    case 0x0082DDu: goto L_0082DD;
    case 0x0082DFu: goto L_0082DF;
    case 0x0082E2u: goto L_0082E2;
    case 0x0082E5u: goto L_0082E5;
    case 0x0082E6u: goto L_0082E6;
    case 0x0082E8u: goto L_0082E8;
    case 0x0082EBu: goto L_0082EB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00816A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Au,cpu,0x78u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00816A SEI
    cpu.setFlag('I', true);
    goto L_00816B;
L_00816B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Bu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00816B PHP
    cpu.push("PHP", hw);
    goto L_00816C;
L_00816C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00816C REP
    cpu.rep(0x30u);
    goto L_00816E;
L_00816E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Eu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00816E PHA
    cpu.push("PHA", hw);
    goto L_00816F;
L_00816F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Fu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00816F PHX
    cpu.push("PHX", hw);
    goto L_008170;
L_008170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8170u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8170u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008170 PHY
    cpu.push("PHY", hw);
    goto L_008171;
L_008171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8171u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8171u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008171 PHB
    cpu.push("PHB", hw);
    goto L_008172;
L_008172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8172u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8172u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008172 PHK
    cpu.push("PHK", hw);
    goto L_008173;
L_008173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8173u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8173u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008173 PLB
    cpu.pop("PLB", hw);
    goto L_008174;
L_008174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008174 SEP
    cpu.sep(0x30u);
    goto L_008176;
L_008176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8176u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8176u, 4u, 3u, cpu.address("abs", 0x4210u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008176 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008179;
L_008179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8179u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8179u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008179 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DFBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00817C;
L_00817C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00817C BNE -> $008186
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008186; }
    goto L_00817E;
L_00817E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Eu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Eu, 4u, 3u, cpu.address("abs", 0x2142u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00817E LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x2142u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008181;
L_008181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8181u,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8181u, 4u, 3u, cpu.address("abs", 0x1DFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008181 CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0x1DFFu), cpu.x8?8:16));
    goto L_008184;
L_008184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8184u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8184u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008184 BNE -> $00818F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00818F; }
    goto L_008186;
L_008186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8186u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8186u, 4u, 3u, cpu.address("abs", 0x2142u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008186 STA
    hw.write(cpu.address("abs", 0x2142u), cpu.a, cpu.m8?8:16);
    goto L_008189;
L_008189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u, 4u, 3u, cpu.address("abs", 0x1DFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008189 STA
    hw.write(cpu.address("abs", 0x1DFFu), cpu.a, cpu.m8?8:16);
    goto L_00818C;
L_00818C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00818C STZ
    hw.write(cpu.address("abs", 0x1DFBu), 0, cpu.m8?8:16);
    goto L_00818F;
L_00818F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Fu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00818F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DF9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008192;
L_008192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8192u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8192u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008192 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_008195;
L_008195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8195u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8195u, 4u, 3u, cpu.address("abs", 0x1DFAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008195 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DFAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008198;
L_008198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8198u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8198u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008198 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_00819B;
L_00819B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Bu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00819B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DFCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00819E;
L_00819E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Eu, 4u, 3u, cpu.address("abs", 0x2143u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00819E STA
    hw.write(cpu.address("abs", 0x2143u), cpu.a, cpu.m8?8:16);
    goto L_0081A1;
L_0081A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A1u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081A1 STZ
    hw.write(cpu.address("abs", 0x1DF9u), 0, cpu.m8?8:16);
    goto L_0081A4;
L_0081A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A4u, 4u, 3u, cpu.address("abs", 0x1DFAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081A4 STZ
    hw.write(cpu.address("abs", 0x1DFAu), 0, cpu.m8?8:16);
    goto L_0081A7;
L_0081A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A7u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081A7 STZ
    hw.write(cpu.address("abs", 0x1DFCu), 0, cpu.m8?8:16);
    goto L_0081AA;
L_0081AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81AAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081AA LDA
    cpu.setA(0x80u, 8);
    goto L_0081AC;
L_0081AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81ACu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81ACu, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081AC STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_0081AF;
L_0081AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81AFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81AFu, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081AF STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_0081B2;
L_0081B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081B2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x41u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081B4;
L_0081B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B4u, 4u, 3u, cpu.address("abs", 0x2123u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081B4 STA
    hw.write(cpu.address("abs", 0x2123u), cpu.a, cpu.m8?8:16);
    goto L_0081B7;
L_0081B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081B9;
L_0081B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B9u, 4u, 3u, cpu.address("abs", 0x2124u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081B9 STA
    hw.write(cpu.address("abs", 0x2124u), cpu.a, cpu.m8?8:16);
    goto L_0081BC;
L_0081BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081BC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x43u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081BE;
L_0081BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BEu, 4u, 3u, cpu.address("abs", 0x2125u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081BE STA
    hw.write(cpu.address("abs", 0x2125u), cpu.a, cpu.m8?8:16);
    goto L_0081C1;
L_0081C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x44u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081C3;
L_0081C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C3u, 4u, 3u, cpu.address("abs", 0x2130u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081C3 STA
    hw.write(cpu.address("abs", 0x2130u), cpu.a, cpu.m8?8:16);
    goto L_0081C6;
L_0081C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C6u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081C6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081C9;
L_0081C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081C9 BPL -> $0081CE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0081CE; }
    goto L_0081CB;
L_0081CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CBu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CBu, 3u, 3u, cpu.address("abs", 0x82C4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081CB JMP -> $0082C4
    goto L_0082C4;
L_0081CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x40u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081CE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081D0;
L_0081D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081D0 AND
    cpu.logicAnd(0xFBu);
    goto L_0081D2;
L_0081D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D2u, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081D2 STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_0081D5;
L_0081D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081D5 LDA
    cpu.setA(0x9u, 8);
    goto L_0081D7;
L_0081D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D7u, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081D7 STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_0081DA;
L_0081DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081DC;
L_0081DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081DC BEQ -> $0081E7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0081E7; }
    goto L_0081DE;
L_0081DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DEu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081DE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081E1;
L_0081E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081E1 LSR
    cpu.lsrA();
    goto L_0081E2;
L_0081E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081E2 BEQ -> $008246
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008246; }
    goto L_0081E4;
L_0081E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E4u, 3u, 3u, cpu.address("abs", 0x827Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081E4 JMP -> $00827A
    goto L_00827A;
L_0081E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081E7 INC
    cpu.incMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_0081E9;
L_0081E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E9u, 6u, 3u, cpu.address("abs", 0xA488u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0081E9 JSR -> $00A488 stack real
    { cpu.push16Value(hw,0x81EBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x81ECu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA488u), 0x0081E9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0081EC;
L_0081EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81ECu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x81ECu,0x0081ECu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81ECu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81ECu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081EC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081EF;
L_0081EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81EFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081EF LSR
    cpu.lsrA();
    goto L_0081F0;
L_0081F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081F0 BNE -> $008222
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008222; }
    goto L_0081F2;
L_0081F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081F2 BCS -> $0081F7
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_0081F7; }
    goto L_0081F4;
L_0081F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F4u, 6u, 3u, cpu.address("abs", 0x8DACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0081F4 JSR -> $008DAC stack real
    { cpu.push16Value(hw,0x81F6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x81F7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8DACu), 0x0081F4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0081F7;
L_0081F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x81F7u,0x0081F7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F7u, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081F7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081FA;
L_0081FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081FA CMP
    cpu.compareA(0x8u);
    goto L_0081FC;
L_0081FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081FC BNE -> $008209
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008209; }
    goto L_0081FE;
L_0081FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FEu, 4u, 3u, cpu.address("abs", 0x1FFEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FFEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008201;
L_008201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8201u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8201u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008201 BEQ -> $00821A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00821A; }
    goto L_008203;
L_008203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8203u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8203u, 8u, 4u, 0x0C9567u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $008203 JSL -> $0C9567 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8206u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8207u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0C9567u, 0x008203u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008207;
L_008207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8207u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8207u,0x008207u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8207u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8207u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008207 BRA -> $00821A
    goto L_00821A;
L_008209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8209u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8209u, 8u, 4u, 0x0087ADu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $008209 JSL -> $0087AD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x820Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x820Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0087ADu, 0x008209u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00820D;
L_00820D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x820Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x820Du,0x00820Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x820Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x820Du, 4u, 3u, cpu.address("abs", 0x143Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00820D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x143Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008210;
L_008210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8210u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8210u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8210u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008210 BEQ -> $008217
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008217; }
    goto L_008212;
L_008212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8212u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8212u, 6u, 3u, cpu.address("abs", 0xA7C2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008212 JSR -> $00A7C2 stack real
    { cpu.push16Value(hw,0x8214u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8215u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA7C2u), 0x008212u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008215;
L_008215:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8215u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8215u,0x008215u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8215u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8215u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008215 BRA -> $00823D
    goto L_00823D;
L_008217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8217u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8217u, 6u, 3u, cpu.address("abs", 0xA390u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008217 JSR -> $00A390 stack real
    { cpu.push16Value(hw,0x8219u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x821Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA390u), 0x008217u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00821A;
L_00821A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x821Au,0x00821Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Au, 6u, 3u, cpu.address("abs", 0xA436u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00821A JSR -> $00A436 stack real
    { cpu.push16Value(hw,0x821Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x821Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA436u), 0x00821Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00821D;
L_00821D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x821Du,0x00821Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Du, 6u, 3u, cpu.address("abs", 0xA300u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00821D JSR -> $00A300 stack real
    { cpu.push16Value(hw,0x821Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8220u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA300u), 0x00821Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008220;
L_008220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8220u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8220u,0x008220u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8220u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8220u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008220 BRA -> $00823D
    goto L_00823D;
L_008222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8222u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8222u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008222 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13D9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008225;
L_008225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008225 CMP
    cpu.compareA(0xAu);
    goto L_008227;
L_008227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8227u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8227u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008227 BNE -> $008237
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008237; }
    goto L_008229;
L_008229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8229u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8229u, 4u, 3u, cpu.address("abs", 0x1DE8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008229 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1DE8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00822C;
L_00822C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00822C DEY
    cpu.decReg('Y');
    goto L_00822D;
L_00822D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00822D DEY
    cpu.decReg('Y');
    goto L_00822E;
L_00822E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00822E CPY
    cpu.compareY(0x4u);
    goto L_008230;
L_008230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8230u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8230u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008230 BCS -> $008237
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_008237; }
    goto L_008232;
L_008232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8232u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8232u, 6u, 3u, cpu.address("abs", 0xA529u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008232 JSR -> $00A529 stack real
    { cpu.push16Value(hw,0x8234u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8235u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA529u), 0x008232u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008235;
L_008235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8235u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8235u,0x008235u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8235u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8235u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008235 BRA -> $008243
    goto L_008243;
L_008237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8237u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8237u, 6u, 3u, cpu.address("abs", 0xA4E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008237 JSR -> $00A4E3 stack real
    { cpu.push16Value(hw,0x8239u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x823Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA4E3u), 0x008237u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00823A;
L_00823A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x823Au,0x00823Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Au, 6u, 3u, cpu.address("abs", 0xA300u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00823A JSR -> $00A300 stack real
    { cpu.push16Value(hw,0x823Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x823Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA300u), 0x00823Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00823D;
L_00823D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x823Du,0x00823Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Du, 6u, 3u, cpu.address("abs", 0x85D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00823D JSR -> $0085D2 stack real
    { cpu.push16Value(hw,0x823Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8240u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D2u), 0x00823Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008240;
L_008240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8240u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8240u,0x008240u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8240u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8240u, 6u, 3u, cpu.address("abs", 0x8449u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008240 JSR -> $008449 stack real
    { cpu.push16Value(hw,0x8242u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8243u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8449u), 0x008240u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008243;
L_008243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8243u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8243u,0x008243u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8243u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8243u, 6u, 3u, cpu.address("abs", 0x8650u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008243 JSR -> $008650 stack real
    { cpu.push16Value(hw,0x8245u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8246u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8650u), 0x008243u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008246;
L_008246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8246u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8246u,0x008246u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8246u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8246u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008246 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008248;
L_008248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8248u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8248u, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008248 STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_00824B;
L_00824B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00824B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00824D;
L_00824D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Du, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00824D STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_008250;
L_008250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8250u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8250u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008250 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008252;
L_008252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8252u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8252u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008252 CLC
    cpu.setFlag('C', false);
    goto L_008253;
L_008253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8253u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8253u, 4u, 3u, cpu.address("abs", 0x1888u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008253 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1888u), cpu.m8?8:16));
    goto L_008256;
L_008256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8256u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8256u, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008256 STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_008259;
L_008259:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8259u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8259u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8259u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008259 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00825B;
L_00825B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x825Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Bu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Bu, 4u, 3u, cpu.address("abs", 0x1889u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00825B ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1889u), cpu.m8?8:16));
    goto L_00825E;
L_00825E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x825Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Eu, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00825E STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_008261;
L_008261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8261u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8261u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008261 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008263;
L_008263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8263u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8263u, 4u, 3u, cpu.address("abs", 0x210Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008263 STA
    hw.write(cpu.address("abs", 0x210Fu), cpu.a, cpu.m8?8:16);
    goto L_008266;
L_008266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8266u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8266u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008266 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008268;
L_008268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8268u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8268u, 4u, 3u, cpu.address("abs", 0x210Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008268 STA
    hw.write(cpu.address("abs", 0x210Fu), cpu.a, cpu.m8?8:16);
    goto L_00826B;
L_00826B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00826B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00826D;
L_00826D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Du, 4u, 3u, cpu.address("abs", 0x2110u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00826D STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_008270;
L_008270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8270u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8270u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x21u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008270 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x21u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008272;
L_008272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8272u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8272u, 4u, 3u, cpu.address("abs", 0x2110u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008272 STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_008275;
L_008275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8275u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8275u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008275 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008278;
L_008278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8278u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8278u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008278 BEQ -> $008292
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008292; }
    goto L_00827A;
L_00827A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00827A LDA
    cpu.setA(0x81u, 8);
    goto L_00827C;
L_00827C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Cu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Cu, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00827C LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13C6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00827F;
L_00827F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00827F CPY
    cpu.compareY(0x8u);
    goto L_008281;
L_008281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8281u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8281u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008281 BNE -> $0082A1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0082A1; }
    goto L_008283;
L_008283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8283u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8283u, 4u, 3u, cpu.address("abs", 0x0DAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008283 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xDAEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008286;
L_008286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8286u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8286u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8286u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008286 STY
    hw.write(cpu.address("abs", 0x2100u), cpu.y, cpu.x8?8:16);
    goto L_008289;
L_008289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8289u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8289u, 4u, 3u, cpu.address("abs", 0x0D9Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008289 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xD9Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00828C;
L_00828C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Cu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Cu, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00828C STY
    hw.write(cpu.address("abs", 0x420Cu), cpu.y, cpu.x8?8:16);
    goto L_00828F;
L_00828F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Fu, 3u, 3u, cpu.address("abs", 0x838Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00828F JMP -> $00838C
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x838Cu),0x00828Fu); return;
L_008292:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8292u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8292u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8292u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008292 LDY
    cpu.setY(0x24u, 8);
    goto L_008294;
L_008294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8294u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8294u, 4u, 3u, cpu.address("abs", 0x4211u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008294 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4211u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008297;
L_008297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8297u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8297u, 4u, 3u, cpu.address("abs", 0x4209u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008297 STY
    hw.write(cpu.address("abs", 0x4209u), cpu.y, cpu.x8?8:16);
    goto L_00829A;
L_00829A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Au, 4u, 3u, cpu.address("abs", 0x420Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00829A STZ
    hw.write(cpu.address("abs", 0x420Au), 0, cpu.m8?8:16);
    goto L_00829D;
L_00829D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00829D STZ
    hw.write(cpu.address("dp", 0x11u), 0, cpu.m8?8:16);
    goto L_00829F;
L_00829F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00829F LDA
    cpu.setA(0xA1u, 8);
    goto L_0082A1;
L_0082A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082A1 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0082A4;
L_0082A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A4u, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082A4 STZ
    hw.write(cpu.address("abs", 0x2111u), 0, cpu.m8?8:16);
    goto L_0082A7;
L_0082A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082A7 STZ
    hw.write(cpu.address("abs", 0x2111u), 0, cpu.m8?8:16);
    goto L_0082AA;
L_0082AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082AA STZ
    hw.write(cpu.address("abs", 0x2112u), 0, cpu.m8?8:16);
    goto L_0082AD;
L_0082AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82ADu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82ADu, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082AD STZ
    hw.write(cpu.address("abs", 0x2112u), 0, cpu.m8?8:16);
    goto L_0082B0;
L_0082B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u, 4u, 3u, cpu.address("abs", 0x0DAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082B0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDAEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0082B3;
L_0082B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B3u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082B3 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_0082B6;
L_0082B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u, 4u, 3u, cpu.address("abs", 0x0D9Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082B6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0082B9;
L_0082B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B9u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082B9 STA
    hw.write(cpu.address("abs", 0x420Cu), cpu.a, cpu.m8?8:16);
    goto L_0082BC;
L_0082BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082BC REP
    cpu.rep(0x30u);
    goto L_0082BE;
L_0082BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BEu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0082BE PLB
    cpu.pop("PLB", hw);
    goto L_0082BF;
L_0082BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BFu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BFu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082BF PLY
    cpu.pop("PLY", hw);
    goto L_0082C0;
L_0082C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C0u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082C0 PLX
    cpu.pop("PLX", hw);
    goto L_0082C1;
L_0082C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C1u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C1u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082C1 PLA
    cpu.pop("PLA", hw);
    goto L_0082C2;
L_0082C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C2u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0082C2 PLP
    cpu.pop("PLP", hw);
    goto L_0082C3;
L_0082C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82C3u,0x0082C3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0082C3 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x0082C3u);return;}
L_0082C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082C4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0082C6;
L_0082C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082C6 BNE -> $0082F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x0082F7u,0x0082C6u); return; }
    goto L_0082C8;
L_0082C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C8u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082C8 INC
    cpu.incMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_0082CA;
L_0082CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CAu, 4u, 3u, cpu.address("abs", 0x143Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082CA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x143Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0082CD;
L_0082CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082CD BEQ -> $0082D4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0082D4; }
    goto L_0082CF;
L_0082CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CFu, 6u, 3u, cpu.address("abs", 0xA7C2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082CF JSR -> $00A7C2 stack real
    { cpu.push16Value(hw,0x82D1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82D2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA7C2u), 0x0082CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082D2;
L_0082D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82D2u,0x0082D2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082D2 BRA -> $0082E8
    goto L_0082E8;
L_0082D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D4u, 6u, 3u, cpu.address("abs", 0xA436u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082D4 JSR -> $00A436 stack real
    { cpu.push16Value(hw,0x82D6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82D7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA436u), 0x0082D4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082D7;
L_0082D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82D7u,0x0082D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D7u, 6u, 3u, cpu.address("abs", 0xA300u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082D7 JSR -> $00A300 stack real
    { cpu.push16Value(hw,0x82D9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82DAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA300u), 0x0082D7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082DA;
L_0082DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82DAu,0x0082DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DAu,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DAu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082DA BIT
    cpu.bit(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), false);
    goto L_0082DD;
L_0082DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DDu,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082DD BVC -> $0082E8
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_0082E8; }
    goto L_0082DF;
L_0082DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DFu, 6u, 3u, cpu.address("abs", 0x98A9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082DF JSR -> $0098A9 stack real
    { cpu.push16Value(hw,0x82E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82E2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x98A9u), 0x0082DFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082E2;
L_0082E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82E2u,0x0082E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E2u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082E2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0082E5;
L_0082E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082E5 LSR
    cpu.lsrA();
    goto L_0082E6;
L_0082E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082E6 BCS -> $0082EB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_0082EB; }
    goto L_0082E8;
L_0082E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E8u, 6u, 3u, cpu.address("abs", 0x8DACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082E8 JSR -> $008DAC stack real
    { cpu.push16Value(hw,0x82EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82EBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8DACu), 0x0082E8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082EB;
L_0082EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82EBu,0x0082EBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu, 6u, 3u, cpu.address("abs", 0xA488u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082EB JSR -> $00A488 stack real
    { cpu.push16Value(hw,0x82EDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82EEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA488u), 0x0082EBu); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82EEu,0x0082EBu); return;
}

void sub_0082C3_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0082C3u: goto L_0082C3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0082C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0082C3 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x0082C3u);return;}
}

void sub_008439_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008439u: goto L_008439;
    case 0x00843Bu: goto L_00843B;
    case 0x00843Eu: goto L_00843E;
    case 0x008440u: goto L_008440;
    case 0x008443u: goto L_008443;
    case 0x008445u: goto L_008445;
    case 0x008446u: goto L_008446;
    case 0x008448u: goto L_008448;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008439:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8439u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8439u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8439u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008439 LDY
    cpu.setY(0x20u, 8);
    goto L_00843B;
L_00843B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x843Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x843Bu,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x843Bu, 4u, 3u, cpu.address("abs", 0x4212u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00843B BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x4212u), cpu.m8?8:16), false);
    goto L_00843E;
L_00843E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x843Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x843Eu,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x843Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00843E BVS -> $008439
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_008439; }
    goto L_008440;
L_008440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8440u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8440u, 4u, 3u, cpu.address("abs", 0x4212u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008440 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x4212u), cpu.m8?8:16), false);
    goto L_008443;
L_008443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8443u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8443u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8443u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008443 BVC -> $008440
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_008440; }
    goto L_008445;
L_008445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8445u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8445u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008445 DEY
    cpu.decReg('Y');
    goto L_008446;
L_008446:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8446u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8446u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8446u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008446 BNE -> $008445
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008445; }
    goto L_008448;
L_008448:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8448u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8448u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8448u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008448 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008448u);return;} hw.unresolvedReturn(0x008448u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_009F29_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009F29u: goto L_009F29;
    case 0x009F2Bu: goto L_009F2B;
    case 0x009F2Eu: goto L_009F2E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009F29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F29u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009F29 LDA
    cpu.setA(0x1u, 8);
    goto L_009F2B;
L_009F2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Bu, 4u, 3u, cpu.address("abs", 0x0DB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009F2B STA
    hw.write(cpu.address("abs", 0xDB1u), cpu.a, cpu.m8?8:16);
    goto L_009F2E;
L_009F2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009F2E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009F2Eu);return;} hw.unresolvedReturn(0x009F2Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00A2E6_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008494u: goto L_008494;
    case 0x008496u: goto L_008496;
    case 0x008499u: goto L_008499;
    case 0x00849Cu: goto L_00849C;
    case 0x00A2E6u: goto L_00A2E6;
    case 0x00A2EAu: goto L_00A2EA;
    case 0x00A2EBu: goto L_00A2EB;
    case 0x00A2EDu: goto L_00A2ED;
    case 0x00A2EEu: goto L_00A2EE;
    case 0x00A2F0u: goto L_00A2F0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8494u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8494u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008494 LDY
    cpu.setY(0x1Eu, 8);
    goto L_008496;
L_008496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u, 4u + ((((0x8475u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8475u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008496 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x8475u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008499;
L_008499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u, 4u + ((((0x0423u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008499 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x423u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00849C;
L_00849C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849C ASL
    cpu.aslA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x849Du,0x00849Cu); return;
L_00A2E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E6u, 8u, 4u, 0x028AB1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A2E6 JSL -> $028AB1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA2E9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA2EAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x028AB1u, 0x00A2E6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A2EA;
L_00A2EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2EAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EAu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00A2EA PLA
    cpu.pop("PLA", hw);
    goto L_00A2EB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EAu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00A2EA PLA
    cpu.pop("PLA", hw);
    goto L_00A2EB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA2EAu,0x00A2EAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00A2EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2EBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2EB STA
    hw.write(cpu.address("dp", 0x1Du), cpu.a, cpu.m8?8:16);
    goto L_00A2ED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2EB STA
    hw.write(cpu.address("dp", 0x1Du), cpu.a, cpu.m8?8:16);
    goto L_00A2ED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA2EBu,0x00A2EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00A2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2EDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EDu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00A2ED PLA
    cpu.pop("PLA", hw);
    goto L_00A2EE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EDu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00A2ED PLA
    cpu.pop("PLA", hw);
    goto L_00A2EE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA2EDu,0x00A2EDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00A2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2EE STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_00A2F0;
L_00A2F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F0u, 3u, 3u, cpu.address("abs", 0x8494u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A2F0 JMP -> $008494
    goto L_008494;
}

void sub_00A300_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A300u: goto L_00A300;
    case 0x00A302u: goto L_00A302;
    case 0x00A304u: goto L_00A304;
    case 0x00A307u: goto L_00A307;
    case 0x00A309u: goto L_00A309;
    case 0x00A30Bu: goto L_00A30B;
    case 0x00A30Eu: goto L_00A30E;
    case 0x00A311u: goto L_00A311;
    case 0x00A314u: goto L_00A314;
    case 0x00A317u: goto L_00A317;
    case 0x00A31Au: goto L_00A31A;
    case 0x00A31Cu: goto L_00A31C;
    case 0x00A31Fu: goto L_00A31F;
    case 0x00A322u: goto L_00A322;
    case 0x00A325u: goto L_00A325;
    case 0x00A328u: goto L_00A328;
    case 0x00A32Au: goto L_00A32A;
    case 0x00A32Du: goto L_00A32D;
    case 0x00A330u: goto L_00A330;
    case 0x00A333u: goto L_00A333;
    case 0x00A336u: goto L_00A336;
    case 0x00A339u: goto L_00A339;
    case 0x00A33Cu: goto L_00A33C;
    case 0x00A33Fu: goto L_00A33F;
    case 0x00A341u: goto L_00A341;
    case 0x00A344u: goto L_00A344;
    case 0x00A347u: goto L_00A347;
    case 0x00A34Au: goto L_00A34A;
    case 0x00A34Du: goto L_00A34D;
    case 0x00A350u: goto L_00A350;
    case 0x00A353u: goto L_00A353;
    case 0x00A355u: goto L_00A355;
    case 0x00A358u: goto L_00A358;
    case 0x00A35Bu: goto L_00A35B;
    case 0x00A35Eu: goto L_00A35E;
    case 0x00A361u: goto L_00A361;
    case 0x00A363u: goto L_00A363;
    case 0x00A366u: goto L_00A366;
    case 0x00A367u: goto L_00A367;
    case 0x00A368u: goto L_00A368;
    case 0x00A36Bu: goto L_00A36B;
    case 0x00A36Du: goto L_00A36D;
    case 0x00A370u: goto L_00A370;
    case 0x00A373u: goto L_00A373;
    case 0x00A375u: goto L_00A375;
    case 0x00A378u: goto L_00A378;
    case 0x00A37Bu: goto L_00A37B;
    case 0x00A37Eu: goto L_00A37E;
    case 0x00A381u: goto L_00A381;
    case 0x00A383u: goto L_00A383;
    case 0x00A386u: goto L_00A386;
    case 0x00A387u: goto L_00A387;
    case 0x00A388u: goto L_00A388;
    case 0x00A38Bu: goto L_00A38B;
    case 0x00A38Du: goto L_00A38D;
    case 0x00A38Fu: goto L_00A38F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA300u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA300u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A300 REP
    cpu.rep(0x20u);
    goto L_00A302;
L_00A302:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA302u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA302u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA302u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A302 LDX
    cpu.setX(0x4u, 8);
    goto L_00A304;
L_00A304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA304u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA304u, 4u, 3u, cpu.address("abs", 0x0D84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A304 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xD84u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A307;
L_00A307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA307u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA307u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A307 BEQ -> $00A328
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A328; }
    goto L_00A309;
L_00A309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA309u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA309u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A309 LDY
    cpu.setY(0x86u, 8);
    goto L_00A30B;
L_00A30B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA30Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Bu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Bu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A30B STY
    hw.write(cpu.address("abs", 0x2121u), cpu.y, cpu.x8?8:16);
    goto L_00A30E;
L_00A30E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA30Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A30E LDA
    cpu.setA(0x2200u, 16);
    goto L_00A311;
L_00A311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA311u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA311u, 5u, 3u, cpu.address("abs", 0x4320u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A311 STA
    hw.write(cpu.address("abs", 0x4320u), cpu.a, cpu.m8?8:16);
    goto L_00A314;
L_00A314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA314u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA314u, 5u, 3u, cpu.address("abs", 0x0D82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A314 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A317;
L_00A317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA317u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA317u, 5u, 3u, cpu.address("abs", 0x4322u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A317 STA
    hw.write(cpu.address("abs", 0x4322u), cpu.a, cpu.m8?8:16);
    goto L_00A31A;
L_00A31A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA31Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A31A LDY
    cpu.setY(0x0u, 8);
    goto L_00A31C;
L_00A31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA31Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Cu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Cu, 4u, 3u, cpu.address("abs", 0x4324u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A31C STY
    hw.write(cpu.address("abs", 0x4324u), cpu.y, cpu.x8?8:16);
    goto L_00A31F;
L_00A31F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA31Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A31F LDA
    cpu.setA(0x14u, 16);
    goto L_00A322;
L_00A322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA322u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA322u, 5u, 3u, cpu.address("abs", 0x4325u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A322 STA
    hw.write(cpu.address("abs", 0x4325u), cpu.a, cpu.m8?8:16);
    goto L_00A325;
L_00A325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA325u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA325u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A325 STX
    hw.write(cpu.address("abs", 0x420Bu), cpu.x, cpu.x8?8:16);
    goto L_00A328;
L_00A328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA328u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA328u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A328 LDY
    cpu.setY(0x80u, 8);
    goto L_00A32A;
L_00A32A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA32Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Au, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A32A STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_00A32D;
L_00A32D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA32Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A32D LDA
    cpu.setA(0x1801u, 16);
    goto L_00A330;
L_00A330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA330u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA330u, 5u, 3u, cpu.address("abs", 0x4320u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A330 STA
    hw.write(cpu.address("abs", 0x4320u), cpu.a, cpu.m8?8:16);
    goto L_00A333;
L_00A333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA333u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA333u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A333 LDA
    cpu.setA(0x67F0u, 16);
    goto L_00A336;
L_00A336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA336u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA336u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A336 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00A339;
L_00A339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA339u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA339u, 5u, 3u, cpu.address("abs", 0x0D99u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A339 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD99u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A33C;
L_00A33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA33Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Cu, 5u, 3u, cpu.address("abs", 0x4322u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A33C STA
    hw.write(cpu.address("abs", 0x4322u), cpu.a, cpu.m8?8:16);
    goto L_00A33F;
L_00A33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A33F LDY
    cpu.setY(0x7Eu, 8);
    goto L_00A341;
L_00A341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA341u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA341u, 4u, 3u, cpu.address("abs", 0x4324u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A341 STY
    hw.write(cpu.address("abs", 0x4324u), cpu.y, cpu.x8?8:16);
    goto L_00A344;
L_00A344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA344u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA344u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A344 LDA
    cpu.setA(0x20u, 16);
    goto L_00A347;
L_00A347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA347u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA347u, 5u, 3u, cpu.address("abs", 0x4325u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A347 STA
    hw.write(cpu.address("abs", 0x4325u), cpu.a, cpu.m8?8:16);
    goto L_00A34A;
L_00A34A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Au,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Au, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A34A STX
    hw.write(cpu.address("abs", 0x420Bu), cpu.x, cpu.x8?8:16);
    goto L_00A34D;
L_00A34D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A34D LDA
    cpu.setA(0x6000u, 16);
    goto L_00A350;
L_00A350:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA350u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA350u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA350u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A350 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00A353;
L_00A353:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA353u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA353u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA353u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A353 LDX
    cpu.setX(0x0u, 8);
    goto L_00A355;
L_00A355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA355u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA355u, 5u + ((((0x0D85u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0D85u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A355 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xD85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A358;
L_00A358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA358u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA358u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA358u, 5u, 3u, cpu.address("abs", 0x4322u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A358 STA
    hw.write(cpu.address("abs", 0x4322u), cpu.a, cpu.m8?8:16);
    goto L_00A35B;
L_00A35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA35Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A35B LDA
    cpu.setA(0x40u, 16);
    goto L_00A35E;
L_00A35E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA35Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Eu, 5u, 3u, cpu.address("abs", 0x4325u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A35E STA
    hw.write(cpu.address("abs", 0x4325u), cpu.a, cpu.m8?8:16);
    goto L_00A361;
L_00A361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA361u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA361u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A361 LDY
    cpu.setY(0x4u, 8);
    goto L_00A363;
L_00A363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA363u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA363u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A363 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_00A366;
L_00A366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA366u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA366u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A366 INX
    cpu.inc('X');
    goto L_00A367;
L_00A367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA367u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA367u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A367 INX
    cpu.inc('X');
    goto L_00A368;
L_00A368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u, 4u, 3u, cpu.address("abs", 0x0D84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A368 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0xD84u), cpu.x8?8:16));
    goto L_00A36B;
L_00A36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A36B BCC -> $00A355
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00A355; }
    goto L_00A36D;
L_00A36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A36D LDA
    cpu.setA(0x6100u, 16);
    goto L_00A370;
L_00A370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA370u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA370u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A370 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00A373;
L_00A373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA373u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA373u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA373u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A373 LDX
    cpu.setX(0x0u, 8);
    goto L_00A375;
L_00A375:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA375u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA375u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA375u, 5u + ((((0x0D8Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0D8Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A375 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xD8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A378;
L_00A378:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA378u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA378u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA378u, 5u, 3u, cpu.address("abs", 0x4322u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A378 STA
    hw.write(cpu.address("abs", 0x4322u), cpu.a, cpu.m8?8:16);
    goto L_00A37B;
L_00A37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A37B LDA
    cpu.setA(0x40u, 16);
    goto L_00A37E;
L_00A37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Eu, 5u, 3u, cpu.address("abs", 0x4325u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A37E STA
    hw.write(cpu.address("abs", 0x4325u), cpu.a, cpu.m8?8:16);
    goto L_00A381;
L_00A381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA381u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA381u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A381 LDY
    cpu.setY(0x4u, 8);
    goto L_00A383;
L_00A383:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA383u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA383u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA383u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A383 STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_00A386;
L_00A386:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA386u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA386u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA386u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A386 INX
    cpu.inc('X');
    goto L_00A387;
L_00A387:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA387u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA387u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA387u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A387 INX
    cpu.inc('X');
    goto L_00A388;
L_00A388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA388u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA388u, 4u, 3u, cpu.address("abs", 0x0D84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A388 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0xD84u), cpu.x8?8:16));
    goto L_00A38B;
L_00A38B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A38B BCC -> $00A375
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00A375; }
    goto L_00A38D;
L_00A38D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A38D SEP
    cpu.sep(0x20u);
    goto L_00A38F;
L_00A38F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A38F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A38Fu);return;} hw.unresolvedReturn(0x00A38Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00B983_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00B8E3u: goto L_00B8E3;
    case 0x00B8E6u: goto L_00B8E6;
    case 0x00B8E8u: goto L_00B8E8;
    case 0x00B8EAu: goto L_00B8EA;
    case 0x00B8ECu: goto L_00B8EC;
    case 0x00B8EDu: goto L_00B8ED;
    case 0x00B8EFu: goto L_00B8EF;
    case 0x00B8F1u: goto L_00B8F1;
    case 0x00B8F3u: goto L_00B8F3;
    case 0x00B8F5u: goto L_00B8F5;
    case 0x00B8F6u: goto L_00B8F6;
    case 0x00B8F8u: goto L_00B8F8;
    case 0x00B8FAu: goto L_00B8FA;
    case 0x00B8FDu: goto L_00B8FD;
    case 0x00B8FFu: goto L_00B8FF;
    case 0x00B901u: goto L_00B901;
    case 0x00B902u: goto L_00B902;
    case 0x00B903u: goto L_00B903;
    case 0x00B904u: goto L_00B904;
    case 0x00B906u: goto L_00B906;
    case 0x00B907u: goto L_00B907;
    case 0x00B909u: goto L_00B909;
    case 0x00B90Bu: goto L_00B90B;
    case 0x00B90Cu: goto L_00B90C;
    case 0x00B90Fu: goto L_00B90F;
    case 0x00B911u: goto L_00B911;
    case 0x00B912u: goto L_00B912;
    case 0x00B914u: goto L_00B914;
    case 0x00B916u: goto L_00B916;
    case 0x00B917u: goto L_00B917;
    case 0x00B919u: goto L_00B919;
    case 0x00B91Bu: goto L_00B91B;
    case 0x00B91Cu: goto L_00B91C;
    case 0x00B91Eu: goto L_00B91E;
    case 0x00B91Fu: goto L_00B91F;
    case 0x00B921u: goto L_00B921;
    case 0x00B924u: goto L_00B924;
    case 0x00B926u: goto L_00B926;
    case 0x00B928u: goto L_00B928;
    case 0x00B929u: goto L_00B929;
    case 0x00B92Au: goto L_00B92A;
    case 0x00B92Bu: goto L_00B92B;
    case 0x00B92Du: goto L_00B92D;
    case 0x00B930u: goto L_00B930;
    case 0x00B933u: goto L_00B933;
    case 0x00B935u: goto L_00B935;
    case 0x00B936u: goto L_00B936;
    case 0x00B938u: goto L_00B938;
    case 0x00B939u: goto L_00B939;
    case 0x00B93Bu: goto L_00B93B;
    case 0x00B93Du: goto L_00B93D;
    case 0x00B93Fu: goto L_00B93F;
    case 0x00B942u: goto L_00B942;
    case 0x00B944u: goto L_00B944;
    case 0x00B946u: goto L_00B946;
    case 0x00B947u: goto L_00B947;
    case 0x00B948u: goto L_00B948;
    case 0x00B94Au: goto L_00B94A;
    case 0x00B94Cu: goto L_00B94C;
    case 0x00B94Fu: goto L_00B94F;
    case 0x00B950u: goto L_00B950;
    case 0x00B953u: goto L_00B953;
    case 0x00B955u: goto L_00B955;
    case 0x00B956u: goto L_00B956;
    case 0x00B958u: goto L_00B958;
    case 0x00B959u: goto L_00B959;
    case 0x00B95Au: goto L_00B95A;
    case 0x00B95Cu: goto L_00B95C;
    case 0x00B95Du: goto L_00B95D;
    case 0x00B95Fu: goto L_00B95F;
    case 0x00B960u: goto L_00B960;
    case 0x00B961u: goto L_00B961;
    case 0x00B963u: goto L_00B963;
    case 0x00B966u: goto L_00B966;
    case 0x00B969u: goto L_00B969;
    case 0x00B96Au: goto L_00B96A;
    case 0x00B96Du: goto L_00B96D;
    case 0x00B96Eu: goto L_00B96E;
    case 0x00B96Fu: goto L_00B96F;
    case 0x00B970u: goto L_00B970;
    case 0x00B972u: goto L_00B972;
    case 0x00B973u: goto L_00B973;
    case 0x00B974u: goto L_00B974;
    case 0x00B976u: goto L_00B976;
    case 0x00B977u: goto L_00B977;
    case 0x00B978u: goto L_00B978;
    case 0x00B97Au: goto L_00B97A;
    case 0x00B97Cu: goto L_00B97C;
    case 0x00B97Eu: goto L_00B97E;
    case 0x00B980u: goto L_00B980;
    case 0x00B983u: goto L_00B983;
    case 0x00B985u: goto L_00B985;
    case 0x00B987u: goto L_00B987;
    case 0x00B988u: goto L_00B988;
    case 0x00B98Au: goto L_00B98A;
    case 0x00B98Cu: goto L_00B98C;
    case 0x00B98Fu: goto L_00B98F;
    case 0x00B991u: goto L_00B991;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00B8E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E3u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B8E3 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB8E5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB8E6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B8E3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B8E6;
L_00B8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB8E6u,0x00B8E6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8E6 CMP
    cpu.compareA(0xFFu);
    goto L_00B8E8;
L_00B8E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8E8 BNE -> $00B8ED
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B8ED; }
    goto L_00B8EA;
L_00B8EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8EA SEP
    cpu.sep(0x10u);
    goto L_00B8EC;
L_00B8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ECu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ECu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B8EC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00B8ECu);return;} hw.unresolvedReturn(0x00B8ECu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00B8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8ED STA
    hw.write(cpu.address("dp", 0x8Fu), cpu.a, cpu.m8?8:16);
    goto L_00B8EF;
L_00B8EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8EF AND
    cpu.logicAnd(0xE0u);
    goto L_00B8F1;
L_00B8F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F1 CMP
    cpu.compareA(0xE0u);
    goto L_00B8F3;
L_00B8F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F3 BEQ -> $00B8FF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B8FF; }
    goto L_00B8F5;
L_00B8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F5u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F5u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B8F5 PHA
    cpu.push("PHA", hw);
    goto L_00B8F6;
L_00B8F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B8F8;
L_00B8F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F8 REP
    cpu.rep(0x20u);
    goto L_00B8FA;
L_00B8FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8FA AND
    cpu.logicAnd(0x1Fu);
    goto L_00B8FD;
L_00B8FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8FD BRA -> $00B911
    goto L_00B911;
L_00B8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8FF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B901;
L_00B901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B901 ASL
    cpu.aslA();
    goto L_00B902;
L_00B902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB902u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB902u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B902 ASL
    cpu.aslA();
    goto L_00B903;
L_00B903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB903u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB903u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B903 ASL
    cpu.aslA();
    goto L_00B904;
L_00B904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB904u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB904u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B904 AND
    cpu.logicAnd(0xE0u);
    goto L_00B906;
L_00B906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB906u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB906u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B906 PHA
    cpu.push("PHA", hw);
    goto L_00B907;
L_00B907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB907u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB907u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB907u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B907 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B909;
L_00B909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB909u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB909u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B909 AND
    cpu.logicAnd(0x3u);
    goto L_00B90B;
L_00B90B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B90B XBA
    cpu.xba();
    goto L_00B90C;
L_00B90C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Cu, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B90C JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB90Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB90Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B90Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B90F;
L_00B90F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB90Fu,0x00B90Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B90F REP
    cpu.rep(0x20u);
    goto L_00B911;
L_00B911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB911u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB911u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B911 INC
    cpu.inc('A');
    goto L_00B912;
L_00B912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB912u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB912u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B912 STA
    hw.write(cpu.address("dp", 0x8Du), cpu.a, cpu.m8?8:16);
    goto L_00B914;
L_00B914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB914u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB914u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB914u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B914 SEP
    cpu.sep(0x20u);
    goto L_00B916;
L_00B916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB916u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB916u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB916u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B916 PLA
    cpu.pop("PLA", hw);
    goto L_00B917;
L_00B917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB917u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB917u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB917u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B917 BEQ -> $00B930
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B930; }
    goto L_00B919;
L_00B919:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB919u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB919u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB919u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B919 BMI -> $00B966
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00B966; }
    goto L_00B91B;
L_00B91B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91B ASL
    cpu.aslA();
    goto L_00B91C;
L_00B91C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91C BPL -> $00B93F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00B93F; }
    goto L_00B91E;
L_00B91E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91E ASL
    cpu.aslA();
    goto L_00B91F;
L_00B91F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91F BPL -> $00B94C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00B94C; }
    goto L_00B921;
L_00B921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B921 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB923u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB924u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B921u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B924;
L_00B924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB924u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB924u,0x00B924u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B924 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B926;
L_00B926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB926u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB926u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B926 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B928;
L_00B928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB928u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB928u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB928u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B928 INC
    cpu.inc('A');
    goto L_00B929;
L_00B929:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB929u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB929u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB929u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B929 INY
    cpu.inc('Y');
    goto L_00B92A;
L_00B92A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Au,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B92A DEX
    cpu.decReg('X');
    goto L_00B92B;
L_00B92B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B92B BNE -> $00B926
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B926; }
    goto L_00B92D;
L_00B92D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Du, 3u, 3u, cpu.address("abs", 0xB8E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B92D JMP -> $00B8E3
    goto L_00B8E3;
L_00B930:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB930u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB930u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB930u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B930 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB932u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB933u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B930u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B933;
L_00B933:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB933u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB933u,0x00B933u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB933u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB933u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B933 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B935;
L_00B935:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB935u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB935u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB935u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B935 INY
    cpu.inc('Y');
    goto L_00B936;
L_00B936:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB936u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB936u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB936u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B936 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B938;
L_00B938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB938u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB938u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB938u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B938 DEX
    cpu.decReg('X');
    goto L_00B939;
L_00B939:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB939u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB939u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB939u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B939 STX
    hw.write(cpu.address("dp", 0x8Du), cpu.x, cpu.x8?8:16);
    goto L_00B93B;
L_00B93B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B93B BNE -> $00B930
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B930; }
    goto L_00B93D;
L_00B93D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B93D BRA -> $00B8E3
    goto L_00B8E3;
L_00B93F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Fu, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B93F JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB941u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB942u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B93Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B942;
L_00B942:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB942u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB942u,0x00B942u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB942u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB942u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B942 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B944;
L_00B944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB944u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB944u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB944u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B944 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B946;
L_00B946:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB946u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB946u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB946u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B946 INY
    cpu.inc('Y');
    goto L_00B947;
L_00B947:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB947u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB947u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB947u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B947 DEX
    cpu.decReg('X');
    goto L_00B948;
L_00B948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB948u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB948u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB948u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B948 BNE -> $00B944
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B944; }
    goto L_00B94A;
L_00B94A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B94A BRA -> $00B8E3
    goto L_00B8E3;
L_00B94C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B94C JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB94Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB94Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B94Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B94F;
L_00B94F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB94Fu,0x00B94Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B94F XBA
    cpu.xba();
    goto L_00B950;
L_00B950:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB950u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB950u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB950u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B950 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB952u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB953u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B950u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B953;
L_00B953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB953u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB953u,0x00B953u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB953u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB953u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B953 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B955;
L_00B955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB955u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB955u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B955 XBA
    cpu.xba();
    goto L_00B956;
L_00B956:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB956u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB956u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB956u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B956 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B958;
L_00B958:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB958u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB958u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB958u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B958 INY
    cpu.inc('Y');
    goto L_00B959;
L_00B959:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB959u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB959u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB959u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B959 DEX
    cpu.decReg('X');
    goto L_00B95A;
L_00B95A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B95A BEQ -> $00B963
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B963; }
    goto L_00B95C;
L_00B95C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B95C XBA
    cpu.xba();
    goto L_00B95D;
L_00B95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Du,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B95D STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B95F;
L_00B95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B95F INY
    cpu.inc('Y');
    goto L_00B960;
L_00B960:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB960u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB960u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB960u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B960 DEX
    cpu.decReg('X');
    goto L_00B961;
L_00B961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B961 BNE -> $00B955
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B955; }
    goto L_00B963;
L_00B963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB963u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB963u, 3u, 3u, cpu.address("abs", 0xB8E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B963 JMP -> $00B8E3
    goto L_00B8E3;
L_00B966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B966 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB968u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB969u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B966u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B969;
L_00B969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB969u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB969u,0x00B969u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB969u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB969u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B969 XBA
    cpu.xba();
    goto L_00B96A;
L_00B96A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Au, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B96A JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB96Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB96Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B96Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B96D;
L_00B96D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB96Du,0x00B96Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B96D TAX
    cpu.transfer("TAX");
    goto L_00B96E;
L_00B96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B96E PHY
    cpu.push("PHY", hw);
    goto L_00B96F;
L_00B96F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Fu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B96F TXY
    cpu.transfer("TXY");
    goto L_00B970;
L_00B970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B970 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B972;
L_00B972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB972u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B972 TYX
    cpu.transfer("TYX");
    goto L_00B973;
L_00B973:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB973u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB973u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB973u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B973 PLY
    cpu.pop("PLY", hw);
    goto L_00B974;
L_00B974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB974u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB974u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B974 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B976;
L_00B976:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB976u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB976u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB976u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B976 INY
    cpu.inc('Y');
    goto L_00B977;
L_00B977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB977u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB977u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B977 INX
    cpu.inc('X');
    goto L_00B978;
L_00B978:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB978u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB978u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB978u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B978 REP
    cpu.rep(0x20u);
    goto L_00B97A;
L_00B97A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Au,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B97A DEC
    cpu.decMem(hw, cpu.address("dp", 0x8Du), cpu.m8?8:16);
    goto L_00B97C;
L_00B97C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B97C SEP
    cpu.sep(0x20u);
    goto L_00B97E;
L_00B97E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B97E BNE -> $00B96E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B96E; }
    goto L_00B980;
L_00B980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB980u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB980u, 3u, 3u, cpu.address("abs", 0xB8E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B980 JMP -> $00B8E3
    goto L_00B8E3;
L_00B983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB983u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB983u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Au) & 0xFFFFu), 3u, 0u);
    // $00B983 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B985;
L_00B985:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB985u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB985u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB985u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B985 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B987;
L_00B987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB987u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B987 INX
    cpu.inc('X');
    goto L_00B988;
L_00B988:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB988u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB988u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB988u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B988 BNE -> $00B98F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B98F; }
    goto L_00B98A;
L_00B98A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B98A LDX
    cpu.setX(0x0u, 8);
    goto L_00B98C;
L_00B98C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B98C BRA -> $00B974
    goto L_00B974;
L_00B98F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Fu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B98F STX
    hw.write(cpu.address("dp", 0x8Au), cpu.x, cpu.x8?8:16);
    goto L_00B991;
L_00B991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB991u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB991u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB991u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B991 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00B991u);return;} hw.unresolvedReturn(0x00B991u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00D5F2_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00D73Fu: goto L_00D73F;
    case 0x00D741u: goto L_00D741;
    case 0x00D742u: goto L_00D742;
    case 0x00D744u: goto L_00D744;
    case 0x00D745u: goto L_00D745;
    case 0x00D748u: goto L_00D748;
    case 0x00D74Au: goto L_00D74A;
    case 0x00D74Du: goto L_00D74D;
    case 0x00D74Fu: goto L_00D74F;
    case 0x00D751u: goto L_00D751;
    case 0x00D754u: goto L_00D754;
    case 0x00D756u: goto L_00D756;
    case 0x00D758u: goto L_00D758;
    case 0x00D75Au: goto L_00D75A;
    case 0x00D75Cu: goto L_00D75C;
    case 0x00D75Fu: goto L_00D75F;
    case 0x00D760u: goto L_00D760;
    case 0x00D762u: goto L_00D762;
    case 0x00D764u: goto L_00D764;
    case 0x00D767u: goto L_00D767;
    case 0x00D769u: goto L_00D769;
    case 0x00D76Bu: goto L_00D76B;
    case 0x00D76Eu: goto L_00D76E;
    case 0x00D76Fu: goto L_00D76F;
    case 0x00D770u: goto L_00D770;
    case 0x00D771u: goto L_00D771;
    case 0x00D772u: goto L_00D772;
    case 0x00D774u: goto L_00D774;
    case 0x00D775u: goto L_00D775;
    case 0x00D778u: goto L_00D778;
    case 0x00D77Au: goto L_00D77A;
    case 0x00D77Bu: goto L_00D77B;
    case 0x00D77Cu: goto L_00D77C;
    case 0x00D77Fu: goto L_00D77F;
    case 0x00D781u: goto L_00D781;
    case 0x00D783u: goto L_00D783;
    case 0x00D785u: goto L_00D785;
    case 0x00D788u: goto L_00D788;
    case 0x00D78Au: goto L_00D78A;
    case 0x00D78Cu: goto L_00D78C;
    case 0x00D78Fu: goto L_00D78F;
    case 0x00D790u: goto L_00D790;
    case 0x00D792u: goto L_00D792;
    case 0x00D794u: goto L_00D794;
    case 0x00D795u: goto L_00D795;
    case 0x00D798u: goto L_00D798;
    case 0x00D79Bu: goto L_00D79B;
    case 0x00D79Du: goto L_00D79D;
    case 0x00D7A0u: goto L_00D7A0;
    case 0x00D7A2u: goto L_00D7A2;
    case 0x00D7A4u: goto L_00D7A4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00D73F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D73F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16));
    goto L_00D741;
L_00D741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD741u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD741u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D741 TAY
    cpu.transfer("TAY");
    goto L_00D742;
L_00D742:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD742u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD742u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD742u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D742 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D744;
L_00D744:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD744u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD744u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD744u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D744 SEC
    cpu.setFlag('C', true);
    goto L_00D745;
L_00D745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD745u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD745u, 4u + ((((0xD535u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD535u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D745 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0xD535u), cpu.m8?8:16));
    goto L_00D748;
L_00D748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD748u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD748u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D748 BEQ -> $00D76B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D76B; }
    goto L_00D74A;
L_00D74A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Au,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Au, 4u + ((((0xD535u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD535u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D74A EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xD535u), cpu.m8?8:16));
    goto L_00D74D;
L_00D74D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D74D BPL -> $00D76B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D76B; }
    goto L_00D74F;
L_00D74F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D74F REP
    cpu.rep(0x20u);
    goto L_00D751;
L_00D751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD751u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD751u, 5u + ((((0xD345u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD345u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D751 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xD345u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D754;
L_00D754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD754u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD754u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D754 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x86u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D756;
L_00D756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD756u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD756u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D756 BEQ -> $00D75F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D75F; }
    goto L_00D758;
L_00D758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD758u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD758u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D758 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x72u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D75A;
L_00D75A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD75Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D75A BNE -> $00D75F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D75F; }
    goto L_00D75C;
L_00D75C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD75Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Cu, 5u + ((((0xD43Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD43Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D75C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xD43Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D75F;
L_00D75F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD75Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D75F CLC
    cpu.setFlag('C', false);
    goto L_00D760;
L_00D760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD760u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD760u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D760 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x7Au), cpu.m8?8:16));
    goto L_00D762;
L_00D762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD762u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD762u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D762 BRA -> $00D7A0
    goto L_00D7A0;
L_00D764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD764u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD764u, 6u, 3u, cpu.address("abs", 0xD968u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D764 JSR -> $00D968 stack real
    { cpu.push16Value(hw,0xD766u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD767u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD968u), 0x00D764u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00D767;
L_00D767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD767u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD767u,0x00D767u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD767u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD767u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D767 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D769;
L_00D769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD769u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD769u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D769 BNE -> $00D7A4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D7A4; }
    goto L_00D76B;
L_00D76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Bu, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D76B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13E1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D76E;
L_00D76E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D76E LSR
    cpu.lsrA();
    goto L_00D76F;
L_00D76F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D76F TAY
    cpu.transfer("TAY");
    goto L_00D770;
L_00D770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD770u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD770u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D770 LSR
    cpu.lsrA();
    goto L_00D771;
L_00D771:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD771u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD771u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD771u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D771 TAX
    cpu.transfer("TAX");
    goto L_00D772;
L_00D772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD772u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD772u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D772 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D774;
L_00D774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD774u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD774u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D774 SEC
    cpu.setFlag('C', true);
    goto L_00D775;
L_00D775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD775u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD775u, 4u + ((((0xD5CAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD5CAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D775 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0xD5CAu), cpu.m8?8:16));
    goto L_00D778;
L_00D778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD778u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD778u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D778 BPL -> $00D77C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D77C; }
    goto L_00D77A;
L_00D77A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D77A INY
    cpu.inc('Y');
    goto L_00D77B;
L_00D77B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D77B INY
    cpu.inc('Y');
    goto L_00D77C;
L_00D77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Cu, 4u, 3u, cpu.address("abs", 0x1493u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D77C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1493u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D77F;
L_00D77F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D77F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16));
    goto L_00D781;
L_00D781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD781u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD781u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D781 REP
    cpu.rep(0x20u);
    goto L_00D783;
L_00D783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD783u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD783u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D783 BNE -> $00D78C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D78C; }
    goto L_00D785;
L_00D785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD785u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD785u, 5u + ((((0xD309u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD309u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D785 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD309u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D788;
L_00D788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD788u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD788u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D788 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), false);
    goto L_00D78A;
L_00D78A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Au,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D78A BMI -> $00D78F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D78F; }
    goto L_00D78C;
L_00D78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu, 5u + ((((0xD2CDu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD2CDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D78C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD2CDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D78F;
L_00D78F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D78F CLC
    cpu.setFlag('C', false);
    goto L_00D790;
L_00D790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD790u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD790u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D790 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x7Au), cpu.m8?8:16));
    goto L_00D792;
L_00D792:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD792u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD792u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD792u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D792 STA
    hw.write(cpu.address("dp", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_00D794;
L_00D794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D794 SEC
    cpu.setFlag('C', true);
    goto L_00D795;
L_00D795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD795u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD795u, 5u + ((((0xD5C9u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD5C9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D795 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0xD5C9u), cpu.m8?8:16));
    goto L_00D798;
L_00D798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD798u,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD798u, 5u + ((((0xD2CDu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD2CDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D798 EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xD2CDu), cpu.m8?8:16));
    goto L_00D79B;
L_00D79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D79B BMI -> $00D7A2
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D7A2; }
    goto L_00D79D;
L_00D79D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Du, 5u + ((((0xD5C9u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD5C9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D79D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xD5C9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D7A0;
L_00D7A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D7A0 STA
    hw.write(cpu.address("dp", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_00D7A2;
L_00D7A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D7A2 SEP
    cpu.sep(0x20u);
    goto L_00D7A4;
L_00D7A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D7A4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00D7A4u);return;} hw.unresolvedReturn(0x00D7A4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CC68_E0M1X1C0_part10(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00DC16u: goto L_00DC16;
    case 0x00DC18u: goto L_00DC18;
    case 0x00DC1Au: goto L_00DC1A;
    case 0x00DC1Du: goto L_00DC1D;
    case 0x00DC1Fu: goto L_00DC1F;
    case 0x00DC20u: goto L_00DC20;
    case 0x00DC22u: goto L_00DC22;
    case 0x00DC24u: goto L_00DC24;
    case 0x00DC25u: goto L_00DC25;
    case 0x00DC26u: goto L_00DC26;
    case 0x00DC27u: goto L_00DC27;
    case 0x00DC28u: goto L_00DC28;
    case 0x00DC29u: goto L_00DC29;
    case 0x00DC2Au: goto L_00DC2A;
    case 0x00DC2Bu: goto L_00DC2B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00DC16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC16u))return;
  // 15 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC16 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00DC18;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC16 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00DC18;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC16 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00DC18;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC16 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00DC18;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC16 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00DC18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC16u,0x00DC16u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC18u))return;
  // 15 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC18 BEQ -> $00DC2C
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC2Cu,0x00DC18u); return; }
    goto L_00DC1A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC18 BEQ -> $00DC2C
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC2Cu,0x00DC18u); return; }
    goto L_00DC1A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC18 BEQ -> $00DC2C
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC2Cu,0x00DC18u); return; }
    goto L_00DC1A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC18 BEQ -> $00DC2C
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC2Cu,0x00DC18u); return; }
    goto L_00DC1A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC18 BEQ -> $00DC2C
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC2Cu,0x00DC18u); return; }
    goto L_00DC1A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC18u,0x00DC18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Au))return;
  // 15 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1496u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC1D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au, 5u, 3u, cpu.address("abs", 0x1496u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1496u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC1D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1496u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC1D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1496u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC1D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1496u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC1D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC1Au,0x00DC1Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Du))return;
  // 15 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1D ORA
    cpu.logicOr(0x8u);
    goto L_00DC1F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1D ORA
    cpu.logicOr(0x8D08u);
    goto L_00DC20;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1D ORA
    cpu.logicOr(0x8u);
    goto L_00DC1F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1D ORA
    cpu.logicOr(0x8u);
    goto L_00DC1F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1D ORA
    cpu.logicOr(0x8u);
    goto L_00DC1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC1Du,0x00DC1Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1F STA
    hw.write(cpu.address("abs", 0x1496u), cpu.a, cpu.m8?8:16);
    goto L_00DC22;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1F STA
    hw.write(cpu.address("abs", 0x1496u), cpu.a, cpu.m8?8:16);
    goto L_00DC22;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1F STA
    hw.write(cpu.address("abs", 0x1496u), cpu.a, cpu.m8?8:16);
    goto L_00DC22;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1F STA
    hw.write(cpu.address("abs", 0x1496u), cpu.a, cpu.m8?8:16);
    goto L_00DC22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC1Fu,0x00DC1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC20u))return;
  // 11 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC20u,cpu,0x96u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC20 STX
    hw.write(cpu.address("dpy", 0x14u), cpu.x, cpu.x8?8:16);
    goto L_00DC22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC20u,0x00DC20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC22u))return;
  // 15 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC22 AND
    cpu.logicAnd(0x7u);
    goto L_00DC24;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC22 AND
    cpu.logicAnd(0xD007u);
    goto L_00DC25;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC22 AND
    cpu.logicAnd(0x7u);
    goto L_00DC24;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC22 AND
    cpu.logicAnd(0x7u);
    goto L_00DC24;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC22 AND
    cpu.logicAnd(0x7u);
    goto L_00DC24;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC22u,0x00DC22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC24u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC24u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC24 BNE -> $00DC2C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC2Cu,0x00DC24u); return; }
    goto L_00DC26;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC24u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC24 BNE -> $00DC2C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC2Cu,0x00DC24u); return; }
    goto L_00DC26;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC24u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC24 BNE -> $00DC2C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC2Cu,0x00DC24u); return; }
    goto L_00DC26;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC24u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC24 BNE -> $00DC2C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC2Cu,0x00DC24u); return; }
    goto L_00DC26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC24u,0x00DC24u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC25u))return;
  // 11 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC25u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC25u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA5u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC25 ASL
    cpu.aslMem(hw, cpu.address("dp", 0xA5u), cpu.m8?8:16);
    goto L_00DC27;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC25u,0x00DC25u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC26u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC26 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC28;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC26 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC28;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC26 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC28;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC26 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC28;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC26u,0x00DC26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC27u))return;
  // 11 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC27u,cpu,0x76u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC27u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x49u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC27 ROR
    cpu.rorMem(hw, cpu.address("dpx", 0x49u), cpu.m8?8:16);
    goto L_00DC29;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC27u,0x00DC27u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC28u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC28 EOR
    cpu.logicXor(0x1u);
    goto L_00DC2A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC28 EOR
    cpu.logicXor(0x1u);
    goto L_00DC2A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC28 EOR
    cpu.logicXor(0x1u);
    goto L_00DC2A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC28 EOR
    cpu.logicXor(0x1u);
    goto L_00DC2A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC28u,0x00DC28u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC29u))return;
  // 11 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC29u,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC29u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x85u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00DC29 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0x85u), cpu.m8?8:16));
    goto L_00DC2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC29u,0x00DC29u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Au))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC2A STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC2Cu,0x00DC2Au); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC2A STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC2Cu,0x00DC2Au); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC2A STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC2Cu,0x00DC2Au); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC2A STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC2Cu,0x00DC2Au); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC2Au,0x00DC2Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Bu))return;
  // 11 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Bu,cpu,0x76u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Bu, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x60u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC2B ROR
    cpu.rorMem(hw, cpu.address("dpx", 0x60u), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC2Du,0x00DC2Bu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC2Bu,0x00DC2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E0M1X1CQ_part12(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE96u: goto L_00EE96;
    case 0x00EE98u: goto L_00EE98;
    case 0x00EE99u: goto L_00EE99;
    case 0x00EE9Au: goto L_00EE9A;
    case 0x00EE9Bu: goto L_00EE9B;
    case 0x00EE9Cu: goto L_00EE9C;
    case 0x00EE9Du: goto L_00EE9D;
    case 0x00EE9Eu: goto L_00EE9E;
    case 0x00EE9Fu: goto L_00EE9F;
    case 0x00EEA0u: goto L_00EEA0;
    case 0x00EEA2u: goto L_00EEA2;
    case 0x00EEA3u: goto L_00EEA3;
    case 0x00EEA6u: goto L_00EEA6;
    case 0x00EEA8u: goto L_00EEA8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE96u))return;
  // 17 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0x3u);
    goto L_00EE98;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0xF003u);
    goto L_00EE99;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0xF003u);
    goto L_00EE99;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0x3u);
    goto L_00EE98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE96u,0x00EE96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE98u))return;
  // 6 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE98 BEQ -> $00EEAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EEAAu,0x00EE98u); return; }
    goto L_00EE9A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE98 BEQ -> $00EEAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EEAAu,0x00EE98u); return; }
    goto L_00EE9A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE98u,0x00EE98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE99u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE99 BPL -> $00EE64
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE64u,0x00EE99u); return; }
    goto L_00EE9B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE99 BPL -> $00EE64
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE64u,0x00EE99u); return; }
    goto L_00EE9B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE99u,0x00EE99u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Au))return;
  // 6 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9A CMP
    cpu.compareA(0x2u);
    goto L_00EE9C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9A CMP
    cpu.compareA(0x2u);
    goto L_00EE9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Au,0x00EE9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Bu))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE9Du,true);
    hw.requestDispatch(0x0082C3u,0x00EE9Bu);return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE9Du,true);
    hw.requestDispatch(0x0082C3u,0x00EE9Bu);return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,0x00EE9Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Cu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9C BCS -> $00EED1
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EE9Cu); return; }
    goto L_00EE9E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,0x00EE9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Du))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xC2u) & 0xFFFFu), 2u, 0u);
    // $00EE9D AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0xC2u), cpu.m8?8:16));
    goto L_00EE9F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xC2u) & 0xFFFFu), 2u, 0u);
    // $00EE9D AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0xC2u), cpu.m8?8:16));
    goto L_00EE9F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Du,0x00EE9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Eu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9E REP
    cpu.rep(0x20u);
    goto L_00EEA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,0x00EE9Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Fu))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu, 6u, 3u, cpu.address("abs", 0x9AA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE9F JSR -> $009AA5 stack real
    { cpu.push16Value(hw,0xEEA1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEA2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9AA5u), 0x00EE9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEA2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu, 6u, 3u, cpu.address("abs", 0x9AA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE9F JSR -> $009AA5 stack real
    { cpu.push16Value(hw,0xEEA1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEA2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9AA5u), 0x00EE9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,0x00EE9Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA0u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA0u,0x00EEA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA2u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA2 SEC
    cpu.setFlag('C', true);
    goto L_00EEA3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA2 SEC
    cpu.setFlag('C', true);
    goto L_00EEA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA2u,0x00EEA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA3u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA3 SBC
    cpu.sbc(0x10u);
    goto L_00EEA6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA3 SBC
    cpu.sbc(0x10u);
    goto L_00EEA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA3u,0x00EEA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA6u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA6 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_00EEA8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA6 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_00EEA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA6u,0x00EEA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA8u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA8 SEP
    cpu.sep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAAu,0x00EEA8u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA8 SEP
    cpu.sep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAAu,0x00EEA8u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA8u,0x00EEA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E1M1X1CQ_part13(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EEE4u: goto L_00EEE4;
    case 0x00EEE6u: goto L_00EEE6;
    case 0x00EEE9u: goto L_00EEE9;
    case 0x00EEEBu: goto L_00EEEB;
    case 0x00EEEDu: goto L_00EEED;
    case 0x00EEEFu: goto L_00EEEF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE4u))return;
  // 24 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE4 BNE -> $00EEEF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EEEF; }
    goto L_00EEE6;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE4 BNE -> $00EEEF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EEEF; }
    goto L_00EEE6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE4 BNE -> $00EEEF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EEEF; }
    goto L_00EEE6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE4 BNE -> $00EEEF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EEEF; }
    goto L_00EEE6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE4u,0x00EEE4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE6u))return;
  // 24 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u, 5u, 3u, cpu.address("abs", 0x13EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE6 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13EDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEE9;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE6 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13EDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEE9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u, 5u, 3u, cpu.address("abs", 0x13EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE6 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13EDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEE9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE6 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13EDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEE9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE6u,0x00EEE6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE9u))return;
  // 24 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00EF05u,0x00EEE9u); return; }
    goto L_00EEEB;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00EF05u,0x00EEE9u); return; }
    goto L_00EEEB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00EF05u,0x00EEE9u); return; }
    goto L_00EEEB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00EF05u,0x00EEE9u); return; }
    goto L_00EEEB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE9u,0x00EEE9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEBu))return;
  // 24 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEBu,0x00EEEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEDu))return;
  // 24 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEDu,0x00EEEDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEFu))return;
  // 24 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 5u, 3u, cpu.address("abs", 0x13EEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF2u,0x00EEEFu); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 5u, 3u, cpu.address("abs", 0x13EEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF2u,0x00EEEFu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF2u,0x00EEEFu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF2u,0x00EEEFu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEFu,0x00EEEFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_01F0D3_E1M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01F0D3u: goto L_01F0D3;
    case 0x01F0D6u: goto L_01F0D6;
    case 0x01F0D9u: goto L_01F0D9;
    case 0x01F0DAu: goto L_01F0DA;
    case 0x01F0DCu: goto L_01F0DC;
    case 0x01F0DFu: goto L_01F0DF;
    case 0x01F0E1u: goto L_01F0E1;
    case 0x01F0E4u: goto L_01F0E4;
    case 0x01F0E7u: goto L_01F0E7;
    case 0x01F0E9u: goto L_01F0E9;
    case 0x01F0EBu: goto L_01F0EB;
    case 0x01F0EEu: goto L_01F0EE;
    case 0x01F0F1u: goto L_01F0F1;
    case 0x01F0F2u: goto L_01F0F2;
    case 0x01F0F5u: goto L_01F0F5;
    case 0x01F0F8u: goto L_01F0F8;
    case 0x01F0FBu: goto L_01F0FB;
    case 0x01F0FDu: goto L_01F0FD;
    case 0x01F100u: goto L_01F100;
    case 0x01F103u: goto L_01F103;
    case 0x01F105u: goto L_01F105;
    case 0x01F106u: goto L_01F106;
    case 0x01F109u: goto L_01F109;
    case 0x01F10Au: goto L_01F10A;
    case 0x01F10Cu: goto L_01F10C;
    case 0x01F10Fu: goto L_01F10F;
    case 0x01F111u: goto L_01F111;
    case 0x01F114u: goto L_01F114;
    case 0x01F116u: goto L_01F116;
    case 0x01F119u: goto L_01F119;
    case 0x01F11Cu: goto L_01F11C;
    case 0x01F11Fu: goto L_01F11F;
    case 0x01F122u: goto L_01F122;
    case 0x01F123u: goto L_01F123;
    case 0x01F126u: goto L_01F126;
    case 0x01F127u: goto L_01F127;
    case 0x01F128u: goto L_01F128;
    case 0x01F12Bu: goto L_01F12B;
    case 0x01F12Du: goto L_01F12D;
    case 0x01F12Eu: goto L_01F12E;
    case 0x01F131u: goto L_01F131;
    case 0x01F133u: goto L_01F133;
    case 0x01F136u: goto L_01F136;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01F0D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0D3 LDA
    cpu.setA(0x8D06u, 16);
    goto L_01F0D6;
L_01F0D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D6u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D6u, 5u + 1u, 3u, cpu.address("absy", 0x221Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0D6 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x221Du), cpu.m8?8:16));
    goto L_01F0D9;
L_01F0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0D9 LSR
    cpu.lsrA();
    goto L_01F0DA;
L_01F0DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DAu,cpu,0xB3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DAu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x05u) & 0xFFFFu), 2u, 0u);
    // $01F0DA LDA
    cpu.loadA(hw.readW(cpu.addressStackIndirectY(hw, 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0DC;
L_01F0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DCu, 5u, 3u, cpu.address("abs", 0x18D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0DC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18D6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0DF;
L_01F0DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0DF BEQ -> $01F12D
    if (cpu.z) { hw.addCpuInternalCycles(2u); goto L_01F12D; }
    goto L_01F0E1;
L_01F0E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E1u, 5u, 3u, cpu.address("abs", 0x18D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0E1 STZ
    hw.write(cpu.address("abs", 0x18D6u), 0, cpu.m8?8:16);
    goto L_01F0E4;
L_01F0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0E4 CMP
    cpu.compareA(0xD001u);
    goto L_01F0E7;
L_01F0E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E7u,cpu,0x11u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E7u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xEEu) & 0xFFFFu), 2u, 0u);
    // $01F0E7 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectY(hw, 0xEEu), cpu.m8?8:16));
    goto L_01F0E9;
L_01F0E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E9u,cpu,0xD4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E9u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F0E9 PEI
    cpu.push16Value(hw, hw.readW(cpu.address("dp", 0x18u),16));
    goto L_01F0EB;
L_01F0EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0EBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0EBu, 5u, 3u, cpu.address("abs", 0x18D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0EB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0EE;
L_01F0EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0EEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0EEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0EE CMP
    cpu.compareA(0xD00Au);
    goto L_01F0F1;
L_01F0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F1u,cpu,0x3Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0F1 TSC
    cpu.tsc();
    goto L_01F0F2;
L_01F0F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F2u, 5u, 3u, cpu.address("abs", 0x18D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0F2 STZ
    hw.write(cpu.address("abs", 0x18D4u), 0, cpu.m8?8:16);
    goto L_01F0F5;
L_01F0F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0F5 LDA
    cpu.setA(0x8074u, 16);
    goto L_01F0F8;
L_01F0F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F8u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F8u, 5u, 3u, cpu.address("abs", 0x03C9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0F8 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x3C9u), cpu.m8?8:16), false);
    goto L_01F0FB;
L_01F0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0FB BNE -> $01F116
    if (!cpu.z) { hw.addCpuInternalCycles(2u); goto L_01F116; }
    goto L_01F0FD;
L_01F0FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0FD LDA
    cpu.setA(0x8D29u, 16);
    goto L_01F100;
L_01F100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF100u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF100u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xAD1Du + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $01F100 JSR (AD1D,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xAD1Du+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0xF102u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF103u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x01F100u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01F103;
L_01F103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF103u))return;
  if (!(cpu.e==true && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF103u,0x01F103u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF103u,cpu,0x32u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF103u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Fu) & 0xFFFFu), 2u, 0u);
    // $01F103 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirect(hw, 0xFu), cpu.m8?8:16));
    goto L_01F105;
L_01F105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF105u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF105u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F105 CLC
    cpu.setFlag('C', false);
    goto L_01F106;
L_01F106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF106u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF106u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F106 ADC
    cpu.adc(0xC902u);
    goto L_01F109;
L_01F109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF109u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF109u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F109 ASL
    cpu.aslA();
    goto L_01F10A;
L_01F10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF10Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F10A BCC -> $01F111
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01F111; }
    goto L_01F10C;
L_01F10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF10Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F10C SBC
    cpu.sbc(0xEE0Au);
    goto L_01F10F;
L_01F10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Fu,cpu,0x31u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Fu) & 0xFFFFu), 2u, 0u);
    // $01F10F AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirectY(hw, 0xFu), cpu.m8?8:16));
    goto L_01F111;
L_01F111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF111u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF111u, 5u, 3u, cpu.address("abs", 0x0F32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F111 STA
    hw.write(cpu.address("abs", 0xF32u), cpu.a, cpu.m8?8:16);
    goto L_01F114;
L_01F114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF114u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF114u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F114 BRA -> $01F12D
    goto L_01F12D;
L_01F116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF116u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF116u, 8u, 3u, cpu.address("abs", 0x18D5u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F116 INC
    cpu.incMem(hw, cpu.address("abs", 0x18D5u), cpu.m8?8:16);
    goto L_01F119;
L_01F119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF119u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF119u, 5u, 3u, cpu.address("abs", 0x18D5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F119 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18D5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F11C;
L_01F11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F11C CMP
    cpu.compareA(0xD002u);
    goto L_01F11F;
L_01F11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Fu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Fu, 5u, 3u, cpu.address("abs", 0xD59Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F11F ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xD59Cu), cpu.m8?8:16));
    goto L_01F122;
L_01F122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF122u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF122u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F122 CLC
    cpu.setFlag('C', false);
    goto L_01F123;
L_01F123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF123u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF123u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F123 LDA
    cpu.setA(0x8D6Au, 16);
    goto L_01F126;
L_01F126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF126u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF126u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F126 PHX
    cpu.push("PHX", hw);
    goto L_01F127;
L_01F127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF127u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF127u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F127 CLC
    cpu.setFlag('C', false);
    goto L_01F128;
L_01F128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF128u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF128u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F128 LDY
    cpu.setY(0x8C20u, 16);
    goto L_01F12B;
L_01F12B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Bu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Bu, 9u, 3u, cpu.address("absx", 0x6018u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F12B DEC
    cpu.decMem(hw, cpu.address("absx", 0x6018u), cpu.m8?8:16);
    goto L_01F12E;
L_01F12D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F12D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01F12Du);return;} hw.unresolvedReturn(0x01F12Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF12Du,0x01F12Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Eu, 5u + 1u, 3u, cpu.address("absx", 0x1558u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F12E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F131;
L_01F131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF131u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF131u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F131 BNE -> $01F136
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F136; }
    goto L_01F133;
L_01F133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF133u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF133u, 6u, 3u, cpu.address("absx", 0x1594u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F133 STZ
    hw.write(cpu.address("absx", 0x1594u), 0, cpu.m8?8:16);
    goto L_01F136;
L_01F136:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF136u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF136u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF136u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F136 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01F136u);return;} hw.unresolvedReturn(0x01F136u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_028752_E1M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02884Eu: goto L_02884E;
    case 0x028850u: goto L_028850;
    case 0x028852u: goto L_028852;
    case 0x028855u: goto L_028855;
    case 0x028858u: goto L_028858;
    case 0x02885Bu: goto L_02885B;
    case 0x02885Eu: goto L_02885E;
    case 0x02885Fu: goto L_02885F;
    case 0x028861u: goto L_028861;
    case 0x028864u: goto L_028864;
    case 0x028866u: goto L_028866;
    case 0x028869u: goto L_028869;
    case 0x02886Bu: goto L_02886B;
    case 0x02886Cu: goto L_02886C;
    case 0x02886Eu: goto L_02886E;
    case 0x028871u: goto L_028871;
    case 0x028873u: goto L_028873;
    case 0x028874u: goto L_028874;
    case 0x028875u: goto L_028875;
    case 0x028876u: goto L_028876;
    case 0x028877u: goto L_028877;
    case 0x02887Au: goto L_02887A;
    case 0x02887Du: goto L_02887D;
    case 0x02887Fu: goto L_02887F;
    case 0x028881u: goto L_028881;
    case 0x028883u: goto L_028883;
    case 0x028884u: goto L_028884;
    case 0x028885u: goto L_028885;
    case 0x028886u: goto L_028886;
    case 0x028887u: goto L_028887;
    case 0x028888u: goto L_028888;
    case 0x028889u: goto L_028889;
    case 0x02888Bu: goto L_02888B;
    case 0x02888Du: goto L_02888D;
    case 0x02888Eu: goto L_02888E;
    case 0x02888Fu: goto L_02888F;
    case 0x028891u: goto L_028891;
    case 0x028893u: goto L_028893;
    case 0x028896u: goto L_028896;
    case 0x028898u: goto L_028898;
    case 0x02889Au: goto L_02889A;
    case 0x02889Bu: goto L_02889B;
    case 0x02889Du: goto L_02889D;
    case 0x0288A0u: goto L_0288A0;
    case 0x0288DCu: goto L_0288DC;
    case 0x0288DEu: goto L_0288DE;
    case 0x0288E1u: goto L_0288E1;
    case 0x0288E2u: goto L_0288E2;
    case 0x0288E4u: goto L_0288E4;
    case 0x0288E6u: goto L_0288E6;
    case 0x0288E7u: goto L_0288E7;
    case 0x0288E8u: goto L_0288E8;
    case 0x0288EAu: goto L_0288EA;
    case 0x0288EDu: goto L_0288ED;
    case 0x0288F1u: goto L_0288F1;
    case 0x0288F3u: goto L_0288F3;
    case 0x0288F5u: goto L_0288F5;
    case 0x0288F7u: goto L_0288F7;
    case 0x0288F9u: goto L_0288F9;
    case 0x0288FCu: goto L_0288FC;
    case 0x0288FDu: goto L_0288FD;
    case 0x028901u: goto L_028901;
    case 0x028902u: goto L_028902;
    case 0x028904u: goto L_028904;
    case 0x028905u: goto L_028905;
    case 0x028908u: goto L_028908;
    case 0x028909u: goto L_028909;
    case 0x02890Bu: goto L_02890B;
    case 0x02890Du: goto L_02890D;
    case 0x028910u: goto L_028910;
    case 0x028912u: goto L_028912;
    case 0x028914u: goto L_028914;
    case 0x028916u: goto L_028916;
    case 0x028918u: goto L_028918;
    case 0x02891Bu: goto L_02891B;
    case 0x02891Eu: goto L_02891E;
    case 0x02891Fu: goto L_02891F;
    case 0x028921u: goto L_028921;
    case 0x028922u: goto L_028922;
    case 0x028925u: goto L_028925;
    case 0x028927u: goto L_028927;
    case 0x02892Au: goto L_02892A;
    case 0x02892Du: goto L_02892D;
    case 0x028930u: goto L_028930;
    case 0x028932u: goto L_028932;
    case 0x028933u: goto L_028933;
    case 0x028934u: goto L_028934;
    case 0x028936u: goto L_028936;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02884E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02884E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_028850;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02884E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_028850;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x884Eu,0x02884Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8850u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8850u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8850u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028850 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_028852;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8850u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8850u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028850 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_028852;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8850u,0x028850u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028852:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8852u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8852u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8852u, 5u + 1u, 3u, cpu.address("absx", 0x873Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028852 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x873Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028855;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8852u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8852u, 4u + 1u, 3u, cpu.address("absx", 0x873Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028852 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x873Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028855;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8852u,0x028852u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8855u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8855u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8855u, 6u, 3u, cpu.address("absy", 0x16B1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028855 STA
    hw.write(cpu.address("absy", 0x16B1u), cpu.a, cpu.m8?8:16);
    goto L_028858;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8855u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8855u, 5u, 3u, cpu.address("absy", 0x16B1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028855 STA
    hw.write(cpu.address("absy", 0x16B1u), cpu.a, cpu.m8?8:16);
    goto L_028858;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8855u,0x028855u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8858u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8858u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8858u, 5u + 1u, 3u, cpu.address("absx", 0x873Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028858 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x873Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02885B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8858u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8858u, 4u + 1u, 3u, cpu.address("absx", 0x873Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028858 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x873Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02885B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8858u,0x028858u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02885B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu, 6u, 3u, cpu.address("absy", 0x16B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02885B STA
    hw.write(cpu.address("absy", 0x16B5u), cpu.a, cpu.m8?8:16);
    goto L_02885E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu, 5u, 3u, cpu.address("absy", 0x16B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02885B STA
    hw.write(cpu.address("absy", 0x16B5u), cpu.a, cpu.m8?8:16);
    goto L_02885E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x885Bu,0x02885Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02885E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02885E TXA
    cpu.transfer("TXA");
    goto L_02885F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02885E TXA
    cpu.transfer("TXA");
    goto L_02885F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x885Eu,0x02885Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02885F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02885F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_028861;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02885F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_028861;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x885Fu,0x02885Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8861u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u, 6u, 3u, cpu.address("absy", 0x16C9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028861 STA
    hw.write(cpu.address("absy", 0x16C9u), cpu.a, cpu.m8?8:16);
    goto L_028864;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u, 5u, 3u, cpu.address("absy", 0x16C9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028861 STA
    hw.write(cpu.address("absy", 0x16C9u), cpu.a, cpu.m8?8:16);
    goto L_028864;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8861u,0x028861u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8864u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028864 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028866;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028864 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028866;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8864u,0x028864u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028866:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8866u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8866u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8866u, 6u, 3u, cpu.address("absy", 0x16C1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028866 STA
    hw.write(cpu.address("absy", 0x16C1u), cpu.a, cpu.m8?8:16);
    goto L_028869;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8866u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8866u, 5u, 3u, cpu.address("absy", 0x16C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028866 STA
    hw.write(cpu.address("absy", 0x16C1u), cpu.a, cpu.m8?8:16);
    goto L_028869;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8866u,0x028866u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8869u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028869 LDA
    cpu.setA(0x9908u, 16);
    goto L_02886C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028869 LDA
    cpu.setA(0x8u, 8);
    goto L_02886B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8869u,0x028869u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02886B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Bu, 5u, 3u, cpu.address("absy", 0x16C5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02886B STA
    hw.write(cpu.address("absy", 0x16C5u), cpu.a, cpu.m8?8:16);
    goto L_02886E;
L_02886C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02886C CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_02886E;
L_02886E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Eu, 5u + 1u, 3u, cpu.address("absy", 0x1699u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02886E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1699u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028871;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Eu, 4u + 1u, 3u, cpu.address("absy", 0x1699u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02886E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1699u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028871;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x886Eu,0x02886Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8871u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8871u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8871u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028871 CMP
    cpu.compareA(0xD007u);
    goto L_028874;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8871u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8871u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028871 CMP
    cpu.compareA(0x7u);
    goto L_028873;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8871u,0x028871u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8873u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8873u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028873 BNE -> $02887A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02887A; }
    goto L_028875;
L_028874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8874u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8874u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028874 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xA9u), cpu.m8?8:16));
    goto L_028876;
L_028875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8875u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8875u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028875 LDA
    cpu.setA(0xFFu, 8);
    goto L_028877;
L_028876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8876u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8876u, 6u, 4u, ((0x18CE99u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028876 SBC
    cpu.sbc(hw.readW(((0x18CE99u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_02887A;
L_028877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8877u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8877u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8877u, 5u, 3u, cpu.address("absy", 0x18CEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028877 STA
    hw.write(cpu.address("absy", 0x18CEu), cpu.a, cpu.m8?8:16);
    goto L_02887A;
L_02887A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Au, 6u, 3u, cpu.address("abs", 0x86EDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02887A JSR -> $0286ED stack real
    { cpu.push16Value(hw,0x887Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x887Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x86EDu), 0x02887Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02887D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Au, 6u, 3u, cpu.address("abs", 0x86EDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02887A JSR -> $0286ED stack real
    { cpu.push16Value(hw,0x887Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x887Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x86EDu), 0x02887Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02887D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x887Au,0x02887Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02887D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02887D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02887F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02887D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02887F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x887Du,0x02887Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02887F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02887F BEQ -> $0288A0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0288A0; }
    goto L_028881;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02887F BEQ -> $0288A0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0288A0; }
    goto L_028881;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x887Fu,0x02887Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8881u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8881u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8881u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028881 CMP
    cpu.compareA(0xD00Au);
    goto L_028884;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8881u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8881u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028881 CMP
    cpu.compareA(0xAu);
    goto L_028883;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8881u,0x028881u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8883u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8883u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028883 BNE -> $028885
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_028885; }
    goto L_028885;
L_028884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8884u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8884u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0x8886u,true);
    hw.requestDispatch(0x0082C3u,0x028884u);return;
L_028885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8885u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8885u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028885 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028887;
L_028886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8886u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8886u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028886 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xC9u), cpu.m8?8:16));
    goto L_028888;
L_028887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8887u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8887u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028887 CMP
    cpu.compareA(0x8u);
    goto L_028889;
L_028888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8888u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8888u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $028888 PHP
    cpu.push("PHP", hw);
    goto L_028889;
L_028889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8889u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8889u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8889u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028889 BCS -> $0288DC
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_0288DC; }
    goto L_02888B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8889u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8889u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028889 BCS -> $0288DC
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_0288DC; }
    goto L_02888B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8889u,0x028889u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02888B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02888B CMP
    cpu.compareA(0x9006u);
    goto L_02888E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02888B CMP
    cpu.compareA(0x6u);
    goto L_02888D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x888Bu,0x02888Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02888D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02888D BCC -> $0288DC
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0288DC; }
    goto L_02888F;
L_02888E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu, 5u, 3u, cpu.address("abs", 0x07C9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02888E EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x7C9u), cpu.m8?8:16));
    goto L_028891;
L_02888F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02888F CMP
    cpu.compareA(0x7u);
    goto L_028891;
L_028891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8891u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028891 BNE -> $02889D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02889D; }
    goto L_028893;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028891 BNE -> $02889D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02889D; }
    goto L_028893;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8891u,0x028891u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8893u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u, 5u, 3u, cpu.address("abs", 0x186Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028893 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x186Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028896;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u, 4u, 3u, cpu.address("abs", 0x186Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028893 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x186Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028896;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8893u,0x028893u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8896u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028896 BNE -> $02889D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02889D; }
    goto L_028898;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028896 BNE -> $02889D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02889D; }
    goto L_028898;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8896u,0x028896u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8898u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028898 LDA
    cpu.setA(0x8DFFu, 16);
    goto L_02889B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028898 LDA
    cpu.setA(0xFFu, 8);
    goto L_02889A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8898u,0x028898u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02889A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Au, 4u, 3u, cpu.address("abs", 0x186Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02889A STA
    hw.write(cpu.address("abs", 0x186Bu), cpu.a, cpu.m8?8:16);
    goto L_02889D;
L_02889B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02889B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02889Bu);return;} hw.unresolvedReturn(0x02889Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_02889D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Du))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du, 6u, 3u, cpu.address("abs", 0x8A66u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02889D JSR -> $028A66 stack real
    { cpu.push16Value(hw,0x889Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88A0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8A66u), 0x02889Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0288A0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du, 6u, 3u, cpu.address("abs", 0x8A66u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02889D JSR -> $028A66 stack real
    { cpu.push16Value(hw,0x889Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88A0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8A66u), 0x02889Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0288A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x889Du,0x02889Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A0u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0288A0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x0288A0u);return;} hw.unresolvedReturn(0x0288A0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0288A0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x0288A0u);return;} hw.unresolvedReturn(0x0288A0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88A0u,0x0288A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DCu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288DC LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0288DE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DCu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288DC LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0288DE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88DCu,0x0288DCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DEu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288DE CPY
    cpu.compareY(0xD00Bu);
    goto L_0288E1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DEu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288DE CPY
    cpu.compareY(0xD00Bu);
    goto L_0288E1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88DEu,0x0288DEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E1u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0288E1 PHP
    cpu.push("PHP", hw);
    goto L_0288E2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E1u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0288E1 PHP
    cpu.push("PHP", hw);
    goto L_0288E2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88E1u,0x0288E1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288E2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0288E4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288E2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0288E4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88E2u,0x0288E2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288E4 AND
    cpu.logicAnd(0xC930u);
    goto L_0288E7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288E4 AND
    cpu.logicAnd(0x30u);
    goto L_0288E6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88E4u,0x0288E4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288E6 CMP
    cpu.compareA(0x20u);
    goto L_0288E8;
L_0288E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E7u, 6u, 3u, cpu.address("abs", 0x1BF0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0288E7 JSR -> $021BF0 stack real
    { cpu.push16Value(hw,0x88E9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88EAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x1BF0u), 0x0288E7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0288EA;
L_0288E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288E8 BEQ -> $028905
    if (cpu.z) { hw.addCpuInternalCycles(2u); goto L_028905; }
    goto L_0288EA;
L_0288EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288EA CPY
    cpu.compareY(0xF010u);
    goto L_0288ED;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288EA CPY
    cpu.compareY(0xF010u);
    goto L_0288ED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88EAu,0x0288EAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EDu,cpu,0x0Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EDu, 6u, 4u, 0xD008C0u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288ED ORA
    cpu.logicOr(hw.readW(0xD008C0u, cpu.m8?8:16));
    goto L_0288F1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EDu,cpu,0x0Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EDu, 5u, 4u, 0xD008C0u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288ED ORA
    cpu.logicOr(hw.readW(0xD008C0u, cpu.m8?8:16));
    goto L_0288F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88EDu,0x0288EDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F1u,cpu,0x07u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xADu) & 0xFFFFu), 3u, 0u);
    // $0288F1 ORA
    cpu.logicOr(hw.readW(cpu.addressDpLong(hw, 0xADu), cpu.m8?8:16));
    goto L_0288F3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F1u,cpu,0x07u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F1u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xADu) & 0xFFFFu), 3u, 0u);
    // $0288F1 ORA
    cpu.logicOr(hw.readW(cpu.addressDpLong(hw, 0xADu), cpu.m8?8:16));
    goto L_0288F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88F1u,0x0288F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u,cpu,0x92u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x16u) & 0xFFFFu), 2u, 0u);
    // $0288F3 STA
    hw.write(cpu.addressDpIndirect(hw, 0x16u), cpu.a, cpu.m8?8:16);
    goto L_0288F5;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u,cpu,0x92u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x16u) & 0xFFFFu), 2u, 0u);
    // $0288F3 STA
    hw.write(cpu.addressDpIndirect(hw, 0x16u), cpu.a, cpu.m8?8:16);
    goto L_0288F5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88F3u,0x0288F3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288F5 BEQ -> $028905
    if (cpu.z) { hw.addCpuInternalCycles(2u); goto L_028905; }
    goto L_0288F7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288F5 BEQ -> $028905
    if (cpu.z) { hw.addCpuInternalCycles(2u); goto L_028905; }
    goto L_0288F7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88F5u,0x0288F5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288F7 BNE -> $0288FD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0288FD; }
    goto L_0288F9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288F7 BNE -> $0288FD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0288FD; }
    goto L_0288F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88F7u,0x0288F7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288F9 CPY
    cpu.compareY(0xD00Cu);
    goto L_0288FC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0288F9 CPY
    cpu.compareY(0xD00Cu);
    goto L_0288FC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88F9u,0x0288F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FCu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0288FC PHP
    cpu.push("PHP", hw);
    goto L_0288FD;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FCu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0288FC PHP
    cpu.push("PHP", hw);
    goto L_0288FD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88FCu,0x0288FCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0288FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FDu))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu, 8u, 4u, 0x02A9E4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0288FD JSL -> $02A9E4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8900u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8901u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02A9E4u, 0x0288FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_028901;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu, 8u, 4u, 0x02A9E4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0288FD JSL -> $02A9E4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8900u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8901u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02A9E4u, 0x0288FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_028901;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88FDu,0x0288FDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8901u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8901u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8901u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028901 TYX
    cpu.transfer("TYX");
    goto L_028902;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8901u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8901u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028901 TYX
    cpu.transfer("TYX");
    goto L_028902;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8901u,0x028901u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8902u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8902u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8902u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028902 BPL -> $028922
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_028922; }
    goto L_028904;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8902u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8902u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028902 BPL -> $028922
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_028922; }
    goto L_028904;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8902u,0x028902u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8904u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $028904 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x028904u);return;} hw.unresolvedReturn(0x028904u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $028904 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x028904u);return;} hw.unresolvedReturn(0x028904u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8904u,0x028904u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028905:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8905u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8905u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8905u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028905 LDX
    cpu.setX(0xBD0Bu, 16);
    goto L_028908;
L_028908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8908u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8908u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028908 INY
    cpu.inc('Y');
    goto L_028909;
L_028909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8909u,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8909u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028909 TRB
    cpu.trb(hw, cpu.address("dp", 0xF0u), cpu.m8?8:16);
    goto L_02890B;
L_02890B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Bu,cpu,0x16u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xCAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02890B ASL
    cpu.aslMem(hw, cpu.address("dpx", 0xCAu), cpu.m8?8:16);
    goto L_02890D;
L_02890D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02890D CPX
    cpu.compareX(0xD0FFu);
    goto L_028910;
L_028910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8910u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8910u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xCEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028910 INC
    cpu.incMem(hw, cpu.address("dpx", 0xCEu), cpu.m8?8:16);
    goto L_028912;
L_028912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8912u,cpu,0x61u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8912u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x18u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $028912 ADC
    cpu.adc(hw.readW(cpu.addressDpIndirectX(hw, 0x18u), cpu.m8?8:16));
    goto L_028914;
L_028914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8914u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8914u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8914u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028914 BPL -> $02891B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02891B; }
    goto L_028916;
L_028916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8916u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8916u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8916u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028916 LDA
    cpu.setA(0x1u, 8);
    goto L_028918;
L_028918:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8918u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8918u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8918u, 4u, 3u, cpu.address("abs", 0x1861u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028918 STA
    hw.write(cpu.address("abs", 0x1861u), cpu.a, cpu.m8?8:16);
    goto L_02891B;
L_02891B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x891Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x891Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x891Bu, 4u, 3u, cpu.address("abs", 0x1861u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02891B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1861u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02891E;
L_02891E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x891Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x891Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x891Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02891E CLC
    cpu.setFlag('C', false);
    goto L_02891F;
L_02891F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x891Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x891Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x891Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02891F ADC
    cpu.adc(0xAu);
    goto L_028921;
L_028921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8921u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8921u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028921 TAX
    cpu.transfer("TAX");
    goto L_028922;
L_028922:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8922u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8922u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8922u, 5u, 3u, cpu.address("abs", 0x185Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028922 STX
    hw.write(cpu.address("abs", 0x185Eu), cpu.x, cpu.x8?8:16);
    goto L_028925;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8922u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8922u, 5u, 3u, cpu.address("abs", 0x185Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028922 STX
    hw.write(cpu.address("abs", 0x185Eu), cpu.x, cpu.x8?8:16);
    goto L_028925;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8922u,0x028922u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028925:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8925u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8925u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8925u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028925 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_028927;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8925u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8925u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028925 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_028927;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8925u,0x028925u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028927:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8927u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8927u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8927u, 5u + 1u, 3u, cpu.address("absy", 0x88C5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028927 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88C5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02892A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8927u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8927u, 4u + 1u, 3u, cpu.address("absy", 0x88C5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028927 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88C5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02892A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8927u,0x028927u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02892A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x892Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x892Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x892Au, 6u, 3u, cpu.address("absx", 0x14C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02892A STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_02892D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x892Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x892Au, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02892A STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_02892D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x892Au,0x02892Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02892D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x892Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x892Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x892Du, 5u, 3u, cpu.address("abs", 0x18E2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02892D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18E2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028930;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x892Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x892Du, 4u, 3u, cpu.address("abs", 0x18E2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02892D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18E2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028930;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x892Du,0x02892Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028930:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8930u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8930u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8930u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028930 BEQ -> $028937
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x028937u,0x028930u); return; }
    goto L_028932;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8930u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8930u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028930 BEQ -> $028937
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x028937u,0x028930u); return; }
    goto L_028932;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8930u,0x028930u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028932:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8932u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8932u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8932u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028932 TYA
    cpu.transfer("TYA");
    goto L_028933;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8932u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8932u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028932 TYA
    cpu.transfer("TYA");
    goto L_028933;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8932u,0x028932u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028933:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8933u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8933u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8933u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028933 CLC
    cpu.setFlag('C', false);
    goto L_028934;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8933u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8933u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028933 CLC
    cpu.setFlag('C', false);
    goto L_028934;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8933u,0x028933u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028934:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8934u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8934u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8934u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028934 ADC
    cpu.adc(0xA811u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8937u,0x028934u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8934u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8934u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028934 ADC
    cpu.adc(0x11u);
    goto L_028936;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8934u,0x028934u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028936:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8936u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8936u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8936u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028936 TAY
    cpu.transfer("TAY");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8937u,0x028936u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8936u,0x028936u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_02AD34_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02AD34u: goto L_02AD34;
    case 0x02AD36u: goto L_02AD36;
    case 0x02AD39u: goto L_02AD39;
    case 0x02AD3Bu: goto L_02AD3B;
    case 0x02AD3Cu: goto L_02AD3C;
    case 0x02AD3Eu: goto L_02AD3E;
    case 0x02AD41u: goto L_02AD41;
    case 0x02AD43u: goto L_02AD43;
    case 0x02AD45u: goto L_02AD45;
    case 0x02AD48u: goto L_02AD48;
    case 0x02AD4Bu: goto L_02AD4B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02AD34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD34u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD34u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD34 LDY
    cpu.setY(0x5u, 8);
    goto L_02AD36;
L_02AD36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD36u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD36u, 4u + ((((0x16E1u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x16E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD36 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x16E1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02AD39;
L_02AD39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD39u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD39 BEQ -> $02AD4B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02AD4B; }
    goto L_02AD3B;
L_02AD3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD3B DEY
    cpu.decReg('Y');
    goto L_02AD3C;
L_02AD3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD3C BPL -> $02AD36
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02AD36; }
    goto L_02AD3E;
L_02AD3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Eu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Eu, 6u, 3u, cpu.address("abs", 0x18F7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD3E DEC
    cpu.decMem(hw, cpu.address("abs", 0x18F7u), cpu.m8?8:16);
    goto L_02AD41;
L_02AD41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD41u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD41 BPL -> $02AD48
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02AD48; }
    goto L_02AD43;
L_02AD43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD43 LDA
    cpu.setA(0x5u, 8);
    goto L_02AD45;
L_02AD45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD45u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD45u, 4u, 3u, cpu.address("abs", 0x18F7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD45 STA
    hw.write(cpu.address("abs", 0x18F7u), cpu.a, cpu.m8?8:16);
    goto L_02AD48;
L_02AD48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD48u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD48u, 4u, 3u, cpu.address("abs", 0x18F7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD48 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x18F7u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02AD4B;
L_02AD4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02AD4B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02AD4Bu);return;} hw.unresolvedReturn(0x02AD4Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_04F853_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04F828u: goto L_04F828;
    case 0x04F853u: goto L_04F853;
    case 0x04F856u: goto L_04F856;
    case 0x04F858u: goto L_04F858;
    case 0x04F85Bu: goto L_04F85B;
    case 0x04F85Fu: goto L_04F85F;
    case 0x04F860u: goto L_04F860;
    case 0x04F861u: goto L_04F861;
    case 0x04F864u: goto L_04F864;
    case 0x04F867u: goto L_04F867;
    case 0x04F869u: goto L_04F869;
    case 0x04F86Bu: goto L_04F86B;
    case 0x04F86Cu: goto L_04F86C;
    case 0x04F86Du: goto L_04F86D;
    case 0x04F86Fu: goto L_04F86F;
    case 0x04F871u: goto L_04F871;
    case 0x04F872u: goto L_04F872;
    case 0x04F873u: goto L_04F873;
    case 0x04F875u: goto L_04F875;
    case 0x04F8B7u: goto L_04F8B7;
    case 0x04F8B9u: goto L_04F8B9;
    case 0x04F8BBu: goto L_04F8BB;
    case 0x04F8BDu: goto L_04F8BD;
    case 0x04F8BFu: goto L_04F8BF;
    case 0x04F8C1u: goto L_04F8C1;
    case 0x04F8C3u: goto L_04F8C3;
    case 0x04F8C5u: goto L_04F8C5;
    case 0x04F8C7u: goto L_04F8C7;
    case 0x04F8CBu: goto L_04F8CB;
    case 0x04F8CDu: goto L_04F8CD;
    case 0x04F8CFu: goto L_04F8CF;
    case 0x04F8D0u: goto L_04F8D0;
    case 0x04F8D3u: goto L_04F8D3;
    case 0x04F8D6u: goto L_04F8D6;
    case 0x04F8D8u: goto L_04F8D8;
    case 0x04F8DAu: goto L_04F8DA;
    case 0x04F8DCu: goto L_04F8DC;
    case 0x04F8DEu: goto L_04F8DE;
    case 0x04F8E1u: goto L_04F8E1;
    case 0x04F8E3u: goto L_04F8E3;
    case 0x04F8E5u: goto L_04F8E5;
    case 0x04F8E7u: goto L_04F8E7;
    case 0x04F8E8u: goto L_04F8E8;
    case 0x04F8EAu: goto L_04F8EA;
    case 0x04F8ECu: goto L_04F8EC;
    case 0x04F8EDu: goto L_04F8ED;
    case 0x04F8F0u: goto L_04F8F0;
    case 0x04F8F2u: goto L_04F8F2;
    case 0x04F8F4u: goto L_04F8F4;
    case 0x04F8F6u: goto L_04F8F6;
    case 0x04F8F8u: goto L_04F8F8;
    case 0x04F8F9u: goto L_04F8F9;
    case 0x04F8FCu: goto L_04F8FC;
    case 0x04F8FEu: goto L_04F8FE;
    case 0x04F900u: goto L_04F900;
    case 0x04F902u: goto L_04F902;
    case 0x04F904u: goto L_04F904;
    case 0x04F906u: goto L_04F906;
    case 0x04F907u: goto L_04F907;
    case 0x04F909u: goto L_04F909;
    case 0x04F90Cu: goto L_04F90C;
    case 0x04F90Eu: goto L_04F90E;
    case 0x04F90Fu: goto L_04F90F;
    case 0x04F910u: goto L_04F910;
    case 0x04F912u: goto L_04F912;
    case 0x04F915u: goto L_04F915;
    case 0x04F918u: goto L_04F918;
    case 0x04F91Au: goto L_04F91A;
    case 0x04F91Bu: goto L_04F91B;
    case 0x04F91Du: goto L_04F91D;
    case 0x04F920u: goto L_04F920;
    case 0x04F923u: goto L_04F923;
    case 0x04F925u: goto L_04F925;
    case 0x04F928u: goto L_04F928;
    case 0x04F92Bu: goto L_04F92B;
    case 0x04F92Du: goto L_04F92D;
    case 0x04F92Eu: goto L_04F92E;
    case 0x04F931u: goto L_04F931;
    case 0x04F932u: goto L_04F932;
    case 0x04F935u: goto L_04F935;
    case 0x04F938u: goto L_04F938;
    case 0x04F93Bu: goto L_04F93B;
    case 0x04F93Du: goto L_04F93D;
    case 0x04F940u: goto L_04F940;
    case 0x04F942u: goto L_04F942;
    case 0x04F945u: goto L_04F945;
    case 0x04F948u: goto L_04F948;
    case 0x04F94Bu: goto L_04F94B;
    case 0x04F94Eu: goto L_04F94E;
    case 0x04F94Fu: goto L_04F94F;
    case 0x04F951u: goto L_04F951;
    case 0x04F953u: goto L_04F953;
    case 0x04F955u: goto L_04F955;
    case 0x04F958u: goto L_04F958;
    case 0x04F95Au: goto L_04F95A;
    case 0x04F95Cu: goto L_04F95C;
    case 0x04F95Du: goto L_04F95D;
    case 0x04F95Eu: goto L_04F95E;
    case 0x04F960u: goto L_04F960;
    case 0x04F962u: goto L_04F962;
    case 0x04F963u: goto L_04F963;
    case 0x04F965u: goto L_04F965;
    case 0x04F967u: goto L_04F967;
    case 0x04F96Au: goto L_04F96A;
    case 0x04F96Cu: goto L_04F96C;
    case 0x04F96Du: goto L_04F96D;
    case 0x04F96Eu: goto L_04F96E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04F828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF828u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF828u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF828u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F828 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04F828u);return;} hw.unresolvedReturn(0x04F828u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_04F853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF853u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF853u, 6u, 3u, cpu.address("abs", 0xF87Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F853 JSR -> $04F87C stack real
    { cpu.push16Value(hw,0xF855u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF856u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF87Cu), 0x04F853u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F856;
L_04F856:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF856u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF856u,0x04F856u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF856u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF856u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F856 BNE -> $04F828
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F828; }
    goto L_04F858;
L_04F858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF858u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF858u, 4u + ((((0x0DE5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F858 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F85B;
L_04F85B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF85Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Bu, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $04F85B JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF85Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF85Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x04F85Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F85F;
L_04F85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF85Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF85Fu,0x04F85Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Fu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F85F PLP
    cpu.pop("PLP", hw);
    goto L_04F860;
L_04F860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF860u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF860u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF860u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F860 SED
    cpu.setFlag('D', true);
    goto L_04F861;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF860u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF860u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F860 SED
    cpu.setFlag('D', true);
    goto L_04F861;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF860u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF860u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F860 SED
    cpu.setFlag('D', true);
    goto L_04F861;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF860u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF860u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F860 SED
    cpu.setFlag('D', true);
    goto L_04F861;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF860u,0x04F860u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF861u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF861u,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF861u, 5u, 3u, cpu.address("abs", 0xB8F8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F861 CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0xB8F8u), cpu.x8?8:16));
    goto L_04F864;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF861u,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF861u, 4u, 3u, cpu.address("abs", 0xB8F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F861 CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0xB8F8u), cpu.x8?8:16));
    goto L_04F864;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF861u,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF861u, 5u, 3u, cpu.address("abs", 0xB8F8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F861 CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0xB8F8u), cpu.x8?8:16));
    goto L_04F864;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF861u,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF861u, 4u, 3u, cpu.address("abs", 0xB8F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F861 CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0xB8F8u), cpu.x8?8:16));
    goto L_04F864;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF861u,0x04F861u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF864u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF864u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF864u, 5u + 1u, 3u, cpu.address("absy", 0xFA3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F864 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0xFA3Eu), cpu.m8?8:16));
    goto L_04F867;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF864u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF864u, 5u + ((((0xFA3Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xFA3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F864 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0xFA3Eu), cpu.m8?8:16));
    goto L_04F867;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF864u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF864u, 4u + 1u, 3u, cpu.address("absy", 0xFA3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F864 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0xFA3Eu), cpu.m8?8:16));
    goto L_04F867;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF864u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF864u, 4u + ((((0xFA3Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xFA3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F864 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0xFA3Eu), cpu.m8?8:16));
    goto L_04F867;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF864u,0x04F864u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF867u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF867u,cpu,0xF1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF867u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFAu) & 0xFFFFu), 2u, 0u);
    // $04F867 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectY(hw, 0xFAu), cpu.m8?8:16));
    goto L_04F869;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF867u,cpu,0xF1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF867u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFAu) & 0xFFFFu), 2u, 0u);
    // $04F867 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectY(hw, 0xFAu), cpu.m8?8:16));
    goto L_04F869;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF867u,cpu,0xF1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF867u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFAu) & 0xFFFFu), 2u, 0u);
    // $04F867 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectY(hw, 0xFAu), cpu.m8?8:16));
    goto L_04F869;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF867u,cpu,0xF1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF867u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFAu) & 0xFFFFu), 2u, 0u);
    // $04F867 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectY(hw, 0xFAu), cpu.m8?8:16));
    goto L_04F869;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF867u,0x04F867u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF869u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF869u,cpu,0x37u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF869u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFBu) & 0xFFFFu), 3u, 0u);
    // $04F869 AND
    cpu.logicAnd(hw.readW(cpu.addressDpLongY(hw, 0xFBu), cpu.m8?8:16));
    goto L_04F86B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF869u,cpu,0x37u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF869u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFBu) & 0xFFFFu), 3u, 0u);
    // $04F869 AND
    cpu.logicAnd(hw.readW(cpu.addressDpLongY(hw, 0xFBu), cpu.m8?8:16));
    goto L_04F86B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF869u,cpu,0x37u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF869u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFBu) & 0xFFFFu), 3u, 0u);
    // $04F869 AND
    cpu.logicAnd(hw.readW(cpu.addressDpLongY(hw, 0xFBu), cpu.m8?8:16));
    goto L_04F86B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF869u,cpu,0x37u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF869u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFBu) & 0xFFFFu), 3u, 0u);
    // $04F869 AND
    cpu.logicAnd(hw.readW(cpu.addressDpLongY(hw, 0xFBu), cpu.m8?8:16));
    goto L_04F86B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF869u,0x04F869u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F86B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF86Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F86B TYA
    cpu.transfer("TYA");
    goto L_04F86C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F86B TYA
    cpu.transfer("TYA");
    goto L_04F86C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F86B TYA
    cpu.transfer("TYA");
    goto L_04F86C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F86B TYA
    cpu.transfer("TYA");
    goto L_04F86C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF86Bu,0x04F86Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F86C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF86Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Cu,cpu,0xFBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F86C XCE
    cpu.xce();
    goto L_04F86D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Cu,cpu,0xFBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F86C XCE
    cpu.xce();
    goto L_04F86D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Cu,cpu,0xFBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F86C XCE
    cpu.xce();
    goto L_04F86D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Cu,cpu,0xFBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F86C XCE
    cpu.xce();
    goto L_04F86D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF86Cu,0x04F86Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF86Du))return;
  // 5 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Du,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F86D LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xFCu), cpu.m8?8:16);
    goto L_04F86F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Du,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F86D LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xFCu), cpu.m8?8:16);
    goto L_04F86F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Du,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F86D LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xFCu), cpu.m8?8:16);
    goto L_04F86F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Du,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F86D LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xFCu), cpu.m8?8:16);
    goto L_04F86F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Du,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F86D LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xFCu), cpu.m8?8:16);
    goto L_04F86F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF86Du,0x04F86Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F86F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF86Fu))return;
  // 5 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Fu,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFCu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $04F86F SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0xFCu), cpu.m8?8:16));
    goto L_04F871;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Fu,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFCu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $04F86F SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0xFCu), cpu.m8?8:16));
    goto L_04F871;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Fu,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFCu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $04F86F SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0xFCu), cpu.m8?8:16));
    goto L_04F871;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Fu,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFCu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $04F86F SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0xFCu), cpu.m8?8:16));
    goto L_04F871;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Fu,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFCu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $04F86F SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0xFCu), cpu.m8?8:16));
    goto L_04F871;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF86Fu,0x04F86Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF871u))return;
  // 5 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF871u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF871u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F871 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0xFDu), cpu.m8?8:16), false);
    goto L_04F873;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF871u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF871u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F871 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0xFDu), cpu.m8?8:16), false);
    goto L_04F873;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF871u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF871u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F871 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0xFDu), cpu.m8?8:16), false);
    goto L_04F873;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF871u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF871u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F871 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0xFDu), cpu.m8?8:16), false);
    goto L_04F873;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF871u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF871u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F871 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0xFDu), cpu.m8?8:16), false);
    goto L_04F873;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF871u,0x04F871u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF872u))return;
  // 5 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF872u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF872u, 5u + 1u, 3u, cpu.address("absx", 0xFD70u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F872 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0xFD70u), cpu.m8?8:16));
    goto L_04F875;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF872u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF872u, 5u + ((((0xFD70u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xFD70u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F872 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0xFD70u), cpu.m8?8:16));
    goto L_04F875;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF872u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF872u, 4u + 1u, 3u, cpu.address("absx", 0xFD70u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F872 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0xFD70u), cpu.m8?8:16));
    goto L_04F875;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF872u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF872u, 4u + ((((0xFD70u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xFD70u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F872 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0xFD70u), cpu.m8?8:16));
    goto L_04F875;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF872u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF872u, 4u + ((((0xFD70u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xFD70u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F872 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0xFD70u), cpu.m8?8:16));
    goto L_04F875;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF872u,0x04F872u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF873u))return;
  // 5 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F873 BVS -> $04F872
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_04F872; }
    goto L_04F875;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F873 BVS -> $04F872
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_04F872; }
    goto L_04F875;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F873 BVS -> $04F872
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_04F872; }
    goto L_04F875;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F873 BVS -> $04F872
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_04F872; }
    goto L_04F875;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F873 BVS -> $04F872
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_04F872; }
    goto L_04F875;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF873u,0x04F873u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF875u))return;
  // 5 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F875 BRA -> $04F8B7
    goto L_04F8B7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F875 BRA -> $04F8B7
    goto L_04F8B7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F875 BRA -> $04F8B7
    goto L_04F8B7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F875 BRA -> $04F8B7
    goto L_04F8B7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F875 BRA -> $04F8B7
    goto L_04F8B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF875u,0x04F875u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F8B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B7u))return;
  // 5 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $04F8B7 BRK
    hw.partial(0x04F8B7u, "BRK"); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $04F8B7 BRK
    hw.partial(0x04F8B7u, "BRK"); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $04F8B7 BRK
    hw.partial(0x04F8B7u, "BRK"); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $04F8B7 BRK
    hw.partial(0x04F8B7u, "BRK"); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xF8B9u,true);
    hw.requestDispatch(0x0082C3u,0x04F8B7u);return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8B7u,0x04F8B7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F8B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B9u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B9u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xF8BBu,true);
    hw.requestDispatch(0x0082C3u,0x04F8B9u);return;
L_04F8BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BBu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BBu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xF8BDu,true);
    hw.requestDispatch(0x0082C3u,0x04F8BBu);return;
L_04F8BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BDu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BDu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xF8BFu,true);
    hw.requestDispatch(0x0082C3u,0x04F8BDu);return;
L_04F8BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BFu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BFu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xF8C1u,true);
    hw.requestDispatch(0x0082C3u,0x04F8BFu);return;
L_04F8C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C1u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C1u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xF8C3u,true);
    hw.requestDispatch(0x0082C3u,0x04F8C1u);return;
L_04F8C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C3u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C3u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xF8C5u,true);
    hw.requestDispatch(0x0082C3u,0x04F8C3u);return;
L_04F8C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C5u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C5u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xF8C7u,true);
    hw.requestDispatch(0x0082C3u,0x04F8C5u);return;
L_04F8C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C7u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C7u, 5u, 4u, ((0x10F010u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8C7 SBC
    cpu.sbc(hw.readW(((0x10F010u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_04F8CB;
L_04F8CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8CB BEQ -> $04F8ED
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F8ED; }
    goto L_04F8CD;
L_04F8CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8CD BCC -> $04F8CD
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F8CD; }
    goto L_04F8CF;
L_04F8CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8CF CLC
    cpu.setFlag('C', false);
    goto L_04F8D0;
L_04F8D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D0u, 6u, 3u, cpu.address("abs", 0xFE00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F8D0 JSR -> $04FE00 stack real
    { cpu.push16Value(hw,0xF8D2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF8D3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFE00u), 0x04F8D0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F8D3;
L_04F8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D3u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8D3u,0x04F8D3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D3u, 6u, 3u, cpu.address("abs", 0xFE62u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F8D3 JSR -> $04FE62 stack real
    { cpu.push16Value(hw,0xF8D5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF8D6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFE62u), 0x04F8D3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F8D6;
L_04F8D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D6u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8D6u,0x04F8D6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8D6 REP
    cpu.rep(0x20u);
    goto L_04F8D8;
L_04F8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8D8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F8DA;
L_04F8DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8DA STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_04F8DC;
L_04F8DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8DC SEP
    cpu.sep(0x20u);
    goto L_04F8DE;
L_04F8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DEu, 6u, 3u, cpu.address("abs", 0xFE5Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F8DE JSR -> $04FE5B stack real
    { cpu.push16Value(hw,0xF8E0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF8E1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFE5Bu), 0x04F8DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F8E1;
L_04F8E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E1u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8E1u,0x04F8E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8E1 LDX
    cpu.setX(0x6u, 8);
    goto L_04F8E3;
L_04F8E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8E3 AND
    cpu.logicAnd(0x10u);
    goto L_04F8E5;
L_04F8E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8E5 BEQ -> $04F8E8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F8E8; }
    goto L_04F8E7;
L_04F8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8E7 INX
    cpu.inc('X');
    goto L_04F8E8;
L_04F8E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8E8 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_04F8EA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8E8 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_04F8EA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8E8u,0x04F8E8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F8EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8EAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8EA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F8EC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8EA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F8EC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8EAu,0x04F8EAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8ECu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8ECu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8EC CLC
    cpu.setFlag('C', false);
    goto L_04F8ED;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8ECu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8EC CLC
    cpu.setFlag('C', false);
    goto L_04F8ED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8ECu,0x04F8ECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8EDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EDu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EDu, 4u + ((((0xF8A6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF8A6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8ED ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xF8A6u), cpu.m8?8:16));
    goto L_04F8F0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EDu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EDu, 4u + ((((0xF8A6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF8A6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8ED ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xF8A6u), cpu.m8?8:16));
    goto L_04F8F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8EDu,0x04F8EDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F8F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8F0 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04F8F2;
L_04F8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F2u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8F2 BCC -> $04F8F6
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F8F6; }
    goto L_04F8F4;
L_04F8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F4u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8F4 INC
    cpu.incMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_04F8F6;
L_04F8F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8F6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F8F8;
L_04F8F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8F8 CLC
    cpu.setFlag('C', false);
    goto L_04F8F9;
L_04F8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F9u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F9u, 4u + ((((0xF8AEu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF8AEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8F9 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xF8AEu), cpu.m8?8:16));
    goto L_04F8FC;
L_04F8FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8FCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8FC STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04F8FE;
L_04F8FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8FEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8FEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8FE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F900;
L_04F900:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF900u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF900u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF900u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F900 ADC
    cpu.adc(0x0u);
    goto L_04F902;
L_04F902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF902u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF902u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F902 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_04F904;
L_04F904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF904u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF904u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F904 LDA
    cpu.setA(0x32u, 8);
    goto L_04F906;
L_04F906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF906u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF906u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F906 XBA
    cpu.xba();
    goto L_04F907;
L_04F907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF907u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF907u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF907u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F907 LDA
    cpu.setA(0x28u, 8);
    goto L_04F909;
L_04F909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF909u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF909u, 6u, 3u, cpu.address("abs", 0xFB7Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F909 JSR -> $04FB7B stack real
    { cpu.push16Value(hw,0xF90Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF90Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFB7Bu), 0x04F909u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F90C;
L_04F90C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF90Cu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF90Cu,0x04F90Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF90Cu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF90Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F90C LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F90E;
L_04F90E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF90Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF90Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF90Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F90E DEX
    cpu.decReg('X');
    goto L_04F90F;
L_04F90F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF90Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF90Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF90Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F90F DEX
    cpu.decReg('X');
    goto L_04F910;
L_04F910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF910u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF910u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F910 BPL -> $04F8E8
    if (!cpu.n) { hw.addCpuInternalCycles(2u); goto L_04F8E8; }
    goto L_04F912;
L_04F912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF912u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF912u, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F912 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDDEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F915;
L_04F915:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF915u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF915u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF915u, 6u, 3u, cpu.address("abs", 0xFE62u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F915 JSR -> $04FE62 stack real
    { cpu.push16Value(hw,0xF917u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF918u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFE62u), 0x04F915u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F918;
L_04F918:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF918u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF918u,0x04F918u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF918u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF918u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F918 LDA
    cpu.setA(0x32u, 8);
    goto L_04F91A;
L_04F91A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF91Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF91Au,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF91Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F91A XBA
    cpu.xba();
    goto L_04F91B;
L_04F91B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF91Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF91Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF91Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F91B LDA
    cpu.setA(0x26u, 8);
    goto L_04F91D;
L_04F91D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF91Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF91Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF91Du, 6u, 3u, cpu.address("abs", 0xFB7Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F91D JSR -> $04FB7A stack real
    { cpu.push16Value(hw,0xF91Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF920u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFB7Au), 0x04F91Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F920;
L_04F920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF920u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF920u,0x04F920u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF920u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF920u, 4u + ((((0x0E15u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F920 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F923;
L_04F923:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF923u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF923u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF923u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F923 BEQ -> $04F928
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F928; }
    goto L_04F925;
L_04F925:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF925u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF925u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF925u, 3u, 3u, cpu.address("abs", 0xFF2Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F925 JMP -> $04FF2E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xFF2Eu),0x04F925u); return;
L_04F928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF928u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF928u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF928u, 4u + ((((0x0E05u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F928 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE05u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F92B;
L_04F92B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF92Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF92Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF92Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F92B AND
    cpu.logicAnd(0x1u);
    goto L_04F92D;
L_04F92D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF92Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF92Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF92Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F92D TAY
    cpu.transfer("TAY");
    goto L_04F92E;
L_04F92E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF92Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF92Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF92Eu, 4u + ((((0x0EB5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0EB5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F92E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xEB5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F931;
L_04F931:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF931u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF931u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF931u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F931 CLC
    cpu.setFlag('C', false);
    goto L_04F932;
L_04F932:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF932u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF932u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF932u, 4u + ((((0xF8C6u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF8C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F932 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xF8C6u), cpu.m8?8:16));
    goto L_04F935;
L_04F935:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF935u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF935u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF935u, 5u, 3u, cpu.address("absx", 0x0EB5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F935 STA
    hw.write(cpu.address("absx", 0xEB5u), cpu.a, cpu.m8?8:16);
    goto L_04F938;
L_04F938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF938u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF938u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF938u, 4u + ((((0xF8CAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF8CAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F938 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xF8CAu), cpu.m8?8:16));
    goto L_04F93B;
L_04F93B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF93Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF93Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF93Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F93B BNE -> $04F945
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F945; }
    goto L_04F93D;
L_04F93D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF93Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF93Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF93Du, 4u + ((((0x0E05u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F93D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE05u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F940;
L_04F940:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF940u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF940u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF940u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F940 EOR
    cpu.logicXor(0x1u);
    goto L_04F942;
L_04F942:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF942u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF942u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF942u, 5u, 3u, cpu.address("absx", 0x0E05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F942 STA
    hw.write(cpu.address("absx", 0xE05u), cpu.a, cpu.m8?8:16);
    goto L_04F945;
L_04F945:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF945u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF945u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF945u, 6u, 3u, cpu.address("abs", 0xFEEFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F945 JSR -> $04FEEF stack real
    { cpu.push16Value(hw,0xF947u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF948u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFEEFu), 0x04F945u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F948;
L_04F948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF948u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF948u,0x04F948u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF948u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF948u, 4u + ((((0x0DF5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F948 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xDF5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F94B;
L_04F94B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF94Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF94Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF94Bu, 4u + ((((0x0E04u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F94B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE04u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F94E;
L_04F94E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF94Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF94Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF94Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F94E ASL
    cpu.aslA();
    goto L_04F94F;
L_04F94F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF94Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF94Fu,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF94Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F94F EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_04F951;
L_04F951:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF951u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF951u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF951u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F951 BPL -> $04F95D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F95D; }
    goto L_04F953;
L_04F953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF953u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF953u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF953u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F953 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F955;
L_04F955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF955u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF955u, 4u + ((((0xF8B6u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF8B6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F955 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xF8B6u), cpu.m8?8:16));
    goto L_04F958;
L_04F958:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF958u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF958u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF958u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F958 LDA
    cpu.setA(0x40u, 8);
    goto L_04F95A;
L_04F95A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF95Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF95Au,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF95Au, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xF95Cu,true);
    hw.requestDispatch(0x0082C3u,0x04F95Au);return;
L_04F95C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF95Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF95Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF95Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F95C BPL -> $04F91B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F91B; }
    goto L_04F95E;
L_04F95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF95Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF95Du, 4u + ((((0x0E04u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F95D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE04u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F960;
L_04F95E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF95Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF95Eu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF95Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F95E TSB
    cpu.tsb(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_04F960;
L_04F960:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF960u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF960u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF960u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F960 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_04F962;
L_04F962:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF962u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF962u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF962u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F962 ASL
    cpu.aslA();
    goto L_04F963;
L_04F963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF963u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF963u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F963 BCC -> $04F96D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F96D; }
    goto L_04F965;
L_04F965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF965u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF965u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F965 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F967;
L_04F967:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF967u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF967u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF967u, 4u + ((((0xF8BEu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF8BEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F967 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xF8BEu), cpu.m8?8:16));
    goto L_04F96A;
L_04F96A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF96Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF96Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF96Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F96A LDA
    cpu.setA(0x80u, 8);
    goto L_04F96C;
L_04F96C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF96Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF96Cu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF96Cu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xF96Eu,true);
    hw.requestDispatch(0x0082C3u,0x04F96Cu);return;
L_04F96D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF96Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF96Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF96Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F96D SEP
    cpu.sep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF96Fu,0x04F96Du); return;
L_04F96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF96Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF96Eu, 6u, 3u, cpu.address("abs", 0x0E90u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F96E JSR -> $040E90 stack real
    { cpu.push16Value(hw,0xF970u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF971u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x0E90u), 0x04F96Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF971u,0x04F96Eu); return;
}

void sub_04FB0A_E1M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04FB0Au: goto L_04FB0A;
    case 0x04FB0Du: goto L_04FB0D;
    case 0x04FB0Eu: goto L_04FB0E;
    case 0x04FB11u: goto L_04FB11;
    case 0x04FB13u: goto L_04FB13;
    case 0x04FB15u: goto L_04FB15;
    case 0x04FB17u: goto L_04FB17;
    case 0x04FB1Au: goto L_04FB1A;
    case 0x04FB1Cu: goto L_04FB1C;
    case 0x04FB1Eu: goto L_04FB1E;
    case 0x04FB1Fu: goto L_04FB1F;
    case 0x04FB21u: goto L_04FB21;
    case 0x04FB24u: goto L_04FB24;
    case 0x04FB25u: goto L_04FB25;
    case 0x04FB26u: goto L_04FB26;
    case 0x04FB27u: goto L_04FB27;
    case 0x04FB28u: goto L_04FB28;
    case 0x04FB29u: goto L_04FB29;
    case 0x04FB2Au: goto L_04FB2A;
    case 0x04FB2Bu: goto L_04FB2B;
    case 0x04FB2Cu: goto L_04FB2C;
    case 0x04FB2Eu: goto L_04FB2E;
    case 0x04FB31u: goto L_04FB31;
    case 0x04FB32u: goto L_04FB32;
    case 0x04FB33u: goto L_04FB33;
    case 0x04FB34u: goto L_04FB34;
    case 0x04FB35u: goto L_04FB35;
    case 0x04FB36u: goto L_04FB36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04FB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Au, 5u, 3u, cpu.address("absy", 0x0242u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB0A STA
    hw.write(cpu.address("absy", 0x242u), cpu.a, cpu.m8?8:16);
    goto L_04FB0D;
L_04FB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Du,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB0D XBA
    cpu.xba();
    goto L_04FB0E;
L_04FB0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Eu, 5u, 3u, cpu.address("absy", 0x0243u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB0E STA
    hw.write(cpu.address("absy", 0x243u), cpu.a, cpu.m8?8:16);
    goto L_04FB11;
L_04FB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB11u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB13;
L_04FB13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB13u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB13 BNE -> $04FB36
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04FB36; }
    goto L_04FB15;
L_04FB15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB15u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB15 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB17;
L_04FB17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB17u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB17u, 5u, 3u, cpu.address("absy", 0x0240u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB17 STA
    hw.write(cpu.address("absy", 0x240u), cpu.a, cpu.m8?8:16);
    goto L_04FB1A;
L_04FB1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB1A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB1C;
L_04FB1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB1C BNE -> $04FB36
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04FB36; }
    goto L_04FB1E;
L_04FB1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB1E PHP
    cpu.push("PHP", hw);
    goto L_04FB1F;
L_04FB1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB21;
L_04FB21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB21u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB21u, 5u, 3u, cpu.address("absy", 0x0241u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB21 STA
    hw.write(cpu.address("absy", 0x241u), cpu.a, cpu.m8?8:16);
    goto L_04FB24;
L_04FB24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB24u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB24 TYA
    cpu.transfer("TYA");
    goto L_04FB25;
L_04FB25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB25u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB25 LSR
    cpu.lsrA();
    goto L_04FB26;
L_04FB26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB26u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB26 LSR
    cpu.lsrA();
    goto L_04FB27;
L_04FB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB27u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB27u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB27 PLP
    cpu.pop("PLP", hw);
    goto L_04FB28;
L_04FB28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB28u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFB28u,0x04FB28u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB28u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB28u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB28 PHY
    cpu.push("PHY", hw);
    goto L_04FB29;
L_04FB29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB29 TAY
    cpu.transfer("TAY");
    goto L_04FB2A;
L_04FB2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Au,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2A ROL
    cpu.rolA();
    goto L_04FB2B;
L_04FB2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2B ASL
    cpu.aslA();
    goto L_04FB2C;
L_04FB2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2C AND
    cpu.logicAnd(0x3u);
    goto L_04FB2E;
L_04FB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Eu, 5u, 3u, cpu.address("absy", 0x0430u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2E STA
    hw.write(cpu.address("absy", 0x430u), cpu.a, cpu.m8?8:16);
    goto L_04FB31;
L_04FB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB31 PLY
    cpu.pop("PLY", hw);
    goto L_04FB32;
L_04FB32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB32u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB32 DEY
    cpu.decReg('Y');
    goto L_04FB33;
L_04FB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB33u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB33 DEY
    cpu.decReg('Y');
    goto L_04FB34;
L_04FB34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB34u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB34 DEY
    cpu.decReg('Y');
    goto L_04FB35;
L_04FB35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB35u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB35 DEY
    cpu.decReg('Y');
    goto L_04FB36;
L_04FB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB36u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FB36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FB36u);return;} hw.unresolvedReturn(0x04FB36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FB36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FB36u);return;} hw.unresolvedReturn(0x04FB36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFB36u,0x04FB36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_04FB0A_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04FB0Au: goto L_04FB0A;
    case 0x04FB0Du: goto L_04FB0D;
    case 0x04FB0Eu: goto L_04FB0E;
    case 0x04FB11u: goto L_04FB11;
    case 0x04FB13u: goto L_04FB13;
    case 0x04FB15u: goto L_04FB15;
    case 0x04FB17u: goto L_04FB17;
    case 0x04FB1Au: goto L_04FB1A;
    case 0x04FB1Cu: goto L_04FB1C;
    case 0x04FB1Eu: goto L_04FB1E;
    case 0x04FB1Fu: goto L_04FB1F;
    case 0x04FB21u: goto L_04FB21;
    case 0x04FB24u: goto L_04FB24;
    case 0x04FB25u: goto L_04FB25;
    case 0x04FB26u: goto L_04FB26;
    case 0x04FB27u: goto L_04FB27;
    case 0x04FB28u: goto L_04FB28;
    case 0x04FB29u: goto L_04FB29;
    case 0x04FB2Au: goto L_04FB2A;
    case 0x04FB2Bu: goto L_04FB2B;
    case 0x04FB2Cu: goto L_04FB2C;
    case 0x04FB2Eu: goto L_04FB2E;
    case 0x04FB31u: goto L_04FB31;
    case 0x04FB32u: goto L_04FB32;
    case 0x04FB33u: goto L_04FB33;
    case 0x04FB34u: goto L_04FB34;
    case 0x04FB35u: goto L_04FB35;
    case 0x04FB36u: goto L_04FB36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04FB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Au, 5u, 3u, cpu.address("absy", 0x0242u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB0A STA
    hw.write(cpu.address("absy", 0x242u), cpu.a, cpu.m8?8:16);
    goto L_04FB0D;
L_04FB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Du,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB0D XBA
    cpu.xba();
    goto L_04FB0E;
L_04FB0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Eu, 5u, 3u, cpu.address("absy", 0x0243u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB0E STA
    hw.write(cpu.address("absy", 0x243u), cpu.a, cpu.m8?8:16);
    goto L_04FB11;
L_04FB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB11u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB13;
L_04FB13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB13u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB13 BNE -> $04FB36
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04FB36; }
    goto L_04FB15;
L_04FB15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB15u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB15 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB17;
L_04FB17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB17u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB17u, 5u, 3u, cpu.address("absy", 0x0240u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB17 STA
    hw.write(cpu.address("absy", 0x240u), cpu.a, cpu.m8?8:16);
    goto L_04FB1A;
L_04FB1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB1A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB1C;
L_04FB1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB1C BNE -> $04FB36
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04FB36; }
    goto L_04FB1E;
L_04FB1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB1E PHP
    cpu.push("PHP", hw);
    goto L_04FB1F;
L_04FB1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FB21;
L_04FB21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB21u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB21u, 5u, 3u, cpu.address("absy", 0x0241u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB21 STA
    hw.write(cpu.address("absy", 0x241u), cpu.a, cpu.m8?8:16);
    goto L_04FB24;
L_04FB24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB24u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB24 TYA
    cpu.transfer("TYA");
    goto L_04FB25;
L_04FB25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB25u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB25 LSR
    cpu.lsrA();
    goto L_04FB26;
L_04FB26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB26u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB26 LSR
    cpu.lsrA();
    goto L_04FB27;
L_04FB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB27u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB27u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB27 PLP
    cpu.pop("PLP", hw);
    goto L_04FB28;
L_04FB28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB28u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFB28u,0x04FB28u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB28u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB28u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB28 PHY
    cpu.push("PHY", hw);
    goto L_04FB29;
L_04FB29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB29 TAY
    cpu.transfer("TAY");
    goto L_04FB2A;
L_04FB2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Au,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2A ROL
    cpu.rolA();
    goto L_04FB2B;
L_04FB2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2B ASL
    cpu.aslA();
    goto L_04FB2C;
L_04FB2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2C AND
    cpu.logicAnd(0x3u);
    goto L_04FB2E;
L_04FB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Eu, 5u, 3u, cpu.address("absy", 0x0430u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB2E STA
    hw.write(cpu.address("absy", 0x430u), cpu.a, cpu.m8?8:16);
    goto L_04FB31;
L_04FB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FB31 PLY
    cpu.pop("PLY", hw);
    goto L_04FB32;
L_04FB32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB32u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB32 DEY
    cpu.decReg('Y');
    goto L_04FB33;
L_04FB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB33u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB33 DEY
    cpu.decReg('Y');
    goto L_04FB34;
L_04FB34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB34u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB34 DEY
    cpu.decReg('Y');
    goto L_04FB35;
L_04FB35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB35u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FB35 DEY
    cpu.decReg('Y');
    goto L_04FB36;
L_04FB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FB36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FB36u);return;} hw.unresolvedReturn(0x04FB36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04FE5B_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04FE5Bu: goto L_04FE5B;
    case 0x04FE5Du: goto L_04FE5D;
    case 0x04FE5Eu: goto L_04FE5E;
    case 0x04FE61u: goto L_04FE61;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04FE5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE5B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FE5D;
L_04FE5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE5D CLC
    cpu.setFlag('C', false);
    goto L_04FE5E;
L_04FE5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Eu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Eu, 4u + ((((0xF833u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF833u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE5E ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xF833u), cpu.m8?8:16));
    goto L_04FE61;
L_04FE61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE61u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE61u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FE61 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FE61u);return;} hw.unresolvedReturn(0x04FE61u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04FE7D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04FE7Du: goto L_04FE7D;
    case 0x04FE80u: goto L_04FE80;
    case 0x04FE81u: goto L_04FE81;
    case 0x04FE84u: goto L_04FE84;
    case 0x04FE86u: goto L_04FE86;
    case 0x04FE87u: goto L_04FE87;
    case 0x04FE8Au: goto L_04FE8A;
    case 0x04FE8Du: goto L_04FE8D;
    case 0x04FE8Fu: goto L_04FE8F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04FE7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE7Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE7Du, 4u + ((((0x0E65u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE7D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FE80;
L_04FE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE80u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE80u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE80 XBA
    cpu.xba();
    goto L_04FE81;
L_04FE81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE81u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE81u, 4u + ((((0x0E35u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE81 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE35u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FE84;
L_04FE84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE84u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE84u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE84 REP
    cpu.rep(0x20u);
    goto L_04FE86;
L_04FE86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE86u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE86u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE86 SEC
    cpu.setFlag('C', true);
    goto L_04FE87;
L_04FE87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE87u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE87u, 5u + ((((0x001Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x001Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE87 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1Au), cpu.m8?8:16));
    goto L_04FE8A;
L_04FE8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Au, 6u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE8A STA
    hw.write(cpu.address("absy", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04FE8D;
L_04FE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE8D SEP
    cpu.sep(0x20u);
    goto L_04FE8F;
L_04FE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FE8F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FE8Fu);return;} hw.unresolvedReturn(0x04FE8Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_058734_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x058734u: goto L_058734;
    case 0x058774u: goto L_058774;
    case 0x058775u: goto L_058775;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_058734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u, 3u, 3u, cpu.address("abs", 0x8774u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058734 JMP -> $058774
    goto L_058774;
L_058774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058774 PLP
    cpu.pop("PLP", hw);
    goto L_058775;
L_058775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8775u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058775 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058775u);return;} hw.unresolvedReturn(0x058775u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058775 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058775u);return;} hw.unresolvedReturn(0x058775u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058775 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058775u);return;} hw.unresolvedReturn(0x058775u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8775u,0x058775u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_058734_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x058734u: goto L_058734;
    case 0x058774u: goto L_058774;
    case 0x058775u: goto L_058775;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_058734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u, 3u, 3u, cpu.address("abs", 0x8774u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058734 JMP -> $058774
    goto L_058774;
L_058774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058774 PLP
    cpu.pop("PLP", hw);
    goto L_058775;
L_058775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8775u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058775 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058775u);return;} hw.unresolvedReturn(0x058775u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058775 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058775u);return;} hw.unresolvedReturn(0x058775u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8775u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058775 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058775u);return;} hw.unresolvedReturn(0x058775u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8775u,0x058775u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_05BCE9_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05BCE9u: goto L_05BCE9;
    case 0x05BCECu: goto L_05BCEC;
    case 0x05BCF0u: goto L_05BCF0;
    case 0x05BCF2u: goto L_05BCF2;
    case 0x05BCF4u: goto L_05BCF4;
    case 0x05BCF5u: goto L_05BCF5;
    case 0x05BCF9u: goto L_05BCF9;
    case 0x05BCFCu: goto L_05BCFC;
    case 0x05BCFEu: goto L_05BCFE;
    case 0x05BD00u: goto L_05BD00;
    case 0x05BD02u: goto L_05BD02;
    case 0x05BD04u: goto L_05BD04;
    case 0x05BD05u: goto L_05BD05;
    case 0x05BD08u: goto L_05BD08;
    case 0x05BD0Au: goto L_05BD0A;
    case 0x05BD0Bu: goto L_05BD0B;
    case 0x05BD0Du: goto L_05BD0D;
    case 0x05BD0Fu: goto L_05BD0F;
    case 0x05BD13u: goto L_05BD13;
    case 0x05BD17u: goto L_05BD17;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05BCE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE9u, 4u, 3u, cpu.address("abs", 0x143Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCE9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x143Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05BCEC;
L_05BCEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCECu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCECu, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05BCEC JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBCEFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBCF0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x05BCECu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05BCF0;
L_05BCF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCF0u,0x05BCF0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF0u,cpu,0x36u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF0u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCF0 ROL
    cpu.rolMem(hw, cpu.address("dpx", 0xBDu), cpu.m8?8:16);
    goto L_05BCF2;
L_05BCF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF2u,cpu,0x36u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF2u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCF2 ROL
    cpu.rolMem(hw, cpu.address("dpx", 0xBDu), cpu.m8?8:16);
    goto L_05BCF4;
L_05BCF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF4u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCF4 ROR
    cpu.rorA();
    goto L_05BCF5;
L_05BCF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF5u, 5u, 4u, ((0xDDBF0Au + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCF5 LDA
    cpu.loadA(hw.readW(((0xDDBF0Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05BCF9;
L_05BCF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF9u, 4u + ((((0xBFBAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xBFBAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCF9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xBFBAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05BCFC;
L_05BCFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFCu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFCu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xBFu) & 0xFFFFu), 3u, 0u);
    // $05BCFC STA
    hw.write(cpu.addressDpLongY(hw, 0xBFu), cpu.a, cpu.m8?8:16);
    goto L_05BCFE;
L_05BCFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFEu,cpu,0x35u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xBDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCFE AND
    cpu.logicAnd(hw.readW(cpu.address("dpx", 0xBDu), cpu.m8?8:16));
    goto L_05BD00;
L_05BD00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD00u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD00u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BD00 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xBEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05BD02;
L_05BD02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD02u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BD02 EOR
    cpu.logicXor(0xBCu);
    goto L_05BD04;
L_05BD04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD04u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BD04 DEC
    cpu.decReg('A');
    goto L_05BD05;
L_05BD05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD05u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD05u, 4u + ((((0xBFF6u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xBFF6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BD05 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xBFF6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05BD08;
L_05BD08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD08u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD08u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BD08 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xC0u), cpu.m8?8:16));
    goto L_05BD0A;
L_05BD0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BD0A INC
    cpu.inc('A');
    goto L_05BD0B;
L_05BD0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BD0B CPY
    cpu.compareY(0x36u);
    goto L_05BD0D;
L_05BD0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Du,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BD0D CPY
    cpu.compareY(0xADu);
    goto L_05BD0F;
L_05BD0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Fu,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Fu, 5u, 4u, ((0x22F014u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BD0F AND
    cpu.logicAnd(hw.readW(((0x22F014u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_05BD13;
L_05BD13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD13u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD13u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05BD13 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBD16u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD17u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x05BD13u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05BD17;
L_05BD17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD17u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD17u,0x05BD17u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD17u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD17u, 3u, 3u, cpu.address("abs", 0x4CBDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BD17 JMP -> $054CBD
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x4CBDu),0x05BD17u); return;
}

void sub_0DB198_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB198u: goto L_0DB198;
    case 0x0DB19Au: goto L_0DB19A;
    case 0x0DB19Cu: goto L_0DB19C;
    case 0x0DB19Eu: goto L_0DB19E;
    case 0x0DB1A0u: goto L_0DB1A0;
    case 0x0DB1A2u: goto L_0DB1A2;
    case 0x0DB1A4u: goto L_0DB1A4;
    case 0x0DB1A6u: goto L_0DB1A6;
    case 0x0DB1A8u: goto L_0DB1A8;
    case 0x0DB1AAu: goto L_0DB1AA;
    case 0x0DB1ACu: goto L_0DB1AC;
    case 0x0DB1AEu: goto L_0DB1AE;
    case 0x0DB1B0u: goto L_0DB1B0;
    case 0x0DB1B4u: goto L_0DB1B4;
    case 0x0DB1B6u: goto L_0DB1B6;
    case 0x0DB1B7u: goto L_0DB1B7;
    case 0x0DB1B9u: goto L_0DB1B9;
    case 0x0DB1BBu: goto L_0DB1BB;
    case 0x0DB1BEu: goto L_0DB1BE;
    case 0x0DB1C1u: goto L_0DB1C1;
    case 0x0DB1C5u: goto L_0DB1C5;
    case 0x0DB1C7u: goto L_0DB1C7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB198u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB198u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB198 CPX
    cpu.compareX(0x3u);
    goto L_0DB19A;
L_0DB19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB19Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Au,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB19A BMI -> $0DB1A4
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB1A4; }
    goto L_0DB19C;
L_0DB19C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB19Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Cu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB19C CPX
    cpu.compareX(0x7u);
    goto L_0DB19E;
L_0DB19E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB19Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB19E BMI -> $0DB1C7
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB1C7; }
    goto L_0DB1A0;
L_0DB1A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A0u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1A0 CPX
    cpu.compareX(0x9u);
    goto L_0DB1A2;
L_0DB1A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1A2 BPL -> $0DB1C7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB1C7; }
    goto L_0DB1A4;
L_0DB1A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A4u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1A4 CPX
    cpu.compareX(0x2u);
    goto L_0DB1A6;
L_0DB1A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1A6 BEQ -> $0DB1C7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB1C7; }
    goto L_0DB1A8;
L_0DB1A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1A8 STX
    hw.write(cpu.address("dp", 0xBu), cpu.x, cpu.x8?8:16);
    goto L_0DB1AA;
L_0DB1AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1AAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1AA STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_0DB1AC;
L_0DB1AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ACu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1AC LDX
    cpu.setX(0x1Du, 8);
    goto L_0DB1AE;
L_0DB1AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1AEu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1AEu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB1AE LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB1B0;
L_0DB1B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B0u,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B0u, 5u, 4u, ((0x0DB15Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1B0 CMP
    cpu.compareA(hw.readW(((0xDB15Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DB1B4;
L_0DB1B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1B4 BEQ -> $0DB1BE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB1BE; }
    goto L_0DB1B6;
L_0DB1B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B6u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1B6 DEX
    cpu.decReg('X');
    goto L_0DB1B7;
L_0DB1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1B7 BPL -> $0DB1B0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB1B0; }
    goto L_0DB1B9;
L_0DB1B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1B9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB1BB;
L_0DB1BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BBu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BBu, 3u, 3u, cpu.address("abs", 0xB1C5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1BB JMP -> $0DB1C5
    goto L_0DB1C5;
L_0DB1BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BEu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1BE JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xB1C0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1C1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DB1BEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1C1;
L_0DB1C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1C1u,0x0DB1C1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C1u, 5u, 4u, ((0x0DB17Au + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1C1 LDA
    cpu.loadA(hw.readW(((0xDB17Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB1C5;
L_0DB1C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C5u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1C5 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xBu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB1C7;
L_0DB1C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB1C7u);return;} hw.unresolvedReturn(0x0DB1C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DCFF0_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DCFF0u: goto L_0DCFF0;
    case 0x0DCFF2u: goto L_0DCFF2;
    case 0x0DCFF4u: goto L_0DCFF4;
    case 0x0DCFF5u: goto L_0DCFF5;
    case 0x0DCFF6u: goto L_0DCFF6;
    case 0x0DCFF7u: goto L_0DCFF7;
    case 0x0DCFF8u: goto L_0DCFF8;
    case 0x0DCFF9u: goto L_0DCFF9;
    case 0x0DCFFCu: goto L_0DCFFC;
    case 0x0DCFFFu: goto L_0DCFFF;
    case 0x0DD001u: goto L_0DD001;
    case 0x0DD004u: goto L_0DD004;
    case 0x0DD007u: goto L_0DD007;
    case 0x0DD009u: goto L_0DD009;
    case 0x0DD00Bu: goto L_0DD00B;
    case 0x0DD00Eu: goto L_0DD00E;
    case 0x0DD010u: goto L_0DD010;
    case 0x0DD011u: goto L_0DD011;
    case 0x0DD013u: goto L_0DD013;
    case 0x0DD014u: goto L_0DD014;
    case 0x0DD016u: goto L_0DD016;
    case 0x0DD019u: goto L_0DD019;
    case 0x0DD01Au: goto L_0DD01A;
    case 0x0DD01Bu: goto L_0DD01B;
    case 0x0DD01Du: goto L_0DD01D;
    case 0x0DD01Eu: goto L_0DD01E;
    case 0x0DD020u: goto L_0DD020;
    case 0x0DD022u: goto L_0DD022;
    case 0x0DD024u: goto L_0DD024;
    case 0x0DD025u: goto L_0DD025;
    case 0x0DD026u: goto L_0DD026;
    case 0x0DD028u: goto L_0DD028;
    case 0x0DD02Au: goto L_0DD02A;
    case 0x0DD02Bu: goto L_0DD02B;
    case 0x0DD02Eu: goto L_0DD02E;
    case 0x0DD030u: goto L_0DD030;
    case 0x0DD031u: goto L_0DD031;
    case 0x0DD033u: goto L_0DD033;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DCFF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFF0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DCFF2;
L_0DCFF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCFF4;
L_0DCFF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFF4 LSR
    cpu.lsrA();
    goto L_0DCFF5;
L_0DCFF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFF5 LSR
    cpu.lsrA();
    goto L_0DCFF6;
L_0DCFF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFF6 LSR
    cpu.lsrA();
    goto L_0DCFF7;
L_0DCFF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFF7 LSR
    cpu.lsrA();
    goto L_0DCFF8;
L_0DCFF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFF8 TAX
    cpu.transfer("TAX");
    goto L_0DCFF9;
L_0DCFF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF9u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCFF9 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xCFFBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCFFCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DCFF9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCFFC;
L_0DCFFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFFCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCFFCu,0x0DCFFCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFCu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCFFC JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xCFFEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCFFFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DCFFCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCFFF;
L_0DCFFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFFFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCFFFu,0x0DCFFFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFFF LDA
    cpu.setA(0x8Eu, 8);
    goto L_0DD001;
L_0DD001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD001u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD001u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD001 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xD003u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD004u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DD001u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD004;
L_0DD004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD004u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD004u,0x0DD004u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD004u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD004u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD004 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xD006u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD007u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DD004u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD007;
L_0DD007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD007u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD007u,0x0DD007u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD007u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD007u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD007 LDA
    cpu.setA(0x8Fu, 8);
    goto L_0DD009;
L_0DD009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD009u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD009u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD009u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DD009 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DD00B;
L_0DD00B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD00Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Bu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD00B JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xD00Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD00Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DD00Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD00E;
L_0DD00E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD00Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD00Eu,0x0DD00Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD00E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DD010;
L_0DD010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD010u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD010u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD010 CLC
    cpu.setFlag('C', false);
    goto L_0DD011;
L_0DD011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD011u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD011u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD011 ADC
    cpu.adc(0x10u);
    goto L_0DD013;
L_0DD013:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD013u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD013u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD013u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD013 TAY
    cpu.transfer("TAY");
    goto L_0DD014;
L_0DD014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD014u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD014u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD014 BCC -> $0DD019
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DD019; }
    goto L_0DD016;
L_0DD016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD016u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD016u, 6u, 3u, cpu.address("abs", 0xA987u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD016 JSR -> $0DA987 stack real
    { cpu.push16Value(hw,0xD018u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD019u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA987u), 0x0DD016u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD019;
L_0DD019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD019u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD019u,0x0DD019u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD019u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD019u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD019 TYA
    cpu.transfer("TYA");
    goto L_0DD01A;
L_0DD01A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD01A CLC
    cpu.setFlag('C', false);
    goto L_0DD01B;
L_0DD01B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD01B ADC
    cpu.adc(0x2u);
    goto L_0DD01D;
L_0DD01D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD01D TAY
    cpu.transfer("TAY");
    goto L_0DD01E;
L_0DD01E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD01E AND
    cpu.logicAnd(0xFu);
    goto L_0DD020;
L_0DD020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD020u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD020u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD020 CMP
    cpu.compareA(0x2u);
    goto L_0DD022;
L_0DD022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD022u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD022u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD022 BPL -> $0DD02E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DD02E; }
    goto L_0DD024;
L_0DD024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD024u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD024u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD024 TYA
    cpu.transfer("TYA");
    goto L_0DD025;
L_0DD025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD025u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD025u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD025 SEC
    cpu.setFlag('C', true);
    goto L_0DD026;
L_0DD026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD026u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD026u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD026 SBC
    cpu.sbc(0x10u);
    goto L_0DD028;
L_0DD028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD028 AND
    cpu.logicAnd(0xF1u);
    goto L_0DD02A;
L_0DD02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD02A TAY
    cpu.transfer("TAY");
    goto L_0DD02B;
L_0DD02B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Bu, 6u, 3u, cpu.address("abs", 0xA9EFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD02B JSR -> $0DA9EF stack real
    { cpu.push16Value(hw,0xD02Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD02Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA9EFu), 0x0DD02Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD02E;
L_0DD02E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD02Eu,0x0DD02Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Eu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD02E STY
    hw.write(cpu.address("dp", 0x57u), cpu.y, cpu.x8?8:16);
    goto L_0DD030;
L_0DD030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD030u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD030u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD030 DEX
    cpu.decReg('X');
    goto L_0DD031;
L_0DD031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD031u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD031u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD031 BPL -> $0DCFFC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DCFFC; }
    goto L_0DD033;
L_0DD033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD033u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD033u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD033 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DD033u);return;} hw.unresolvedReturn(0x0DD033u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DDD87_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DDD87u: goto L_0DDD87;
    case 0x0DDD89u: goto L_0DDD89;
    case 0x0DDD8Au: goto L_0DDD8A;
    case 0x0DDD8Bu: goto L_0DDD8B;
    case 0x0DDD8Cu: goto L_0DDD8C;
    case 0x0DDD8Du: goto L_0DDD8D;
    case 0x0DDD8Fu: goto L_0DDD8F;
    case 0x0DDD93u: goto L_0DDD93;
    case 0x0DDD96u: goto L_0DDD96;
    case 0x0DDD99u: goto L_0DDD99;
    case 0x0DDD9Bu: goto L_0DDD9B;
    case 0x0DDD9Du: goto L_0DDD9D;
    case 0x0DDD9Fu: goto L_0DDD9F;
    case 0x0DDDA1u: goto L_0DDDA1;
    case 0x0DDDA2u: goto L_0DDDA2;
    case 0x0DDDA3u: goto L_0DDDA3;
    case 0x0DDDA5u: goto L_0DDDA5;
    case 0x0DDDA7u: goto L_0DDDA7;
    case 0x0DDDAAu: goto L_0DDDAA;
    case 0x0DDDACu: goto L_0DDDAC;
    case 0x0DDDAFu: goto L_0DDDAF;
    case 0x0DDDB1u: goto L_0DDDB1;
    case 0x0DDDB3u: goto L_0DDDB3;
    case 0x0DDDB4u: goto L_0DDDB4;
    case 0x0DDDB5u: goto L_0DDDB5;
    case 0x0DDDB7u: goto L_0DDDB7;
    case 0x0DDDB8u: goto L_0DDDB8;
    case 0x0DDDBAu: goto L_0DDDBA;
    case 0x0DDDBCu: goto L_0DDDBC;
    case 0x0DDDBEu: goto L_0DDDBE;
    case 0x0DDDC0u: goto L_0DDDC0;
    case 0x0DDDC2u: goto L_0DDDC2;
    case 0x0DDDC5u: goto L_0DDDC5;
    case 0x0DDDC7u: goto L_0DDDC7;
    case 0x0DDDC9u: goto L_0DDDC9;
    case 0x0DDDCAu: goto L_0DDDCA;
    case 0x0DDDCBu: goto L_0DDDCB;
    case 0x0DDDCDu: goto L_0DDDCD;
    case 0x0DDDCEu: goto L_0DDDCE;
    case 0x0DDDD0u: goto L_0DDDD0;
    case 0x0DDDD2u: goto L_0DDDD2;
    case 0x0DDDD4u: goto L_0DDDD4;
    case 0x0DDDD6u: goto L_0DDDD6;
    case 0x0DDDD8u: goto L_0DDDD8;
    case 0x0DDDDBu: goto L_0DDDDB;
    case 0x0DDDDDu: goto L_0DDDDD;
    case 0x0DDDDFu: goto L_0DDDDF;
    case 0x0DDDE0u: goto L_0DDDE0;
    case 0x0DDDE1u: goto L_0DDDE1;
    case 0x0DDDE3u: goto L_0DDDE3;
    case 0x0DDDE4u: goto L_0DDDE4;
    case 0x0DDDE6u: goto L_0DDDE6;
    case 0x0DDDE8u: goto L_0DDDE8;
    case 0x0DDDEAu: goto L_0DDDEA;
    case 0x0DDDECu: goto L_0DDDEC;
    case 0x0DDDEEu: goto L_0DDDEE;
    case 0x0DDDEFu: goto L_0DDDEF;
    case 0x0DDDF0u: goto L_0DDDF0;
    case 0x0DDDF3u: goto L_0DDDF3;
    case 0x0DDDF6u: goto L_0DDDF6;
    case 0x0DDDF8u: goto L_0DDDF8;
    case 0x0DDDFAu: goto L_0DDDFA;
    case 0x0DDDFBu: goto L_0DDDFB;
    case 0x0DDDFCu: goto L_0DDDFC;
    case 0x0DDDFEu: goto L_0DDDFE;
    case 0x0DDDFFu: goto L_0DDDFF;
    case 0x0DDE01u: goto L_0DDE01;
    case 0x0DDE03u: goto L_0DDE03;
    case 0x0DDE05u: goto L_0DDE05;
    case 0x0DDE07u: goto L_0DDE07;
    case 0x0DDE09u: goto L_0DDE09;
    case 0x0DDE0Au: goto L_0DDE0A;
    case 0x0DDE0Cu: goto L_0DDE0C;
    case 0x0DDE0Fu: goto L_0DDE0F;
    case 0x0DDE11u: goto L_0DDE11;
    case 0x0DDE12u: goto L_0DDE12;
    case 0x0DDE14u: goto L_0DDE14;
    case 0x0DDE15u: goto L_0DDE15;
    case 0x0DDE17u: goto L_0DDE17;
    case 0x0DDE1Au: goto L_0DDE1A;
    case 0x0DDE1Bu: goto L_0DDE1B;
    case 0x0DDE1Du: goto L_0DDE1D;
    case 0x0DDE1Fu: goto L_0DDE1F;
    case 0x0DDE21u: goto L_0DDE21;
    case 0x0DDE22u: goto L_0DDE22;
    case 0x0DDE23u: goto L_0DDE23;
    case 0x0DDE25u: goto L_0DDE25;
    case 0x0DDE26u: goto L_0DDE26;
    case 0x0DDE28u: goto L_0DDE28;
    case 0x0DDE2Bu: goto L_0DDE2B;
    case 0x0DDE2Eu: goto L_0DDE2E;
    case 0x0DDE30u: goto L_0DDE30;
    case 0x0DDE32u: goto L_0DDE32;
    case 0x0DDE34u: goto L_0DDE34;
    case 0x0DDE36u: goto L_0DDE36;
    case 0x0DDE38u: goto L_0DDE38;
    case 0x0DDE3Bu: goto L_0DDE3B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DDD87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD87u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD87u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD87 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDD89;
L_0DDD89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD89u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD89 LSR
    cpu.lsrA();
    goto L_0DDD8A;
L_0DDD8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD8Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD8A LSR
    cpu.lsrA();
    goto L_0DDD8B;
L_0DDD8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD8Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD8B LSR
    cpu.lsrA();
    goto L_0DDD8C;
L_0DDD8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD8Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD8Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD8C LSR
    cpu.lsrA();
    goto L_0DDD8D;
L_0DDD8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD8Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD8D AND
    cpu.logicAnd(0x1u);
    goto L_0DDD8F;
L_0DDD8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD8Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD8Fu, 8u, 4u, 0x0086FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0DDD8F JSL -> $0086FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDD92u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD93u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086FAu, 0x0DDD8Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDD93;
L_0DDD93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD93u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD93u,0x0DDD93u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD93u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD93u, 5u, 3u, cpu.address("absy", 0x0DDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD93 STA
    hw.write(cpu.address("absy", 0xDDDu), cpu.a, cpu.m8?8:16);
    goto L_0DDD96;
L_0DDD96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD96u,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD96u, 4u + ((((0x0DDEu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD96 BIT
    cpu.bit(hw.readW(cpu.address("absx", 0xDDEu), cpu.m8?8:16), false);
    goto L_0DDD99;
L_0DDD99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD99u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD99u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD99 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DDD9B;
L_0DDD9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD9B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDD9D;
L_0DDD9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD9D AND
    cpu.logicAnd(0xFu);
    goto L_0DDD9F;
L_0DDD9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD9Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD9F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DDDA1;
L_0DDDA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDA1 ASL
    cpu.aslA();
    goto L_0DDDA2;
L_0DDDA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDA2 CLC
    cpu.setFlag('C', false);
    goto L_0DDDA3;
L_0DDDA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDA3 ADC
    cpu.adc(0x2u);
    goto L_0DDDA5;
L_0DDDA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDA5 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DDDA7;
L_0DDDA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDA7u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDDA7 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xDDA9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDDAAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DDDA7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDDAA;
L_0DDDAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDAAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDDAAu,0x0DDDAAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDAAu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDAAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDAA LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DDDAC;
L_0DDDAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDACu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDACu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDDAC JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDDAEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDDAFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDDACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDDAF;
L_0DDDAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDAFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDDAFu,0x0DDDAFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDAFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDAF LDA
    cpu.setA(0xCAu, 8);
    goto L_0DDDB1;
L_0DDDB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB1u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB1u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DDDB1 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DDDB3;
L_0DDDB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB3u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDB3 TYA
    cpu.transfer("TYA");
    goto L_0DDDB4;
L_0DDDB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDB4 CLC
    cpu.setFlag('C', false);
    goto L_0DDDB5;
L_0DDDB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDB5 ADC
    cpu.adc(0x10u);
    goto L_0DDDB7;
L_0DDDB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDB7 TAY
    cpu.transfer("TAY");
    goto L_0DDDB8;
L_0DDDB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDB8 BCC -> $0DDDC2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DDDC2; }
    goto L_0DDDBA;
L_0DDDBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDBA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDDBC;
L_0DDDBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDBC ADC
    cpu.adc(0x0u);
    goto L_0DDDBE;
L_0DDDBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDBEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDBE STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0DDDC0;
L_0DDDC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDC0 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0DDDC2;
L_0DDDC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC2u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDDC2 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDDC4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDDC5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDDC2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDDC5;
L_0DDDC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDC5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDDC5u,0x0DDDC5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDC5 LDA
    cpu.setA(0xCBu, 8);
    goto L_0DDDC7;
L_0DDDC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC7u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC7u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DDDC7 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DDDC9;
L_0DDDC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC9u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDC9 TYA
    cpu.transfer("TYA");
    goto L_0DDDCA;
L_0DDDCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDCAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDCAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDCA CLC
    cpu.setFlag('C', false);
    goto L_0DDDCB;
L_0DDDCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDCBu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDCB ADC
    cpu.adc(0x10u);
    goto L_0DDDCD;
L_0DDDCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDCDu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDCDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDCD TAY
    cpu.transfer("TAY");
    goto L_0DDDCE;
L_0DDDCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDCEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDCE BCC -> $0DDDD8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DDDD8; }
    goto L_0DDDD0;
L_0DDDD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDD0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDDD2;
L_0DDDD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDD2 ADC
    cpu.adc(0x0u);
    goto L_0DDDD4;
L_0DDDD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDD4 STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0DDDD6;
L_0DDDD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDD6 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0DDDD8;
L_0DDDD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDD8u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDDD8 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDDDAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDDDBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDDD8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDDDB;
L_0DDDDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDDBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDDDBu,0x0DDDDBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDDBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDDBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDDB LDA
    cpu.setA(0xF1u, 8);
    goto L_0DDDDD;
L_0DDDDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDDDu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDDDu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DDDDD STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DDDDF;
L_0DDDDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDDFu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDDFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDDF TYA
    cpu.transfer("TYA");
    goto L_0DDDE0;
L_0DDDE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE0u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDE0 CLC
    cpu.setFlag('C', false);
    goto L_0DDDE1;
L_0DDDE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDE1 ADC
    cpu.adc(0x10u);
    goto L_0DDDE3;
L_0DDDE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDE3 TAY
    cpu.transfer("TAY");
    goto L_0DDDE4;
L_0DDDE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDE4 BCC -> $0DDDEE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DDDEE; }
    goto L_0DDDE6;
L_0DDDE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDE6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDDE8;
L_0DDDE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE8u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDE8 ADC
    cpu.adc(0x0u);
    goto L_0DDDEA;
L_0DDDEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDEAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDEAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDEA STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0DDDEC;
L_0DDDEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDECu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDEC STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0DDDEE;
L_0DDDEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDEEu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDEEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDEE DEX
    cpu.decReg('X');
    goto L_0DDDEF;
L_0DDDEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDEFu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDEF DEX
    cpu.decReg('X');
    goto L_0DDDF0;
L_0DDDF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDF0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDF0u, 3u, 3u, cpu.address("abs", 0xDE09u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDF0 JMP -> $0DDE09
    goto L_0DDE09;
L_0DDDF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDF3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDF3u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDDF3 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xDDF5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDDF6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DDDF3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDDF6;
L_0DDDF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDF6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDDF6u,0x0DDDF6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDF6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDF6 LDA
    cpu.setA(0x3Fu, 8);
    goto L_0DDDF8;
L_0DDDF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDF8u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDF8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DDDF8 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DDDFA;
L_0DDDFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDFAu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDFAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDFA TYA
    cpu.transfer("TYA");
    goto L_0DDDFB;
L_0DDDFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDFBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDFB CLC
    cpu.setFlag('C', false);
    goto L_0DDDFC;
L_0DDDFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDFCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDFC ADC
    cpu.adc(0x10u);
    goto L_0DDDFE;
L_0DDDFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDFEu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDFE TAY
    cpu.transfer("TAY");
    goto L_0DDDFF;
L_0DDDFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDDFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDDFFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDDFFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDDFF BCC -> $0DDE09
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DDE09; }
    goto L_0DDE01;
L_0DDE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE01u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE01u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE01 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDE03;
L_0DDE03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE03u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE03u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE03 ADC
    cpu.adc(0x0u);
    goto L_0DDE05;
L_0DDE05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE05u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE05u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE05 STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0DDE07;
L_0DDE07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE07u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE07u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE07 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0DDE09;
L_0DDE09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE09u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE09 DEX
    cpu.decReg('X');
    goto L_0DDE0A;
L_0DDE0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE0A BPL -> $0DDDF3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DDDF3; }
    goto L_0DDE0C;
L_0DDE0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Cu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDE0C JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xDE0Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE0Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DDE0Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDE0F;
L_0DDE0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE0Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE0Fu,0x0DDE0Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE0Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE0F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDE11;
L_0DDE11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE11u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE11 CLC
    cpu.setFlag('C', false);
    goto L_0DDE12;
L_0DDE12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE12u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE12 ADC
    cpu.adc(0x1Fu);
    goto L_0DDE14;
L_0DDE14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE14u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE14u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE14 TAY
    cpu.transfer("TAY");
    goto L_0DDE15;
L_0DDE15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE15u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE15u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE15 BCC -> $0DDE1A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DDE1A; }
    goto L_0DDE17;
L_0DDE17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE17u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE17u, 6u, 3u, cpu.address("abs", 0xA987u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDE17 JSR -> $0DA987 stack real
    { cpu.push16Value(hw,0xDE19u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE1Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA987u), 0x0DDE17u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDE1A;
L_0DDE1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE1Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE1Au,0x0DDE1Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE1Au,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE1A TYA
    cpu.transfer("TYA");
    goto L_0DDE1B;
L_0DDE1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE1Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE1B AND
    cpu.logicAnd(0xFu);
    goto L_0DDE1D;
L_0DDE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE1Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE1D CMP
    cpu.compareA(0xFu);
    goto L_0DDE1F;
L_0DDE1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE1Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE1Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE1F BNE -> $0DDE2E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DDE2E; }
    goto L_0DDE21;
L_0DDE21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE21u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE21 TYA
    cpu.transfer("TYA");
    goto L_0DDE22;
L_0DDE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE22u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE22 CLC
    cpu.setFlag('C', false);
    goto L_0DDE23;
L_0DDE23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE23u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE23 ADC
    cpu.adc(0x10u);
    goto L_0DDE25;
L_0DDE25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE25u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE25 TAY
    cpu.transfer("TAY");
    goto L_0DDE26;
L_0DDE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE26u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE26 BCC -> $0DDE2B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DDE2B; }
    goto L_0DDE28;
L_0DDE28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE28u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE28u, 6u, 3u, cpu.address("abs", 0xA987u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDE28 JSR -> $0DA987 stack real
    { cpu.push16Value(hw,0xDE2Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE2Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA987u), 0x0DDE28u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDE2B;
L_0DDE2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE2Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE2Bu,0x0DDE2Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Bu, 6u, 3u, cpu.address("abs", 0xA9D6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDE2B JSR -> $0DA9D6 stack real
    { cpu.push16Value(hw,0xDE2Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE2Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA9D6u), 0x0DDE2Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDE2E;
L_0DDE2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE2Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE2Eu,0x0DDE2Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Eu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE2Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE2E STY
    hw.write(cpu.address("dp", 0x57u), cpu.y, cpu.x8?8:16);
    goto L_0DDE30;
L_0DDE30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE30u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE30u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE30 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DDE32;
L_0DDE32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE32u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE32u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE32 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DDE34;
L_0DDE34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE34u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE34u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE34 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DDE36;
L_0DDE36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE36u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE36 BMI -> $0DDE3B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DDE3B; }
    goto L_0DDE38;
L_0DDE38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE38u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE38u, 3u, 3u, cpu.address("abs", 0xDDA7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDE38 JMP -> $0DDDA7
    goto L_0DDDA7;
L_0DDE3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE3Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE3Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDE3B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DDE3Bu);return;} hw.unresolvedReturn(0x0DDE3Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DED12_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DED12u: goto L_0DED12;
    case 0x0DED14u: goto L_0DED14;
    case 0x0DED16u: goto L_0DED16;
    case 0x0DED18u: goto L_0DED18;
    case 0x0DED1Au: goto L_0DED1A;
    case 0x0DED1Cu: goto L_0DED1C;
    case 0x0DED1Du: goto L_0DED1D;
    case 0x0DED1Eu: goto L_0DED1E;
    case 0x0DED1Fu: goto L_0DED1F;
    case 0x0DED20u: goto L_0DED20;
    case 0x0DED21u: goto L_0DED21;
    case 0x0DED24u: goto L_0DED24;
    case 0x0DED28u: goto L_0DED28;
    case 0x0DED2Bu: goto L_0DED2B;
    case 0x0DED2Eu: goto L_0DED2E;
    case 0x0DED32u: goto L_0DED32;
    case 0x0DED35u: goto L_0DED35;
    case 0x0DED37u: goto L_0DED37;
    case 0x0DED39u: goto L_0DED39;
    case 0x0DED3Cu: goto L_0DED3C;
    case 0x0DED40u: goto L_0DED40;
    case 0x0DED42u: goto L_0DED42;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DED12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED12u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED12u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED12 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DED14;
L_0DED14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED14u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED14u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED14 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DED16;
L_0DED16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED16u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED16 AND
    cpu.logicAnd(0xFu);
    goto L_0DED18;
L_0DED18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED18u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED18 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DED1A;
L_0DED1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED1A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DED1C;
L_0DED1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED1C LSR
    cpu.lsrA();
    goto L_0DED1D;
L_0DED1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED1D LSR
    cpu.lsrA();
    goto L_0DED1E;
L_0DED1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED1E LSR
    cpu.lsrA();
    goto L_0DED1F;
L_0DED1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED1F LSR
    cpu.lsrA();
    goto L_0DED20;
L_0DED20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED20u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED20 TAX
    cpu.transfer("TAX");
    goto L_0DED21;
L_0DED21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED21u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED21u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DED21 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xED23u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xED24u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DED21u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DED24;
L_0DED24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED24u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED24u,0x0DED24u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED24u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED24u, 5u, 4u, ((0x0DED09u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED24 LDA
    cpu.loadA(hw.readW(((0xDED09u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DED28;
L_0DED28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED28u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED28u, 3u, 3u, cpu.address("abs", 0xED32u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED28 JMP -> $0DED32
    goto L_0DED32;
L_0DED2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Bu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DED2B JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xED2Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xED2Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DED2Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DED2E;
L_0DED2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED2Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED2Eu,0x0DED2Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Eu, 5u, 4u, ((0x0DED0Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED2E LDA
    cpu.loadA(hw.readW(((0xDED0Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DED32;
L_0DED32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED32u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED32u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DED32 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xED34u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xED35u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DED32u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DED35;
L_0DED35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED35u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED35u,0x0DED35u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED35u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED35u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED35 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DED37;
L_0DED37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED37u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED37 BNE -> $0DED2B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DED2B; }
    goto L_0DED39;
L_0DED39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED39u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED39u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DED39 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xED3Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xED3Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DED39u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DED3C;
L_0DED3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED3Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED3Cu,0x0DED3Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED3Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED3Cu, 5u, 4u, ((0x0DED0Fu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED3C LDA
    cpu.loadA(hw.readW(((0xDED0Fu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DED40;
L_0DED40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED40u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED40u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DED40 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DED42;
L_0DED42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED42u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED42u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DED42 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DED42u);return;} hw.unresolvedReturn(0x0DED42u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A3DF_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A3DFu: goto L_B1A3DF;
    case 0xB1A3E2u: goto L_B1A3E2;
    case 0xB1A3E4u: goto L_B1A3E4;
    case 0xB1A3E5u: goto L_B1A3E5;
    case 0xB1A3E6u: goto L_B1A3E6;
    case 0xB1A3E8u: goto L_B1A3E8;
    case 0xB1A3E9u: goto L_B1A3E9;
    case 0xB1A3EBu: goto L_B1A3EB;
    case 0xB1A3EEu: goto L_B1A3EE;
    case 0xB1A3EFu: goto L_B1A3EF;
    case 0xB1A3F0u: goto L_B1A3F0;
    case 0xB1A3F1u: goto L_B1A3F1;
    case 0xB1A3F2u: goto L_B1A3F2;
    case 0xB1A3F4u: goto L_B1A3F4;
    case 0xB1A3F7u: goto L_B1A3F7;
    case 0xB1A3F8u: goto L_B1A3F8;
    case 0xB1A3F9u: goto L_B1A3F9;
    case 0xB1A3FBu: goto L_B1A3FB;
    case 0xB1A3FDu: goto L_B1A3FD;
    case 0xB1A400u: goto L_B1A400;
    case 0xB1A401u: goto L_B1A401;
    case 0xB1A402u: goto L_B1A402;
    case 0xB1A403u: goto L_B1A403;
    case 0xB1A404u: goto L_B1A404;
    case 0xB1A406u: goto L_B1A406;
    case 0xB1A409u: goto L_B1A409;
    case 0xB1A40Au: goto L_B1A40A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A3DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DFu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3DF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A3E2;
L_B1A3E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3E2 BEQ -> $B1A40A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A40A; }
    goto L_B1A3E4;
L_B1A3E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E4u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3E4 PHX
    cpu.push("PHX", hw);
    goto L_B1A3E5;
L_B1A3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3E5 LSR
    cpu.lsrA();
    goto L_B1A3E6;
L_B1A3E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3E6 BCC -> $B1A3F8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A3F8; }
    goto L_B1A3E8;
L_B1A3E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E8u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3E8 PHA
    cpu.push("PHA", hw);
    goto L_B1A3E9;
L_B1A3E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3E9 LDA
    cpu.setA(0x1u, 8);
    goto L_B1A3EB;
L_B1A3EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EBu, 5u, 3u, cpu.address("absy", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3EB STA
    hw.write(cpu.address("absy", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_B1A3EE;
L_B1A3EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EEu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3EE TYA
    cpu.transfer("TYA");
    goto L_B1A3EF;
L_B1A3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3EF ASL
    cpu.aslA();
    goto L_B1A3F0;
L_B1A3F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3F0 ASL
    cpu.aslA();
    goto L_B1A3F1;
L_B1A3F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3F1 TAX
    cpu.transfer("TAX");
    goto L_B1A3F2;
L_B1A3F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3F2 LDA
    cpu.setA(0x80u, 8);
    goto L_B1A3F4;
L_B1A3F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F4u, 5u, 3u, cpu.address("absx", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3F4 STA
    hw.write(cpu.address("absx", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_B1A3F7;
L_B1A3F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A3F7 PLA
    cpu.pop("PLA", hw);
    goto L_B1A3F8;
L_B1A3F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3F8 LSR
    cpu.lsrA();
    goto L_B1A3F9;
L_B1A3F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3F9 BCC -> $B1A409
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A409; }
    goto L_B1A3FB;
L_B1A3FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3FB LDA
    cpu.setA(0x1u, 8);
    goto L_B1A3FD;
L_B1A3FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FDu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FDu, 5u, 3u, cpu.address("absy", 0x0461u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A3FD STA
    hw.write(cpu.address("absy", 0x461u), cpu.a, cpu.m8?8:16);
    goto L_B1A400;
L_B1A400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA400u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA400u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A400 TYA
    cpu.transfer("TYA");
    goto L_B1A401;
L_B1A401:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA401u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA401u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA401u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A401 ASL
    cpu.aslA();
    goto L_B1A402;
L_B1A402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA402u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA402u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A402 ASL
    cpu.aslA();
    goto L_B1A403;
L_B1A403:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA403u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA403u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA403u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A403 TAX
    cpu.transfer("TAX");
    goto L_B1A404;
L_B1A404:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA404u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA404u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA404u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A404 LDA
    cpu.setA(0x80u, 8);
    goto L_B1A406;
L_B1A406:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA406u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA406u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA406u, 5u, 3u, cpu.address("absx", 0x0304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A406 STA
    hw.write(cpu.address("absx", 0x304u), cpu.a, cpu.m8?8:16);
    goto L_B1A409;
L_B1A409:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA409u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA409u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA409u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A409 PLX
    cpu.pop("PLX", hw);
    goto L_B1A40A;
L_B1A40A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A40A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A40Au);return;} hw.unresolvedReturn(0xB1A40Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A9E2_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A9E2u: goto L_B1A9E2;
    case 0xB1A9E5u: goto L_B1A9E5;
    case 0xB1A9E7u: goto L_B1A9E7;
    case 0xB1A9E9u: goto L_B1A9E9;
    case 0xB1A9EBu: goto L_B1A9EB;
    case 0xB1A9EEu: goto L_B1A9EE;
    case 0xB1A9F0u: goto L_B1A9F0;
    case 0xB1A9F2u: goto L_B1A9F2;
    case 0xB1A9F4u: goto L_B1A9F4;
    case 0xB1A9F6u: goto L_B1A9F6;
    case 0xB1A9F8u: goto L_B1A9F8;
    case 0xB1A9FBu: goto L_B1A9FB;
    case 0xB1A9FDu: goto L_B1A9FD;
    case 0xB1AA00u: goto L_B1AA00;
    case 0xB1AA01u: goto L_B1AA01;
    case 0xB1AA04u: goto L_B1AA04;
    case 0xB1AA07u: goto L_B1AA07;
    case 0xB1AA09u: goto L_B1AA09;
    case 0xB1AA0Bu: goto L_B1AA0B;
    case 0xB1AA0Du: goto L_B1AA0D;
    case 0xB1AA0Fu: goto L_B1AA0F;
    case 0xB1AA12u: goto L_B1AA12;
    case 0xB1AA14u: goto L_B1AA14;
    case 0xB1AA16u: goto L_B1AA16;
    case 0xB1AA18u: goto L_B1AA18;
    case 0xB1AA1Au: goto L_B1AA1A;
    case 0xB1AA1Cu: goto L_B1AA1C;
    case 0xB1AA1Eu: goto L_B1AA1E;
    case 0xB1AA20u: goto L_B1AA20;
    case 0xB1AA22u: goto L_B1AA22;
    case 0xB1AA24u: goto L_B1AA24;
    case 0xB1AA26u: goto L_B1AA26;
    case 0xB1AA28u: goto L_B1AA28;
    case 0xB1AA2Au: goto L_B1AA2A;
    case 0xB1AA2Du: goto L_B1AA2D;
    case 0xB1AA2Fu: goto L_B1AA2F;
    case 0xB1AA32u: goto L_B1AA32;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A9E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E2u, 4u + ((((0x1662u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1662u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9E2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1662u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9E5;
L_B1A9E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9E5 AND
    cpu.logicAnd(0x80u);
    goto L_B1A9E7;
L_B1A9E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9E7 BEQ -> $B1AA01
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA01; }
    goto L_B1A9E9;
L_B1A9E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9E9 LDA
    cpu.setA(0x2u, 8);
    goto L_B1A9EB;
L_B1A9EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EBu, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9EB STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A9EE;
L_B1A9EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EEu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9EE STZ
    hw.write(cpu.address("dpx", 0xB6u), 0, cpu.m8?8:16);
    goto L_B1A9F0;
L_B1A9F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9F0 STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_B1A9F2;
L_B1A9F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9F2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9F4;
L_B1A9F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9F4 CMP
    cpu.compareA(0x1Eu);
    goto L_B1A9F6;
L_B1A9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9F6 BNE -> $B1AA00
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA00; }
    goto L_B1A9F8;
L_B1A9F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F8u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F8u, 4u, 3u, cpu.address("abs", 0x18E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9F8 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x18E1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A9FB;
L_B1A9FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9FB LDA
    cpu.setA(0x1Fu, 8);
    goto L_B1A9FD;
L_B1A9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu, 5u, 3u, cpu.address("absy", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9FD STA
    hw.write(cpu.address("absy", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B1AA00;
L_B1AA00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA00u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA00u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1AA00 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1AA00u);return;} hw.unresolvedReturn(0xB1AA00u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1AA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA01 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x14C8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1AA04;
L_B1AA04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u, 5u, 3u, cpu.address("absx", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA04 STZ
    hw.write(cpu.address("absx", 0x1626u), 0, cpu.m8?8:16);
    goto L_B1AA07;
L_B1AA07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA07 CPY
    cpu.compareY(0x8u);
    goto L_B1AA09;
L_B1AA09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA09u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA09 BEQ -> $B1AA14
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA14; }
    goto L_B1AA0B;
L_B1AA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA0B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1AA0D;
L_B1AA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA0D BNE -> $B1AA14
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA14; }
    goto L_B1AA0F;
L_B1AA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA0F STZ
    hw.write(cpu.address("absx", 0x1540u), 0, cpu.m8?8:16);
    goto L_B1AA12;
L_B1AA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA12 BRA -> $B1AA2D
    goto L_B1AA2D;
L_B1AA14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA14u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA14u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA14 LDA
    cpu.setA(0x2u, 8);
    goto L_B1AA16;
L_B1AA16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA16u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA16 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1AA18;
L_B1AA18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA18u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA18 CPY
    cpu.compareY(0xFu);
    goto L_B1AA1A;
L_B1AA1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA1A BEQ -> $B1AA28
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA28; }
    goto L_B1AA1C;
L_B1AA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA1C CPY
    cpu.compareY(0x11u);
    goto L_B1AA1E;
L_B1AA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA1E BEQ -> $B1AA28
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA28; }
    goto L_B1AA20;
L_B1AA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA20 CPY
    cpu.compareY(0xA2u);
    goto L_B1AA22;
L_B1AA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA22 BEQ -> $B1AA28
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA28; }
    goto L_B1AA24;
L_B1AA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA24u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA24 CPY
    cpu.compareY(0xDu);
    goto L_B1AA26;
L_B1AA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA26u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA26 BNE -> $B1AA2A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1AA2A; }
    goto L_B1AA28;
L_B1AA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA28u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA28 LDA
    cpu.setA(0xFFu, 8);
    goto L_B1AA2A;
L_B1AA2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Au, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA2A STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B1AA2D;
L_B1AA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA2D LDA
    cpu.setA(0x9u, 8);
    goto L_B1AA2F;
L_B1AA2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Fu, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AA2F STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1AA32;
L_B1AA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA32u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA32u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1AA32 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1AA32u);return;} hw.unresolvedReturn(0xB1AA32u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

