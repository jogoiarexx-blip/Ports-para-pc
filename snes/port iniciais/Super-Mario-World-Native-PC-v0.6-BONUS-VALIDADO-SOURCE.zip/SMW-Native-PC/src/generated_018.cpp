#include "generated.hpp"
void sub_0087AD_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0087ADu: goto L_0087AD;
    case 0x0087AFu: goto L_0087AF;
    case 0x0087B2u: goto L_0087B2;
    case 0x0087B4u: goto L_0087B4;
    case 0x0087B7u: goto L_0087B7;
    case 0x0087B9u: goto L_0087B9;
    case 0x0087BBu: goto L_0087BB;
    case 0x0087BDu: goto L_0087BD;
    case 0x0087C0u: goto L_0087C0;
    case 0x0087C2u: goto L_0087C2;
    case 0x0087C5u: goto L_0087C5;
    case 0x0087C8u: goto L_0087C8;
    case 0x0087CBu: goto L_0087CB;
    case 0x0087CEu: goto L_0087CE;
    case 0x0087D1u: goto L_0087D1;
    case 0x0087D3u: goto L_0087D3;
    case 0x0087D6u: goto L_0087D6;
    case 0x0087D9u: goto L_0087D9;
    case 0x0087DAu: goto L_0087DA;
    case 0x0087DCu: goto L_0087DC;
    case 0x0087DEu: goto L_0087DE;
    case 0x0087E1u: goto L_0087E1;
    case 0x0087E4u: goto L_0087E4;
    case 0x0087E7u: goto L_0087E7;
    case 0x0087EAu: goto L_0087EA;
    case 0x0087EDu: goto L_0087ED;
    case 0x0087EEu: goto L_0087EE;
    case 0x0087F0u: goto L_0087F0;
    case 0x0087F3u: goto L_0087F3;
    case 0x0087F5u: goto L_0087F5;
    case 0x0087F8u: goto L_0087F8;
    case 0x0087FBu: goto L_0087FB;
    case 0x0087FCu: goto L_0087FC;
    case 0x0087FEu: goto L_0087FE;
    case 0x008800u: goto L_008800;
    case 0x008803u: goto L_008803;
    case 0x008806u: goto L_008806;
    case 0x008809u: goto L_008809;
    case 0x00880Au: goto L_00880A;
    case 0x00880Du: goto L_00880D;
    case 0x008810u: goto L_008810;
    case 0x008813u: goto L_008813;
    case 0x008815u: goto L_008815;
    case 0x008818u: goto L_008818;
    case 0x00881Bu: goto L_00881B;
    case 0x00881Cu: goto L_00881C;
    case 0x00881Eu: goto L_00881E;
    case 0x008820u: goto L_008820;
    case 0x008823u: goto L_008823;
    case 0x008826u: goto L_008826;
    case 0x008829u: goto L_008829;
    case 0x00882Au: goto L_00882A;
    case 0x00882Du: goto L_00882D;
    case 0x008830u: goto L_008830;
    case 0x008831u: goto L_008831;
    case 0x008833u: goto L_008833;
    case 0x008836u: goto L_008836;
    case 0x008838u: goto L_008838;
    case 0x00883Bu: goto L_00883B;
    case 0x00883Eu: goto L_00883E;
    case 0x00883Fu: goto L_00883F;
    case 0x008841u: goto L_008841;
    case 0x008843u: goto L_008843;
    case 0x008846u: goto L_008846;
    case 0x008849u: goto L_008849;
    case 0x00884Bu: goto L_00884B;
    case 0x00884Eu: goto L_00884E;
    case 0x008851u: goto L_008851;
    case 0x008854u: goto L_008854;
    case 0x008857u: goto L_008857;
    case 0x00885Au: goto L_00885A;
    case 0x00885Cu: goto L_00885C;
    case 0x00885Fu: goto L_00885F;
    case 0x008862u: goto L_008862;
    case 0x008863u: goto L_008863;
    case 0x008865u: goto L_008865;
    case 0x008867u: goto L_008867;
    case 0x00886Au: goto L_00886A;
    case 0x00886Du: goto L_00886D;
    case 0x008870u: goto L_008870;
    case 0x008873u: goto L_008873;
    case 0x008876u: goto L_008876;
    case 0x008877u: goto L_008877;
    case 0x008879u: goto L_008879;
    case 0x00887Cu: goto L_00887C;
    case 0x00887Eu: goto L_00887E;
    case 0x008881u: goto L_008881;
    case 0x008884u: goto L_008884;
    case 0x008885u: goto L_008885;
    case 0x008887u: goto L_008887;
    case 0x008889u: goto L_008889;
    case 0x00888Cu: goto L_00888C;
    case 0x00888Eu: goto L_00888E;
    case 0x008891u: goto L_008891;
    case 0x008894u: goto L_008894;
    case 0x008897u: goto L_008897;
    case 0x008898u: goto L_008898;
    case 0x00889Au: goto L_00889A;
    case 0x00889Du: goto L_00889D;
    case 0x0088A0u: goto L_0088A0;
    case 0x0088A3u: goto L_0088A3;
    case 0x0088A5u: goto L_0088A5;
    case 0x0088A8u: goto L_0088A8;
    case 0x0088ABu: goto L_0088AB;
    case 0x0088ACu: goto L_0088AC;
    case 0x0088AEu: goto L_0088AE;
    case 0x0088B0u: goto L_0088B0;
    case 0x0088B3u: goto L_0088B3;
    case 0x0088B6u: goto L_0088B6;
    case 0x0088B9u: goto L_0088B9;
    case 0x0088BAu: goto L_0088BA;
    case 0x0088BCu: goto L_0088BC;
    case 0x0088BFu: goto L_0088BF;
    case 0x0088C2u: goto L_0088C2;
    case 0x0088C3u: goto L_0088C3;
    case 0x0088C5u: goto L_0088C5;
    case 0x0088C8u: goto L_0088C8;
    case 0x0088CAu: goto L_0088CA;
    case 0x0088CDu: goto L_0088CD;
    case 0x0088D0u: goto L_0088D0;
    case 0x0088D1u: goto L_0088D1;
    case 0x0088D3u: goto L_0088D3;
    case 0x0088D5u: goto L_0088D5;
    case 0x0088D8u: goto L_0088D8;
    case 0x0088DAu: goto L_0088DA;
    case 0x0088DDu: goto L_0088DD;
    case 0x0088DFu: goto L_0088DF;
    case 0x0088E2u: goto L_0088E2;
    case 0x0088E5u: goto L_0088E5;
    case 0x0088E7u: goto L_0088E7;
    case 0x0088EAu: goto L_0088EA;
    case 0x0088ECu: goto L_0088EC;
    case 0x0088EEu: goto L_0088EE;
    case 0x0088F0u: goto L_0088F0;
    case 0x0088F3u: goto L_0088F3;
    case 0x0088F5u: goto L_0088F5;
    case 0x0088F8u: goto L_0088F8;
    case 0x0088FBu: goto L_0088FB;
    case 0x0088FEu: goto L_0088FE;
    case 0x008901u: goto L_008901;
    case 0x008904u: goto L_008904;
    case 0x008906u: goto L_008906;
    case 0x008909u: goto L_008909;
    case 0x00890Cu: goto L_00890C;
    case 0x00890Du: goto L_00890D;
    case 0x00890Fu: goto L_00890F;
    case 0x008911u: goto L_008911;
    case 0x008914u: goto L_008914;
    case 0x008917u: goto L_008917;
    case 0x00891Au: goto L_00891A;
    case 0x00891Du: goto L_00891D;
    case 0x008920u: goto L_008920;
    case 0x008921u: goto L_008921;
    case 0x008923u: goto L_008923;
    case 0x008926u: goto L_008926;
    case 0x008928u: goto L_008928;
    case 0x00892Bu: goto L_00892B;
    case 0x00892Eu: goto L_00892E;
    case 0x00892Fu: goto L_00892F;
    case 0x008931u: goto L_008931;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0087AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087AD SEP
    cpu.sep(0x30u);
    goto L_0087AF;
L_0087AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087AF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087B2;
L_0087B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087B2 BNE -> $0087B7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0087B7; }
    goto L_0087B4;
L_0087B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u, 3u, 3u, cpu.address("abs", 0x88DDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087B4 JMP -> $0088DD
    goto L_0088DD;
L_0087B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087B9;
L_0087B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087B9 AND
    cpu.logicAnd(0x1u);
    goto L_0087BB;
L_0087BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087BB BEQ -> $0087C0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0087C0; }
    goto L_0087BD;
L_0087BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu, 3u, 3u, cpu.address("abs", 0x8849u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087BD JMP -> $008849
    goto L_008849;
L_0087C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087C0 LDY
    cpu.setY(0x81u, 8);
    goto L_0087C2;
L_0087C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C2u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C2u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087C2 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_0087C5;
L_0087C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C5u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087C5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087C8;
L_0087C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087C8 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0087CB;
L_0087CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087CB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087CE;
L_0087CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CEu, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087CE STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_0087D1;
L_0087D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087D1 LDX
    cpu.setX(0x6u, 8);
    goto L_0087D3;
L_0087D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u, 4u + ((((0x8A16u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087D3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087D6;
L_0087D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087D6 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_0087D9;
L_0087D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D9u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087D9 DEX
    cpu.decReg('X');
    goto L_0087DA;
L_0087DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087DA BPL -> $0087D3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0087D3; }
    goto L_0087DC;
L_0087DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087DC LDA
    cpu.setA(0x2u, 8);
    goto L_0087DE;
L_0087DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DEu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087DE STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_0087E1;
L_0087E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E1u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E1u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087E1 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_0087E4;
L_0087E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E4u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087E4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087E7;
L_0087E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087E7 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0087EA;
L_0087EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EAu, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087EA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087ED;
L_0087ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087ED CLC
    cpu.setFlag('C', false);
    goto L_0087EE;
L_0087EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087EE ADC
    cpu.adc(0x8u);
    goto L_0087F0;
L_0087F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F0u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087F0 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_0087F3;
L_0087F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087F3 LDX
    cpu.setX(0x6u, 8);
    goto L_0087F5;
L_0087F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F5u, 4u + ((((0x8A1Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087F5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A1Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087F8;
L_0087F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F8u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087F8 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_0087FB;
L_0087FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087FB DEX
    cpu.decReg('X');
    goto L_0087FC;
L_0087FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087FC BPL -> $0087F5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0087F5; }
    goto L_0087FE;
L_0087FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087FE LDA
    cpu.setA(0x2u, 8);
    goto L_008800;
L_008800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8800u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8800u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8800u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008800 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008803;
L_008803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8803u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8803u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8803u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008803 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_008806;
L_008806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008806 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008809;
L_008809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8809u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8809u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008809 INC
    cpu.inc('A');
    goto L_00880A;
L_00880A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00880A STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00880D;
L_00880D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Du, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00880D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008810;
L_008810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8810u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8810u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8810u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008810 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008813;
L_008813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008813 LDX
    cpu.setX(0x6u, 8);
    goto L_008815;
L_008815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8815u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8815u, 4u + ((((0x8A24u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008815 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008818;
L_008818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008818 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_00881B;
L_00881B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00881B DEX
    cpu.decReg('X');
    goto L_00881C;
L_00881C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00881C BPL -> $008815
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008815; }
    goto L_00881E;
L_00881E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00881E LDA
    cpu.setA(0x2u, 8);
    goto L_008820;
L_008820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8820u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8820u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008820 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008823;
L_008823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8823u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8823u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008823 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_008826;
L_008826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8826u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008826 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008829;
L_008829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8829u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8829u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008829 INC
    cpu.inc('A');
    goto L_00882A;
L_00882A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Au, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00882A STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00882D;
L_00882D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Du, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00882D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008830;
L_008830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008830 CLC
    cpu.setFlag('C', false);
    goto L_008831;
L_008831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8831u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8831u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008831 ADC
    cpu.adc(0x8u);
    goto L_008833;
L_008833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8833u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8833u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008833 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008836;
L_008836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8836u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8836u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008836 LDX
    cpu.setX(0x6u, 8);
    goto L_008838;
L_008838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8838u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8838u, 4u + ((((0x8A2Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A2Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008838 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A2Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00883B;
L_00883B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Bu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00883B STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_00883E;
L_00883E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00883E DEX
    cpu.decReg('X');
    goto L_00883F;
L_00883F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00883F BPL -> $008838
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008838; }
    goto L_008841;
L_008841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8841u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008841 LDA
    cpu.setA(0x2u, 8);
    goto L_008843;
L_008843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008843 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008846;
L_008846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u, 3u, 3u, cpu.address("abs", 0x88DDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008846 JMP -> $0088DD
    goto L_0088DD;
L_008849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8849u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8849u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008849 LDY
    cpu.setY(0x80u, 8);
    goto L_00884B;
L_00884B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Bu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Bu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00884B STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_00884E;
L_00884E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00884E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008851;
L_008851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8851u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8851u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008851 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008854;
L_008854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008854 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008857;
L_008857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008857 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_00885A;
L_00885A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00885A LDX
    cpu.setX(0x6u, 8);
    goto L_00885C;
L_00885C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Cu, 4u + ((((0x8A16u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00885C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00885F;
L_00885F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Fu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00885F STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008862;
L_008862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8862u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8862u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008862 DEX
    cpu.decReg('X');
    goto L_008863;
L_008863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8863u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8863u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008863 BPL -> $00885C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00885C; }
    goto L_008865;
L_008865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8865u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8865u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008865 LDA
    cpu.setA(0x2u, 8);
    goto L_008867;
L_008867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8867u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8867u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008867 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_00886A;
L_00886A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Au, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00886A STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_00886D;
L_00886D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00886D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008870;
L_008870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8870u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8870u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008870 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008873;
L_008873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8873u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8873u, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008873 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008876;
L_008876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8876u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8876u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008876 CLC
    cpu.setFlag('C', false);
    goto L_008877;
L_008877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8877u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8877u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8877u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008877 ADC
    cpu.adc(0x4u);
    goto L_008879;
L_008879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8879u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8879u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008879 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_00887C;
L_00887C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00887C LDX
    cpu.setX(0x6u, 8);
    goto L_00887E;
L_00887E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Eu, 4u + ((((0x8A1Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00887E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A1Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008881;
L_008881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8881u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8881u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008881 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008884;
L_008884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8884u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8884u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008884 DEX
    cpu.decReg('X');
    goto L_008885;
L_008885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8885u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8885u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008885 BPL -> $00887E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00887E; }
    goto L_008887;
L_008887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8887u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8887u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008887 LDA
    cpu.setA(0x40u, 8);
    goto L_008889;
L_008889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8889u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8889u, 4u, 3u, cpu.address("abs", 0x4315u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008889 STA
    hw.write(cpu.address("abs", 0x4315u), cpu.a, cpu.m8?8:16);
    goto L_00888C;
L_00888C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00888C LDA
    cpu.setA(0x2u, 8);
    goto L_00888E;
L_00888E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00888E STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008891;
L_008891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008891 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_008894;
L_008894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8894u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8894u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008894 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008897;
L_008897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8897u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8897u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008897 CLC
    cpu.setFlag('C', false);
    goto L_008898;
L_008898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008898 ADC
    cpu.adc(0x20u);
    goto L_00889A;
L_00889A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Au, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00889A STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00889D;
L_00889D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00889D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088A0;
L_0088A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A0u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088A0 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_0088A3;
L_0088A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088A3 LDX
    cpu.setX(0x6u, 8);
    goto L_0088A5;
L_0088A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A5u, 4u + ((((0x8A24u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088A5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088A8;
L_0088A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088A8 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_0088AB;
L_0088AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ABu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088AB DEX
    cpu.decReg('X');
    goto L_0088AC;
L_0088AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088AC BPL -> $0088A5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0088A5; }
    goto L_0088AE;
L_0088AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088AE LDA
    cpu.setA(0x2u, 8);
    goto L_0088B0;
L_0088B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B0u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088B0 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_0088B3;
L_0088B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B3u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B3u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088B3 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_0088B6;
L_0088B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B6u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088B6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088B9;
L_0088B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088B9 CLC
    cpu.setFlag('C', false);
    goto L_0088BA;
L_0088BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088BA ADC
    cpu.adc(0x20u);
    goto L_0088BC;
L_0088BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088BC STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0088BF;
L_0088BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BFu, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088BF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088C2;
L_0088C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088C2 CLC
    cpu.setFlag('C', false);
    goto L_0088C3;
L_0088C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088C3 ADC
    cpu.adc(0x4u);
    goto L_0088C5;
L_0088C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C5u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088C5 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_0088C8;
L_0088C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088C8 LDX
    cpu.setX(0x6u, 8);
    goto L_0088CA;
L_0088CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CAu, 4u + ((((0x8A2Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A2Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088CA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A2Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088CD;
L_0088CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CDu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088CD STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_0088D0;
L_0088D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088D0 DEX
    cpu.decReg('X');
    goto L_0088D1;
L_0088D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088D1 BPL -> $0088CA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0088CA; }
    goto L_0088D3;
L_0088D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088D3 LDA
    cpu.setA(0x40u, 8);
    goto L_0088D5;
L_0088D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D5u, 4u, 3u, cpu.address("abs", 0x4315u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088D5 STA
    hw.write(cpu.address("abs", 0x4315u), cpu.a, cpu.m8?8:16);
    goto L_0088D8;
L_0088D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088D8 LDA
    cpu.setA(0x2u, 8);
    goto L_0088DA;
L_0088DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DAu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088DA STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_0088DD;
L_0088DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088DD LDA
    cpu.setA(0x0u, 8);
    goto L_0088DF;
L_0088DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088DF STA
    hw.write(cpu.address("abs", 0x1BE4u), cpu.a, cpu.m8?8:16);
    goto L_0088E2;
L_0088E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u, 4u, 3u, cpu.address("abs", 0x1CE6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088E2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088E5;
L_0088E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088E5 BNE -> $0088EA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0088EA; }
    goto L_0088E7;
L_0088E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E7u, 3u, 3u, cpu.address("abs", 0x8A10u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088E7 JMP -> $008A10
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8A10u),0x0088E7u); return;
L_0088EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088EA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088EC;
L_0088EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ECu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088EC AND
    cpu.logicAnd(0x2u);
    goto L_0088EE;
L_0088EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088EE BEQ -> $0088F3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0088F3; }
    goto L_0088F0;
L_0088F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F0u, 3u, 3u, cpu.address("abs", 0x897Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088F0 JMP -> $00897C
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x897Cu),0x0088F0u); return;
L_0088F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088F3 LDY
    cpu.setY(0x81u, 8);
    goto L_0088F5;
L_0088F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088F5 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_0088F8;
L_0088F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F8u, 4u, 3u, cpu.address("abs", 0x1CE7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088F8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088FB;
L_0088FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088FB STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0088FE;
L_0088FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FEu, 4u, 3u, cpu.address("abs", 0x1CE6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008901;
L_008901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8901u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8901u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008901 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008904;
L_008904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008904 LDX
    cpu.setX(0x6u, 8);
    goto L_008906;
L_008906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u, 4u + ((((0x8A32u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008906 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A32u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008909;
L_008909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8909u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8909u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008909 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_00890C;
L_00890C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00890C DEX
    cpu.decReg('X');
    goto L_00890D;
L_00890D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00890D BPL -> $008906
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008906; }
    goto L_00890F;
L_00890F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00890F LDA
    cpu.setA(0x2u, 8);
    goto L_008911;
L_008911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8911u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8911u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008911 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008914;
L_008914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8914u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8914u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8914u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008914 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_008917;
L_008917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8917u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8917u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8917u, 4u, 3u, cpu.address("abs", 0x1CE7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008917 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00891A;
L_00891A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x891Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x891Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x891Au, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00891A STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00891D;
L_00891D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x891Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x891Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x891Du, 4u, 3u, cpu.address("abs", 0x1CE6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00891D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008920;
L_008920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8920u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8920u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008920 CLC
    cpu.setFlag('C', false);
    goto L_008921;
L_008921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8921u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8921u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008921 ADC
    cpu.adc(0x8u);
    goto L_008923;
L_008923:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8923u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8923u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8923u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008923 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008926;
L_008926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8926u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8926u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008926 LDX
    cpu.setX(0x6u, 8);
    goto L_008928;
L_008928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8928u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8928u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8928u, 4u + ((((0x8A39u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A39u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008928 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A39u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00892B;
L_00892B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x892Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x892Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x892Bu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00892B STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_00892E;
L_00892E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x892Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x892Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x892Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00892E DEX
    cpu.decReg('X');
    goto L_00892F;
L_00892F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x892Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x892Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x892Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00892F BPL -> $008928
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008928; }
    goto L_008931;
L_008931:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8931u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8931u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8931u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008931 LDA
    cpu.setA(0x2u, 8);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8933u,0x008931u); return;
}

void sub_009440_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009440u: goto L_009440;
    case 0x009443u: goto L_009443;
    case 0x009446u: goto L_009446;
    case 0x009448u: goto L_009448;
    case 0x00944Au: goto L_00944A;
    case 0x00944Cu: goto L_00944C;
    case 0x00944Eu: goto L_00944E;
    case 0x00CA88u: goto L_00CA88;
    case 0x00CA8Au: goto L_00CA8A;
    case 0x00CA8Du: goto L_00CA8D;
    case 0x00CA8Eu: goto L_00CA8E;
    case 0x00CA8Fu: goto L_00CA8F;
    case 0x00CA90u: goto L_00CA90;
    case 0x00CA91u: goto L_00CA91;
    case 0x00CA93u: goto L_00CA93;
    case 0x00CA96u: goto L_00CA96;
    case 0x00CA98u: goto L_00CA98;
    case 0x00CA9Bu: goto L_00CA9B;
    case 0x00CA9Du: goto L_00CA9D;
    case 0x00CA9Fu: goto L_00CA9F;
    case 0x00CAA2u: goto L_00CAA2;
    case 0x00CAA5u: goto L_00CAA5;
    case 0x00CAA8u: goto L_00CAA8;
    case 0x00CAAAu: goto L_00CAAA;
    case 0x00CAADu: goto L_00CAAD;
    case 0x00CAAEu: goto L_00CAAE;
    case 0x00CAB1u: goto L_00CAB1;
    case 0x00CAB2u: goto L_00CAB2;
    case 0x00CAB3u: goto L_00CAB3;
    case 0x00CAB4u: goto L_00CAB4;
    case 0x00CAB5u: goto L_00CAB5;
    case 0x00CAB7u: goto L_00CAB7;
    case 0x00CAB9u: goto L_00CAB9;
    case 0x00CABBu: goto L_00CABB;
    case 0x00CABDu: goto L_00CABD;
    case 0x00CAC0u: goto L_00CAC0;
    case 0x00CAC1u: goto L_00CAC1;
    case 0x00CAC3u: goto L_00CAC3;
    case 0x00CAC5u: goto L_00CAC5;
    case 0x00CAC7u: goto L_00CAC7;
    case 0x00CACAu: goto L_00CACA;
    case 0x00CACCu: goto L_00CACC;
    case 0x00CACDu: goto L_00CACD;
    case 0x00CACFu: goto L_00CACF;
    case 0x00CAD1u: goto L_00CAD1;
    case 0x00CAD3u: goto L_00CAD3;
    case 0x00CAD6u: goto L_00CAD6;
    case 0x00CAD9u: goto L_00CAD9;
    case 0x00CADBu: goto L_00CADB;
    case 0x00CADDu: goto L_00CADD;
    case 0x00CADFu: goto L_00CADF;
    case 0x00CAE1u: goto L_00CAE1;
    case 0x00CAE4u: goto L_00CAE4;
    case 0x00CAE5u: goto L_00CAE5;
    case 0x00CAE7u: goto L_00CAE7;
    case 0x00CAE9u: goto L_00CAE9;
    case 0x00CAEBu: goto L_00CAEB;
    case 0x00CAEDu: goto L_00CAED;
    case 0x00CAEFu: goto L_00CAEF;
    case 0x00CAF2u: goto L_00CAF2;
    case 0x00CAF4u: goto L_00CAF4;
    case 0x00CAF5u: goto L_00CAF5;
    case 0x00CAF7u: goto L_00CAF7;
    case 0x00CAF9u: goto L_00CAF9;
    case 0x00CAFBu: goto L_00CAFB;
    case 0x00CAFEu: goto L_00CAFE;
    case 0x00CAFFu: goto L_00CAFF;
    case 0x00CB00u: goto L_00CB00;
    case 0x00CB01u: goto L_00CB01;
    case 0x00CB02u: goto L_00CB02;
    case 0x00CB04u: goto L_00CB04;
    case 0x00CB06u: goto L_00CB06;
    case 0x00CB08u: goto L_00CB08;
    case 0x00CB0Au: goto L_00CB0A;
    case 0x00CB0Cu: goto L_00CB0C;
    case 0x00CB0Fu: goto L_00CB0F;
    case 0x00CB11u: goto L_00CB11;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9440u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9440u, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009440 STA
    hw.write(cpu.address("abs", 0x1433u), cpu.a, cpu.m8?8:16);
    goto L_009443;
L_009443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9443u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9443u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9443u, 6u, 3u, cpu.address("abs", 0xCA61u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009443 JSR -> $00CA61 stack real
    { cpu.push16Value(hw,0x9445u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9446u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA61u), 0x009443u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009446;
L_009446:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9446u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9446u,0x009446u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9446u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9446u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009446 LDA
    cpu.setA(0x80u, 8);
    goto L_009448;
L_009448:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9448u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9448u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9448u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009448 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00944A;
L_00944A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x944Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x944Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x944Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00944A LDA
    cpu.setA(0x70u, 8);
    goto L_00944C;
L_00944C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x944Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x944Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x944Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00944C STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_00944E;
L_00944E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x944Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x944Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x944Eu, 3u, 3u, cpu.address("abs", 0xCA88u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00944E JMP -> $00CA88
    goto L_00CA88;
L_00CA88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA88u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA88u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA88 REP
    cpu.rep(0x30u);
    goto L_00CA8A;
L_00CA8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA8A AND
    cpu.logicAnd(0xFFu);
    goto L_00CA8D;
L_00CA8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA8D ASL
    cpu.aslA();
    goto L_00CA8E;
L_00CA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Eu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA8E DEC
    cpu.decReg('A');
    goto L_00CA8F;
L_00CA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA8F ASL
    cpu.aslA();
    goto L_00CA90;
L_00CA90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA90u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA90u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA90 TAY
    cpu.transfer("TAY");
    goto L_00CA91;
L_00CA91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA91u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA91u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA91 SEP
    cpu.sep(0x20u);
    goto L_00CA93;
L_00CA93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA93u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA93u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA93 LDX
    cpu.setX(0x0u, 16);
    goto L_00CA96;
L_00CA96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA96u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA96u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA96 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CA98;
L_00CA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA98u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA98u, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA98 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1433u), cpu.m8?8:16));
    goto L_00CA9B;
L_00CA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA9B BCC -> $00CABD
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CABD; }
    goto L_00CA9D;
L_00CA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA9D LDA
    cpu.setA(0xFFu, 8);
    goto L_00CA9F;
L_00CA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Fu, 5u, 3u, cpu.address("absx", 0x04A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA9F STA
    hw.write(cpu.address("absx", 0x4A0u), cpu.a, cpu.m8?8:16);
    goto L_00CAA2;
L_00CAA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA2u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA2u, 5u, 3u, cpu.address("absx", 0x04A1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAA2 STZ
    hw.write(cpu.address("absx", 0x4A1u), 0, cpu.m8?8:16);
    goto L_00CAA5;
L_00CAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA5u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAA5 CPY
    cpu.compareY(0x1C0u);
    goto L_00CAA8;
L_00CAA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAA8 BCS -> $00CAB1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CAB1; }
    goto L_00CAAA;
L_00CAAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAAu, 5u, 3u, cpu.address("absy", 0x04A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAAA STA
    hw.write(cpu.address("absy", 0x4A0u), cpu.a, cpu.m8?8:16);
    goto L_00CAAD;
L_00CAAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAADu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAAD INC
    cpu.inc('A');
    goto L_00CAAE;
L_00CAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAEu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAEu, 5u, 3u, cpu.address("absy", 0x04A1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAAE STA
    hw.write(cpu.address("absy", 0x4A1u), cpu.a, cpu.m8?8:16);
    goto L_00CAB1;
L_00CAB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAB1 INX
    cpu.inc('X');
    goto L_00CAB2;
L_00CAB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAB2 INX
    cpu.inc('X');
    goto L_00CAB3;
L_00CAB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAB3 DEY
    cpu.decReg('Y');
    goto L_00CAB4;
L_00CAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB4u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAB4 DEY
    cpu.decReg('Y');
    goto L_00CAB5;
L_00CAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAB5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CAB7;
L_00CAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAB7 BEQ -> $00CB0A
    if (cpu.z) { hw.addCpuInternalCycles(2u); goto L_00CB0A; }
    goto L_00CAB9;
L_00CAB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB9u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAB9 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_00CABB;
L_00CABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABBu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CABB BRA -> $00CA96
    goto L_00CA96;
L_00CABD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABDu, 6u, 3u, cpu.address("abs", 0xCC14u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CABD JSR -> $00CC14 stack real
    { cpu.push16Value(hw,0xCABFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAC0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCC14u), 0x00CABDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CAC0;
L_00CAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC0u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAC0u,0x00CAC0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAC0 CLC
    cpu.setFlag('C', false);
    goto L_00CAC1;
L_00CAC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC1u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAC1 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_00CAC3;
L_00CAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAC3 BCC -> $00CAC7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CAC7; }
    goto L_00CAC5;
L_00CAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAC5 LDA
    cpu.setA(0xFFu, 8);
    goto L_00CAC7;
L_00CAC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC7u, 5u, 3u, cpu.address("absx", 0x04A1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAC7 STA
    hw.write(cpu.address("absx", 0x4A1u), cpu.a, cpu.m8?8:16);
    goto L_00CACA;
L_00CACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CACA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CACC;
L_00CACC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACCu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CACC SEC
    cpu.setFlag('C', true);
    goto L_00CACD;
L_00CACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CACD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_00CACF;
L_00CACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACFu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CACF BCS -> $00CAD3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CAD3; }
    goto L_00CAD1;
L_00CAD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAD1 LDA
    cpu.setA(0x0u, 8);
    goto L_00CAD3;
L_00CAD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD3u, 5u, 3u, cpu.address("absx", 0x04A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAD3 STA
    hw.write(cpu.address("absx", 0x4A0u), cpu.a, cpu.m8?8:16);
    goto L_00CAD6;
L_00CAD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD6u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAD6 CPY
    cpu.compareY(0x1E0u);
    goto L_00CAD9;
L_00CAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD9u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAD9 BCS -> $00CAFE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CAFE; }
    goto L_00CADB;
L_00CADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCADBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCADBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CADB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CADD;
L_00CADD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCADDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCADDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCADDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CADD BNE -> $00CAE7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CAE7; }
    goto L_00CADF;
L_00CADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCADFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCADFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CADF LDA
    cpu.setA(0x0u, 8);
    goto L_00CAE1;
L_00CAE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE1u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE1u, 5u, 3u, cpu.address("absy", 0x04A1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAE1 STA
    hw.write(cpu.address("absy", 0x4A1u), cpu.a, cpu.m8?8:16);
    goto L_00CAE4;
L_00CAE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE4u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAE4 DEC
    cpu.decReg('A');
    goto L_00CAE5;
L_00CAE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAE5 BRA -> $00CAFB
    goto L_00CAFB;
L_00CAE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAE7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CAE9;
L_00CAE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE9u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAE9 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_00CAEB;
L_00CAEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAEB BCC -> $00CAEF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CAEF; }
    goto L_00CAED;
L_00CAED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAED LDA
    cpu.setA(0xFFu, 8);
    goto L_00CAEF;
L_00CAEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEFu, 5u, 3u, cpu.address("absy", 0x04A1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAEF STA
    hw.write(cpu.address("absy", 0x4A1u), cpu.a, cpu.m8?8:16);
    goto L_00CAF2;
L_00CAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CAF4;
L_00CAF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAF4 SEC
    cpu.setFlag('C', true);
    goto L_00CAF5;
L_00CAF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAF5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_00CAF7;
L_00CAF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF7u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAF7 BCS -> $00CAFB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CAFB; }
    goto L_00CAF9;
L_00CAF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAF9 LDA
    cpu.setA(0x0u, 8);
    goto L_00CAFB;
L_00CAFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFBu, 5u, 3u, cpu.address("absy", 0x04A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAFB STA
    hw.write(cpu.address("absy", 0x4A0u), cpu.a, cpu.m8?8:16);
    goto L_00CAFE;
L_00CAFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAFE INX
    cpu.inc('X');
    goto L_00CAFF;
L_00CAFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CAFF INX
    cpu.inc('X');
    goto L_00CB00;
L_00CB00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB00u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB00u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CB00 DEY
    cpu.decReg('Y');
    goto L_00CB01;
L_00CB01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB01u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB01u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CB01 DEY
    cpu.decReg('Y');
    goto L_00CB02;
L_00CB02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB02u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB02u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CB02 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CB04;
L_00CB04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB04u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CB04 BEQ -> $00CB0A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CB0A; }
    goto L_00CB06;
L_00CB06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB06u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB06u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CB06 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_00CB08;
L_00CB08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB08u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CB08 BNE -> $00CABD
    if (!cpu.z) { hw.addCpuInternalCycles(2u); goto L_00CABD; }
    goto L_00CB0A;
L_00CB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CB0A LDA
    cpu.setA(0x80u, 8);
    goto L_00CB0C;
L_00CB0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Cu, 4u, 3u, cpu.address("abs", 0x0D9Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CB0C STA
    hw.write(cpu.address("abs", 0xD9Fu), cpu.a, cpu.m8?8:16);
    goto L_00CB0F;
L_00CB0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CB0F SEP
    cpu.sep(0x10u);
    goto L_00CB11;
L_00CB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB11u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB11u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CB11 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CB11u);return;} hw.unresolvedReturn(0x00CB11u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00AE15_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00AE15u: goto L_00AE15;
    case 0x00AE17u: goto L_00AE17;
    case 0x00AE1Au: goto L_00AE1A;
    case 0x00AE1Cu: goto L_00AE1C;
    case 0x00AE1Fu: goto L_00AE1F;
    case 0x00AE22u: goto L_00AE22;
    case 0x00AE24u: goto L_00AE24;
    case 0x00AE27u: goto L_00AE27;
    case 0x00AE2Au: goto L_00AE2A;
    case 0x00AE2Du: goto L_00AE2D;
    case 0x00AE2Fu: goto L_00AE2F;
    case 0x00AE32u: goto L_00AE32;
    case 0x00AE34u: goto L_00AE34;
    case 0x00AE37u: goto L_00AE37;
    case 0x00AE39u: goto L_00AE39;
    case 0x00AE3Bu: goto L_00AE3B;
    case 0x00AE3Eu: goto L_00AE3E;
    case 0x00AE40u: goto L_00AE40;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00AE15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE15u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE15u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE15 LDA
    cpu.setA(0x2u, 8);
    goto L_00AE17;
L_00AE17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE17u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE17u, 4u, 3u, cpu.address("abs", 0x192Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE17 STA
    hw.write(cpu.address("abs", 0x192Eu), cpu.a, cpu.m8?8:16);
    goto L_00AE1A;
L_00AE1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE1A LDA
    cpu.setA(0x7u, 8);
    goto L_00AE1C;
L_00AE1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Cu, 4u, 3u, cpu.address("abs", 0x192Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE1C STA
    hw.write(cpu.address("abs", 0x192Du), cpu.a, cpu.m8?8:16);
    goto L_00AE1F;
L_00AE1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Fu, 6u, 3u, cpu.address("abs", 0xABEDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AE1F JSR -> $00ABED stack real
    { cpu.push16Value(hw,0xAE21u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE22u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABEDu), 0x00AE1Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AE22;
L_00AE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE22u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE22u,0x00AE22u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE22u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE22u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE22 REP
    cpu.rep(0x30u);
    goto L_00AE24;
L_00AE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE24u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE24 LDA
    cpu.setA(0x17u, 16);
    goto L_00AE27;
L_00AE27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE27u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE27u, 5u, 3u, cpu.address("abs", 0x0701u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE27 STA
    hw.write(cpu.address("abs", 0x701u), cpu.a, cpu.m8?8:16);
    goto L_00AE2A;
L_00AE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE2A LDA
    cpu.setA(0xB5F4u, 16);
    goto L_00AE2D;
L_00AE2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE2D STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00AE2F;
L_00AE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE2F LDA
    cpu.setA(0x18u, 16);
    goto L_00AE32;
L_00AE32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE32u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE32u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE32 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00AE34;
L_00AE34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE34u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE34 LDA
    cpu.setA(0x3u, 16);
    goto L_00AE37;
L_00AE37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE37u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE37u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE37 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_00AE39;
L_00AE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE39 STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_00AE3B;
L_00AE3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Bu, 6u, 3u, cpu.address("abs", 0xACFFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AE3B JSR -> $00ACFF stack real
    { cpu.push16Value(hw,0xAE3Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE3Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACFFu), 0x00AE3Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AE3E;
L_00AE3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE3Eu,0x00AE3Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE3E SEP
    cpu.sep(0x30u);
    goto L_00AE40;
L_00AE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AE40 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00AE40u);return;} hw.unresolvedReturn(0x00AE40u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00AE15_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00AE15u: goto L_00AE15;
    case 0x00AE17u: goto L_00AE17;
    case 0x00AE1Au: goto L_00AE1A;
    case 0x00AE1Cu: goto L_00AE1C;
    case 0x00AE1Fu: goto L_00AE1F;
    case 0x00AE22u: goto L_00AE22;
    case 0x00AE24u: goto L_00AE24;
    case 0x00AE27u: goto L_00AE27;
    case 0x00AE2Au: goto L_00AE2A;
    case 0x00AE2Du: goto L_00AE2D;
    case 0x00AE2Fu: goto L_00AE2F;
    case 0x00AE32u: goto L_00AE32;
    case 0x00AE34u: goto L_00AE34;
    case 0x00AE37u: goto L_00AE37;
    case 0x00AE39u: goto L_00AE39;
    case 0x00AE3Bu: goto L_00AE3B;
    case 0x00AE3Eu: goto L_00AE3E;
    case 0x00AE40u: goto L_00AE40;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00AE15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE15u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE15u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE15 LDA
    cpu.setA(0x2u, 8);
    goto L_00AE17;
L_00AE17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE17u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE17u, 4u, 3u, cpu.address("abs", 0x192Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE17 STA
    hw.write(cpu.address("abs", 0x192Eu), cpu.a, cpu.m8?8:16);
    goto L_00AE1A;
L_00AE1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE1A LDA
    cpu.setA(0x7u, 8);
    goto L_00AE1C;
L_00AE1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Cu, 4u, 3u, cpu.address("abs", 0x192Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE1C STA
    hw.write(cpu.address("abs", 0x192Du), cpu.a, cpu.m8?8:16);
    goto L_00AE1F;
L_00AE1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Fu, 6u, 3u, cpu.address("abs", 0xABEDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AE1F JSR -> $00ABED stack real
    { cpu.push16Value(hw,0xAE21u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE22u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABEDu), 0x00AE1Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AE22;
L_00AE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE22u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE22u,0x00AE22u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE22u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE22u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE22 REP
    cpu.rep(0x30u);
    goto L_00AE24;
L_00AE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE24u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE24 LDA
    cpu.setA(0x17u, 16);
    goto L_00AE27;
L_00AE27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE27u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE27u, 5u, 3u, cpu.address("abs", 0x0701u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE27 STA
    hw.write(cpu.address("abs", 0x701u), cpu.a, cpu.m8?8:16);
    goto L_00AE2A;
L_00AE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE2A LDA
    cpu.setA(0xB5F4u, 16);
    goto L_00AE2D;
L_00AE2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE2D STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00AE2F;
L_00AE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE2F LDA
    cpu.setA(0x18u, 16);
    goto L_00AE32;
L_00AE32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE32u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE32u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE32 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00AE34;
L_00AE34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE34u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE34 LDA
    cpu.setA(0x3u, 16);
    goto L_00AE37;
L_00AE37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE37u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE37u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE37 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_00AE39;
L_00AE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE39 STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_00AE3B;
L_00AE3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Bu, 6u, 3u, cpu.address("abs", 0xACFFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AE3B JSR -> $00ACFF stack real
    { cpu.push16Value(hw,0xAE3Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE3Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACFFu), 0x00AE3Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AE3E;
L_00AE3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE3Eu,0x00AE3Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AE3E SEP
    cpu.sep(0x30u);
    goto L_00AE40;
L_00AE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AE40 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00AE40u);return;} hw.unresolvedReturn(0x00AE40u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CA61_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CA61u: goto L_00CA61;
    case 0x00CA63u: goto L_00CA63;
    case 0x00CA66u: goto L_00CA66;
    case 0x00CA68u: goto L_00CA68;
    case 0x00CA6Au: goto L_00CA6A;
    case 0x00CA6Cu: goto L_00CA6C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CA61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA61u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA61u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA61 REP
    cpu.rep(0x20u);
    goto L_00CA63;
L_00CA63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA63u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA63u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA63 LDA
    cpu.setA(0xCB12u, 16);
    goto L_00CA66;
L_00CA66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA66u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA66u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA66 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00CA68;
L_00CA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA68u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA68u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA68 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_00CA6A;
L_00CA6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA6A SEP
    cpu.sep(0x20u);
    goto L_00CA6C;
L_00CA6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA6C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CA6Cu);return;} hw.unresolvedReturn(0x00CA6Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CA61_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CA61u: goto L_00CA61;
    case 0x00CA63u: goto L_00CA63;
    case 0x00CA66u: goto L_00CA66;
    case 0x00CA68u: goto L_00CA68;
    case 0x00CA6Au: goto L_00CA6A;
    case 0x00CA6Cu: goto L_00CA6C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CA61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA61u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA61u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA61 REP
    cpu.rep(0x20u);
    goto L_00CA63;
L_00CA63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA63u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA63u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA63 LDA
    cpu.setA(0xCB12u, 16);
    goto L_00CA66;
L_00CA66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA66u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA66u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA66 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00CA68;
L_00CA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA68u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA68u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA68 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_00CA6A;
L_00CA6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA6A SEP
    cpu.sep(0x20u);
    goto L_00CA6C;
L_00CA6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA6C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CA6Cu);return;} hw.unresolvedReturn(0x00CA6Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00EC21_E0M1X1CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE4Du: goto L_00EE4D;
    case 0x00EE4Eu: goto L_00EE4E;
    case 0x00EE4Fu: goto L_00EE4F;
    case 0x00EE50u: goto L_00EE50;
    case 0x00EE51u: goto L_00EE51;
    case 0x00EE52u: goto L_00EE52;
    case 0x00EE55u: goto L_00EE55;
    case 0x00EE57u: goto L_00EE57;
    case 0x00EE5Au: goto L_00EE5A;
    case 0x00EE5Cu: goto L_00EE5C;
    case 0x00EE5Fu: goto L_00EE5F;
    case 0x00EE61u: goto L_00EE61;
    case 0x00EE62u: goto L_00EE62;
    case 0x00EE63u: goto L_00EE63;
    case 0x00EE64u: goto L_00EE64;
    case 0x00EE65u: goto L_00EE65;
    case 0x00EE67u: goto L_00EE67;
    case 0x00EE68u: goto L_00EE68;
    case 0x00EE69u: goto L_00EE69;
    case 0x00EE6Bu: goto L_00EE6B;
    case 0x00EE6Eu: goto L_00EE6E;
    case 0x00EE70u: goto L_00EE70;
    case 0x00EE72u: goto L_00EE72;
    case 0x00EE73u: goto L_00EE73;
    case 0x00EE76u: goto L_00EE76;
    case 0x00EE77u: goto L_00EE77;
    case 0x00EE78u: goto L_00EE78;
    case 0x00EE79u: goto L_00EE79;
    case 0x00EE7Au: goto L_00EE7A;
    case 0x00EE7Bu: goto L_00EE7B;
    case 0x00EE7Cu: goto L_00EE7C;
    case 0x00EE7Du: goto L_00EE7D;
    case 0x00EE7Fu: goto L_00EE7F;
    case 0x00EE80u: goto L_00EE80;
    case 0x00EE83u: goto L_00EE83;
    case 0x00EE85u: goto L_00EE85;
    case 0x00EE86u: goto L_00EE86;
    case 0x00EE87u: goto L_00EE87;
    case 0x00EE89u: goto L_00EE89;
    case 0x00EE8Bu: goto L_00EE8B;
    case 0x00EE8Du: goto L_00EE8D;
    case 0x00EE8Eu: goto L_00EE8E;
    case 0x00EE8Fu: goto L_00EE8F;
    case 0x00EE92u: goto L_00EE92;
    case 0x00EE94u: goto L_00EE94;
    case 0x00EE95u: goto L_00EE95;
    case 0x00EE96u: goto L_00EE96;
    case 0x00EE98u: goto L_00EE98;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE4Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Du,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE4Fu,true);
    hw.requestDispatch(0x0082C3u,0x00EE4Du);return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Du,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE4Fu,true);
    hw.requestDispatch(0x0082C3u,0x00EE4Du);return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Du,0x00EE4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE4Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE4E BCS -> $00EE57
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EE57; }
    goto L_00EE50;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Eu,0x00EE4Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE4Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Fu,cpu,0x07u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $00EE4F ORA
    cpu.logicOr(hw.readW(cpu.addressDpLong(hw, 0xAu), cpu.m8?8:16));
    goto L_00EE51;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Fu,cpu,0x07u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $00EE4F ORA
    cpu.logicOr(hw.readW(cpu.addressDpLong(hw, 0xAu), cpu.m8?8:16));
    goto L_00EE51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Fu,0x00EE4Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE50u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE50u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE50 ASL
    cpu.aslA();
    goto L_00EE51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE50u,0x00EE50u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE51u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE51u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE51 TAX
    cpu.transfer("TAX");
    goto L_00EE52;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE51u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE51 TAX
    cpu.transfer("TAX");
    goto L_00EE52;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE51u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE51 TAX
    cpu.transfer("TAX");
    goto L_00EE52;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE51u,0x00EE51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE52u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE52u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE52u, 6u, 3u, cpu.address("abs", 0xEFCDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE52 JSR -> $00EFCD stack real
    { cpu.push16Value(hw,0xEE54u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE55u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEFCDu), 0x00EE52u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE55;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE52u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE52u, 6u, 3u, cpu.address("abs", 0xEFCDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE52 JSR -> $00EFCD stack real
    { cpu.push16Value(hw,0xEE54u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE55u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEFCDu), 0x00EE52u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE55;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE52u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE52u, 6u, 3u, cpu.address("abs", 0xEFCDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE52 JSR -> $00EFCD stack real
    { cpu.push16Value(hw,0xEE54u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE55u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEFCDu), 0x00EE52u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE52u,0x00EE52u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE55u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE55u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE55u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE55 BRA -> $00EE83
    goto L_00EE83;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE55u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE55u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE55 BRA -> $00EE83
    goto L_00EE83;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE55u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE55u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE55 BRA -> $00EE83
    goto L_00EE83;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE55u,0x00EE55u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE57u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE57u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE57u, 6u, 3u, cpu.address("abs", 0xF267u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE57 JSR -> $00F267 stack real
    { cpu.push16Value(hw,0xEE59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE5Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF267u), 0x00EE57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE5A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE57u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE57u, 6u, 3u, cpu.address("abs", 0xF267u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE57 JSR -> $00F267 stack real
    { cpu.push16Value(hw,0xEE59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE5Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF267u), 0x00EE57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE5A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE57u,0x00EE57u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE5Au))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5A LDY
    cpu.setY(0x3u, 8);
    goto L_00EE5C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5A LDY
    cpu.setY(0x3u, 8);
    goto L_00EE5C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE5Au,0x00EE5Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE5Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Cu, 5u, 3u, cpu.address("abs", 0x1693u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE5F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Cu, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE5Cu,0x00EE5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE5Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5F CMP
    cpu.compareA(0xD01Eu);
    goto L_00EE62;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE5F CMP
    cpu.compareA(0x1Eu);
    goto L_00EE61;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE5Fu,0x00EE5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE61u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE61u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE61 BNE -> $00EE78
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE78; }
    goto L_00EE63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE61u,0x00EE61u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE62u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE62u,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE62u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE62 ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0xA6u), cpu.m8?8:16));
    goto L_00EE64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE62u,0x00EE62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE63u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE63u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE63u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE63 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE65;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE63u,0x00EE63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE64u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE64u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE64u, 6u, 4u, 0xA61CF0u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE64 STA
    hw.write(0xA61CF0u, cpu.a, cpu.m8?8:16);
    goto L_00EE68;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE64u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE64u, 6u, 4u, 0xA61CF0u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE64 STA
    hw.write(0xA61CF0u, cpu.a, cpu.m8?8:16);
    goto L_00EE68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE64u,0x00EE64u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE65u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE65u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE65 BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE83; }
    goto L_00EE67;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE65u,0x00EE65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE67u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE67u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE67u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE67 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE69;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE67u,0x00EE67u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE68u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE68u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE68u, 5u + 1u, 3u, cpu.address("absy", 0x18F0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE68 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x18F0u), cpu.m8?8:16));
    goto L_00EE6B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE68u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE68u, 5u + ((((0x18F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x18F0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE68 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x18F0u), cpu.m8?8:16));
    goto L_00EE6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE68u,0x00EE68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE69u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE69u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE69u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE69 BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE83; }
    goto L_00EE6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE69u,0x00EE69u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE6Bu))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu, 5u, 3u, cpu.address("abs", 0x140Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x140Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE6E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x140Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE6E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Bu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x140Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE6E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE6Bu,0x00EE6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE6Eu))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6E BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE83; }
    goto L_00EE70;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6E BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE83; }
    goto L_00EE70;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE6E BEQ -> $00EE83
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE83; }
    goto L_00EE70;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE6Eu,0x00EE6Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE70u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE70 LDA
    cpu.setA(0x2221u, 16);
    goto L_00EE73;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE70 LDA
    cpu.setA(0x2221u, 16);
    goto L_00EE73;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE70 LDA
    cpu.setA(0x21u, 8);
    goto L_00EE72;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE70u,0x00EE70u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE72u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE72u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE72u, 8u, 4u, 0x00F17Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EE72 JSL -> $00F17F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEE75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE76u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F17Fu, 0x00EE72u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE72u,0x00EE72u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE73u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE73u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE73u, 6u, 4u, ((0x8000F1u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE73 ADC
    cpu.adc(hw.readW(((0x8000F1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00EE77;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE73u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE73u, 6u, 4u, ((0x8000F1u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE73 ADC
    cpu.adc(hw.readW(((0x8000F1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00EE77;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE73u,0x00EE73u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE76u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE76u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE76u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE76 BRA -> $00EE1D
    hw.requestDispatch(0x00EE1Du,0x00EE76u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE76u,0x00EE76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE77u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE77u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE77u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE77 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE79;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE77u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE77u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE77 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE79;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE77u,0x00EE77u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE78u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE78u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE78 CMP
    cpu.compareA(0x32u);
    goto L_00EE7A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE78u,0x00EE78u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE79u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE79u,cpu,0x32u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE79u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xD0u) & 0xFFFFu), 2u, 0u);
    // $00EE79 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirect(hw, 0xD0u), cpu.m8?8:16));
    goto L_00EE7B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE79u,cpu,0x32u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE79u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xD0u) & 0xFFFFu), 2u, 0u);
    // $00EE79 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirect(hw, 0xD0u), cpu.m8?8:16));
    goto L_00EE7B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE79u,0x00EE79u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7A BNE -> $00EE7F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE7F; }
    goto L_00EE7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Au,0x00EE7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Bu,cpu,0x03u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Bu, 5u, 2u, cpu.addressStack(0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7B ORA
    cpu.logicOr(hw.readW(cpu.addressStack(0x9Cu), cpu.m8?8:16));
    goto L_00EE7D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Bu,cpu,0x03u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Bu, 5u, 2u, cpu.addressStack(0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7B ORA
    cpu.logicOr(hw.readW(cpu.addressStack(0x9Cu), cpu.m8?8:16));
    goto L_00EE7D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Bu,0x00EE7Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Cu, 4u, 3u, cpu.address("abs", 0x1909u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7C STZ
    hw.write(cpu.address("abs", 0x1909u), 0, cpu.m8?8:16);
    goto L_00EE7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Cu,0x00EE7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7D ORA
    cpu.logicOr(0x2219u);
    goto L_00EE80;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE7D ORA
    cpu.logicOr(0x2219u);
    goto L_00EE80;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Du,0x00EE7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Fu, 8u, 4u, 0x00F120u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EE7F JSL -> $00F120 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEE82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE83u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F120u, 0x00EE7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE83;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Fu,0x00EE7Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE80u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE80u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE80u, 6u, 3u, cpu.address("abs", 0x00F1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE80 JSR -> $0000F1 stack real
    { cpu.push16Value(hw,0xEE82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE83u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x00F1u), 0x00EE80u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE83;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE80u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE80u, 6u, 3u, cpu.address("abs", 0x00F1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE80 JSR -> $0000F1 stack real
    { cpu.push16Value(hw,0xEE82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE83u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x00F1u), 0x00EE80u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EE83;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE80u,0x00EE80u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE83u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE83u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE83u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE83 LDY
    cpu.setY(0xA520u, 16);
    goto L_00EE86;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE83u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE83 LDY
    cpu.setY(0x20u, 8);
    goto L_00EE85;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE83u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE83 LDY
    cpu.setY(0x20u, 8);
    goto L_00EE85;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE83u,0x00EE83u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE85u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE85u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE85u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE85 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE87;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE85u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE85u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE85 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE85u,0x00EE85u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE86u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE86u, 5u + 1u, 3u, cpu.address("absx", 0x0610u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE86 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x610u), cpu.m8?8:16));
    goto L_00EE89;
L_00EE87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE87u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE87 BPL -> $00EE8F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EE8F; }
    goto L_00EE89;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE87 BPL -> $00EE8F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EE8F; }
    goto L_00EE89;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE87u,0x00EE87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE89u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE89 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE8B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE89 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE8B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE89 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE8B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE89u,0x00EE89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Bu))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8B CMP
    cpu.compareA(0x9002u);
    goto L_00EE8E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8B CMP
    cpu.compareA(0x9002u);
    goto L_00EE8E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8B CMP
    cpu.compareA(0x2u);
    goto L_00EE8D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Bu,0x00EE8Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8D BCC -> $00EE39
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE39u,0x00EE8Du); return; }
    goto L_00EE8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Du,0x00EE8Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8E TAX
    cpu.transfer("TAX");
    goto L_00EE8F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8E TAX
    cpu.transfer("TAX");
    goto L_00EE8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Eu,0x00EE8Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Fu))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu, 5u, 3u, cpu.address("abs", 0x1423u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1423u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE92;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu, 4u, 3u, cpu.address("abs", 0x1423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1423u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE92;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu, 4u, 3u, cpu.address("abs", 0x1423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1423u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE92;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,0x00EE8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE92u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE92 BEQ -> $00EED1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EE92u); return; }
    goto L_00EE94;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE92 BEQ -> $00EED1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EE92u); return; }
    goto L_00EE94;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE92 BEQ -> $00EED1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EE92u); return; }
    goto L_00EE94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE92u,0x00EE92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE94u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE94 DEX
    cpu.decReg('X');
    goto L_00EE95;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE94 DEX
    cpu.decReg('X');
    goto L_00EE95;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE94 DEX
    cpu.decReg('X');
    goto L_00EE95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE94u,0x00EE94u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE95u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE95 TXA
    cpu.transfer("TXA");
    goto L_00EE96;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE95 TXA
    cpu.transfer("TXA");
    goto L_00EE96;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE95 TXA
    cpu.transfer("TXA");
    goto L_00EE96;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE95u,0x00EE95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE96u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0xF003u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE99u,0x00EE96u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0xF003u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE99u,0x00EE96u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0x3u);
    goto L_00EE98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE96u,0x00EE96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE98u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE98 BEQ -> $00EEAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EEAAu,0x00EE98u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Au,0x00EE98u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE98u,0x00EE98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EC21_E0M1X1CQ_part5(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF00u: goto L_00EF00;
    case 0x00EF01u: goto L_00EF01;
    case 0x00EF02u: goto L_00EF02;
    case 0x00EF03u: goto L_00EF03;
    case 0x00EF04u: goto L_00EF04;
    case 0x00EF05u: goto L_00EF05;
    case 0x00EF06u: goto L_00EF06;
    case 0x00EF08u: goto L_00EF08;
    case 0x00EF09u: goto L_00EF09;
    case 0x00EF0Bu: goto L_00EF0B;
    case 0x00EF0Du: goto L_00EF0D;
    case 0x00EF0Eu: goto L_00EF0E;
    case 0x00EF0Fu: goto L_00EF0F;
    case 0x00EF10u: goto L_00EF10;
    case 0x00EF11u: goto L_00EF11;
    case 0x00EF13u: goto L_00EF13;
    case 0x00EF16u: goto L_00EF16;
    case 0x00EF18u: goto L_00EF18;
    case 0x00EF1Au: goto L_00EF1A;
    case 0x00EF1Cu: goto L_00EF1C;
    case 0x00EF1Fu: goto L_00EF1F;
    case 0x00EF21u: goto L_00EF21;
    case 0x00EF23u: goto L_00EF23;
    case 0x00EF25u: goto L_00EF25;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF00u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF00u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF00u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF00 LDX
    cpu.setX(0x8E1Cu, 16);
    goto L_00EF03;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF00u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF00 LDX
    cpu.setX(0x1Cu, 8);
    goto L_00EF02;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF00u,0x00EF00u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF01u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF01u,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF01u, 8u, 3u, cpu.address("abs", 0xED8Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF01 TRB
    cpu.trb(hw, cpu.address("abs", 0xED8Eu), cpu.m8?8:16);
    goto L_00EF04;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF01u,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF01u, 8u, 3u, cpu.address("abs", 0xED8Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF01 TRB
    cpu.trb(hw, cpu.address("abs", 0xED8Eu), cpu.m8?8:16);
    goto L_00EF04;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF01u,0x00EF01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF02u))return;
  // 8 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF02 STX
    hw.write(cpu.address("abs", 0x13EDu), cpu.x, cpu.x8?8:16);
    goto L_00EF05;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u, 5u, 3u, cpu.address("abs", 0x13EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF02 STX
    hw.write(cpu.address("abs", 0x13EDu), cpu.x, cpu.x8?8:16);
    goto L_00EF05;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF02 STX
    hw.write(cpu.address("abs", 0x13EDu), cpu.x, cpu.x8?8:16);
    goto L_00EF05;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF02u,0x00EF02u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF03u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF03u, 4u, 3u, cpu.address("abs", 0xBE13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF03 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0xBE13u), cpu.m8?8:16));
    goto L_00EF06;
L_00EF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF04u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u,cpu,0x13u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xBEu) & 0xFFFFu), 2u, 0u);
    // $00EF04 ORA
    cpu.logicOr(hw.readW(cpu.addressStackIndirectY(hw, 0xBEu), cpu.m8?8:16));
    goto L_00EF06;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u,cpu,0x13u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xBEu) & 0xFFFFu), 2u, 0u);
    // $00EF04 ORA
    cpu.logicOr(hw.readW(cpu.addressStackIndirectY(hw, 0xBEu), cpu.m8?8:16));
    goto L_00EF06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF04u,0x00EF04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF05u))return;
  // 8 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u, 4u + ((((0xE4B9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4B9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF05 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xE4B9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF08;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u, 5u + 1u, 3u, cpu.address("absy", 0xE4B9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF05 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xE4B9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF08;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u, 4u + ((((0xE4B9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4B9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF05 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xE4B9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF08;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF05u,0x00EF05u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF06u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u, 5u + 1u, 3u, cpu.address("absy", 0x8EE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF06 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8EE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF09;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u, 5u + ((((0x8EE4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8EE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF06 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8EE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF09;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u, 4u + 1u, 3u, cpu.address("absy", 0x8EE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF06 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8EE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF06u,0x00EF06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF08u))return;
  // 8 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF08 STX
    hw.write(cpu.address("abs", 0x13E1u), cpu.x, cpu.x8?8:16);
    goto L_00EF0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 5u, 3u, cpu.address("abs", 0x13E1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF08 STX
    hw.write(cpu.address("abs", 0x13E1u), cpu.x, cpu.x8?8:16);
    goto L_00EF0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF08 STX
    hw.write(cpu.address("abs", 0x13E1u), cpu.x, cpu.x8?8:16);
    goto L_00EF0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF08u,0x00EF08u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF09u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x13u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00EF09 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0x13u), cpu.m8?8:16));
    goto L_00EF0B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x13u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00EF09 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0x13u), cpu.m8?8:16));
    goto L_00EF0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x13u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00EF09 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0x13u), cpu.m8?8:16));
    goto L_00EF0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF09u,0x00EF09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Bu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0B CPY
    cpu.compareY(0xB01Cu);
    goto L_00EF0E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0B CPY
    cpu.compareY(0x1Cu);
    goto L_00EF0D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0B CPY
    cpu.compareY(0xB01Cu);
    goto L_00EF0E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0B CPY
    cpu.compareY(0x1Cu);
    goto L_00EF0D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,0x00EF0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Du))return;
  // 7 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0D BCS -> $00EF38
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF38u,0x00EF0Du); return; }
    goto L_00EF0F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0D BCS -> $00EF38
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF38u,0x00EF0Du); return; }
    goto L_00EF0F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Du,0x00EF0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0E AND
    cpu.logicAnd(0x7BA5u);
    goto L_00EF11;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0E AND
    cpu.logicAnd(0xA5u);
    goto L_00EF10;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Eu,0x00EF0Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Fu))return;
  // 7 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF11;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF11;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Fu,0x00EF0Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF10u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF10u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF10 TDC
    cpu.tdc();
    goto L_00EF11;
L_00EF11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF11u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF11 BEQ -> $00EF31
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF11u); return; }
    goto L_00EF13;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF11 BEQ -> $00EF31
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF11u); return; }
    goto L_00EF13;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF11 BEQ -> $00EF31
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF11u); return; }
    goto L_00EF13;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF11 BEQ -> $00EF31
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF11u); return; }
    goto L_00EF13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF11u,0x00EF11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF13u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u, 5u + 1u, 3u, cpu.address("absy", 0xE53Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF13 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF16;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u, 5u + ((((0xE53Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE53Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF13 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF16;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u, 4u + 1u, 3u, cpu.address("absy", 0xE53Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF13 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF16;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u, 4u + ((((0xE53Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE53Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF13 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF16;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF13u,0x00EF13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF16u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF16u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF16 BEQ -> $00EF31
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF16u); return; }
    goto L_00EF18;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF16u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF16 BEQ -> $00EF31
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF16u); return; }
    goto L_00EF18;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF16u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF16 BEQ -> $00EF31
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF16u); return; }
    goto L_00EF18;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF16u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF16 BEQ -> $00EF31
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF16u); return; }
    goto L_00EF18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF16u,0x00EF16u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF18u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF18u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF18 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00EF1A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF18u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF18 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00EF1A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF18u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF18 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00EF1A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF18u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF18 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00EF1A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF18u,0x00EF18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1A BPL -> $00EF31
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF1Au); return; }
    goto L_00EF1C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1A BPL -> $00EF31
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF1Au); return; }
    goto L_00EF1C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1A BPL -> $00EF31
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF1Au); return; }
    goto L_00EF1C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1A BPL -> $00EF31
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF31u,0x00EF1Au); return; }
    goto L_00EF1C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF1Au,0x00EF1Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Cu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu, 5u, 3u, cpu.address("abs", 0x13E5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1C STX
    hw.write(cpu.address("abs", 0x13E5u), cpu.x, cpu.x8?8:16);
    goto L_00EF1F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1C STX
    hw.write(cpu.address("abs", 0x13E5u), cpu.x, cpu.x8?8:16);
    goto L_00EF1F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu, 5u, 3u, cpu.address("abs", 0x13E5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1C STX
    hw.write(cpu.address("abs", 0x13E5u), cpu.x, cpu.x8?8:16);
    goto L_00EF1F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1C STX
    hw.write(cpu.address("abs", 0x13E5u), cpu.x, cpu.x8?8:16);
    goto L_00EF1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,0x00EF1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Fu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF21;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF21;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF21;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,0x00EF1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF21u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF21 BPL -> $00EF26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF26u,0x00EF21u); return; }
    goto L_00EF23;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF21 BPL -> $00EF26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF26u,0x00EF21u); return; }
    goto L_00EF23;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF21 BPL -> $00EF26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF26u,0x00EF21u); return; }
    goto L_00EF23;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF21 BPL -> $00EF26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF26u,0x00EF21u); return; }
    goto L_00EF23;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF21u,0x00EF21u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF23u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF23 EOR
    cpu.logicXor(0x1AFFu);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF26u,0x00EF23u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF23 EOR
    cpu.logicXor(0x1AFFu);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF26u,0x00EF23u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF23 EOR
    cpu.logicXor(0xFFu);
    goto L_00EF25;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF23 EOR
    cpu.logicXor(0xFFu);
    goto L_00EF25;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF23u,0x00EF23u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF25u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF25 INC
    cpu.inc('A');
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF26u,0x00EF25u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF25 INC
    cpu.inc('A');
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF26u,0x00EF25u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF25u,0x00EF25u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00F377_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F377u: goto L_00F377;
    case 0x00F37Au: goto L_00F37A;
    case 0x00F37Du: goto L_00F37D;
    case 0x00F37Eu: goto L_00F37E;
    case 0x00F380u: goto L_00F380;
    case 0x00F382u: goto L_00F382;
    case 0x00F384u: goto L_00F384;
    case 0x00F386u: goto L_00F386;
    case 0x00F38Au: goto L_00F38A;
    case 0x00F38Bu: goto L_00F38B;
    case 0x00F38Fu: goto L_00F38F;
    case 0x00F390u: goto L_00F390;
    case 0x00F393u: goto L_00F393;
    case 0x00F395u: goto L_00F395;
    case 0x00F398u: goto L_00F398;
    case 0x00F39Au: goto L_00F39A;
    case 0x00F39Du: goto L_00F39D;
    case 0x00F39Fu: goto L_00F39F;
    case 0x00F3A2u: goto L_00F3A2;
    case 0x00F3A4u: goto L_00F3A4;
    case 0x00F3A7u: goto L_00F3A7;
    case 0x00F3A9u: goto L_00F3A9;
    case 0x00F3ACu: goto L_00F3AC;
    case 0x00F3AEu: goto L_00F3AE;
    case 0x00F3B1u: goto L_00F3B1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F377:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF377u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF377u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF377u, 4u, 3u, cpu.address("abs", 0x1420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F377 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1420u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F37A;
L_00F37A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF37Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Au, 6u, 3u, cpu.address("abs", 0x1420u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F37A INC
    cpu.incMem(hw, cpu.address("abs", 0x1420u), cpu.m8?8:16);
    goto L_00F37D;
L_00F37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F37D CLC
    cpu.setFlag('C', false);
    goto L_00F37E;
L_00F37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F37E ADC
    cpu.adc(0x9u);
    goto L_00F380;
L_00F380:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF380u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF380u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF380u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F380 CMP
    cpu.compareA(0xDu);
    goto L_00F382;
L_00F382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF382u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF382u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F382 BCC -> $00F386
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F386; }
    goto L_00F384;
L_00F384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF384u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF384u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F384 LDA
    cpu.setA(0xDu, 8);
    goto L_00F386;
L_00F386:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF386u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF386u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF386u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F386 BRA -> $00F38A
    goto L_00F38A;
L_00F38A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF38Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF38Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF38Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F38A PHA
    cpu.push("PHA", hw);
    goto L_00F38B;
L_00F38B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF38Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF38Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF38Bu, 8u, 4u, 0x02AD34u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F38B JSL -> $02AD34 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF38Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF38Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02AD34u, 0x00F38Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F38F;
L_00F38F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF38Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF38Fu,0x00F38Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF38Fu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF38Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F38F PLA
    cpu.pop("PLA", hw);
    goto L_00F390;
L_00F390:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF390u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF390u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF390u, 5u, 3u, cpu.address("absy", 0x16E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F390 STA
    hw.write(cpu.address("absy", 0x16E1u), cpu.a, cpu.m8?8:16);
    goto L_00F393;
L_00F393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF393u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF393u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F393 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F395;
L_00F395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF395u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF395u, 5u, 3u, cpu.address("absy", 0x16EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F395 STA
    hw.write(cpu.address("absy", 0x16EDu), cpu.a, cpu.m8?8:16);
    goto L_00F398;
L_00F398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF398u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF398u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F398 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F39A;
L_00F39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF39Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF39Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF39Au, 5u, 3u, cpu.address("absy", 0x16F3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F39A STA
    hw.write(cpu.address("absy", 0x16F3u), cpu.a, cpu.m8?8:16);
    goto L_00F39D;
L_00F39D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF39Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF39Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF39Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F39D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F39F;
L_00F39F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF39Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF39Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF39Fu, 5u, 3u, cpu.address("absy", 0x16E7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F39F STA
    hw.write(cpu.address("absy", 0x16E7u), cpu.a, cpu.m8?8:16);
    goto L_00F3A2;
L_00F3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3A2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3A2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3A2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F3A4;
L_00F3A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3A4u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3A4u, 5u, 3u, cpu.address("absy", 0x16F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3A4 STA
    hw.write(cpu.address("absy", 0x16F9u), cpu.a, cpu.m8?8:16);
    goto L_00F3A7;
L_00F3A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3A7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3A7 LDA
    cpu.setA(0x30u, 8);
    goto L_00F3A9;
L_00F3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3A9u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3A9u, 5u, 3u, cpu.address("absy", 0x16FFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3A9 STA
    hw.write(cpu.address("absy", 0x16FFu), cpu.a, cpu.m8?8:16);
    goto L_00F3AC;
L_00F3AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3AC LDA
    cpu.setA(0x0u, 8);
    goto L_00F3AE;
L_00F3AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3AEu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3AEu, 5u, 3u, cpu.address("absy", 0x1705u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3AE STA
    hw.write(cpu.address("absy", 0x1705u), cpu.a, cpu.m8?8:16);
    goto L_00F3B1;
L_00F3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3B1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F3B1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00F3B1u);return;} hw.unresolvedReturn(0x00F3B1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_00F545_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F545u: goto L_00F545;
    case 0x00F546u: goto L_00F546;
    case 0x00F548u: goto L_00F548;
    case 0x00F54Bu: goto L_00F54B;
    case 0x00F54Du: goto L_00F54D;
    case 0x00F54Fu: goto L_00F54F;
    case 0x00F552u: goto L_00F552;
    case 0x00F554u: goto L_00F554;
    case 0x00F556u: goto L_00F556;
    case 0x00F559u: goto L_00F559;
    case 0x00F55Au: goto L_00F55A;
    case 0x00F55Cu: goto L_00F55C;
    case 0x00F55Eu: goto L_00F55E;
    case 0x00F55Fu: goto L_00F55F;
    case 0x00F560u: goto L_00F560;
    case 0x00F562u: goto L_00F562;
    case 0x00F564u: goto L_00F564;
    case 0x00F566u: goto L_00F566;
    case 0x00F567u: goto L_00F567;
    case 0x00F56Au: goto L_00F56A;
    case 0x00F56Cu: goto L_00F56C;
    case 0x00F56Fu: goto L_00F56F;
    case 0x00F571u: goto L_00F571;
    case 0x00F573u: goto L_00F573;
    case 0x00F576u: goto L_00F576;
    case 0x00F577u: goto L_00F577;
    case 0x00F57Au: goto L_00F57A;
    case 0x00F57Cu: goto L_00F57C;
    case 0x00F57Eu: goto L_00F57E;
    case 0x00F581u: goto L_00F581;
    case 0x00F583u: goto L_00F583;
    case 0x00F584u: goto L_00F584;
    case 0x00F586u: goto L_00F586;
    case 0x00F588u: goto L_00F588;
    case 0x00F58Bu: goto L_00F58B;
    case 0x00F58Du: goto L_00F58D;
    case 0x00F58Fu: goto L_00F58F;
    case 0x00F592u: goto L_00F592;
    case 0x00F594u: goto L_00F594;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF545u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF545u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F545 TAY
    cpu.transfer("TAY");
    goto L_00F546;
L_00F546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF546u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF546u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F546 BNE -> $00F577
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F577; }
    goto L_00F548;
L_00F548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF548u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF548u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F548 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00F54B;
L_00F54B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF54Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF54Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF54Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F54B CPY
    cpu.compareY(0x29u);
    goto L_00F54D;
L_00F54D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF54Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF54Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF54Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F54D BNE -> $00F55A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F55A; }
    goto L_00F54F;
L_00F54F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF54Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF54Fu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF54Fu, 4u, 3u, cpu.address("abs", 0x14ADu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F54F LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x14ADu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00F552;
L_00F552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF552u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF552u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F552 BEQ -> $00F594
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F594; }
    goto L_00F554;
L_00F554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF554u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF554u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F554 LDA
    cpu.setA(0x24u, 8);
    goto L_00F556;
L_00F556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF556u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF556u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F556 STA
    hw.write(cpu.address("abs", 0x1693u), cpu.a, cpu.m8?8:16);
    goto L_00F559;
L_00F559:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF559u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF559u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF559u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F559 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00F559u);return;} hw.unresolvedReturn(0x00F559u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_00F55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF55Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF55Au,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF55Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F55A CPY
    cpu.compareY(0x2Bu);
    goto L_00F55C;
L_00F55C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF55Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF55Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF55Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F55C BEQ -> $00F56C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F56C; }
    goto L_00F55E;
L_00F55E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF55Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF55Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF55Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F55E TYA
    cpu.transfer("TYA");
    goto L_00F55F;
L_00F55F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF55Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF55Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF55Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F55F SEC
    cpu.setFlag('C', true);
    goto L_00F560;
L_00F560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF560u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF560u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF560u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F560 SBC
    cpu.sbc(0xECu);
    goto L_00F562;
L_00F562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF562u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF562u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F562 CMP
    cpu.compareA(0x10u);
    goto L_00F564;
L_00F564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF564u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF564u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF564u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F564 BCS -> $00F592
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F592; }
    goto L_00F566;
L_00F566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF566u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF566u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF566u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F566 INC
    cpu.inc('A');
    goto L_00F567;
L_00F567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF567u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF567u, 4u, 3u, cpu.address("abs", 0x1423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F567 STA
    hw.write(cpu.address("abs", 0x1423u), cpu.a, cpu.m8?8:16);
    goto L_00F56A;
L_00F56A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF56Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF56Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF56Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F56A BRA -> $00F571
    goto L_00F571;
L_00F56C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF56Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF56Cu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF56Cu, 4u, 3u, cpu.address("abs", 0x14ADu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F56C LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x14ADu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00F56F;
L_00F56F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF56Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF56Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF56Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F56F BEQ -> $00F594
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F594; }
    goto L_00F571;
L_00F571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF571u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF571u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F571 LDA
    cpu.setA(0x32u, 8);
    goto L_00F573;
L_00F573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF573u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF573u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F573 STA
    hw.write(cpu.address("abs", 0x1693u), cpu.a, cpu.m8?8:16);
    goto L_00F576;
L_00F576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF576u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF576u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F576 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00F576u);return;} hw.unresolvedReturn(0x00F576u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_00F577:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF577u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF577u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF577u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F577 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00F57A;
L_00F57A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF57Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF57Au,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF57Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F57A CPY
    cpu.compareY(0x32u);
    goto L_00F57C;
L_00F57C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF57Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF57Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF57Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F57C BNE -> $00F584
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F584; }
    goto L_00F57E;
L_00F57E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF57Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF57Eu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF57Eu, 4u, 3u, cpu.address("abs", 0x14ADu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F57E LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x14ADu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00F581;
L_00F581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF581u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF581u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F581 BNE -> $00F58D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F58D; }
    goto L_00F583;
L_00F583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF583u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF583u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F583 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00F583u);return;} hw.unresolvedReturn(0x00F583u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_00F584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF584u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF584u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF584u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F584 CPY
    cpu.compareY(0x2Fu);
    goto L_00F586;
L_00F586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF586u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF586u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F586 BNE -> $00F594
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F594; }
    goto L_00F588;
L_00F588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF588u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF588u, 4u, 3u, cpu.address("abs", 0x14AEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F588 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x14AEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00F58B;
L_00F58B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF58Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF58Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF58Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F58B BEQ -> $00F594
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F594; }
    goto L_00F58D;
L_00F58D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF58Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF58Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF58Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F58D LDY
    cpu.setY(0x2Bu, 8);
    goto L_00F58F;
L_00F58F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF58Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF58Fu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF58Fu, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F58F STY
    hw.write(cpu.address("abs", 0x1693u), cpu.y, cpu.x8?8:16);
    goto L_00F592;
L_00F592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF592u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF592u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF592u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F592 LDA
    cpu.setA(0x0u, 8);
    goto L_00F594;
L_00F594:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF594u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF594u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF594u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F594 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00F594u);return;} hw.unresolvedReturn(0x00F594u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_018E5F_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018E5Fu: goto L_018E5F;
    case 0x018E62u: goto L_018E62;
    case 0x018E65u: goto L_018E65;
    case 0x018E66u: goto L_018E66;
    case 0x018E67u: goto L_018E67;
    case 0x018E68u: goto L_018E68;
    case 0x018E6Au: goto L_018E6A;
    case 0x018E6Du: goto L_018E6D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018E5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Fu, 7u, 3u, cpu.address("absx", 0x1570u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018E5F INC
    cpu.incMem(hw, cpu.address("absx", 0x1570u), cpu.m8?8:16);
    goto L_018E62;
L_018E62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E62u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E62u, 4u + ((((0x1570u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018E62 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1570u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018E65;
L_018E65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E65u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018E65 LSR
    cpu.lsrA();
    goto L_018E66;
L_018E66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E66u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018E66 LSR
    cpu.lsrA();
    goto L_018E67;
L_018E67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E67u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018E67 LSR
    cpu.lsrA();
    goto L_018E68;
L_018E68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E68u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018E68 AND
    cpu.logicAnd(0x1u);
    goto L_018E6A;
L_018E6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Au, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018E6A STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_018E6D;
L_018E6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018E6D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018E6Du);return;} hw.unresolvedReturn(0x018E6Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_018E5F_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018E5Fu: goto L_018E5F;
    case 0x018E62u: goto L_018E62;
    case 0x018E65u: goto L_018E65;
    case 0x018E66u: goto L_018E66;
    case 0x018E67u: goto L_018E67;
    case 0x018E68u: goto L_018E68;
    case 0x018E6Au: goto L_018E6A;
    case 0x018E6Du: goto L_018E6D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018E5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Fu, 7u, 3u, cpu.address("absx", 0x1570u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018E5F INC
    cpu.incMem(hw, cpu.address("absx", 0x1570u), cpu.m8?8:16);
    goto L_018E62;
L_018E62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E62u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E62u, 4u + ((((0x1570u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018E62 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1570u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018E65;
L_018E65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E65u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018E65 LSR
    cpu.lsrA();
    goto L_018E66;
L_018E66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E66u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018E66 LSR
    cpu.lsrA();
    goto L_018E67;
L_018E67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E67u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018E67 LSR
    cpu.lsrA();
    goto L_018E68;
L_018E68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E68u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018E68 AND
    cpu.logicAnd(0x1u);
    goto L_018E6A;
L_018E6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Au, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018E6A STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_018E6D;
L_018E6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018E6D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018E6Du);return;} hw.unresolvedReturn(0x018E6Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01ABCC_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01ABCCu: goto L_01ABCC;
    case 0x01ABCDu: goto L_01ABCD;
    case 0x01ABCEu: goto L_01ABCE;
    case 0x01ABD0u: goto L_01ABD0;
    case 0x01ABD1u: goto L_01ABD1;
    case 0x01ABD4u: goto L_01ABD4;
    case 0x01ABD7u: goto L_01ABD7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01ABCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABCCu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABCCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABCC TXA
    cpu.transfer("TXA");
    goto L_01ABCD;
L_01ABCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABCDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABCDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABCD CLC
    cpu.setFlag('C', false);
    goto L_01ABCE;
L_01ABCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABCEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABCE ADC
    cpu.adc(0xCu);
    goto L_01ABD0;
L_01ABD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABD0 TAX
    cpu.transfer("TAX");
    goto L_01ABD1;
L_01ABD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD1u, 6u, 3u, cpu.address("abs", 0xABD8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ABD1 JSR -> $01ABD8 stack real
    { cpu.push16Value(hw,0xABD3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xABD4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABD8u), 0x01ABD1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01ABD4;
L_01ABD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABD4u,0x01ABD4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD4u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD4u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABD4 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01ABD7;
L_01ABD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ABD7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01ABD7u);return;} hw.unresolvedReturn(0x01ABD7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04D718_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04D718u: goto L_04D718;
    case 0x04D71Cu: goto L_04D71C;
    case 0x04D71Eu: goto L_04D71E;
    case 0x04D720u: goto L_04D720;
    case 0x04D722u: goto L_04D722;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04D718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD718u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD718u, 8u, 4u, 0x0087ADu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $04D718 JSL -> $0087AD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD71Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD71Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0087ADu, 0x04D718u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04D71C;
L_04D71C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D71C REP
    cpu.rep(0x30u);
    goto L_04D71E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D71C REP
    cpu.rep(0x30u);
    goto L_04D71E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD71Cu,0x04D71Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04D71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D71E INC
    cpu.incMem(hw, cpu.address("dp", 0x47u), cpu.m8?8:16);
    goto L_04D720;
L_04D720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD720u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD720u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D720 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04D722;
L_04D722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD722u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD722u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D722 CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD723u,0x04D722u); return;
}

void sub_04D718_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04D718u: goto L_04D718;
    case 0x04D71Cu: goto L_04D71C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04D718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD718u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD718u, 8u, 4u, 0x0087ADu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $04D718 JSL -> $0087AD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD71Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD71Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0087ADu, 0x04D718u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04D71C;
L_04D71C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD71Cu,0x04D71Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D71C REP
    cpu.rep(0x30u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD71Eu,0x04D71Cu); return;
}

void sub_04D770_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04D770u: goto L_04D770;
    case 0x04D774u: goto L_04D774;
    case 0x04D778u: goto L_04D778;
    case 0x04D77Cu: goto L_04D77C;
    case 0x04D780u: goto L_04D780;
    case 0x04D784u: goto L_04D784;
    case 0x04D788u: goto L_04D788;
    case 0x04D78Cu: goto L_04D78C;
    case 0x04D790u: goto L_04D790;
    case 0x04D794u: goto L_04D794;
    case 0x04D798u: goto L_04D798;
    case 0x04D79Cu: goto L_04D79C;
    case 0x04D7A0u: goto L_04D7A0;
    case 0x04D7A4u: goto L_04D7A4;
    case 0x04D7A8u: goto L_04D7A8;
    case 0x04D7ACu: goto L_04D7AC;
    case 0x04D7B0u: goto L_04D7B0;
    case 0x04D7B4u: goto L_04D7B4;
    case 0x04D7B8u: goto L_04D7B8;
    case 0x04D7BCu: goto L_04D7BC;
    case 0x04D7C0u: goto L_04D7C0;
    case 0x04D7C4u: goto L_04D7C4;
    case 0x04D7C8u: goto L_04D7C8;
    case 0x04D7CCu: goto L_04D7CC;
    case 0x04D7D0u: goto L_04D7D0;
    case 0x04D7D4u: goto L_04D7D4;
    case 0x04D7D8u: goto L_04D7D8;
    case 0x04D7DCu: goto L_04D7DC;
    case 0x04D7E0u: goto L_04D7E0;
    case 0x04D7E4u: goto L_04D7E4;
    case 0x04D7E8u: goto L_04D7E8;
    case 0x04D7ECu: goto L_04D7EC;
    case 0x04D7F0u: goto L_04D7F0;
    case 0x04D7F1u: goto L_04D7F1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04D770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD770u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD770u, 5u, 4u, ((0x7FC800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D770 STA
    hw.write(((0x7FC800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D774;
L_04D774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD774u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD774u, 5u, 4u, ((0x7FC9B0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D774 STA
    hw.write(((0x7FC9B0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D778;
L_04D778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD778u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD778u, 5u, 4u, ((0x7FCB60u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D778 STA
    hw.write(((0x7FCB60u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D77C;
L_04D77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Cu, 5u, 4u, ((0x7FCD10u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D77C STA
    hw.write(((0x7FCD10u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D780;
L_04D780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD780u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD780u, 5u, 4u, ((0x7FCEC0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D780 STA
    hw.write(((0x7FCEC0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D784;
L_04D784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD784u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD784u, 5u, 4u, ((0x7FD070u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D784 STA
    hw.write(((0x7FD070u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D788;
L_04D788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD788u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD788u, 5u, 4u, ((0x7FD220u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D788 STA
    hw.write(((0x7FD220u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D78C;
L_04D78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu, 5u, 4u, ((0x7FD3D0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D78C STA
    hw.write(((0x7FD3D0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D790;
L_04D790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD790u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD790u, 5u, 4u, ((0x7FD580u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D790 STA
    hw.write(((0x7FD580u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D794;
L_04D794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u, 5u, 4u, ((0x7FD730u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D794 STA
    hw.write(((0x7FD730u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D798;
L_04D798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD798u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD798u, 5u, 4u, ((0x7FD8E0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D798 STA
    hw.write(((0x7FD8E0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D79C;
L_04D79C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Cu, 5u, 4u, ((0x7FDA90u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D79C STA
    hw.write(((0x7FDA90u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7A0;
L_04D7A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A0u, 5u, 4u, ((0x7FDC40u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7A0 STA
    hw.write(((0x7FDC40u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7A4;
L_04D7A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A4u, 5u, 4u, ((0x7FDDF0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7A4 STA
    hw.write(((0x7FDDF0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7A8;
L_04D7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A8u, 5u, 4u, ((0x7FDFA0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7A8 STA
    hw.write(((0x7FDFA0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7AC;
L_04D7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ACu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ACu, 5u, 4u, ((0x7FE150u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7AC STA
    hw.write(((0x7FE150u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7B0;
L_04D7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B0u, 5u, 4u, ((0x7FE300u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7B0 STA
    hw.write(((0x7FE300u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7B4;
L_04D7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B4u, 5u, 4u, ((0x7FE4B0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7B4 STA
    hw.write(((0x7FE4B0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7B8;
L_04D7B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B8u, 5u, 4u, ((0x7FE660u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7B8 STA
    hw.write(((0x7FE660u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7BC;
L_04D7BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BCu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BCu, 5u, 4u, ((0x7FE810u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7BC STA
    hw.write(((0x7FE810u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7C0;
L_04D7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C0u, 5u, 4u, ((0x7FE9C0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7C0 STA
    hw.write(((0x7FE9C0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7C4;
L_04D7C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C4u, 5u, 4u, ((0x7FEB70u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7C4 STA
    hw.write(((0x7FEB70u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7C8;
L_04D7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C8u, 5u, 4u, ((0x7FED20u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7C8 STA
    hw.write(((0x7FED20u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7CC;
L_04D7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CCu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CCu, 5u, 4u, ((0x7FEED0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7CC STA
    hw.write(((0x7FEED0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7D0;
L_04D7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D0u, 5u, 4u, ((0x7FF080u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7D0 STA
    hw.write(((0x7FF080u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7D4;
L_04D7D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D4u, 5u, 4u, ((0x7FF230u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7D4 STA
    hw.write(((0x7FF230u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7D8;
L_04D7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D8u, 5u, 4u, ((0x7FF3E0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7D8 STA
    hw.write(((0x7FF3E0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7DC;
L_04D7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DCu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DCu, 5u, 4u, ((0x7FF590u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7DC STA
    hw.write(((0x7FF590u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7E0;
L_04D7E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E0u, 5u, 4u, ((0x7FF740u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7E0 STA
    hw.write(((0x7FF740u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7E4;
L_04D7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E4u, 5u, 4u, ((0x7FF8F0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7E4 STA
    hw.write(((0x7FF8F0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7E8;
L_04D7E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E8u, 5u, 4u, ((0x7FFAA0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7E8 STA
    hw.write(((0x7FFAA0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7EC;
L_04D7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ECu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ECu, 5u, 4u, ((0x7FFC50u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7EC STA
    hw.write(((0x7FFC50u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04D7F0;
L_04D7F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7F0 INX
    cpu.inc('X');
    goto L_04D7F1;
L_04D7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04D7F1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04D7F1u);return;} hw.unresolvedReturn(0x04D7F1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04FE62_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04FE62u: goto L_04FE62;
    case 0x04FE63u: goto L_04FE63;
    case 0x04FE64u: goto L_04FE64;
    case 0x04FE66u: goto L_04FE66;
    case 0x04FE67u: goto L_04FE67;
    case 0x04FE69u: goto L_04FE69;
    case 0x04FE6Cu: goto L_04FE6C;
    case 0x04FE6Fu: goto L_04FE6F;
    case 0x04FE71u: goto L_04FE71;
    case 0x04FE72u: goto L_04FE72;
    case 0x04FE75u: goto L_04FE75;
    case 0x04FE77u: goto L_04FE77;
    case 0x04FE79u: goto L_04FE79;
    case 0x04FE7Bu: goto L_04FE7B;
    case 0x04FE7Du: goto L_04FE7D;
    case 0x04FE80u: goto L_04FE80;
    case 0x04FE81u: goto L_04FE81;
    case 0x04FE84u: goto L_04FE84;
    case 0x04FE86u: goto L_04FE86;
    case 0x04FE87u: goto L_04FE87;
    case 0x04FE8Au: goto L_04FE8A;
    case 0x04FE8Du: goto L_04FE8D;
    case 0x04FE8Fu: goto L_04FE8F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04FE62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE62u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE62 TXA
    cpu.transfer("TXA");
    goto L_04FE63;
L_04FE63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE63u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE63u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE63 CLC
    cpu.setFlag('C', false);
    goto L_04FE64;
L_04FE64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE64u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE64u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE64 ADC
    cpu.adc(0x10u);
    goto L_04FE66;
L_04FE66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE66u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE66 TAX
    cpu.transfer("TAX");
    goto L_04FE67;
L_04FE67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE67u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE67 LDY
    cpu.setY(0x2u, 8);
    goto L_04FE69;
L_04FE69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE69u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE69u, 6u, 3u, cpu.address("abs", 0xFE7Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FE69 JSR -> $04FE7D stack real
    { cpu.push16Value(hw,0xFE6Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFE6Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFE7Du), 0x04FE69u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04FE6C;
L_04FE6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE6Cu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFE6Cu,0x04FE6Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE6Cu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE6Cu, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE6C LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDDEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04FE6F;
L_04FE6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE6Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE6Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE6F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FE71;
L_04FE71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE71u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE71u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE71 SEC
    cpu.setFlag('C', true);
    goto L_04FE72;
L_04FE72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE72u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE72u, 4u + ((((0x0E55u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E55u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE72 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0xE55u), cpu.m8?8:16));
    goto L_04FE75;
L_04FE75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE75u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE75u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE75 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04FE77;
L_04FE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE77u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE77u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE77 BCS -> $04FE7B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_04FE7B; }
    goto L_04FE79;
L_04FE79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE79u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE79u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE79 DEC
    cpu.decMem(hw, cpu.address("dp", 0x3u), cpu.m8?8:16);
    goto L_04FE7B;
L_04FE7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE7Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE7B LDY
    cpu.setY(0x0u, 8);
    goto L_04FE7D;
L_04FE7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE7Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE7Du, 4u + ((((0x0E65u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE7D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FE80;
L_04FE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE80u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE80u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE80 XBA
    cpu.xba();
    goto L_04FE81;
L_04FE81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE81u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE81u, 4u + ((((0x0E35u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE81 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE35u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FE84;
L_04FE84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE84u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE84u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE84 REP
    cpu.rep(0x20u);
    goto L_04FE86;
L_04FE86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE86u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE86u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE86 SEC
    cpu.setFlag('C', true);
    goto L_04FE87;
L_04FE87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE87u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE87u, 5u + ((((0x001Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x001Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE87 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1Au), cpu.m8?8:16));
    goto L_04FE8A;
L_04FE8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Au, 6u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE8A STA
    hw.write(cpu.address("absy", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04FE8D;
L_04FE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE8D SEP
    cpu.sep(0x20u);
    goto L_04FE8F;
L_04FE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FE8F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FE8Fu);return;} hw.unresolvedReturn(0x04FE8Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_05D796_E0M1X1CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05DA14u: goto L_05DA14;
    case 0x05DA17u: goto L_05DA17;
    case 0x05DA19u: goto L_05DA19;
    case 0x05DA1Cu: goto L_05DA1C;
    case 0x05DA1Eu: goto L_05DA1E;
    case 0x05DA20u: goto L_05DA20;
    case 0x05DA22u: goto L_05DA22;
    case 0x05DA24u: goto L_05DA24;
    case 0x05DA26u: goto L_05DA26;
    case 0x05DA28u: goto L_05DA28;
    case 0x05DA2Au: goto L_05DA2A;
    case 0x05DA2Cu: goto L_05DA2C;
    case 0x05DA30u: goto L_05DA30;
    case 0x05DA32u: goto L_05DA32;
    case 0x05DA33u: goto L_05DA33;
    case 0x05DA35u: goto L_05DA35;
    case 0x05DA38u: goto L_05DA38;
    case 0x05DA3Bu: goto L_05DA3B;
    case 0x05DA3Du: goto L_05DA3D;
    case 0x05DA40u: goto L_05DA40;
    case 0x05DA42u: goto L_05DA42;
    case 0x05DA45u: goto L_05DA45;
    case 0x05DA47u: goto L_05DA47;
    case 0x05DA4Au: goto L_05DA4A;
    case 0x05DA4Cu: goto L_05DA4C;
    case 0x05DA4Eu: goto L_05DA4E;
    case 0x05DA50u: goto L_05DA50;
    case 0x05DA52u: goto L_05DA52;
    case 0x05DA54u: goto L_05DA54;
    case 0x05DA56u: goto L_05DA56;
    case 0x05DA58u: goto L_05DA58;
    case 0x05DA5Au: goto L_05DA5A;
    case 0x05DA5Cu: goto L_05DA5C;
    case 0x05DA5Eu: goto L_05DA5E;
    case 0x05DA60u: goto L_05DA60;
    case 0x05DA63u: goto L_05DA63;
    case 0x05DA65u: goto L_05DA65;
    case 0x05DA69u: goto L_05DA69;
    case 0x05DA6Bu: goto L_05DA6B;
    case 0x05DA6Du: goto L_05DA6D;
    case 0x05DA6Fu: goto L_05DA6F;
    case 0x05DA71u: goto L_05DA71;
    case 0x05DA73u: goto L_05DA73;
    case 0x05DA75u: goto L_05DA75;
    case 0x05DA77u: goto L_05DA77;
    case 0x05DA79u: goto L_05DA79;
    case 0x05DA7Bu: goto L_05DA7B;
    case 0x05DA7Eu: goto L_05DA7E;
    case 0x05DA80u: goto L_05DA80;
    case 0x05DA82u: goto L_05DA82;
    case 0x05DA84u: goto L_05DA84;
    case 0x05DA86u: goto L_05DA86;
    case 0x05DA88u: goto L_05DA88;
    case 0x05DA8Au: goto L_05DA8A;
    case 0x05DA8Cu: goto L_05DA8C;
    case 0x05DA8Eu: goto L_05DA8E;
    case 0x05DA91u: goto L_05DA91;
    case 0x05DA93u: goto L_05DA93;
    case 0x05DA95u: goto L_05DA95;
    case 0x05DA98u: goto L_05DA98;
    case 0x05DA9Bu: goto L_05DA9B;
    case 0x05DA9Eu: goto L_05DA9E;
    case 0x05DAA1u: goto L_05DAA1;
    case 0x05DAA3u: goto L_05DAA3;
    case 0x05DAA7u: goto L_05DAA7;
    case 0x05DAAAu: goto L_05DAAA;
    case 0x05DAACu: goto L_05DAAC;
    case 0x05DAADu: goto L_05DAAD;
    case 0x05DAAEu: goto L_05DAAE;
    case 0x05DAAFu: goto L_05DAAF;
    case 0x05DAB1u: goto L_05DAB1;
    case 0x05DAB2u: goto L_05DAB2;
    case 0x05DAB5u: goto L_05DAB5;
    case 0x05DAB7u: goto L_05DAB7;
    case 0x05DABAu: goto L_05DABA;
    case 0x05DABCu: goto L_05DABC;
    case 0x05DABFu: goto L_05DABF;
    case 0x05DAC1u: goto L_05DAC1;
    case 0x05DAC4u: goto L_05DAC4;
    case 0x05DAC6u: goto L_05DAC6;
    case 0x05DAC9u: goto L_05DAC9;
    case 0x05DACBu: goto L_05DACB;
    case 0x05DACEu: goto L_05DACE;
    case 0x05DAD0u: goto L_05DAD0;
    case 0x05DAD4u: goto L_05DAD4;
    case 0x05DAD7u: goto L_05DAD7;
    case 0x05DADAu: goto L_05DADA;
    case 0x05DADCu: goto L_05DADC;
    case 0x05DADFu: goto L_05DADF;
    case 0x05DAE1u: goto L_05DAE1;
    case 0x05DAE4u: goto L_05DAE4;
    case 0x05DAE6u: goto L_05DAE6;
    case 0x05DAE8u: goto L_05DAE8;
    case 0x05DAEBu: goto L_05DAEB;
    case 0x05DAECu: goto L_05DAEC;
    case 0x05DAEEu: goto L_05DAEE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05DA14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA14u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA14u, 4u, 3u, cpu.address("abs", 0x1412u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA14 STA
    hw.write(cpu.address("abs", 0x1412u), cpu.a, cpu.m8?8:16);
    goto L_05DA17;
L_05DA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA17u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA17u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA17u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA17 SEP
    cpu.sep(0x30u);
    goto L_05DA19;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA17u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA17u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA17 SEP
    cpu.sep(0x30u);
    goto L_05DA19;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA17u,0x05DA17u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05DA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA19u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA19u, 4u, 3u, cpu.address("abs", 0x13BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA19 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13BFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DA1C;
L_05DA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA1C CMP
    cpu.compareA(0x52u);
    goto L_05DA1E;
L_05DA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA1E BCC -> $05DA24
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_05DA24; }
    goto L_05DA20;
L_05DA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA20u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA20 LDX
    cpu.setX(0x3u, 8);
    goto L_05DA22;
L_05DA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA22u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA22u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA22 BRA -> $05DA38
    goto L_05DA38;
L_05DA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA24u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA24 LDX
    cpu.setX(0x4u, 8);
    goto L_05DA26;
L_05DA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA26u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA26 LDY
    cpu.setY(0x4u, 8);
    goto L_05DA28;
L_05DA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA28u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA28u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $05DA28 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DA2A;
L_05DA2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA2A AND
    cpu.logicAnd(0xFu);
    goto L_05DA2C;
L_05DA2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Cu,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Cu, 5u, 4u, ((0x05D760u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA2C CMP
    cpu.compareA(hw.readW(((0x5D760u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_05DA30;
L_05DA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA30u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA30u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA30 BEQ -> $05DA38
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05DA38; }
    goto L_05DA32;
L_05DA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA32u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA32 DEX
    cpu.decReg('X');
    goto L_05DA33;
L_05DA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA33u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA33 BPL -> $05DA2C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_05DA2C; }
    goto L_05DA35;
L_05DA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA35u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA35u, 3u, 3u, cpu.address("abs", 0xDAD7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA35 JMP -> $05DAD7
    goto L_05DAD7;
L_05DA38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA38u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA38u, 4u, 3u, cpu.address("abs", 0x141Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA38 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DA3B;
L_05DA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA3B BNE -> $05DA35
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05DA35; }
    goto L_05DA3D;
L_05DA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Du, 4u, 3u, cpu.address("abs", 0x141Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA3D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DA40;
L_05DA40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA40u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA40 BNE -> $05DA35
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05DA35; }
    goto L_05DA42;
L_05DA42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA42u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA42u, 4u, 3u, cpu.address("abs", 0x141Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA42 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DA45;
L_05DA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA45u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA45 BNE -> $05DA35
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05DA35; }
    goto L_05DA47;
L_05DA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA47u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA47u, 4u, 3u, cpu.address("abs", 0x13BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA47 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13BFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DA4A;
L_05DA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA4A CMP
    cpu.compareA(0x31u);
    goto L_05DA4C;
L_05DA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA4C BEQ -> $05DA5E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05DA5E; }
    goto L_05DA4E;
L_05DA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA4E CMP
    cpu.compareA(0x32u);
    goto L_05DA50;
L_05DA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA50u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA50 BEQ -> $05DA5E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05DA5E; }
    goto L_05DA52;
L_05DA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA52u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA52u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA52 CMP
    cpu.compareA(0x34u);
    goto L_05DA54;
L_05DA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA54u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA54 BEQ -> $05DA5E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05DA5E; }
    goto L_05DA56;
L_05DA56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA56u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA56 CMP
    cpu.compareA(0x35u);
    goto L_05DA58;
L_05DA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA58u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA58 BEQ -> $05DA5E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05DA5E; }
    goto L_05DA5A;
L_05DA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA5A CMP
    cpu.compareA(0x40u);
    goto L_05DA5C;
L_05DA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA5C BNE -> $05DA60
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05DA60; }
    goto L_05DA5E;
L_05DA5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA5E LDX
    cpu.setX(0x5u, 8);
    goto L_05DA60;
L_05DA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA60u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA60u, 4u, 3u, cpu.address("abs", 0x13CFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA60 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13CFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DA63;
L_05DA63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA63u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA63 BNE -> $05DAD0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05DAD0; }
    goto L_05DA65;
L_05DA65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA65u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA65u, 5u, 4u, ((0x05D790u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA65 LDA
    cpu.loadA(hw.readW(((0x5D790u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DA69;
L_05DA69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA69u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA69u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA69 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_05DA6B;
L_05DA6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA6B LDA
    cpu.setA(0x1u, 8);
    goto L_05DA6D;
L_05DA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA6D STA
    hw.write(cpu.address("dp", 0x97u), cpu.a, cpu.m8?8:16);
    goto L_05DA6F;
L_05DA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA6F LDA
    cpu.setA(0x30u, 8);
    goto L_05DA71;
L_05DA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA71u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA71u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA71 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_05DA73;
L_05DA73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA73u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA73u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA73 STZ
    hw.write(cpu.address("dp", 0x95u), 0, cpu.m8?8:16);
    goto L_05DA75;
L_05DA75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA75u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA75 LDA
    cpu.setA(0xC0u, 8);
    goto L_05DA77;
L_05DA77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA77u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA77u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA77 STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_05DA79;
L_05DA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA79u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA79u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA79 STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_05DA7B;
L_05DA7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Bu, 4u, 3u, cpu.address("abs", 0x192Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA7B STZ
    hw.write(cpu.address("abs", 0x192Au), 0, cpu.m8?8:16);
    goto L_05DA7E;
L_05DA7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA7E LDA
    cpu.setA(0xEEu, 8);
    goto L_05DA80;
L_05DA80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA80u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA80u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA80 STA
    hw.write(cpu.address("dp", 0xCEu), cpu.a, cpu.m8?8:16);
    goto L_05DA82;
L_05DA82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA82u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA82 LDA
    cpu.setA(0xC3u, 8);
    goto L_05DA84;
L_05DA84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA84u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA84u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA84 STA
    hw.write(cpu.address("dp", 0xCFu), cpu.a, cpu.m8?8:16);
    goto L_05DA86;
L_05DA86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA86u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA86u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA86 LDA
    cpu.setA(0x7u, 8);
    goto L_05DA88;
L_05DA88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA88u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA88u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA88 STA
    hw.write(cpu.address("dp", 0xD0u), cpu.a, cpu.m8?8:16);
    goto L_05DA8A;
L_05DA8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Au,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xCEu) & 0xFFFFu), 3u, 0u);
    // $05DA8A LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0xCEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DA8C;
L_05DA8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA8C AND
    cpu.logicAnd(0x3Fu);
    goto L_05DA8E;
L_05DA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Eu, 4u, 3u, cpu.address("abs", 0x1692u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA8E STA
    hw.write(cpu.address("abs", 0x1692u), cpu.a, cpu.m8?8:16);
    goto L_05DA91;
L_05DA91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA91u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA91u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xCEu) & 0xFFFFu), 3u, 0u);
    // $05DA91 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0xCEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DA93;
L_05DA93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA93u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA93 AND
    cpu.logicAnd(0xC0u);
    goto L_05DA95;
L_05DA95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA95u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA95u, 4u, 3u, cpu.address("abs", 0x190Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA95 STA
    hw.write(cpu.address("abs", 0x190Eu), cpu.a, cpu.m8?8:16);
    goto L_05DA98;
L_05DA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA98u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA98u, 4u, 3u, cpu.address("abs", 0x1413u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA98 STZ
    hw.write(cpu.address("abs", 0x1413u), 0, cpu.m8?8:16);
    goto L_05DA9B;
L_05DA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Bu, 4u, 3u, cpu.address("abs", 0x1414u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA9B STZ
    hw.write(cpu.address("abs", 0x1414u), 0, cpu.m8?8:16);
    goto L_05DA9E;
L_05DA9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Eu, 4u, 3u, cpu.address("abs", 0x1411u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DA9E STZ
    hw.write(cpu.address("abs", 0x1411u), 0, cpu.m8?8:16);
    goto L_05DAA1;
L_05DAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA1u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAA1 STZ
    hw.write(cpu.address("dp", 0x5Bu), 0, cpu.m8?8:16);
    goto L_05DAA3;
L_05DAA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA3u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA3u, 5u, 4u, ((0x05D78Au + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAA3 LDA
    cpu.loadA(hw.readW(((0x5D78Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DAA7;
L_05DAA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA7u, 4u, 3u, cpu.address("abs", 0x1BE3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAA7 STA
    hw.write(cpu.address("abs", 0x1BE3u), cpu.a, cpu.m8?8:16);
    goto L_05DAAA;
L_05DAAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAAAu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAAAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAAA STX
    hw.write(cpu.address("dp", 0x0u), cpu.x, cpu.x8?8:16);
    goto L_05DAAC;
L_05DAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAACu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAAC TXA
    cpu.transfer("TXA");
    goto L_05DAAD;
L_05DAAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAADu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAAD ASL
    cpu.aslA();
    goto L_05DAAE;
L_05DAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAAEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAAE CLC
    cpu.setFlag('C', false);
    goto L_05DAAF;
L_05DAAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAAFu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAAFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAAF ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_05DAB1;
L_05DAB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAB1 TAY
    cpu.transfer("TAY");
    goto L_05DAB2;
L_05DAB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB2u, 4u + ((((0xD766u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD766u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAB2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD766u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DAB5;
L_05DAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAB5 STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_05DAB7;
L_05DAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB7u, 4u + ((((0xD767u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD767u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAB7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD767u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DABA;
L_05DABA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDABAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDABAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDABAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DABA STA
    hw.write(cpu.address("dp", 0x66u), cpu.a, cpu.m8?8:16);
    goto L_05DABC;
L_05DABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDABCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDABCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDABCu, 4u + ((((0xD768u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD768u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DABC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD768u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DABF;
L_05DABF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDABFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDABFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDABFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DABF STA
    hw.write(cpu.address("dp", 0x67u), cpu.a, cpu.m8?8:16);
    goto L_05DAC1;
L_05DAC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAC1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAC1u, 4u + ((((0xD778u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD778u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAC1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD778u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DAC4;
L_05DAC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAC4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAC4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x68u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAC4 STA
    hw.write(cpu.address("dp", 0x68u), cpu.a, cpu.m8?8:16);
    goto L_05DAC6;
L_05DAC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAC6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAC6u, 4u + ((((0xD779u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD779u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAC6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD779u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DAC9;
L_05DAC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAC9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAC9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAC9 STA
    hw.write(cpu.address("dp", 0x69u), cpu.a, cpu.m8?8:16);
    goto L_05DACB;
L_05DACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDACBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDACBu, 4u + ((((0xD77Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD77Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DACB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD77Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DACE;
L_05DACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDACEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDACEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDACEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DACE STA
    hw.write(cpu.address("dp", 0x6Au), cpu.a, cpu.m8?8:16);
    goto L_05DAD0;
L_05DAD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD0u, 5u, 4u, ((0x05D760u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAD0 LDA
    cpu.loadA(hw.readW(((0x5D760u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DAD4;
L_05DAD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD4u, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAD4 STA
    hw.write(cpu.address("abs", 0x1931u), cpu.a, cpu.m8?8:16);
    goto L_05DAD7;
L_05DAD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD7u, 4u, 3u, cpu.address("abs", 0x141Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAD7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DADA;
L_05DADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDADAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDADAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DADA BEQ -> $05DAEB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05DAEB; }
    goto L_05DADC;
L_05DADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDADCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDADCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDADCu, 4u, 3u, cpu.address("abs", 0x1425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DADC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1425u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DADF;
L_05DADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDADFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDADFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DADF BNE -> $05DAEB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05DAEB; }
    goto L_05DAE1;
L_05DAE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE1u, 4u, 3u, cpu.address("abs", 0x13BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAE1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13BFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05DAE4;
L_05DAE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAE4 CMP
    cpu.compareA(0x24u);
    goto L_05DAE6;
L_05DAE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAE6 BNE -> $05DAEB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05DAEB; }
    goto L_05DAE8;
L_05DAE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE8u, 6u, 3u, cpu.address("abs", 0xDAEFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05DAE8 JSR -> $05DAEF stack real
    { cpu.push16Value(hw,0xDAEAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDAEBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDAEFu), 0x05DAE8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05DAEB;
L_05DAEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAEBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDAEBu,0x05DAEBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAEBu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAEBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05DAEB PLB
    cpu.pop("PLB", hw);
    goto L_05DAEC;
L_05DAEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAECu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAECu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05DAEC SEP
    cpu.sep(0x30u);
    goto L_05DAEE;
L_05DAEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAEEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAEEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05DAEE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x05DAEEu);return;} hw.unresolvedReturn(0x05DAEEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0DAEFC_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DAEFCu: goto L_0DAEFC;
    case 0x0DAEFEu: goto L_0DAEFE;
    case 0x0DAF00u: goto L_0DAF00;
    case 0x0DAF01u: goto L_0DAF01;
    case 0x0DAF02u: goto L_0DAF02;
    case 0x0DAF03u: goto L_0DAF03;
    case 0x0DAF04u: goto L_0DAF04;
    case 0x0DAF06u: goto L_0DAF06;
    case 0x0DAF07u: goto L_0DAF07;
    case 0x0DAF09u: goto L_0DAF09;
    case 0x0DAF0Bu: goto L_0DAF0B;
    case 0x0DAF0Du: goto L_0DAF0D;
    case 0x0DAF0Fu: goto L_0DAF0F;
    case 0x0DAF12u: goto L_0DAF12;
    case 0x0DAF14u: goto L_0DAF14;
    case 0x0DAF17u: goto L_0DAF17;
    case 0x0DAF1Au: goto L_0DAF1A;
    case 0x0DAF1Cu: goto L_0DAF1C;
    case 0x0DAF1Fu: goto L_0DAF1F;
    case 0x0DAF20u: goto L_0DAF20;
    case 0x0DAF22u: goto L_0DAF22;
    case 0x0DAF24u: goto L_0DAF24;
    case 0x0DAF26u: goto L_0DAF26;
    case 0x0DAF28u: goto L_0DAF28;
    case 0x0DAF2Bu: goto L_0DAF2B;
    case 0x0DAF2Du: goto L_0DAF2D;
    case 0x0DAF30u: goto L_0DAF30;
    case 0x0DAF33u: goto L_0DAF33;
    case 0x0DAF35u: goto L_0DAF35;
    case 0x0DAF38u: goto L_0DAF38;
    case 0x0DAF3Au: goto L_0DAF3A;
    case 0x0DAF3Cu: goto L_0DAF3C;
    case 0x0DAF3Fu: goto L_0DAF3F;
    case 0x0DAF41u: goto L_0DAF41;
    case 0x0DAF44u: goto L_0DAF44;
    case 0x0DAF47u: goto L_0DAF47;
    case 0x0DAF49u: goto L_0DAF49;
    case 0x0DAF4Cu: goto L_0DAF4C;
    case 0x0DAF4Fu: goto L_0DAF4F;
    case 0x0DAF51u: goto L_0DAF51;
    case 0x0DAF52u: goto L_0DAF52;
    case 0x0DAF54u: goto L_0DAF54;
    case 0x0DAF56u: goto L_0DAF56;
    case 0x0DAF57u: goto L_0DAF57;
    case 0x0DAF59u: goto L_0DAF59;
    case 0x0DAF5Cu: goto L_0DAF5C;
    case 0x0DAF5Eu: goto L_0DAF5E;
    case 0x0DAF60u: goto L_0DAF60;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DAEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFCu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAEFC LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DAEFE;
L_0DAEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAEFE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DAF00;
L_0DAF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF00u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF00u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF00 LSR
    cpu.lsrA();
    goto L_0DAF01;
L_0DAF01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF01u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF01u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF01 LSR
    cpu.lsrA();
    goto L_0DAF02;
L_0DAF02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF02u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF02 LSR
    cpu.lsrA();
    goto L_0DAF03;
L_0DAF03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF03u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF03 LSR
    cpu.lsrA();
    goto L_0DAF04;
L_0DAF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF04u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF04u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF04 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DAF06;
L_0DAF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF06u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF06 ASL
    cpu.aslA();
    goto L_0DAF07;
L_0DAF07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF07u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF07u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF07 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DAF09;
L_0DAF09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF09u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF09u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF09 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DAF0B;
L_0DAF0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF0B LDA
    cpu.setA(0x0u, 8);
    goto L_0DAF0D;
L_0DAF0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF0D STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DAF0F;
L_0DAF0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Fu, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAF0F JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xAF11u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF12u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DAF0Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DAF12;
L_0DAF12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF12u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF12u,0x0DAF12u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF12u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF12u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF12 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DAF14;
L_0DAF14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF14u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF14u, 3u, 3u, cpu.address("abs", 0xAF20u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF14 JMP -> $0DAF20
    goto L_0DAF20;
L_0DAF17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF17u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF17u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAF17 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xAF19u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF1Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DAF17u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DAF1A;
L_0DAF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF1Au,0x0DAF1Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF1A LDA
    cpu.setA(0x65u, 8);
    goto L_0DAF1C;
L_0DAF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAF1C JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xAF1Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF1Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DAF1Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DAF1F;
L_0DAF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF1Fu,0x0DAF1Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF1F DEX
    cpu.decReg('X');
    goto L_0DAF20;
L_0DAF20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF20u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF20 CPX
    cpu.compareX(0x4u);
    goto L_0DAF22;
L_0DAF22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF22u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF22 BPL -> $0DAF17
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DAF17; }
    goto L_0DAF24;
L_0DAF24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF24u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF24 CPX
    cpu.compareX(0x2u);
    goto L_0DAF26;
L_0DAF26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF26u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF26 BMI -> $0DAF3C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DAF3C; }
    goto L_0DAF28;
L_0DAF28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF28u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF28u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAF28 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xAF2Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF2Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DAF28u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DAF2B;
L_0DAF2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF2Bu,0x0DAF2Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF2B LDA
    cpu.setA(0xF0u, 8);
    goto L_0DAF2D;
L_0DAF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAF2D JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xAF2Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF30u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DAF2Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DAF30;
L_0DAF30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF30u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF30u,0x0DAF30u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF30u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF30u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAF30 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xAF32u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF33u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DAF30u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DAF33;
L_0DAF33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF33u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF33u,0x0DAF33u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF33u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF33 LDA
    cpu.setA(0xEFu, 8);
    goto L_0DAF35;
L_0DAF35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF35u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF35u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAF35 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xAF37u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF38u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DAF35u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DAF38;
L_0DAF38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF38u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF38u,0x0DAF38u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF38u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF38u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF38 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DAF3A;
L_0DAF3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF3A BEQ -> $0DAF4C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DAF4C; }
    goto L_0DAF3C;
L_0DAF3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Cu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAF3C JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xAF3Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF3Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DAF3Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DAF3F;
L_0DAF3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF3Fu,0x0DAF3Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF3F LDA
    cpu.setA(0xC8u, 8);
    goto L_0DAF41;
L_0DAF41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF41u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF41u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAF41 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xAF43u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF44u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DAF41u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DAF44;
L_0DAF44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF44u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF44u,0x0DAF44u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF44u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF44u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAF44 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xAF46u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF47u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DAF44u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DAF47;
L_0DAF47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF47u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF47u,0x0DAF47u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF47 LDA
    cpu.setA(0xC9u, 8);
    goto L_0DAF49;
L_0DAF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF49u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF49u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAF49 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xAF4Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF4Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DAF49u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DAF4C;
L_0DAF4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF4Cu,0x0DAF4Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Cu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAF4C JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xAF4Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF4Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DAF4Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DAF4F;
L_0DAF4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF4Fu,0x0DAF4Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF4F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DAF51;
L_0DAF51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF51u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF51 SEC
    cpu.setFlag('C', true);
    goto L_0DAF52;
L_0DAF52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF52u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF52u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF52 SBC
    cpu.sbc(0x2u);
    goto L_0DAF54;
L_0DAF54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF54u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF54u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF54 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DAF56;
L_0DAF56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF56u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF56u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF56 TAX
    cpu.transfer("TAX");
    goto L_0DAF57;
L_0DAF57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF57u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF57u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF57 INC
    cpu.incMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DAF59;
L_0DAF59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF59u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF59u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAF59 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xAF5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF5Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DAF59u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DAF5C;
L_0DAF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF5Cu,0x0DAF5Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF5C DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DAF5E;
L_0DAF5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAF5E BPL -> $0DAF20
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DAF20; }
    goto L_0DAF60;
L_0DAF60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF60u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAF60 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DAF60u);return;} hw.unresolvedReturn(0x0DAF60u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB114_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB114u: goto L_0DB114;
    case 0x0DB116u: goto L_0DB116;
    case 0x0DB118u: goto L_0DB118;
    case 0x0DB11Au: goto L_0DB11A;
    case 0x0DB11Cu: goto L_0DB11C;
    case 0x0DB11Eu: goto L_0DB11E;
    case 0x0DB120u: goto L_0DB120;
    case 0x0DB122u: goto L_0DB122;
    case 0x0DB124u: goto L_0DB124;
    case 0x0DB126u: goto L_0DB126;
    case 0x0DB128u: goto L_0DB128;
    case 0x0DB12Au: goto L_0DB12A;
    case 0x0DB12Cu: goto L_0DB12C;
    case 0x0DB130u: goto L_0DB130;
    case 0x0DB132u: goto L_0DB132;
    case 0x0DB133u: goto L_0DB133;
    case 0x0DB135u: goto L_0DB135;
    case 0x0DB137u: goto L_0DB137;
    case 0x0DB139u: goto L_0DB139;
    case 0x0DB13Bu: goto L_0DB13B;
    case 0x0DB13Du: goto L_0DB13D;
    case 0x0DB13Fu: goto L_0DB13F;
    case 0x0DB141u: goto L_0DB141;
    case 0x0DB143u: goto L_0DB143;
    case 0x0DB145u: goto L_0DB145;
    case 0x0DB147u: goto L_0DB147;
    case 0x0DB149u: goto L_0DB149;
    case 0x0DB14Bu: goto L_0DB14B;
    case 0x0DB14Du: goto L_0DB14D;
    case 0x0DB14Fu: goto L_0DB14F;
    case 0x0DB152u: goto L_0DB152;
    case 0x0DB155u: goto L_0DB155;
    case 0x0DB159u: goto L_0DB159;
    case 0x0DB15Bu: goto L_0DB15B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB114u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB114u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB114 CPX
    cpu.compareX(0x3u);
    goto L_0DB116;
L_0DB116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB116u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB116u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB116 BMI -> $0DB120
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB120; }
    goto L_0DB118;
L_0DB118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB118u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB118u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB118 CPX
    cpu.compareX(0x9u);
    goto L_0DB11A;
L_0DB11A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Au,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB11A BMI -> $0DB120
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB120; }
    goto L_0DB11C;
L_0DB11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Cu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB11C CPX
    cpu.compareX(0xBu);
    goto L_0DB11E;
L_0DB11E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB11E BMI -> $0DB15B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB15B; }
    goto L_0DB120;
L_0DB120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB120u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB120u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB120 CPX
    cpu.compareX(0x2u);
    goto L_0DB122;
L_0DB122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB122u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB122u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB122 BEQ -> $0DB15B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB15B; }
    goto L_0DB124;
L_0DB124:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB124u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB124u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB124u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB124 STX
    hw.write(cpu.address("dp", 0xBu), cpu.x, cpu.x8?8:16);
    goto L_0DB126;
L_0DB126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB126u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB126u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB126 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_0DB128;
L_0DB128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB128u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB128u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB128 LDX
    cpu.setX(0x11u, 8);
    goto L_0DB12A;
L_0DB12A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB12Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Au,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB12A LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB12C;
L_0DB12C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB12Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Cu,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Cu, 5u, 4u, ((0x0DB0F0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB12C CMP
    cpu.compareA(hw.readW(((0xDB0F0u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DB130;
L_0DB130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB130u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB130u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB130 BEQ -> $0DB152
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB152; }
    goto L_0DB132;
L_0DB132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB132u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB132u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB132u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB132 DEX
    cpu.decReg('X');
    goto L_0DB133;
L_0DB133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB133u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB133u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB133 BPL -> $0DB12C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB12C; }
    goto L_0DB135;
L_0DB135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB135u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB135u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB135u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB135 CMP
    cpu.compareA(0x25u);
    goto L_0DB137;
L_0DB137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB137u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB137u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB137 BEQ -> $0DB14D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB14D; }
    goto L_0DB139;
L_0DB139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB139u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB139u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB139 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB13B;
L_0DB13B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB13B CMP
    cpu.compareA(0x1u);
    goto L_0DB13D;
L_0DB13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB13D BEQ -> $0DB14B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB14B; }
    goto L_0DB13F;
L_0DB13F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB13F CMP
    cpu.compareA(0x3u);
    goto L_0DB141;
L_0DB141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB141u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB141u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB141 BEQ -> $0DB14B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB14B; }
    goto L_0DB143;
L_0DB143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB143u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB143u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB143 CMP
    cpu.compareA(0x45u);
    goto L_0DB145;
L_0DB145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB145u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB145u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB145 BEQ -> $0DB14B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB14B; }
    goto L_0DB147;
L_0DB147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB147u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB147u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB147 CMP
    cpu.compareA(0x48u);
    goto L_0DB149;
L_0DB149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB149u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB149u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB149 BNE -> $0DB14D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB14D; }
    goto L_0DB14B;
L_0DB14B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB14B INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_0DB14D;
L_0DB14D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB14D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB14F;
L_0DB14F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Fu, 3u, 3u, cpu.address("abs", 0xB159u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB14F JMP -> $0DB159
    goto L_0DB159;
L_0DB152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB152u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB152u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB152 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xB154u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB155u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DB152u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB155;
L_0DB155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB155u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB155u,0x0DB155u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB155u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB155u, 5u, 4u, ((0x0DB102u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB155 LDA
    cpu.loadA(hw.readW(((0xDB102u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB159;
L_0DB159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB159u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB159u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB159 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xBu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB15B;
L_0DB15B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB15Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB15B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB15Bu);return;} hw.unresolvedReturn(0x0DB15Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DDD5C_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DDD5Cu: goto L_0DDD5C;
    case 0x0DDD5Eu: goto L_0DDD5E;
    case 0x0DDD60u: goto L_0DDD60;
    case 0x0DDD61u: goto L_0DDD61;
    case 0x0DDD62u: goto L_0DDD62;
    case 0x0DDD63u: goto L_0DDD63;
    case 0x0DDD64u: goto L_0DDD64;
    case 0x0DDD66u: goto L_0DDD66;
    case 0x0DDD68u: goto L_0DDD68;
    case 0x0DDD6Au: goto L_0DDD6A;
    case 0x0DDD6Cu: goto L_0DDD6C;
    case 0x0DDD6Fu: goto L_0DDD6F;
    case 0x0DDD71u: goto L_0DDD71;
    case 0x0DDD74u: goto L_0DDD74;
    case 0x0DDD76u: goto L_0DDD76;
    case 0x0DDD79u: goto L_0DDD79;
    case 0x0DDD7Au: goto L_0DDD7A;
    case 0x0DDD7Cu: goto L_0DDD7C;
    case 0x0DDD7Fu: goto L_0DDD7F;
    case 0x0DDD82u: goto L_0DDD82;
    case 0x0DDD84u: goto L_0DDD84;
    case 0x0DDD86u: goto L_0DDD86;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DDD5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD5Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD5Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD5C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DDD5E;
L_0DDD5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD5Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD5Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD5E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDD60;
L_0DDD60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD60u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD60u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD60 LSR
    cpu.lsrA();
    goto L_0DDD61;
L_0DDD61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD61u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD61u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD61 LSR
    cpu.lsrA();
    goto L_0DDD62;
L_0DDD62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD62u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD62 LSR
    cpu.lsrA();
    goto L_0DDD63;
L_0DDD63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD63u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD63u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD63 LSR
    cpu.lsrA();
    goto L_0DDD64;
L_0DDD64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD64u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD64u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD64 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DDD66;
L_0DDD66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD66u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD66u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD66 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDD68;
L_0DDD68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD68u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD68 AND
    cpu.logicAnd(0xFu);
    goto L_0DDD6A;
L_0DDD6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD6Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD6Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD6A STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DDD6C;
L_0DDD6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD6Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD6Cu, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDD6C JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xDD6Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD6Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DDD6Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDD6F;
L_0DDD6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD6Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD6Fu,0x0DDD6Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD6Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD6Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD6F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DDD71;
L_0DDD71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD71u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD71u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDD71 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDD73u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD74u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDD71u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDD74;
L_0DDD74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD74u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD74u,0x0DDD74u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD74u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD74 LDA
    cpu.setA(0x65u, 8);
    goto L_0DDD76;
L_0DDD76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD76u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD76u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDD76 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xDD78u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD79u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DDD76u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDD79;
L_0DDD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD79u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD79u,0x0DDD79u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD79u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD79u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD79 DEX
    cpu.decReg('X');
    goto L_0DDD7A;
L_0DDD7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD7Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD7A BPL -> $0DDD71
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DDD71; }
    goto L_0DDD7C;
L_0DDD7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD7Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD7Cu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDD7C JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xDD7Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD7Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DDD7Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDD7F;
L_0DDD7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD7Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD7Fu,0x0DDD7Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD7Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD7Fu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDD7F JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xDD81u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD82u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DDD7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDD82;
L_0DDD82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD82u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD82u,0x0DDD82u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD82u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD82u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD82 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DDD84;
L_0DDD84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD84u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDD84 BPL -> $0DDD6F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DDD6F; }
    goto L_0DDD86;
L_0DDD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD86u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD86u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDD86 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DDD86u);return;} hw.unresolvedReturn(0x0DDD86u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_AE8DD6_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xAE8DD6u: goto L_AE8DD6;
    case 0xAE8DD7u: goto L_AE8DD7;
    case 0xAE8DD9u: goto L_AE8DD9;
    case 0xAE8DDAu: goto L_AE8DDA;
    case 0xAE8DDBu: goto L_AE8DDB;
    case 0xAE8DDDu: goto L_AE8DDD;
    case 0xAE8DE0u: goto L_AE8DE0;
    case 0xAE8DE2u: goto L_AE8DE2;
    case 0xAE8DE4u: goto L_AE8DE4;
    case 0xAE8DE6u: goto L_AE8DE6;
    case 0xAE8DE8u: goto L_AE8DE8;
    case 0xAE8DEAu: goto L_AE8DEA;
    case 0xAE8DECu: goto L_AE8DEC;
    case 0xAE8DEFu: goto L_AE8DEF;
    case 0xAE8DF0u: goto L_AE8DF0;
    case 0xAE8DF3u: goto L_AE8DF3;
    case 0xAE8DF4u: goto L_AE8DF4;
    case 0xAE8DF8u: goto L_AE8DF8;
    case 0xAE8DFAu: goto L_AE8DFA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_AE8DD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DD6 INY
    cpu.inc('Y');
    goto L_AE8DD7;
L_AE8DD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD7u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DD7 ASL
    cpu.aslMem(hw, cpu.address("dp", 0xD0u), cpu.m8?8:16);
    goto L_AE8DD9;
L_AE8DD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD9u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DD9 SED
    cpu.setFlag('D', true);
    goto L_AE8DDA;
L_AE8DDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDAu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DDA XBA
    cpu.xba();
    goto L_AE8DDB;
L_AE8DDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDBu,cpu,0x16u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDBu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DDB ASL
    cpu.aslMem(hw, cpu.address("dpx", 0x6Fu), cpu.m8?8:16);
    goto L_AE8DDD;
L_AE8DDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDDu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDDu, 4u + ((((0xBD10u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xBD10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DDD LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xBD10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_AE8DE0;
L_AE8DE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE0u,cpu,0x11u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xCBu) & 0xFFFFu), 2u, 0u);
    // $AE8DE0 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectY(hw, 0xCBu), cpu.m8?8:16));
    goto L_AE8DE2;
L_AE8DE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE2u,cpu,0x12u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xE9u) & 0xFFFFu), 2u, 0u);
    // $AE8DE2 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirect(hw, 0xE9u), cpu.m8?8:16));
    goto L_AE8DE4;
L_AE8DE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE4u,cpu,0x13u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE4u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x18u) & 0xFFFFu), 2u, 0u);
    // $AE8DE4 ORA
    cpu.logicOr(hw.readW(cpu.addressStackIndirectY(hw, 0x18u), cpu.m8?8:16));
    goto L_AE8DE6;
L_AE8DE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DE6 ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0x59u), cpu.m8?8:16));
    goto L_AE8DE8;
L_AE8DE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE8u,cpu,0x16u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xADu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DE8 ASL
    cpu.aslMem(hw, cpu.address("dpx", 0xADu), cpu.m8?8:16);
    goto L_AE8DEA;
L_AE8DEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEAu,cpu,0x17u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEAu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x16u) & 0xFFFFu), 3u, 0u);
    // $AE8DEA ORA
    cpu.logicOr(hw.readW(cpu.addressDpLongY(hw, 0x16u), cpu.m8?8:16));
    goto L_AE8DEC;
L_AE8DEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DECu,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DECu, 4u + ((((0x1A94u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1A94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DEC ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x1A94u), cpu.m8?8:16));
    goto L_AE8DEF;
L_AE8DEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $AE8DEF PLP
    cpu.pop("PLP", hw);
    goto L_AE8DF0;
L_AE8DF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF0u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u, 8u, 3u, cpu.address("abs", 0x1DD5u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF0 TRB
    cpu.trb(hw, cpu.address("abs", 0x1DD5u), cpu.m8?8:16);
    goto L_AE8DF3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u, 8u, 3u, cpu.address("abs", 0x1DD5u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF0 TRB
    cpu.trb(hw, cpu.address("abs", 0x1DD5u), cpu.m8?8:16);
    goto L_AE8DF3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u, 6u, 3u, cpu.address("abs", 0x1DD5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF0 TRB
    cpu.trb(hw, cpu.address("abs", 0x1DD5u), cpu.m8?8:16);
    goto L_AE8DF3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u, 6u, 3u, cpu.address("abs", 0x1DD5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF0 TRB
    cpu.trb(hw, cpu.address("abs", 0x1DD5u), cpu.m8?8:16);
    goto L_AE8DF3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DF0u,0xAE8DF0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_AE8DF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF3u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF3 TXY
    cpu.transfer("TXY");
    goto L_AE8DF4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF3 TXY
    cpu.transfer("TXY");
    goto L_AE8DF4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF3 TXY
    cpu.transfer("TXY");
    goto L_AE8DF4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF3 TXY
    cpu.transfer("TXY");
    goto L_AE8DF4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DF3u,0xAE8DF3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_AE8DF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF4u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u, 6u, 4u, ((0xAAE800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF4 ORA
    cpu.logicOr(hw.readW(((0xAAE800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_AE8DF8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u, 6u, 4u, ((0xAAE800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF4 ORA
    cpu.logicOr(hw.readW(((0xAAE800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_AE8DF8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u, 5u, 4u, ((0xAAE800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF4 ORA
    cpu.logicOr(hw.readW(((0xAAE800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_AE8DF8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF4u, 5u, 4u, ((0xAAE800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF4 ORA
    cpu.logicOr(hw.readW(((0xAAE800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_AE8DF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DF4u,0xAE8DF4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_AE8DF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF8u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xF4u), cpu.m8?8:16));
    goto L_AE8DFA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xF4u), cpu.m8?8:16));
    goto L_AE8DFA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xF4u), cpu.m8?8:16));
    goto L_AE8DFA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $AE8DF8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xF4u), cpu.m8?8:16));
    goto L_AE8DFA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DF8u,0xAE8DF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_AE8DFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFAu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $AE8DFA BRK
    hw.partial(0xAE8DFAu, "BRK"); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $AE8DFA BRK
    hw.partial(0xAE8DFAu, "BRK"); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $AE8DFA BRK
    hw.partial(0xAE8DFAu, "BRK"); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $AE8DFA BRK
    hw.partial(0xAE8DFAu, "BRK"); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DFAu,0xAE8DFAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_B19B13_E0M1X1C0_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB18628u: goto L_B18628;
    case 0xB1862Bu: goto L_B1862B;
    case 0xB1862Du: goto L_B1862D;
    case 0xB1862Fu: goto L_B1862F;
    case 0xB18631u: goto L_B18631;
    case 0xB18633u: goto L_B18633;
    case 0xB18635u: goto L_B18635;
    case 0xB18636u: goto L_B18636;
    case 0xB18637u: goto L_B18637;
    case 0xB18638u: goto L_B18638;
    case 0xB1863Cu: goto L_B1863C;
    case 0xB1863Eu: goto L_B1863E;
    case 0xB18640u: goto L_B18640;
    case 0xB18643u: goto L_B18643;
    case 0xB18644u: goto L_B18644;
    case 0xB18647u: goto L_B18647;
    case 0xB18648u: goto L_B18648;
    case 0xB18649u: goto L_B18649;
    case 0xB1864Bu: goto L_B1864B;
    case 0xB1864Du: goto L_B1864D;
    case 0xB1864Fu: goto L_B1864F;
    case 0xB18650u: goto L_B18650;
    case 0xB18652u: goto L_B18652;
    case 0xB18654u: goto L_B18654;
    case 0xB18655u: goto L_B18655;
    case 0xB18656u: goto L_B18656;
    case 0xB18657u: goto L_B18657;
    case 0xB18659u: goto L_B18659;
    case 0xB1865Au: goto L_B1865A;
    case 0xB1865Bu: goto L_B1865B;
    case 0xB1865Cu: goto L_B1865C;
    case 0xB1865Eu: goto L_B1865E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B18628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8628u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8628u,cpu,0x5Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8628u, 7u, 3u, cpu.address("absx", 0x2388u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18628 LSR
    cpu.lsrMem(hw, cpu.address("absx", 0x2388u), cpu.m8?8:16);
    goto L_B1862B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8628u,0xB18628u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1862B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Bu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1862B INC
    cpu.incMem(hw, cpu.address("dp", 0x2Bu), cpu.m8?8:16);
    goto L_B1862D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x862Bu,0xB1862Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1862D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Du))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1862D CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x2Bu), cpu.x8?8:16));
    goto L_B1862F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x862Du,0xB1862Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1862F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Fu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Fu,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1862F CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x2Bu), cpu.x8?8:16));
    goto L_B18631;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x862Fu,0xB1862Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8631u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8631u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8631u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x93u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18631 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x93u), cpu.x8?8:16));
    goto L_B18633;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8631u,0xB18631u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8633u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18633 CPX
    cpu.compareX(0x4Eu);
    goto L_B18635;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8633u,0xB18633u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8635u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8635u,cpu,0xD4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8635u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18635 PEI
    cpu.push16Value(hw, hw.readW(cpu.address("dp", 0xCAu),16));
    goto L_B18637;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8635u,0xB18635u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8636u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18636 DEX
    cpu.decReg('X');
    goto L_B18637;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8636u,0xB18636u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8637u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8637u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8637u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18637 XBA
    cpu.xba();
    goto L_B18638;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8637u,0xB18637u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18638:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8638u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8638u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8638u, 5u, 4u, ((0xF8DCE4u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18638 ORA
    cpu.logicOr(hw.readW(((0xF8DCE4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_B1863C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8638u,0xB18638u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1863C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Cu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1863C BCC -> $B18636
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B18636; }
    goto L_B1863E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x863Cu,0xB1863Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1863E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Eu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1863E BCC -> $B18638
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B18638; }
    goto L_B18640;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x863Eu,0xB1863Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8640u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8640u,cpu,0x5Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8640u, 7u, 3u, cpu.address("absx", 0x5E88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18640 LSR
    cpu.lsrMem(hw, cpu.address("absx", 0x5E88u), cpu.m8?8:16);
    goto L_B18643;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8640u,0xB18640u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8643u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8643u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8643u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18643 DEY
    cpu.decReg('Y');
    goto L_B18644;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8643u,0xB18643u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8644u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8644u,cpu,0x5Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8644u, 7u, 3u, cpu.address("absx", 0x5388u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18644 LSR
    cpu.lsrMem(hw, cpu.address("absx", 0x5388u), cpu.m8?8:16);
    goto L_B18647;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8644u,0xB18644u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8647u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18647 DEY
    cpu.decReg('Y');
    goto L_B18648;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8647u,0xB18647u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8648u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8648u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8648u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18648 TCD
    cpu.tcd();
    goto L_B18649;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8648u,0xB18648u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8649u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8649u,cpu,0xE7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8649u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFBu) & 0xFFFFu), 3u, 0u);
    // $B18649 SBC
    cpu.sbc(hw.readW(cpu.addressDpLong(hw, 0xFBu), cpu.m8?8:16));
    goto L_B1864B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8649u,0xB18649u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1864B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Bu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Bu,cpu,0xD4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1864B PEI
    cpu.push16Value(hw, hw.readW(cpu.address("dp", 0xFBu),16));
    goto L_B1864D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x864Bu,0xB1864Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1864D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Du))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Du,cpu,0xD4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1864D PEI
    cpu.push16Value(hw, hw.readW(cpu.address("dp", 0x85u),16));
    goto L_B1864F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x864Du,0xB1864Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1864F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Fu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Fu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1864F DEY
    cpu.decReg('Y');
    goto L_B18650;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x864Fu,0xB1864Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8650u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8650u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8650u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18650 STA
    hw.write(cpu.address("dp", 0x88u), cpu.a, cpu.m8?8:16);
    goto L_B18652;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8650u,0xB18650u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8652u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8652u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8652u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18652 STA
    hw.write(cpu.address("dp", 0x88u), cpu.a, cpu.m8?8:16);
    goto L_B18654;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8652u,0xB18652u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8654u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8654u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8654u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18654 SEC
    cpu.setFlag('C', true);
    goto L_B18655;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8654u,0xB18654u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8655u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18655 DEY
    cpu.decReg('Y');
    goto L_B18656;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8655u,0xB18655u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8656u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8656u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8656u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18656 DEX
    cpu.decReg('X');
    goto L_B18657;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8656u,0xB18656u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8657u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8657u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8657u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x06u) & 0xFFFFu), 3u, 0u);
    // $B18657 STA
    hw.write(cpu.addressDpLong(hw, 0x6u), cpu.a, cpu.m8?8:16);
    goto L_B18659;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8657u,0xB18657u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8659u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8659u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8659u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18659 DEY
    cpu.decReg('Y');
    goto L_B1865A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8659u,0xB18659u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1865A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Au))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Au,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1865A PHD
    cpu.push("PHD", hw);
    goto L_B1865B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x865Au,0xB1865Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1865B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1865B DEY
    cpu.decReg('Y');
    goto L_B1865C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x865Bu,0xB1865Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1865C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1865C BPL -> $B185E6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0xB185E6u,0xB1865Cu); return; }
    goto L_B1865E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x865Cu,0xB1865Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1865E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Eu,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1865E ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0x88u), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8660u,0xB1865Eu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x865Eu,0xB1865Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_B19B13_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB18628u: goto L_B18628;
    case 0xB1862Bu: goto L_B1862B;
    case 0xB1862Du: goto L_B1862D;
    case 0xB1862Fu: goto L_B1862F;
    case 0xB18631u: goto L_B18631;
    case 0xB18633u: goto L_B18633;
    case 0xB18635u: goto L_B18635;
    case 0xB18636u: goto L_B18636;
    case 0xB18637u: goto L_B18637;
    case 0xB18638u: goto L_B18638;
    case 0xB1863Cu: goto L_B1863C;
    case 0xB1863Eu: goto L_B1863E;
    case 0xB18640u: goto L_B18640;
    case 0xB18643u: goto L_B18643;
    case 0xB18644u: goto L_B18644;
    case 0xB18647u: goto L_B18647;
    case 0xB18648u: goto L_B18648;
    case 0xB18649u: goto L_B18649;
    case 0xB1864Bu: goto L_B1864B;
    case 0xB1864Du: goto L_B1864D;
    case 0xB1864Fu: goto L_B1864F;
    case 0xB18650u: goto L_B18650;
    case 0xB18652u: goto L_B18652;
    case 0xB18654u: goto L_B18654;
    case 0xB18655u: goto L_B18655;
    case 0xB18656u: goto L_B18656;
    case 0xB18657u: goto L_B18657;
    case 0xB18659u: goto L_B18659;
    case 0xB1865Au: goto L_B1865A;
    case 0xB1865Bu: goto L_B1865B;
    case 0xB1865Cu: goto L_B1865C;
    case 0xB1865Eu: goto L_B1865E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B18628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8628u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8628u,cpu,0x5Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8628u, 7u, 3u, cpu.address("absx", 0x2388u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18628 LSR
    cpu.lsrMem(hw, cpu.address("absx", 0x2388u), cpu.m8?8:16);
    goto L_B1862B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8628u,0xB18628u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1862B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Bu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1862B INC
    cpu.incMem(hw, cpu.address("dp", 0x2Bu), cpu.m8?8:16);
    goto L_B1862D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x862Bu,0xB1862Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1862D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Du))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1862D CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x2Bu), cpu.x8?8:16));
    goto L_B1862F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x862Du,0xB1862Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1862F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Fu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Fu,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1862F CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x2Bu), cpu.x8?8:16));
    goto L_B18631;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x862Fu,0xB1862Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8631u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8631u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8631u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x93u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18631 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x93u), cpu.x8?8:16));
    goto L_B18633;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8631u,0xB18631u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8633u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18633 CPX
    cpu.compareX(0x4Eu);
    goto L_B18635;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8633u,0xB18633u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8635u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8635u,cpu,0xD4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8635u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18635 PEI
    cpu.push16Value(hw, hw.readW(cpu.address("dp", 0xCAu),16));
    goto L_B18637;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8635u,0xB18635u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8636u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18636 DEX
    cpu.decReg('X');
    goto L_B18637;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8636u,0xB18636u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8637u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8637u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8637u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18637 XBA
    cpu.xba();
    goto L_B18638;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8637u,0xB18637u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18638:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8638u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8638u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8638u, 5u, 4u, ((0xF8DCE4u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18638 ORA
    cpu.logicOr(hw.readW(((0xF8DCE4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_B1863C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8638u,0xB18638u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1863C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Cu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1863C BCC -> $B18636
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B18636; }
    goto L_B1863E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x863Cu,0xB1863Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1863E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Eu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1863E BCC -> $B18638
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B18638; }
    goto L_B18640;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x863Eu,0xB1863Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8640u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8640u,cpu,0x5Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8640u, 7u, 3u, cpu.address("absx", 0x5E88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18640 LSR
    cpu.lsrMem(hw, cpu.address("absx", 0x5E88u), cpu.m8?8:16);
    goto L_B18643;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8640u,0xB18640u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8643u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8643u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8643u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18643 DEY
    cpu.decReg('Y');
    goto L_B18644;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8643u,0xB18643u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8644u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8644u,cpu,0x5Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8644u, 7u, 3u, cpu.address("absx", 0x5388u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18644 LSR
    cpu.lsrMem(hw, cpu.address("absx", 0x5388u), cpu.m8?8:16);
    goto L_B18647;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8644u,0xB18644u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8647u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18647 DEY
    cpu.decReg('Y');
    goto L_B18648;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8647u,0xB18647u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8648u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8648u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8648u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18648 TCD
    cpu.tcd();
    goto L_B18649;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8648u,0xB18648u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8649u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8649u,cpu,0xE7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8649u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFBu) & 0xFFFFu), 3u, 0u);
    // $B18649 SBC
    cpu.sbc(hw.readW(cpu.addressDpLong(hw, 0xFBu), cpu.m8?8:16));
    goto L_B1864B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8649u,0xB18649u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1864B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Bu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Bu,cpu,0xD4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1864B PEI
    cpu.push16Value(hw, hw.readW(cpu.address("dp", 0xFBu),16));
    goto L_B1864D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x864Bu,0xB1864Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1864D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Du))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Du,cpu,0xD4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1864D PEI
    cpu.push16Value(hw, hw.readW(cpu.address("dp", 0x85u),16));
    goto L_B1864F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x864Du,0xB1864Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1864F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Fu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Fu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1864F DEY
    cpu.decReg('Y');
    goto L_B18650;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x864Fu,0xB1864Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8650u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8650u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8650u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18650 STA
    hw.write(cpu.address("dp", 0x88u), cpu.a, cpu.m8?8:16);
    goto L_B18652;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8650u,0xB18650u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8652u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8652u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8652u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18652 STA
    hw.write(cpu.address("dp", 0x88u), cpu.a, cpu.m8?8:16);
    goto L_B18654;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8652u,0xB18652u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8654u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8654u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8654u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18654 SEC
    cpu.setFlag('C', true);
    goto L_B18655;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8654u,0xB18654u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8655u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18655 DEY
    cpu.decReg('Y');
    goto L_B18656;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8655u,0xB18655u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8656u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8656u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8656u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18656 DEX
    cpu.decReg('X');
    goto L_B18657;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8656u,0xB18656u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8657u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8657u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8657u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x06u) & 0xFFFFu), 3u, 0u);
    // $B18657 STA
    hw.write(cpu.addressDpLong(hw, 0x6u), cpu.a, cpu.m8?8:16);
    goto L_B18659;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8657u,0xB18657u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8659u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8659u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8659u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18659 DEY
    cpu.decReg('Y');
    goto L_B1865A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8659u,0xB18659u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1865A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Au))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Au,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1865A PHD
    cpu.push("PHD", hw);
    goto L_B1865B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x865Au,0xB1865Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1865B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1865B DEY
    cpu.decReg('Y');
    goto L_B1865C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x865Bu,0xB1865Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1865C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1865C BPL -> $B185E6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0xB185E6u,0xB1865Cu); return; }
    goto L_B1865E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x865Cu,0xB1865Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1865E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Eu,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1865E ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0x88u), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8660u,0xB1865Eu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x865Eu,0xB1865Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

