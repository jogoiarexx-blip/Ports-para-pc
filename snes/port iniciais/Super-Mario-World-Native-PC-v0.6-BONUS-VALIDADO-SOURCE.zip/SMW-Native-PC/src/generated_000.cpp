#include "generated.hpp"
void sub_0080FD_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0080FDu: goto L_0080FD;
    case 0x0080FFu: goto L_0080FF;
    case 0x008102u: goto L_008102;
    case 0x008104u: goto L_008104;
    case 0x008107u: goto L_008107;
    case 0x008109u: goto L_008109;
    case 0x00810Cu: goto L_00810C;
    case 0x00811Du: goto L_00811D;
    case 0x00811Fu: goto L_00811F;
    case 0x008122u: goto L_008122;
    case 0x008125u: goto L_008125;
    case 0x008127u: goto L_008127;
    case 0x00812Au: goto L_00812A;
    case 0x00812Du: goto L_00812D;
    case 0x008130u: goto L_008130;
    case 0x008131u: goto L_008131;
    case 0x008133u: goto L_008133;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0080FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080FD LDA
    cpu.setA(0x0u, 8);
    goto L_0080FF;
L_0080FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FFu, 4u, 3u, cpu.address("abs", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080FF STA
    hw.write(cpu.address("abs", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_008102;
L_008102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8102u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8102u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008102 LDA
    cpu.setA(0x80u, 8);
    goto L_008104;
L_008104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8104u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8104u, 4u, 3u, cpu.address("abs", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008104 STA
    hw.write(cpu.address("abs", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_008107;
L_008107:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8107u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8107u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8107u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008107 LDA
    cpu.setA(0xFu, 8);
    goto L_008109;
L_008109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u, 4u, 3u, cpu.address("abs", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008109 STA
    hw.write(cpu.address("abs", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_00810C;
L_00810C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00810C BRA -> $00811D
    goto L_00811D;
L_00811D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00811D LDA
    cpu.setA(0xFFu, 8);
    goto L_00811F;
L_00811F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00811F STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_008122;
L_008122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u, 6u, 3u, cpu.address("abs", 0x80F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008122 JSR -> $0080F7 stack real
    { cpu.push16Value(hw,0x8124u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8125u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80F7u), 0x008122u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008125;
L_008125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8125u,0x008125u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008125 LDX
    cpu.setX(0x3u, 8);
    goto L_008127;
L_008127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u, 5u, 3u, cpu.address("absx", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008127 STZ
    hw.write(cpu.address("absx", 0x2140u), 0, cpu.m8?8:16);
    goto L_00812A;
L_00812A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au, 5u, 3u, cpu.address("absx", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00812A STZ
    hw.write(cpu.address("absx", 0x1DF9u), 0, cpu.m8?8:16);
    goto L_00812D;
L_00812D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du, 5u, 3u, cpu.address("absx", 0x1DFDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00812D STZ
    hw.write(cpu.address("absx", 0x1DFDu), 0, cpu.m8?8:16);
    goto L_008130;
L_008130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008130 DEX
    cpu.decReg('X');
    goto L_008131;
L_008131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008131 BPL -> $008127
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008127; }
    goto L_008133;
L_008133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008133 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008133u);return;} hw.unresolvedReturn(0x008133u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0086DF_E1M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0086DFu: goto L_0086DF;
    case 0x0086E1u: goto L_0086E1;
    case 0x0086E2u: goto L_0086E2;
    case 0x0086E4u: goto L_0086E4;
    case 0x0086E6u: goto L_0086E6;
    case 0x0086E9u: goto L_0086E9;
    case 0x0086EAu: goto L_0086EA;
    case 0x0086EBu: goto L_0086EB;
    case 0x0086ECu: goto L_0086EC;
    case 0x0086EEu: goto L_0086EE;
    case 0x0086EFu: goto L_0086EF;
    case 0x0086F1u: goto L_0086F1;
    case 0x0086F3u: goto L_0086F3;
    case 0x0086F5u: goto L_0086F5;
    case 0x0086F7u: goto L_0086F7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0086DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DFu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086DF STY
    hw.write(cpu.address("dp", 0x3u), cpu.y, cpu.x8?8:16);
    goto L_0086E1;
L_0086E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E1u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E1u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0086E1 PLY
    cpu.pop("PLY", hw);
    goto L_0086E2;
L_0086E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E2u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086E2 STY
    hw.write(cpu.address("dp", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_0086E4;
L_0086E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086E4 REP
    cpu.rep(0x30u);
    goto L_0086E6;
L_0086E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086E6 AND
    cpu.logicAnd(0xFFu);
    goto L_0086E9;
L_0086E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086E9 ASL
    cpu.aslA();
    goto L_0086EA;
L_0086EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086EA TAY
    cpu.transfer("TAY");
    goto L_0086EB;
L_0086EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EBu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EBu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0086EB PLA
    cpu.pop("PLA", hw);
    goto L_0086EC;
L_0086EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ECu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086EC STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0086EE;
L_0086EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086EE INY
    cpu.inc('Y');
    goto L_0086EF;
L_0086EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EFu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $0086EF LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0086F1;
L_0086F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086F1 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0086F3;
L_0086F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086F3 SEP
    cpu.sep(0x30u);
    goto L_0086F5;
L_0086F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086F5 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0086F7;
L_0086F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u,cpu,0xDCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, 0x0000u, 3u, 0u);
    // $0086F7 JMP [0000] -> dispatcher C++ dinamico
    hw.requestDispatch(hw.read24(0x0000u),0x0086F7u); return;
}

void sub_00ACED_E1M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00ACEDu: goto L_00ACED;
    case 0x00ACF0u: goto L_00ACF0;
    case 0x00ACF2u: goto L_00ACF2;
    case 0x00ACF5u: goto L_00ACF5;
    case 0x00ACF6u: goto L_00ACF6;
    case 0x00ACF7u: goto L_00ACF7;
    case 0x00ACFAu: goto L_00ACFA;
    case 0x00ACFBu: goto L_00ACFB;
    case 0x00ACFCu: goto L_00ACFC;
    case 0x00ACFEu: goto L_00ACFE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00ACED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEDu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACED LDY
    cpu.setY(0x7u, 16);
    goto L_00ACF0;
L_00ACF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACF0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ACF2;
L_00ACF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF2u, 6u, 3u, cpu.address("absx", 0x0703u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACF2 STA
    hw.write(cpu.address("absx", 0x703u), cpu.a, cpu.m8?8:16);
    goto L_00ACF5;
L_00ACF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACF5 TXA
    cpu.transfer("TXA");
    goto L_00ACF6;
L_00ACF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACF6 CLC
    cpu.setFlag('C', false);
    goto L_00ACF7;
L_00ACF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACF7 ADC
    cpu.adc(0x20u);
    goto L_00ACFA;
L_00ACFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACFA TAX
    cpu.transfer("TAX");
    goto L_00ACFB;
L_00ACFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFBu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACFB DEY
    cpu.decReg('Y');
    goto L_00ACFC;
L_00ACFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACFC BPL -> $00ACF0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00ACF0; }
    goto L_00ACFE;
L_00ACFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ACFE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00ACFEu);return;} hw.unresolvedReturn(0x00ACFEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CA44_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CA44u: goto L_00CA44;
    case 0x00CA47u: goto L_00CA47;
    case 0x00CA49u: goto L_00CA49;
    case 0x00CA4Au: goto L_00CA4A;
    case 0x00CA4Du: goto L_00CA4D;
    case 0x00CA4Fu: goto L_00CA4F;
    case 0x00CA52u: goto L_00CA52;
    case 0x00CA54u: goto L_00CA54;
    case 0x00CA56u: goto L_00CA56;
    case 0x00CA58u: goto L_00CA58;
    case 0x00CA5Au: goto L_00CA5A;
    case 0x00CA5Cu: goto L_00CA5C;
    case 0x00CA5Eu: goto L_00CA5E;
    case 0x00CA60u: goto L_00CA60;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CA44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA44u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA44u, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA44 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1433u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CA47;
L_00CA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA47u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA47 BNE -> $00CA4A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA4A; }
    goto L_00CA49;
L_00CA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA49u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA49u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA49 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CA49u);return;} hw.unresolvedReturn(0x00CA49u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00CA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Au, 6u, 3u, cpu.address("abs", 0xCA61u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA4A JSR -> $00CA61 stack real
    { cpu.push16Value(hw,0xCA4Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCA4Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA61u), 0x00CA4Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CA4D;
L_00CA4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA4Du,0x00CA4Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA4D LDA
    cpu.setA(0xFCu, 8);
    goto L_00CA4F;
L_00CA4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Fu, 6u, 3u, cpu.address("abs", 0xCA6Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA4F JSR -> $00CA6D stack real
    { cpu.push16Value(hw,0xCA51u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCA52u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA6Du), 0x00CA4Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CA52;
L_00CA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA52u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA52u,0x00CA52u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA52u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA52u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA52 LDA
    cpu.setA(0x33u, 8);
    goto L_00CA54;
L_00CA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA54u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA54u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA54 STA
    hw.write(cpu.address("dp", 0x41u), cpu.a, cpu.m8?8:16);
    goto L_00CA56;
L_00CA56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA56u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA56u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA56 STA
    hw.write(cpu.address("dp", 0x43u), cpu.a, cpu.m8?8:16);
    goto L_00CA58;
L_00CA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA58u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA58 LDA
    cpu.setA(0x3u, 8);
    goto L_00CA5A;
L_00CA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA5A STA
    hw.write(cpu.address("dp", 0x42u), cpu.a, cpu.m8?8:16);
    goto L_00CA5C;
L_00CA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA5C LDA
    cpu.setA(0x22u, 8);
    goto L_00CA5E;
L_00CA5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA5E STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_00CA60;
L_00CA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA60u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA60u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA60 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CA60u);return;} hw.unresolvedReturn(0x00CA60u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CA44_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CA44u: goto L_00CA44;
    case 0x00CA47u: goto L_00CA47;
    case 0x00CA49u: goto L_00CA49;
    case 0x00CA4Au: goto L_00CA4A;
    case 0x00CA4Du: goto L_00CA4D;
    case 0x00CA4Fu: goto L_00CA4F;
    case 0x00CA52u: goto L_00CA52;
    case 0x00CA54u: goto L_00CA54;
    case 0x00CA56u: goto L_00CA56;
    case 0x00CA58u: goto L_00CA58;
    case 0x00CA5Au: goto L_00CA5A;
    case 0x00CA5Cu: goto L_00CA5C;
    case 0x00CA5Eu: goto L_00CA5E;
    case 0x00CA60u: goto L_00CA60;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CA44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA44u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA44u, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA44 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1433u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CA47;
L_00CA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA47u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA47 BNE -> $00CA4A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA4A; }
    goto L_00CA49;
L_00CA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA49u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA49u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA49 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CA49u);return;} hw.unresolvedReturn(0x00CA49u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00CA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Au, 6u, 3u, cpu.address("abs", 0xCA61u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA4A JSR -> $00CA61 stack real
    { cpu.push16Value(hw,0xCA4Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCA4Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA61u), 0x00CA4Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CA4D;
L_00CA4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA4Du,0x00CA4Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA4D LDA
    cpu.setA(0xFCu, 8);
    goto L_00CA4F;
L_00CA4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Fu, 6u, 3u, cpu.address("abs", 0xCA6Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA4F JSR -> $00CA6D stack real
    { cpu.push16Value(hw,0xCA51u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCA52u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA6Du), 0x00CA4Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CA52;
L_00CA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA52u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA52u,0x00CA52u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA52u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA52u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA52 LDA
    cpu.setA(0x33u, 8);
    goto L_00CA54;
L_00CA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA54u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA54u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA54 STA
    hw.write(cpu.address("dp", 0x41u), cpu.a, cpu.m8?8:16);
    goto L_00CA56;
L_00CA56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA56u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA56u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA56 STA
    hw.write(cpu.address("dp", 0x43u), cpu.a, cpu.m8?8:16);
    goto L_00CA58;
L_00CA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA58u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA58 LDA
    cpu.setA(0x3u, 8);
    goto L_00CA5A;
L_00CA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA5A STA
    hw.write(cpu.address("dp", 0x42u), cpu.a, cpu.m8?8:16);
    goto L_00CA5C;
L_00CA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA5C LDA
    cpu.setA(0x22u, 8);
    goto L_00CA5E;
L_00CA5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA5E STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_00CA60;
L_00CA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA60u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA60u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA60 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CA60u);return;} hw.unresolvedReturn(0x00CA60u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CC14_E1M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CC14u: goto L_00CC14;
    case 0x00CC15u: goto L_00CC15;
    case 0x00CC17u: goto L_00CC17;
    case 0x00CC1Au: goto L_00CC1A;
    case 0x00CC1Du: goto L_00CC1D;
    case 0x00CC20u: goto L_00CC20;
    case 0x00CC23u: goto L_00CC23;
    case 0x00CC24u: goto L_00CC24;
    case 0x00CC25u: goto L_00CC25;
    case 0x00CC26u: goto L_00CC26;
    case 0x00CC27u: goto L_00CC27;
    case 0x00CC28u: goto L_00CC28;
    case 0x00CC29u: goto L_00CC29;
    case 0x00CC2Bu: goto L_00CC2B;
    case 0x00CC2Eu: goto L_00CC2E;
    case 0x00CC2Fu: goto L_00CC2F;
    case 0x00CC30u: goto L_00CC30;
    case 0x00CC32u: goto L_00CC32;
    case 0x00CC34u: goto L_00CC34;
    case 0x00CC37u: goto L_00CC37;
    case 0x00CC3Au: goto L_00CC3A;
    case 0x00CC3Du: goto L_00CC3D;
    case 0x00CC3Eu: goto L_00CC3E;
    case 0x00CC3Fu: goto L_00CC3F;
    case 0x00CC40u: goto L_00CC40;
    case 0x00CC41u: goto L_00CC41;
    case 0x00CC44u: goto L_00CC44;
    case 0x00CC46u: goto L_00CC46;
    case 0x00CC48u: goto L_00CC48;
    case 0x00CC4Bu: goto L_00CC4B;
    case 0x00CC4Eu: goto L_00CC4E;
    case 0x00CC51u: goto L_00CC51;
    case 0x00CC52u: goto L_00CC52;
    case 0x00CC53u: goto L_00CC53;
    case 0x00CC54u: goto L_00CC54;
    case 0x00CC55u: goto L_00CC55;
    case 0x00CC58u: goto L_00CC58;
    case 0x00CC5Au: goto L_00CC5A;
    case 0x00CC5Bu: goto L_00CC5B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC14u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC14u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CC14 PHY
    cpu.push("PHY", hw);
    goto L_00CC15;
L_00CC15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC15u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC15 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC17;
L_00CC17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC17u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC17u, 4u, 3u, cpu.address("abs", 0x4205u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC17 STA
    hw.write(cpu.address("abs", 0x4205u), cpu.a, cpu.m8?8:16);
    goto L_00CC1A;
L_00CC1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC1Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC1Au, 4u, 3u, cpu.address("abs", 0x4204u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC1A STZ
    hw.write(cpu.address("abs", 0x4204u), 0, cpu.m8?8:16);
    goto L_00CC1D;
L_00CC1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC1Du, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1433u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC20;
L_00CC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC20u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC20u, 4u, 3u, cpu.address("abs", 0x4206u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC20 STA
    hw.write(cpu.address("abs", 0x4206u), cpu.a, cpu.m8?8:16);
    goto L_00CC23;
L_00CC23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC23u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC23 NOP
    ;
    goto L_00CC24;
L_00CC24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC24u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC24 NOP
    ;
    goto L_00CC25;
L_00CC25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC25u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC25 NOP
    ;
    goto L_00CC26;
L_00CC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC26u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC26 NOP
    ;
    goto L_00CC27;
L_00CC27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC27u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC27u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC27 NOP
    ;
    goto L_00CC28;
L_00CC28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC28u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC28u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC28 NOP
    ;
    goto L_00CC29;
L_00CC29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC29u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC29u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC29 REP
    cpu.rep(0x20u);
    goto L_00CC2B;
L_00CC2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC2Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC2Bu, 5u, 3u, cpu.address("abs", 0x4214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC2B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4214u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC2E;
L_00CC2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC2Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC2E LSR
    cpu.lsrA();
    goto L_00CC2F;
L_00CC2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC2Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC2F TAY
    cpu.transfer("TAY");
    goto L_00CC30;
L_00CC30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC30u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC30u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC30 SEP
    cpu.sep(0x20u);
    goto L_00CC32;
L_00CC32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC32u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC32u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x06u) & 0xFFFFu), 2u, 0u);
    // $00CC32 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC34;
L_00CC34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC34u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC34u, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC34 STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_00CC37;
L_00CC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC37u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC37u, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC37 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1433u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC3A;
L_00CC3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Au, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC3A STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_00CC3D;
L_00CC3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Du,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC3D NOP
    ;
    goto L_00CC3E;
L_00CC3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Eu,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC3E NOP
    ;
    goto L_00CC3F;
L_00CC3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Fu,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC3Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC3F NOP
    ;
    goto L_00CC40;
L_00CC40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC40u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC40 NOP
    ;
    goto L_00CC41;
L_00CC41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC41u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC41u, 4u, 3u, cpu.address("abs", 0x4217u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC41 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4217u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC44;
L_00CC44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC44u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC44u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC44 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_00CC46;
L_00CC46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC46u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC46u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 2u, 0u);
    // $00CC46 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC48;
L_00CC48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC48u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC48u, 4u, 3u, cpu.address("abs", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC48 STA
    hw.write(cpu.address("abs", 0x4202u), cpu.a, cpu.m8?8:16);
    goto L_00CC4B;
L_00CC4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC4Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC4Bu, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC4B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1433u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC4E;
L_00CC4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC4Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC4Eu, 4u, 3u, cpu.address("abs", 0x4203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC4E STA
    hw.write(cpu.address("abs", 0x4203u), cpu.a, cpu.m8?8:16);
    goto L_00CC51;
L_00CC51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC51u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC51 NOP
    ;
    goto L_00CC52;
L_00CC52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC52u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC52 NOP
    ;
    goto L_00CC53;
L_00CC53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC53u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC53 NOP
    ;
    goto L_00CC54;
L_00CC54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC54u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC54 NOP
    ;
    goto L_00CC55;
L_00CC55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC55u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC55u, 4u, 3u, cpu.address("abs", 0x4217u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC55 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4217u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CC58;
L_00CC58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC58u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CC58 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_00CC5A;
L_00CC5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC5Au,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC5Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CC5A PLY
    cpu.pop("PLY", hw);
    goto L_00CC5B;
L_00CC5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC5Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC5Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CC5B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CC5Bu);return;} hw.unresolvedReturn(0x00CC5Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00D988_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00D988u: goto L_00D988;
    case 0x00D98Bu: goto L_00D98B;
    case 0x00D98Du: goto L_00D98D;
    case 0x00D990u: goto L_00D990;
    case 0x00D993u: goto L_00D993;
    case 0x00D995u: goto L_00D995;
    case 0x00D998u: goto L_00D998;
    case 0x00D99Au: goto L_00D99A;
    case 0x00D99Cu: goto L_00D99C;
    case 0x00D99Eu: goto L_00D99E;
    case 0x00D9A0u: goto L_00D9A0;
    case 0x00D9A2u: goto L_00D9A2;
    case 0x00D9A4u: goto L_00D9A4;
    case 0x00D9A6u: goto L_00D9A6;
    case 0x00D9A8u: goto L_00D9A8;
    case 0x00D9ABu: goto L_00D9AB;
    case 0x00D9ADu: goto L_00D9AD;
    case 0x00D9AFu: goto L_00D9AF;
    case 0x00D9B1u: goto L_00D9B1;
    case 0x00D9B3u: goto L_00D9B3;
    case 0x00D9B5u: goto L_00D9B5;
    case 0x00D9B8u: goto L_00D9B8;
    case 0x00D9B9u: goto L_00D9B9;
    case 0x00D9BAu: goto L_00D9BA;
    case 0x00D9BCu: goto L_00D9BC;
    case 0x00D9BDu: goto L_00D9BD;
    case 0x00D9BEu: goto L_00D9BE;
    case 0x00D9C1u: goto L_00D9C1;
    case 0x00D9C3u: goto L_00D9C3;
    case 0x00D9C4u: goto L_00D9C4;
    case 0x00D9C6u: goto L_00D9C6;
    case 0x00D9C8u: goto L_00D9C8;
    case 0x00D9CAu: goto L_00D9CA;
    case 0x00D9CBu: goto L_00D9CB;
    case 0x00D9CCu: goto L_00D9CC;
    case 0x00D9CDu: goto L_00D9CD;
    case 0x00D9CFu: goto L_00D9CF;
    case 0x00D9D1u: goto L_00D9D1;
    case 0x00D9D3u: goto L_00D9D3;
    case 0x00D9D5u: goto L_00D9D5;
    case 0x00D9D7u: goto L_00D9D7;
    case 0x00D9D9u: goto L_00D9D9;
    case 0x00D9DBu: goto L_00D9DB;
    case 0x00D9DDu: goto L_00D9DD;
    case 0x00D9DFu: goto L_00D9DF;
    case 0x00D9E1u: goto L_00D9E1;
    case 0x00D9E3u: goto L_00D9E3;
    case 0x00D9E5u: goto L_00D9E5;
    case 0x00D9E7u: goto L_00D9E7;
    case 0x00D9E9u: goto L_00D9E9;
    case 0x00D9EBu: goto L_00D9EB;
    case 0x00D9EDu: goto L_00D9ED;
    case 0x00D9EFu: goto L_00D9EF;
    case 0x00D9F1u: goto L_00D9F1;
    case 0x00D9F4u: goto L_00D9F4;
    case 0x00D9F6u: goto L_00D9F6;
    case 0x00D9F9u: goto L_00D9F9;
    case 0x00D9FBu: goto L_00D9FB;
    case 0x00D9FDu: goto L_00D9FD;
    case 0x00D9FFu: goto L_00D9FF;
    case 0x00DA01u: goto L_00DA01;
    case 0x00DA04u: goto L_00DA04;
    case 0x00DA06u: goto L_00DA06;
    case 0x00DA07u: goto L_00DA07;
    case 0x00DA08u: goto L_00DA08;
    case 0x00DA0Au: goto L_00DA0A;
    case 0x00DA0Bu: goto L_00DA0B;
    case 0x00DA0Du: goto L_00DA0D;
    case 0x00DA0Fu: goto L_00DA0F;
    case 0x00DA11u: goto L_00DA11;
    case 0x00DA12u: goto L_00DA12;
    case 0x00DA13u: goto L_00DA13;
    case 0x00DA15u: goto L_00DA15;
    case 0x00DA17u: goto L_00DA17;
    case 0x00DA18u: goto L_00DA18;
    case 0x00DA19u: goto L_00DA19;
    case 0x00DA1Au: goto L_00DA1A;
    case 0x00DA1Bu: goto L_00DA1B;
    case 0x00DA1Du: goto L_00DA1D;
    case 0x00DA1Fu: goto L_00DA1F;
    case 0x00DA21u: goto L_00DA21;
    case 0x00DA23u: goto L_00DA23;
    case 0x00DA25u: goto L_00DA25;
    case 0x00DA28u: goto L_00DA28;
    case 0x00DA2Au: goto L_00DA2A;
    case 0x00DA2Du: goto L_00DA2D;
    case 0x00DA2Fu: goto L_00DA2F;
    case 0x00DA31u: goto L_00DA31;
    case 0x00DA33u: goto L_00DA33;
    case 0x00DA35u: goto L_00DA35;
    case 0x00DA37u: goto L_00DA37;
    case 0x00DA39u: goto L_00DA39;
    case 0x00DA3Cu: goto L_00DA3C;
    case 0x00DA3Eu: goto L_00DA3E;
    case 0x00DA40u: goto L_00DA40;
    case 0x00DA42u: goto L_00DA42;
    case 0x00DA44u: goto L_00DA44;
    case 0x00DA46u: goto L_00DA46;
    case 0x00DA48u: goto L_00DA48;
    case 0x00DA4Au: goto L_00DA4A;
    case 0x00DA4Cu: goto L_00DA4C;
    case 0x00DA4Eu: goto L_00DA4E;
    case 0x00DA4Fu: goto L_00DA4F;
    case 0x00DA50u: goto L_00DA50;
    case 0x00DA51u: goto L_00DA51;
    case 0x00DA52u: goto L_00DA52;
    case 0x00DA53u: goto L_00DA53;
    case 0x00DA55u: goto L_00DA55;
    case 0x00DA58u: goto L_00DA58;
    case 0x00DA5Au: goto L_00DA5A;
    case 0x00DA5Bu: goto L_00DA5B;
    case 0x00DA5Du: goto L_00DA5D;
    case 0x00DA5Eu: goto L_00DA5E;
    case 0x00DA60u: goto L_00DA60;
    case 0x00DA62u: goto L_00DA62;
    case 0x00DA63u: goto L_00DA63;
    case 0x00DA64u: goto L_00DA64;
    case 0x00DA67u: goto L_00DA67;
    case 0x00DA69u: goto L_00DA69;
    case 0x00DA6Bu: goto L_00DA6B;
    case 0x00DA6Cu: goto L_00DA6C;
    case 0x00DA6Fu: goto L_00DA6F;
    case 0x00DA71u: goto L_00DA71;
    case 0x00DA73u: goto L_00DA73;
    case 0x00DA75u: goto L_00DA75;
    case 0x00DA77u: goto L_00DA77;
    case 0x00DA78u: goto L_00DA78;
    case 0x00DA79u: goto L_00DA79;
    case 0x00DA7Cu: goto L_00DA7C;
    case 0x00DA7Fu: goto L_00DA7F;
    case 0x00DA83u: goto L_00DA83;
    case 0x00DA86u: goto L_00DA86;
    case 0x00DA88u: goto L_00DA88;
    case 0x00DA8Au: goto L_00DA8A;
    case 0x00DA8Cu: goto L_00DA8C;
    case 0x00DA8Du: goto L_00DA8D;
    case 0x00DA8Fu: goto L_00DA8F;
    case 0x00DA92u: goto L_00DA92;
    case 0x00DA94u: goto L_00DA94;
    case 0x00DA97u: goto L_00DA97;
    case 0x00DA98u: goto L_00DA98;
    case 0x00DA99u: goto L_00DA99;
    case 0x00DA9Bu: goto L_00DA9B;
    case 0x00DA9Cu: goto L_00DA9C;
    case 0x00DA9Fu: goto L_00DA9F;
    case 0x00DAA2u: goto L_00DAA2;
    case 0x00DAA4u: goto L_00DAA4;
    case 0x00DAA5u: goto L_00DAA5;
    case 0x00DAA8u: goto L_00DAA8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00D988:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD988u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD988u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD988u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D988 STZ
    hw.write(cpu.address("abs", 0x13EDu), 0, cpu.m8?8:16);
    goto L_00D98B;
L_00D98B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD98Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD98Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD98Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D98B STZ
    hw.write(cpu.address("dp", 0x73u), 0, cpu.m8?8:16);
    goto L_00D98D;
L_00D98D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD98Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD98Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD98Du, 4u, 3u, cpu.address("abs", 0x1407u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D98D STZ
    hw.write(cpu.address("abs", 0x1407u), 0, cpu.m8?8:16);
    goto L_00D990;
L_00D990:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD990u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD990u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD990u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D990 STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    goto L_00D993;
L_00D993:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD993u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD993u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD993u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D993 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x7Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D995;
L_00D995:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD995u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD995u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD995u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D995 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D998;
L_00D998:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD998u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD998u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD998u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D998 BEQ -> $00D9EB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D9EB; }
    goto L_00D99A;
L_00D99A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD99Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD99Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD99Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D99A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D99C;
L_00D99C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD99Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD99Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD99Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D99C BNE -> $00D9AF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D9AF; }
    goto L_00D99E;
L_00D99E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD99Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD99Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD99Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D99E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D9A0;
L_00D9A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A0u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9A0 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_00D9A2;
L_00D9A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9A2 BPL -> $00D9AF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D9AF; }
    goto L_00D9A4;
L_00D9A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9A4 LDA
    cpu.setA(0xBu, 8);
    goto L_00D9A6;
L_00D9A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9A6 STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00D9A8;
L_00D9A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A8u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9A8 STZ
    hw.write(cpu.address("abs", 0x13EDu), 0, cpu.m8?8:16);
    goto L_00D9AB;
L_00D9AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9ABu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9AB LDY
    cpu.setY(0xF0u, 8);
    goto L_00D9AD;
L_00D9AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9ADu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9AD BRA -> $00D9B5
    goto L_00D9B5;
L_00D9AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9AFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9AFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9AF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D9B1;
L_00D9B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9B1 AND
    cpu.logicAnd(0x4u);
    goto L_00D9B3;
L_00D9B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9B3 BEQ -> $00D9BD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D9BD; }
    goto L_00D9B5;
L_00D9B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B5u, 6u, 3u, cpu.address("abs", 0xDAA9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D9B5 JSR -> $00DAA9 stack real
    { cpu.push16Value(hw,0xD9B7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD9B8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDAA9u), 0x00D9B5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00D9B8;
L_00D9B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9B8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD9B8u,0x00D9B8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B8u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9B8 TYA
    cpu.transfer("TYA");
    goto L_00D9B9;
L_00D9B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9B9 CLC
    cpu.setFlag('C', false);
    goto L_00D9BA;
L_00D9BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9BA ADC
    cpu.adc(0x8u);
    goto L_00D9BC;
L_00D9BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BCu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9BC TAY
    cpu.transfer("TAY");
    goto L_00D9BD;
L_00D9BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BDu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9BD INY
    cpu.inc('Y');
    goto L_00D9BE;
L_00D9BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BEu, 4u, 3u, cpu.address("abs", 0x13FAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9BE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13FAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D9C1;
L_00D9C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9C1 BNE -> $00D9CC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D9CC; }
    goto L_00D9C3;
L_00D9C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9C3 DEY
    cpu.decReg('Y');
    goto L_00D9C4;
L_00D9C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9C4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D9C6;
L_00D9C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9C6 AND
    cpu.logicAnd(0x3u);
    goto L_00D9C8;
L_00D9C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9C8 BNE -> $00D9CC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D9CC; }
    goto L_00D9CA;
L_00D9CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CAu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9CA DEY
    cpu.decReg('Y');
    goto L_00D9CB;
L_00D9CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CBu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9CB DEY
    cpu.decReg('Y');
    goto L_00D9CC;
L_00D9CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CCu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9CC TYA
    cpu.transfer("TYA");
    goto L_00D9CD;
L_00D9CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CDu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9CD BMI -> $00D9D7
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D9D7; }
    goto L_00D9CF;
L_00D9CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9CF CMP
    cpu.compareA(0x10u);
    goto L_00D9D1;
L_00D9D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9D1 BCC -> $00D9DD
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00D9DD; }
    goto L_00D9D3;
L_00D9D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9D3 LDA
    cpu.setA(0x10u, 8);
    goto L_00D9D5;
L_00D9D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9D5 BRA -> $00D9DD
    goto L_00D9DD;
L_00D9D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9D7 CMP
    cpu.compareA(0xF0u);
    goto L_00D9D9;
L_00D9D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D9u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9D9 BCS -> $00D9DD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00D9DD; }
    goto L_00D9DB;
L_00D9DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9DBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9DB LDA
    cpu.setA(0xF0u, 8);
    goto L_00D9DD;
L_00D9DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9DDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9DDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9DD STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00D9DF;
L_00D9DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9DFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9DF LDY
    cpu.setY(0x80u, 8);
    goto L_00D9E1;
L_00D9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9E1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D9E3;
L_00D9E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9E3 AND
    cpu.logicAnd(0x3u);
    goto L_00D9E5;
L_00D9E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9E5 BNE -> $00DA48
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DA48; }
    goto L_00D9E7;
L_00D9E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9E7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D9E9;
L_00D9E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9E9 BRA -> $00DA46
    goto L_00DA46;
L_00D9EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9EBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9EB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D9ED;
L_00D9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9EDu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9EDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9ED ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_00D9EF;
L_00D9EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9EFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9EF BPL -> $00DA0B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DA0B; }
    goto L_00D9F1;
L_00D9F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9F1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9F1u, 4u, 3u, cpu.address("abs", 0x13FAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9F1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13FAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D9F4;
L_00D9F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9F4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9F4 BNE -> $00DA0B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DA0B; }
    goto L_00D9F6;
L_00D9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9F6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9F6u, 6u, 3u, cpu.address("abs", 0xDAA9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D9F6 JSR -> $00DAA9 stack real
    { cpu.push16Value(hw,0xD9F8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD9F9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDAA9u), 0x00D9F6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00D9F9;
L_00D9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9F9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD9F9u,0x00D9F9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9F9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9F9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9F9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D9FB;
L_00D9FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9FBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9FB BNE -> $00DA06
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DA06; }
    goto L_00D9FD;
L_00D9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9FDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9FD LDA
    cpu.setA(0xBu, 8);
    goto L_00D9FF;
L_00D9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9FFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9FFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D9FF STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00DA01;
L_00DA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA01u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA01u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA01 STZ
    hw.write(cpu.address("abs", 0x13EDu), 0, cpu.m8?8:16);
    goto L_00DA04;
L_00DA04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA04u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA04 LDY
    cpu.setY(0xF0u, 8);
    goto L_00DA06;
L_00DA06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA06u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA06 TYA
    cpu.transfer("TYA");
    goto L_00DA07;
L_00DA07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA07u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA07 SEC
    cpu.setFlag('C', true);
    goto L_00DA08;
L_00DA08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA08u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA08 SBC
    cpu.sbc(0x20u);
    goto L_00DA0A;
L_00DA0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA0Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA0A TAY
    cpu.transfer("TAY");
    goto L_00DA0B;
L_00DA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA0Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA0Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA0B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DA0D;
L_00DA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA0Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA0D AND
    cpu.logicAnd(0x3u);
    goto L_00DA0F;
L_00DA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA0Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA0F BNE -> $00DA13
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DA13; }
    goto L_00DA11;
L_00DA11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA11u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA11 INY
    cpu.inc('Y');
    goto L_00DA12;
L_00DA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA12u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA12 INY
    cpu.inc('Y');
    goto L_00DA13;
L_00DA13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA13u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA13u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA13 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DA15;
L_00DA15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA15u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA15u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA15 AND
    cpu.logicAnd(0xCu);
    goto L_00DA17;
L_00DA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA17u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA17u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA17 LSR
    cpu.lsrA();
    goto L_00DA18;
L_00DA18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA18u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA18 LSR
    cpu.lsrA();
    goto L_00DA19;
L_00DA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA19u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA19u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA19 TAX
    cpu.transfer("TAX");
    goto L_00DA1A;
L_00DA1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Au,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA1A TYA
    cpu.transfer("TYA");
    goto L_00DA1B;
L_00DA1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA1B BMI -> $00DA25
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DA25; }
    goto L_00DA1D;
L_00DA1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA1D CMP
    cpu.compareA(0x40u);
    goto L_00DA1F;
L_00DA1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA1Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA1F BCC -> $00DA2D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00DA2D; }
    goto L_00DA21;
L_00DA21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA21u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA21 LDA
    cpu.setA(0x40u, 8);
    goto L_00DA23;
L_00DA23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA23u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA23u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA23 BRA -> $00DA2D
    goto L_00DA2D;
L_00DA25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA25u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA25u, 4u + ((((0xD984u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD984u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA25 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0xD984u), cpu.m8?8:16));
    goto L_00DA28;
L_00DA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA28u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA28 BCS -> $00DA2D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00DA2D; }
    goto L_00DA2A;
L_00DA2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Au, 4u + ((((0xD984u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD984u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA2A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xD984u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DA2D;
L_00DA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA2D STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00DA2F;
L_00DA2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA2Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA2F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DA31;
L_00DA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA31u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA31 BNE -> $00DA40
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DA40; }
    goto L_00DA33;
L_00DA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA33u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA33u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA33 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DA35;
L_00DA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA35u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA35 AND
    cpu.logicAnd(0x4u);
    goto L_00DA37;
L_00DA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA37u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA37 BEQ -> $00DA40
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DA40; }
    goto L_00DA39;
L_00DA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA39u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA39u, 4u, 3u, cpu.address("abs", 0x13E8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA39 STZ
    hw.write(cpu.address("abs", 0x13E8u), 0, cpu.m8?8:16);
    goto L_00DA3C;
L_00DA3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Cu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA3C INC
    cpu.incMem(hw, cpu.address("dp", 0x73u), cpu.m8?8:16);
    goto L_00DA3E;
L_00DA3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA3Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA3E BRA -> $00DA69
    goto L_00DA69;
L_00DA40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA40u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA40u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA40 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DA42;
L_00DA42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA42u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA42 AND
    cpu.logicAnd(0x3u);
    goto L_00DA44;
L_00DA44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA44u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA44 BEQ -> $00DA69
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DA69; }
    goto L_00DA46;
L_00DA46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA46u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA46u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA46 LDY
    cpu.setY(0x78u, 8);
    goto L_00DA48;
L_00DA48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA48u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA48u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA48 STY
    hw.write(cpu.address("dp", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_00DA4A;
L_00DA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA4A AND
    cpu.logicAnd(0x1u);
    goto L_00DA4C;
L_00DA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA4C STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00DA4E;
L_00DA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Eu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00DA4E PHA
    cpu.push("PHA", hw);
    goto L_00DA4F;
L_00DA4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA4F ASL
    cpu.aslA();
    goto L_00DA50;
L_00DA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA50u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA50 ASL
    cpu.aslA();
    goto L_00DA51;
L_00DA51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA51u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA51 TAX
    cpu.transfer("TAX");
    goto L_00DA52;
L_00DA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA52u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA52u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00DA52 PLA
    cpu.pop("PLA", hw);
    goto L_00DA53;
L_00DA53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA53u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA53u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA53 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_00DA55;
L_00DA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA55u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA55u, 4u, 3u, cpu.address("abs", 0x1403u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA55 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1403u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DA58;
L_00DA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA58u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA58 BEQ -> $00DA5D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DA5D; }
    goto L_00DA5A;
L_00DA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA5A CLC
    cpu.setFlag('C', false);
    goto L_00DA5B;
L_00DA5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA5B ADC
    cpu.adc(0x4u);
    goto L_00DA5D;
L_00DA5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA5D TAY
    cpu.transfer("TAY");
    goto L_00DA5E;
L_00DA5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA5E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DA60;
L_00DA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA60u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA60 BEQ -> $00DA64
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DA64; }
    goto L_00DA62;
L_00DA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA62u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA62 INY
    cpu.inc('Y');
    goto L_00DA63;
L_00DA63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA63u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA63u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA63 INY
    cpu.inc('Y');
    goto L_00DA64;
L_00DA64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA64u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA64u, 6u, 3u, cpu.address("abs", 0xD742u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DA64 JSR -> $00D742 stack real
    { cpu.push16Value(hw,0xDA66u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDA67u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD742u), 0x00DA64u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DA67;
L_00DA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA67u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA67u,0x00DA67u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA67u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA67u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA67 BRA -> $00DA7C
    goto L_00DA7C;
L_00DA69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA69u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA69u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA69 LDY
    cpu.setY(0x0u, 8);
    goto L_00DA6B;
L_00DA6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Bu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA6B TYX
    cpu.transfer("TYX");
    goto L_00DA6C;
L_00DA6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Cu, 4u, 3u, cpu.address("abs", 0x1403u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA6C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1403u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DA6F;
L_00DA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA6F BEQ -> $00DA79
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DA79; }
    goto L_00DA71;
L_00DA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA71u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA71u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA71 LDX
    cpu.setX(0x1Eu, 8);
    goto L_00DA73;
L_00DA73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA73u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA73u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA73 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DA75;
L_00DA75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA75u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA75u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA75 BNE -> $00DA79
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DA79; }
    goto L_00DA77;
L_00DA77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA77u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA77u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA77 INX
    cpu.inc('X');
    goto L_00DA78;
L_00DA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA78u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA78u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA78 INX
    cpu.inc('X');
    goto L_00DA79;
L_00DA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA79u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA79u, 6u, 3u, cpu.address("abs", 0xD772u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DA79 JSR -> $00D772 stack real
    { cpu.push16Value(hw,0xDA7Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDA7Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD772u), 0x00DA79u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DA7C;
L_00DA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA7Cu,0x00DA7Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Cu, 6u, 3u, cpu.address("abs", 0xD062u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DA7C JSR -> $00D062 stack real
    { cpu.push16Value(hw,0xDA7Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDA7Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD062u), 0x00DA7Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DA7F;
L_00DA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA7Fu,0x00DA7Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Fu, 8u, 4u, 0x00CEB1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00DA7F JSL -> $00CEB1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDA82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDA83u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00CEB1u, 0x00DA7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DA83;
L_00DA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA83u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA83u,0x00DA83u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA83u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA83u, 4u, 3u, cpu.address("abs", 0x14A6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA83 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DA86;
L_00DA86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA86u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA86u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA86 BNE -> $00DA8C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DA8C; }
    goto L_00DA88;
L_00DA88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA88u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA88u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA88 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DA8A;
L_00DA8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA8A BNE -> $00DA8D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DA8D; }
    goto L_00DA8C;
L_00DA8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DA8C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DA8Cu);return;} hw.unresolvedReturn(0x00DA8Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00DA8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA8D LDA
    cpu.setA(0x18u, 8);
    goto L_00DA8F;
L_00DA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Fu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Fu, 4u, 3u, cpu.address("abs", 0x149Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA8F LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x149Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DA92;
L_00DA92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA92u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA92 BNE -> $00DA9F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DA9F; }
    goto L_00DA94;
L_00DA94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA94u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA94u, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA94 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1496u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DA97;
L_00DA97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA97u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA97 LSR
    cpu.lsrA();
    goto L_00DA98;
L_00DA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA98u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA98u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA98 LSR
    cpu.lsrA();
    goto L_00DA99;
L_00DA99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA99u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA99 AND
    cpu.logicAnd(0x3u);
    goto L_00DA9B;
L_00DA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA9B TAY
    cpu.transfer("TAY");
    goto L_00DA9C;
L_00DA9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Cu, 4u + ((((0xD980u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD980u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA9C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD980u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DA9F;
L_00DA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Fu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Fu, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DA9F LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x148Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DAA2;
L_00DAA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DAA2 BEQ -> $00DAA5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DAA5; }
    goto L_00DAA4;
L_00DAA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DAA4 INC
    cpu.inc('A');
    goto L_00DAA5;
L_00DAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA5u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DAA5 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00DAA8;
L_00DAA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DAA8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DAA8u);return;} hw.unresolvedReturn(0x00DAA8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00E92B_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00E9ADu: goto L_00E9AD;
    case 0x00E9AFu: goto L_00E9AF;
    case 0x00E9B1u: goto L_00E9B1;
    case 0x00E9B2u: goto L_00E9B2;
    case 0x00E9B4u: goto L_00E9B4;
    case 0x00E9B5u: goto L_00E9B5;
    case 0x00E9B8u: goto L_00E9B8;
    case 0x00E9BAu: goto L_00E9BA;
    case 0x00E9BCu: goto L_00E9BC;
    case 0x00E9BEu: goto L_00E9BE;
    case 0x00E9BFu: goto L_00E9BF;
    case 0x00E9C1u: goto L_00E9C1;
    case 0x00E9C2u: goto L_00E9C2;
    case 0x00E9C5u: goto L_00E9C5;
    case 0x00E9C8u: goto L_00E9C8;
    case 0x00E9CAu: goto L_00E9CA;
    case 0x00E9CCu: goto L_00E9CC;
    case 0x00E9CEu: goto L_00E9CE;
    case 0x00E9D1u: goto L_00E9D1;
    case 0x00E9D3u: goto L_00E9D3;
    case 0x00E9D5u: goto L_00E9D5;
    case 0x00E9D7u: goto L_00E9D7;
    case 0x00E9D9u: goto L_00E9D9;
    case 0x00E9DCu: goto L_00E9DC;
    case 0x00E9DDu: goto L_00E9DD;
    case 0x00E9DEu: goto L_00E9DE;
    case 0x00E9DFu: goto L_00E9DF;
    case 0x00E9E0u: goto L_00E9E0;
    case 0x00E9E2u: goto L_00E9E2;
    case 0x00E9E4u: goto L_00E9E4;
    case 0x00E9E5u: goto L_00E9E5;
    case 0x00E9E7u: goto L_00E9E7;
    case 0x00E9EAu: goto L_00E9EA;
    case 0x00E9ECu: goto L_00E9EC;
    case 0x00E9EEu: goto L_00E9EE;
    case 0x00E9F0u: goto L_00E9F0;
    case 0x00E9F3u: goto L_00E9F3;
    case 0x00E9F6u: goto L_00E9F6;
    case 0x00E9F9u: goto L_00E9F9;
    case 0x00E9FBu: goto L_00E9FB;
    case 0x00E9FDu: goto L_00E9FD;
    case 0x00E9FFu: goto L_00E9FF;
    case 0x00EA01u: goto L_00EA01;
    case 0x00EA03u: goto L_00EA03;
    case 0x00EA06u: goto L_00EA06;
    case 0x00EA08u: goto L_00EA08;
    case 0x00EA0Bu: goto L_00EA0B;
    case 0x00EA0Du: goto L_00EA0D;
    case 0x00EA0Fu: goto L_00EA0F;
    case 0x00EA11u: goto L_00EA11;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00E9AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9ADu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ADu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9AD REP
    cpu.rep(0x20u);
    goto L_00E9AF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ADu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9AD REP
    cpu.rep(0x20u);
    goto L_00E9AF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ADu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9AD REP
    cpu.rep(0x20u);
    goto L_00E9AF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9ADu,0x00E9ADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9AFu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9AF LDY
    cpu.setY(0xAD00u, 16);
    goto L_00E9B2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9AF LDY
    cpu.setY(0x0u, 8);
    goto L_00E9B1;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9AF LDY
    cpu.setY(0x0u, 8);
    goto L_00E9B1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9AFu,0x00E9AFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9B1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B1u, 5u, 3u, cpu.address("abs", 0x1462u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9B1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1462u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9B4;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B1u, 5u, 3u, cpu.address("abs", 0x1462u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9B1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1462u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9B1u,0x00E9B1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B2u,cpu,0x62u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B2u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E9B2 PER
    cpu.push16Value(hw, 0x1C9u);
    goto L_00E9B5;
L_00E9B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9B4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9B4 CLC
    cpu.setFlag('C', false);
    goto L_00E9B5;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9B4 CLC
    cpu.setFlag('C', false);
    goto L_00E9B5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9B4u,0x00E9B4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9B5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9B5 ADC
    cpu.adc(0xE8u);
    goto L_00E9B8;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9B5 ADC
    cpu.adc(0xE8u);
    goto L_00E9B8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9B5 ADC
    cpu.adc(0xE8u);
    goto L_00E9B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9B5u,0x00E9B5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9B8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9B8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_00E9BA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9B8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_00E9BA;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9B8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_00E9BA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9B8u,0x00E9B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9BAu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9BA BEQ -> $00E9C8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E9C8; }
    goto L_00E9BC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9BA BEQ -> $00E9C8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E9C8; }
    goto L_00E9BC;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9BA BEQ -> $00E9C8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E9C8; }
    goto L_00E9BC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9BAu,0x00E9BAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9BCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9BC BMI -> $00E9C8
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E9C8; }
    goto L_00E9BE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9BC BMI -> $00E9C8
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E9C8; }
    goto L_00E9BE;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9BC BMI -> $00E9C8
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E9C8; }
    goto L_00E9BE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9BCu,0x00E9BCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9BEu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9BE INY
    cpu.inc('Y');
    goto L_00E9BF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9BE INY
    cpu.inc('Y');
    goto L_00E9BF;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9BE INY
    cpu.inc('Y');
    goto L_00E9BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9BEu,0x00E9BEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9BFu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9BF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9C1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9BF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9C1;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9BF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9C1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9BFu,0x00E9BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9C1u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9C1 SEC
    cpu.setFlag('C', true);
    goto L_00E9C2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9C1 SEC
    cpu.setFlag('C', true);
    goto L_00E9C2;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9C1 SEC
    cpu.setFlag('C', true);
    goto L_00E9C2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9C1u,0x00E9C1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9C2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9C2 SBC
    cpu.sbc(0x8u);
    goto L_00E9C5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9C2 SBC
    cpu.sbc(0x8u);
    goto L_00E9C5;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9C2 SBC
    cpu.sbc(0x8u);
    goto L_00E9C5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9C2u,0x00E9C2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9C5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C5u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C5u, 5u, 3u, cpu.address("abs", 0x1462u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9C5 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1462u), cpu.m8?8:16));
    goto L_00E9C8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C5u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C5u, 5u, 3u, cpu.address("abs", 0x1462u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9C5 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1462u), cpu.m8?8:16));
    goto L_00E9C8;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C5u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C5u, 5u, 3u, cpu.address("abs", 0x1462u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9C5 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1462u), cpu.m8?8:16));
    goto L_00E9C8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9C5u,0x00E9C5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9C8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9C8 SEP
    cpu.sep(0x20u);
    goto L_00E9CA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9C8 SEP
    cpu.sep(0x20u);
    goto L_00E9CA;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9C8 SEP
    cpu.sep(0x20u);
    goto L_00E9CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9C8u,0x00E9C8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9CAu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9CA BEQ -> $00E9FB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E9FB; }
    goto L_00E9CC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9CA BEQ -> $00E9FB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E9FB; }
    goto L_00E9CC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9CA BEQ -> $00E9FB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E9FB; }
    goto L_00E9CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9CAu,0x00E9CAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9CCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9CC BPL -> $00E9FB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E9FB; }
    goto L_00E9CE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9CC BPL -> $00E9FB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E9FB; }
    goto L_00E9CE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9CC BPL -> $00E9FB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E9FB; }
    goto L_00E9CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9CCu,0x00E9CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9CEu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CEu, 4u, 3u, cpu.address("abs", 0x1411u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9CE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1411u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9D1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CEu, 4u, 3u, cpu.address("abs", 0x1411u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9CE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1411u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9D1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CEu, 4u, 3u, cpu.address("abs", 0x1411u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9CE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1411u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9D1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9CEu,0x00E9CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9D1u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D1 BNE -> $00E9F6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E9F6; }
    goto L_00E9D3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D1 BNE -> $00E9F6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E9F6; }
    goto L_00E9D3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D1 BNE -> $00E9F6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E9F6; }
    goto L_00E9D3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9D1u,0x00E9D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9D3u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D3 LDA
    cpu.setA(0x80u, 8);
    goto L_00E9D5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D3 LDA
    cpu.setA(0x80u, 8);
    goto L_00E9D5;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D3 LDA
    cpu.setA(0x80u, 8);
    goto L_00E9D5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9D3u,0x00E9D3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9D5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D5u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D5 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00E9D7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D5u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D5 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00E9D7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D5u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D5 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00E9D7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9D5u,0x00E9D5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9D7u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D7 REP
    cpu.rep(0x20u);
    goto L_00E9D9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D7 REP
    cpu.rep(0x20u);
    goto L_00E9D9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D7 REP
    cpu.rep(0x20u);
    goto L_00E9D9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9D7u,0x00E9D7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9D9u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D9u, 5u, 3u, cpu.address("abs", 0x1446u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1446u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9DC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D9u, 5u, 3u, cpu.address("abs", 0x1446u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1446u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9DC;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D9u, 5u, 3u, cpu.address("abs", 0x1446u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9D9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1446u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9DC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9D9u,0x00E9D9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9DCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DCu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9DC LSR
    cpu.lsrA();
    goto L_00E9DD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DCu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9DC LSR
    cpu.lsrA();
    goto L_00E9DD;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DCu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9DC LSR
    cpu.lsrA();
    goto L_00E9DD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9DCu,0x00E9DCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9DDu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9DD LSR
    cpu.lsrA();
    goto L_00E9DE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9DD LSR
    cpu.lsrA();
    goto L_00E9DE;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9DD LSR
    cpu.lsrA();
    goto L_00E9DE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9DDu,0x00E9DDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9DEu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9DE LSR
    cpu.lsrA();
    goto L_00E9DF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9DE LSR
    cpu.lsrA();
    goto L_00E9DF;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9DE LSR
    cpu.lsrA();
    goto L_00E9DF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9DEu,0x00E9DEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9DFu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9DF LSR
    cpu.lsrA();
    goto L_00E9E0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9DF LSR
    cpu.lsrA();
    goto L_00E9E0;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9DF LSR
    cpu.lsrA();
    goto L_00E9E0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9DFu,0x00E9DFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9E0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E0 SEP
    cpu.sep(0x20u);
    goto L_00E9E2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E0 SEP
    cpu.sep(0x20u);
    goto L_00E9E2;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E0 SEP
    cpu.sep(0x20u);
    goto L_00E9E2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9E0u,0x00E9E0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9E2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00E9E4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00E9E4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00E9E4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9E2u,0x00E9E2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9E4u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E4 SEC
    cpu.setFlag('C', true);
    goto L_00E9E5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E4 SEC
    cpu.setFlag('C', true);
    goto L_00E9E5;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E4 SEC
    cpu.setFlag('C', true);
    goto L_00E9E5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9E4u,0x00E9E4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9E5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00E9E7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00E9E7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00E9E7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9E5u,0x00E9E5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9E7u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E7u,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E7u, 4u + 1u, 3u, cpu.address("absy", 0xE90Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E7 EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xE90Eu), cpu.m8?8:16));
    goto L_00E9EA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E7u,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E7u, 4u + ((((0xE90Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E7 EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xE90Eu), cpu.m8?8:16));
    goto L_00E9EA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E7u,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E7u, 4u + ((((0xE90Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9E7 EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xE90Eu), cpu.m8?8:16));
    goto L_00E9EA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9E7u,0x00E9E7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9EAu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EA BMI -> $00E9F6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E9F6; }
    goto L_00E9EC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EA BMI -> $00E9F6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E9F6; }
    goto L_00E9EC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EA BMI -> $00E9F6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E9F6; }
    goto L_00E9EC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9EAu,0x00E9EAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9ECu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9EE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9EE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9EE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9ECu,0x00E9ECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9EEu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EE STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00E9F0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EE STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00E9F0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9EE STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00E9F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9EEu,0x00E9EEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u, 4u, 3u, cpu.address("abs", 0x144Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x144Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9F3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u, 4u, 3u, cpu.address("abs", 0x144Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x144Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9F3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u, 4u, 3u, cpu.address("abs", 0x144Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x144Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9F0u,0x00E9F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F3u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u, 4u, 3u, cpu.address("abs", 0x13DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F3 STA
    hw.write(cpu.address("abs", 0x13DAu), cpu.a, cpu.m8?8:16);
    goto L_00E9F6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u, 4u, 3u, cpu.address("abs", 0x13DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F3 STA
    hw.write(cpu.address("abs", 0x13DAu), cpu.a, cpu.m8?8:16);
    goto L_00E9F6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u, 4u, 3u, cpu.address("abs", 0x13DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F3 STA
    hw.write(cpu.address("abs", 0x13DAu), cpu.a, cpu.m8?8:16);
    goto L_00E9F6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9F3u,0x00E9F3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F6u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F6u, 4u + 1u, 3u, cpu.address("absy", 0xE90Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE90Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9F9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F6u, 4u + ((((0xE90Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE90Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9F9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F6u, 4u + ((((0xE90Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE90Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9F6u,0x00E9F6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F9u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F9 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00E9FB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F9 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00E9FB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9F9 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00E9FB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9F9u,0x00E9F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9FBu))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9FD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9FD;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E9FD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9FBu,0x00E9FBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9FDu))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FD AND
    cpu.logicAnd(0x1Cu);
    goto L_00E9FF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FD AND
    cpu.logicAnd(0x1Cu);
    goto L_00E9FF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FD AND
    cpu.logicAnd(0x1Cu);
    goto L_00E9FF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9FDu,0x00E9FDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9FFu))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FF CMP
    cpu.compareA(0x1Cu);
    goto L_00EA01;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FF CMP
    cpu.compareA(0x1Cu);
    goto L_00EA01;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E9FF CMP
    cpu.compareA(0x1Cu);
    goto L_00EA01;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9FFu,0x00E9FFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA01u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA01u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA01 BNE -> $00EA0D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA0D; }
    goto L_00EA03;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA01u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA01 BNE -> $00EA0D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA0D; }
    goto L_00EA03;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA01u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA01 BNE -> $00EA0D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA0D; }
    goto L_00EA03;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA01u,0x00EA01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA03u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA03 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA06;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA03 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA06;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA03 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA03u,0x00EA03u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA06u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA06u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA06 BNE -> $00EA0D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA0D; }
    goto L_00EA08;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA06u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA06 BNE -> $00EA0D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA0D; }
    goto L_00EA08;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA06u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA06 BNE -> $00EA0D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA0D; }
    goto L_00EA08;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA06u,0x00EA06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA08u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA08u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA08u, 6u, 3u, cpu.address("abs", 0xF629u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA08 JSR -> $00F629 stack real
    { cpu.push16Value(hw,0xEA0Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF629u), 0x00EA08u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA08u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA08u, 6u, 3u, cpu.address("abs", 0xF629u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA08 JSR -> $00F629 stack real
    { cpu.push16Value(hw,0xEA0Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF629u), 0x00EA08u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA0B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA08u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA08u, 6u, 3u, cpu.address("abs", 0xF629u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA08 JSR -> $00F629 stack real
    { cpu.push16Value(hw,0xEA0Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF629u), 0x00EA08u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA08u,0x00EA08u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA0Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0B BRA -> $00EA32
    hw.requestDispatch(0x00EA32u,0x00EA0Bu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0B BRA -> $00EA32
    hw.requestDispatch(0x00EA32u,0x00EA0Bu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0B BRA -> $00EA32
    hw.requestDispatch(0x00EA32u,0x00EA0Bu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,0x00EA0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA0Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA0F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA0F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA0F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA0Du,0x00EA0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA0Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0F AND
    cpu.logicAnd(0x3u);
    goto L_00EA11;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0F AND
    cpu.logicAnd(0x3u);
    goto L_00EA11;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA0F AND
    cpu.logicAnd(0x3u);
    goto L_00EA11;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA0Fu,0x00EA0Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA11u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA11 BEQ -> $00EA34
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA34u,0x00EA11u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA13u,0x00EA11u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA11 BEQ -> $00EA34
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA34u,0x00EA11u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA13u,0x00EA11u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA11 BEQ -> $00EA34
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA34u,0x00EA11u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA13u,0x00EA11u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA11u,0x00EA11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00E92B_E1M1X1CQ_part3(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EA24u: goto L_00EA24;
    case 0x00EA26u: goto L_00EA26;
    case 0x00EA28u: goto L_00EA28;
    case 0x00EA2Bu: goto L_00EA2B;
    case 0x00EA2Du: goto L_00EA2D;
    case 0x00EA30u: goto L_00EA30;
    case 0x00EA32u: goto L_00EA32;
    case 0x00EA34u: goto L_00EA34;
    case 0x00EA37u: goto L_00EA37;
    case 0x00EA39u: goto L_00EA39;
    case 0x00EA3Bu: goto L_00EA3B;
    case 0x00EA3Du: goto L_00EA3D;
    case 0x00EA3Fu: goto L_00EA3F;
    case 0x00EA42u: goto L_00EA42;
    case 0x00EA45u: goto L_00EA45;
    case 0x00EA47u: goto L_00EA47;
    case 0x00EA49u: goto L_00EA49;
    case 0x00EA4Bu: goto L_00EA4B;
    case 0x00EA4Du: goto L_00EA4D;
    case 0x00EA4Fu: goto L_00EA4F;
    case 0x00EA51u: goto L_00EA51;
    case 0x00EA53u: goto L_00EA53;
    case 0x00EA55u: goto L_00EA55;
    case 0x00EA57u: goto L_00EA57;
    case 0x00EA59u: goto L_00EA59;
    case 0x00EA5Cu: goto L_00EA5C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA24u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA24u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA24 BMI -> $00EA34
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA34; }
    goto L_00EA26;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA24u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA24 BMI -> $00EA34
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA34; }
    goto L_00EA26;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA24u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA24 BMI -> $00EA34
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA34; }
    goto L_00EA26;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA24u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA24 BMI -> $00EA34
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA34; }
    goto L_00EA26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA24u,0x00EA24u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA26u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA26 LDA
    cpu.setA(0x3u, 8);
    goto L_00EA28;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA26 LDA
    cpu.setA(0x3u, 8);
    goto L_00EA28;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA26 LDA
    cpu.setA(0x3u, 8);
    goto L_00EA28;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA26 LDA
    cpu.setA(0x3u, 8);
    goto L_00EA28;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA26u,0x00EA26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA28u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA28u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA28u, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA28 STA
    hw.write(cpu.address("abs", 0x13E5u), cpu.a, cpu.m8?8:16);
    goto L_00EA2B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA28u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA28u, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA28 STA
    hw.write(cpu.address("abs", 0x13E5u), cpu.a, cpu.m8?8:16);
    goto L_00EA2B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA28u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA28u, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA28 STA
    hw.write(cpu.address("abs", 0x13E5u), cpu.a, cpu.m8?8:16);
    goto L_00EA2B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA28u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA28u, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA28 STA
    hw.write(cpu.address("abs", 0x13E5u), cpu.a, cpu.m8?8:16);
    goto L_00EA2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA28u,0x00EA28u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA2Bu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA2B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA2D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA2B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA2D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA2B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA2D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA2B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA2D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA2Bu,0x00EA2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA2Du))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Du,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Du, 4u + 1u, 3u, cpu.address("absy", 0xE90Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA2D EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xE90Du), cpu.m8?8:16));
    goto L_00EA30;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Du,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Du, 4u + ((((0xE90Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA2D EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xE90Du), cpu.m8?8:16));
    goto L_00EA30;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Du,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Du, 4u + 1u, 3u, cpu.address("absy", 0xE90Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA2D EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xE90Du), cpu.m8?8:16));
    goto L_00EA30;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Du,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Du, 4u + ((((0xE90Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA2D EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xE90Du), cpu.m8?8:16));
    goto L_00EA30;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA2Du,0x00EA2Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA30u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA30u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA30u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA30 BPL -> $00EA34
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA34; }
    goto L_00EA32;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA30u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA30u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA30 BPL -> $00EA34
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA34; }
    goto L_00EA32;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA30u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA30u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA30 BPL -> $00EA34
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA34; }
    goto L_00EA32;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA30u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA30u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA30 BPL -> $00EA34
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA34; }
    goto L_00EA32;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA30u,0x00EA30u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA32u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA32u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA32u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA32 STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00EA34;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA32u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA32u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA32 STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00EA34;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA32u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA32u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA32 STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00EA34;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA32u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA32u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA32 STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00EA34;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA32u,0x00EA32u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA34u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA34u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA34u, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA34 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13F9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA37;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA34u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA34u, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA34 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13F9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA37;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA34u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA34u, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA34 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13F9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA37;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA34u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA34u, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA34 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13F9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA37;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA34u,0x00EA34u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA37u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA37u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA37 CMP
    cpu.compareA(0x1u);
    goto L_00EA39;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA37u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA37 CMP
    cpu.compareA(0x1u);
    goto L_00EA39;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA37u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA37 CMP
    cpu.compareA(0x1u);
    goto L_00EA39;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA37u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA37 CMP
    cpu.compareA(0x1u);
    goto L_00EA39;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA37u,0x00EA37u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA39u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA39u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA39 BNE -> $00EA42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA42; }
    goto L_00EA3B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA39u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA39 BNE -> $00EA42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA42; }
    goto L_00EA3B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA39u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA39 BNE -> $00EA42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA42; }
    goto L_00EA3B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA39u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA39 BNE -> $00EA42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA42; }
    goto L_00EA3B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA39u,0x00EA39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA3Bu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA3D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA3D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA3D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA3D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA3Bu,0x00EA3Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA3Du))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3D BNE -> $00EA42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA42; }
    goto L_00EA3F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3D BNE -> $00EA42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA42; }
    goto L_00EA3F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3D BNE -> $00EA42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA42; }
    goto L_00EA3F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3D BNE -> $00EA42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA42; }
    goto L_00EA3F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA3Du,0x00EA3Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA3Fu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Fu, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3F STZ
    hw.write(cpu.address("abs", 0x13F9u), 0, cpu.m8?8:16);
    goto L_00EA42;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Fu, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3F STZ
    hw.write(cpu.address("abs", 0x13F9u), 0, cpu.m8?8:16);
    goto L_00EA42;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Fu, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3F STZ
    hw.write(cpu.address("abs", 0x13F9u), 0, cpu.m8?8:16);
    goto L_00EA42;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Fu, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3F STZ
    hw.write(cpu.address("abs", 0x13F9u), 0, cpu.m8?8:16);
    goto L_00EA42;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA3Fu,0x00EA3Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA42u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u, 4u, 3u, cpu.address("abs", 0x13FAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA42 STZ
    hw.write(cpu.address("abs", 0x13FAu), 0, cpu.m8?8:16);
    goto L_00EA45;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u, 4u, 3u, cpu.address("abs", 0x13FAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA42 STZ
    hw.write(cpu.address("abs", 0x13FAu), 0, cpu.m8?8:16);
    goto L_00EA45;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u, 4u, 3u, cpu.address("abs", 0x13FAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA42 STZ
    hw.write(cpu.address("abs", 0x13FAu), 0, cpu.m8?8:16);
    goto L_00EA45;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u, 4u, 3u, cpu.address("abs", 0x13FAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA42 STZ
    hw.write(cpu.address("abs", 0x13FAu), 0, cpu.m8?8:16);
    goto L_00EA45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA42u,0x00EA42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA45u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA45 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA47;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA45 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA47;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA45 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA47;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA45 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA47;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA45u,0x00EA45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA47u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA47 BNE -> $00EA5E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA5Eu,0x00EA47u); return; }
    goto L_00EA49;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA47 BNE -> $00EA5E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA5Eu,0x00EA47u); return; }
    goto L_00EA49;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA47 BNE -> $00EA5E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA5Eu,0x00EA47u); return; }
    goto L_00EA49;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA47 BNE -> $00EA5E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA5Eu,0x00EA47u); return; }
    goto L_00EA49;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA47u,0x00EA47u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA49u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA49 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA4B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA49 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA4B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA49 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA4B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA49 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA4B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA49u,0x00EA49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA4Bu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4B BCC -> $00EAA3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA3u,0x00EA4Bu); return; }
    goto L_00EA4D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4B BCC -> $00EAA3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA3u,0x00EA4Bu); return; }
    goto L_00EA4D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4B BCC -> $00EAA3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA3u,0x00EA4Bu); return; }
    goto L_00EA4D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4B BCC -> $00EAA3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA3u,0x00EA4Bu); return; }
    goto L_00EA4D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA4Bu,0x00EA4Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA4Du))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA4F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA4F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA4F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA4F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA4Du,0x00EA4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA4Fu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4F BNE -> $00EA65
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA65u,0x00EA4Fu); return; }
    goto L_00EA51;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4F BNE -> $00EA65
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA65u,0x00EA4Fu); return; }
    goto L_00EA51;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4F BNE -> $00EA65
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA65u,0x00EA4Fu); return; }
    goto L_00EA51;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4F BNE -> $00EA65
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA65u,0x00EA4Fu); return; }
    goto L_00EA51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA4Fu,0x00EA4Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA51u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA51u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA51u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA51 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA53;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA51u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA51u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA51 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA53;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA51u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA51u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA51 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA53;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA51u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA51u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA51 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA53;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA51u,0x00EA51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA53u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA53 BMI -> $00EA65
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA65u,0x00EA53u); return; }
    goto L_00EA55;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA53 BMI -> $00EA65
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA65u,0x00EA53u); return; }
    goto L_00EA55;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA53 BMI -> $00EA65
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA65u,0x00EA53u); return; }
    goto L_00EA55;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA53 BMI -> $00EA65
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA65u,0x00EA53u); return; }
    goto L_00EA55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA53u,0x00EA53u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA55u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA55u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA55u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA55 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA57;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA55u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA55u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA55 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA57;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA55u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA55u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA55 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA57;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA55u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA55u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA55 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA57;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA55u,0x00EA55u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA57u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA57u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA57 BCC -> $00EAA5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA5u,0x00EA57u); return; }
    goto L_00EA59;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA57u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA57 BCC -> $00EAA5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA5u,0x00EA57u); return; }
    goto L_00EA59;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA57u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA57 BCC -> $00EAA5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA5u,0x00EA57u); return; }
    goto L_00EA59;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA57u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA57 BCC -> $00EAA5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA5u,0x00EA57u); return; }
    goto L_00EA59;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA57u,0x00EA57u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA59u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA59u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA59u, 6u, 3u, cpu.address("abs", 0xFDA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA59 JSR -> $00FDA5 stack real
    { cpu.push16Value(hw,0xEA5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA5u), 0x00EA59u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA5C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA59u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA59u, 6u, 3u, cpu.address("abs", 0xFDA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA59 JSR -> $00FDA5 stack real
    { cpu.push16Value(hw,0xEA5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA5u), 0x00EA59u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA5C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA59u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA59u, 6u, 3u, cpu.address("abs", 0xFDA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA59 JSR -> $00FDA5 stack real
    { cpu.push16Value(hw,0xEA5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA5u), 0x00EA59u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA5C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA59u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA59u, 6u, 3u, cpu.address("abs", 0xFDA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA59 JSR -> $00FDA5 stack real
    { cpu.push16Value(hw,0xEA5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA5u), 0x00EA59u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA5C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA59u,0x00EA59u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA5Cu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA5C STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA5Eu,0x00EA5Cu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA5C STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA5Eu,0x00EA5Cu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA5C STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA5Eu,0x00EA5Cu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA5C STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA5Eu,0x00EA5Cu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,0x00EA5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E0M1X1CQ_part13(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EEAAu: goto L_00EEAA;
    case 0x00EEABu: goto L_00EEAB;
    case 0x00EEACu: goto L_00EEAC;
    case 0x00EEADu: goto L_00EEAD;
    case 0x00EEAEu: goto L_00EEAE;
    case 0x00EEB1u: goto L_00EEB1;
    case 0x00EEB3u: goto L_00EEB3;
    case 0x00EEB4u: goto L_00EEB4;
    case 0x00EEB7u: goto L_00EEB7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEAAu))return;
  // 17 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAA TXA
    cpu.transfer("TXA");
    goto L_00EEAB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAA TXA
    cpu.transfer("TXA");
    goto L_00EEAB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAA TXA
    cpu.transfer("TXA");
    goto L_00EEAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAAu,0x00EEAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEABu))return;
  // 17 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAB LSR
    cpu.lsrA();
    goto L_00EEAC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAB LSR
    cpu.lsrA();
    goto L_00EEAC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAB LSR
    cpu.lsrA();
    goto L_00EEAC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEABu,0x00EEABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEACu))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAC LSR
    cpu.lsrA();
    goto L_00EEAD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAC LSR
    cpu.lsrA();
    goto L_00EEAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEACu,0x00EEACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEADu))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEADu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAD TAX
    cpu.transfer("TAX");
    goto L_00EEAE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEADu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAD TAX
    cpu.transfer("TAX");
    goto L_00EEAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEADu,0x00EEADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEAEu))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAEu, 4u + 1u, 3u, cpu.address("absx", 0x1F27u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F27u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEB1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAEu, 4u + ((((0x1F27u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F27u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F27u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEB1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAEu,0x00EEAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB1u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB1 BNE -> $00EED1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EEB1u); return; }
    goto L_00EEB3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB1 BNE -> $00EED1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EEB1u); return; }
    goto L_00EEB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB1u,0x00EEB1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB3u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB3 INC
    cpu.inc('A');
    goto L_00EEB4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB3 INC
    cpu.inc('A');
    goto L_00EEB4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB3u,0x00EEB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB4u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB4u, 5u, 3u, cpu.address("absx", 0x1F27u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB4 STA
    hw.write(cpu.address("absx", 0x1F27u), cpu.a, cpu.m8?8:16);
    goto L_00EEB7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB4u, 5u, 3u, cpu.address("absx", 0x1F27u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB4 STA
    hw.write(cpu.address("absx", 0x1F27u), cpu.a, cpu.m8?8:16);
    goto L_00EEB7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB4u,0x00EEB4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB7u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB7u, 4u, 3u, cpu.address("abs", 0x13D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB7 STA
    hw.write(cpu.address("abs", 0x13D2u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBAu,0x00EEB7u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB7u, 4u, 3u, cpu.address("abs", 0x13D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB7 STA
    hw.write(cpu.address("abs", 0x13D2u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBAu,0x00EEB7u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB7u,0x00EEB7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E1M1X1CQ_part18(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF28u: goto L_00EF28;
    case 0x00EF29u: goto L_00EF29;
    case 0x00EF2Au: goto L_00EF2A;
    case 0x00EF2Bu: goto L_00EF2B;
    case 0x00EF2Cu: goto L_00EF2C;
    case 0x00EF2Du: goto L_00EF2D;
    case 0x00EF2Eu: goto L_00EF2E;
    case 0x00EF2Fu: goto L_00EF2F;
    case 0x00EF30u: goto L_00EF30;
    case 0x00EF31u: goto L_00EF31;
    case 0x00EF32u: goto L_00EF32;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF28u))return;
  // 13 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF28u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF28 BCC -> $00EF2F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EF2F; }
    goto L_00EF2A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF28u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF28 BCC -> $00EF2F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EF2F; }
    goto L_00EF2A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF28u,0x00EF28u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF29u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF29u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF29u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF29 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xB9u), cpu.m8?8:16));
    goto L_00EF2B;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF29u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF29u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF29 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xB9u), cpu.m8?8:16));
    goto L_00EF2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF29u,0x00EF29u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Au))return;
  // 13 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Au, 4u + 1u, 3u, cpu.address("absy", 0xE4FBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE4FBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF2D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Au, 4u + ((((0xE4FBu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4FBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE4FBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF2D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF2Au,0x00EF2Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Bu))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Bu,cpu,0xFBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2B XCE
    cpu.xce();
    goto L_00EF2C;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Bu,cpu,0xFBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2B XCE
    cpu.xce();
    goto L_00EF2C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF2Bu,0x00EF2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Cu))return;
  // 19 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Cu,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2C CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x80u), cpu.x8?8:16));
    goto L_00EF2E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Cu,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2C CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x80u), cpu.x8?8:16));
    goto L_00EF2E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Cu,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2C CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x80u), cpu.x8?8:16));
    goto L_00EF2E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF2Cu,0x00EF2Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Du))return;
  // 13 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2D BRA -> $00EF60
    hw.requestDispatch(0x00EF60u,0x00EF2Du); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2D BRA -> $00EF60
    hw.requestDispatch(0x00EF60u,0x00EF2Du); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF2Du,0x00EF2Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Eu))return;
  // 19 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Eu,cpu,0x31u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA0u) & 0xFFFFu), 2u, 0u);
    // $00EF2E AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirectY(hw, 0xA0u), cpu.m8?8:16));
    goto L_00EF30;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Eu,cpu,0x31u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA0u) & 0xFFFFu), 2u, 0u);
    // $00EF2E AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirectY(hw, 0xA0u), cpu.m8?8:16));
    goto L_00EF30;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Eu,cpu,0x31u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA0u) & 0xFFFFu), 2u, 0u);
    // $00EF2E AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirectY(hw, 0xA0u), cpu.m8?8:16));
    goto L_00EF30;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF2Eu,0x00EF2Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Fu))return;
  // 13 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2F LDY
    cpu.setY(0xA520u, 16);
    goto L_00EF32;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2F LDY
    cpu.setY(0x20u, 8);
    goto L_00EF31;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF2Fu,0x00EF2Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF30u))return;
  // 19 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF30u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF30u, 6u, 3u, cpu.address("abs", 0x7DA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF30 JSR -> $007DA5 stack real
    { cpu.push16Value(hw,0xEF32u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF33u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x7DA5u), 0x00EF30u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF33u,0x00EF30u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF30u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF30u, 6u, 3u, cpu.address("abs", 0x7DA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF30 JSR -> $007DA5 stack real
    { cpu.push16Value(hw,0xEF32u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF33u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x7DA5u), 0x00EF30u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF33u,0x00EF30u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF30u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF30u, 6u, 3u, cpu.address("abs", 0x7DA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF30 JSR -> $007DA5 stack real
    { cpu.push16Value(hw,0xEF32u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF33u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x7DA5u), 0x00EF30u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF33u,0x00EF30u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF30u,0x00EF30u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF31u))return;
  // 23 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF31 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF33u,0x00EF31u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF31 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF33u,0x00EF31u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF31 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF33u,0x00EF31u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF31 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF33u,0x00EF31u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF31u,0x00EF31u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF32u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF32u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF32u, 4u + 1u, 3u, cpu.address("absx", 0xDAD9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF32 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xDAD9u), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF35u,0x00EF32u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF32u,0x00EF32u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00F04D_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F04Du: goto L_00F04D;
    case 0x00F04Eu: goto L_00F04E;
    case 0x00F050u: goto L_00F050;
    case 0x00F054u: goto L_00F054;
    case 0x00F056u: goto L_00F056;
    case 0x00F057u: goto L_00F057;
    case 0x00F059u: goto L_00F059;
    case 0x00F05Au: goto L_00F05A;
    case 0x00F05Bu: goto L_00F05B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF04Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Du,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F04D PHX
    cpu.push("PHX", hw);
    goto L_00F04E;
L_00F04E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF04Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F04E LDX
    cpu.setX(0x19u, 8);
    goto L_00F050;
L_00F050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF050u,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF050u, 5u, 4u, ((0x00EAC1u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F050 CMP
    cpu.compareA(hw.readW(((0xEAC1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F054;
L_00F054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF054u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF054u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F054 BEQ -> $00F05A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F05A; }
    goto L_00F056;
L_00F056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF056u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF056u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF056u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F056 DEX
    cpu.decReg('X');
    goto L_00F057;
L_00F057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF057u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF057u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F057 BPL -> $00F050
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00F050; }
    goto L_00F059;
L_00F059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF059u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF059u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F059 CLC
    cpu.setFlag('C', false);
    goto L_00F05A;
L_00F05A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF05Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Au,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F05A PLX
    cpu.pop("PLX", hw);
    goto L_00F05B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Au,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F05A PLX
    cpu.pop("PLX", hw);
    goto L_00F05B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF05Au,0x00F05Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF05Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F05B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00F05Bu);return;} hw.unresolvedReturn(0x00F05Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F05B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00F05Bu);return;} hw.unresolvedReturn(0x00F05Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF05Bu,0x00F05Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00F606_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F606u: goto L_00F606;
    case 0x00F608u: goto L_00F608;
    case 0x00F60Au: goto L_00F60A;
    case 0x00F60Cu: goto L_00F60C;
    case 0x00F60Fu: goto L_00F60F;
    case 0x00F611u: goto L_00F611;
    case 0x00F614u: goto L_00F614;
    case 0x00F616u: goto L_00F616;
    case 0x00F618u: goto L_00F618;
    case 0x00F61Bu: goto L_00F61B;
    case 0x00F61Du: goto L_00F61D;
    case 0x00F620u: goto L_00F620;
    case 0x00F622u: goto L_00F622;
    case 0x00F625u: goto L_00F625;
    case 0x00F628u: goto L_00F628;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF606u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF606u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F606 LDA
    cpu.setA(0x90u, 8);
    goto L_00F608;
L_00F608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF608u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF608u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F608 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00F60A;
L_00F60A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF60Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF60Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF60Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F60A LDA
    cpu.setA(0x9u, 8);
    goto L_00F60C;
L_00F60C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF60Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF60Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF60Cu, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F60C STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_00F60F;
L_00F60F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF60Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF60Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF60Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F60F LDA
    cpu.setA(0xFFu, 8);
    goto L_00F611;
L_00F611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF611u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF611u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F611 STA
    hw.write(cpu.address("abs", 0xDDAu), cpu.a, cpu.m8?8:16);
    goto L_00F614;
L_00F614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF614u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF614u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F614 LDA
    cpu.setA(0x9u, 8);
    goto L_00F616;
L_00F616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF616u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF616u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F616 STA
    hw.write(cpu.address("dp", 0x71u), cpu.a, cpu.m8?8:16);
    goto L_00F618;
L_00F618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF618u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF618u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F618 STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    goto L_00F61B;
L_00F61B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF61Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF61Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF61Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F61B LDA
    cpu.setA(0x30u, 8);
    goto L_00F61D;
L_00F61D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF61Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF61Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF61Du, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F61D STA
    hw.write(cpu.address("abs", 0x1496u), cpu.a, cpu.m8?8:16);
    goto L_00F620;
L_00F620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF620u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF620u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F620 STA
    hw.write(cpu.address("dp", 0x9Du), cpu.a, cpu.m8?8:16);
    goto L_00F622;
L_00F622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF622u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF622u, 4u, 3u, cpu.address("abs", 0x1407u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F622 STZ
    hw.write(cpu.address("abs", 0x1407u), 0, cpu.m8?8:16);
    goto L_00F625;
L_00F625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF625u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF625u, 4u, 3u, cpu.address("abs", 0x188Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F625 STZ
    hw.write(cpu.address("abs", 0x188Au), 0, cpu.m8?8:16);
    goto L_00F628;
L_00F628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF628u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF628u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF628u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F628 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00F628u);return;} hw.unresolvedReturn(0x00F628u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_019CF3_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019CF3u: goto L_019CF3;
    case 0x019CF5u: goto L_019CF5;
    case 0x019CF7u: goto L_019CF7;
    case 0x019CF9u: goto L_019CF9;
    case 0x019CFCu: goto L_019CFC;
    case 0x019CFEu: goto L_019CFE;
    case 0x019CFFu: goto L_019CFF;
    case 0x019D00u: goto L_019D00;
    case 0x019D02u: goto L_019D02;
    case 0x019D04u: goto L_019D04;
    case 0x019D06u: goto L_019D06;
    case 0x019D09u: goto L_019D09;
    case 0x019D0Au: goto L_019D0A;
    case 0x019D0Bu: goto L_019D0B;
    case 0x019D0Eu: goto L_019D0E;
    case 0x019D10u: goto L_019D10;
    case 0x019D13u: goto L_019D13;
    case 0x019D15u: goto L_019D15;
    case 0x019D17u: goto L_019D17;
    case 0x019D1Au: goto L_019D1A;
    case 0x019D1Cu: goto L_019D1C;
    case 0x019D1Eu: goto L_019D1E;
    case 0x019D1Fu: goto L_019D1F;
    case 0x019D21u: goto L_019D21;
    case 0x019D23u: goto L_019D23;
    case 0x019D24u: goto L_019D24;
    case 0x019D27u: goto L_019D27;
    case 0x019D2Au: goto L_019D2A;
    case 0x019D2Cu: goto L_019D2C;
    case 0x019D2Du: goto L_019D2D;
    case 0x019D30u: goto L_019D30;
    case 0x019D33u: goto L_019D33;
    case 0x019D35u: goto L_019D35;
    case 0x019D36u: goto L_019D36;
    case 0x019D38u: goto L_019D38;
    case 0x019D39u: goto L_019D39;
    case 0x019D3Cu: goto L_019D3C;
    case 0x019D3Fu: goto L_019D3F;
    case 0x019D41u: goto L_019D41;
    case 0x019D42u: goto L_019D42;
    case 0x019D43u: goto L_019D43;
    case 0x019D45u: goto L_019D45;
    case 0x019D46u: goto L_019D46;
    case 0x019D49u: goto L_019D49;
    case 0x019D4Bu: goto L_019D4B;
    case 0x019D4Eu: goto L_019D4E;
    case 0x019D4Fu: goto L_019D4F;
    case 0x019D50u: goto L_019D50;
    case 0x019D51u: goto L_019D51;
    case 0x019D52u: goto L_019D52;
    case 0x019D54u: goto L_019D54;
    case 0x019D56u: goto L_019D56;
    case 0x019D57u: goto L_019D57;
    case 0x019D59u: goto L_019D59;
    case 0x019D5Bu: goto L_019D5B;
    case 0x019D5Eu: goto L_019D5E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019CF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019CF3 LDY
    cpu.setY(0x0u, 8);
    goto L_019CF5;
L_019CF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019CF5 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_019CF7;
L_019CF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF7u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019CF7 STY
    hw.write(cpu.address("dp", 0xFu), cpu.y, cpu.x8?8:16);
    goto L_019CF9;
L_019CF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF9u, 6u, 3u, cpu.address("abs", 0xA365u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019CF9 JSR -> $01A365 stack real
    { cpu.push16Value(hw,0x9CFBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9CFCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA365u), 0x019CF9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019CFC;
L_019CFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CFCu,0x019CFCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFCu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019CFC LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019CFE;
L_019CFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFEu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019CFE TYA
    cpu.transfer("TYA");
    goto L_019CFF;
L_019CFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019CFF CLC
    cpu.setFlag('C', false);
    goto L_019D00;
L_019D00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D00u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D00u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D00 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16));
    goto L_019D02;
L_019D02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D02u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D02u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D02 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_019D04;
L_019D04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D04u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D04u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D04 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019D06;
L_019D06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D06u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D06u, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D06 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D09;
L_019D09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D09u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D09 ASL
    cpu.aslA();
    goto L_019D0A;
L_019D0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D0A ASL
    cpu.aslA();
    goto L_019D0B;
L_019D0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Bu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Bu, 4u + ((((0x9C7Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9C7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D0B ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x9C7Fu), cpu.m8?8:16));
    goto L_019D0E;
L_019D0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D0E STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_019D10;
L_019D10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D10u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D10u, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D10 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D13;
L_019D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D13u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D13u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D13 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16));
    goto L_019D15;
L_019D15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D15u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D15 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_019D17;
L_019D17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D17u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D17u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D17 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019D1A;
L_019D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D1A LDA
    cpu.setA(0x3u, 8);
    goto L_019D1C;
L_019D1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D1C STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_019D1E;
L_019D1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Eu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019D1E PHX
    cpu.push("PHX", hw);
    goto L_019D1F;
L_019D1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D1F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019D21;
L_019D21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D21u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D21u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D21 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D23;
L_019D23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D23u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D23 CLC
    cpu.setFlag('C', false);
    goto L_019D24;
L_019D24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D24u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D24u, 4u + ((((0x9CD3u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9CD3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D24 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x9CD3u), cpu.m8?8:16));
    goto L_019D27;
L_019D27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D27u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D27u, 5u, 3u, cpu.address("absy", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D27 STA
    hw.write(cpu.address("absy", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_019D2A;
L_019D2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D2A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D2C;
L_019D2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D2C CLC
    cpu.setFlag('C', false);
    goto L_019D2D;
L_019D2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Du,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Du, 4u + ((((0x9CD7u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9CD7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D2D ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x9CD7u), cpu.m8?8:16));
    goto L_019D30;
L_019D30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D30u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D30u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D30 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_019D33;
L_019D33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D33u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D33u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D33 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D35;
L_019D35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D35u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D35 CLC
    cpu.setFlag('C', false);
    goto L_019D36;
L_019D36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D36u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D36u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D36 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_019D38;
L_019D38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D38u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D38 TAX
    cpu.transfer("TAX");
    goto L_019D39;
L_019D39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D39u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D39u, 4u + ((((0x9B83u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9B83u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D39 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9B83u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D3C;
L_019D3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Cu, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D3C STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_019D3F;
L_019D3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D3F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D41;
L_019D41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D41u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D41u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D41 ASL
    cpu.aslA();
    goto L_019D42;
L_019D42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D42u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D42u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D42 ASL
    cpu.aslA();
    goto L_019D43;
L_019D43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D43u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D43u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D43 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_019D45;
L_019D45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D45u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D45 TAX
    cpu.transfer("TAX");
    goto L_019D46;
L_019D46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D46u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D46u, 4u + ((((0x9CDBu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9CDBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D46 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9CDBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D49;
L_019D49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D49u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D49u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D49 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_019D4B;
L_019D4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Bu, 5u, 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D4B STA
    hw.write(cpu.address("absy", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_019D4E;
L_019D4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D4E INY
    cpu.inc('Y');
    goto L_019D4F;
L_019D4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D4F INY
    cpu.inc('Y');
    goto L_019D50;
L_019D50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D50u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D50 INY
    cpu.inc('Y');
    goto L_019D51;
L_019D51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D51u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D51 INY
    cpu.inc('Y');
    goto L_019D52;
L_019D52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D52u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D52u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D52 DEC
    cpu.decMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_019D54;
L_019D54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D54u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D54 BPL -> $019D1F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_019D1F; }
    goto L_019D56;
L_019D56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D56u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D56u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019D56 PLX
    cpu.pop("PLX", hw);
    goto L_019D57;
L_019D57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D57u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D57 LDA
    cpu.setA(0x3u, 8);
    goto L_019D59;
L_019D59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D59u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D59 LDY
    cpu.setY(0x0u, 8);
    goto L_019D5B;
L_019D5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Bu, 6u, 3u, cpu.address("abs", 0xB7BBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019D5B JSR -> $01B7BB stack real
    { cpu.push16Value(hw,0x9D5Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D5Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB7BBu), 0x019D5Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019D5E;
L_019D5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D5Eu,0x019D5Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019D5E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x019D5Eu);return;} hw.unresolvedReturn(0x019D5Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_019CF3_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019CF3u: goto L_019CF3;
    case 0x019CF5u: goto L_019CF5;
    case 0x019CF7u: goto L_019CF7;
    case 0x019CF9u: goto L_019CF9;
    case 0x019CFCu: goto L_019CFC;
    case 0x019CFEu: goto L_019CFE;
    case 0x019CFFu: goto L_019CFF;
    case 0x019D00u: goto L_019D00;
    case 0x019D02u: goto L_019D02;
    case 0x019D04u: goto L_019D04;
    case 0x019D06u: goto L_019D06;
    case 0x019D09u: goto L_019D09;
    case 0x019D0Au: goto L_019D0A;
    case 0x019D0Bu: goto L_019D0B;
    case 0x019D0Eu: goto L_019D0E;
    case 0x019D10u: goto L_019D10;
    case 0x019D13u: goto L_019D13;
    case 0x019D15u: goto L_019D15;
    case 0x019D17u: goto L_019D17;
    case 0x019D1Au: goto L_019D1A;
    case 0x019D1Cu: goto L_019D1C;
    case 0x019D1Eu: goto L_019D1E;
    case 0x019D1Fu: goto L_019D1F;
    case 0x019D21u: goto L_019D21;
    case 0x019D23u: goto L_019D23;
    case 0x019D24u: goto L_019D24;
    case 0x019D27u: goto L_019D27;
    case 0x019D2Au: goto L_019D2A;
    case 0x019D2Cu: goto L_019D2C;
    case 0x019D2Du: goto L_019D2D;
    case 0x019D30u: goto L_019D30;
    case 0x019D33u: goto L_019D33;
    case 0x019D35u: goto L_019D35;
    case 0x019D36u: goto L_019D36;
    case 0x019D38u: goto L_019D38;
    case 0x019D39u: goto L_019D39;
    case 0x019D3Cu: goto L_019D3C;
    case 0x019D3Fu: goto L_019D3F;
    case 0x019D41u: goto L_019D41;
    case 0x019D42u: goto L_019D42;
    case 0x019D43u: goto L_019D43;
    case 0x019D45u: goto L_019D45;
    case 0x019D46u: goto L_019D46;
    case 0x019D49u: goto L_019D49;
    case 0x019D4Bu: goto L_019D4B;
    case 0x019D4Eu: goto L_019D4E;
    case 0x019D4Fu: goto L_019D4F;
    case 0x019D50u: goto L_019D50;
    case 0x019D51u: goto L_019D51;
    case 0x019D52u: goto L_019D52;
    case 0x019D54u: goto L_019D54;
    case 0x019D56u: goto L_019D56;
    case 0x019D57u: goto L_019D57;
    case 0x019D59u: goto L_019D59;
    case 0x019D5Bu: goto L_019D5B;
    case 0x019D5Eu: goto L_019D5E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019CF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019CF3 LDY
    cpu.setY(0x0u, 8);
    goto L_019CF5;
L_019CF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019CF5 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_019CF7;
L_019CF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF7u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019CF7 STY
    hw.write(cpu.address("dp", 0xFu), cpu.y, cpu.x8?8:16);
    goto L_019CF9;
L_019CF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF9u, 6u, 3u, cpu.address("abs", 0xA365u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019CF9 JSR -> $01A365 stack real
    { cpu.push16Value(hw,0x9CFBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9CFCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA365u), 0x019CF9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019CFC;
L_019CFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CFCu,0x019CFCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFCu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019CFC LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019CFE;
L_019CFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFEu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019CFE TYA
    cpu.transfer("TYA");
    goto L_019CFF;
L_019CFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019CFF CLC
    cpu.setFlag('C', false);
    goto L_019D00;
L_019D00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D00u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D00u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D00 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16));
    goto L_019D02;
L_019D02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D02u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D02u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D02 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_019D04;
L_019D04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D04u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D04u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D04 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019D06;
L_019D06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D06u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D06u, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D06 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D09;
L_019D09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D09u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D09 ASL
    cpu.aslA();
    goto L_019D0A;
L_019D0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D0A ASL
    cpu.aslA();
    goto L_019D0B;
L_019D0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Bu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Bu, 4u + ((((0x9C7Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9C7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D0B ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x9C7Fu), cpu.m8?8:16));
    goto L_019D0E;
L_019D0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D0E STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_019D10;
L_019D10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D10u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D10u, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D10 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D13;
L_019D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D13u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D13u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D13 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16));
    goto L_019D15;
L_019D15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D15u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D15 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_019D17;
L_019D17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D17u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D17u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D17 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019D1A;
L_019D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D1A LDA
    cpu.setA(0x3u, 8);
    goto L_019D1C;
L_019D1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D1C STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_019D1E;
L_019D1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Eu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019D1E PHX
    cpu.push("PHX", hw);
    goto L_019D1F;
L_019D1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D1F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019D21;
L_019D21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D21u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D21u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D21 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D23;
L_019D23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D23u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D23 CLC
    cpu.setFlag('C', false);
    goto L_019D24;
L_019D24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D24u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D24u, 4u + ((((0x9CD3u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9CD3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D24 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x9CD3u), cpu.m8?8:16));
    goto L_019D27;
L_019D27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D27u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D27u, 5u, 3u, cpu.address("absy", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D27 STA
    hw.write(cpu.address("absy", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_019D2A;
L_019D2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D2A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D2C;
L_019D2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D2C CLC
    cpu.setFlag('C', false);
    goto L_019D2D;
L_019D2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Du,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Du, 4u + ((((0x9CD7u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9CD7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D2D ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x9CD7u), cpu.m8?8:16));
    goto L_019D30;
L_019D30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D30u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D30u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D30 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_019D33;
L_019D33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D33u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D33u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D33 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D35;
L_019D35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D35u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D35 CLC
    cpu.setFlag('C', false);
    goto L_019D36;
L_019D36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D36u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D36u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D36 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_019D38;
L_019D38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D38u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D38 TAX
    cpu.transfer("TAX");
    goto L_019D39;
L_019D39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D39u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D39u, 4u + ((((0x9B83u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9B83u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D39 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9B83u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D3C;
L_019D3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Cu, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D3C STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_019D3F;
L_019D3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D3F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D41;
L_019D41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D41u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D41u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D41 ASL
    cpu.aslA();
    goto L_019D42;
L_019D42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D42u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D42u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D42 ASL
    cpu.aslA();
    goto L_019D43;
L_019D43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D43u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D43u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D43 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_019D45;
L_019D45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D45u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D45 TAX
    cpu.transfer("TAX");
    goto L_019D46;
L_019D46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D46u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D46u, 4u + ((((0x9CDBu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9CDBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D46 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9CDBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019D49;
L_019D49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D49u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D49u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D49 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_019D4B;
L_019D4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Bu, 5u, 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D4B STA
    hw.write(cpu.address("absy", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_019D4E;
L_019D4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D4E INY
    cpu.inc('Y');
    goto L_019D4F;
L_019D4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D4F INY
    cpu.inc('Y');
    goto L_019D50;
L_019D50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D50u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D50 INY
    cpu.inc('Y');
    goto L_019D51;
L_019D51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D51u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D51 INY
    cpu.inc('Y');
    goto L_019D52;
L_019D52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D52u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D52u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D52 DEC
    cpu.decMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_019D54;
L_019D54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D54u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D54 BPL -> $019D1F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_019D1F; }
    goto L_019D56;
L_019D56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D56u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D56u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019D56 PLX
    cpu.pop("PLX", hw);
    goto L_019D57;
L_019D57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D57u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D57 LDA
    cpu.setA(0x3u, 8);
    goto L_019D59;
L_019D59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D59u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019D59 LDY
    cpu.setY(0x0u, 8);
    goto L_019D5B;
L_019D5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Bu, 6u, 3u, cpu.address("abs", 0xB7BBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019D5B JSR -> $01B7BB stack real
    { cpu.push16Value(hw,0x9D5Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D5Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB7BBu), 0x019D5Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019D5E;
L_019D5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D5Eu,0x019D5Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019D5E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x019D5Eu);return;} hw.unresolvedReturn(0x019D5Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01AD07_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01AD07u: goto L_01AD07;
    case 0x01AD0Au: goto L_01AD0A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01AD07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD07u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD07u, 4u, 3u, cpu.address("abs", 0x148Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD07 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD0A;
L_01AD0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD0A ASL
    cpu.aslA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD0Bu,0x01AD0Au); return;
}

void sub_01AD07_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01AD07u: goto L_01AD07;
    case 0x01AD0Au: goto L_01AD0A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01AD07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD07u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD07u, 4u, 3u, cpu.address("abs", 0x148Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD07 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD0A;
L_01AD0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD0A ASL
    cpu.aslA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD0Bu,0x01AD0Au); return;
}

void sub_01AD07_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01AD07u: goto L_01AD07;
    case 0x01AD0Au: goto L_01AD0A;
    case 0x01AD0Bu: goto L_01AD0B;
    case 0x01AD0Cu: goto L_01AD0C;
    case 0x01AD0Du: goto L_01AD0D;
    case 0x01AD10u: goto L_01AD10;
    case 0x01AD13u: goto L_01AD13;
    case 0x01AD16u: goto L_01AD16;
    case 0x01AD18u: goto L_01AD18;
    case 0x01AD1Bu: goto L_01AD1B;
    case 0x01AD1Du: goto L_01AD1D;
    case 0x01AD1Fu: goto L_01AD1F;
    case 0x01AD21u: goto L_01AD21;
    case 0x01AD23u: goto L_01AD23;
    case 0x01AD26u: goto L_01AD26;
    case 0x01AD29u: goto L_01AD29;
    case 0x01AD2Cu: goto L_01AD2C;
    case 0x01AD2Fu: goto L_01AD2F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01AD07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD07u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD07u, 4u, 3u, cpu.address("abs", 0x148Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD07 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD0A;
L_01AD0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD0A ASL
    cpu.aslA();
    goto L_01AD0B;
L_01AD0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD0B ASL
    cpu.aslA();
    goto L_01AD0C;
L_01AD0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD0C SEC
    cpu.setFlag('C', true);
    goto L_01AD0D;
L_01AD0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Du,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Du, 4u, 3u, cpu.address("abs", 0x148Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD0D ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x148Bu), cpu.m8?8:16));
    goto L_01AD10;
L_01AD10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD10u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD10u, 4u, 3u, cpu.address("abs", 0x148Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD10 STA
    hw.write(cpu.address("abs", 0x148Bu), cpu.a, cpu.m8?8:16);
    goto L_01AD13;
L_01AD13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD13u,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD13u, 6u, 3u, cpu.address("abs", 0x148Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD13 ASL
    cpu.aslMem(hw, cpu.address("abs", 0x148Cu), cpu.m8?8:16);
    goto L_01AD16;
L_01AD16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD16u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD16 LDA
    cpu.setA(0x20u, 8);
    goto L_01AD18;
L_01AD18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD18u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD18u, 4u, 3u, cpu.address("abs", 0x148Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD18 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x148Cu), cpu.m8?8:16), false);
    goto L_01AD1B;
L_01AD1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD1Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD1B BCC -> $01AD21
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01AD21; }
    goto L_01AD1D;
L_01AD1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD1Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD1D BEQ -> $01AD26
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AD26; }
    goto L_01AD1F;
L_01AD1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD1Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD1Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD1F BNE -> $01AD23
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AD23; }
    goto L_01AD21;
L_01AD21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD21u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD21 BNE -> $01AD26
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AD26; }
    goto L_01AD23;
L_01AD23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD23u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD23u, 6u, 3u, cpu.address("abs", 0x148Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD23 INC
    cpu.incMem(hw, cpu.address("abs", 0x148Cu), cpu.m8?8:16);
    goto L_01AD26;
L_01AD26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD26u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD26u, 4u, 3u, cpu.address("abs", 0x148Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD26 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD29;
L_01AD29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD29u,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD29u, 4u, 3u, cpu.address("abs", 0x148Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD29 EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x148Bu), cpu.m8?8:16));
    goto L_01AD2C;
L_01AD2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD2Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD2Cu, 5u, 3u, cpu.address("absy", 0x148Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD2C STA
    hw.write(cpu.address("absy", 0x148Du), cpu.a, cpu.m8?8:16);
    goto L_01AD2F;
L_01AD2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD2Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD2Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01AD2F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x01AD2Fu);return;} hw.unresolvedReturn(0x01AD2Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_02BB23_E1M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02BB23u: goto L_02BB23;
    case 0x02BB25u: goto L_02BB25;
    case 0x02BB28u: goto L_02BB28;
    case 0x02BB2Au: goto L_02BB2A;
    case 0x02BB2Cu: goto L_02BB2C;
    case 0x02BB2Eu: goto L_02BB2E;
    case 0x02BB31u: goto L_02BB31;
    case 0x02BB33u: goto L_02BB33;
    case 0x02BB35u: goto L_02BB35;
    case 0x02BB37u: goto L_02BB37;
    case 0x02BB3Au: goto L_02BB3A;
    case 0x02BB3Du: goto L_02BB3D;
    case 0x02BB3Eu: goto L_02BB3E;
    case 0x02BB40u: goto L_02BB40;
    case 0x02BB41u: goto L_02BB41;
    case 0x02BB43u: goto L_02BB43;
    case 0x02BB44u: goto L_02BB44;
    case 0x02BB48u: goto L_02BB48;
    case 0x02BB4Au: goto L_02BB4A;
    case 0x02BB4Cu: goto L_02BB4C;
    case 0x02BB50u: goto L_02BB50;
    case 0x02BB51u: goto L_02BB51;
    case 0x02BB53u: goto L_02BB53;
    case 0x02BB54u: goto L_02BB54;
    case 0x02BB56u: goto L_02BB56;
    case 0x02BB59u: goto L_02BB59;
    case 0x02BB5Au: goto L_02BB5A;
    case 0x02BB5Cu: goto L_02BB5C;
    case 0x02BB5Eu: goto L_02BB5E;
    case 0x02BB60u: goto L_02BB60;
    case 0x02BB61u: goto L_02BB61;
    case 0x02BB63u: goto L_02BB63;
    case 0x02BB64u: goto L_02BB64;
    case 0x02BB68u: goto L_02BB68;
    case 0x02BB6Bu: goto L_02BB6B;
    case 0x02BB6Fu: goto L_02BB6F;
    case 0x02BB72u: goto L_02BB72;
    case 0x02BB74u: goto L_02BB74;
    case 0x02BB78u: goto L_02BB78;
    case 0x02BB7Bu: goto L_02BB7B;
    case 0x02BB7Cu: goto L_02BB7C;
    case 0x02BB7Du: goto L_02BB7D;
    case 0x02BB7Eu: goto L_02BB7E;
    case 0x02BB7Fu: goto L_02BB7F;
    case 0x02BB83u: goto L_02BB83;
    case 0x02BB86u: goto L_02BB86;
    case 0x02BB87u: goto L_02BB87;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02BB23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB23u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB23u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB23 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_02BB25;
L_02BB25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB25u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB25u, 6u, 3u, cpu.address("abs", 0xD0C9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02BB25 JSR -> $02D0C9 stack real
    { cpu.push16Value(hw,0xBB27u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB28u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD0C9u), 0x02BB25u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02BB28;
L_02BB28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB28u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB28u,0x02BB28u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB28u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB28 BNE -> $02BB87
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02BB87; }
    goto L_02BB2A;
L_02BB2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB2A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02BB2C;
L_02BB2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB2C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_02BB2E;
L_02BB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Eu, 4u + 1u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB2E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02BB31;
L_02BB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB31u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB31 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_02BB33;
L_02BB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB33u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB33u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB33 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02BB35;
L_02BB35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB35u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB35u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB35 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_02BB37;
L_02BB37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB37u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB37u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB37 LDY
    cpu.setY(0xDAF8u, 16);
    goto L_02BB3A;
L_02BB3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Au, 4u + 1u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB3A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02BB3D;
L_02BB3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB3D ASL
    cpu.aslA();
    goto L_02BB3E;
L_02BB3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Eu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB3E ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_02BB40;
L_02BB40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB40u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB40 TAX
    cpu.transfer("TAX");
    goto L_02BB41;
L_02BB41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB41u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB41u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB41 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02BB43;
L_02BB43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB43u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB43 CLC
    cpu.setFlag('C', false);
    goto L_02BB44;
L_02BB44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB44u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB44u, 5u, 4u, ((0x02BB0Bu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB44 ADC
    cpu.adc(hw.readW(((0x2BB0Bu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_02BB48;
L_02BB48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB48u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB48u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB48 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_02BB4A;
L_02BB4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB4A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02BB4C;
L_02BB4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Cu,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Cu, 5u, 4u, ((0x02BB0Fu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB4C ADC
    cpu.adc(hw.readW(((0x2BB0Fu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_02BB50;
L_02BB50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB50u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB50u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02BB50 PHA
    cpu.push("PHA", hw);
    goto L_02BB51;
L_02BB51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB51u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB51u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB51 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02BB53;
L_02BB53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB53u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB53 SEC
    cpu.setFlag('C', true);
    goto L_02BB54;
L_02BB54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB54u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB54u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB54 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_02BB56;
L_02BB56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB56u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB56u, 5u, 3u, cpu.address("absy", 0x0200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB56 STA
    hw.write(cpu.address("absy", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_02BB59;
L_02BB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB59u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB59u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02BB59 PLA
    cpu.pop("PLA", hw);
    goto L_02BB5A;
L_02BB5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Au,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB5A SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16));
    goto L_02BB5C;
L_02BB5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB5C BNE -> $02BB86
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02BB86; }
    goto L_02BB5E;
L_02BB5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB5E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02BB60;
L_02BB60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB60u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB60u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB60 SEC
    cpu.setFlag('C', true);
    goto L_02BB61;
L_02BB61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB61u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB61u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB61 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_02BB63;
L_02BB63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB63u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB63u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB63 CLC
    cpu.setFlag('C', false);
    goto L_02BB64;
L_02BB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB64u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB64u, 5u, 4u, ((0x02BB13u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB64 ADC
    cpu.adc(hw.readW(((0x2BB13u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_02BB68;
L_02BB68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB68u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB68u, 5u, 3u, cpu.address("absy", 0x0201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB68 STA
    hw.write(cpu.address("absy", 0x201u), cpu.a, cpu.m8?8:16);
    goto L_02BB6B;
L_02BB6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Bu, 5u, 4u, ((0x02BB17u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB6B LDA
    cpu.loadA(hw.readW(((0x2BB17u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02BB6F;
L_02BB6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Fu, 5u, 3u, cpu.address("absy", 0x0202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB6F STA
    hw.write(cpu.address("absy", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_02BB72;
L_02BB72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB72u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB72u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB72 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02BB74;
L_02BB74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB74u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB74u, 5u, 4u, ((0x02BB1Bu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB74 ORA
    cpu.logicOr(hw.readW(((0x2BB1Bu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_02BB78;
L_02BB78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB78u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB78u, 5u, 3u, cpu.address("absy", 0x0203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB78 STA
    hw.write(cpu.address("absy", 0x203u), cpu.a, cpu.m8?8:16);
    goto L_02BB7B;
L_02BB7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB7B TYA
    cpu.transfer("TYA");
    goto L_02BB7C;
L_02BB7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB7C LSR
    cpu.lsrA();
    goto L_02BB7D;
L_02BB7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB7D LSR
    cpu.lsrA();
    goto L_02BB7E;
L_02BB7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB7E TAY
    cpu.transfer("TAY");
    goto L_02BB7F;
L_02BB7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Fu, 5u, 4u, ((0x02BB1Fu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB7F LDA
    cpu.loadA(hw.readW(((0x2BB1Fu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02BB83;
L_02BB83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB83u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB83u, 5u, 3u, cpu.address("absy", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02BB83 STA
    hw.write(cpu.address("absy", 0x420u), cpu.a, cpu.m8?8:16);
    goto L_02BB86;
L_02BB86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB86u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB86u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02BB86 PLX
    cpu.pop("PLX", hw);
    goto L_02BB87;
L_02BB87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB87u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB87u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02BB87 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02BB87u);return;} hw.unresolvedReturn(0x02BB87u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_02D025_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02D025u: goto L_02D025;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02D025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD025u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD025u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D025 STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD027u,0x02D025u); return;
}

void sub_02D0E6_E1M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02D0E6u: goto L_02D0E6;
    case 0x02D0E8u: goto L_02D0E8;
    case 0x02D148u: goto L_02D148;
    case 0x02D149u: goto L_02D149;
    case 0x02D14Bu: goto L_02D14B;
    case 0x02D14Cu: goto L_02D14C;
    case 0x02D14Eu: goto L_02D14E;
    case 0x02D151u: goto L_02D151;
    case 0x02D153u: goto L_02D153;
    case 0x02D155u: goto L_02D155;
    case 0x02D158u: goto L_02D158;
    case 0x02D15Au: goto L_02D15A;
    case 0x02D15Cu: goto L_02D15C;
    case 0x02D15Eu: goto L_02D15E;
    case 0x02D160u: goto L_02D160;
    case 0x02D163u: goto L_02D163;
    case 0x02D166u: goto L_02D166;
    case 0x02D168u: goto L_02D168;
    case 0x02D169u: goto L_02D169;
    case 0x02D16Cu: goto L_02D16C;
    case 0x02D16Eu: goto L_02D16E;
    case 0x02D171u: goto L_02D171;
    case 0x02D174u: goto L_02D174;
    case 0x02D177u: goto L_02D177;
    case 0x02D179u: goto L_02D179;
    case 0x02D17Bu: goto L_02D17B;
    case 0x02D17Eu: goto L_02D17E;
    case 0x02D180u: goto L_02D180;
    case 0x02D182u: goto L_02D182;
    case 0x02D183u: goto L_02D183;
    case 0x02D184u: goto L_02D184;
    case 0x02D185u: goto L_02D185;
    case 0x02D186u: goto L_02D186;
    case 0x02D188u: goto L_02D188;
    case 0x02D18Au: goto L_02D18A;
    case 0x02D18Cu: goto L_02D18C;
    case 0x02D190u: goto L_02D190;
    case 0x02D192u: goto L_02D192;
    case 0x02D194u: goto L_02D194;
    case 0x02D198u: goto L_02D198;
    case 0x02D199u: goto L_02D199;
    case 0x02D19Bu: goto L_02D19B;
    case 0x02D19Du: goto L_02D19D;
    case 0x02D1A1u: goto L_02D1A1;
    case 0x02D1A3u: goto L_02D1A3;
    case 0x02D1A5u: goto L_02D1A5;
    case 0x02D1A9u: goto L_02D1A9;
    case 0x02D1ABu: goto L_02D1AB;
    case 0x02D1ADu: goto L_02D1AD;
    case 0x02D1AFu: goto L_02D1AF;
    case 0x02D1B1u: goto L_02D1B1;
    case 0x02D1B4u: goto L_02D1B4;
    case 0x02D1B6u: goto L_02D1B6;
    case 0x02D1B9u: goto L_02D1B9;
    case 0x02D1BBu: goto L_02D1BB;
    case 0x02D1BDu: goto L_02D1BD;
    case 0x02D1BFu: goto L_02D1BF;
    case 0x02D1C2u: goto L_02D1C2;
    case 0x02D1C4u: goto L_02D1C4;
    case 0x02D1C6u: goto L_02D1C6;
    case 0x02D1C8u: goto L_02D1C8;
    case 0x02D1CAu: goto L_02D1CA;
    case 0x02D1CBu: goto L_02D1CB;
    case 0x02D1CDu: goto L_02D1CD;
    case 0x02D1D0u: goto L_02D1D0;
    case 0x02D1D3u: goto L_02D1D3;
    case 0x02D1D6u: goto L_02D1D6;
    case 0x02D1D9u: goto L_02D1D9;
    case 0x02D1DCu: goto L_02D1DC;
    case 0x02D1DEu: goto L_02D1DE;
    case 0x02D1E1u: goto L_02D1E1;
    case 0x02D1E3u: goto L_02D1E3;
    case 0x02D1E4u: goto L_02D1E4;
    case 0x02D1E6u: goto L_02D1E6;
    case 0x02D1E8u: goto L_02D1E8;
    case 0x02D1EAu: goto L_02D1EA;
    case 0x02D1ECu: goto L_02D1EC;
    case 0x02D1EEu: goto L_02D1EE;
    case 0x02D1F0u: goto L_02D1F0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02D0E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E6u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0E6 STZ
    hw.write(cpu.address("dp", 0xFu), 0, cpu.m8?8:16);
    goto L_02D0E8;
L_02D0E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0E8 BRA -> $02D149
    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao
    goto L_02D149;
L_02D148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD148u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD148u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02D148 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02D148u);return;} hw.unresolvedReturn(0x02D148u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_02D149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD149u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD149u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D149 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D14B;
L_02D14B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD14Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD14Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD14Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D14B CLC
    cpu.setFlag('C', false);
    goto L_02D14C;
L_02D14C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD14Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD14Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD14Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D14C ADC
    cpu.adc(0x8u);
    goto L_02D14E;
L_02D14E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD14Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD14Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD14Eu, 4u, 3u, cpu.address("abs", 0x18B2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D14E STA
    hw.write(cpu.address("abs", 0x18B2u), cpu.a, cpu.m8?8:16);
    goto L_02D151;
L_02D151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD151u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD151u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D151 AND
    cpu.logicAnd(0xF0u);
    goto L_02D153;
L_02D153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD153u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD153u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D153 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_02D155;
L_02D155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD155u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD155u, 4u + 1u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D155 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D158;
L_02D158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD158u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD158u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D158 ADC
    cpu.adc(0x0u);
    goto L_02D15A;
L_02D15A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD15Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D15A CMP
    cpu.compareA(0x2u);
    goto L_02D15C;
L_02D15C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD15Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D15C BCS -> $02D148
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_02D148; }
    goto L_02D15E;
L_02D15E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD15Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D15E STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_02D160;
L_02D160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD160u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD160u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD160u, 4u, 3u, cpu.address("abs", 0x18B3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D160 STA
    hw.write(cpu.address("abs", 0x18B3u), cpu.a, cpu.m8?8:16);
    goto L_02D163;
L_02D163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD163u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD163u, 5u + 1u, 3u, cpu.address("absx", 0x157Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D163 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x157Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02D166;
L_02D166:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD166u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD166u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD166u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D166 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D168;
L_02D168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD168u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD168u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D168 CLC
    cpu.setFlag('C', false);
    goto L_02D169;
L_02D169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD169u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD169u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD169u, 4u + 1u, 3u, cpu.address("absy", 0xD0D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D169 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD0D0u), cpu.m8?8:16));
    goto L_02D16C;
L_02D16C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD16Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D16C STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_02D16E;
L_02D16E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD16Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Eu, 4u, 3u, cpu.address("abs", 0x18B0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D16E STA
    hw.write(cpu.address("abs", 0x18B0u), cpu.a, cpu.m8?8:16);
    goto L_02D171;
L_02D171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD171u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD171u, 4u + 1u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D171 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D174;
L_02D174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD174u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD174u, 4u + 1u, 3u, cpu.address("absy", 0xD0D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D174 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD0D2u), cpu.m8?8:16));
    goto L_02D177;
L_02D177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD177u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD177u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D177 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x5Du), cpu.m8?8:16));
    goto L_02D179;
L_02D179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD179u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD179u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D179 BCS -> $02D148
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_02D148; }
    goto L_02D17B;
L_02D17B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD17Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Bu, 4u, 3u, cpu.address("abs", 0x18B1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D17B STA
    hw.write(cpu.address("abs", 0x18B1u), cpu.a, cpu.m8?8:16);
    goto L_02D17E;
L_02D17E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD17Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D17E STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_02D180;
L_02D180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD180u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD180u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D180 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D182;
L_02D182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD182u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD182u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D182 LSR
    cpu.lsrA();
    goto L_02D183;
L_02D183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD183u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD183u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D183 LSR
    cpu.lsrA();
    goto L_02D184;
L_02D184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD184u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD184u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D184 LSR
    cpu.lsrA();
    goto L_02D185;
L_02D185:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD185u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD185u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD185u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D185 LSR
    cpu.lsrA();
    goto L_02D186;
L_02D186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD186u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD186u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D186 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_02D188;
L_02D188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD188u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD188u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D188 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_02D18A;
L_02D18A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD18Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD18Au,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD18Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D18A LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02D18C;
L_02D18C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD18Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD18Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD18Cu, 5u, 4u, ((0x00BA60u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D18C LDA
    cpu.loadA(hw.readW(((0xBA60u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D190;
L_02D190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD190u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD190u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD190u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D190 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02D192;
L_02D192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD192u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD192u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D192 BEQ -> $02D198
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02D198; }
    goto L_02D194;
L_02D194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD194u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD194u, 5u, 4u, ((0x00BA70u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D194 LDA
    cpu.loadA(hw.readW(((0xBA70u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D198;
L_02D198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD198u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD198u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D198 CLC
    cpu.setFlag('C', false);
    goto L_02D199;
L_02D199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD199u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD199u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D199 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_02D19B;
L_02D19B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD19Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D19B STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_02D19D;
L_02D19D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD19Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Du, 5u, 4u, ((0x00BA9Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D19D LDA
    cpu.loadA(hw.readW(((0xBA9Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D1A1;
L_02D1A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A1u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1A1 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02D1A3;
L_02D1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1A3 BEQ -> $02D1A9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02D1A9; }
    goto L_02D1A5;
L_02D1A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A5u, 5u, 4u, ((0x00BAACu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1A5 LDA
    cpu.loadA(hw.readW(((0xBAACu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D1A9;
L_02D1A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A9u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1A9 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_02D1AB;
L_02D1AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ABu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ABu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1AB STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_02D1AD;
L_02D1AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ADu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1AD LDA
    cpu.setA(0x7Eu, 8);
    goto L_02D1AF;
L_02D1AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1AFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1AFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1AF STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_02D1B1;
L_02D1B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B1u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B1u, 5u, 3u, cpu.address("abs", 0x15E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1B1 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02D1B4;
L_02D1B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B4u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B4u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x05u) & 0xFFFFu), 3u, 0u);
    // $02D1B4 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D1B6;
L_02D1B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B6u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1B6 STA
    hw.write(cpu.address("abs", 0x1693u), cpu.a, cpu.m8?8:16);
    goto L_02D1B9;
L_02D1B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B9u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1B9 INC
    cpu.incMem(hw, cpu.address("dp", 0x7u), cpu.m8?8:16);
    goto L_02D1BB;
L_02D1BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BBu,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BBu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x05u) & 0xFFFFu), 3u, 0u);
    // $02D1BB LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D1BD;
L_02D1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1BD BNE -> $02D1F0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02D1F0; }
    goto L_02D1BF;
L_02D1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BFu, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1BF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D1C2;
L_02D1C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1C2 CMP
    cpu.compareA(0x45u);
    goto L_02D1C4;
L_02D1C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1C4 BCC -> $02D1F0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_02D1F0; }
    goto L_02D1C6;
L_02D1C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1C6 CMP
    cpu.compareA(0x48u);
    goto L_02D1C8;
L_02D1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1C8 BCS -> $02D1F0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_02D1F0; }
    goto L_02D1CA;
L_02D1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1CA SEC
    cpu.setFlag('C', true);
    goto L_02D1CB;
L_02D1CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CBu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1CB SBC
    cpu.sbc(0x44u);
    goto L_02D1CD;
L_02D1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CDu, 4u, 3u, cpu.address("abs", 0x18D6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1CD STA
    hw.write(cpu.address("abs", 0x18D6u), cpu.a, cpu.m8?8:16);
    goto L_02D1D0;
L_02D1D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D0u, 4u, 3u, cpu.address("abs", 0x14A3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1D0 STZ
    hw.write(cpu.address("abs", 0x14A3u), 0, cpu.m8?8:16);
    goto L_02D1D3;
L_02D1D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D3u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D3u, 5u, 3u, cpu.address("abs", 0x18DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1D3 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x18DCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02D1D6;
L_02D1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D6u, 4u + 1u, 3u, cpu.address("absy", 0xD1F1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1D6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD1F1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D1D9;
L_02D1D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D9u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1D9 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_02D1DC;
L_02D1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1DC LDA
    cpu.setA(0x22u, 8);
    goto L_02D1DE;
L_02D1DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DEu, 5u, 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1DE STA
    hw.write(cpu.address("absx", 0x1564u), cpu.a, cpu.m8?8:16);
    goto L_02D1E1;
L_02D1E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1E1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D1E3;
L_02D1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1E3 CLC
    cpu.setFlag('C', false);
    goto L_02D1E4;
L_02D1E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E4u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1E4 ADC
    cpu.adc(0x8u);
    goto L_02D1E6;
L_02D1E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1E6 AND
    cpu.logicAnd(0xF0u);
    goto L_02D1E8;
L_02D1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1E8 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_02D1EA;
L_02D1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1EA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D1EC;
L_02D1EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ECu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1EC ADC
    cpu.adc(0x0u);
    goto L_02D1EE;
L_02D1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D1EE STA
    hw.write(cpu.address("dp", 0x97u), cpu.a, cpu.m8?8:16);
    goto L_02D1F0;
L_02D1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02D1F0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02D1F0u);return;} hw.unresolvedReturn(0x02D1F0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02D288_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02D288u: goto L_02D288;
    case 0x02D289u: goto L_02D289;
    case 0x02D28Au: goto L_02D28A;
    case 0x02D28Cu: goto L_02D28C;
    case 0x02D28Du: goto L_02D28D;
    case 0x02D290u: goto L_02D290;
    case 0x02D293u: goto L_02D293;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02D288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD288u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD288u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD288u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D288 TXA
    cpu.transfer("TXA");
    goto L_02D289;
L_02D289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD289u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD289u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D289 CLC
    cpu.setFlag('C', false);
    goto L_02D28A;
L_02D28A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD28Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD28Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD28Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D28A ADC
    cpu.adc(0xCu);
    goto L_02D28C;
L_02D28C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD28Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD28Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD28Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D28C TAX
    cpu.transfer("TAX");
    goto L_02D28D;
L_02D28D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD28Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD28Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD28Du, 6u, 3u, cpu.address("abs", 0xD294u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02D28D JSR -> $02D294 stack real
    { cpu.push16Value(hw,0xD28Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD290u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD294u), 0x02D28Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02D290;
L_02D290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD290u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD290u,0x02D290u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD290u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD290u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D290 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02D293;
L_02D293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD293u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD293u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD293u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02D293 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02D293u);return;} hw.unresolvedReturn(0x02D293u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02D294_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02D294u: goto L_02D294;
    case 0x02D296u: goto L_02D296;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02D294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD294u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD294u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D294 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D296;
L_02D296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD296u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD296u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD296u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D296 ASL
    cpu.aslA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD297u,0x02D296u); return;
}

void sub_02D294_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02D294u: goto L_02D294;
    case 0x02D296u: goto L_02D296;
    case 0x02D297u: goto L_02D297;
    case 0x02D298u: goto L_02D298;
    case 0x02D299u: goto L_02D299;
    case 0x02D29Au: goto L_02D29A;
    case 0x02D29Bu: goto L_02D29B;
    case 0x02D29Eu: goto L_02D29E;
    case 0x02D2A1u: goto L_02D2A1;
    case 0x02D2A2u: goto L_02D2A2;
    case 0x02D2A3u: goto L_02D2A3;
    case 0x02D2A5u: goto L_02D2A5;
    case 0x02D2A7u: goto L_02D2A7;
    case 0x02D2A8u: goto L_02D2A8;
    case 0x02D2A9u: goto L_02D2A9;
    case 0x02D2AAu: goto L_02D2AA;
    case 0x02D2ABu: goto L_02D2AB;
    case 0x02D2ADu: goto L_02D2AD;
    case 0x02D2AFu: goto L_02D2AF;
    case 0x02D2B1u: goto L_02D2B1;
    case 0x02D2B2u: goto L_02D2B2;
    case 0x02D2B3u: goto L_02D2B3;
    case 0x02D2B4u: goto L_02D2B4;
    case 0x02D2B6u: goto L_02D2B6;
    case 0x02D2B8u: goto L_02D2B8;
    case 0x02D2B9u: goto L_02D2B9;
    case 0x02D2BCu: goto L_02D2BC;
    case 0x02D2BFu: goto L_02D2BF;
    case 0x02D2C0u: goto L_02D2C0;
    case 0x02D2C1u: goto L_02D2C1;
    case 0x02D2C3u: goto L_02D2C3;
    case 0x02D2C6u: goto L_02D2C6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02D294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD294u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD294u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D294 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D296;
L_02D296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD296u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD296u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD296u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D296 ASL
    cpu.aslA();
    goto L_02D297;
L_02D297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD297u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD297u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D297 ASL
    cpu.aslA();
    goto L_02D298;
L_02D298:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD298u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD298u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD298u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D298 ASL
    cpu.aslA();
    goto L_02D299;
L_02D299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD299u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD299u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D299 ASL
    cpu.aslA();
    goto L_02D29A;
L_02D29A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD29Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD29Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD29Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D29A CLC
    cpu.setFlag('C', false);
    goto L_02D29B;
L_02D29B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD29Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD29Bu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD29Bu, 4u + ((((0x14ECu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14ECu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D29B ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x14ECu), cpu.m8?8:16));
    goto L_02D29E;
L_02D29E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD29Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD29Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD29Eu, 5u, 3u, cpu.address("absx", 0x14ECu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D29E STA
    hw.write(cpu.address("absx", 0x14ECu), cpu.a, cpu.m8?8:16);
    goto L_02D2A1;
L_02D2A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A1u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D2A1 PHP
    cpu.push("PHP", hw);
    goto L_02D2A2;
L_02D2A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A2u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D2A2 PHP
    cpu.push("PHP", hw);
    goto L_02D2A3;
L_02D2A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2A3 LDY
    cpu.setY(0x0u, 8);
    goto L_02D2A5;
L_02D2A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2A5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D2A7;
L_02D2A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2A7 LSR
    cpu.lsrA();
    goto L_02D2A8;
L_02D2A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2A8 LSR
    cpu.lsrA();
    goto L_02D2A9;
L_02D2A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2A9 LSR
    cpu.lsrA();
    goto L_02D2AA;
L_02D2AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2AAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2AA LSR
    cpu.lsrA();
    goto L_02D2AB;
L_02D2AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ABu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2AB CMP
    cpu.compareA(0x8u);
    goto L_02D2AD;
L_02D2AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ADu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2AD BCC -> $02D2B2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_02D2B2; }
    goto L_02D2AF;
L_02D2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2AFu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2AF ORA
    cpu.logicOr(0xF0u);
    goto L_02D2B1;
L_02D2B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B1u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2B1 DEY
    cpu.decReg('Y');
    goto L_02D2B2;
L_02D2B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B2u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D2B2 PLP
    cpu.pop("PLP", hw);
    goto L_02D2B3;
L_02D2B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD2B3u,0x02D2B3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B3u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D2B3 PHA
    cpu.push("PHA", hw);
    goto L_02D2B4;
L_02D2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B4u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2B4 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16));
    goto L_02D2B6;
L_02D2B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B6u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2B6 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_02D2B8;
L_02D2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B8u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2B8 TYA
    cpu.transfer("TYA");
    goto L_02D2B9;
L_02D2B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B9u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2B9u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2B9 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16));
    goto L_02D2BC;
L_02D2BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BCu, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2BC STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_02D2BF;
L_02D2BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BFu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2BFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D2BF PLA
    cpu.pop("PLA", hw);
    goto L_02D2C0;
L_02D2C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C0u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D2C0 PLP
    cpu.pop("PLP", hw);
    goto L_02D2C1;
L_02D2C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD2C1u,0x02D2C1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2C1 ADC
    cpu.adc(0x0u);
    goto L_02D2C3;
L_02D2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C3u, 4u, 3u, cpu.address("abs", 0x1491u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D2C3 STA
    hw.write(cpu.address("abs", 0x1491u), cpu.a, cpu.m8?8:16);
    goto L_02D2C6;
L_02D2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD2C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD2C6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02D2C6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02D2C6u);return;} hw.unresolvedReturn(0x02D2C6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_03B72B_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x03B72Bu: goto L_03B72B;
    case 0x03B72Cu: goto L_03B72C;
    case 0x03B72Eu: goto L_03B72E;
    case 0x03B730u: goto L_03B730;
    case 0x03B731u: goto L_03B731;
    case 0x03B733u: goto L_03B733;
    case 0x03B734u: goto L_03B734;
    case 0x03B736u: goto L_03B736;
    case 0x03B738u: goto L_03B738;
    case 0x03B73Au: goto L_03B73A;
    case 0x03B73Bu: goto L_03B73B;
    case 0x03B73Cu: goto L_03B73C;
    case 0x03B73Eu: goto L_03B73E;
    case 0x03B740u: goto L_03B740;
    case 0x03B742u: goto L_03B742;
    case 0x03B744u: goto L_03B744;
    case 0x03B746u: goto L_03B746;
    case 0x03B747u: goto L_03B747;
    case 0x03B749u: goto L_03B749;
    case 0x03B74Au: goto L_03B74A;
    case 0x03B74Cu: goto L_03B74C;
    case 0x03B74Eu: goto L_03B74E;
    case 0x03B750u: goto L_03B750;
    case 0x03B751u: goto L_03B751;
    case 0x03B753u: goto L_03B753;
    case 0x03B755u: goto L_03B755;
    case 0x03B757u: goto L_03B757;
    case 0x03B758u: goto L_03B758;
    case 0x03B75Au: goto L_03B75A;
    case 0x03B75Bu: goto L_03B75B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_03B72B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Bu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $03B72B PHX
    cpu.push("PHX", hw);
    goto L_03B72C;
L_03B72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B72C LDX
    cpu.setX(0x1u, 8);
    goto L_03B72E;
L_03B72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Eu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B72E LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03B730;
L_03B730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB730u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB730u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B730 SEC
    cpu.setFlag('C', true);
    goto L_03B731;
L_03B731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB731u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB731u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B731 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16));
    goto L_03B733;
L_03B733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB733u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB733u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $03B733 PHA
    cpu.push("PHA", hw);
    goto L_03B734;
L_03B734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB734u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB734u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B734 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03B736;
L_03B736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB736u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB736u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B736 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_03B738;
L_03B738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB738u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB738u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B738 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_03B73A;
L_03B73A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB73Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $03B73A PLA
    cpu.pop("PLA", hw);
    goto L_03B73B;
L_03B73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B73B CLC
    cpu.setFlag('C', false);
    goto L_03B73C;
L_03B73C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB73Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B73C ADC
    cpu.adc(0x80u);
    goto L_03B73E;
L_03B73E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB73Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B73E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03B740;
L_03B740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB740u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB740u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B740 ADC
    cpu.adc(0x0u);
    goto L_03B742;
L_03B742:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB742u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB742u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB742u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B742 BNE -> $03B75A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_03B75A; }
    goto L_03B744;
L_03B744:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB744u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB744u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB744u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B744 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03B746;
L_03B746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB746u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB746u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B746 SEC
    cpu.setFlag('C', true);
    goto L_03B747;
L_03B747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB747u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB747u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B747 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x0u), cpu.m8?8:16));
    goto L_03B749;
L_03B749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB749u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB749u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B749 CLC
    cpu.setFlag('C', false);
    goto L_03B74A;
L_03B74A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB74Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Au,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B74A ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16));
    goto L_03B74C;
L_03B74C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB74Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B74C STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_03B74E;
L_03B74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Eu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B74E LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03B750;
L_03B750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB750u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB750u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B750 CLC
    cpu.setFlag('C', false);
    goto L_03B751;
L_03B751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB751u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB751u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B751 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x6u), cpu.m8?8:16));
    goto L_03B753;
L_03B753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB753u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB753u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B753 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16));
    goto L_03B755;
L_03B755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB755u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB755u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B755 BCC -> $03B75A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_03B75A; }
    goto L_03B757;
L_03B757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB757u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB757u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB757u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B757 DEX
    cpu.decReg('X');
    goto L_03B758;
L_03B758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB758u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB758u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B758 BPL -> $03B72E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_03B72E; }
    goto L_03B75A;
L_03B75A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB75Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Au,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $03B75A PLX
    cpu.pop("PLX", hw);
    goto L_03B75B;
L_03B75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $03B75B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x03B75Bu);return;} hw.unresolvedReturn(0x03B75Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_048241_E0M1X1C1_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x048395u: goto L_048395;
    case 0x048398u: goto L_048398;
    case 0x04839Au: goto L_04839A;
    case 0x04839Du: goto L_04839D;
    case 0x04839Fu: goto L_04839F;
    case 0x0483A1u: goto L_0483A1;
    case 0x0483A3u: goto L_0483A3;
    case 0x0483A5u: goto L_0483A5;
    case 0x0483A6u: goto L_0483A6;
    case 0x0483A9u: goto L_0483A9;
    case 0x0483ABu: goto L_0483AB;
    case 0x0483ADu: goto L_0483AD;
    case 0x0483AFu: goto L_0483AF;
    case 0x0483B1u: goto L_0483B1;
    case 0x0483B2u: goto L_0483B2;
    case 0x0483B5u: goto L_0483B5;
    case 0x0483B7u: goto L_0483B7;
    case 0x0483B9u: goto L_0483B9;
    case 0x0483BBu: goto L_0483BB;
    case 0x0483BDu: goto L_0483BD;
    case 0x0483BFu: goto L_0483BF;
    case 0x0483C1u: goto L_0483C1;
    case 0x0483C3u: goto L_0483C3;
    case 0x0483C6u: goto L_0483C6;
    case 0x0483C8u: goto L_0483C8;
    case 0x0483CAu: goto L_0483CA;
    case 0x0483CCu: goto L_0483CC;
    case 0x0483CEu: goto L_0483CE;
    case 0x0483D1u: goto L_0483D1;
    case 0x0483D3u: goto L_0483D3;
    case 0x0483D6u: goto L_0483D6;
    case 0x0483D7u: goto L_0483D7;
    case 0x0483D8u: goto L_0483D8;
    case 0x0483D9u: goto L_0483D9;
    case 0x0483DAu: goto L_0483DA;
    case 0x0483DBu: goto L_0483DB;
    case 0x0483DCu: goto L_0483DC;
    case 0x0483DEu: goto L_0483DE;
    case 0x0483E1u: goto L_0483E1;
    case 0x0483E3u: goto L_0483E3;
    case 0x0483E5u: goto L_0483E5;
    case 0x0483E7u: goto L_0483E7;
    case 0x0483E9u: goto L_0483E9;
    case 0x0483EBu: goto L_0483EB;
    case 0x0483EDu: goto L_0483ED;
    case 0x0483EFu: goto L_0483EF;
    case 0x0483F1u: goto L_0483F1;
    case 0x0483F3u: goto L_0483F3;
    case 0x0483F5u: goto L_0483F5;
    case 0x0483F7u: goto L_0483F7;
    case 0x0483FAu: goto L_0483FA;
    case 0x0483FCu: goto L_0483FC;
    case 0x0483FEu: goto L_0483FE;
    case 0x048401u: goto L_048401;
    case 0x048403u: goto L_048403;
    case 0x048405u: goto L_048405;
    case 0x048408u: goto L_048408;
    case 0x04840Au: goto L_04840A;
    case 0x04840Du: goto L_04840D;
    case 0x048410u: goto L_048410;
    case 0x048413u: goto L_048413;
    case 0x048414u: goto L_048414;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_048395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8395u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8395u, 5u, 3u, cpu.address("abs", 0x1DF2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048395 STA
    hw.write(cpu.address("abs", 0x1DF2u), cpu.a, cpu.m8?8:16);
    goto L_048398;
L_048398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8398u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8398u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048398 SEP
    cpu.sep(0x20u);
    goto L_04839A;
L_04839A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Au, 4u, 3u, cpu.address("abs", 0x13D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04839A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04839D;
L_04839D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04839D BEQ -> $0483C3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0483C3; }
    goto L_04839F;
L_04839F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04839F LDX
    cpu.setX(0x0u, 8);
    goto L_0483A1;
L_0483A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483A1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0483A3;
L_0483A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483A3 AND
    cpu.logicAnd(0x3u);
    goto L_0483A5;
L_0483A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483A5 ASL
    cpu.aslA();
    goto L_0483A6;
L_0483A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A6u, 6u, 3u, cpu.address("abs", 0x8415u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0483A6 JSR -> $048415 stack real
    { cpu.push16Value(hw,0x83A8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83A9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8415u), 0x0483A6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0483A9;
L_0483A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83A9u,0x0483A9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483A9 LDX
    cpu.setX(0x2u, 8);
    goto L_0483AB;
L_0483AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ABu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ABu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483AB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0483AD;
L_0483AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483AD AND
    cpu.logicAnd(0xCu);
    goto L_0483AF;
L_0483AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483AF ORA
    cpu.logicOr(0x10u);
    goto L_0483B1;
L_0483B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483B1 LSR
    cpu.lsrA();
    goto L_0483B2;
L_0483B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u, 6u, 3u, cpu.address("abs", 0x8415u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0483B2 JSR -> $048415 stack real
    { cpu.push16Value(hw,0x83B4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83B5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8415u), 0x0483B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0483B5;
L_0483B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83B5u,0x0483B5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483B5 LDY
    cpu.setY(0x15u, 8);
    goto L_0483B7;
L_0483B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0483B9;
L_0483B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483B9 AND
    cpu.logicAnd(0x18u);
    goto L_0483BB;
L_0483BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483BB BNE -> $0483BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0483BF; }
    goto L_0483BD;
L_0483BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BDu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483BD LDY
    cpu.setY(0x18u, 8);
    goto L_0483BF;
L_0483BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BFu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483BF STY
    hw.write(cpu.address("dp", 0x12u), cpu.y, cpu.x8?8:16);
    goto L_0483C1;
L_0483C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483C1 BRA -> $04840D
    goto L_04840D;
L_0483C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u, 4u, 3u, cpu.address("abs", 0x1BA0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483C3 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0483C6;
L_0483C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483C6 BEQ -> $04840A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04840A; }
    goto L_0483C8;
L_0483C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C8u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483C8 CPX
    cpu.compareX(0xFEu);
    goto L_0483CA;
L_0483CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483CA BNE -> $0483D6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0483D6; }
    goto L_0483CC;
L_0483CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483CC LDA
    cpu.setA(0x21u, 8);
    goto L_0483CE;
L_0483CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CEu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483CE STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_0483D1;
L_0483D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483D1 LDA
    cpu.setA(0x8u, 8);
    goto L_0483D3;
L_0483D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D3u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483D3 STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_0483D6;
L_0483D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D6u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483D6 TXA
    cpu.transfer("TXA");
    goto L_0483D7;
L_0483D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483D7 LSR
    cpu.lsrA();
    goto L_0483D8;
L_0483D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483D8 LSR
    cpu.lsrA();
    goto L_0483D9;
L_0483D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483D9 LSR
    cpu.lsrA();
    goto L_0483DA;
L_0483DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483DA LSR
    cpu.lsrA();
    goto L_0483DB;
L_0483DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483DB TAY
    cpu.transfer("TAY");
    goto L_0483DC;
L_0483DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483DC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0483DE;
L_0483DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DEu,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DEu, 4u + ((((0x8231u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8231u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483DE AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0x8231u), cpu.m8?8:16));
    goto L_0483E1;
L_0483E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483E1 BNE -> $0483F3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0483F3; }
    goto L_0483E3;
L_0483E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483E3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0483E5;
L_0483E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E5u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483E5 EOR
    cpu.logicXor(0x1u);
    goto L_0483E7;
L_0483E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483E7 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_0483E9;
L_0483E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483E9 STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_0483EB;
L_0483EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483EB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0483ED;
L_0483ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EDu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483ED EOR
    cpu.logicXor(0x1u);
    goto L_0483EF;
L_0483EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483EF STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_0483F1;
L_0483F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483F1 STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_0483F3;
L_0483F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F3u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483F3 CPX
    cpu.compareX(0x80u);
    goto L_0483F5;
L_0483F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483F5 BCS -> $0483FE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_0483FE; }
    goto L_0483F7;
L_0483F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F7u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483F7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13D9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0483FA;
L_0483FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483FA CMP
    cpu.compareA(0x2u);
    goto L_0483FC;
L_0483FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483FC BNE -> $04840A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04840A; }
    goto L_0483FE;
L_0483FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FEu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FEu, 6u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483FE DEC
    cpu.decMem(hw, cpu.address("abs", 0x1BA0u), cpu.m8?8:16);
    goto L_048401;
L_048401:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8401u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8401u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8401u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048401 BNE -> $04840D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04840D; }
    goto L_048403;
L_048403:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8403u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8403u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8403u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048403 LDA
    cpu.setA(0x22u, 8);
    goto L_048405;
L_048405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8405u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8405u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8405u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048405 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_048408;
L_048408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8408u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8408u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048408 BRA -> $04840D
    goto L_04840D;
L_04840A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Au, 6u, 3u, cpu.address("abs", 0x8576u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04840A JSR -> $048576 stack real
    { cpu.push16Value(hw,0x840Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x840Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8576u), 0x04840Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04840D;
L_04840D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x840Du,0x04840Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Du, 6u, 3u, cpu.address("abs", 0xF708u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04840D JSR -> $04F708 stack real
    { cpu.push16Value(hw,0x840Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8410u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF708u), 0x04840Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048410;
L_048410:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8410u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8410u,0x048410u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8410u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8410u, 6u, 3u, cpu.address("abs", 0x862Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048410 JSR -> $04862E stack real
    { cpu.push16Value(hw,0x8412u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8413u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x862Eu), 0x048410u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048413;
L_048413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8413u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8413u,0x048413u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8413u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8413u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $048413 PLB
    cpu.pop("PLB", hw);
    goto L_048414;
L_048414:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8414u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8414u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8414u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $048414 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x048414u);return;} hw.unresolvedReturn(0x048414u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_048241_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x048395u: goto L_048395;
    case 0x048398u: goto L_048398;
    case 0x04839Au: goto L_04839A;
    case 0x04839Du: goto L_04839D;
    case 0x04839Fu: goto L_04839F;
    case 0x0483A1u: goto L_0483A1;
    case 0x0483A3u: goto L_0483A3;
    case 0x0483A5u: goto L_0483A5;
    case 0x0483A6u: goto L_0483A6;
    case 0x0483A9u: goto L_0483A9;
    case 0x0483ABu: goto L_0483AB;
    case 0x0483ADu: goto L_0483AD;
    case 0x0483AFu: goto L_0483AF;
    case 0x0483B1u: goto L_0483B1;
    case 0x0483B2u: goto L_0483B2;
    case 0x0483B5u: goto L_0483B5;
    case 0x0483B7u: goto L_0483B7;
    case 0x0483B9u: goto L_0483B9;
    case 0x0483BBu: goto L_0483BB;
    case 0x0483BDu: goto L_0483BD;
    case 0x0483BFu: goto L_0483BF;
    case 0x0483C1u: goto L_0483C1;
    case 0x0483C3u: goto L_0483C3;
    case 0x0483C6u: goto L_0483C6;
    case 0x0483C8u: goto L_0483C8;
    case 0x0483CAu: goto L_0483CA;
    case 0x0483CCu: goto L_0483CC;
    case 0x0483CEu: goto L_0483CE;
    case 0x0483D1u: goto L_0483D1;
    case 0x0483D3u: goto L_0483D3;
    case 0x0483D6u: goto L_0483D6;
    case 0x0483D7u: goto L_0483D7;
    case 0x0483D8u: goto L_0483D8;
    case 0x0483D9u: goto L_0483D9;
    case 0x0483DAu: goto L_0483DA;
    case 0x0483DBu: goto L_0483DB;
    case 0x0483DCu: goto L_0483DC;
    case 0x0483DEu: goto L_0483DE;
    case 0x0483E1u: goto L_0483E1;
    case 0x0483E3u: goto L_0483E3;
    case 0x0483E5u: goto L_0483E5;
    case 0x0483E7u: goto L_0483E7;
    case 0x0483E9u: goto L_0483E9;
    case 0x0483EBu: goto L_0483EB;
    case 0x0483EDu: goto L_0483ED;
    case 0x0483EFu: goto L_0483EF;
    case 0x0483F1u: goto L_0483F1;
    case 0x0483F3u: goto L_0483F3;
    case 0x0483F5u: goto L_0483F5;
    case 0x0483F7u: goto L_0483F7;
    case 0x0483FAu: goto L_0483FA;
    case 0x0483FCu: goto L_0483FC;
    case 0x0483FEu: goto L_0483FE;
    case 0x048401u: goto L_048401;
    case 0x048403u: goto L_048403;
    case 0x048405u: goto L_048405;
    case 0x048408u: goto L_048408;
    case 0x04840Au: goto L_04840A;
    case 0x04840Du: goto L_04840D;
    case 0x048410u: goto L_048410;
    case 0x048413u: goto L_048413;
    case 0x048414u: goto L_048414;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_048395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8395u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8395u, 5u, 3u, cpu.address("abs", 0x1DF2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048395 STA
    hw.write(cpu.address("abs", 0x1DF2u), cpu.a, cpu.m8?8:16);
    goto L_048398;
L_048398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8398u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8398u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048398 SEP
    cpu.sep(0x20u);
    goto L_04839A;
L_04839A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Au, 4u, 3u, cpu.address("abs", 0x13D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04839A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04839D;
L_04839D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04839D BEQ -> $0483C3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0483C3; }
    goto L_04839F;
L_04839F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04839F LDX
    cpu.setX(0x0u, 8);
    goto L_0483A1;
L_0483A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483A1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0483A3;
L_0483A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483A3 AND
    cpu.logicAnd(0x3u);
    goto L_0483A5;
L_0483A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483A5 ASL
    cpu.aslA();
    goto L_0483A6;
L_0483A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A6u, 6u, 3u, cpu.address("abs", 0x8415u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0483A6 JSR -> $048415 stack real
    { cpu.push16Value(hw,0x83A8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83A9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8415u), 0x0483A6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0483A9;
L_0483A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83A9u,0x0483A9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483A9 LDX
    cpu.setX(0x2u, 8);
    goto L_0483AB;
L_0483AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ABu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ABu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483AB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0483AD;
L_0483AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483AD AND
    cpu.logicAnd(0xCu);
    goto L_0483AF;
L_0483AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483AF ORA
    cpu.logicOr(0x10u);
    goto L_0483B1;
L_0483B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483B1 LSR
    cpu.lsrA();
    goto L_0483B2;
L_0483B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u, 6u, 3u, cpu.address("abs", 0x8415u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0483B2 JSR -> $048415 stack real
    { cpu.push16Value(hw,0x83B4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83B5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8415u), 0x0483B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0483B5;
L_0483B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83B5u,0x0483B5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483B5 LDY
    cpu.setY(0x15u, 8);
    goto L_0483B7;
L_0483B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0483B9;
L_0483B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483B9 AND
    cpu.logicAnd(0x18u);
    goto L_0483BB;
L_0483BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483BB BNE -> $0483BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0483BF; }
    goto L_0483BD;
L_0483BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BDu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483BD LDY
    cpu.setY(0x18u, 8);
    goto L_0483BF;
L_0483BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BFu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483BF STY
    hw.write(cpu.address("dp", 0x12u), cpu.y, cpu.x8?8:16);
    goto L_0483C1;
L_0483C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483C1 BRA -> $04840D
    goto L_04840D;
L_0483C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u, 4u, 3u, cpu.address("abs", 0x1BA0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483C3 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0483C6;
L_0483C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483C6 BEQ -> $04840A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04840A; }
    goto L_0483C8;
L_0483C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C8u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483C8 CPX
    cpu.compareX(0xFEu);
    goto L_0483CA;
L_0483CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483CA BNE -> $0483D6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0483D6; }
    goto L_0483CC;
L_0483CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483CC LDA
    cpu.setA(0x21u, 8);
    goto L_0483CE;
L_0483CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CEu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483CE STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_0483D1;
L_0483D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483D1 LDA
    cpu.setA(0x8u, 8);
    goto L_0483D3;
L_0483D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D3u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483D3 STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_0483D6;
L_0483D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D6u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483D6 TXA
    cpu.transfer("TXA");
    goto L_0483D7;
L_0483D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483D7 LSR
    cpu.lsrA();
    goto L_0483D8;
L_0483D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483D8 LSR
    cpu.lsrA();
    goto L_0483D9;
L_0483D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483D9 LSR
    cpu.lsrA();
    goto L_0483DA;
L_0483DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483DA LSR
    cpu.lsrA();
    goto L_0483DB;
L_0483DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483DB TAY
    cpu.transfer("TAY");
    goto L_0483DC;
L_0483DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483DC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0483DE;
L_0483DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DEu,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DEu, 4u + ((((0x8231u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8231u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483DE AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0x8231u), cpu.m8?8:16));
    goto L_0483E1;
L_0483E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483E1 BNE -> $0483F3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0483F3; }
    goto L_0483E3;
L_0483E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483E3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0483E5;
L_0483E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E5u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483E5 EOR
    cpu.logicXor(0x1u);
    goto L_0483E7;
L_0483E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483E7 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_0483E9;
L_0483E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483E9 STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_0483EB;
L_0483EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483EB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0483ED;
L_0483ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EDu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483ED EOR
    cpu.logicXor(0x1u);
    goto L_0483EF;
L_0483EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483EF STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_0483F1;
L_0483F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483F1 STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_0483F3;
L_0483F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F3u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483F3 CPX
    cpu.compareX(0x80u);
    goto L_0483F5;
L_0483F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483F5 BCS -> $0483FE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_0483FE; }
    goto L_0483F7;
L_0483F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F7u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483F7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13D9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0483FA;
L_0483FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483FA CMP
    cpu.compareA(0x2u);
    goto L_0483FC;
L_0483FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483FC BNE -> $04840A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04840A; }
    goto L_0483FE;
L_0483FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FEu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FEu, 6u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0483FE DEC
    cpu.decMem(hw, cpu.address("abs", 0x1BA0u), cpu.m8?8:16);
    goto L_048401;
L_048401:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8401u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8401u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8401u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048401 BNE -> $04840D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04840D; }
    goto L_048403;
L_048403:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8403u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8403u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8403u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048403 LDA
    cpu.setA(0x22u, 8);
    goto L_048405;
L_048405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8405u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8405u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8405u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048405 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_048408;
L_048408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8408u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8408u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048408 BRA -> $04840D
    goto L_04840D;
L_04840A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Au, 6u, 3u, cpu.address("abs", 0x8576u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04840A JSR -> $048576 stack real
    { cpu.push16Value(hw,0x840Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x840Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8576u), 0x04840Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04840D;
L_04840D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x840Du,0x04840Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Du, 6u, 3u, cpu.address("abs", 0xF708u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04840D JSR -> $04F708 stack real
    { cpu.push16Value(hw,0x840Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8410u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF708u), 0x04840Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048410;
L_048410:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8410u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8410u,0x048410u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8410u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8410u, 6u, 3u, cpu.address("abs", 0x862Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048410 JSR -> $04862E stack real
    { cpu.push16Value(hw,0x8412u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8413u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x862Eu), 0x048410u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048413;
L_048413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8413u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8413u,0x048413u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8413u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8413u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $048413 PLB
    cpu.pop("PLB", hw);
    goto L_048414;
L_048414:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8414u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8414u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8414u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $048414 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x048414u);return;} hw.unresolvedReturn(0x048414u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_04F882_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04F882u: goto L_04F882;
    case 0x04F884u: goto L_04F884;
    case 0x04F887u: goto L_04F887;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04F882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF882u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF882u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F882 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04F884;
L_04F884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF884u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF884u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F884 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13D9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F887;
L_04F887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF887u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF887u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F887 CPY
    cpu.compareY(0xAu);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF889u,0x04F887u); return;
}

void sub_04FE90_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04FE90u: goto L_04FE90;
    case 0x04FE91u: goto L_04FE91;
    case 0x04FE92u: goto L_04FE92;
    case 0x04FE94u: goto L_04FE94;
    case 0x04FE95u: goto L_04FE95;
    case 0x04FE98u: goto L_04FE98;
    case 0x04FE9Bu: goto L_04FE9B;
    case 0x04FE9Du: goto L_04FE9D;
    case 0x04FEA0u: goto L_04FEA0;
    case 0x04FEA1u: goto L_04FEA1;
    case 0x04FEA2u: goto L_04FEA2;
    case 0x04FEA4u: goto L_04FEA4;
    case 0x04FEA5u: goto L_04FEA5;
    case 0x04FEA8u: goto L_04FEA8;
    case 0x04FEABu: goto L_04FEAB;
    case 0x04FEAEu: goto L_04FEAE;
    case 0x04FEAFu: goto L_04FEAF;
    case 0x04FEB0u: goto L_04FEB0;
    case 0x04FEB1u: goto L_04FEB1;
    case 0x04FEB2u: goto L_04FEB2;
    case 0x04FEB3u: goto L_04FEB3;
    case 0x04FEB6u: goto L_04FEB6;
    case 0x04FEB9u: goto L_04FEB9;
    case 0x04FEBCu: goto L_04FEBC;
    case 0x04FEBDu: goto L_04FEBD;
    case 0x04FEBEu: goto L_04FEBE;
    case 0x04FEBFu: goto L_04FEBF;
    case 0x04FEC0u: goto L_04FEC0;
    case 0x04FEC1u: goto L_04FEC1;
    case 0x04FEC3u: goto L_04FEC3;
    case 0x04FEC4u: goto L_04FEC4;
    case 0x04FEC6u: goto L_04FEC6;
    case 0x04FEC8u: goto L_04FEC8;
    case 0x04FEC9u: goto L_04FEC9;
    case 0x04FECCu: goto L_04FECC;
    case 0x04FECFu: goto L_04FECF;
    case 0x04FED0u: goto L_04FED0;
    case 0x04FED3u: goto L_04FED3;
    case 0x04FED6u: goto L_04FED6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04FE90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE90u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE90u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE90 TXA
    cpu.transfer("TXA");
    goto L_04FE91;
L_04FE91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE91u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE91u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE91 CLC
    cpu.setFlag('C', false);
    goto L_04FE92;
L_04FE92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE92u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE92 ADC
    cpu.adc(0x20u);
    goto L_04FE94;
L_04FE94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE94u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE94 TAX
    cpu.transfer("TAX");
    goto L_04FE95;
L_04FE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE95u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE95u, 6u, 3u, cpu.address("abs", 0xFEABu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FE95 JSR -> $04FEAB stack real
    { cpu.push16Value(hw,0xFE97u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFE98u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFEABu), 0x04FE95u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04FE98;
L_04FE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE98u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFE98u,0x04FE98u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE98u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE98u, 4u + ((((0x0E35u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE98 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE35u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FE9B;
L_04FE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE9Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE9B BPL -> $04FEA0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04FEA0; }
    goto L_04FE9D;
L_04FE9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE9Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE9Du, 5u, 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE9D STZ
    hw.write(cpu.address("absx", 0xE35u), 0, cpu.m8?8:16);
    goto L_04FEA0;
L_04FEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA0u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEA0 TXA
    cpu.transfer("TXA");
    goto L_04FEA1;
L_04FEA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEA1 SEC
    cpu.setFlag('C', true);
    goto L_04FEA2;
L_04FEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEA2 SBC
    cpu.sbc(0x10u);
    goto L_04FEA4;
L_04FEA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEA4 TAX
    cpu.transfer("TAX");
    goto L_04FEA5;
L_04FEA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA5u, 6u, 3u, cpu.address("abs", 0xFEABu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FEA5 JSR -> $04FEAB stack real
    { cpu.push16Value(hw,0xFEA7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFEA8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFEABu), 0x04FEA5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04FEA8;
L_04FEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFEA8u,0x04FEA8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA8u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA8u, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEA8 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDDEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04FEAB;
L_04FEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEABu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEABu, 4u + ((((0x0E95u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEAB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FEAE;
L_04FEAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEAEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEAE ASL
    cpu.aslA();
    goto L_04FEAF;
L_04FEAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEAFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEAFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEAF ASL
    cpu.aslA();
    goto L_04FEB0;
L_04FEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEB0 ASL
    cpu.aslA();
    goto L_04FEB1;
L_04FEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEB1 ASL
    cpu.aslA();
    goto L_04FEB2;
L_04FEB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEB2 CLC
    cpu.setFlag('C', false);
    goto L_04FEB3;
L_04FEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB3u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB3u, 4u + ((((0x0EC5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0EC5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEB3 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xEC5u), cpu.m8?8:16));
    goto L_04FEB6;
L_04FEB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB6u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB6u, 5u, 3u, cpu.address("absx", 0x0EC5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEB6 STA
    hw.write(cpu.address("absx", 0xEC5u), cpu.a, cpu.m8?8:16);
    goto L_04FEB9;
L_04FEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB9u, 4u + ((((0x0E95u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEB9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FEBC;
L_04FEBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBCu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FEBC PHP
    cpu.push("PHP", hw);
    goto L_04FEBD;
L_04FEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEBD LSR
    cpu.lsrA();
    goto L_04FEBE;
L_04FEBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEBE LSR
    cpu.lsrA();
    goto L_04FEBF;
L_04FEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEBF LSR
    cpu.lsrA();
    goto L_04FEC0;
L_04FEC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEC0 LSR
    cpu.lsrA();
    goto L_04FEC1;
L_04FEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEC1 LDY
    cpu.setY(0x0u, 8);
    goto L_04FEC3;
L_04FEC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC3u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FEC3 PLP
    cpu.pop("PLP", hw);
    goto L_04FEC4;
L_04FEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFEC4u,0x04FEC4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEC4 BPL -> $04FEC9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04FEC9; }
    goto L_04FEC6;
L_04FEC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC6u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEC6 ORA
    cpu.logicOr(0xF0u);
    goto L_04FEC8;
L_04FEC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC8u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEC8 DEY
    cpu.decReg('Y');
    goto L_04FEC9;
L_04FEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC9u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC9u, 4u + ((((0x0E35u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEC9 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE35u), cpu.m8?8:16));
    goto L_04FECC;
L_04FECC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFECCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFECCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFECCu, 5u, 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FECC STA
    hw.write(cpu.address("absx", 0xE35u), cpu.a, cpu.m8?8:16);
    goto L_04FECF;
L_04FECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFECFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFECFu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFECFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FECF TYA
    cpu.transfer("TYA");
    goto L_04FED0;
L_04FED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFED0u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFED0u, 4u + ((((0x0E65u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FED0 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE65u), cpu.m8?8:16));
    goto L_04FED3;
L_04FED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFED3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFED3u, 5u, 3u, cpu.address("absx", 0x0E65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FED3 STA
    hw.write(cpu.address("absx", 0xE65u), cpu.a, cpu.m8?8:16);
    goto L_04FED6;
L_04FED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFED6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFED6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FED6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FED6u);return;} hw.unresolvedReturn(0x04FED6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04FE90_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04FE90u: goto L_04FE90;
    case 0x04FE91u: goto L_04FE91;
    case 0x04FE92u: goto L_04FE92;
    case 0x04FE94u: goto L_04FE94;
    case 0x04FE95u: goto L_04FE95;
    case 0x04FE98u: goto L_04FE98;
    case 0x04FE9Bu: goto L_04FE9B;
    case 0x04FE9Du: goto L_04FE9D;
    case 0x04FEA0u: goto L_04FEA0;
    case 0x04FEA1u: goto L_04FEA1;
    case 0x04FEA2u: goto L_04FEA2;
    case 0x04FEA4u: goto L_04FEA4;
    case 0x04FEA5u: goto L_04FEA5;
    case 0x04FEA8u: goto L_04FEA8;
    case 0x04FEABu: goto L_04FEAB;
    case 0x04FEAEu: goto L_04FEAE;
    case 0x04FEAFu: goto L_04FEAF;
    case 0x04FEB0u: goto L_04FEB0;
    case 0x04FEB1u: goto L_04FEB1;
    case 0x04FEB2u: goto L_04FEB2;
    case 0x04FEB3u: goto L_04FEB3;
    case 0x04FEB6u: goto L_04FEB6;
    case 0x04FEB9u: goto L_04FEB9;
    case 0x04FEBCu: goto L_04FEBC;
    case 0x04FEBDu: goto L_04FEBD;
    case 0x04FEBEu: goto L_04FEBE;
    case 0x04FEBFu: goto L_04FEBF;
    case 0x04FEC0u: goto L_04FEC0;
    case 0x04FEC1u: goto L_04FEC1;
    case 0x04FEC3u: goto L_04FEC3;
    case 0x04FEC4u: goto L_04FEC4;
    case 0x04FEC6u: goto L_04FEC6;
    case 0x04FEC8u: goto L_04FEC8;
    case 0x04FEC9u: goto L_04FEC9;
    case 0x04FECCu: goto L_04FECC;
    case 0x04FECFu: goto L_04FECF;
    case 0x04FED0u: goto L_04FED0;
    case 0x04FED3u: goto L_04FED3;
    case 0x04FED6u: goto L_04FED6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04FE90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE90u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE90u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE90 TXA
    cpu.transfer("TXA");
    goto L_04FE91;
L_04FE91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE91u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE91u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE91 CLC
    cpu.setFlag('C', false);
    goto L_04FE92;
L_04FE92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE92u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE92 ADC
    cpu.adc(0x20u);
    goto L_04FE94;
L_04FE94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE94u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE94 TAX
    cpu.transfer("TAX");
    goto L_04FE95;
L_04FE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE95u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE95u, 6u, 3u, cpu.address("abs", 0xFEABu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FE95 JSR -> $04FEAB stack real
    { cpu.push16Value(hw,0xFE97u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFE98u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFEABu), 0x04FE95u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04FE98;
L_04FE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE98u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFE98u,0x04FE98u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE98u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE98u, 4u + ((((0x0E35u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE98 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE35u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FE9B;
L_04FE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE9Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE9B BPL -> $04FEA0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04FEA0; }
    goto L_04FE9D;
L_04FE9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE9Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE9Du, 5u, 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE9D STZ
    hw.write(cpu.address("absx", 0xE35u), 0, cpu.m8?8:16);
    goto L_04FEA0;
L_04FEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA0u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEA0 TXA
    cpu.transfer("TXA");
    goto L_04FEA1;
L_04FEA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEA1 SEC
    cpu.setFlag('C', true);
    goto L_04FEA2;
L_04FEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEA2 SBC
    cpu.sbc(0x10u);
    goto L_04FEA4;
L_04FEA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEA4 TAX
    cpu.transfer("TAX");
    goto L_04FEA5;
L_04FEA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA5u, 6u, 3u, cpu.address("abs", 0xFEABu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FEA5 JSR -> $04FEAB stack real
    { cpu.push16Value(hw,0xFEA7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFEA8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFEABu), 0x04FEA5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04FEA8;
L_04FEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFEA8u,0x04FEA8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA8u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA8u, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEA8 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDDEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04FEAB;
L_04FEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEABu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEABu, 4u + ((((0x0E95u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEAB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FEAE;
L_04FEAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEAEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEAE ASL
    cpu.aslA();
    goto L_04FEAF;
L_04FEAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEAFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEAFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEAF ASL
    cpu.aslA();
    goto L_04FEB0;
L_04FEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEB0 ASL
    cpu.aslA();
    goto L_04FEB1;
L_04FEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEB1 ASL
    cpu.aslA();
    goto L_04FEB2;
L_04FEB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEB2 CLC
    cpu.setFlag('C', false);
    goto L_04FEB3;
L_04FEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB3u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB3u, 4u + ((((0x0EC5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0EC5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEB3 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xEC5u), cpu.m8?8:16));
    goto L_04FEB6;
L_04FEB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB6u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB6u, 5u, 3u, cpu.address("absx", 0x0EC5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEB6 STA
    hw.write(cpu.address("absx", 0xEC5u), cpu.a, cpu.m8?8:16);
    goto L_04FEB9;
L_04FEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB9u, 4u + ((((0x0E95u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEB9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FEBC;
L_04FEBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBCu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FEBC PHP
    cpu.push("PHP", hw);
    goto L_04FEBD;
L_04FEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEBD LSR
    cpu.lsrA();
    goto L_04FEBE;
L_04FEBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEBE LSR
    cpu.lsrA();
    goto L_04FEBF;
L_04FEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEBF LSR
    cpu.lsrA();
    goto L_04FEC0;
L_04FEC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEC0 LSR
    cpu.lsrA();
    goto L_04FEC1;
L_04FEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEC1 LDY
    cpu.setY(0x0u, 8);
    goto L_04FEC3;
L_04FEC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC3u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04FEC3 PLP
    cpu.pop("PLP", hw);
    goto L_04FEC4;
L_04FEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFEC4u,0x04FEC4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEC4 BPL -> $04FEC9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04FEC9; }
    goto L_04FEC6;
L_04FEC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC6u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEC6 ORA
    cpu.logicOr(0xF0u);
    goto L_04FEC8;
L_04FEC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC8u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEC8 DEY
    cpu.decReg('Y');
    goto L_04FEC9;
L_04FEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC9u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC9u, 4u + ((((0x0E35u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FEC9 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE35u), cpu.m8?8:16));
    goto L_04FECC;
L_04FECC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFECCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFECCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFECCu, 5u, 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FECC STA
    hw.write(cpu.address("absx", 0xE35u), cpu.a, cpu.m8?8:16);
    goto L_04FECF;
L_04FECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFECFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFECFu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFECFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FECF TYA
    cpu.transfer("TYA");
    goto L_04FED0;
L_04FED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFED0u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFED0u, 4u + ((((0x0E65u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FED0 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE65u), cpu.m8?8:16));
    goto L_04FED3;
L_04FED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFED3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFED3u, 5u, 3u, cpu.address("absx", 0x0E65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FED3 STA
    hw.write(cpu.address("absx", 0xE65u), cpu.a, cpu.m8?8:16);
    goto L_04FED6;
L_04FED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFED6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFED6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FED6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FED6u);return;} hw.unresolvedReturn(0x04FED6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_05881A_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05881Au: goto L_05881A;
    case 0x05881Cu: goto L_05881C;
    case 0x05881Fu: goto L_05881F;
    case 0x058823u: goto L_058823;
    case 0x058826u: goto L_058826;
    case 0x058829u: goto L_058829;
    case 0x05882Cu: goto L_05882C;
    case 0x05882Du: goto L_05882D;
    case 0x05882Eu: goto L_05882E;
    case 0x058830u: goto L_058830;
    case 0x058831u: goto L_058831;
    case 0x058833u: goto L_058833;
    case 0x058835u: goto L_058835;
    case 0x058838u: goto L_058838;
    case 0x058839u: goto L_058839;
    case 0x05883Au: goto L_05883A;
    case 0x05883Cu: goto L_05883C;
    case 0x05883Du: goto L_05883D;
    case 0x05883Fu: goto L_05883F;
    case 0x058840u: goto L_058840;
    case 0x058842u: goto L_058842;
    case 0x058843u: goto L_058843;
    case 0x058845u: goto L_058845;
    case 0x058846u: goto L_058846;
    case 0x058848u: goto L_058848;
    case 0x05884Au: goto L_05884A;
    case 0x05884Bu: goto L_05884B;
    case 0x05884Cu: goto L_05884C;
    case 0x05884Eu: goto L_05884E;
    case 0x058850u: goto L_058850;
    case 0x058853u: goto L_058853;
    case 0x058854u: goto L_058854;
    case 0x058855u: goto L_058855;
    case 0x058857u: goto L_058857;
    case 0x058859u: goto L_058859;
    case 0x05885Au: goto L_05885A;
    case 0x05885Bu: goto L_05885B;
    case 0x05885Du: goto L_05885D;
    case 0x05885Eu: goto L_05885E;
    case 0x058860u: goto L_058860;
    case 0x058861u: goto L_058861;
    case 0x058863u: goto L_058863;
    case 0x058864u: goto L_058864;
    case 0x058866u: goto L_058866;
    case 0x058867u: goto L_058867;
    case 0x058869u: goto L_058869;
    case 0x05886Au: goto L_05886A;
    case 0x05886Cu: goto L_05886C;
    case 0x05886Du: goto L_05886D;
    case 0x05886Fu: goto L_05886F;
    case 0x058870u: goto L_058870;
    case 0x058872u: goto L_058872;
    case 0x058873u: goto L_058873;
    case 0x058875u: goto L_058875;
    case 0x058876u: goto L_058876;
    case 0x058878u: goto L_058878;
    case 0x058879u: goto L_058879;
    case 0x05887Bu: goto L_05887B;
    case 0x05887Cu: goto L_05887C;
    case 0x05887Eu: goto L_05887E;
    case 0x058880u: goto L_058880;
    case 0x058883u: goto L_058883;
    case 0x058885u: goto L_058885;
    case 0x058888u: goto L_058888;
    case 0x05888Cu: goto L_05888C;
    case 0x05888Eu: goto L_05888E;
    case 0x058890u: goto L_058890;
    case 0x058891u: goto L_058891;
    case 0x058893u: goto L_058893;
    case 0x058894u: goto L_058894;
    case 0x058896u: goto L_058896;
    case 0x058897u: goto L_058897;
    case 0x058899u: goto L_058899;
    case 0x05889Au: goto L_05889A;
    case 0x05889Cu: goto L_05889C;
    case 0x05889Fu: goto L_05889F;
    case 0x0588A2u: goto L_0588A2;
    case 0x0588A5u: goto L_0588A5;
    case 0x0588A8u: goto L_0588A8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05881A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05881A SEP
    cpu.sep(0x30u);
    goto L_05881C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05881A SEP
    cpu.sep(0x30u);
    goto L_05881C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x881Au,0x05881Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05881C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Cu, 4u, 3u, cpu.address("abs", 0x1925u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05881C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1925u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05881F;
L_05881F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Fu, 8u, 4u, 0x0086FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05881F JSL -> $0086FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8822u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8823u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086FAu, 0x05881Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_058823;
L_058823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8823u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8823u,0x058823u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8823u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8823u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058823 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_058826;
L_058826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8826u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058826 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_058829;
L_058829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8829u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8829u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058829 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_05882C;
L_05882C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Cu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05882C TXY
    cpu.transfer("TXY");
    goto L_05882D;
L_05882D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05882D TXA
    cpu.transfer("TXA");
    goto L_05882E;
L_05882E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05882E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16));
    goto L_058830;
L_058830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058830 TXA
    cpu.transfer("TXA");
    goto L_058831;
L_058831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8831u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8831u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058831 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCEu), cpu.m8?8:16));
    goto L_058833;
L_058833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8833u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8833u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058833 BIT
    cpu.bit(0x5u, true);
    goto L_058835;
L_058835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8835u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8835u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058835 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_058838;
L_058838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8838u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8838u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058838 TXY
    cpu.transfer("TXY");
    goto L_058839;
L_058839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8839u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8839u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058839 TXA
    cpu.transfer("TXA");
    goto L_05883A;
L_05883A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Au,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05883A ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16));
    goto L_05883C;
L_05883C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05883C TXA
    cpu.transfer("TXA");
    goto L_05883D;
L_05883D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Du,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05883D ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05883F;
L_05883F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05883F TXA
    cpu.transfer("TXA");
    goto L_058840;
L_058840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8840u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8840u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058840 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16));
    goto L_058842;
L_058842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8842u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8842u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058842 TXA
    cpu.transfer("TXA");
    goto L_058843;
L_058843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058843 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058845;
L_058845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8845u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8845u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058845 TXA
    cpu.transfer("TXA");
    goto L_058846;
L_058846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058846 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCEu), cpu.m8?8:16));
    goto L_058848;
L_058848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058848 BIT
    cpu.bit(0x5u, true);
    goto L_05884A;
L_05884A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05884A TXY
    cpu.transfer("TXY");
    goto L_05884B;
L_05884B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Bu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05884B TXA
    cpu.transfer("TXA");
    goto L_05884C;
L_05884C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05884C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCEu), cpu.m8?8:16));
    goto L_05884E;
L_05884E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05884E BIT
    cpu.bit(0x5u, true);
    goto L_058850;
L_058850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8850u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8850u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058850 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_058853;
L_058853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8853u,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8853u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058853 TXS
    cpu.transfer("TXS");
    goto L_058854;
L_058854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058854 TXA
    cpu.transfer("TXA");
    goto L_058855;
L_058855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8855u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8855u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058855 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCEu), cpu.m8?8:16));
    goto L_058857;
L_058857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058857 BIT
    cpu.bit(0x5u, true);
    goto L_058859;
L_058859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8859u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058859 TXS
    cpu.transfer("TXS");
    goto L_05885A;
L_05885A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05885A TXA
    cpu.transfer("TXA");
    goto L_05885B;
L_05885B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05885B ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05885D;
L_05885D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05885D TXA
    cpu.transfer("TXA");
    goto L_05885E;
L_05885E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05885E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058860;
L_058860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8860u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8860u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058860 TXA
    cpu.transfer("TXA");
    goto L_058861;
L_058861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8861u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058861 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058863;
L_058863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8863u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8863u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058863 TXA
    cpu.transfer("TXA");
    goto L_058864;
L_058864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8864u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058864 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058866;
L_058866:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8866u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8866u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8866u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058866 TXA
    cpu.transfer("TXA");
    goto L_058867;
L_058867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8867u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8867u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058867 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058869;
L_058869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8869u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058869 TXA
    cpu.transfer("TXA");
    goto L_05886A;
L_05886A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Au,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05886A ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05886C;
L_05886C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05886C TXA
    cpu.transfer("TXA");
    goto L_05886D;
L_05886D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05886D ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05886F;
L_05886F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05886F TXA
    cpu.transfer("TXA");
    goto L_058870;
L_058870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8870u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8870u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058870 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058872;
L_058872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8872u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8872u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058872 TXA
    cpu.transfer("TXA");
    goto L_058873;
L_058873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8873u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8873u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058873 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058875;
L_058875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8875u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8875u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058875 TXA
    cpu.transfer("TXA");
    goto L_058876;
L_058876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8876u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8876u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058876 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_058878;
L_058878:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8878u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8878u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8878u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058878 TXA
    cpu.transfer("TXA");
    goto L_058879;
L_058879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8879u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8879u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058879 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    goto L_05887B;
L_05887B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Bu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05887B TXA
    cpu.transfer("TXA");
    goto L_05887C;
L_05887C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05887C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCEu), cpu.m8?8:16));
    goto L_05887E;
L_05887E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Eu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05887E BIT
    cpu.bit(0x5u, true);
    goto L_058880;
L_058880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8880u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8880u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058880 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_058883;
L_058883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8883u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8883u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058883 SEP
    cpu.sep(0x30u);
    goto L_058885;
L_058885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8885u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8885u, 4u, 3u, cpu.address("abs", 0x1925u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058885 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1925u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058888;
L_058888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8888u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8888u, 8u, 4u, 0x0086FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058888 JSL -> $0086FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x888Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x888Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086FAu, 0x058888u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05888C;
L_05888C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x888Cu,0x05888Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Cu,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05888C BVS -> $05881A
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_05881A; }
    goto L_05888E;
L_05888E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05888E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_058890;
L_058890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8890u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8890u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8890u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058890 PHB
    cpu.push("PHB", hw);
    goto L_058891;
L_058891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058891 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_058893;
L_058893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058893 PHB
    cpu.push("PHB", hw);
    goto L_058894;
L_058894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8894u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8894u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058894 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_058896;
L_058896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058896 PHB
    cpu.push("PHB", hw);
    goto L_058897;
L_058897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8897u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8897u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058897 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_058899;
L_058899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8899u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8899u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058899 PHB
    cpu.push("PHB", hw);
    goto L_05889A;
L_05889A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Au,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05889A ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16));
    goto L_05889C;
L_05889C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Cu))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Cu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Cu, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05889C STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_05889F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x889Cu,0x05889Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05889F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Fu))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Fu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Fu, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05889F STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_0588A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x889Fu,0x05889Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A2u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A2u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A2u, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588A2 STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_0588A5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88A2u,0x0588A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A5u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A5u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A5u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588A5 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0588A8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88A5u,0x0588A5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0588A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A8u))return;
  // 15 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588A8 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88ABu,0x0588A8u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88A8u,0x0588A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_058883_E0M0X0C0_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0588FFu: goto L_0588FF;
    case 0x058900u: goto L_058900;
    case 0x058902u: goto L_058902;
    case 0x058903u: goto L_058903;
    case 0x058905u: goto L_058905;
    case 0x058907u: goto L_058907;
    case 0x05890Au: goto L_05890A;
    case 0x05890Bu: goto L_05890B;
    case 0x05890Cu: goto L_05890C;
    case 0x05890Eu: goto L_05890E;
    case 0x05890Fu: goto L_05890F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0588FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FFu))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FFu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588FF TXA
    cpu.transfer("TXA");
    goto L_058900;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88FFu,0x0588FFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058900:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8900u))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8900u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8900u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058900 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16));
    goto L_058902;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8900u,0x058900u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8902u))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8902u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8902u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058902 TXA
    cpu.transfer("TXA");
    goto L_058903;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8902u,0x058902u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8903u))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8903u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8903u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058903 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCEu), cpu.m8?8:16));
    goto L_058905;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8903u,0x058903u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058905:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8905u))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8905u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8905u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058905 BIT
    cpu.bit(0x5u, true);
    goto L_058907;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8905u,0x058905u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8907u))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8907u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8907u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058907 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_05890A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8907u,0x058907u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05890A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Au))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Au,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05890A TXY
    cpu.transfer("TXY");
    goto L_05890B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x890Au,0x05890Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05890B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Bu))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Bu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05890B TXA
    cpu.transfer("TXA");
    goto L_05890C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x890Bu,0x05890Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05890C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Cu))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05890C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16));
    goto L_05890E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x890Cu,0x05890Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05890E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Eu))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05890E TXA
    cpu.transfer("TXA");
    goto L_05890F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x890Eu,0x05890Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05890F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Fu))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05890F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8911u,0x05890Fu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x890Fu,0x05890Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_05881A_E0M0X0CQ_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0588FFu: goto L_0588FF;
    case 0x058900u: goto L_058900;
    case 0x058902u: goto L_058902;
    case 0x058903u: goto L_058903;
    case 0x058905u: goto L_058905;
    case 0x058907u: goto L_058907;
    case 0x05890Au: goto L_05890A;
    case 0x05890Bu: goto L_05890B;
    case 0x05890Cu: goto L_05890C;
    case 0x05890Eu: goto L_05890E;
    case 0x05890Fu: goto L_05890F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0588FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FFu))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FFu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0588FF TXA
    cpu.transfer("TXA");
    goto L_058900;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88FFu,0x0588FFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058900:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8900u))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8900u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8900u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058900 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16));
    goto L_058902;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8900u,0x058900u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8902u))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8902u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8902u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058902 TXA
    cpu.transfer("TXA");
    goto L_058903;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8902u,0x058902u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8903u))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8903u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8903u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058903 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCEu), cpu.m8?8:16));
    goto L_058905;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8903u,0x058903u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058905:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8905u))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8905u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8905u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058905 BIT
    cpu.bit(0x5u, true);
    goto L_058907;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8905u,0x058905u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8907u))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8907u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8907u, 6u, 3u, cpu.address("abs", 0x0589u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058907 DEC
    cpu.decMem(hw, cpu.address("abs", 0x589u), cpu.m8?8:16);
    goto L_05890A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8907u,0x058907u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05890A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Au))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Au,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05890A TXY
    cpu.transfer("TXY");
    goto L_05890B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x890Au,0x05890Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05890B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Bu))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Bu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05890B TXA
    cpu.transfer("TXA");
    goto L_05890C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x890Bu,0x05890Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05890C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Cu))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05890C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16));
    goto L_05890E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x890Cu,0x05890Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05890E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Eu))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05890E TXA
    cpu.transfer("TXA");
    goto L_05890F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x890Eu,0x05890Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05890F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Fu))return;
  // 14 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05890F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8911u,0x05890Fu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x890Fu,0x05890Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_0CA75A_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CA75Au: goto L_0CA75A;
    case 0x0CA75Bu: goto L_0CA75B;
    case 0x0CA75Du: goto L_0CA75D;
    case 0x0CA75Eu: goto L_0CA75E;
    case 0x0CA75Fu: goto L_0CA75F;
    case 0x0CA763u: goto L_0CA763;
    case 0x0CA764u: goto L_0CA764;
    case 0x0CA767u: goto L_0CA767;
    case 0x0CA76Au: goto L_0CA76A;
    case 0x0CA76Cu: goto L_0CA76C;
    case 0x0CA76Fu: goto L_0CA76F;
    case 0x0CA772u: goto L_0CA772;
    case 0x0CA774u: goto L_0CA774;
    case 0x0CA777u: goto L_0CA777;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CA75A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Au,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CA75A PHB
    cpu.push("PHB", hw);
    goto L_0CA75B;
L_0CA75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA75B LDA
    cpu.setA(0x0u, 8);
    goto L_0CA75D;
L_0CA75D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CA75D PHA
    cpu.push("PHA", hw);
    goto L_0CA75E;
L_0CA75E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CA75E PLB
    cpu.pop("PLB", hw);
    goto L_0CA75F;
L_0CA75F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Fu, 8u, 4u, 0x00CEB1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0CA75F JSL -> $00CEB1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA762u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA763u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00CEB1u, 0x0CA75Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0CA763;
L_0CA763:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA763u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA763u,0x0CA763u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA763u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA763u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CA763 PLB
    cpu.pop("PLB", hw);
    goto L_0CA764;
L_0CA764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA764u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA764u, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA764 STZ
    hw.write(cpu.address("abs", 0x13F9u), 0, cpu.m8?8:16);
    goto L_0CA767;
L_0CA767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA767u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA767u, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA767 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1496u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CA76A;
L_0CA76A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA76A BEQ -> $0CA76F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CA76F; }
    goto L_0CA76C;
L_0CA76C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Cu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Cu, 6u, 3u, cpu.address("abs", 0x1496u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA76C DEC
    cpu.decMem(hw, cpu.address("abs", 0x1496u), cpu.m8?8:16);
    goto L_0CA76F;
L_0CA76F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Fu, 4u, 3u, cpu.address("abs", 0x14A2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA76F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CA772;
L_0CA772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA772u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA772u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA772 BEQ -> $0CA777
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CA777; }
    goto L_0CA774;
L_0CA774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA774u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA774u, 6u, 3u, cpu.address("abs", 0x14A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA774 DEC
    cpu.decMem(hw, cpu.address("abs", 0x14A2u), cpu.m8?8:16);
    goto L_0CA777;
L_0CA777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA777u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA777u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CA777 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CA777u);return;} hw.unresolvedReturn(0x0CA777u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0CAA15_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CAA15u: goto L_0CAA15;
    case 0x0CAA16u: goto L_0CAA16;
    case 0x0CAA18u: goto L_0CAA18;
    case 0x0CAA19u: goto L_0CAA19;
    case 0x0CAA1Au: goto L_0CAA1A;
    case 0x0CAA1Du: goto L_0CAA1D;
    case 0x0CAA20u: goto L_0CAA20;
    case 0x0CAA23u: goto L_0CAA23;
    case 0x0CAA26u: goto L_0CAA26;
    case 0x0CAA27u: goto L_0CAA27;
    case 0x0CAA29u: goto L_0CAA29;
    case 0x0CAA2Cu: goto L_0CAA2C;
    case 0x0CAA2Fu: goto L_0CAA2F;
    case 0x0CAA31u: goto L_0CAA31;
    case 0x0CAA34u: goto L_0CAA34;
    case 0x0CAA35u: goto L_0CAA35;
    case 0x0CAA37u: goto L_0CAA37;
    case 0x0CAA3Au: goto L_0CAA3A;
    case 0x0CAA3Du: goto L_0CAA3D;
    case 0x0CAA40u: goto L_0CAA40;
    case 0x0CAA43u: goto L_0CAA43;
    case 0x0CAA46u: goto L_0CAA46;
    case 0x0CAA47u: goto L_0CAA47;
    case 0x0CAA48u: goto L_0CAA48;
    case 0x0CAA49u: goto L_0CAA49;
    case 0x0CAA4Au: goto L_0CAA4A;
    case 0x0CAA4Cu: goto L_0CAA4C;
    case 0x0CAA4Fu: goto L_0CAA4F;
    case 0x0CAA52u: goto L_0CAA52;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CAA15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA15u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA15u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CAA15 PHY
    cpu.push("PHY", hw);
    goto L_0CAA16;
L_0CAA16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA16u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA16u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA16 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAA18;
L_0CAA18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA18u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA18 ASL
    cpu.aslA();
    goto L_0CAA19;
L_0CAA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA19 TAY
    cpu.transfer("TAY");
    goto L_0CAA1A;
L_0CAA1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Au, 4u + ((((0xAA11u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAA11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA1A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAA11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAA1D;
L_0CAA1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Du, 5u, 3u, cpu.address("absx", 0x0203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA1D STA
    hw.write(cpu.address("absx", 0x203u), cpu.a, cpu.m8?8:16);
    goto L_0CAA20;
L_0CAA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u, 4u + ((((0xAA12u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAA12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA20 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAA12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAA23;
L_0CAA23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA23u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA23u, 5u, 3u, cpu.address("absx", 0x0207u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA23 STA
    hw.write(cpu.address("absx", 0x207u), cpu.a, cpu.m8?8:16);
    goto L_0CAA26;
L_0CAA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA26u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA26u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CAA26 PLY
    cpu.pop("PLY", hw);
    goto L_0CAA27;
L_0CAA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA27u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA27u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA27 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAA29;
L_0CAA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA29u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA29u, 5u, 3u, cpu.address("absx", 0x0200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA29 STA
    hw.write(cpu.address("absx", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_0CAA2C;
L_0CAA2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Cu, 5u, 3u, cpu.address("absx", 0x0204u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA2C STA
    hw.write(cpu.address("absx", 0x204u), cpu.a, cpu.m8?8:16);
    goto L_0CAA2F;
L_0CAA2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA2F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAA31;
L_0CAA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u, 5u, 3u, cpu.address("absx", 0x0201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA31 STA
    hw.write(cpu.address("absx", 0x201u), cpu.a, cpu.m8?8:16);
    goto L_0CAA34;
L_0CAA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA34u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA34 CLC
    cpu.setFlag('C', false);
    goto L_0CAA35;
L_0CAA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA35 ADC
    cpu.adc(0x10u);
    goto L_0CAA37;
L_0CAA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u, 5u, 3u, cpu.address("absx", 0x0205u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA37 STA
    hw.write(cpu.address("absx", 0x205u), cpu.a, cpu.m8?8:16);
    goto L_0CAA3A;
L_0CAA3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Au, 4u + ((((0xAA0Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAA0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA3A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAA0Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAA3D;
L_0CAA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du, 5u, 3u, cpu.address("absx", 0x0202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA3D STA
    hw.write(cpu.address("absx", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_0CAA40;
L_0CAA40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA40u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA40u, 4u + ((((0xAA0Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAA0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA40 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAA0Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAA43;
L_0CAA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA43u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA43u, 5u, 3u, cpu.address("absx", 0x0206u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA43 STA
    hw.write(cpu.address("absx", 0x206u), cpu.a, cpu.m8?8:16);
    goto L_0CAA46;
L_0CAA46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA46u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA46 TXA
    cpu.transfer("TXA");
    goto L_0CAA47;
L_0CAA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA47u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA47 LSR
    cpu.lsrA();
    goto L_0CAA48;
L_0CAA48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA48u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA48 LSR
    cpu.lsrA();
    goto L_0CAA49;
L_0CAA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA49 TAX
    cpu.transfer("TAX");
    goto L_0CAA4A;
L_0CAA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA4A LDA
    cpu.setA(0x2u, 8);
    goto L_0CAA4C;
L_0CAA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu, 5u, 3u, cpu.address("absx", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA4C STA
    hw.write(cpu.address("absx", 0x420u), cpu.a, cpu.m8?8:16);
    goto L_0CAA4F;
L_0CAA4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Fu, 5u, 3u, cpu.address("absx", 0x0421u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAA4F STA
    hw.write(cpu.address("absx", 0x421u), cpu.a, cpu.m8?8:16);
    goto L_0CAA52;
L_0CAA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA52u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA52u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CAA52 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CAA52u);return;} hw.unresolvedReturn(0x0CAA52u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0CC94E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CC94Eu: goto L_0CC94E;
    case 0x0CC951u: goto L_0CC951;
    case 0x0CC953u: goto L_0CC953;
    case 0x0CC956u: goto L_0CC956;
    case 0x0CC959u: goto L_0CC959;
    case 0x0CC95Bu: goto L_0CC95B;
    case 0x0CC95Du: goto L_0CC95D;
    case 0x0CC960u: goto L_0CC960;
    case 0x0CC961u: goto L_0CC961;
    case 0x0CC962u: goto L_0CC962;
    case 0x0CC963u: goto L_0CC963;
    case 0x0CC964u: goto L_0CC964;
    case 0x0CC966u: goto L_0CC966;
    case 0x0CC969u: goto L_0CC969;
    case 0x0CC96Bu: goto L_0CC96B;
    case 0x0CC96Cu: goto L_0CC96C;
    case 0x0CC96Du: goto L_0CC96D;
    case 0x0CC96Eu: goto L_0CC96E;
    case 0x0CC96Fu: goto L_0CC96F;
    case 0x0CC970u: goto L_0CC970;
    case 0x0CC972u: goto L_0CC972;
    case 0x0CC974u: goto L_0CC974;
    case 0x0CC975u: goto L_0CC975;
    case 0x0CC976u: goto L_0CC976;
    case 0x0CC978u: goto L_0CC978;
    case 0x0CC979u: goto L_0CC979;
    case 0x0CC97Bu: goto L_0CC97B;
    case 0x0CC97Du: goto L_0CC97D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CC94E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC94Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Eu, 4u, 3u, cpu.address("abs", 0x1443u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC94E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1443u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CC951;
L_0CC951:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC951u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC951u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC951u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC951 BEQ -> $0CC97D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CC97D; }
    goto L_0CC953;
L_0CC953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC953u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC953u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC953u, 6u, 3u, cpu.address("abs", 0x1443u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC953 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1443u), cpu.m8?8:16);
    goto L_0CC956;
L_0CC956:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC956u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC956u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC956u, 4u, 3u, cpu.address("abs", 0x1443u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC956 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1443u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CC959;
L_0CC959:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC959u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC959u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC959u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC959 AND
    cpu.logicAnd(0x1Fu);
    goto L_0CC95B;
L_0CC95B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC95Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC95B BNE -> $0CC97D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CC97D; }
    goto L_0CC95D;
L_0CC95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Du, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC95D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CC960;
L_0CC960:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC960u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC960u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC960u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC960 DEC
    cpu.decReg('A');
    goto L_0CC961;
L_0CC961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC961u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC961u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC961 ASL
    cpu.aslA();
    goto L_0CC962;
L_0CC962:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC962u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC962u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC962u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC962 ASL
    cpu.aslA();
    goto L_0CC963;
L_0CC963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC963u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC963u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC963 ASL
    cpu.aslA();
    goto L_0CC964;
L_0CC964:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC964u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC964u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC964u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC964 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0CC966;
L_0CC966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC966u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC966u, 4u, 3u, cpu.address("abs", 0x1443u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC966 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1443u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CC969;
L_0CC969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC969u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC969u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC969u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC969 AND
    cpu.logicAnd(0xE0u);
    goto L_0CC96B;
L_0CC96B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC96B LSR
    cpu.lsrA();
    goto L_0CC96C;
L_0CC96C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC96C LSR
    cpu.lsrA();
    goto L_0CC96D;
L_0CC96D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC96D LSR
    cpu.lsrA();
    goto L_0CC96E;
L_0CC96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC96E LSR
    cpu.lsrA();
    goto L_0CC96F;
L_0CC96F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC96F LSR
    cpu.lsrA();
    goto L_0CC970;
L_0CC970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC970u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC970u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC970 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_0CC972;
L_0CC972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC972u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC972u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC972u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC972 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0CC974;
L_0CC974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC974u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC974u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC974 ASL
    cpu.aslA();
    goto L_0CC975;
L_0CC975:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC975u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC975u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC975u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC975 CLC
    cpu.setFlag('C', false);
    goto L_0CC976;
L_0CC976:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC976u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC976u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC976u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC976 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_0CC978;
L_0CC978:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC978u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC978u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC978u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC978 CLC
    cpu.setFlag('C', false);
    goto L_0CC979;
L_0CC979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC979u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC979u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC979 ADC
    cpu.adc(0x21u);
    goto L_0CC97B;
L_0CC97B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC97Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CC97B STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_0CC97D;
L_0CC97D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC97Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CC97D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CC97Du);return;} hw.unresolvedReturn(0x0CC97Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB604_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB604u: goto L_0DB604;
    case 0x0DB606u: goto L_0DB606;
    case 0x0DB608u: goto L_0DB608;
    case 0x0DB60Au: goto L_0DB60A;
    case 0x0DB60Cu: goto L_0DB60C;
    case 0x0DB60Eu: goto L_0DB60E;
    case 0x0DB610u: goto L_0DB610;
    case 0x0DB613u: goto L_0DB613;
    case 0x0DB615u: goto L_0DB615;
    case 0x0DB617u: goto L_0DB617;
    case 0x0DB619u: goto L_0DB619;
    case 0x0DB61Bu: goto L_0DB61B;
    case 0x0DB61Du: goto L_0DB61D;
    case 0x0DB620u: goto L_0DB620;
    case 0x0DB624u: goto L_0DB624;
    case 0x0DB627u: goto L_0DB627;
    case 0x0DB628u: goto L_0DB628;
    case 0x0DB62Au: goto L_0DB62A;
    case 0x0DB62Cu: goto L_0DB62C;
    case 0x0DB62Eu: goto L_0DB62E;
    case 0x0DB630u: goto L_0DB630;
    case 0x0DB633u: goto L_0DB633;
    case 0x0DB637u: goto L_0DB637;
    case 0x0DB63Au: goto L_0DB63A;
    case 0x0DB63Du: goto L_0DB63D;
    case 0x0DB641u: goto L_0DB641;
    case 0x0DB644u: goto L_0DB644;
    case 0x0DB647u: goto L_0DB647;
    case 0x0DB64Bu: goto L_0DB64B;
    case 0x0DB64Eu: goto L_0DB64E;
    case 0x0DB650u: goto L_0DB650;
    case 0x0DB652u: goto L_0DB652;
    case 0x0DB653u: goto L_0DB653;
    case 0x0DB654u: goto L_0DB654;
    case 0x0DB656u: goto L_0DB656;
    case 0x0DB657u: goto L_0DB657;
    case 0x0DB65Au: goto L_0DB65A;
    case 0x0DB65Eu: goto L_0DB65E;
    case 0x0DB661u: goto L_0DB661;
    case 0x0DB664u: goto L_0DB664;
    case 0x0DB666u: goto L_0DB666;
    case 0x0DB668u: goto L_0DB668;
    case 0x0DB66Au: goto L_0DB66A;
    case 0x0DB66Cu: goto L_0DB66C;
    case 0x0DB66Eu: goto L_0DB66E;
    case 0x0DB671u: goto L_0DB671;
    case 0x0DB675u: goto L_0DB675;
    case 0x0DB678u: goto L_0DB678;
    case 0x0DB679u: goto L_0DB679;
    case 0x0DB67Bu: goto L_0DB67B;
    case 0x0DB67Du: goto L_0DB67D;
    case 0x0DB67Fu: goto L_0DB67F;
    case 0x0DB681u: goto L_0DB681;
    case 0x0DB684u: goto L_0DB684;
    case 0x0DB688u: goto L_0DB688;
    case 0x0DB68Bu: goto L_0DB68B;
    case 0x0DB68Eu: goto L_0DB68E;
    case 0x0DB692u: goto L_0DB692;
    case 0x0DB695u: goto L_0DB695;
    case 0x0DB698u: goto L_0DB698;
    case 0x0DB69Cu: goto L_0DB69C;
    case 0x0DB69Fu: goto L_0DB69F;
    case 0x0DB6A1u: goto L_0DB6A1;
    case 0x0DB6A3u: goto L_0DB6A3;
    case 0x0DB6A4u: goto L_0DB6A4;
    case 0x0DB6A5u: goto L_0DB6A5;
    case 0x0DB6A7u: goto L_0DB6A7;
    case 0x0DB6A8u: goto L_0DB6A8;
    case 0x0DB6ABu: goto L_0DB6AB;
    case 0x0DB6AFu: goto L_0DB6AF;
    case 0x0DB6B2u: goto L_0DB6B2;
    case 0x0DB6B3u: goto L_0DB6B3;
    case 0x0DB6B6u: goto L_0DB6B6;
    case 0x0DB6B9u: goto L_0DB6B9;
    case 0x0DB6BBu: goto L_0DB6BB;
    case 0x0DB6BDu: goto L_0DB6BD;
    case 0x0DB6C0u: goto L_0DB6C0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB604u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB604u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB604u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB604 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB606;
L_0DB606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB606u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB606u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB606 AND
    cpu.logicAnd(0xFu);
    goto L_0DB608;
L_0DB608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB608u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB608u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB608 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB60A;
L_0DB60A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB60A LDA
    cpu.setA(0x3u, 8);
    goto L_0DB60C;
L_0DB60C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB60C STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_0DB60E;
L_0DB60E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB60E LDX
    cpu.setX(0x0u, 8);
    goto L_0DB610;
L_0DB610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB610u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB610u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB610 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xB612u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB613u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DB610u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB613;
L_0DB613:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB613u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB613u,0x0DB613u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB613u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB613u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB613 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB615;
L_0DB615:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB615u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB615u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB615u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB615 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB617;
L_0DB617:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB617u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB617u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB617u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB617 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DB619;
L_0DB619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB619u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB619u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB619 LDA
    cpu.setA(0x2u, 8);
    goto L_0DB61B;
L_0DB61B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB61B STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DB61D;
L_0DB61D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Du, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB61D JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xB61Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB620u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DB61Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB620;
L_0DB620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB620u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB620u,0x0DB620u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB620u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB620u, 5u, 4u, ((0x0DB5E8u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB620 LDA
    cpu.loadA(hw.readW(((0xDB5E8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB624;
L_0DB624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB624 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB626u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB627u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB624u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB627;
L_0DB627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB627u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB627u,0x0DB627u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB627u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB627u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB627 INX
    cpu.inc('X');
    goto L_0DB628;
L_0DB628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB628u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB628u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB628u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB628 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DB62A;
L_0DB62A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB62A BPL -> $0DB61D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB61D; }
    goto L_0DB62C;
L_0DB62C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB62C DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DB62E;
L_0DB62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB62E BEQ -> $0DB652
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB652; }
    goto L_0DB630;
L_0DB630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB630u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB630u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB630 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xB632u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB633u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DB630u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB633;
L_0DB633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB633u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB633u,0x0DB633u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB633u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB633u, 5u, 4u, ((0x0DB5E8u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB633 LDA
    cpu.loadA(hw.readW(((0xDB5E8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB637;
L_0DB637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB637u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB637u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB637u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB637 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB639u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB63Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB637u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB63A;
L_0DB63A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB63Au,0x0DB63Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Au, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB63A JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xB63Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB63Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DB63Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB63D;
L_0DB63D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB63Du,0x0DB63Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Du, 5u, 4u, ((0x0DB5E9u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB63D LDA
    cpu.loadA(hw.readW(((0xDB5E9u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB641;
L_0DB641:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB641u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB641u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB641u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB641 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB643u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB644u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB641u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB644;
L_0DB644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB644u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB644u,0x0DB644u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB644u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB644u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB644 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xB646u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB647u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DB644u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB647;
L_0DB647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB647u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB647u,0x0DB647u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB647u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB647u, 5u, 4u, ((0x0DB5EAu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB647 LDA
    cpu.loadA(hw.readW(((0xDB5EAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB64B;
L_0DB64B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Bu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB64B JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB64Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB64Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB64Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB64E;
L_0DB64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB64Eu,0x0DB64Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Eu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB64E DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DB650;
L_0DB650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB650u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB650u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB650 BNE -> $0DB630
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB630; }
    goto L_0DB652;
L_0DB652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB652u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB652u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB652 TXA
    cpu.transfer("TXA");
    goto L_0DB653;
L_0DB653:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB653u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB653u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB653u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB653 CLC
    cpu.setFlag('C', false);
    goto L_0DB654;
L_0DB654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB654u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB654u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB654 ADC
    cpu.adc(0x3u);
    goto L_0DB656;
L_0DB656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB656u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB656u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB656u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB656 TAX
    cpu.transfer("TAX");
    goto L_0DB657;
L_0DB657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB657u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB657u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB657 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xB659u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB65Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DB657u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB65A;
L_0DB65A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB65Au,0x0DB65Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Au, 5u, 4u, ((0x0DB5E8u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB65A LDA
    cpu.loadA(hw.readW(((0xDB5E8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB65E;
L_0DB65E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Eu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB65E JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB660u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB661u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB65Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB661;
L_0DB661:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB661u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB661u,0x0DB661u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB661u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB661u, 3u, 3u, cpu.address("abs", 0xB6B2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB661 JMP -> $0DB6B2
    goto L_0DB6B2;
L_0DB664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB664u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB664u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB664u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB664 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB666;
L_0DB666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB666u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB666u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB666 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB668;
L_0DB668:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB668u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB668u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB668u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB668 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DB66A;
L_0DB66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB66A LDA
    cpu.setA(0x2u, 8);
    goto L_0DB66C;
L_0DB66C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB66C STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DB66E;
L_0DB66E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Eu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB66E JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB670u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB671u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB66Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB671;
L_0DB671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB671u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB671u,0x0DB671u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB671u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB671u, 5u, 4u, ((0x0DB5E8u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB671 LDA
    cpu.loadA(hw.readW(((0xDB5E8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB675;
L_0DB675:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB675u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB675u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB675u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB675 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB677u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB678u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB675u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB678;
L_0DB678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB678u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB678u,0x0DB678u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB678u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB678u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB678 INX
    cpu.inc('X');
    goto L_0DB679;
L_0DB679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB679u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB679u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB679 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DB67B;
L_0DB67B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB67Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB67B BPL -> $0DB66E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB66E; }
    goto L_0DB67D;
L_0DB67D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB67Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Du,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB67D DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DB67F;
L_0DB67F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB67Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB67F BEQ -> $0DB6A3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB6A3; }
    goto L_0DB681;
L_0DB681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB681u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB681u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB681 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB683u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB684u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB681u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB684;
L_0DB684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB684u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB684u,0x0DB684u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB684u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB684u, 5u, 4u, ((0x0DB5E8u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB684 LDA
    cpu.loadA(hw.readW(((0xDB5E8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB688;
L_0DB688:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB688u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB688u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB688u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB688 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB68Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB68Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB688u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB68B;
L_0DB68B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB68Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB68Bu,0x0DB68Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Bu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB68B JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB68Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB68Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB68Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB68E;
L_0DB68E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB68Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB68Eu,0x0DB68Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB68Eu, 5u, 4u, ((0x0DB5E9u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB68E LDA
    cpu.loadA(hw.readW(((0xDB5E9u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB692;
L_0DB692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB692u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB692u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB692 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB694u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB695u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB692u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB695;
L_0DB695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB695u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB695u,0x0DB695u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB695u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB695u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB695 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB697u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB698u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB695u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB698;
L_0DB698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB698u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB698u,0x0DB698u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB698u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB698u, 5u, 4u, ((0x0DB5EAu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB698 LDA
    cpu.loadA(hw.readW(((0xDB5EAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB69C;
L_0DB69C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB69Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Cu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB69C JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB69Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB69Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB69Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB69F;
L_0DB69F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB69Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB69Fu,0x0DB69Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Fu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB69Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB69F DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DB6A1;
L_0DB6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6A1 BNE -> $0DB681
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB681; }
    goto L_0DB6A3;
L_0DB6A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A3u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6A3 TXA
    cpu.transfer("TXA");
    goto L_0DB6A4;
L_0DB6A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6A4 CLC
    cpu.setFlag('C', false);
    goto L_0DB6A5;
L_0DB6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6A5 ADC
    cpu.adc(0x3u);
    goto L_0DB6A7;
L_0DB6A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6A7 TAX
    cpu.transfer("TAX");
    goto L_0DB6A8;
L_0DB6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6A8u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB6A8 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB6AAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6ABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB6A8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB6AB;
L_0DB6AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6ABu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6ABu,0x0DB6ABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ABu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ABu, 5u, 4u, ((0x0DB5E8u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6AB LDA
    cpu.loadA(hw.readW(((0xDB5E8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB6AF;
L_0DB6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB6AF JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB6B1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6B2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB6AFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB6B2;
L_0DB6B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6B2u,0x0DB6B2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6B2 INX
    cpu.inc('X');
    goto L_0DB6B3;
L_0DB6B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB6B3 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xB6B5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6B6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DB6B3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB6B6;
L_0DB6B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6B6u,0x0DB6B6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B6u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB6B6 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xB6B8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6B9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DB6B6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB6B9;
L_0DB6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6B9u,0x0DB6B9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6B9 DEC
    cpu.decMem(hw, cpu.address("dp", 0x3u), cpu.m8?8:16);
    goto L_0DB6BB;
L_0DB6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6BB BMI -> $0DB6C0
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB6C0; }
    goto L_0DB6BD;
L_0DB6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu, 3u, 3u, cpu.address("abs", 0xB664u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6BD JMP -> $0DB664
    goto L_0DB664;
L_0DB6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB6C0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB6C0u);return;} hw.unresolvedReturn(0x0DB6C0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DDAC8_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DDAC8u: goto L_0DDAC8;
    case 0x0DDACAu: goto L_0DDACA;
    case 0x0DDACCu: goto L_0DDACC;
    case 0x0DDACEu: goto L_0DDACE;
    case 0x0DDACFu: goto L_0DDACF;
    case 0x0DDAD1u: goto L_0DDAD1;
    case 0x0DDAD2u: goto L_0DDAD2;
    case 0x0DDAD3u: goto L_0DDAD3;
    case 0x0DDAD4u: goto L_0DDAD4;
    case 0x0DDAD5u: goto L_0DDAD5;
    case 0x0DDAD7u: goto L_0DDAD7;
    case 0x0DDADAu: goto L_0DDADA;
    case 0x0DDADEu: goto L_0DDADE;
    case 0x0DDAE1u: goto L_0DDAE1;
    case 0x0DDAE4u: goto L_0DDAE4;
    case 0x0DDAE8u: goto L_0DDAE8;
    case 0x0DDAEAu: goto L_0DDAEA;
    case 0x0DDAEDu: goto L_0DDAED;
    case 0x0DDAEFu: goto L_0DDAEF;
    case 0x0DDAF1u: goto L_0DDAF1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DDAC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAC8u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAC8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAC8 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DDACA;
L_0DDACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDACAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDACAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDACA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDACC;
L_0DDACC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDACCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDACCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDACCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDACC AND
    cpu.logicAnd(0xFu);
    goto L_0DDACE;
L_0DDACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDACEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDACEu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDACEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDACE TAX
    cpu.transfer("TAX");
    goto L_0DDACF;
L_0DDACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDACFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDACFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDACFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDACF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDAD1;
L_0DDAD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAD1 LSR
    cpu.lsrA();
    goto L_0DDAD2;
L_0DDAD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAD2 LSR
    cpu.lsrA();
    goto L_0DDAD3;
L_0DDAD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAD3 LSR
    cpu.lsrA();
    goto L_0DDAD4;
L_0DDAD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAD4 LSR
    cpu.lsrA();
    goto L_0DDAD5;
L_0DDAD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAD5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DDAD7;
L_0DDAD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAD7u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDAD7 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDAD9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDADAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDAD7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDADA;
L_0DDADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDADAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDADAu,0x0DDADAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDADAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDADAu, 5u, 4u, ((0x0DDAC4u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDADA LDA
    cpu.loadA(hw.readW(((0xDDAC4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDADE;
L_0DDADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDADEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDADEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDADEu, 3u, 3u, cpu.address("abs", 0xDAE8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDADE JMP -> $0DDAE8
    goto L_0DDAE8;
L_0DDAE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE1u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDAE1 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDAE3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDAE4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDAE1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDAE4;
L_0DDAE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAE4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDAE4u,0x0DDAE4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE4u, 5u, 4u, ((0x0DDAC6u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAE4 LDA
    cpu.loadA(hw.readW(((0xDDAC6u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDAE8;
L_0DDAE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE8u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DDAE8 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DDAEA;
L_0DDAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAEAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAEAu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDAEA JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xDAECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDAEDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DDAEAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDAED;
L_0DDAED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAEDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDAEDu,0x0DDAEDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAEDu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAEDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAED DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DDAEF;
L_0DDAEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAEFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAEFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAEF BPL -> $0DDAE1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DDAE1; }
    goto L_0DDAF1;
L_0DDAF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAF1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAF1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDAF1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DDAF1u);return;} hw.unresolvedReturn(0x0DDAF1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DED4A_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DED4Au: goto L_0DED4A;
    case 0x0DED4Du: goto L_0DED4D;
    case 0x0DED4Fu: goto L_0DED4F;
    case 0x0DED52u: goto L_0DED52;
    case 0x0DED55u: goto L_0DED55;
    case 0x0DED57u: goto L_0DED57;
    case 0x0DED5Au: goto L_0DED5A;
    case 0x0DED5Bu: goto L_0DED5B;
    case 0x0DED5Du: goto L_0DED5D;
    case 0x0DED60u: goto L_0DED60;
    case 0x0DED62u: goto L_0DED62;
    case 0x0DED64u: goto L_0DED64;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DED4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED4Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED4Au, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DED4A JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xED4Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xED4Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DED4Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DED4D;
L_0DED4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED4Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED4Du,0x0DED4Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED4Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED4D LDA
    cpu.setA(0xAu, 8);
    goto L_0DED4F;
L_0DED4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED4Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED4Fu, 3u, 3u, cpu.address("abs", 0xED57u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED4F JMP -> $0DED57
    goto L_0DED57;
L_0DED52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED52u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED52u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DED52 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xED54u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xED55u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DED52u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DED55;
L_0DED55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED55u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED55u,0x0DED55u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED55u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED55 LDA
    cpu.setA(0xBu, 8);
    goto L_0DED57;
L_0DED57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED57u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED57u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DED57 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xED59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xED5Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DED57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DED5A;
L_0DED5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED5Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED5Au,0x0DED5Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED5Au,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED5Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED5A DEX
    cpu.decReg('X');
    goto L_0DED5B;
L_0DED5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED5Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED5Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED5B BNE -> $0DED52
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DED52; }
    goto L_0DED5D;
L_0DED5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED5Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED5Du, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DED5D JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xED5Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xED60u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DED5Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DED60;
L_0DED60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED60u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED60u,0x0DED60u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED60u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED60 LDA
    cpu.setA(0xCu, 8);
    goto L_0DED62;
L_0DED62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED62u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED62u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DED62 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DED64;
L_0DED64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED64u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED64u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DED64 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DED64u);return;} hw.unresolvedReturn(0x0DED64u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B19211_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB19210u: goto L_B19210;
    case 0xB19211u: goto L_B19211;
    case 0xB19214u: goto L_B19214;
    case 0xB19216u: goto L_B19216;
    case 0xB19218u: goto L_B19218;
    case 0xB1921Au: goto L_B1921A;
    case 0xB1921Cu: goto L_B1921C;
    case 0xB1921Fu: goto L_B1921F;
    case 0xB19221u: goto L_B19221;
    case 0xB19224u: goto L_B19224;
    case 0xB19226u: goto L_B19226;
    case 0xB19228u: goto L_B19228;
    case 0xB1922Cu: goto L_B1922C;
    case 0xB1922Fu: goto L_B1922F;
    case 0xB19231u: goto L_B19231;
    case 0xB19233u: goto L_B19233;
    case 0xB19236u: goto L_B19236;
    case 0xB19238u: goto L_B19238;
    case 0xB1923Au: goto L_B1923A;
    case 0xB1923Bu: goto L_B1923B;
    case 0xB1923Eu: goto L_B1923E;
    case 0xB19240u: goto L_B19240;
    case 0xB19242u: goto L_B19242;
    case 0xB19244u: goto L_B19244;
    case 0xB19245u: goto L_B19245;
    case 0xB19247u: goto L_B19247;
    case 0xB19249u: goto L_B19249;
    case 0xB1924Bu: goto L_B1924B;
    case 0xB1924Eu: goto L_B1924E;
    case 0xB19250u: goto L_B19250;
    case 0xB19252u: goto L_B19252;
    case 0xB19255u: goto L_B19255;
    case 0xB19256u: goto L_B19256;
    case 0xB19258u: goto L_B19258;
    case 0xB1925Bu: goto L_B1925B;
    case 0xB1925Eu: goto L_B1925E;
    case 0xB19260u: goto L_B19260;
    case 0xB19263u: goto L_B19263;
    case 0xB19265u: goto L_B19265;
    case 0xB19268u: goto L_B19268;
    case 0xB1926Au: goto L_B1926A;
    case 0xB1926Du: goto L_B1926D;
    case 0xB1926Fu: goto L_B1926F;
    case 0xB19272u: goto L_B19272;
    case 0xB19275u: goto L_B19275;
    case 0xB19277u: goto L_B19277;
    case 0xB19279u: goto L_B19279;
    case 0xB1927Cu: goto L_B1927C;
    case 0xB1927Eu: goto L_B1927E;
    case 0xB19280u: goto L_B19280;
    case 0xB19283u: goto L_B19283;
    case 0xB19288u: goto L_B19288;
    case 0xB1928Au: goto L_B1928A;
    case 0xB1928Cu: goto L_B1928C;
    case 0xB1928Du: goto L_B1928D;
    case 0xB1928Eu: goto L_B1928E;
    case 0xB19290u: goto L_B19290;
    case 0xB19291u: goto L_B19291;
    case 0xB19294u: goto L_B19294;
    case 0xB19297u: goto L_B19297;
    case 0xB19299u: goto L_B19299;
    case 0xB1929Cu: goto L_B1929C;
    case 0xB1929Eu: goto L_B1929E;
    case 0xB192A0u: goto L_B192A0;
    case 0xB192A2u: goto L_B192A2;
    case 0xB192A4u: goto L_B192A4;
    case 0xB192A7u: goto L_B192A7;
    case 0xB192AAu: goto L_B192AA;
    case 0xB192ADu: goto L_B192AD;
    case 0xB192B0u: goto L_B192B0;
    case 0xB192B2u: goto L_B192B2;
    case 0xB192B5u: goto L_B192B5;
    case 0xB192B7u: goto L_B192B7;
    case 0xB192BAu: goto L_B192BA;
    case 0xB192BDu: goto L_B192BD;
    case 0xB192C0u: goto L_B192C0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B19210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9210u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19210 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB19210u);return;} hw.unresolvedReturn(0xB19210u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19210 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB19210u);return;} hw.unresolvedReturn(0xB19210u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9210u,0xB19210u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B19211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9211u, 4u, 3u, cpu.address("abs", 0x190Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19211 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x190Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19214;
L_B19214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19214 BEQ -> $B1925B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1925B; }
    goto L_B19216;
L_B19216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9216u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19216 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19218;
L_B19218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9218u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9218u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19218 BNE -> $B19258
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B19258; }
    goto L_B1921A;
L_B1921A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1921A LDY
    cpu.setY(0x3Cu, 8);
    goto L_B1921C;
L_B1921C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Cu, 6u, 3u, cpu.address("abs", 0x944Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1921C JSR -> $B1944D stack real
    { cpu.push16Value(hw,0x921Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x921Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x944Du), 0xB1921Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1921F;
L_B1921F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x921Fu,0xB1921Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1921F BEQ -> $B19233
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B19233; }
    goto L_B19221;
L_B19221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19221 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19224;
L_B19224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9224u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9224u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19224 CMP
    cpu.compareA(0x6Eu);
    goto L_B19226;
L_B19226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19226 BCC -> $B1925B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1925B; }
    goto L_B19228;
L_B19228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u, 8u, 4u, 0x00F04Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B19228 JSL -> $00F04D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x922Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x922Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F04Du, 0xB19228u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1922C;
L_B1922C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Cu, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1922C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1922F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Cu, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1922C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1922F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x922Cu,0xB1922Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1922F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1922F BCC -> $B1925B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1925B; }
    goto L_B19231;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1922F BCC -> $B1925B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1925B; }
    goto L_B19231;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x922Fu,0xB1922Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B19231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9231u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9231u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9231u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19231 BCS -> $B1923A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1923A; }
    goto L_B19233;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9231u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9231u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19231 BCS -> $B1923A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1923A; }
    goto L_B19233;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9231u,0xB19231u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B19233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9233u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9233u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9233u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19233 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19236;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9233u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9233u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19233 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19236;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9233u,0xB19233u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B19236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9236u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9236u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9236u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19236 CMP
    cpu.compareA(0x6u);
    goto L_B19238;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9236u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9236u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19236 CMP
    cpu.compareA(0x6u);
    goto L_B19238;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9236u,0xB19236u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B19238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9238u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9238u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19238 BCS -> $B1925B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1925B; }
    goto L_B1923A;
L_B1923A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1923A TAY
    cpu.transfer("TAY");
    goto L_B1923B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1923A TAY
    cpu.transfer("TAY");
    goto L_B1923B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x923Au,0xB1923Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1923B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu, 4u + ((((0x164Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1923B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x164Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1923E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu, 4u + ((((0x164Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1923B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x164Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1923E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x923Bu,0xB1923Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1923E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Eu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1923E ORA
    cpu.logicOr(0x1u);
    goto L_B19240;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Eu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1923E ORA
    cpu.logicOr(0x1u);
    goto L_B19240;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x923Eu,0xB1923Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B19240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9240u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9240u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9240u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19240 CPY
    cpu.compareY(0x4u);
    goto L_B19242;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9240u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9240u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19240 CPY
    cpu.compareY(0x4u);
    goto L_B19242;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9240u,0xB19240u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B19242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9242u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9242u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19242 BNE -> $B19258
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B19258; }
    goto L_B19244;
L_B19244:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9244u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9244u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9244u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B19244 PHA
    cpu.push("PHA", hw);
    goto L_B19245;
L_B19245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9245u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9245u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9245u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19245 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19247;
L_B19247:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9247u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19247 CMP
    cpu.compareA(0x35u);
    goto L_B19249;
L_B19249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9249u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9249u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19249 BEQ -> $B19252
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B19252; }
    goto L_B1924B;
L_B1924B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Bu, 4u + ((((0x167Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x167Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1924B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x167Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1924E;
L_B1924E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1924E AND
    cpu.logicAnd(0x2u);
    goto L_B19250;
L_B19250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19250 BNE -> $B19255
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B19255; }
    goto L_B19252;
L_B19252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9252u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9252u, 6u, 3u, cpu.address("abs", 0x9330u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19252 JSR -> $B19330 stack real
    { cpu.push16Value(hw,0x9254u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9255u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9330u), 0xB19252u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19255;
L_B19255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9255u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9255u,0xB19255u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9255u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9255u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B19255 PLA
    cpu.pop("PLA", hw);
    goto L_B19256;
L_B19256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9256u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9256u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19256 ORA
    cpu.logicOr(0x80u);
    goto L_B19258;
L_B19258:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9258u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9258u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9258u, 5u, 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19258 STA
    hw.write(cpu.address("absx", 0x164Au), cpu.a, cpu.m8?8:16);
    goto L_B1925B;
L_B1925B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Bu, 4u + ((((0x1686u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1925B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1686u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1925E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Bu, 4u + ((((0x1686u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1925B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1686u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1925E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x925Bu,0xB1925Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1925E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1925E BMI -> $B19210
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_B19210; }
    goto L_B19260;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1925E BMI -> $B19210
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_B19210; }
    goto L_B19260;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x925Eu,0xB1925Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B19260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9260u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9260u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9260u, 4u, 3u, cpu.address("abs", 0x185Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19260 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x185Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19263;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9260u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9260u, 4u, 3u, cpu.address("abs", 0x185Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19260 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x185Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19263;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9260u,0xB19260u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B19263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9263u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9263u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9263u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19263 BEQ -> $B1926F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1926F; }
    goto L_B19265;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9263u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9263u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19263 BEQ -> $B1926F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1926F; }
    goto L_B19265;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9263u,0xB19263u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B19265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9265u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u, 4u, 3u, cpu.address("abs", 0x190Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19265 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x190Eu), cpu.m8?8:16), false);
    goto L_B19268;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u, 4u, 3u, cpu.address("abs", 0x190Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19265 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x190Eu), cpu.m8?8:16), false);
    goto L_B19268;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9265u,0xB19265u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B19268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9268u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19268 BVS -> $B192C0
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_B192C0; }
    goto L_B1926A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19268 BVS -> $B192C0
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_B192C0; }
    goto L_B1926A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9268u,0xB19268u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1926A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au, 4u + ((((0x166Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x166Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1926A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x166Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1926D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au, 4u + ((((0x166Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x166Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1926A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x166Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1926D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x926Au,0xB1926Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1926D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1926D BMI -> $B192C0
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_B192C0; }
    goto L_B1926F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1926D BMI -> $B192C0
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_B192C0; }
    goto L_B1926F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x926Du,0xB1926Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1926F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Fu, 6u, 3u, cpu.address("abs", 0x92C9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1926F JSR -> $B192C9 stack real
    { cpu.push16Value(hw,0x9271u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9272u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x92C9u), 0xB1926Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19272;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Fu, 6u, 3u, cpu.address("abs", 0x92C9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1926F JSR -> $B192C9 stack real
    { cpu.push16Value(hw,0x9271u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9272u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x92C9u), 0xB1926Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19272;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x926Fu,0xB1926Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B19272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9272u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9272u,0xB19272u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9272u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9272u, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19272 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19275;
L_B19275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9275u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9275u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19275 BPL -> $B19288
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_B19288; }
    goto L_B19277;
L_B19277:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9277u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9277u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9277u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19277 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19279;
L_B19279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9279u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9279u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19279 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15ACu), cpu.m8?8:16));
    goto L_B1927C;
L_B1927C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1927C BNE -> $B19288
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B19288; }
    goto L_B1927E;
L_B1927E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1927E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19280;
L_B19280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u, 6u, 3u, cpu.address("abs", 0x928Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19280 JSR -> $B1928E stack real
    { cpu.push16Value(hw,0x9282u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9283u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x928Eu), 0xB19280u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19283;
L_B19283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9283u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9283u,0xB19283u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9283u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9283u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19283 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB19283u);return;} hw.unresolvedReturn(0xB19283u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B19288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9288u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9288u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9288u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19288 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1928A;
L_B1928A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1928A BEQ -> $B192C0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B192C0; }
    goto L_B1928C;
L_B1928C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1928C ASL
    cpu.aslA();
    goto L_B1928D;
L_B1928D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Du,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1928D ROL
    cpu.rolA();
    goto L_B1928E;
L_B1928E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1928E AND
    cpu.logicAnd(0x1u);
    goto L_B19290;
L_B19290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9290u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9290u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19290 TAY
    cpu.transfer("TAY");
    goto L_B19291;
L_B19291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9291u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9291u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9291u, 6u, 3u, cpu.address("abs", 0x9441u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19291 JSR -> $B19441 stack real
    { cpu.push16Value(hw,0x9293u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9294u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9441u), 0xB19291u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19294;
L_B19294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9294u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9294u,0xB19294u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9294u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9294u, 4u, 3u, cpu.address("abs", 0x1862u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19294 STA
    hw.write(cpu.address("abs", 0x1862u), cpu.a, cpu.m8?8:16);
    goto L_B19297;
L_B19297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9297u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9297u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19297 BEQ -> $B192BA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B192BA; }
    goto L_B19299;
L_B19299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19299 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1929C;
L_B1929C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1929C CMP
    cpu.compareA(0x11u);
    goto L_B1929E;
L_B1929E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1929E BCC -> $B192BA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B192BA; }
    goto L_B192A0;
L_B192A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192A0 CMP
    cpu.compareA(0x6Eu);
    goto L_B192A2;
L_B192A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192A2 BCS -> $B192BA
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B192BA; }
    goto L_B192A4;
L_B192A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A4u, 6u, 3u, cpu.address("abs", 0x9425u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B192A4 JSR -> $B19425 stack real
    { cpu.push16Value(hw,0x92A6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x92A7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9425u), 0xB192A4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B192A7;
L_B192A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92A7u,0xB192A7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A7u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192A7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B192AA;
L_B192AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92AAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92AAu, 4u, 3u, cpu.address("abs", 0x18A7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192AA STA
    hw.write(cpu.address("abs", 0x18A7u), cpu.a, cpu.m8?8:16);
    goto L_B192AD;
L_B192AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ADu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ADu, 4u, 3u, cpu.address("abs", 0x185Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192AD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x185Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B192B0;
L_B192B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192B0 BEQ -> $B192BA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B192BA; }
    goto L_B192B2;
L_B192B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B2u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192B2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B192B5;
L_B192B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B5u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192B5 ORA
    cpu.logicOr(0x40u);
    goto L_B192B7;
L_B192B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B7u, 5u, 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192B7 STA
    hw.write(cpu.address("absx", 0x1588u), cpu.a, cpu.m8?8:16);
    goto L_B192BA;
L_B192BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BAu, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192BA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B192BD;
L_B192BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BDu, 4u, 3u, cpu.address("abs", 0x1860u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B192BD STA
    hw.write(cpu.address("abs", 0x1860u), cpu.a, cpu.m8?8:16);
    goto L_B192C0;
L_B192C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B192C0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB192C0u);return;} hw.unresolvedReturn(0xB192C0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B192C0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB192C0u);return;} hw.unresolvedReturn(0xB192C0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92C0u,0xB192C0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_B19F0D_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB19F0Du: goto L_B19F0D;
    case 0xB19F0Fu: goto L_B19F0F;
    case 0xB19F12u: goto L_B19F12;
    case 0xB19F15u: goto L_B19F15;
    case 0xB19F17u: goto L_B19F17;
    case 0xB19F19u: goto L_B19F19;
    case 0xB19F1Cu: goto L_B19F1C;
    case 0xB19F1Du: goto L_B19F1D;
    case 0xB19F20u: goto L_B19F20;
    case 0xB19F23u: goto L_B19F23;
    case 0xB19F24u: goto L_B19F24;
    case 0xB19F27u: goto L_B19F27;
    case 0xB19F2Au: goto L_B19F2A;
    case 0xB19F2Du: goto L_B19F2D;
    case 0xB19F2Fu: goto L_B19F2F;
    case 0xB19F32u: goto L_B19F32;
    case 0xB19F34u: goto L_B19F34;
    case 0xB19F37u: goto L_B19F37;
    case 0xB19F3Au: goto L_B19F3A;
    case 0xB19F3Bu: goto L_B19F3B;
    case 0xB19F3Du: goto L_B19F3D;
    case 0xB19F40u: goto L_B19F40;
    case 0xB19F42u: goto L_B19F42;
    case 0xB19F44u: goto L_B19F44;
    case 0xB19F46u: goto L_B19F46;
    case 0xB19F48u: goto L_B19F48;
    case 0xB19F4Bu: goto L_B19F4B;
    case 0xB19F4Cu: goto L_B19F4C;
    case 0xB19F4Du: goto L_B19F4D;
    case 0xB19F4Eu: goto L_B19F4E;
    case 0xB19F4Fu: goto L_B19F4F;
    case 0xB19F51u: goto L_B19F51;
    case 0xB19F54u: goto L_B19F54;
    case 0xB19F57u: goto L_B19F57;
    case 0xB19F5Au: goto L_B19F5A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B19F0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F0D STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_B19F0F;
L_B19F0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Fu, 6u, 3u, cpu.address("abs", 0xA365u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19F0F JSR -> $B1A365 stack real
    { cpu.push16Value(hw,0x9F11u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F12u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA365u), 0xB19F0Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19F12;
L_B19F12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F12u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F12u,0xB19F12u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F12u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F12u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F12 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F15;
L_B19F15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F15 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_B19F17;
L_B19F17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F17u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F17 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B19F19;
L_B19F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F19 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F1C;
L_B19F1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F1C CLC
    cpu.setFlag('C', false);
    goto L_B19F1D;
L_B19F1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Du,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Du, 4u + ((((0x9C7Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9C7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F1D ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x9C7Fu), cpu.m8?8:16));
    goto L_B19F20;
L_B19F20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F20u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F20u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F20 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B19F23;
L_B19F23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F23u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F23 TAX
    cpu.transfer("TAX");
    goto L_B19F24;
L_B19F24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u, 4u + ((((0x9B83u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9B83u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F24 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9B83u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F27;
L_B19F27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F27u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F27u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F27 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_B19F2A;
L_B19F2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Au, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F2A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B19F2D;
L_B19F2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F2F;
L_B19F2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Fu, 5u, 3u, cpu.address("absy", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F2F STA
    hw.write(cpu.address("absy", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_B19F32;
L_B19F32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F32u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F32u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F32 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F34;
L_B19F34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F34 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_B19F37;
L_B19F37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F37u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F37u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F37 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F3A;
L_B19F3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F3A LSR
    cpu.lsrA();
    goto L_B19F3B;
L_B19F3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F3B LDA
    cpu.setA(0x0u, 8);
    goto L_B19F3D;
L_B19F3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Du,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Du, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F3D ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16));
    goto L_B19F40;
L_B19F40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F40u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F40 BCS -> $B19F44
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B19F44; }
    goto L_B19F42;
L_B19F42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F42u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F42 EOR
    cpu.logicXor(0x40u);
    goto L_B19F44;
L_B19F44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F44u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F44u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F44 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_B19F46;
L_B19F46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F46 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16));
    goto L_B19F48;
L_B19F48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F48u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F48u, 5u, 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F48 STA
    hw.write(cpu.address("absy", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_B19F4B;
L_B19F4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4B TYA
    cpu.transfer("TYA");
    goto L_B19F4C;
L_B19F4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4C LSR
    cpu.lsrA();
    goto L_B19F4D;
L_B19F4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4D LSR
    cpu.lsrA();
    goto L_B19F4E;
L_B19F4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4E TAY
    cpu.transfer("TAY");
    goto L_B19F4F;
L_B19F4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4F LDA
    cpu.setA(0x2u, 8);
    goto L_B19F51;
L_B19F51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F51u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F51u, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F51 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16));
    goto L_B19F54;
L_B19F54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F54u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F54u, 5u, 3u, cpu.address("absy", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F54 STA
    hw.write(cpu.address("absy", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_B19F57;
L_B19F57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F57u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F57u, 6u, 3u, cpu.address("abs", 0xA3DFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19F57 JSR -> $B1A3DF stack real
    { cpu.push16Value(hw,0x9F59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F5Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA3DFu), 0xB19F57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19F5A;
L_B19F5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F5Au,0xB19F5Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19F5A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB19F5Au);return;} hw.unresolvedReturn(0xB19F5Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B19F0D_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB19F0Du: goto L_B19F0D;
    case 0xB19F0Fu: goto L_B19F0F;
    case 0xB19F12u: goto L_B19F12;
    case 0xB19F15u: goto L_B19F15;
    case 0xB19F17u: goto L_B19F17;
    case 0xB19F19u: goto L_B19F19;
    case 0xB19F1Cu: goto L_B19F1C;
    case 0xB19F1Du: goto L_B19F1D;
    case 0xB19F20u: goto L_B19F20;
    case 0xB19F23u: goto L_B19F23;
    case 0xB19F24u: goto L_B19F24;
    case 0xB19F27u: goto L_B19F27;
    case 0xB19F2Au: goto L_B19F2A;
    case 0xB19F2Du: goto L_B19F2D;
    case 0xB19F2Fu: goto L_B19F2F;
    case 0xB19F32u: goto L_B19F32;
    case 0xB19F34u: goto L_B19F34;
    case 0xB19F37u: goto L_B19F37;
    case 0xB19F3Au: goto L_B19F3A;
    case 0xB19F3Bu: goto L_B19F3B;
    case 0xB19F3Du: goto L_B19F3D;
    case 0xB19F40u: goto L_B19F40;
    case 0xB19F42u: goto L_B19F42;
    case 0xB19F44u: goto L_B19F44;
    case 0xB19F46u: goto L_B19F46;
    case 0xB19F48u: goto L_B19F48;
    case 0xB19F4Bu: goto L_B19F4B;
    case 0xB19F4Cu: goto L_B19F4C;
    case 0xB19F4Du: goto L_B19F4D;
    case 0xB19F4Eu: goto L_B19F4E;
    case 0xB19F4Fu: goto L_B19F4F;
    case 0xB19F51u: goto L_B19F51;
    case 0xB19F54u: goto L_B19F54;
    case 0xB19F57u: goto L_B19F57;
    case 0xB19F5Au: goto L_B19F5A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B19F0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F0D STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_B19F0F;
L_B19F0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Fu, 6u, 3u, cpu.address("abs", 0xA365u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19F0F JSR -> $B1A365 stack real
    { cpu.push16Value(hw,0x9F11u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F12u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA365u), 0xB19F0Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19F12;
L_B19F12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F12u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F12u,0xB19F12u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F12u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F12u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F12 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F15;
L_B19F15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F15 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_B19F17;
L_B19F17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F17u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F17 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B19F19;
L_B19F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F19 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F1C;
L_B19F1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F1C CLC
    cpu.setFlag('C', false);
    goto L_B19F1D;
L_B19F1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Du,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Du, 4u + ((((0x9C7Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9C7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F1D ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x9C7Fu), cpu.m8?8:16));
    goto L_B19F20;
L_B19F20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F20u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F20u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F20 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B19F23;
L_B19F23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F23u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F23 TAX
    cpu.transfer("TAX");
    goto L_B19F24;
L_B19F24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u, 4u + ((((0x9B83u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9B83u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F24 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9B83u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F27;
L_B19F27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F27u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F27u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F27 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_B19F2A;
L_B19F2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Au, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F2A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B19F2D;
L_B19F2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F2F;
L_B19F2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Fu, 5u, 3u, cpu.address("absy", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F2F STA
    hw.write(cpu.address("absy", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_B19F32;
L_B19F32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F32u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F32u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F32 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F34;
L_B19F34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F34 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_B19F37;
L_B19F37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F37u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F37u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F37 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F3A;
L_B19F3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F3A LSR
    cpu.lsrA();
    goto L_B19F3B;
L_B19F3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F3B LDA
    cpu.setA(0x0u, 8);
    goto L_B19F3D;
L_B19F3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Du,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Du, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F3D ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16));
    goto L_B19F40;
L_B19F40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F40u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F40 BCS -> $B19F44
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B19F44; }
    goto L_B19F42;
L_B19F42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F42u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F42 EOR
    cpu.logicXor(0x40u);
    goto L_B19F44;
L_B19F44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F44u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F44u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F44 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_B19F46;
L_B19F46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F46 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16));
    goto L_B19F48;
L_B19F48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F48u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F48u, 5u, 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F48 STA
    hw.write(cpu.address("absy", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_B19F4B;
L_B19F4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4B TYA
    cpu.transfer("TYA");
    goto L_B19F4C;
L_B19F4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4C LSR
    cpu.lsrA();
    goto L_B19F4D;
L_B19F4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4D LSR
    cpu.lsrA();
    goto L_B19F4E;
L_B19F4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4E TAY
    cpu.transfer("TAY");
    goto L_B19F4F;
L_B19F4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4F LDA
    cpu.setA(0x2u, 8);
    goto L_B19F51;
L_B19F51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F51u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F51u, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F51 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16));
    goto L_B19F54;
L_B19F54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F54u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F54u, 5u, 3u, cpu.address("absy", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F54 STA
    hw.write(cpu.address("absy", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_B19F57;
L_B19F57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F57u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F57u, 6u, 3u, cpu.address("abs", 0xA3DFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19F57 JSR -> $B1A3DF stack real
    { cpu.push16Value(hw,0x9F59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F5Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA3DFu), 0xB19F57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19F5A;
L_B19F5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F5Au,0xB19F5Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19F5A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB19F5Au);return;} hw.unresolvedReturn(0xB19F5Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B19F0D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB19F0Du: goto L_B19F0D;
    case 0xB19F0Fu: goto L_B19F0F;
    case 0xB19F12u: goto L_B19F12;
    case 0xB19F15u: goto L_B19F15;
    case 0xB19F17u: goto L_B19F17;
    case 0xB19F19u: goto L_B19F19;
    case 0xB19F1Cu: goto L_B19F1C;
    case 0xB19F1Du: goto L_B19F1D;
    case 0xB19F20u: goto L_B19F20;
    case 0xB19F23u: goto L_B19F23;
    case 0xB19F24u: goto L_B19F24;
    case 0xB19F27u: goto L_B19F27;
    case 0xB19F2Au: goto L_B19F2A;
    case 0xB19F2Du: goto L_B19F2D;
    case 0xB19F2Fu: goto L_B19F2F;
    case 0xB19F32u: goto L_B19F32;
    case 0xB19F34u: goto L_B19F34;
    case 0xB19F37u: goto L_B19F37;
    case 0xB19F3Au: goto L_B19F3A;
    case 0xB19F3Bu: goto L_B19F3B;
    case 0xB19F3Du: goto L_B19F3D;
    case 0xB19F40u: goto L_B19F40;
    case 0xB19F42u: goto L_B19F42;
    case 0xB19F44u: goto L_B19F44;
    case 0xB19F46u: goto L_B19F46;
    case 0xB19F48u: goto L_B19F48;
    case 0xB19F4Bu: goto L_B19F4B;
    case 0xB19F4Cu: goto L_B19F4C;
    case 0xB19F4Du: goto L_B19F4D;
    case 0xB19F4Eu: goto L_B19F4E;
    case 0xB19F4Fu: goto L_B19F4F;
    case 0xB19F51u: goto L_B19F51;
    case 0xB19F54u: goto L_B19F54;
    case 0xB19F57u: goto L_B19F57;
    case 0xB19F5Au: goto L_B19F5A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B19F0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F0D STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_B19F0F;
L_B19F0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Fu, 6u, 3u, cpu.address("abs", 0xA365u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19F0F JSR -> $B1A365 stack real
    { cpu.push16Value(hw,0x9F11u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F12u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA365u), 0xB19F0Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19F12;
L_B19F12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F12u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F12u,0xB19F12u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F12u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F12u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F12 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F15;
L_B19F15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F15 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_B19F17;
L_B19F17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F17u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F17 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B19F19;
L_B19F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F19 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F1C;
L_B19F1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F1C CLC
    cpu.setFlag('C', false);
    goto L_B19F1D;
L_B19F1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Du,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Du, 4u + ((((0x9C7Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9C7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F1D ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x9C7Fu), cpu.m8?8:16));
    goto L_B19F20;
L_B19F20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F20u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F20u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F20 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B19F23;
L_B19F23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F23u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F23 TAX
    cpu.transfer("TAX");
    goto L_B19F24;
L_B19F24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u, 4u + ((((0x9B83u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9B83u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F24 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9B83u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F27;
L_B19F27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F27u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F27u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F27 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_B19F2A;
L_B19F2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Au, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F2A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B19F2D;
L_B19F2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F2F;
L_B19F2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Fu, 5u, 3u, cpu.address("absy", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F2F STA
    hw.write(cpu.address("absy", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_B19F32;
L_B19F32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F32u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F32u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F32 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F34;
L_B19F34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F34 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_B19F37;
L_B19F37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F37u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F37u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F37 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19F3A;
L_B19F3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F3A LSR
    cpu.lsrA();
    goto L_B19F3B;
L_B19F3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F3B LDA
    cpu.setA(0x0u, 8);
    goto L_B19F3D;
L_B19F3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Du,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Du, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F3D ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16));
    goto L_B19F40;
L_B19F40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F40u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F40 BCS -> $B19F44
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B19F44; }
    goto L_B19F42;
L_B19F42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F42u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F42 EOR
    cpu.logicXor(0x40u);
    goto L_B19F44;
L_B19F44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F44u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F44u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F44 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_B19F46;
L_B19F46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F46 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16));
    goto L_B19F48;
L_B19F48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F48u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F48u, 5u, 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F48 STA
    hw.write(cpu.address("absy", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_B19F4B;
L_B19F4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4B TYA
    cpu.transfer("TYA");
    goto L_B19F4C;
L_B19F4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4C LSR
    cpu.lsrA();
    goto L_B19F4D;
L_B19F4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4D LSR
    cpu.lsrA();
    goto L_B19F4E;
L_B19F4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4E TAY
    cpu.transfer("TAY");
    goto L_B19F4F;
L_B19F4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F4F LDA
    cpu.setA(0x2u, 8);
    goto L_B19F51;
L_B19F51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F51u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F51u, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F51 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16));
    goto L_B19F54;
L_B19F54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F54u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F54u, 5u, 3u, cpu.address("absy", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19F54 STA
    hw.write(cpu.address("absy", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_B19F57;
L_B19F57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F57u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F57u, 6u, 3u, cpu.address("abs", 0xA3DFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19F57 JSR -> $B1A3DF stack real
    { cpu.push16Value(hw,0x9F59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F5Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA3DFu), 0xB19F57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19F5A;
L_B19F5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F5Au,0xB19F5Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19F5A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB19F5Au);return;} hw.unresolvedReturn(0xB19F5Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A7C9_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A7C9u: goto L_B1A7C9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C9u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C9u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $B1A7C9 BRK
    hw.partial(0xB1A7C9u, "BRK"); return;
}

