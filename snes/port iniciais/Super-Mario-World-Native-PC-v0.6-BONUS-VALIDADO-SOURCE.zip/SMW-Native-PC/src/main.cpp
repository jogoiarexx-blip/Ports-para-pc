#include "generated.hpp"
#include <iostream>
#include <fstream>
#include <cstdlib>
#ifdef FORJA65_NATIVE_SPC_LINKED
void forja65_native_spc_tick(ApuBridge&,unsigned);
#endif
static void forja65Fatal(const char*msg){std::ofstream f("forja65-last-error.txt",std::ios::trunc);if(f)f<<msg<<'\n';std::cerr<<msg<<'\n';
#ifdef _WIN32
MessageBoxA(nullptr,msg,"Forja65 - erro ao executar o port",MB_OK|MB_ICONERROR);
#endif
}
int main(){CpuState cpu;try{SnesRuntime hw("assets/cart-data.bin",MapperKind::LoROM,2048u,9u,1u,CartChip::None,"save.srm",1u);
#ifdef FORJA65_NATIVE_SPC_LINKED
hw.apu.setNativeStepHook(&forja65_native_spc_tick);
#endif
forja65_register_native_hooks(hw);
if(hw.cartHashHex()!="4d7bc08f726d10cb")throw std::runtime_error("ROM/native pack fingerprint mismatch: "+hw.cartHashHex()+" expected 4d7bc08f726d10cb");
hw.beginFrame();try{forja65_dispatch(cpu,hw,0x008000u,0xFFFFFFu);}catch(const std::exception&e){if(std::string(e.what())!="FORJA65_HEADLESS_COMPLETE"){
  hw.writeBootProbe(); hw.writeNativeDependencyReport();
  std::ofstream state("forja65-cpu-failure.txt",std::ios::trunc);
  if(state)state<<std::hex<<"cpu_pb=0x"<<unsigned(cpu.pb)<<"\ncpu_a=0x"<<cpu.a<<"\ncpu_x=0x"<<cpu.x<<"\ncpu_y=0x"<<cpu.y<<"\ncpu_s=0x"<<cpu.s<<"\nlast_cpu_pc=0x"<<hw.lastInstructionPc<<"\n"<<std::dec<<"frames="<<hw.frameCounter<<"\ninstructions="<<hw.cpuInstructionCount<<"\n";
  throw;
}hw.stopped=true;}unsigned lim=0;if(const char*e=std::getenv("FORJA65_HEADLESS_FRAMES"))lim=(unsigned)std::strtoul(e,nullptr,10);while(!hw.stopped){try{forja65_wait(cpu,hw,hw.lastInstructionPc);if(hw.dispatchPending)forja65_dispatch(cpu,hw,hw.dispatchTarget,hw.dispatchFrom);hw.maybeCaptureNativeScene();if(lim&&hw.frameCounter>=lim)hw.stopped=true;}catch(const std::exception&e){if(std::string(e.what())!="FORJA65_HEADLESS_COMPLETE"){
  hw.writeBootProbe(); hw.writeNativeDependencyReport();
  std::ofstream state("forja65-cpu-failure.txt",std::ios::trunc);
  if(state)state<<std::hex<<"cpu_pb=0x"<<unsigned(cpu.pb)<<"\ncpu_a=0x"<<cpu.a<<"\ncpu_x=0x"<<cpu.x<<"\ncpu_y=0x"<<cpu.y<<"\ncpu_s=0x"<<cpu.s<<"\nlast_cpu_pc=0x"<<hw.lastInstructionPc<<"\n"<<std::dec<<"frames="<<hw.frameCounter<<"\ninstructions="<<hw.cpuInstructionCount<<"\n";
  throw;
}hw.stopped=true;}}hw.writeNativeDependencyReport();hw.writePpuRegisterProfile();hw.writeBootProbe();std::ofstream qa("forja65-qa-status.txt",std::ios::trunc);if(qa)qa<<"FORJA65_QA 1\nrom="<<hw.cartHashHex()<<"\nruntime_started=PASS\nframes="<<hw.frameCounter<<"\ninstructions="<<hw.cpuInstructionCount<<"\nnmi_services="<<hw.nmiServiceCount<<"\nirq_services="<<hw.irqServiceCount<<"\nppu_forced_blank="<<((hw.ppu.regs[0]&0x80u)?1:0)<<"\nframebuffer_hash="<<std::hex<<hw.framebufferHash()<<"\nwram_hash="<<hw.ramHash()<<std::dec<<"\nnew_oracle_hints="<<(std::filesystem::exists("forja65-oracle-hints.txt")?"YES":"NO")<<"\nppu_virtual_accesses="<<(hw.hwUsage.ppuReads+hw.hwUsage.ppuWrites)<<"\nppu_accesses="<<(hw.hwUsage.ppuReads+hw.hwUsage.ppuWrites)<<"\nppu_native_accesses="<<(hw.hwUsage.ppuNativeReads+hw.hwUsage.ppuNativeWrites)<<"\nppu_fallback_accesses="<<(hw.hwUsage.ppuFallbackReads+hw.hwUsage.ppuFallbackWrites)<<"\napu_virtual_accesses="<<(hw.hwUsage.apuReads+hw.hwUsage.apuWrites)<<"\napu_accesses="<<(hw.hwUsage.apuReads+hw.hwUsage.apuWrites)<<"\napu_native_master_cycles="<<hw.apu.nativeMasterCycles<<"\napu_fallback_master_cycles="<<hw.apu.fallbackMasterCycles<<"\ndsp_native_samples="<<hw.apu.dspNativeSamples<<"\ndsp_fallback_samples="<<hw.apu.dspFallbackSamples<<"\nrom_runtime_reads="<<hw.hwUsage.romReads<<"\nrom_native_reads="<<hw.hwUsage.romNativeReads<<"\nrom_fallback_reads="<<hw.hwUsage.romFallbackReads<<"\ndma_bytes="<<hw.hwUsage.dmaBytes<<"\ndma_native_bytes="<<hw.hwUsage.dmaNativeBytes<<"\ndma_fallback_bytes="<<hw.hwUsage.dmaFallbackBytes<<"\nhdma_bytes="<<hw.hwUsage.hdmaBytes<<"\nhdma_native_bytes="<<hw.hwUsage.hdmaNativeBytes<<"\nhdma_fallback_bytes="<<hw.hwUsage.hdmaFallbackBytes<<"\n";std::cout<<"Forja65: port C++ executado, frames="<<hw.frameCounter<<"\n";}catch(const std::exception&e){forja65Fatal(e.what());std::ofstream qa("forja65-qa-status.txt",std::ios::trunc);if(qa)qa<<"FORJA65_QA 1\nruntime_started=FAIL\nerror="<<e.what()<<"\n";return 2;}return 0;}
