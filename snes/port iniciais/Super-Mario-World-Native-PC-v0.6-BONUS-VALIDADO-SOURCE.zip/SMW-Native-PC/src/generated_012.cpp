#include "generated.hpp"
void sub_0085D2_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0085D2u: goto L_0085D2;
    case 0x0085D4u: goto L_0085D4;
    case 0x0085D7u: goto L_0085D7;
    case 0x0085D9u: goto L_0085D9;
    case 0x0085DCu: goto L_0085DC;
    case 0x0085DEu: goto L_0085DE;
    case 0x0085E1u: goto L_0085E1;
    case 0x0085E3u: goto L_0085E3;
    case 0x0085E6u: goto L_0085E6;
    case 0x0085E8u: goto L_0085E8;
    case 0x0085EAu: goto L_0085EA;
    case 0x0085EEu: goto L_0085EE;
    case 0x0085F2u: goto L_0085F2;
    case 0x0085F3u: goto L_0085F3;
    case 0x0085F7u: goto L_0085F7;
    case 0x0085F9u: goto L_0085F9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0085D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0085D2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0085D4;
L_0085D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D4u, 4u + ((((0x84D0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x84D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0085D4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x84D0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0085D7;
L_0085D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0085D7 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0085D9;
L_0085D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D9u, 4u + ((((0x84D1u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x84D1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0085D9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x84D1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0085DC;
L_0085DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0085DC STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0085DE;
L_0085DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DEu, 4u + ((((0x84D2u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x84D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0085DE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x84D2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0085E1;
L_0085E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0085E1 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0085E3;
L_0085E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E3u, 6u, 3u, cpu.address("abs", 0x871Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0085E3 JSR -> $00871E stack real
    { cpu.push16Value(hw,0x85E5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85E6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x871Eu), 0x0085E3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0085E6;
L_0085E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E6u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85E6u,0x0085E6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0085E6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0085E8;
L_0085E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0085E8 BNE -> $0085F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0085F7; }
    goto L_0085EA;
L_0085EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EAu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EAu, 5u, 4u, 0x7F837Bu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0085EA STA
    hw.write(0x7F837Bu, cpu.a, cpu.m8?8:16);
    goto L_0085EE;
L_0085EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu, 5u, 4u, 0x7F837Cu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0085EE STA
    hw.write(0x7F837Cu, cpu.a, cpu.m8?8:16);
    goto L_0085F2;
L_0085F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F2u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0085F2 DEC
    cpu.decReg('A');
    goto L_0085F3;
L_0085F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F3u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F3u, 5u, 4u, 0x7F837Du, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0085F3 STA
    hw.write(0x7F837Du, cpu.a, cpu.m8?8:16);
    goto L_0085F7;
L_0085F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F7u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0085F7 STZ
    hw.write(cpu.address("dp", 0x12u), 0, cpu.m8?8:16);
    goto L_0085F9;
L_0085F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0085F9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0085F9u);return;} hw.unresolvedReturn(0x0085F9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_009CBE_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009CBEu: goto L_009CBE;
    case 0x009CC0u: goto L_009CC0;
    case 0x009CC2u: goto L_009CC2;
    case 0x009CC4u: goto L_009CC4;
    case 0x009CC6u: goto L_009CC6;
    case 0x009CC8u: goto L_009CC8;
    case 0x009CCAu: goto L_009CCA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009CBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009CBE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009CC0;
L_009CC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009CC0 AND
    cpu.logicAnd(0xC0u);
    goto L_009CC2;
L_009CC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009CC2 BNE -> $009CCA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009CCA; }
    goto L_009CC4;
L_009CC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009CC4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009CC6;
L_009CC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009CC6 AND
    cpu.logicAnd(0xF0u);
    goto L_009CC8;
L_009CC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009CC8 BNE -> $009CCA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009CCA; }
    goto L_009CCA;
L_009CCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009CCA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009CCAu);return;} hw.unresolvedReturn(0x009CCAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_009D38_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009D38u: goto L_009D38;
    case 0x009D3Au: goto L_009D3A;
    case 0x009D3Cu: goto L_009D3C;
    case 0x009D3Eu: goto L_009D3E;
    case 0x009D41u: goto L_009D41;
    case 0x009D45u: goto L_009D45;
    case 0x009D46u: goto L_009D46;
    case 0x009D47u: goto L_009D47;
    case 0x009D4Bu: goto L_009D4B;
    case 0x009D4Cu: goto L_009D4C;
    case 0x009D4Du: goto L_009D4D;
    case 0x009D4Eu: goto L_009D4E;
    case 0x009D51u: goto L_009D51;
    case 0x009D53u: goto L_009D53;
    case 0x009D55u: goto L_009D55;
    case 0x009D57u: goto L_009D57;
    case 0x009D59u: goto L_009D59;
    case 0x009D5Bu: goto L_009D5B;
    case 0x009D5Du: goto L_009D5D;
    case 0x009D5Fu: goto L_009D5F;
    case 0x009D61u: goto L_009D61;
    case 0x009D64u: goto L_009D64;
    case 0x009D66u: goto L_009D66;
    case 0x009D6Au: goto L_009D6A;
    case 0x009D6Cu: goto L_009D6C;
    case 0x009D6Eu: goto L_009D6E;
    case 0x009D70u: goto L_009D70;
    case 0x009D72u: goto L_009D72;
    case 0x009D74u: goto L_009D74;
    case 0x009D76u: goto L_009D76;
    case 0x009D79u: goto L_009D79;
    case 0x009D7Au: goto L_009D7A;
    case 0x009D7Cu: goto L_009D7C;
    case 0x009D80u: goto L_009D80;
    case 0x009D81u: goto L_009D81;
    case 0x009D83u: goto L_009D83;
    case 0x009D85u: goto L_009D85;
    case 0x009D86u: goto L_009D86;
    case 0x009D8Au: goto L_009D8A;
    case 0x009D8Cu: goto L_009D8C;
    case 0x009D90u: goto L_009D90;
    case 0x009D94u: goto L_009D94;
    case 0x009D96u: goto L_009D96;
    case 0x009D98u: goto L_009D98;
    case 0x009D9Bu: goto L_009D9B;
    case 0x009D9Fu: goto L_009D9F;
    case 0x009DA0u: goto L_009DA0;
    case 0x009DA1u: goto L_009DA1;
    case 0x009DA2u: goto L_009DA2;
    case 0x009DA4u: goto L_009DA4;
    case 0x009DA6u: goto L_009DA6;
    case 0x009DA8u: goto L_009DA8;
    case 0x009DAAu: goto L_009DAA;
    case 0x009DABu: goto L_009DAB;
    case 0x009DADu: goto L_009DAD;
    case 0x009DAFu: goto L_009DAF;
    case 0x009DB1u: goto L_009DB1;
    case 0x009DB2u: goto L_009DB2;
    case 0x009DB4u: goto L_009DB4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009D38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D38u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D38 LDX
    cpu.setX(0xCBu, 8);
    goto L_009D3A;
L_009D3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D3A STZ
    hw.write(cpu.address("dp", 0x5u), 0, cpu.m8?8:16);
    goto L_009D3C;
L_009D3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D3C REP
    cpu.rep(0x10u);
    goto L_009D3E;
L_009D3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D3E LDY
    cpu.setY(0x0u, 16);
    goto L_009D41;
L_009D41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D41u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D41u, 5u, 4u, ((0x05B6FEu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D41 LDA
    cpu.loadA(hw.readW(((0x5B6FEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009D45;
L_009D45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D45u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D45u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009D45 PHX
    cpu.push("PHX", hw);
    goto L_009D46;
L_009D46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D46u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D46 TYX
    cpu.transfer("TYX");
    goto L_009D47;
L_009D47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D47u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D47u, 5u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D47 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_009D4B;
L_009D4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Bu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009D4B PLX
    cpu.pop("PLX", hw);
    goto L_009D4C;
L_009D4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D4C INX
    cpu.inc('X');
    goto L_009D4D;
L_009D4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D4D INY
    cpu.inc('Y');
    goto L_009D4E;
L_009D4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D4E CPY
    cpu.compareY(0xCCu);
    goto L_009D51;
L_009D51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D51u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D51u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D51 BNE -> $009D41
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009D41; }
    goto L_009D53;
L_009D53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D53u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D53u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D53 SEP
    cpu.sep(0x10u);
    goto L_009D55;
L_009D55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D55u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D55 LDA
    cpu.setA(0x84u, 8);
    goto L_009D57;
L_009D57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D57u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D57u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D57 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_009D59;
L_009D59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D59u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D59 LDX
    cpu.setX(0x2u, 8);
    goto L_009D5B;
L_009D5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Bu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D5B STX
    hw.write(cpu.address("dp", 0x4u), cpu.x, cpu.x8?8:16);
    goto L_009D5D;
L_009D5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Du,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D5D LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x5u), cpu.m8?8:16);
    goto L_009D5F;
L_009D5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D5F BCS -> $009DA6
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_009DA6; }
    goto L_009D61;
L_009D61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D61u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D61u, 6u, 3u, cpu.address("abs", 0x9DB5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009D61 JSR -> $009DB5 stack real
    { cpu.push16Value(hw,0x9D63u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D64u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9DB5u), 0x009D61u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009D64;
L_009D64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D64u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D64u,0x009D64u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D64u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D64u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D64 BNE -> $009DA6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009DA6; }
    goto L_009D66;
L_009D66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D66u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D66u, 5u, 4u, ((0x70008Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D66 LDA
    cpu.loadA(hw.readW(((0x70008Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009D6A;
L_009D6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D6A SEP
    cpu.sep(0x10u);
    goto L_009D6C;
L_009D6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D6C CMP
    cpu.compareA(0x60u);
    goto L_009D6E;
L_009D6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D6E BCC -> $009D76
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_009D76; }
    goto L_009D70;
L_009D70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D70u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D70 LDY
    cpu.setY(0x87u, 8);
    goto L_009D72;
L_009D72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D72u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D72 LDA
    cpu.setA(0x88u, 8);
    goto L_009D74;
L_009D74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D74 BRA -> $009D7A
    goto L_009D7A;
L_009D76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D76u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D76u, 6u, 3u, cpu.address("abs", 0x9045u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009D76 JSR -> $009045 stack real
    { cpu.push16Value(hw,0x9D78u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D79u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9045u), 0x009D76u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009D79;
L_009D79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D79u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D79u,0x009D79u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D79u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D79u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D79 TXY
    cpu.transfer("TXY");
    goto L_009D7A;
L_009D7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Au,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D7A LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_009D7C;
L_009D7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Cu, 5u, 4u, ((0x7F8381u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D7C STA
    hw.write(((0x7F8381u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_009D80;
L_009D80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D80u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D80u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D80 TYA
    cpu.transfer("TYA");
    goto L_009D81;
L_009D81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D81u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D81 BNE -> $009D85
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009D85; }
    goto L_009D83;
L_009D83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D83u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D83 LDY
    cpu.setY(0xFCu, 8);
    goto L_009D85;
L_009D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D85u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D85u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D85 TYA
    cpu.transfer("TYA");
    goto L_009D86;
L_009D86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D86u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D86u, 5u, 4u, ((0x7F837Fu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D86 STA
    hw.write(((0x7F837Fu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_009D8A;
L_009D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D8A LDA
    cpu.setA(0x38u, 8);
    goto L_009D8C;
L_009D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Cu, 5u, 4u, ((0x7F8380u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D8C STA
    hw.write(((0x7F8380u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_009D90;
L_009D90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D90u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D90u, 5u, 4u, ((0x7F8382u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D90 STA
    hw.write(((0x7F8382u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_009D94;
L_009D94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D94u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D94u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D94 REP
    cpu.rep(0x20u);
    goto L_009D96;
L_009D96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D96u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D96 LDY
    cpu.setY(0x3u, 8);
    goto L_009D98;
L_009D98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D98u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D98u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D98 LDA
    cpu.setA(0x38FCu, 16);
    goto L_009D9B;
L_009D9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D9Bu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D9Bu, 6u, 4u, ((0x7F8383u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D9B STA
    hw.write(((0x7F8383u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_009D9F;
L_009D9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D9Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009D9F INX
    cpu.inc('X');
    goto L_009DA0;
L_009DA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DA0 INX
    cpu.inc('X');
    goto L_009DA1;
L_009DA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA1u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DA1 DEY
    cpu.decReg('Y');
    goto L_009DA2;
L_009DA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DA2 BNE -> $009D98
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009D98; }
    goto L_009DA4;
L_009DA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DA4 SEP
    cpu.sep(0x20u);
    goto L_009DA6;
L_009DA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DA6 SEP
    cpu.sep(0x10u);
    goto L_009DA8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DA6 SEP
    cpu.sep(0x10u);
    goto L_009DA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DA6u,0x009DA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009DA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DA8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009DAA;
L_009DAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DAAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DAA SEC
    cpu.setFlag('C', true);
    goto L_009DAB;
L_009DAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DABu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DAB SBC
    cpu.sbc(0x24u);
    goto L_009DAD;
L_009DAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DADu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DAD STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_009DAF;
L_009DAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DAFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DAFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DAF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_009DB1;
L_009DB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB1u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DB1 DEX
    cpu.decReg('X');
    goto L_009DB2;
L_009DB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009DB2 BPL -> $009D5B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_009D5B; }
    goto L_009DB4;
L_009DB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009DB4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009DB4u);return;} hw.unresolvedReturn(0x009DB4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00AB42_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00AB42u: goto L_00AB42;
    case 0x00AB44u: goto L_00AB44;
    case 0x00AB48u: goto L_00AB48;
    case 0x00AB4Au: goto L_00AB4A;
    case 0x00AB4Du: goto L_00AB4D;
    case 0x00AB50u: goto L_00AB50;
    case 0x00AB52u: goto L_00AB52;
    case 0x00AB54u: goto L_00AB54;
    case 0x00AB57u: goto L_00AB57;
    case 0x00AB59u: goto L_00AB59;
    case 0x00AB5Cu: goto L_00AB5C;
    case 0x00AB5Fu: goto L_00AB5F;
    case 0x00AB61u: goto L_00AB61;
    case 0x00AB64u: goto L_00AB64;
    case 0x00AB66u: goto L_00AB66;
    case 0x00AB68u: goto L_00AB68;
    case 0x00AB6Au: goto L_00AB6A;
    case 0x00AB6Cu: goto L_00AB6C;
    case 0x00AB6Eu: goto L_00AB6E;
    case 0x00AB6Fu: goto L_00AB6F;
    case 0x00AB71u: goto L_00AB71;
    case 0x00AB73u: goto L_00AB73;
    case 0x00AB75u: goto L_00AB75;
    case 0x00AB77u: goto L_00AB77;
    case 0x00AB79u: goto L_00AB79;
    case 0x00AB7Cu: goto L_00AB7C;
    case 0x00AB7Fu: goto L_00AB7F;
    case 0x00AB81u: goto L_00AB81;
    case 0x00AB84u: goto L_00AB84;
    case 0x00AB87u: goto L_00AB87;
    case 0x00AB89u: goto L_00AB89;
    case 0x00AB8Cu: goto L_00AB8C;
    case 0x00AB8Eu: goto L_00AB8E;
    case 0x00AB90u: goto L_00AB90;
    case 0x00AB92u: goto L_00AB92;
    case 0x00AB93u: goto L_00AB93;
    case 0x00AB95u: goto L_00AB95;
    case 0x00AB97u: goto L_00AB97;
    case 0x00AB99u: goto L_00AB99;
    case 0x00AB9Bu: goto L_00AB9B;
    case 0x00AB9Du: goto L_00AB9D;
    case 0x00AB9Fu: goto L_00AB9F;
    case 0x00ABA1u: goto L_00ABA1;
    case 0x00ABA4u: goto L_00ABA4;
    case 0x00ABA7u: goto L_00ABA7;
    case 0x00ABA9u: goto L_00ABA9;
    case 0x00ABACu: goto L_00ABAC;
    case 0x00ABAFu: goto L_00ABAF;
    case 0x00ABB1u: goto L_00ABB1;
    case 0x00ABB4u: goto L_00ABB4;
    case 0x00ABB5u: goto L_00ABB5;
    case 0x00ABB6u: goto L_00ABB6;
    case 0x00ABB8u: goto L_00ABB8;
    case 0x00ABBBu: goto L_00ABBB;
    case 0x00ABBEu: goto L_00ABBE;
    case 0x00ABBFu: goto L_00ABBF;
    case 0x00ABC1u: goto L_00ABC1;
    case 0x00ABC3u: goto L_00ABC3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00AB42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB42u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB42 LDY
    cpu.setY(0x27u, 8);
    goto L_00AB44;
L_00AB44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB44u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB44u, 8u, 4u, 0x00BA28u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00AB44 JSL -> $00BA28 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB47u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB48u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00BA28u, 0x00AB44u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AB48;
L_00AB48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB48u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB48u,0x00AB48u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB48u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB48u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB48 REP
    cpu.rep(0x10u);
    goto L_00AB4A;
L_00AB4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB4A LDY
    cpu.setY(0x0u, 16);
    goto L_00AB4D;
L_00AB4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB4D LDX
    cpu.setX(0x3FFu, 16);
    goto L_00AB50;
L_00AB50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB50u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB50u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00AB50 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AB52;
L_00AB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB52u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB52u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB52 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_00AB54;
L_00AB54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB54u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB54u, 6u, 3u, cpu.address("abs", 0xABC4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AB54 JSR -> $00ABC4 stack real
    { cpu.push16Value(hw,0xAB56u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB57u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABC4u), 0x00AB54u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AB57;
L_00AB57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB57u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB57u,0x00AB57u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB57u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB57u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB57 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AB59;
L_00AB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB59u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB59u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB59 STA
    hw.write(cpu.address("abs", 0x2119u), cpu.a, cpu.m8?8:16);
    goto L_00AB5C;
L_00AB5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Cu, 6u, 3u, cpu.address("abs", 0xABC4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AB5C JSR -> $00ABC4 stack real
    { cpu.push16Value(hw,0xAB5Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB5Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABC4u), 0x00AB5Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AB5F;
L_00AB5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB5Fu,0x00AB5Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB5F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AB61;
L_00AB61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB61u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB61u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB61 STA
    hw.write(cpu.address("abs", 0x2119u), cpu.a, cpu.m8?8:16);
    goto L_00AB64;
L_00AB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB64u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB64u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB64 STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_00AB66;
L_00AB66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB66u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB66u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB66 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_00AB68;
L_00AB68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB68u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB68u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB68 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_00AB6A;
L_00AB6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Au,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB6A ROL
    cpu.rolMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_00AB6C;
L_00AB6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Cu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB6C ROL
    cpu.rolMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_00AB6E;
L_00AB6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB6E INY
    cpu.inc('Y');
    goto L_00AB6F;
L_00AB6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Fu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00AB6F LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AB71;
L_00AB71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB71u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB71u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB71 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_00AB73;
L_00AB73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB73u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB73u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB73 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_00AB75;
L_00AB75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB75u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB75u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB75 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_00AB77;
L_00AB77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB77u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB77u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB77 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AB79;
L_00AB79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB79u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB79u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB79 STA
    hw.write(cpu.address("abs", 0x2119u), cpu.a, cpu.m8?8:16);
    goto L_00AB7C;
L_00AB7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB7Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB7Cu, 6u, 3u, cpu.address("abs", 0xABC4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AB7C JSR -> $00ABC4 stack real
    { cpu.push16Value(hw,0xAB7Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB7Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABC4u), 0x00AB7Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AB7F;
L_00AB7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB7Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB7Fu,0x00AB7Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB7Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB7Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB7F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AB81;
L_00AB81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB81u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB81u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB81 STA
    hw.write(cpu.address("abs", 0x2119u), cpu.a, cpu.m8?8:16);
    goto L_00AB84;
L_00AB84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB84u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB84u, 6u, 3u, cpu.address("abs", 0xABC4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AB84 JSR -> $00ABC4 stack real
    { cpu.push16Value(hw,0xAB86u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB87u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABC4u), 0x00AB84u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AB87;
L_00AB87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB87u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB87u,0x00AB87u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB87u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB87u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB87 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AB89;
L_00AB89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB89u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB89u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB89 STA
    hw.write(cpu.address("abs", 0x2119u), cpu.a, cpu.m8?8:16);
    goto L_00AB8C;
L_00AB8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB8C STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_00AB8E;
L_00AB8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Eu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB8E ROL
    cpu.rolMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_00AB90;
L_00AB90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB90u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB90u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB90 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_00AB92;
L_00AB92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB92u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB92u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB92 INY
    cpu.inc('Y');
    goto L_00AB93;
L_00AB93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB93u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB93u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00AB93 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AB95;
L_00AB95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB95u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB95u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB95 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_00AB97;
L_00AB97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB97u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB97u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB97 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_00AB99;
L_00AB99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB99u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB99u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB99 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_00AB9B;
L_00AB9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Bu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB9B ROL
    cpu.rolMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_00AB9D;
L_00AB9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Du,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB9D ROL
    cpu.rolMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_00AB9F;
L_00AB9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AB9F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ABA1;
L_00ABA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA1u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABA1 STA
    hw.write(cpu.address("abs", 0x2119u), cpu.a, cpu.m8?8:16);
    goto L_00ABA4;
L_00ABA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA4u, 6u, 3u, cpu.address("abs", 0xABC4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ABA4 JSR -> $00ABC4 stack real
    { cpu.push16Value(hw,0xABA6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xABA7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABC4u), 0x00ABA4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ABA7;
L_00ABA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABA7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABA7u,0x00ABA7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABA7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ABA9;
L_00ABA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA9u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABA9 STA
    hw.write(cpu.address("abs", 0x2119u), cpu.a, cpu.m8?8:16);
    goto L_00ABAC;
L_00ABAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABACu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABACu, 6u, 3u, cpu.address("abs", 0xABC4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ABAC JSR -> $00ABC4 stack real
    { cpu.push16Value(hw,0xABAEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xABAFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABC4u), 0x00ABACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ABAF;
L_00ABAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABAFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABAFu,0x00ABAFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABAFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABAFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABAF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ABB1;
L_00ABB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB1u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABB1 STA
    hw.write(cpu.address("abs", 0x2119u), cpu.a, cpu.m8?8:16);
    goto L_00ABB4;
L_00ABB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB4u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABB4 INY
    cpu.inc('Y');
    goto L_00ABB5;
L_00ABB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABB5 DEX
    cpu.decReg('X');
    goto L_00ABB6;
L_00ABB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABB6 BPL -> $00AB50
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AB50; }
    goto L_00ABB8;
L_00ABB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABB8 LDX
    cpu.setX(0x2000u, 16);
    goto L_00ABBB;
L_00ABBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABBBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABBBu, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABBB STZ
    hw.write(cpu.address("abs", 0x2119u), 0, cpu.m8?8:16);
    goto L_00ABBE;
L_00ABBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABBEu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABBE DEX
    cpu.decReg('X');
    goto L_00ABBF;
L_00ABBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABBFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABBFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABBF BNE -> $00ABBB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ABBB; }
    goto L_00ABC1;
L_00ABC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABC1 SEP
    cpu.sep(0x10u);
    goto L_00ABC3;
L_00ABC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ABC3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00ABC3u);return;} hw.unresolvedReturn(0x00ABC3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00B983_E1M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00B983u: goto L_00B983;
    case 0x00B985u: goto L_00B985;
    case 0x00B987u: goto L_00B987;
    case 0x00B988u: goto L_00B988;
    case 0x00B98Au: goto L_00B98A;
    case 0x00B98Du: goto L_00B98D;
    case 0x00B98Fu: goto L_00B98F;
    case 0x00B991u: goto L_00B991;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00B983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB983u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB983u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Au) & 0xFFFFu), 3u, 0u);
    // $00B983 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B985;
L_00B985:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB985u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB985u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB985u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B985 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B987;
L_00B987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB987u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B987 INX
    cpu.inc('X');
    goto L_00B988;
L_00B988:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB988u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB988u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB988u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B988 BNE -> $00B98F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B98F; }
    goto L_00B98A;
L_00B98A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B98A LDX
    cpu.setX(0x8000u, 16);
    goto L_00B98D;
L_00B98D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B98D INC
    cpu.incMem(hw, cpu.address("dp", 0x8Cu), cpu.m8?8:16);
    goto L_00B98F;
L_00B98F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Fu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B98F STX
    hw.write(cpu.address("dp", 0x8Au), cpu.x, cpu.x8?8:16);
    goto L_00B991;
L_00B991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB991u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB991u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB991u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B991 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00B991u);return;} hw.unresolvedReturn(0x00B991u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00C47E_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00C592u: goto L_00C592;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00C592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC592u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00C592 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00C592u);return;} hw.unresolvedReturn(0x00C592u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00C592 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00C592u);return;} hw.unresolvedReturn(0x00C592u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00C592 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00C592u);return;} hw.unresolvedReturn(0x00C592u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00C592 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00C592u);return;} hw.unresolvedReturn(0x00C592u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC592u,0x00C592u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E1M1X1CQ_part12(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EED7u: goto L_00EED7;
    case 0x00EED9u: goto L_00EED9;
    case 0x00EEDBu: goto L_00EEDB;
    case 0x00EEDDu: goto L_00EEDD;
    case 0x00EEDFu: goto L_00EEDF;
    case 0x00EEE1u: goto L_00EEE1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED7u))return;
  // 23 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED7u,0x00EED7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED9u))return;
  // 23 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED9u,0x00EED9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEDBu))return;
  // 23 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEDD;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEDD;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEDD;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDBu,0x00EEDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEDDu))return;
  // 23 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16));
    goto L_00EEDF;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16));
    goto L_00EEDF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16));
    goto L_00EEDF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16));
    goto L_00EEDF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEDFu))return;
  // 23 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDF STA
    hw.write(cpu.address("dp", 0x97u), cpu.a, cpu.m8?8:16);
    goto L_00EEE1;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDF STA
    hw.write(cpu.address("dp", 0x97u), cpu.a, cpu.m8?8:16);
    goto L_00EEE1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDF STA
    hw.write(cpu.address("dp", 0x97u), cpu.a, cpu.m8?8:16);
    goto L_00EEE1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDF STA
    hw.write(cpu.address("dp", 0x97u), cpu.a, cpu.m8?8:16);
    goto L_00EEE1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDFu,0x00EEDFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE1u))return;
  // 24 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u, 5u + 1u, 3u, cpu.address("absy", 0xE53Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE4u,0x00EEE1u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u, 5u + ((((0xE53Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE53Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE4u,0x00EEE1u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u, 4u + 1u, 3u, cpu.address("absy", 0xE53Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE4u,0x00EEE1u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u, 4u + ((((0xE53Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE53Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE4u,0x00EEE1u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE1u,0x00EEE1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1C1_part34(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF92u: goto L_00EF92;
    case 0x00EF93u: goto L_00EF93;
    case 0x00EF95u: goto L_00EF95;
    case 0x00EF96u: goto L_00EF96;
    case 0x00EF98u: goto L_00EF98;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF92u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF92 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EF95;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF92 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EF95;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF92 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EF95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF92u,0x00EF92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF93u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF93u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF93u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9C1Du + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $00EF93 JSR (9C1D,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9C1Du+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0xEF95u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF96u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x00EF93u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF96;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF93u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF93u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9C1Du + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $00EF93 JSR (9C1D,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9C1Du+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0xEF95u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF96u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x00EF93u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF96;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF93u,0x00EF93u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF95u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 5u, 3u, cpu.address("abs", 0x1697u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 5u, 3u, cpu.address("abs", 0x1697u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF95u,0x00EF95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF96u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF96u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF96u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x16u) & 0xFFFFu), 3u, 0u);
    // $00EF96 STA
    hw.write(cpu.addressDpLongY(hw, 0x16u), cpu.a, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF96u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF96u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x16u) & 0xFFFFu), 3u, 0u);
    // $00EF96 STA
    hw.write(cpu.addressDpLongY(hw, 0x16u), cpu.a, cpu.m8?8:16);
    goto L_00EF98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF96u,0x00EF96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF98u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF98u,0x00EF98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part34(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF92u: goto L_00EF92;
    case 0x00EF93u: goto L_00EF93;
    case 0x00EF95u: goto L_00EF95;
    case 0x00EF96u: goto L_00EF96;
    case 0x00EF98u: goto L_00EF98;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF92u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF92 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EF95;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF92 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EF95;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF92 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EF95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF92u,0x00EF92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF93u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF93u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF93u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9C1Du + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $00EF93 JSR (9C1D,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9C1Du+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0xEF95u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF96u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x00EF93u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF96;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF93u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF93u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9C1Du + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $00EF93 JSR (9C1D,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9C1Du+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0xEF95u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF96u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x00EF93u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF96;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF93u,0x00EF93u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF95u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 5u, 3u, cpu.address("abs", 0x1697u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 5u, 3u, cpu.address("abs", 0x1697u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF95u,0x00EF95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF96u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF96u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF96u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x16u) & 0xFFFFu), 3u, 0u);
    // $00EF96 STA
    hw.write(cpu.addressDpLongY(hw, 0x16u), cpu.a, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF96u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF96u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x16u) & 0xFFFFu), 3u, 0u);
    // $00EF96 STA
    hw.write(cpu.addressDpLongY(hw, 0x16u), cpu.a, cpu.m8?8:16);
    goto L_00EF98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF96u,0x00EF96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF98u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF98u,0x00EF98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EC21_E0M1X1CQ_part12(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EFB6u: goto L_00EFB6;
    case 0x00EFB8u: goto L_00EFB8;
    case 0x00EFB9u: goto L_00EFB9;
    case 0x00EFBBu: goto L_00EFBB;
    case 0x00EFBCu: goto L_00EFBC;
    case 0x00EFBFu: goto L_00EFBF;
    case 0x00EFC1u: goto L_00EFC1;
    case 0x00EFC3u: goto L_00EFC3;
    case 0x00EFC5u: goto L_00EFC5;
    case 0x00EFC7u: goto L_00EFC7;
    case 0x00EFC8u: goto L_00EFC8;
    case 0x00EFC9u: goto L_00EFC9;
    case 0x00EFCCu: goto L_00EFCC;
    case 0x00EFCDu: goto L_00EFCD;
    case 0x00EFCFu: goto L_00EFCF;
    case 0x00EFD2u: goto L_00EFD2;
    case 0x00EFD4u: goto L_00EFD4;
    case 0x00EFD7u: goto L_00EFD7;
    case 0x00EFD8u: goto L_00EFD8;
    case 0x00EFDBu: goto L_00EFDB;
    case 0x00EFDDu: goto L_00EFDD;
    case 0x00EFDFu: goto L_00EFDF;
    case 0x00EFE0u: goto L_00EFE0;
    case 0x00EFE3u: goto L_00EFE3;
    case 0x00EFE5u: goto L_00EFE5;
    case 0x00EFE7u: goto L_00EFE7;
    case 0x00F629u: goto L_00F629;
    case 0x00F62Du: goto L_00F62D;
    case 0x00F62Fu: goto L_00F62F;
    case 0x00F631u: goto L_00F631;
    case 0x00F633u: goto L_00F633;
    case 0x00F635u: goto L_00F635;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EFB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB6u))return;
  // 13 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB6 LDA
    cpu.setA(0x8D09u, 16);
    goto L_00EFB9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB6 LDA
    cpu.setA(0x9u, 8);
    goto L_00EFB8;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB6 LDA
    cpu.setA(0x9u, 8);
    goto L_00EFB8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB6u,0x00EFB6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB8u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB8u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB8 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EFBB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB8u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB8 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EFBB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB8u,0x00EFB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB9u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB9u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB9u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x601Du + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $00EFB9 JSR (601D,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x601Du+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0xEFBBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFBCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x00EFB9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EFBC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB9u,0x00EFB9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFBBu))return;
  // 13 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFBB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFBBu);return;} hw.unresolvedReturn(0x00EFBBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFBB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFBBu);return;} hw.unresolvedReturn(0x00EFBBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFBB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFBBu);return;} hw.unresolvedReturn(0x00EFBBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFBBu,0x00EFBBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFBCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBCu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBCu, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFBC LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EFBF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFBCu,0x00EFBCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFBFu))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBFu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFBF CPX
    cpu.compareX(0xCEu);
    goto L_00EFC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFBFu,0x00EFBFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFC1u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFC1 BCC -> $00EFE7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EFE7; }
    goto L_00EFC3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFC1u,0x00EFC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFC3u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC3u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFC3 CPX
    cpu.compareX(0xD2u);
    goto L_00EFC5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFC3u,0x00EFC3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFC5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFC5 BCS -> $00EFE7
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EFE7; }
    goto L_00EFC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFC5u,0x00EFC5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFC7u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC7u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFC7 TXA
    cpu.transfer("TXA");
    goto L_00EFC8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFC7u,0x00EFC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFC8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC8u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFC8 SEC
    cpu.setFlag('C', true);
    goto L_00EFC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFC8u,0x00EFC8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFC9u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFC9 SBC
    cpu.sbc(0xACCu);
    goto L_00EFCC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFC9u,0x00EFC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFCCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFCCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFCCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFCC TAX
    cpu.transfer("TAX");
    goto L_00EFCD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFCCu,0x00EFCCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFCDu))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFCDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFCDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFCD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFCF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFCDu,0x00EFCDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFCFu))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFCFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFCFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFCF AND
    cpu.logicAnd(0xD003u);
    goto L_00EFD2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFCFu,0x00EFCFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD2u,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC2u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFD2 TRB
    cpu.trb(hw, cpu.address("dp", 0xC2u), cpu.m8?8:16);
    goto L_00EFD4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFD2u,0x00EFD2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD4u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD4u, 6u, 3u, cpu.address("abs", 0x94A5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFD4 JSR -> $0094A5 stack real
    { cpu.push16Value(hw,0xEFD6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFD7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x94A5u), 0x00EFD4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EFD7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFD4u,0x00EFD4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD7u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFD7 CLC
    cpu.setFlag('C', false);
    goto L_00EFD8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFD7u,0x00EFD7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD8u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD8u, 5u + ((((0xE913u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE913u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFD8 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE913u), cpu.m8?8:16));
    goto L_00EFDB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFD8u,0x00EFD8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDBu))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFDB STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00EFDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFDBu,0x00EFDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDDu))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFDD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFDF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFDDu,0x00EFDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDFu))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFDF CLC
    cpu.setFlag('C', false);
    goto L_00EFE0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFDFu,0x00EFDFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE0u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE0u, 5u + ((((0xE91Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE91Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFE0 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE91Fu), cpu.m8?8:16));
    goto L_00EFE3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFE0u,0x00EFE0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE3u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFE3 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EFE5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFE3u,0x00EFE3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFE5 SEP
    cpu.sep(0x20u);
    goto L_00EFE7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFE5u,0x00EFE5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE7u))return;
  // 6 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFE7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFE7u);return;} hw.unresolvedReturn(0x00EFE7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFE7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFE7u);return;} hw.unresolvedReturn(0x00EFE7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFE7u,0x00EFE7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u, 8u, 4u, 0x00F606u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F629 JSL -> $00F606 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF62Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF62Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F606u, 0x00F629u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F62D;
L_00F62D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF62Du,0x00F62Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62D STZ
    hw.write(cpu.address("dp", 0x15u), 0, cpu.m8?8:16);
    goto L_00F62F;
L_00F62F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62F STZ
    hw.write(cpu.address("dp", 0x16u), 0, cpu.m8?8:16);
    goto L_00F631;
L_00F631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF631u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F631 STZ
    hw.write(cpu.address("dp", 0x17u), 0, cpu.m8?8:16);
    goto L_00F633;
L_00F633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F633 STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_00F635;
L_00F635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF635u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F635 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F635u);return;} hw.unresolvedReturn(0x00F635u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_018AFC_E0M1X1C0_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018AFCu: goto L_018AFC;
    case 0x018AFEu: goto L_018AFE;
    case 0x018B00u: goto L_018B00;
    case 0x018B03u: goto L_018B03;
    case 0x018B06u: goto L_018B06;
    case 0x018B09u: goto L_018B09;
    case 0x018B0Au: goto L_018B0A;
    case 0x018B0Du: goto L_018B0D;
    case 0x018B0Fu: goto L_018B0F;
    case 0x018B11u: goto L_018B11;
    case 0x018B14u: goto L_018B14;
    case 0x018B15u: goto L_018B15;
    case 0x018B18u: goto L_018B18;
    case 0x018B1Au: goto L_018B1A;
    case 0x018B1Bu: goto L_018B1B;
    case 0x018B1Cu: goto L_018B1C;
    case 0x018B1Fu: goto L_018B1F;
    case 0x018B22u: goto L_018B22;
    case 0x018B23u: goto L_018B23;
    case 0x018B26u: goto L_018B26;
    case 0x018B28u: goto L_018B28;
    case 0x018B29u: goto L_018B29;
    case 0x018B2Cu: goto L_018B2C;
    case 0x018B2Eu: goto L_018B2E;
    case 0x018B31u: goto L_018B31;
    case 0x018B32u: goto L_018B32;
    case 0x018B33u: goto L_018B33;
    case 0x018B36u: goto L_018B36;
    case 0x018B38u: goto L_018B38;
    case 0x018B3Au: goto L_018B3A;
    case 0x018B3Cu: goto L_018B3C;
    case 0x018B3Fu: goto L_018B3F;
    case 0x018B41u: goto L_018B41;
    case 0x018B43u: goto L_018B43;
    case 0x018B46u: goto L_018B46;
    case 0x018B49u: goto L_018B49;
    case 0x018B4Cu: goto L_018B4C;
    case 0x018B4Fu: goto L_018B4F;
    case 0x018B51u: goto L_018B51;
    case 0x018B54u: goto L_018B54;
    case 0x018B57u: goto L_018B57;
    case 0x018B59u: goto L_018B59;
    case 0x018B5Cu: goto L_018B5C;
    case 0x018B5Du: goto L_018B5D;
    case 0x018B5Fu: goto L_018B5F;
    case 0x018B61u: goto L_018B61;
    case 0x018B64u: goto L_018B64;
    case 0x018B66u: goto L_018B66;
    case 0x018B68u: goto L_018B68;
    case 0x018B6Bu: goto L_018B6B;
    case 0x018B6Cu: goto L_018B6C;
    case 0x018B6Fu: goto L_018B6F;
    case 0x018B70u: goto L_018B70;
    case 0x018B73u: goto L_018B73;
    case 0x018B75u: goto L_018B75;
    case 0x018B77u: goto L_018B77;
    case 0x018B7Au: goto L_018B7A;
    case 0x018B7Bu: goto L_018B7B;
    case 0x018B7Du: goto L_018B7D;
    case 0x018B7Fu: goto L_018B7F;
    case 0x018B82u: goto L_018B82;
    case 0x018B84u: goto L_018B84;
    case 0x018B86u: goto L_018B86;
    case 0x018B89u: goto L_018B89;
    case 0x018B8Bu: goto L_018B8B;
    case 0x018B8Eu: goto L_018B8E;
    case 0x018B90u: goto L_018B90;
    case 0x018B93u: goto L_018B93;
    case 0x018B96u: goto L_018B96;
    case 0x018B98u: goto L_018B98;
    case 0x018B9Au: goto L_018B9A;
    case 0x018B9Du: goto L_018B9D;
    case 0x018BA0u: goto L_018BA0;
    case 0x018BA3u: goto L_018BA3;
    case 0x018BA6u: goto L_018BA6;
    case 0x018BA8u: goto L_018BA8;
    case 0x018BABu: goto L_018BAB;
    case 0x018BADu: goto L_018BAD;
    case 0x018BB0u: goto L_018BB0;
    case 0x018BB3u: goto L_018BB3;
    case 0x018BB5u: goto L_018BB5;
    case 0x018BB8u: goto L_018BB8;
    case 0x018BBAu: goto L_018BBA;
    case 0x018BBDu: goto L_018BBD;
    case 0x018BC0u: goto L_018BC0;
    case 0x018BC3u: goto L_018BC3;
    case 0x018BC6u: goto L_018BC6;
    case 0x018BC7u: goto L_018BC7;
    case 0x018BCAu: goto L_018BCA;
    case 0x018BCCu: goto L_018BCC;
    case 0x018BCEu: goto L_018BCE;
    case 0x018BD1u: goto L_018BD1;
    case 0x018BD3u: goto L_018BD3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018AFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AFC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018AFE;
L_018AFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AFE BEQ -> $018B0A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B0A; }
    goto L_018B00;
L_018B00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B00u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B00u, 6u, 3u, cpu.address("abs", 0xA7E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B00 JSR -> $01A7E4 stack real
    { cpu.push16Value(hw,0x8B02u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B03u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA7E4u), 0x018B00u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B03;
L_018B03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B03u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B03u,0x018B03u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B03u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B03u, 6u, 3u, cpu.address("abs", 0xA40Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B03 JSR -> $01A40D stack real
    { cpu.push16Value(hw,0x8B05u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B06u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA40Du), 0x018B03u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B06;
L_018B06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B06u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B06u,0x018B06u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B06u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B06u, 6u, 3u, cpu.address("abs", 0x8BC3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B06 JSR -> $018BC3 stack real
    { cpu.push16Value(hw,0x8B08u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B09u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8BC3u), 0x018B06u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B09;
L_018B09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B09u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B09u,0x018B09u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B09u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B09u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B09 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018B09u);return;} hw.unresolvedReturn(0x018B09u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_018B0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Au, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B0A JSR -> $01800E stack real
    { cpu.push16Value(hw,0x8B0Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B0Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0x018B0Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B0D;
L_018B0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B0Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B0Du,0x018B0Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B0D BEQ -> $018B2E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B2E; }
    goto L_018B0F;
L_018B0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B0F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018B11;
L_018B11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B11u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B11u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B11 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B14;
L_018B14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B14u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B14u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B14 LSR
    cpu.lsrA();
    goto L_018B15;
L_018B15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B15u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B15u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B15 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x157Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018B18;
L_018B18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B18u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B18 BCC -> $018B1C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_018B1C; }
    goto L_018B1A;
L_018B1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B1A INY
    cpu.inc('Y');
    goto L_018B1B;
L_018B1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B1B INY
    cpu.inc('Y');
    goto L_018B1C;
L_018B1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Cu, 4u + ((((0x88ECu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88ECu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B1C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88ECu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B1F;
L_018B1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Fu,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Fu, 4u + ((((0x15B8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15B8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B1F EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0x15B8u), cpu.m8?8:16));
    goto L_018B22;
L_018B22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B22u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B22 ASL
    cpu.aslA();
    goto L_018B23;
L_018B23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B23u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B23u, 4u + ((((0x88ECu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88ECu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B23 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88ECu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B26;
L_018B26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B26u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B26 BCC -> $018B2C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_018B2C; }
    goto L_018B28;
L_018B28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B28u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B28u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B28 CLC
    cpu.setFlag('C', false);
    goto L_018B29;
L_018B29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B29u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B29u, 4u + ((((0x15B8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15B8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B29 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x15B8u), cpu.m8?8:16));
    goto L_018B2C;
L_018B2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B2C STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_018B2E;
L_018B2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B2Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Eu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Eu, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B2E LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x157Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018B31;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Eu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Eu, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B2E LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x157Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018B31;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B2Eu,0x018B2Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B31u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B31u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B31 TYA
    cpu.transfer("TYA");
    goto L_018B32;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B31u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B31 TYA
    cpu.transfer("TYA");
    goto L_018B32;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B31u,0x018B31u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B32u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B32u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B32 INC
    cpu.inc('A');
    goto L_018B33;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B32u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B32 INC
    cpu.inc('A');
    goto L_018B33;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B32u,0x018B32u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B33u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B33u,cpu,0x3Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B33u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B33 AND
    cpu.logicAnd(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16));
    goto L_018B36;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B33u,cpu,0x3Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B33u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B33 AND
    cpu.logicAnd(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16));
    goto L_018B36;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B33u,0x018B33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B36u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B36u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B36 AND
    cpu.logicAnd(0x3u);
    goto L_018B38;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B36u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B36 AND
    cpu.logicAnd(0x3u);
    goto L_018B38;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B36u,0x018B36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B38u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B38u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B38 BEQ -> $018B3C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B3C; }
    goto L_018B3A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B38u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B38 BEQ -> $018B3C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B3C; }
    goto L_018B3A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B38u,0x018B38u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B3Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B3A STZ
    hw.write(cpu.address("dpx", 0xB6u), 0, cpu.m8?8:16);
    goto L_018B3C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B3A STZ
    hw.write(cpu.address("dpx", 0xB6u), 0, cpu.m8?8:16);
    goto L_018B3C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B3Au,0x018B3Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B3Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Cu, 6u, 3u, cpu.address("abs", 0x8014u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B3C JSR -> $018014 stack real
    { cpu.push16Value(hw,0x8B3Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B3Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8014u), 0x018B3Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B3F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Cu, 6u, 3u, cpu.address("abs", 0x8014u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B3C JSR -> $018014 stack real
    { cpu.push16Value(hw,0x8B3Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B3Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8014u), 0x018B3Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B3F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B3Cu,0x018B3Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B3Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B3F BEQ -> $018B43
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B43; }
    goto L_018B41;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B3F BEQ -> $018B43
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B43; }
    goto L_018B41;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B3Fu,0x018B3Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B41u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B41u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B41u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B41 STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_018B43;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B41u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B41u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B41 STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_018B43;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B41u,0x018B41u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B43u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B43u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B43u, 6u, 3u, cpu.address("abs", 0xAC31u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B43 JSR -> $01AC31 stack real
    { cpu.push16Value(hw,0x8B45u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B46u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC31u), 0x018B43u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B46;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B43u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B43u, 6u, 3u, cpu.address("abs", 0xAC31u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B43 JSR -> $01AC31 stack real
    { cpu.push16Value(hw,0x8B45u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B46u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC31u), 0x018B43u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B46;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B43u,0x018B43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B46u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B46u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B46u, 6u, 3u, cpu.address("abs", 0x9032u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B46 JSR -> $019032 stack real
    { cpu.push16Value(hw,0x8B48u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B49u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9032u), 0x018B46u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B49;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B46u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B46u, 6u, 3u, cpu.address("abs", 0x9032u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B46 JSR -> $019032 stack real
    { cpu.push16Value(hw,0x8B48u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B49u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9032u), 0x018B46u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B49;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B46u,0x018B46u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B49u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B49u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B49u, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B49 JSR -> $018E5F stack real
    { cpu.push16Value(hw,0x8B4Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B4Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x018B49u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B4C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B49u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B49u, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B49 JSR -> $018E5F stack real
    { cpu.push16Value(hw,0x8B4Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B4Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x018B49u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B4C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B49u,0x018B49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B4C JSR -> $01800E stack real
    { cpu.push16Value(hw,0x8B4Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B4Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0x018B4Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B4F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B4C JSR -> $01800E stack real
    { cpu.push16Value(hw,0x8B4Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B4Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0x018B4Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B4F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B4Cu,0x018B4Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B4F BEQ -> $018B84
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B84; }
    goto L_018B51;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B4F BEQ -> $018B84
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B84; }
    goto L_018B51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B4Fu,0x018B4Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B51u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B51u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B51u, 6u, 3u, cpu.address("abs", 0x9A04u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B51 JSR -> $019A04 stack real
    { cpu.push16Value(hw,0x8B53u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B54u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9A04u), 0x018B51u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B54;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B51u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B51u, 6u, 3u, cpu.address("abs", 0x9A04u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B51 JSR -> $019A04 stack real
    { cpu.push16Value(hw,0x8B53u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B54u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9A04u), 0x018B51u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B51u,0x018B51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B54u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B54u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B54u, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B54 STZ
    hw.write(cpu.address("absx", 0x151Cu), 0, cpu.m8?8:16);
    goto L_018B57;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B54u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B54u, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B54 STZ
    hw.write(cpu.address("absx", 0x151Cu), 0, cpu.m8?8:16);
    goto L_018B57;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B54u,0x018B54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B57u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B57u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B57u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B57 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018B59;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B57u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B57u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B57 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018B59;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B57u,0x018B57u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B59u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B59u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B59u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B59 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B5C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B59u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B59u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B59 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B5C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B59u,0x018B59u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B5Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018B5C PHA
    cpu.push("PHA", hw);
    goto L_018B5D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018B5C PHA
    cpu.push("PHA", hw);
    goto L_018B5D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B5Cu,0x018B5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B5Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B5D AND
    cpu.logicAnd(0x4u);
    goto L_018B5F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B5D AND
    cpu.logicAnd(0x4u);
    goto L_018B5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B5Du,0x018B5Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B5Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B5F BEQ -> $018B7A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B7A; }
    goto L_018B61;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B5F BEQ -> $018B7A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B7A; }
    goto L_018B61;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B5Fu,0x018B5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B61u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B61u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B61u, 4u + ((((0x1570u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B61 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1570u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B64;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B61u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B61u, 4u + ((((0x1570u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B61 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1570u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B61u,0x018B61u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B64u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B64u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B64u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B64 AND
    cpu.logicAnd(0x7Fu);
    goto L_018B66;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B64u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B64u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B64 AND
    cpu.logicAnd(0x7Fu);
    goto L_018B66;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B64u,0x018B64u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B66u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B66u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B66 BNE -> $018B7A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B7A; }
    goto L_018B68;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B66u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B66 BNE -> $018B7A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B7A; }
    goto L_018B68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B66u,0x018B66u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B68u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B68u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B68u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B68 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B68u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B68u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B68 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B68u,0x018B68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018B6B PHA
    cpu.push("PHA", hw);
    goto L_018B6C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018B6B PHA
    cpu.push("PHA", hw);
    goto L_018B6C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B6Bu,0x018B6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Cu, 6u, 3u, cpu.address("abs", 0x857Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B6C JSR -> $01857C stack real
    { cpu.push16Value(hw,0x8B6Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B6Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x857Cu), 0x018B6Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B6F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Cu, 6u, 3u, cpu.address("abs", 0x857Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B6C JSR -> $01857C stack real
    { cpu.push16Value(hw,0x8B6Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B6Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x857Cu), 0x018B6Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B6F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B6Cu,0x018B6Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Fu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018B6F PLA
    cpu.pop("PLA", hw);
    goto L_018B70;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Fu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018B6F PLA
    cpu.pop("PLA", hw);
    goto L_018B70;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B6Fu,0x018B6Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B70u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B70u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B70u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B70 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16));
    goto L_018B73;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B70u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B70u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B70 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16));
    goto L_018B73;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B70u,0x018B70u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B73u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B73u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B73 BEQ -> $018B7A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B7A; }
    goto L_018B75;
L_018B75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B75u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B75 LDA
    cpu.setA(0x8u, 8);
    goto L_018B77;
L_018B77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B77u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B77u, 5u, 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B77 STA
    hw.write(cpu.address("absx", 0x15ACu), cpu.a, cpu.m8?8:16);
    goto L_018B7A;
L_018B7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018B7A PLA
    cpu.pop("PLA", hw);
    goto L_018B7B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018B7A PLA
    cpu.pop("PLA", hw);
    goto L_018B7B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B7Au,0x018B7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B7B AND
    cpu.logicAnd(0x8u);
    goto L_018B7D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B7B AND
    cpu.logicAnd(0x8u);
    goto L_018B7D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B7Bu,0x018B7Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B7D BEQ -> $018B82
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B82; }
    goto L_018B7F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B7D BEQ -> $018B82
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B82; }
    goto L_018B7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B7Du,0x018B7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu, 6u, 3u, cpu.address("abs", 0x8898u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B7F JSR -> $018898 stack real
    { cpu.push16Value(hw,0x8B81u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B82u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8898u), 0x018B7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B82;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu, 6u, 3u, cpu.address("abs", 0x8898u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B7F JSR -> $018898 stack real
    { cpu.push16Value(hw,0x8B81u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B82u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8898u), 0x018B7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B82;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B7Fu,0x018B7Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B82u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B82u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B82u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B82 BRA -> $018BB0
    goto L_018BB0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B82u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B82u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B82 BRA -> $018BB0
    goto L_018BB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B82u,0x018B82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B84u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B84u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B84u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B84 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018B86;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B84u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B84u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B84 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018B86;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B84u,0x018B84u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B86u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B86u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B86u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B86 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B89;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B86u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B86u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B86 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B89;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B86u,0x018B86u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B89u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B89u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B89 BPL -> $018B90
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_018B90; }
    goto L_018B8B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B89u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B89 BPL -> $018B90
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_018B90; }
    goto L_018B8B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B89u,0x018B89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B8Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B8Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B8Bu, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B8B JSR -> $018E5F stack real
    { cpu.push16Value(hw,0x8B8Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B8Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x018B8Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B8E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B8Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B8Bu, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B8B JSR -> $018E5F stack real
    { cpu.push16Value(hw,0x8B8Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B8Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x018B8Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B8E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B8Bu,0x018B8Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B8Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B8Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B8Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B8E BRA -> $018B93
    goto L_018B93;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B8Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B8Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B8E BRA -> $018B93
    goto L_018B93;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B8Eu,0x018B8Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B90u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B90u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B90u, 5u, 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B90 STZ
    hw.write(cpu.address("absx", 0x1570u), 0, cpu.m8?8:16);
    goto L_018B93;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B90u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B90u, 5u, 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B90 STZ
    hw.write(cpu.address("absx", 0x1570u), 0, cpu.m8?8:16);
    goto L_018B93;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B90u,0x018B90u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B93u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B93u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B93u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B93 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B96;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B93u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B93u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B93 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B96;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B93u,0x018B93u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B96u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B96 AND
    cpu.logicAnd(0x2u);
    goto L_018B98;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B96 AND
    cpu.logicAnd(0x2u);
    goto L_018B98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B96u,0x018B96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B98u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B98u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B98 BEQ -> $018BB0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018BB0; }
    goto L_018B9A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B98u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B98 BEQ -> $018BB0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018BB0; }
    goto L_018B9A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B98u,0x018B98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B9Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Au, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B9A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B9D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Au, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B9A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B9D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B9Au,0x018B9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018B9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B9Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Du,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Du, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B9D ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16));
    goto L_018BA0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Du,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Du, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B9D ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16));
    goto L_018BA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B9Du,0x018B9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA0u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA0u, 4u + ((((0x1528u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BA0 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1528u), cpu.m8?8:16));
    goto L_018BA3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA0u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA0u, 4u + ((((0x1528u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BA0 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1528u), cpu.m8?8:16));
    goto L_018BA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BA0u,0x018BA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA3u, 4u + ((((0x1534u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BA3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1534u), cpu.m8?8:16));
    goto L_018BA6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA3u, 4u + ((((0x1534u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BA3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1534u), cpu.m8?8:16));
    goto L_018BA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BA3u,0x018BA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BA6 BNE -> $018BB0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_018BB0; }
    goto L_018BA8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BA6 BNE -> $018BB0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_018BB0; }
    goto L_018BA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BA6u,0x018BA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA8u, 6u, 3u, cpu.address("abs", 0x9098u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BA8 JSR -> $019098 stack real
    { cpu.push16Value(hw,0x8BAAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9098u), 0x018BA8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BAB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA8u, 6u, 3u, cpu.address("abs", 0x9098u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BA8 JSR -> $019098 stack real
    { cpu.push16Value(hw,0x8BAAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9098u), 0x018BA8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BA8u,0x018BA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BAB LDA
    cpu.setA(0x1u, 8);
    goto L_018BAD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BAB LDA
    cpu.setA(0x1u, 8);
    goto L_018BAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BABu,0x018BABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BADu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BADu, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BAD STA
    hw.write(cpu.address("absx", 0x151Cu), cpu.a, cpu.m8?8:16);
    goto L_018BB0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BADu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BADu, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BAD STA
    hw.write(cpu.address("absx", 0x151Cu), cpu.a, cpu.m8?8:16);
    goto L_018BB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BADu,0x018BADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB0u, 4u + ((((0x1528u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BB0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1528u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BB3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB0u, 4u + ((((0x1528u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BB0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1528u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BB0u,0x018BB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BB3 BEQ -> $018BBA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018BBA; }
    goto L_018BB5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BB3 BEQ -> $018BBA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018BBA; }
    goto L_018BB5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BB3u,0x018BB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB5u, 6u, 3u, cpu.address("abs", 0x8931u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BB5 JSR -> $018931 stack real
    { cpu.push16Value(hw,0x8BB7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BB8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8931u), 0x018BB5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BB8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB5u, 6u, 3u, cpu.address("abs", 0x8931u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BB5 JSR -> $018931 stack real
    { cpu.push16Value(hw,0x8BB7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BB8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8931u), 0x018BB5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BB8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BB5u,0x018BB5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BB8 BRA -> $018BBD
    goto L_018BBD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BB8 BRA -> $018BBD
    goto L_018BBD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BB8u,0x018BB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BBAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBAu, 6u, 3u, cpu.address("abs", 0xA7E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BBA JSR -> $01A7E4 stack real
    { cpu.push16Value(hw,0x8BBCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BBDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA7E4u), 0x018BBAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BBD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBAu, 6u, 3u, cpu.address("abs", 0xA7E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BBA JSR -> $01A7E4 stack real
    { cpu.push16Value(hw,0x8BBCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BBDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA7E4u), 0x018BBAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BBD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BBAu,0x018BBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BBDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBDu, 6u, 3u, cpu.address("abs", 0xA40Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BBD JSR -> $01A40D stack real
    { cpu.push16Value(hw,0x8BBFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BC0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA40Du), 0x018BBDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BC0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBDu, 6u, 3u, cpu.address("abs", 0xA40Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BBD JSR -> $01A40D stack real
    { cpu.push16Value(hw,0x8BBFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BC0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA40Du), 0x018BBDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BC0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BBDu,0x018BBDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u, 6u, 3u, cpu.address("abs", 0x9089u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BC0 JSR -> $019089 stack real
    { cpu.push16Value(hw,0x8BC2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BC3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9089u), 0x018BC0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BC3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u, 6u, 3u, cpu.address("abs", 0x9089u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BC0 JSR -> $019089 stack real
    { cpu.push16Value(hw,0x8BC2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BC3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9089u), 0x018BC0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BC3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BC0u,0x018BC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BC3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BC6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BC3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BC6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BC3u,0x018BC3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018BC6 PHA
    cpu.push("PHA", hw);
    goto L_018BC7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018BC6 PHA
    cpu.push("PHA", hw);
    goto L_018BC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BC6u,0x018BC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BC7 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15ACu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018BCA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BC7 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15ACu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018BCA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BC7u,0x018BC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BCA BEQ -> $018BDE
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x018BDEu,0x018BCAu); return; }
    goto L_018BCC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BCA BEQ -> $018BDE
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x018BDEu,0x018BCAu); return; }
    goto L_018BCC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BCAu,0x018BCAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BCC LDA
    cpu.setA(0x2u, 8);
    goto L_018BCE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BCC LDA
    cpu.setA(0x2u, 8);
    goto L_018BCE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BCCu,0x018BCCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BCE STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_018BD1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BCE STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_018BD1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BCEu,0x018BCEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BD1 LDA
    cpu.setA(0x0u, 8);
    goto L_018BD3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BD1 LDA
    cpu.setA(0x0u, 8);
    goto L_018BD3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BD1u,0x018BD1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018BD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BD3 CPY
    cpu.compareY(0x5u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BD5u,0x018BD3u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BD3 CPY
    cpu.compareY(0x5u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BD5u,0x018BD3u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BD3u,0x018BD3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_018AFC_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018AFCu: goto L_018AFC;
    case 0x018AFEu: goto L_018AFE;
    case 0x018B00u: goto L_018B00;
    case 0x018B03u: goto L_018B03;
    case 0x018B06u: goto L_018B06;
    case 0x018B09u: goto L_018B09;
    case 0x018B0Au: goto L_018B0A;
    case 0x018B0Du: goto L_018B0D;
    case 0x018B0Fu: goto L_018B0F;
    case 0x018B11u: goto L_018B11;
    case 0x018B14u: goto L_018B14;
    case 0x018B15u: goto L_018B15;
    case 0x018B18u: goto L_018B18;
    case 0x018B1Au: goto L_018B1A;
    case 0x018B1Bu: goto L_018B1B;
    case 0x018B1Cu: goto L_018B1C;
    case 0x018B1Fu: goto L_018B1F;
    case 0x018B22u: goto L_018B22;
    case 0x018B23u: goto L_018B23;
    case 0x018B26u: goto L_018B26;
    case 0x018B28u: goto L_018B28;
    case 0x018B29u: goto L_018B29;
    case 0x018B2Cu: goto L_018B2C;
    case 0x018B2Eu: goto L_018B2E;
    case 0x018B31u: goto L_018B31;
    case 0x018B32u: goto L_018B32;
    case 0x018B33u: goto L_018B33;
    case 0x018B36u: goto L_018B36;
    case 0x018B38u: goto L_018B38;
    case 0x018B3Au: goto L_018B3A;
    case 0x018B3Cu: goto L_018B3C;
    case 0x018B3Fu: goto L_018B3F;
    case 0x018B41u: goto L_018B41;
    case 0x018B43u: goto L_018B43;
    case 0x018B46u: goto L_018B46;
    case 0x018B49u: goto L_018B49;
    case 0x018B4Cu: goto L_018B4C;
    case 0x018B4Fu: goto L_018B4F;
    case 0x018B51u: goto L_018B51;
    case 0x018B54u: goto L_018B54;
    case 0x018B57u: goto L_018B57;
    case 0x018B59u: goto L_018B59;
    case 0x018B5Cu: goto L_018B5C;
    case 0x018B5Du: goto L_018B5D;
    case 0x018B5Fu: goto L_018B5F;
    case 0x018B61u: goto L_018B61;
    case 0x018B64u: goto L_018B64;
    case 0x018B66u: goto L_018B66;
    case 0x018B68u: goto L_018B68;
    case 0x018B6Bu: goto L_018B6B;
    case 0x018B6Cu: goto L_018B6C;
    case 0x018B6Fu: goto L_018B6F;
    case 0x018B70u: goto L_018B70;
    case 0x018B73u: goto L_018B73;
    case 0x018B75u: goto L_018B75;
    case 0x018B77u: goto L_018B77;
    case 0x018B7Au: goto L_018B7A;
    case 0x018B7Bu: goto L_018B7B;
    case 0x018B7Du: goto L_018B7D;
    case 0x018B7Fu: goto L_018B7F;
    case 0x018B82u: goto L_018B82;
    case 0x018B84u: goto L_018B84;
    case 0x018B86u: goto L_018B86;
    case 0x018B89u: goto L_018B89;
    case 0x018B8Bu: goto L_018B8B;
    case 0x018B8Eu: goto L_018B8E;
    case 0x018B90u: goto L_018B90;
    case 0x018B93u: goto L_018B93;
    case 0x018B96u: goto L_018B96;
    case 0x018B98u: goto L_018B98;
    case 0x018B9Au: goto L_018B9A;
    case 0x018B9Du: goto L_018B9D;
    case 0x018BA0u: goto L_018BA0;
    case 0x018BA3u: goto L_018BA3;
    case 0x018BA6u: goto L_018BA6;
    case 0x018BA8u: goto L_018BA8;
    case 0x018BABu: goto L_018BAB;
    case 0x018BADu: goto L_018BAD;
    case 0x018BB0u: goto L_018BB0;
    case 0x018BB3u: goto L_018BB3;
    case 0x018BB5u: goto L_018BB5;
    case 0x018BB8u: goto L_018BB8;
    case 0x018BBAu: goto L_018BBA;
    case 0x018BBDu: goto L_018BBD;
    case 0x018BC0u: goto L_018BC0;
    case 0x018BC3u: goto L_018BC3;
    case 0x018BC6u: goto L_018BC6;
    case 0x018BC7u: goto L_018BC7;
    case 0x018BCAu: goto L_018BCA;
    case 0x018BCCu: goto L_018BCC;
    case 0x018BCEu: goto L_018BCE;
    case 0x018BD1u: goto L_018BD1;
    case 0x018BD3u: goto L_018BD3;
    case 0x018BD5u: goto L_018BD5;
    case 0x018BD7u: goto L_018BD7;
    case 0x018BD8u: goto L_018BD8;
    case 0x018BDBu: goto L_018BDB;
    case 0x018BDEu: goto L_018BDE;
    case 0x018BE0u: goto L_018BE0;
    case 0x018BE3u: goto L_018BE3;
    case 0x018BE5u: goto L_018BE5;
    case 0x018BE7u: goto L_018BE7;
    case 0x018BEAu: goto L_018BEA;
    case 0x018BECu: goto L_018BEC;
    case 0x018BEFu: goto L_018BEF;
    case 0x018BF0u: goto L_018BF0;
    case 0x018BF2u: goto L_018BF2;
    case 0x018BF3u: goto L_018BF3;
    case 0x018BF5u: goto L_018BF5;
    case 0x018BF7u: goto L_018BF7;
    case 0x018BFAu: goto L_018BFA;
    case 0x018BFBu: goto L_018BFB;
    case 0x018BFDu: goto L_018BFD;
    case 0x018C00u: goto L_018C00;
    case 0x018C03u: goto L_018C03;
    case 0x018C04u: goto L_018C04;
    case 0x018C07u: goto L_018C07;
    case 0x018C08u: goto L_018C08;
    case 0x018C0Au: goto L_018C0A;
    case 0x018C0Cu: goto L_018C0C;
    case 0x018C0Eu: goto L_018C0E;
    case 0x018C10u: goto L_018C10;
    case 0x018C13u: goto L_018C13;
    case 0x018C14u: goto L_018C14;
    case 0x018C17u: goto L_018C17;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018AFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AFC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018AFE;
L_018AFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AFE BEQ -> $018B0A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B0A; }
    goto L_018B00;
L_018B00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B00u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B00u, 6u, 3u, cpu.address("abs", 0xA7E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B00 JSR -> $01A7E4 stack real
    { cpu.push16Value(hw,0x8B02u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B03u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA7E4u), 0x018B00u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B03;
L_018B03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B03u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B03u,0x018B03u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B03u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B03u, 6u, 3u, cpu.address("abs", 0xA40Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B03 JSR -> $01A40D stack real
    { cpu.push16Value(hw,0x8B05u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B06u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA40Du), 0x018B03u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B06;
L_018B06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B06u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B06u,0x018B06u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B06u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B06u, 6u, 3u, cpu.address("abs", 0x8BC3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B06 JSR -> $018BC3 stack real
    { cpu.push16Value(hw,0x8B08u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B09u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8BC3u), 0x018B06u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B09;
L_018B09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B09u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B09u,0x018B09u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B09u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B09u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B09 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018B09u);return;} hw.unresolvedReturn(0x018B09u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_018B0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Au, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B0A JSR -> $01800E stack real
    { cpu.push16Value(hw,0x8B0Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B0Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0x018B0Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B0D;
L_018B0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B0Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B0Du,0x018B0Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B0D BEQ -> $018B2E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B2E; }
    goto L_018B0F;
L_018B0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B0Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B0F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018B11;
L_018B11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B11u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B11u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B11 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B14;
L_018B14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B14u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B14u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B14 LSR
    cpu.lsrA();
    goto L_018B15;
L_018B15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B15u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B15u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B15 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x157Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018B18;
L_018B18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B18u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B18 BCC -> $018B1C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_018B1C; }
    goto L_018B1A;
L_018B1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B1A INY
    cpu.inc('Y');
    goto L_018B1B;
L_018B1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B1B INY
    cpu.inc('Y');
    goto L_018B1C;
L_018B1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Cu, 4u + ((((0x88ECu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88ECu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B1C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88ECu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B1F;
L_018B1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Fu,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B1Fu, 4u + ((((0x15B8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15B8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B1F EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0x15B8u), cpu.m8?8:16));
    goto L_018B22;
L_018B22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B22u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B22 ASL
    cpu.aslA();
    goto L_018B23;
L_018B23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B23u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B23u, 4u + ((((0x88ECu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88ECu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B23 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88ECu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B26;
L_018B26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B26u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B26 BCC -> $018B2C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_018B2C; }
    goto L_018B28;
L_018B28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B28u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B28u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B28 CLC
    cpu.setFlag('C', false);
    goto L_018B29;
L_018B29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B29u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B29u, 4u + ((((0x15B8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15B8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B29 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x15B8u), cpu.m8?8:16));
    goto L_018B2C;
L_018B2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B2C STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_018B2E;
L_018B2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Eu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B2Eu, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B2E LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x157Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018B31;
L_018B31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B31u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B31 TYA
    cpu.transfer("TYA");
    goto L_018B32;
L_018B32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B32u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B32 INC
    cpu.inc('A');
    goto L_018B33;
L_018B33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B33u,cpu,0x3Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B33u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B33 AND
    cpu.logicAnd(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16));
    goto L_018B36;
L_018B36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B36u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B36 AND
    cpu.logicAnd(0x3u);
    goto L_018B38;
L_018B38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B38u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B38 BEQ -> $018B3C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B3C; }
    goto L_018B3A;
L_018B3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Au,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B3A STZ
    hw.write(cpu.address("dpx", 0xB6u), 0, cpu.m8?8:16);
    goto L_018B3C;
L_018B3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Cu, 6u, 3u, cpu.address("abs", 0x8014u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B3C JSR -> $018014 stack real
    { cpu.push16Value(hw,0x8B3Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B3Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8014u), 0x018B3Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B3F;
L_018B3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B3Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B3Fu,0x018B3Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B3F BEQ -> $018B43
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B43; }
    goto L_018B41;
L_018B41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B41u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B41u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B41 STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_018B43;
L_018B43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B43u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B43u, 6u, 3u, cpu.address("abs", 0xAC31u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B43 JSR -> $01AC31 stack real
    { cpu.push16Value(hw,0x8B45u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B46u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC31u), 0x018B43u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B46;
L_018B46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B46u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B46u,0x018B46u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B46u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B46u, 6u, 3u, cpu.address("abs", 0x9032u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B46 JSR -> $019032 stack real
    { cpu.push16Value(hw,0x8B48u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B49u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9032u), 0x018B46u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B49;
L_018B49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B49u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B49u,0x018B49u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B49u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B49u, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B49 JSR -> $018E5F stack real
    { cpu.push16Value(hw,0x8B4Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B4Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x018B49u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B4C;
L_018B4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B4Cu,0x018B4Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B4C JSR -> $01800E stack real
    { cpu.push16Value(hw,0x8B4Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B4Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0x018B4Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B4F;
L_018B4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B4Fu,0x018B4Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B4F BEQ -> $018B84
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B84; }
    goto L_018B51;
L_018B51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B51u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B51u, 6u, 3u, cpu.address("abs", 0x9A04u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B51 JSR -> $019A04 stack real
    { cpu.push16Value(hw,0x8B53u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B54u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9A04u), 0x018B51u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B54;
L_018B54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B54u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B54u,0x018B54u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B54u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B54u, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B54 STZ
    hw.write(cpu.address("absx", 0x151Cu), 0, cpu.m8?8:16);
    goto L_018B57;
L_018B57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B57u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B57u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B57 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018B59;
L_018B59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B59u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B59u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B59 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B5C;
L_018B5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018B5C PHA
    cpu.push("PHA", hw);
    goto L_018B5D;
L_018B5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B5D AND
    cpu.logicAnd(0x4u);
    goto L_018B5F;
L_018B5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B5F BEQ -> $018B7A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B7A; }
    goto L_018B61;
L_018B61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B61u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B61u, 4u + ((((0x1570u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B61 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1570u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B64;
L_018B64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B64u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B64u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B64 AND
    cpu.logicAnd(0x7Fu);
    goto L_018B66;
L_018B66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B66u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B66 BNE -> $018B7A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B7A; }
    goto L_018B68;
L_018B68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B68u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B68u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B68 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B6B;
L_018B6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018B6B PHA
    cpu.push("PHA", hw);
    goto L_018B6C;
L_018B6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Cu, 6u, 3u, cpu.address("abs", 0x857Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B6C JSR -> $01857C stack real
    { cpu.push16Value(hw,0x8B6Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B6Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x857Cu), 0x018B6Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B6F;
L_018B6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B6Fu,0x018B6Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Fu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018B6F PLA
    cpu.pop("PLA", hw);
    goto L_018B70;
L_018B70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B70u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B70u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B70 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16));
    goto L_018B73;
L_018B73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B73u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B73u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B73 BEQ -> $018B7A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B7A; }
    goto L_018B75;
L_018B75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B75u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B75 LDA
    cpu.setA(0x8u, 8);
    goto L_018B77;
L_018B77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B77u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B77u, 5u, 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B77 STA
    hw.write(cpu.address("absx", 0x15ACu), cpu.a, cpu.m8?8:16);
    goto L_018B7A;
L_018B7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018B7A PLA
    cpu.pop("PLA", hw);
    goto L_018B7B;
L_018B7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B7B AND
    cpu.logicAnd(0x8u);
    goto L_018B7D;
L_018B7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B7D BEQ -> $018B82
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018B82; }
    goto L_018B7F;
L_018B7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Fu, 6u, 3u, cpu.address("abs", 0x8898u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B7F JSR -> $018898 stack real
    { cpu.push16Value(hw,0x8B81u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B82u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8898u), 0x018B7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B82;
L_018B82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B82u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B82u,0x018B82u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B82u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B82u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B82 BRA -> $018BB0
    goto L_018BB0;
L_018B84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B84u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B84u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B84 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018B86;
L_018B86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B86u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B86u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B86 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B89;
L_018B89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B89u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B89 BPL -> $018B90
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_018B90; }
    goto L_018B8B;
L_018B8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B8Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B8Bu, 6u, 3u, cpu.address("abs", 0x8E5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018B8B JSR -> $018E5F stack real
    { cpu.push16Value(hw,0x8B8Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B8Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E5Fu), 0x018B8Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018B8E;
L_018B8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B8Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B8Eu,0x018B8Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B8Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B8Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B8E BRA -> $018B93
    goto L_018B93;
L_018B90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B90u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B90u, 5u, 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B90 STZ
    hw.write(cpu.address("absx", 0x1570u), 0, cpu.m8?8:16);
    goto L_018B93;
L_018B93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B93u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B93u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B93 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B96;
L_018B96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B96 AND
    cpu.logicAnd(0x2u);
    goto L_018B98;
L_018B98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B98u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B98 BEQ -> $018BB0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018BB0; }
    goto L_018B9A;
L_018B9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Au, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B9A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018B9D;
L_018B9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Du,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B9Du, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018B9D ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16));
    goto L_018BA0;
L_018BA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA0u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA0u, 4u + ((((0x1528u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BA0 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1528u), cpu.m8?8:16));
    goto L_018BA3;
L_018BA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA3u, 4u + ((((0x1534u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BA3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1534u), cpu.m8?8:16));
    goto L_018BA6;
L_018BA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BA6 BNE -> $018BB0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_018BB0; }
    goto L_018BA8;
L_018BA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BA8u, 6u, 3u, cpu.address("abs", 0x9098u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BA8 JSR -> $019098 stack real
    { cpu.push16Value(hw,0x8BAAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9098u), 0x018BA8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BAB;
L_018BAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BABu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BABu,0x018BABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BAB LDA
    cpu.setA(0x1u, 8);
    goto L_018BAD;
L_018BAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BADu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BADu, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BAD STA
    hw.write(cpu.address("absx", 0x151Cu), cpu.a, cpu.m8?8:16);
    goto L_018BB0;
L_018BB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB0u, 4u + ((((0x1528u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BB0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1528u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BB3;
L_018BB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BB3 BEQ -> $018BBA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018BBA; }
    goto L_018BB5;
L_018BB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB5u, 6u, 3u, cpu.address("abs", 0x8931u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BB5 JSR -> $018931 stack real
    { cpu.push16Value(hw,0x8BB7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BB8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8931u), 0x018BB5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BB8;
L_018BB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BB8u,0x018BB8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BB8 BRA -> $018BBD
    goto L_018BBD;
L_018BBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBAu, 6u, 3u, cpu.address("abs", 0xA7E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BBA JSR -> $01A7E4 stack real
    { cpu.push16Value(hw,0x8BBCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BBDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA7E4u), 0x018BBAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BBD;
L_018BBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BBDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BBDu,0x018BBDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBDu, 6u, 3u, cpu.address("abs", 0xA40Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BBD JSR -> $01A40D stack real
    { cpu.push16Value(hw,0x8BBFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BC0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA40Du), 0x018BBDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BC0;
L_018BC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BC0u,0x018BC0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u, 6u, 3u, cpu.address("abs", 0x9089u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BC0 JSR -> $019089 stack real
    { cpu.push16Value(hw,0x8BC2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BC3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9089u), 0x018BC0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BC3;
L_018BC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BC3u,0x018BC3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC3u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BC3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BC6;
L_018BC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018BC6 PHA
    cpu.push("PHA", hw);
    goto L_018BC7;
L_018BC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BC7 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15ACu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018BCA;
L_018BCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BCA BEQ -> $018BDE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018BDE; }
    goto L_018BCC;
L_018BCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BCC LDA
    cpu.setA(0x2u, 8);
    goto L_018BCE;
L_018BCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BCE STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_018BD1;
L_018BD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BD1 LDA
    cpu.setA(0x0u, 8);
    goto L_018BD3;
L_018BD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BD3 CPY
    cpu.compareY(0x5u);
    goto L_018BD5;
L_018BD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD5u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BD5 BCC -> $018BD8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_018BD8; }
    goto L_018BD7;
L_018BD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD7u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BD7 INC
    cpu.inc('A');
    goto L_018BD8;
L_018BD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD8u,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD8u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BD8 EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16));
    goto L_018BDB;
L_018BDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDBu, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BDB STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_018BDE;
L_018BDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BDE LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018BE0;
L_018BE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u, 4u + ((((0x88F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x88F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BE0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x88F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BE3;
L_018BE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BE3 AND
    cpu.logicAnd(0x40u);
    goto L_018BE5;
L_018BE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BE5 BNE -> $018BEC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_018BEC; }
    goto L_018BE7;
L_018BE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018BE7 JSR -> $019F0D stack real
    { cpu.push16Value(hw,0x8BE9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8BEAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x018BE7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018BEA;
L_018BEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BEAu,0x018BEAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BEA BRA -> $018C13
    goto L_018C13;
L_018BEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BECu, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BEC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BEF;
L_018BEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BEF LSR
    cpu.lsrA();
    goto L_018BF0;
L_018BF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BF0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BF2;
L_018BF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF2u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018BF2 PHA
    cpu.push("PHA", hw);
    goto L_018BF3;
L_018BF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BF3 SBC
    cpu.sbc(0xFu);
    goto L_018BF5;
L_018BF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BF5 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_018BF7;
L_018BF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF7u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BF7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018BFA;
L_018BFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018BFA PHA
    cpu.push("PHA", hw);
    goto L_018BFB;
L_018BFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BFB SBC
    cpu.sbc(0x0u);
    goto L_018BFD;
L_018BFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BFDu, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018BFD STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_018C00;
L_018C00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C00u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C00u, 6u, 3u, cpu.address("abs", 0x9D67u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018C00 JSR -> $019D67 stack real
    { cpu.push16Value(hw,0x8C02u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C03u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D67u), 0x018C00u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018C03;
L_018C03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C03u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C03u,0x018C03u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C03u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018C03 PLA
    cpu.pop("PLA", hw);
    goto L_018C04;
L_018C04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018C04 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_018C07;
L_018C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018C07 PLA
    cpu.pop("PLA", hw);
    goto L_018C08;
L_018C08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C08u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C08u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018C08 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_018C0A;
L_018C0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018C0A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018C0C;
L_018C0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018C0C CMP
    cpu.compareA(0x8u);
    goto L_018C0E;
L_018C0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018C0E BCC -> $018C13
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_018C13; }
    goto L_018C10;
L_018C10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C10u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C10u, 6u, 3u, cpu.address("abs", 0x9E28u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018C10 JSR -> $019E28 stack real
    { cpu.push16Value(hw,0x8C12u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C13u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E28u), 0x018C10u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018C13;
L_018C13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C13u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C13u,0x018C13u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C13u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018C13 PLA
    cpu.pop("PLA", hw);
    goto L_018C14;
L_018C14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C14u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C14u, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018C14 STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_018C17;
L_018C17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C17u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018C17 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018C17u);return;} hw.unresolvedReturn(0x018C17u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_019435_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019435u: goto L_019435;
    case 0x019437u: goto L_019437;
    case 0x01943Au: goto L_01943A;
    case 0x01943Du: goto L_01943D;
    case 0x019440u: goto L_019440;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9435u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9435u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019435 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019437;
L_019437:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9437u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9437u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9437u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019437 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01943A;
L_01943A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x943Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x943Au,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x943Au, 4u + ((((0x9134u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9134u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01943A ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x9134u), cpu.m8?8:16));
    goto L_01943D;
L_01943D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x943Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x943Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x943Du, 5u, 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01943D STA
    hw.write(cpu.address("absx", 0x1588u), cpu.a, cpu.m8?8:16);
    goto L_019440;
L_019440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9440u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9440u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019440 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x019440u);return;} hw.unresolvedReturn(0x019440u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01A847_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A847u: goto L_01A847;
    case 0x01A84Bu: goto L_01A84B;
    case 0x01A84Eu: goto L_01A84E;
    case 0x01A851u: goto L_01A851;
    case 0x01A853u: goto L_01A853;
    case 0x01A855u: goto L_01A855;
    case 0x01A857u: goto L_01A857;
    case 0x01A85Au: goto L_01A85A;
    case 0x01A85Eu: goto L_01A85E;
    case 0x01A861u: goto L_01A861;
    case 0x01A863u: goto L_01A863;
    case 0x01A865u: goto L_01A865;
    case 0x01A868u: goto L_01A868;
    case 0x01A86Bu: goto L_01A86B;
    case 0x01A86Du: goto L_01A86D;
    case 0x01A870u: goto L_01A870;
    case 0x01A872u: goto L_01A872;
    case 0x01A874u: goto L_01A874;
    case 0x01A877u: goto L_01A877;
    case 0x01A87Au: goto L_01A87A;
    case 0x01A87Cu: goto L_01A87C;
    case 0x01A87Du: goto L_01A87D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A847:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA847u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA847u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA847u, 8u, 4u, 0x01AB6Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A847 JSL -> $01AB6F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA84Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA84Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB6Fu, 0x01A847u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A84B;
L_01A84B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA84Bu,0x01A84Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Bu, 6u, 3u, cpu.address("abs", 0x18D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A84B INC
    cpu.incMem(hw, cpu.address("abs", 0x18D2u), cpu.m8?8:16);
    goto L_01A84E;
L_01A84E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Eu, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A84E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18D2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A851;
L_01A851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA851u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA851u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A851 CMP
    cpu.compareA(0x8u);
    goto L_01A853;
L_01A853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA853u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA853u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A853 BCC -> $01A85A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01A85A; }
    goto L_01A855;
L_01A855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A855 LDA
    cpu.setA(0x8u, 8);
    goto L_01A857;
L_01A857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA857u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA857u, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A857 STA
    hw.write(cpu.address("abs", 0x18D2u), cpu.a, cpu.m8?8:16);
    goto L_01A85A;
L_01A85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Au, 8u, 4u, 0x02ACE5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A85A JSL -> $02ACE5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA85Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA85Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACE5u, 0x01A85Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A85E;
L_01A85E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA85Eu,0x01A85Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Eu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Eu, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A85E LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x18D2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A861;
L_01A861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA861u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA861u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A861 CPY
    cpu.compareY(0x8u);
    goto L_01A863;
L_01A863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A863 BCS -> $01A86B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01A86B; }
    goto L_01A865;
L_01A865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u, 4u + ((((0xA61Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA61Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A865 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA61Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A868;
L_01A868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A868 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_01A86B;
L_01A86B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A86B LDA
    cpu.setA(0x2u, 8);
    goto L_01A86D;
L_01A86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Du, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A86D STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_01A870;
L_01A870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA870u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA870u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A870 LDA
    cpu.setA(0xD0u, 8);
    goto L_01A872;
L_01A872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA872u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA872u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A872 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_01A874;
L_01A874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A874 JSR -> $01AD30 stack real
    { cpu.push16Value(hw,0xA876u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA877u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0x01A874u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A877;
L_01A877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA877u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA877u,0x01A877u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u, 4u + ((((0xA839u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA839u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A877 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA839u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A87A;
L_01A87A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A87A STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_01A87C;
L_01A87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A87C CLC
    cpu.setFlag('C', false);
    goto L_01A87D;
L_01A87D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A87D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A87Du);return;} hw.unresolvedReturn(0x01A87Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01E309_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01E309u: goto L_01E309;
    case 0x01E30Cu: goto L_01E30C;
    case 0x01E30Fu: goto L_01E30F;
    case 0x01E311u: goto L_01E311;
    case 0x01E313u: goto L_01E313;
    case 0x01E315u: goto L_01E315;
    case 0x01E317u: goto L_01E317;
    case 0x01E31Au: goto L_01E31A;
    case 0x01E31Cu: goto L_01E31C;
    case 0x01E31Du: goto L_01E31D;
    case 0x01E320u: goto L_01E320;
    case 0x01E323u: goto L_01E323;
    case 0x01E325u: goto L_01E325;
    case 0x01E327u: goto L_01E327;
    case 0x01E329u: goto L_01E329;
    case 0x01E32Bu: goto L_01E32B;
    case 0x01E32Du: goto L_01E32D;
    case 0x01E330u: goto L_01E330;
    case 0x01E332u: goto L_01E332;
    case 0x01E334u: goto L_01E334;
    case 0x01E336u: goto L_01E336;
    case 0x01E339u: goto L_01E339;
    case 0x01E33Bu: goto L_01E33B;
    case 0x01E33Du: goto L_01E33D;
    case 0x01E33Fu: goto L_01E33F;
    case 0x01E343u: goto L_01E343;
    case 0x01E345u: goto L_01E345;
    case 0x01E347u: goto L_01E347;
    case 0x01E349u: goto L_01E349;
    case 0x01E34Bu: goto L_01E34B;
    case 0x01E34Cu: goto L_01E34C;
    case 0x01E34Du: goto L_01E34D;
    case 0x01E34Eu: goto L_01E34E;
    case 0x01E34Fu: goto L_01E34F;
    case 0x01E351u: goto L_01E351;
    case 0x01E352u: goto L_01E352;
    case 0x01E355u: goto L_01E355;
    case 0x01E358u: goto L_01E358;
    case 0x01E35Bu: goto L_01E35B;
    case 0x01E35Eu: goto L_01E35E;
    case 0x01E363u: goto L_01E363;
    case 0x01E365u: goto L_01E365;
    case 0x01E366u: goto L_01E366;
    case 0x01E367u: goto L_01E367;
    case 0x01E369u: goto L_01E369;
    case 0x01E36Bu: goto L_01E36B;
    case 0x01E36Eu: goto L_01E36E;
    case 0x01E370u: goto L_01E370;
    case 0x01E373u: goto L_01E373;
    case 0x01E376u: goto L_01E376;
    case 0x01E379u: goto L_01E379;
    case 0x01E37Bu: goto L_01E37B;
    case 0x01E37Eu: goto L_01E37E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01E309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE309u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE309u, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E309 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E30C;
L_01E30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Cu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Cu, 4u + ((((0x15D0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E30C ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15D0u), cpu.m8?8:16));
    goto L_01E30F;
L_01E30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E30F BNE -> $01E343
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E343; }
    goto L_01E311;
L_01E311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE311u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE311u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E311 INC
    cpu.incMem(hw, cpu.address("dpx", 0xC2u), cpu.m8?8:16);
    goto L_01E313;
L_01E313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE313u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE313u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E313 LDA
    cpu.setA(0xB0u, 8);
    goto L_01E315;
L_01E315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE315u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE315u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E315 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_01E317;
L_01E317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE317u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE317u, 6u, 3u, cpu.address("abs", 0x80CBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E317 JSR -> $0180CB stack real
    { cpu.push16Value(hw,0xE319u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE31Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80CBu), 0x01E317u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E31A;
L_01E31A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE31Au,0x01E31Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E31A BNE -> $01E320
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E320; }
    goto L_01E31C;
L_01E31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E31C TAY
    cpu.transfer("TAY");
    goto L_01E31D;
L_01E31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Du, 6u, 3u, cpu.address("abs", 0x99E1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E31D JSR -> $0199E1 stack real
    { cpu.push16Value(hw,0xE31Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE320u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99E1u), 0x01E31Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E320;
L_01E320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE320u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE320u,0x01E320u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE320u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE320u, 6u, 3u, cpu.address("abs", 0x857Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E320 JSR -> $01857C stack real
    { cpu.push16Value(hw,0xE322u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE323u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x857Cu), 0x01E320u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E323;
L_01E323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE323u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE323u,0x01E323u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE323u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE323u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E323 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E325;
L_01E325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE325u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE325u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E325 CMP
    cpu.compareA(0x4Eu);
    goto L_01E327;
L_01E327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE327u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE327u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E327 BNE -> $01E343
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E343; }
    goto L_01E329;
L_01E329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE329u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE329u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E329 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E32B;
L_01E32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E32B STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_01E32D;
L_01E32D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Du, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E32D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E330;
L_01E330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E330 STA
    hw.write(cpu.address("dp", 0x9Bu), cpu.a, cpu.m8?8:16);
    goto L_01E332;
L_01E332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE332u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE332u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E332 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E334;
L_01E334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE334u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE334u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E334 STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_01E336;
L_01E336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE336u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE336u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E336 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E339;
L_01E339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE339u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE339u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E339 STA
    hw.write(cpu.address("dp", 0x99u), cpu.a, cpu.m8?8:16);
    goto L_01E33B;
L_01E33B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E33B LDA
    cpu.setA(0x8u, 8);
    goto L_01E33D;
L_01E33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E33D STA
    hw.write(cpu.address("dp", 0x9Cu), cpu.a, cpu.m8?8:16);
    goto L_01E33F;
L_01E33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Fu, 8u, 4u, 0x00BEB0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01E33F JSL -> $00BEB0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE342u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE343u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00BEB0u, 0x01E33Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E343;
L_01E343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE343u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE343u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE343u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E343 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E345;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE343u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE343u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E343 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E345;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE343u,0x01E343u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01E345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE345u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE345u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE345u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E345 CMP
    cpu.compareA(0x4Du);
    goto L_01E347;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE345u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE345u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E345 CMP
    cpu.compareA(0x4Du);
    goto L_01E347;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE345u,0x01E345u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01E347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE347u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE347u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E347 BNE -> $01E363
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E363; }
    goto L_01E349;
L_01E349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E349 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E34B;
L_01E34B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E34B LSR
    cpu.lsrA();
    goto L_01E34C;
L_01E34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E34C LSR
    cpu.lsrA();
    goto L_01E34D;
L_01E34D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E34D LSR
    cpu.lsrA();
    goto L_01E34E;
L_01E34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E34E LSR
    cpu.lsrA();
    goto L_01E34F;
L_01E34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E34F AND
    cpu.logicAnd(0x1u);
    goto L_01E351;
L_01E351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE351u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE351u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E351 TAY
    cpu.transfer("TAY");
    goto L_01E352;
L_01E352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE352u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE352u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE352u, 4u + ((((0xE35Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE35Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E352 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE35Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E355;
L_01E355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE355u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE355u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E355 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_01E358;
L_01E358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE358u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE358u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE358u, 4u + ((((0xE361u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE361u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E358 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE361u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E35B;
L_01E35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Bu, 6u, 3u, cpu.address("abs", 0x9CF3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E35B JSR -> $019CF3 stack real
    { cpu.push16Value(hw,0xE35Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE35Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CF3u), 0x01E35Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E35E;
L_01E35E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE35Eu,0x01E35Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E35E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01E35Eu);return;} hw.unresolvedReturn(0x01E35Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01E363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE363u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE363u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E363 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E365;
L_01E365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE365u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE365u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E365 ASL
    cpu.aslA();
    goto L_01E366;
L_01E366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE366u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE366u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E366 ASL
    cpu.aslA();
    goto L_01E367;
L_01E367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE367u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE367u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E367 AND
    cpu.logicAnd(0xC0u);
    goto L_01E369;
L_01E369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE369u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE369u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE369u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E369 ORA
    cpu.logicOr(0x31u);
    goto L_01E36B;
L_01E36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Bu, 5u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E36B STA
    hw.write(cpu.address("absx", 0x15F6u), cpu.a, cpu.m8?8:16);
    goto L_01E36E;
L_01E36E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE36Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E36E LDA
    cpu.setA(0x3u, 8);
    goto L_01E370;
L_01E370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE370u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE370u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E370 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_01E373;
L_01E373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE373u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE373u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE373u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E373 JSR -> $019F0D stack real
    { cpu.push16Value(hw,0xE375u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE376u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x01E373u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E376;
L_01E376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE376u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE376u,0x01E376u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE376u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE376u, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E376 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E379;
L_01E379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE379u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE379u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E379 AND
    cpu.logicAnd(0x3Fu);
    goto L_01E37B;
L_01E37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Bu, 5u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E37B STA
    hw.write(cpu.address("absx", 0x15F6u), cpu.a, cpu.m8?8:16);
    goto L_01E37E;
L_01E37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E37E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01E37Eu);return;} hw.unresolvedReturn(0x01E37Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01E309_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01E309u: goto L_01E309;
    case 0x01E30Cu: goto L_01E30C;
    case 0x01E30Fu: goto L_01E30F;
    case 0x01E311u: goto L_01E311;
    case 0x01E313u: goto L_01E313;
    case 0x01E315u: goto L_01E315;
    case 0x01E317u: goto L_01E317;
    case 0x01E31Au: goto L_01E31A;
    case 0x01E31Cu: goto L_01E31C;
    case 0x01E31Du: goto L_01E31D;
    case 0x01E320u: goto L_01E320;
    case 0x01E323u: goto L_01E323;
    case 0x01E325u: goto L_01E325;
    case 0x01E327u: goto L_01E327;
    case 0x01E329u: goto L_01E329;
    case 0x01E32Bu: goto L_01E32B;
    case 0x01E32Du: goto L_01E32D;
    case 0x01E330u: goto L_01E330;
    case 0x01E332u: goto L_01E332;
    case 0x01E334u: goto L_01E334;
    case 0x01E336u: goto L_01E336;
    case 0x01E339u: goto L_01E339;
    case 0x01E33Bu: goto L_01E33B;
    case 0x01E33Du: goto L_01E33D;
    case 0x01E33Fu: goto L_01E33F;
    case 0x01E343u: goto L_01E343;
    case 0x01E345u: goto L_01E345;
    case 0x01E347u: goto L_01E347;
    case 0x01E349u: goto L_01E349;
    case 0x01E34Bu: goto L_01E34B;
    case 0x01E34Cu: goto L_01E34C;
    case 0x01E34Du: goto L_01E34D;
    case 0x01E34Eu: goto L_01E34E;
    case 0x01E34Fu: goto L_01E34F;
    case 0x01E351u: goto L_01E351;
    case 0x01E352u: goto L_01E352;
    case 0x01E355u: goto L_01E355;
    case 0x01E358u: goto L_01E358;
    case 0x01E35Bu: goto L_01E35B;
    case 0x01E35Eu: goto L_01E35E;
    case 0x01E363u: goto L_01E363;
    case 0x01E365u: goto L_01E365;
    case 0x01E366u: goto L_01E366;
    case 0x01E367u: goto L_01E367;
    case 0x01E369u: goto L_01E369;
    case 0x01E36Bu: goto L_01E36B;
    case 0x01E36Eu: goto L_01E36E;
    case 0x01E370u: goto L_01E370;
    case 0x01E373u: goto L_01E373;
    case 0x01E376u: goto L_01E376;
    case 0x01E379u: goto L_01E379;
    case 0x01E37Bu: goto L_01E37B;
    case 0x01E37Eu: goto L_01E37E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01E309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE309u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE309u, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E309 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E30C;
L_01E30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Cu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Cu, 4u + ((((0x15D0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E30C ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15D0u), cpu.m8?8:16));
    goto L_01E30F;
L_01E30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E30F BNE -> $01E343
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E343; }
    goto L_01E311;
L_01E311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE311u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE311u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E311 INC
    cpu.incMem(hw, cpu.address("dpx", 0xC2u), cpu.m8?8:16);
    goto L_01E313;
L_01E313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE313u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE313u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E313 LDA
    cpu.setA(0xB0u, 8);
    goto L_01E315;
L_01E315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE315u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE315u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E315 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_01E317;
L_01E317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE317u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE317u, 6u, 3u, cpu.address("abs", 0x80CBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E317 JSR -> $0180CB stack real
    { cpu.push16Value(hw,0xE319u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE31Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80CBu), 0x01E317u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E31A;
L_01E31A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE31Au,0x01E31Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E31A BNE -> $01E320
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E320; }
    goto L_01E31C;
L_01E31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E31C TAY
    cpu.transfer("TAY");
    goto L_01E31D;
L_01E31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Du, 6u, 3u, cpu.address("abs", 0x99E1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E31D JSR -> $0199E1 stack real
    { cpu.push16Value(hw,0xE31Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE320u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99E1u), 0x01E31Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E320;
L_01E320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE320u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE320u,0x01E320u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE320u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE320u, 6u, 3u, cpu.address("abs", 0x857Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E320 JSR -> $01857C stack real
    { cpu.push16Value(hw,0xE322u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE323u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x857Cu), 0x01E320u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E323;
L_01E323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE323u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE323u,0x01E323u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE323u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE323u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E323 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E325;
L_01E325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE325u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE325u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E325 CMP
    cpu.compareA(0x4Eu);
    goto L_01E327;
L_01E327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE327u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE327u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E327 BNE -> $01E343
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E343; }
    goto L_01E329;
L_01E329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE329u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE329u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E329 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E32B;
L_01E32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E32B STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_01E32D;
L_01E32D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Du, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E32D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E330;
L_01E330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E330 STA
    hw.write(cpu.address("dp", 0x9Bu), cpu.a, cpu.m8?8:16);
    goto L_01E332;
L_01E332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE332u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE332u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E332 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E334;
L_01E334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE334u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE334u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E334 STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_01E336;
L_01E336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE336u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE336u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E336 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E339;
L_01E339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE339u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE339u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E339 STA
    hw.write(cpu.address("dp", 0x99u), cpu.a, cpu.m8?8:16);
    goto L_01E33B;
L_01E33B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E33B LDA
    cpu.setA(0x8u, 8);
    goto L_01E33D;
L_01E33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E33D STA
    hw.write(cpu.address("dp", 0x9Cu), cpu.a, cpu.m8?8:16);
    goto L_01E33F;
L_01E33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Fu, 8u, 4u, 0x00BEB0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01E33F JSL -> $00BEB0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE342u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE343u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00BEB0u, 0x01E33Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E343;
L_01E343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE343u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE343u,0x01E343u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE343u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE343u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E343 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E345;
L_01E345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE345u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE345u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E345 CMP
    cpu.compareA(0x4Du);
    goto L_01E347;
L_01E347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE347u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE347u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E347 BNE -> $01E363
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01E363; }
    goto L_01E349;
L_01E349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E349 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E34B;
L_01E34B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E34B LSR
    cpu.lsrA();
    goto L_01E34C;
L_01E34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E34C LSR
    cpu.lsrA();
    goto L_01E34D;
L_01E34D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E34D LSR
    cpu.lsrA();
    goto L_01E34E;
L_01E34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E34E LSR
    cpu.lsrA();
    goto L_01E34F;
L_01E34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E34F AND
    cpu.logicAnd(0x1u);
    goto L_01E351;
L_01E351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE351u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE351u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E351 TAY
    cpu.transfer("TAY");
    goto L_01E352;
L_01E352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE352u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE352u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE352u, 4u + ((((0xE35Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE35Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E352 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE35Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E355;
L_01E355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE355u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE355u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E355 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_01E358;
L_01E358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE358u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE358u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE358u, 4u + ((((0xE361u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE361u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E358 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE361u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E35B;
L_01E35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Bu, 6u, 3u, cpu.address("abs", 0x9CF3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E35B JSR -> $019CF3 stack real
    { cpu.push16Value(hw,0xE35Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE35Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CF3u), 0x01E35Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E35E;
L_01E35E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE35Eu,0x01E35Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E35E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01E35Eu);return;} hw.unresolvedReturn(0x01E35Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01E363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE363u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE363u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E363 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E365;
L_01E365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE365u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE365u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E365 ASL
    cpu.aslA();
    goto L_01E366;
L_01E366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE366u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE366u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E366 ASL
    cpu.aslA();
    goto L_01E367;
L_01E367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE367u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE367u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E367 AND
    cpu.logicAnd(0xC0u);
    goto L_01E369;
L_01E369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE369u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE369u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE369u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E369 ORA
    cpu.logicOr(0x31u);
    goto L_01E36B;
L_01E36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Bu, 5u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E36B STA
    hw.write(cpu.address("absx", 0x15F6u), cpu.a, cpu.m8?8:16);
    goto L_01E36E;
L_01E36E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE36Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E36E LDA
    cpu.setA(0x3u, 8);
    goto L_01E370;
L_01E370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE370u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE370u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E370 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_01E373;
L_01E373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE373u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE373u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE373u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E373 JSR -> $019F0D stack real
    { cpu.push16Value(hw,0xE375u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE376u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x01E373u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E376;
L_01E376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE376u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE376u,0x01E376u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE376u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE376u, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E376 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E379;
L_01E379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE379u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE379u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E379 AND
    cpu.logicAnd(0x3Fu);
    goto L_01E37B;
L_01E37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Bu, 5u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E37B STA
    hw.write(cpu.address("absx", 0x15F6u), cpu.a, cpu.m8?8:16);
    goto L_01E37E;
L_01E37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E37E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01E37Eu);return;} hw.unresolvedReturn(0x01E37Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01EA8F_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01EA8Fu: goto L_01EA8F;
    case 0x01EA92u: goto L_01EA92;
    case 0x01EA95u: goto L_01EA95;
    case 0x01EA97u: goto L_01EA97;
    case 0x01EA9Au: goto L_01EA9A;
    case 0x01EA9Du: goto L_01EA9D;
    case 0x01EA9Fu: goto L_01EA9F;
    case 0x01EAA1u: goto L_01EAA1;
    case 0x01EAA3u: goto L_01EAA3;
    case 0x01EAA5u: goto L_01EAA5;
    case 0x01EAA7u: goto L_01EAA7;
    case 0x01EAA9u: goto L_01EAA9;
    case 0x01EAABu: goto L_01EAAB;
    case 0x01EAADu: goto L_01EAAD;
    case 0x01EAAFu: goto L_01EAAF;
    case 0x01EAB1u: goto L_01EAB1;
    case 0x01EAB2u: goto L_01EAB2;
    case 0x01EAB3u: goto L_01EAB3;
    case 0x01EAB4u: goto L_01EAB4;
    case 0x01EAB5u: goto L_01EAB5;
    case 0x01EAB6u: goto L_01EAB6;
    case 0x01EAB7u: goto L_01EAB7;
    case 0x01EAB9u: goto L_01EAB9;
    case 0x01EABBu: goto L_01EABB;
    case 0x01EABEu: goto L_01EABE;
    case 0x01EAC0u: goto L_01EAC0;
    case 0x01EAC3u: goto L_01EAC3;
    case 0x01EAC6u: goto L_01EAC6;
    case 0x01EAC9u: goto L_01EAC9;
    case 0x01EACBu: goto L_01EACB;
    case 0x01EACDu: goto L_01EACD;
    case 0x01EAD0u: goto L_01EAD0;
    case 0x01EAD3u: goto L_01EAD3;
    case 0x01EAD6u: goto L_01EAD6;
    case 0x01EAD7u: goto L_01EAD7;
    case 0x01EAD9u: goto L_01EAD9;
    case 0x01EADBu: goto L_01EADB;
    case 0x01EADDu: goto L_01EADD;
    case 0x01EADFu: goto L_01EADF;
    case 0x01EAE2u: goto L_01EAE2;
    case 0x01EAE4u: goto L_01EAE4;
    case 0x01EAE6u: goto L_01EAE6;
    case 0x01EAE8u: goto L_01EAE8;
    case 0x01EAEAu: goto L_01EAEA;
    case 0x01EAECu: goto L_01EAEC;
    case 0x01EAEEu: goto L_01EAEE;
    case 0x01EAF0u: goto L_01EAF0;
    case 0x01EAF3u: goto L_01EAF3;
    case 0x01EAF5u: goto L_01EAF5;
    case 0x01EAF7u: goto L_01EAF7;
    case 0x01EAF9u: goto L_01EAF9;
    case 0x01EAFBu: goto L_01EAFB;
    case 0x01EAFEu: goto L_01EAFE;
    case 0x01EB00u: goto L_01EB00;
    case 0x01EB02u: goto L_01EB02;
    case 0x01EB04u: goto L_01EB04;
    case 0x01EB06u: goto L_01EB06;
    case 0x01EB08u: goto L_01EB08;
    case 0x01EB0Au: goto L_01EB0A;
    case 0x01EB0Cu: goto L_01EB0C;
    case 0x01EB0Fu: goto L_01EB0F;
    case 0x01EB11u: goto L_01EB11;
    case 0x01EB14u: goto L_01EB14;
    case 0x01EB16u: goto L_01EB16;
    case 0x01EB18u: goto L_01EB18;
    case 0x01EB1Au: goto L_01EB1A;
    case 0x01EB1Cu: goto L_01EB1C;
    case 0x01EB1Eu: goto L_01EB1E;
    case 0x01EB21u: goto L_01EB21;
    case 0x01EB23u: goto L_01EB23;
    case 0x01EB25u: goto L_01EB25;
    case 0x01EB27u: goto L_01EB27;
    case 0x01EB2Au: goto L_01EB2A;
    case 0x01EB2Cu: goto L_01EB2C;
    case 0x01EB2Eu: goto L_01EB2E;
    case 0x01EB31u: goto L_01EB31;
    case 0x01EB33u: goto L_01EB33;
    case 0x01EB36u: goto L_01EB36;
    case 0x01EB38u: goto L_01EB38;
    case 0x01EB3Au: goto L_01EB3A;
    case 0x01EB3Cu: goto L_01EB3C;
    case 0x01EB3Eu: goto L_01EB3E;
    case 0x01EB3Fu: goto L_01EB3F;
    case 0x01EB40u: goto L_01EB40;
    case 0x01EB41u: goto L_01EB41;
    case 0x01EB43u: goto L_01EB43;
    case 0x01EB44u: goto L_01EB44;
    case 0x01EB45u: goto L_01EB45;
    case 0x01EB48u: goto L_01EB48;
    case 0x01EB4Au: goto L_01EB4A;
    case 0x01EB4Cu: goto L_01EB4C;
    case 0x01EB4Eu: goto L_01EB4E;
    case 0x01EB51u: goto L_01EB51;
    case 0x01EB53u: goto L_01EB53;
    case 0x01EB54u: goto L_01EB54;
    case 0x01EB57u: goto L_01EB57;
    case 0x01EB59u: goto L_01EB59;
    case 0x01EB5Bu: goto L_01EB5B;
    case 0x01EB5Eu: goto L_01EB5E;
    case 0x01EB61u: goto L_01EB61;
    case 0x01EB64u: goto L_01EB64;
    case 0x01EB66u: goto L_01EB66;
    case 0x01EB67u: goto L_01EB67;
    case 0x01EB69u: goto L_01EB69;
    case 0x01EB6Bu: goto L_01EB6B;
    case 0x01EB6Du: goto L_01EB6D;
    case 0x01EB6Fu: goto L_01EB6F;
    case 0x01EB72u: goto L_01EB72;
    case 0x01EB75u: goto L_01EB75;
    case 0x01EB78u: goto L_01EB78;
    case 0x01EB7Au: goto L_01EB7A;
    case 0x01EB7Du: goto L_01EB7D;
    case 0x01EB7Fu: goto L_01EB7F;
    case 0x01EB81u: goto L_01EB81;
    case 0x01EB82u: goto L_01EB82;
    case 0x01EB85u: goto L_01EB85;
    case 0x01EB87u: goto L_01EB87;
    case 0x01EB8Au: goto L_01EB8A;
    case 0x01EB8Du: goto L_01EB8D;
    case 0x01EB90u: goto L_01EB90;
    case 0x01EB93u: goto L_01EB93;
    case 0x01EB95u: goto L_01EB95;
    case 0x01EB97u: goto L_01EB97;
    case 0x01EB99u: goto L_01EB99;
    case 0x01EB9Au: goto L_01EB9A;
    case 0x01EB9Du: goto L_01EB9D;
    case 0x01EB9Fu: goto L_01EB9F;
    case 0x01EBA2u: goto L_01EBA2;
    case 0x01EBA4u: goto L_01EBA4;
    case 0x01EBA7u: goto L_01EBA7;
    case 0x01EBA9u: goto L_01EBA9;
    case 0x01EBABu: goto L_01EBAB;
    case 0x01EBADu: goto L_01EBAD;
    case 0x01EBB0u: goto L_01EBB0;
    case 0x01EBB1u: goto L_01EBB1;
    case 0x01EBB3u: goto L_01EBB3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01EA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Fu, 4u, 3u, cpu.address("abs", 0x18E8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA8F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EA92;
L_01EA92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA92u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA92u, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA92 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13C6u), cpu.m8?8:16));
    goto L_01EA95;
L_01EA95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA95u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA95u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA95 BEQ -> $01EA9A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EA9A; }
    goto L_01EA97;
L_01EA97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA97u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA97u, 3u, 3u, cpu.address("abs", 0xEB48u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA97 JMP -> $01EB48
    goto L_01EB48;
L_01EA9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Au, 4u, 3u, cpu.address("abs", 0x18DCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA9A STZ
    hw.write(cpu.address("abs", 0x18DCu), 0, cpu.m8?8:16);
    goto L_01EA9D;
L_01EA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA9D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EA9F;
L_01EA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EA9F CMP
    cpu.compareA(0x2u);
    goto L_01EAA1;
L_01EAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAA1 BCC -> $01EAA7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01EAA7; }
    goto L_01EAA3;
L_01EAA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAA3 LDA
    cpu.setA(0x30u, 8);
    goto L_01EAA5;
L_01EAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAA5 BRA -> $01EAB2
    goto L_01EAB2;
L_01EAA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAA7 LDY
    cpu.setY(0x0u, 8);
    goto L_01EAA9;
L_01EAA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAA9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAAB;
L_01EAAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAABu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAAB BEQ -> $01EADF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EADF; }
    goto L_01EAAD;
L_01EAAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAADu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAAD BPL -> $01EAB2
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01EAB2; }
    goto L_01EAAF;
L_01EAAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAAFu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAAF EOR
    cpu.logicXor(0xFFu);
    goto L_01EAB1;
L_01EAB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB1u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB1 INC
    cpu.inc('A');
    goto L_01EAB2;
L_01EAB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB2 LSR
    cpu.lsrA();
    goto L_01EAB3;
L_01EAB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB3 LSR
    cpu.lsrA();
    goto L_01EAB4;
L_01EAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB4 LSR
    cpu.lsrA();
    goto L_01EAB5;
L_01EAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB5 LSR
    cpu.lsrA();
    goto L_01EAB6;
L_01EAB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB6 TAY
    cpu.transfer("TAY");
    goto L_01EAB7;
L_01EAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAB9;
L_01EAB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAB9 BNE -> $01EAD0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EAD0; }
    goto L_01EABB;
L_01EABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEABBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEABBu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEABBu, 7u, 3u, cpu.address("absx", 0x1570u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EABB DEC
    cpu.decMem(hw, cpu.address("absx", 0x1570u), cpu.m8?8:16);
    goto L_01EABE;
L_01EABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEABEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEABEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EABE BPL -> $01EAD0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01EAD0; }
    goto L_01EAC0;
L_01EAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC0u, 4u + ((((0xEDF5u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEDF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAC0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEDF5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAC3;
L_01EAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC3u, 5u, 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAC3 STA
    hw.write(cpu.address("absx", 0x1570u), cpu.a, cpu.m8?8:16);
    goto L_01EAC6;
L_01EAC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC6u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC6u, 6u, 3u, cpu.address("abs", 0x18ADu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAC6 DEC
    cpu.decMem(hw, cpu.address("abs", 0x18ADu), cpu.m8?8:16);
    goto L_01EAC9;
L_01EAC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAC9 BPL -> $01EAD0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01EAD0; }
    goto L_01EACB;
L_01EACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEACBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEACBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EACB LDA
    cpu.setA(0x2u, 8);
    goto L_01EACD;
L_01EACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEACDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEACDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEACDu, 4u, 3u, cpu.address("abs", 0x18ADu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EACD STA
    hw.write(cpu.address("abs", 0x18ADu), cpu.a, cpu.m8?8:16);
    goto L_01EAD0;
L_01EAD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD0u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD0u, 4u, 3u, cpu.address("abs", 0x18ADu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAD0 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x18ADu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EAD3;
L_01EAD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD3u, 4u + ((((0xEDEEu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEDEEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAD3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEDEEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAD6;
L_01EAD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAD6 TAY
    cpu.transfer("TAY");
    goto L_01EAD7;
L_01EAD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAD7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAD9;
L_01EAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAD9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAD9 CMP
    cpu.compareA(0x2u);
    goto L_01EADB;
L_01EADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEADBu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEADBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EADB BCS -> $01EB2E
    if (cpu.c) { hw.addCpuInternalCycles(2u); goto L_01EB2E; }
    goto L_01EADD;
L_01EADD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEADDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEADDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEADDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EADD BRA -> $01EAE2
    goto L_01EAE2;
L_01EADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEADFu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEADFu, 5u, 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EADF STZ
    hw.write(cpu.address("absx", 0x1570u), 0, cpu.m8?8:16);
    goto L_01EAE2;
L_01EAE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAE2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAE4;
L_01EAE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAE4 BEQ -> $01EAF0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EAF0; }
    goto L_01EAE6;
L_01EAE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAE6 LDY
    cpu.setY(0x2u, 8);
    goto L_01EAE8;
L_01EAE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAE8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAE8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAEA;
L_01EAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAEAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAEA BPL -> $01EAF0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01EAF0; }
    goto L_01EAEC;
L_01EAEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAECu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAEC LDY
    cpu.setY(0x5u, 8);
    goto L_01EAEE;
L_01EAEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAEEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAEEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAEE BRA -> $01EAF0
    goto L_01EAF0;
L_01EAF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF0u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAF0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAF3;
L_01EAF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAF3 BEQ -> $01EAF7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EAF7; }
    goto L_01EAF5;
L_01EAF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAF5 LDY
    cpu.setY(0x3u, 8);
    goto L_01EAF7;
L_01EAF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAF7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAF9;
L_01EAF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAF9 BNE -> $01EB21
    if (!cpu.z) { hw.addCpuInternalCycles(2u); goto L_01EB21; }
    goto L_01EAFB;
L_01EAFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAFBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAFBu, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAFB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EAFE;
L_01EAFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAFEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EAFE BEQ -> $01EB0C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB0C; }
    goto L_01EB00;
L_01EB00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB00u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB00 LDY
    cpu.setY(0x7u, 8);
    goto L_01EB02;
L_01EB02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB02u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB02u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB02 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB04;
L_01EB04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB04u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB04 AND
    cpu.logicAnd(0x8u);
    goto L_01EB06;
L_01EB06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB06u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB06 BEQ -> $01EB0A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB0A; }
    goto L_01EB08;
L_01EB08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB08u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB08 LDY
    cpu.setY(0x6u, 8);
    goto L_01EB0A;
L_01EB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB0A BRA -> $01EB21
    goto L_01EB21;
L_01EB0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Cu, 4u, 3u, cpu.address("abs", 0x18AFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB0C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18AFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB0F;
L_01EB0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB0F BEQ -> $01EB16
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB16; }
    goto L_01EB11;
L_01EB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB11u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB11u, 6u, 3u, cpu.address("abs", 0x18AFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB11 DEC
    cpu.decMem(hw, cpu.address("abs", 0x18AFu), cpu.m8?8:16);
    goto L_01EB14;
L_01EB14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB14u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB14u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB14 BRA -> $01EB1C
    goto L_01EB1C;
L_01EB16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB16u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB16u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB16 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB18;
L_01EB18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB18u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB18 AND
    cpu.logicAnd(0x4u);
    goto L_01EB1A;
L_01EB1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB1A BEQ -> $01EB21
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB21; }
    goto L_01EB1C;
L_01EB1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB1C LDY
    cpu.setY(0x4u, 8);
    goto L_01EB1E;
L_01EB1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Eu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Eu, 6u, 3u, cpu.address("abs", 0x18DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB1E INC
    cpu.incMem(hw, cpu.address("abs", 0x18DCu), cpu.m8?8:16);
    goto L_01EB21;
L_01EB21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB21u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB21u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB21 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB23;
L_01EB23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB23u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB23 CMP
    cpu.compareA(0x1u);
    goto L_01EB25;
L_01EB25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB25u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB25 BEQ -> $01EB2E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB2E; }
    goto L_01EB27;
L_01EB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB27u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB27u, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB27 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB2A;
L_01EB2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB2Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB2A BNE -> $01EB2E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB2E; }
    goto L_01EB2C;
L_01EB2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB2Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB2C LDY
    cpu.setY(0x4u, 8);
    goto L_01EB2E;
L_01EB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB2Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB2Eu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB2E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB31;
L_01EB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB31u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB31 BEQ -> $01EB44
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB44; }
    goto L_01EB33;
L_01EB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB33u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB33u, 4u, 3u, cpu.address("abs", 0x1419u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB33 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1419u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB36;
L_01EB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB36u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB36 CMP
    cpu.compareA(0x1u);
    goto L_01EB38;
L_01EB38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB38u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB38 BNE -> $01EB44
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB44; }
    goto L_01EB3A;
L_01EB3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB3A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB3C;
L_01EB3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB3C AND
    cpu.logicAnd(0x8u);
    goto L_01EB3E;
L_01EB3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB3E LSR
    cpu.lsrA();
    goto L_01EB3F;
L_01EB3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB3Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB3F LSR
    cpu.lsrA();
    goto L_01EB40;
L_01EB40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB40u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB40 LSR
    cpu.lsrA();
    goto L_01EB41;
L_01EB41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB41u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB41 ADC
    cpu.adc(0x8u);
    goto L_01EB43;
L_01EB43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB43u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB43 TAY
    cpu.transfer("TAY");
    goto L_01EB44;
L_01EB44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB44u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB44u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB44 TYA
    cpu.transfer("TYA");
    goto L_01EB45;
L_01EB45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB45u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB45u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB45 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_01EB48;
L_01EB48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB48u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB48u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB48 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB4A;
L_01EB4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB4A CMP
    cpu.compareA(0x1u);
    goto L_01EB4C;
L_01EB4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB4C BNE -> $01EB97
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB97; }
    goto L_01EB4E;
L_01EB4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Eu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB4Eu, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB4E LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x157Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EB51;
L_01EB51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB51u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB51u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB51 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB53;
L_01EB53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB53u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB53 CLC
    cpu.setFlag('C', false);
    goto L_01EB54;
L_01EB54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB54u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB54u, 4u + ((((0xEDF1u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEDF1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB54 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xEDF1u), cpu.m8?8:16));
    goto L_01EB57;
L_01EB57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB57u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB57u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB57 STA
    hw.write(cpu.address("dpx", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_01EB59;
L_01EB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB59u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB59u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB59 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB5B;
L_01EB5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB5Bu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB5Bu, 4u + ((((0xEDF3u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEDF3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB5B ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xEDF3u), cpu.m8?8:16));
    goto L_01EB5E;
L_01EB5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB5Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB5Eu, 5u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB5E STA
    hw.write(cpu.address("absx", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_01EB61;
L_01EB61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB61u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB61u, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB61 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1602u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EB64;
L_01EB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB64u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB64u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB64 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB66;
L_01EB66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB66u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB66 CLC
    cpu.setFlag('C', false);
    goto L_01EB67;
L_01EB67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB67u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB67 ADC
    cpu.adc(0x10u);
    goto L_01EB69;
L_01EB69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB69u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB69u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB69 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_01EB6B;
L_01EB6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB6B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB6D;
L_01EB6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB6D ADC
    cpu.adc(0x0u);
    goto L_01EB6F;
L_01EB6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB6Fu, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB6F STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_01EB72;
L_01EB72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB72u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB72u, 4u + ((((0xEDE4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEDE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB72 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEDE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB75;
L_01EB75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB75u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB75u, 4u, 3u, cpu.address("abs", 0x188Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB75 STA
    hw.write(cpu.address("abs", 0x188Bu), cpu.a, cpu.m8?8:16);
    goto L_01EB78;
L_01EB78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB78u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB78 LDA
    cpu.setA(0x1u, 8);
    goto L_01EB7A;
L_01EB7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB7Au,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB7Au, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB7A LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1602u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EB7D;
L_01EB7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB7Du,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB7D CPY
    cpu.compareY(0x3u);
    goto L_01EB7F;
L_01EB7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB7Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB7F BNE -> $01EB82
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EB82; }
    goto L_01EB81;
L_01EB81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB81u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB81u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB81 INC
    cpu.inc('A');
    goto L_01EB82;
L_01EB82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB82u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB82u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB82 STA
    hw.write(cpu.address("abs", 0x187Au), cpu.a, cpu.m8?8:16);
    goto L_01EB85;
L_01EB85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB85u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB85 LDA
    cpu.setA(0x1u, 8);
    goto L_01EB87;
L_01EB87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB87u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB87u, 4u, 3u, cpu.address("abs", 0x0DC1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB87 STA
    hw.write(cpu.address("abs", 0xDC1u), cpu.a, cpu.m8?8:16);
    goto L_01EB8A;
L_01EB8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB8Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB8Au, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB8A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB8D;
L_01EB8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB8Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB8Du, 4u, 3u, cpu.address("abs", 0x13C7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB8D STA
    hw.write(cpu.address("abs", 0x13C7u), cpu.a, cpu.m8?8:16);
    goto L_01EB90;
L_01EB90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB90u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB90u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB90 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB93;
L_01EB93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB93u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB93 EOR
    cpu.logicXor(0x1u);
    goto L_01EB95;
L_01EB95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB95u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB95u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB95 STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_01EB97;
L_01EB97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB97u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB97u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB97 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB99;
L_01EB99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB99u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB99u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EB99 PHA
    cpu.push("PHA", hw);
    goto L_01EB9A;
L_01EB9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB9Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB9Au, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB9A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EB9D;
L_01EB9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB9Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB9D BEQ -> $01EBAD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EBAD; }
    goto L_01EB9F;
L_01EB9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB9Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB9Fu, 4u, 3u, cpu.address("abs", 0x1419u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EB9F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1419u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EBA2;
L_01EBA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EBA2 BEQ -> $01EBAD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EBAD; }
    goto L_01EBA4;
L_01EBA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA4u, 4u, 3u, cpu.address("abs", 0x1405u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EBA4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1405u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EBA7;
L_01EBA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EBA7 BNE -> $01EBB0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EBB0; }
    goto L_01EBA9;
L_01EBA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EBA9 LDA
    cpu.setA(0x10u, 8);
    goto L_01EBAB;
L_01EBAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBABu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBABu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EBAB STA
    hw.write(cpu.address("dp", 0x64u), cpu.a, cpu.m8?8:16);
    goto L_01EBAD;
L_01EBAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBADu, 6u, 3u, cpu.address("abs", 0xEE61u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01EBAD JSR -> $01EE61 stack real
    { cpu.push16Value(hw,0xEBAFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEBB0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEE61u), 0x01EBADu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01EBB0;
L_01EBB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBB0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB0u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EBB0 PLA
    cpu.pop("PLA", hw);
    goto L_01EBB1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB0u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EBB0 PLA
    cpu.pop("PLA", hw);
    goto L_01EBB1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEBB0u,0x01EBB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EBB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBB1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EBB1 STA
    hw.write(cpu.address("dp", 0x64u), cpu.a, cpu.m8?8:16);
    goto L_01EBB3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EBB1 STA
    hw.write(cpu.address("dp", 0x64u), cpu.a, cpu.m8?8:16);
    goto L_01EBB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEBB1u,0x01EBB1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EBB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBB3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01EBB3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01EBB3u);return;} hw.unresolvedReturn(0x01EBB3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBB3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01EBB3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01EBB3u);return;} hw.unresolvedReturn(0x01EBB3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEBB3u,0x01EBB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_01EF18_E1M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01F03Eu: goto L_01F03E;
    case 0x01F041u: goto L_01F041;
    case 0x01F042u: goto L_01F042;
    case 0x01F044u: goto L_01F044;
    case 0x01F045u: goto L_01F045;
    case 0x01F046u: goto L_01F046;
    case 0x01F048u: goto L_01F048;
    case 0x01F049u: goto L_01F049;
    case 0x01F04Au: goto L_01F04A;
    case 0x01F04Bu: goto L_01F04B;
    case 0x01F04Cu: goto L_01F04C;
    case 0x01F04Du: goto L_01F04D;
    case 0x01F04Fu: goto L_01F04F;
    case 0x01F051u: goto L_01F051;
    case 0x01F052u: goto L_01F052;
    case 0x01F054u: goto L_01F054;
    case 0x01F057u: goto L_01F057;
    case 0x01F059u: goto L_01F059;
    case 0x01F05Au: goto L_01F05A;
    case 0x01F05Bu: goto L_01F05B;
    case 0x01F05Cu: goto L_01F05C;
    case 0x01F05Eu: goto L_01F05E;
    case 0x01F060u: goto L_01F060;
    case 0x01F063u: goto L_01F063;
    case 0x01F065u: goto L_01F065;
    case 0x01F067u: goto L_01F067;
    case 0x01F068u: goto L_01F068;
    case 0x01F06Au: goto L_01F06A;
    case 0x01F06Cu: goto L_01F06C;
    case 0x01F06Eu: goto L_01F06E;
    case 0x01F06Fu: goto L_01F06F;
    case 0x01F071u: goto L_01F071;
    case 0x01F073u: goto L_01F073;
    case 0x01F074u: goto L_01F074;
    case 0x01F076u: goto L_01F076;
    case 0x01F078u: goto L_01F078;
    case 0x01F079u: goto L_01F079;
    case 0x01F07Du: goto L_01F07D;
    case 0x01F080u: goto L_01F080;
    case 0x01F082u: goto L_01F082;
    case 0x01F083u: goto L_01F083;
    case 0x01F087u: goto L_01F087;
    case 0x01F08Au: goto L_01F08A;
    case 0x01F08Cu: goto L_01F08C;
    case 0x01F08Fu: goto L_01F08F;
    case 0x01F090u: goto L_01F090;
    case 0x01F093u: goto L_01F093;
    case 0x01F096u: goto L_01F096;
    case 0x01F098u: goto L_01F098;
    case 0x01F09Bu: goto L_01F09B;
    case 0x01F09Du: goto L_01F09D;
    case 0x01F0A0u: goto L_01F0A0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01F03E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF03Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Eu, 6u, 3u, cpu.address("absy", 0x0302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F03E STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01F041;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Eu, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F03E STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01F041;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Eu, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F03E STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01F041;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF03Eu,0x01F03Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF041u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF041u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF041u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F041 PLA
    cpu.pop("PLA", hw);
    goto L_01F042;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF041u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF041u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01F041 PLA
    cpu.pop("PLA", hw);
    goto L_01F042;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF041u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF041u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01F041 PLA
    cpu.pop("PLA", hw);
    goto L_01F042;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF041u,0x01F041u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF042u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF042u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF042u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F042 CMP
    cpu.compareA(0xB00Fu);
    goto L_01F045;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF042u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF042u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F042 CMP
    cpu.compareA(0xFu);
    goto L_01F044;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF042u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF042u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F042 CMP
    cpu.compareA(0xFu);
    goto L_01F044;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF042u,0x01F042u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF044u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF044u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF044u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F044 BCS -> $01F0A0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01F0A0; }
    goto L_01F046;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF044u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF044u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F044 BCS -> $01F0A0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01F0A0; }
    goto L_01F046;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF044u,0x01F044u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF045u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF045u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F045 PHY
    cpu.push("PHY", hw);
    goto L_01F046;
L_01F046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF046u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF046u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF046u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F046 CMP
    cpu.compareA(0x9005u);
    goto L_01F049;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF046u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF046u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F046 CMP
    cpu.compareA(0x5u);
    goto L_01F048;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF046u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF046u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F046 CMP
    cpu.compareA(0x5u);
    goto L_01F048;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF046u,0x01F046u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF048u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF048u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF048u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F048 BCC -> $01F0A0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01F0A0; }
    goto L_01F04A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF048u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF048u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F048 BCC -> $01F0A0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01F0A0; }
    goto L_01F04A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF048u,0x01F048u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF049u,cpu,0x56u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF049u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F049 LSR
    cpu.lsrMem(hw, cpu.address("dpx", 0xE9u), cpu.m8?8:16);
    goto L_01F04B;
L_01F04A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF04Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F04A SBC
    cpu.sbc(0x5u);
    goto L_01F04C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F04A SBC
    cpu.sbc(0x5u);
    goto L_01F04C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF04Au,0x01F04Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F04B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF04Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Bu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F04B ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xBCu), cpu.m8?8:16));
    goto L_01F04D;
L_01F04C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF04Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Cu, 5u + 1u, 3u, cpu.address("absx", 0x157Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F04C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x157Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01F04F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Cu, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F04C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x157Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01F04F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF04Cu,0x01F04Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF04Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Du,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Du, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xF015u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $01F04D JMP (F015,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xF015u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x01F04Du); return; }
L_01F04F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF04Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F04F BEQ -> $01F054
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F054; }
    goto L_01F051;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F04F BEQ -> $01F054
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F054; }
    goto L_01F051;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF04Fu,0x01F04Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF051u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF051u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF051u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F051 CLC
    cpu.setFlag('C', false);
    goto L_01F052;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF051u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF051u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F051 CLC
    cpu.setFlag('C', false);
    goto L_01F052;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF051u,0x01F051u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF052u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF052u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF052u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F052 ADC
    cpu.adc(0xAu);
    goto L_01F054;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF052u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF052u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F052 ADC
    cpu.adc(0xAu);
    goto L_01F054;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF052u,0x01F052u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF054u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF054u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF054u, 5u + 1u, 3u, cpu.address("absx", 0x1602u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F054 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1602u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01F057;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF054u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF054u, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F054 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1602u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01F057;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF054u,0x01F054u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF057u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF057u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF057u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F057 CPY
    cpu.compareY(0xD00Au);
    goto L_01F05A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF057u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF057u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F057 CPY
    cpu.compareY(0xAu);
    goto L_01F059;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF057u,0x01F057u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF059u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF059u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F059 BNE -> $01F05E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F05E; }
    goto L_01F05B;
L_01F05A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF05Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Au,cpu,0x03u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Au, 4u, 2u, cpu.addressStack(0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F05A ORA
    cpu.logicOr(hw.readW(cpu.addressStack(0x18u), cpu.m8?8:16));
    goto L_01F05C;
L_01F05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF05Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F05B CLC
    cpu.setFlag('C', false);
    goto L_01F05C;
L_01F05C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF05Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F05C ADC
    cpu.adc(0x14u);
    goto L_01F05E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F05C ADC
    cpu.adc(0x14u);
    goto L_01F05E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF05Cu,0x01F05Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F05E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF05Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F05E STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_01F060;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F05E STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_01F060;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF05Eu,0x01F05Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF060u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF060u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF060u, 6u, 3u, cpu.address("abs", 0x80CBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F060 JSR -> $0180CB stack real
    { cpu.push16Value(hw,0xF062u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF063u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80CBu), 0x01F060u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01F063;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF060u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF060u, 6u, 3u, cpu.address("abs", 0x80CBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F060 JSR -> $0180CB stack real
    { cpu.push16Value(hw,0xF062u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF063u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80CBu), 0x01F060u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01F063;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF060u,0x01F060u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF063u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF063u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF063u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F063 BNE -> $01F0A0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F0A0; }
    goto L_01F065;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF063u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF063u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F063 BNE -> $01F0A0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F0A0; }
    goto L_01F065;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF063u,0x01F063u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF065u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF065u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF065u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F065 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F067;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF065u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF065u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F065 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F067;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF065u,0x01F065u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF067u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF067u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF067u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F067 SEC
    cpu.setFlag('C', true);
    goto L_01F068;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF067u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF067u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F067 SEC
    cpu.setFlag('C', true);
    goto L_01F068;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF067u,0x01F067u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF068u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF068u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF068u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F068 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_01F06A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF068u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF068u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F068 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_01F06A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF068u,0x01F068u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F06A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF06Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F06A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_01F06C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F06A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_01F06C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF06Au,0x01F06Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF06Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F06C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F06E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F06C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F06E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF06Cu,0x01F06Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F06E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF06Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F06E SEC
    cpu.setFlag('C', true);
    goto L_01F06F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F06E SEC
    cpu.setFlag('C', true);
    goto L_01F06F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF06Eu,0x01F06Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF06Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Fu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F06F SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_01F071;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Fu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F06F SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_01F071;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF06Fu,0x01F06Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F071:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF071u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF071u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF071u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F071 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_01F073;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF071u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF071u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F071 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_01F073;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF071u,0x01F071u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF073u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF073u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF073u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F073 PHX
    cpu.push("PHX", hw);
    goto L_01F074;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF073u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF073u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01F073 PHX
    cpu.push("PHX", hw);
    goto L_01F074;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF073u,0x01F073u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF074u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF074u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF074u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F074 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01F076;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF074u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF074u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F074 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01F076;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF074u,0x01F074u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF076u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF076u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF076u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F076 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F078;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF076u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF076u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F076 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F078;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF076u,0x01F076u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF078u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF078u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF078u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F078 CLC
    cpu.setFlag('C', false);
    goto L_01F079;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF078u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF078u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F078 CLC
    cpu.setFlag('C', false);
    goto L_01F079;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF078u,0x01F078u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF079u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF079u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF079u, 5u, 4u, ((0x03C176u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F079 ADC
    cpu.adc(hw.readW(((0x3C176u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_01F07D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF079u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF079u, 5u, 4u, ((0x03C176u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F079 ADC
    cpu.adc(hw.readW(((0x3C176u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_01F07D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF079u,0x01F079u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F07D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF07Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF07Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF07Du, 4u, 3u, cpu.address("abs", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F07D STA
    hw.write(cpu.address("abs", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_01F080;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF07Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF07Du, 4u, 3u, cpu.address("abs", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F07D STA
    hw.write(cpu.address("abs", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_01F080;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF07Du,0x01F07Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF080u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF080u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF080u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F080 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F082;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF080u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF080u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F080 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F082;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF080u,0x01F080u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F082:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF082u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF082u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF082u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F082 CLC
    cpu.setFlag('C', false);
    goto L_01F083;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF082u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF082u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F082 CLC
    cpu.setFlag('C', false);
    goto L_01F083;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF082u,0x01F082u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF083u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF083u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF083u, 5u, 4u, ((0x03C19Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F083 ADC
    cpu.adc(hw.readW(((0x3C19Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_01F087;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF083u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF083u, 5u, 4u, ((0x03C19Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F083 ADC
    cpu.adc(hw.readW(((0x3C19Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_01F087;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF083u,0x01F083u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF087u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF087u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF087u, 4u, 3u, cpu.address("abs", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F087 STA
    hw.write(cpu.address("abs", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_01F08A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF087u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF087u, 4u, 3u, cpu.address("abs", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F087 STA
    hw.write(cpu.address("abs", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_01F08A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF087u,0x01F087u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F08A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF08Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF08Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF08Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F08A LDA
    cpu.setA(0x3Fu, 8);
    goto L_01F08C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF08Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF08Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F08A LDA
    cpu.setA(0x3Fu, 8);
    goto L_01F08C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF08Au,0x01F08Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F08C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF08Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF08Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF08Cu, 4u, 3u, cpu.address("abs", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F08C STA
    hw.write(cpu.address("abs", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01F08F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF08Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF08Cu, 4u, 3u, cpu.address("abs", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F08C STA
    hw.write(cpu.address("abs", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01F08F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF08Cu,0x01F08Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F08F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF08Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF08Fu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF08Fu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F08F PLX
    cpu.pop("PLX", hw);
    goto L_01F090;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF08Fu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF08Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01F08F PLX
    cpu.pop("PLX", hw);
    goto L_01F090;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF08Fu,0x01F08Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF090u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF090u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF090u, 5u + 1u, 3u, cpu.address("absx", 0x15EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F090 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01F093;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF090u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF090u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F090 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01F093;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF090u,0x01F090u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF093u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF093u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF093u, 4u + 1u, 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F093 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x303u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F096;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF093u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF093u, 4u + ((((0x0303u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F093 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x303u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F096;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF093u,0x01F093u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF096u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF096u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF096u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F096 ORA
    cpu.logicOr(0x1u);
    goto L_01F098;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF096u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF096u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F096 ORA
    cpu.logicOr(0x1u);
    goto L_01F098;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF096u,0x01F096u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF098u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF098u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF098u, 4u, 3u, cpu.address("abs", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F098 STA
    hw.write(cpu.address("abs", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_01F09B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF098u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF098u, 4u, 3u, cpu.address("abs", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F098 STA
    hw.write(cpu.address("abs", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_01F09B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF098u,0x01F098u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F09B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF09Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF09Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF09Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F09B LDA
    cpu.setA(0x0u, 8);
    goto L_01F09D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF09Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF09Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F09B LDA
    cpu.setA(0x0u, 8);
    goto L_01F09D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF09Bu,0x01F09Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF09Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF09Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF09Du, 4u, 3u, cpu.address("abs", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F09D STA
    hw.write(cpu.address("abs", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_01F0A0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF09Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF09Du, 4u, 3u, cpu.address("abs", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F09D STA
    hw.write(cpu.address("abs", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_01F0A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF09Du,0x01F09Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01F0A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0A0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F0A0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01F0A0u);return;} hw.unresolvedReturn(0x01F0A0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F0A0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01F0A0u);return;} hw.unresolvedReturn(0x01F0A0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF0A0u,0x01F0A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_03C30F_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x03C30Fu: goto L_03C30F;
    case 0x03C312u: goto L_03C312;
    case 0x03C316u: goto L_03C316;
    case 0x03C318u: goto L_03C318;
    case 0x03C31Au: goto L_03C31A;
    case 0x03C31Cu: goto L_03C31C;
    case 0x03C320u: goto L_03C320;
    case 0x03C322u: goto L_03C322;
    case 0x03C325u: goto L_03C325;
    case 0x03C327u: goto L_03C327;
    case 0x03C328u: goto L_03C328;
    case 0x03C32Au: goto L_03C32A;
    case 0x03C32Cu: goto L_03C32C;
    case 0x03C32Fu: goto L_03C32F;
    case 0x03C331u: goto L_03C331;
    case 0x03C347u: goto L_03C347;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_03C30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Fu, 6u, 3u, cpu.address("abs", 0xB760u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $03C30F JSR -> $03B760 stack real
    { cpu.push16Value(hw,0xC311u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC312u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB760u), 0x03C30Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_03C312;
L_03C312:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC312u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC312u,0x03C312u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC312u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC312u, 8u, 4u, 0x01A7DCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $03C312 JSL -> $01A7DC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC315u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC316u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01A7DCu, 0x03C312u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_03C316;
L_03C316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC316u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC316u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC316u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C316 BCC -> $03C347
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_03C347; }
    goto L_03C318;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC316u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC316u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C316 BCC -> $03C347
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_03C347; }
    goto L_03C318;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC316u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC316u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C316 BCC -> $03C347
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_03C347; }
    goto L_03C318;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC316u,0x03C316u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC318u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC318u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC318u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C318 LDA
    cpu.setA(0x74u, 8);
    goto L_03C31A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC318u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC318u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C318 LDA
    cpu.setA(0x74u, 8);
    goto L_03C31A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC318u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC318u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C318 LDA
    cpu.setA(0x74u, 8);
    goto L_03C31A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC318u,0x03C318u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C31A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC31Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C31A STA
    hw.write(cpu.address("dpx", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_03C31C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C31A STA
    hw.write(cpu.address("dpx", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_03C31C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C31A STA
    hw.write(cpu.address("dpx", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_03C31C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC31Au,0x03C31Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC31Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Cu, 8u, 4u, 0x07F7D2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $03C31C JSL -> $07F7D2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC31Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC320u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F7D2u, 0x03C31Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_03C320;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Cu, 8u, 4u, 0x07F7D2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $03C31C JSL -> $07F7D2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC31Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC320u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F7D2u, 0x03C31Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_03C320;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Cu, 8u, 4u, 0x07F7D2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $03C31C JSL -> $07F7D2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC31Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC320u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F7D2u, 0x03C31Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_03C320;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC31Cu,0x03C31Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC320u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC320u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC320u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C320 LDA
    cpu.setA(0x20u, 8);
    goto L_03C322;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC320u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC320u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C320 LDA
    cpu.setA(0x20u, 8);
    goto L_03C322;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC320u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC320u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C320 LDA
    cpu.setA(0x20u, 8);
    goto L_03C322;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC320u,0x03C320u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC322u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u, 5u, 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C322 STA
    hw.write(cpu.address("absx", 0x154Cu), cpu.a, cpu.m8?8:16);
    goto L_03C325;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u, 5u, 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C322 STA
    hw.write(cpu.address("absx", 0x154Cu), cpu.a, cpu.m8?8:16);
    goto L_03C325;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u, 5u, 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C322 STA
    hw.write(cpu.address("absx", 0x154Cu), cpu.a, cpu.m8?8:16);
    goto L_03C325;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC322u,0x03C322u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC325u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC325u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC325u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C325 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C327;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC325u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC325u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C325 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C327;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC325u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC325u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C325 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C327;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC325u,0x03C325u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC327u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC327u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC327u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C327 SEC
    cpu.setFlag('C', true);
    goto L_03C328;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC327u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC327u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C327 SEC
    cpu.setFlag('C', true);
    goto L_03C328;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC327u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC327u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C327 SEC
    cpu.setFlag('C', true);
    goto L_03C328;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC327u,0x03C327u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC328u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC328u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C328 SBC
    cpu.sbc(0xFu);
    goto L_03C32A;
L_03C32A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C32A STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_03C32C;
L_03C32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Cu, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C32C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C32F;
L_03C32F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C32F SBC
    cpu.sbc(0x0u);
    goto L_03C331;
L_03C331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC331u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC331u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C331 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC334u,0x03C331u); return;
L_03C347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC347u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC347u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC347u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $03C347 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x03C347u);return;} hw.unresolvedReturn(0x03C347u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC347u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC347u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $03C347 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x03C347u);return;} hw.unresolvedReturn(0x03C347u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC347u,0x03C347u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_049A24_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x049A24u: goto L_049A24;
    case 0x049A26u: goto L_049A26;
    case 0x049A29u: goto L_049A29;
    case 0x049A2Au: goto L_049A2A;
    case 0x049A2Bu: goto L_049A2B;
    case 0x049A2Cu: goto L_049A2C;
    case 0x049A2Fu: goto L_049A2F;
    case 0x049A32u: goto L_049A32;
    case 0x049A35u: goto L_049A35;
    case 0x049A38u: goto L_049A38;
    case 0x049A3Au: goto L_049A3A;
    case 0x049A3Cu: goto L_049A3C;
    case 0x049A3Fu: goto L_049A3F;
    case 0x049A42u: goto L_049A42;
    case 0x049A45u: goto L_049A45;
    case 0x049A47u: goto L_049A47;
    case 0x049A4Au: goto L_049A4A;
    case 0x049A4Du: goto L_049A4D;
    case 0x049A4Fu: goto L_049A4F;
    case 0x049A52u: goto L_049A52;
    case 0x049A55u: goto L_049A55;
    case 0x049A58u: goto L_049A58;
    case 0x049A5Au: goto L_049A5A;
    case 0x049A5Du: goto L_049A5D;
    case 0x049A60u: goto L_049A60;
    case 0x049A63u: goto L_049A63;
    case 0x049A66u: goto L_049A66;
    case 0x049A69u: goto L_049A69;
    case 0x049A6Cu: goto L_049A6C;
    case 0x049A6Fu: goto L_049A6F;
    case 0x049A71u: goto L_049A71;
    case 0x049A74u: goto L_049A74;
    case 0x049A77u: goto L_049A77;
    case 0x049A7Au: goto L_049A7A;
    case 0x049A7Du: goto L_049A7D;
    case 0x049A80u: goto L_049A80;
    case 0x049A83u: goto L_049A83;
    case 0x049A85u: goto L_049A85;
    case 0x049A87u: goto L_049A87;
    case 0x049A89u: goto L_049A89;
    case 0x049A8Au: goto L_049A8A;
    case 0x049A8Bu: goto L_049A8B;
    case 0x049A8Cu: goto L_049A8C;
    case 0x049A8Du: goto L_049A8D;
    case 0x049A8Eu: goto L_049A8E;
    case 0x049A90u: goto L_049A90;
    case 0x049A92u: goto L_049A92;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_049A24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A24u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A24u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A24 REP
    cpu.rep(0x20u);
    goto L_049A26;
L_049A26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A26u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A26u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A26 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049A29;
L_049A29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A29u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A29 LSR
    cpu.lsrA();
    goto L_049A2A;
L_049A2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A2A LSR
    cpu.lsrA();
    goto L_049A2B;
L_049A2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A2B TAX
    cpu.transfer("TAX");
    goto L_049A2C;
L_049A2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Cu, 5u + ((((0x1F11u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A2C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049A2F;
L_049A2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A2F AND
    cpu.logicAnd(0xFFu);
    goto L_049A32;
L_049A32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A32u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A32u, 5u, 3u, cpu.address("abs", 0x13C3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A32 STA
    hw.write(cpu.address("abs", 0x13C3u), cpu.a, cpu.m8?8:16);
    goto L_049A35;
L_049A35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A35u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A35u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A35 LDA
    cpu.setA(0x1Au, 16);
    goto L_049A38;
L_049A38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A38u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A38u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A38 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_049A3A;
L_049A3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A3A LDY
    cpu.setY(0x41u, 8);
    goto L_049A3C;
L_049A3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Cu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Cu, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A3C LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049A3F;
L_049A3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Fu, 5u + ((((0x1F19u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A3F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049A42;
L_049A42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A42u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A42u, 5u + ((((0x9964u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9964u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A42 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x9964u), cpu.m8?8:16));
    goto L_049A45;
L_049A45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A45u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A45 BNE -> $049A85
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049A85; }
    goto L_049A47;
L_049A47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A47u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A47u, 5u + ((((0x1F17u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A47 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049A4A;
L_049A4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Au,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Au, 5u + ((((0x9966u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9966u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A4A CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x9966u), cpu.m8?8:16));
    goto L_049A4D;
L_049A4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A4D BNE -> $049A85
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049A85; }
    goto L_049A4F;
L_049A4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Fu, 5u + ((((0x9968u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9968u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A4F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9968u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049A52;
L_049A52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A52u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A52u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A52 AND
    cpu.logicAnd(0xFFu);
    goto L_049A55;
L_049A55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A55u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A55u, 5u, 3u, cpu.address("abs", 0x13C3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A55 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x13C3u), cpu.m8?8:16));
    goto L_049A58;
L_049A58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A58u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A58 BNE -> $049A85
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049A85; }
    goto L_049A5A;
L_049A5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Au, 5u + ((((0x99AAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x99AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A5A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x99AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049A5D;
L_049A5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Du, 6u, 3u, cpu.address("absx", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A5D STA
    hw.write(cpu.address("absx", 0x1F19u), cpu.a, cpu.m8?8:16);
    goto L_049A60;
L_049A60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A60u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A60u, 5u + ((((0x99ACu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x99ACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A60 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x99ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049A63;
L_049A63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A63u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A63u, 6u, 3u, cpu.address("absx", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A63 STA
    hw.write(cpu.address("absx", 0x1F17u), cpu.a, cpu.m8?8:16);
    goto L_049A66;
L_049A66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A66u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A66u, 5u + ((((0x99AEu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x99AEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A66 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x99AEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049A69;
L_049A69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A69u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A69 AND
    cpu.logicAnd(0xFFu);
    goto L_049A6C;
L_049A6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A6Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A6Cu, 5u, 3u, cpu.address("abs", 0x13C3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A6C STA
    hw.write(cpu.address("abs", 0x13C3u), cpu.a, cpu.m8?8:16);
    goto L_049A6F;
L_049A6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A6Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A6Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A6F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049A71;
L_049A71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A71u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A71u, 5u + ((((0x99F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x99F0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A71 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x99F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049A74;
L_049A74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A74u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A74u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A74 AND
    cpu.logicAnd(0xFFu);
    goto L_049A77;
L_049A77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A77u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A77u, 6u, 3u, cpu.address("absx", 0x1F21u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A77 STA
    hw.write(cpu.address("absx", 0x1F21u), cpu.a, cpu.m8?8:16);
    goto L_049A7A;
L_049A7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A7Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A7Au, 5u + ((((0x99F1u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x99F1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A7A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x99F1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049A7D;
L_049A7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A7Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A7D AND
    cpu.logicAnd(0xFFu);
    goto L_049A80;
L_049A80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A80u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A80u, 6u, 3u, cpu.address("absx", 0x1F1Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A80 STA
    hw.write(cpu.address("absx", 0x1F1Fu), cpu.a, cpu.m8?8:16);
    goto L_049A83;
L_049A83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A83u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A83u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A83 BRA -> $049A90
    goto L_049A90;
L_049A85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A85u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A85u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A85 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_049A87;
L_049A87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A87u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A87u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A87 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_049A89;
L_049A89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A89u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A89 DEY
    cpu.decReg('Y');
    goto L_049A8A;
L_049A8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A8Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A8A DEY
    cpu.decReg('Y');
    goto L_049A8B;
L_049A8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A8Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A8B DEY
    cpu.decReg('Y');
    goto L_049A8C;
L_049A8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A8Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A8Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A8C DEY
    cpu.decReg('Y');
    goto L_049A8D;
L_049A8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A8Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A8Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A8D DEY
    cpu.decReg('Y');
    goto L_049A8E;
L_049A8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A8Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A8E BPL -> $049A3F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_049A3F; }
    goto L_049A90;
L_049A90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A90u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A90u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049A90 SEP
    cpu.sep(0x20u);
    goto L_049A92;
L_049A92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A92u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A92u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049A92 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x049A92u);return;} hw.unresolvedReturn(0x049A92u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_05B10C_E0M1X1C0_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05B10Cu: goto L_05B10C;
    case 0x05B10Du: goto L_05B10D;
    case 0x05B10Eu: goto L_05B10E;
    case 0x05B10Fu: goto L_05B10F;
    case 0x05B112u: goto L_05B112;
    case 0x05B115u: goto L_05B115;
    case 0x05B118u: goto L_05B118;
    case 0x05B11Au: goto L_05B11A;
    case 0x05B11Bu: goto L_05B11B;
    case 0x05B11Du: goto L_05B11D;
    case 0x05B120u: goto L_05B120;
    case 0x05B123u: goto L_05B123;
    case 0x05B125u: goto L_05B125;
    case 0x05B127u: goto L_05B127;
    case 0x05B129u: goto L_05B129;
    case 0x05B12Cu: goto L_05B12C;
    case 0x05B12Eu: goto L_05B12E;
    case 0x05B130u: goto L_05B130;
    case 0x05B132u: goto L_05B132;
    case 0x05B135u: goto L_05B135;
    case 0x05B138u: goto L_05B138;
    case 0x05B13Au: goto L_05B13A;
    case 0x05B13Du: goto L_05B13D;
    case 0x05B13Fu: goto L_05B13F;
    case 0x05B141u: goto L_05B141;
    case 0x05B143u: goto L_05B143;
    case 0x05B145u: goto L_05B145;
    case 0x05B148u: goto L_05B148;
    case 0x05B14Au: goto L_05B14A;
    case 0x05B14Du: goto L_05B14D;
    case 0x05B14Fu: goto L_05B14F;
    case 0x05B150u: goto L_05B150;
    case 0x05B153u: goto L_05B153;
    case 0x05B155u: goto L_05B155;
    case 0x05B158u: goto L_05B158;
    case 0x05B15Au: goto L_05B15A;
    case 0x05B15Bu: goto L_05B15B;
    case 0x05B15Du: goto L_05B15D;
    case 0x05B16Eu: goto L_05B16E;
    case 0x05B170u: goto L_05B170;
    case 0x05B172u: goto L_05B172;
    case 0x05B174u: goto L_05B174;
    case 0x05B176u: goto L_05B176;
    case 0x05B178u: goto L_05B178;
    case 0x05B17Au: goto L_05B17A;
    case 0x05B17Cu: goto L_05B17C;
    case 0x05B17Eu: goto L_05B17E;
    case 0x05B180u: goto L_05B180;
    case 0x05B182u: goto L_05B182;
    case 0x05B184u: goto L_05B184;
    case 0x05B186u: goto L_05B186;
    case 0x05B189u: goto L_05B189;
    case 0x05B18Bu: goto L_05B18B;
    case 0x05B18Eu: goto L_05B18E;
    case 0x05B191u: goto L_05B191;
    case 0x05B194u: goto L_05B194;
    case 0x05B196u: goto L_05B196;
    case 0x05B197u: goto L_05B197;
    case 0x05B199u: goto L_05B199;
    case 0x05B19Cu: goto L_05B19C;
    case 0x05B19Eu: goto L_05B19E;
    case 0x05B1A0u: goto L_05B1A0;
    case 0x05B1A3u: goto L_05B1A3;
    case 0x05B1A5u: goto L_05B1A5;
    case 0x05B1A7u: goto L_05B1A7;
    case 0x05B1AAu: goto L_05B1AA;
    case 0x05B1ACu: goto L_05B1AC;
    case 0x05B1ADu: goto L_05B1AD;
    case 0x05B1AFu: goto L_05B1AF;
    case 0x05B1B2u: goto L_05B1B2;
    case 0x05B1B4u: goto L_05B1B4;
    case 0x05B1B7u: goto L_05B1B7;
    case 0x05B1B9u: goto L_05B1B9;
    case 0x05B1BAu: goto L_05B1BA;
    case 0x05B1BCu: goto L_05B1BC;
    case 0x05B1BFu: goto L_05B1BF;
    case 0x05B1C1u: goto L_05B1C1;
    case 0x05B1C3u: goto L_05B1C3;
    case 0x05B1C5u: goto L_05B1C5;
    case 0x05B1C7u: goto L_05B1C7;
    case 0x05B1C9u: goto L_05B1C9;
    case 0x05B1CAu: goto L_05B1CA;
    case 0x05B1CDu: goto L_05B1CD;
    case 0x05B1CEu: goto L_05B1CE;
    case 0x05B1D1u: goto L_05B1D1;
    case 0x05B1D3u: goto L_05B1D3;
    case 0x05B1D5u: goto L_05B1D5;
    case 0x05B1D8u: goto L_05B1D8;
    case 0x05B1DAu: goto L_05B1DA;
    case 0x05B1DBu: goto L_05B1DB;
    case 0x05B1DCu: goto L_05B1DC;
    case 0x05B1DDu: goto L_05B1DD;
    case 0x05B1DEu: goto L_05B1DE;
    case 0x05B1E0u: goto L_05B1E0;
    case 0x05B1E3u: goto L_05B1E3;
    case 0x05B1E5u: goto L_05B1E5;
    case 0x05B1E7u: goto L_05B1E7;
    case 0x05B1EBu: goto L_05B1EB;
    case 0x05B1ECu: goto L_05B1EC;
    case 0x05B1EFu: goto L_05B1EF;
    case 0x05B1F2u: goto L_05B1F2;
    case 0x05B1F6u: goto L_05B1F6;
    case 0x05B1F9u: goto L_05B1F9;
    case 0x05B1FDu: goto L_05B1FD;
    case 0x05B1FEu: goto L_05B1FE;
    case 0x05B200u: goto L_05B200;
    case 0x05B202u: goto L_05B202;
    case 0x05B204u: goto L_05B204;
    case 0x05B206u: goto L_05B206;
    case 0x05B208u: goto L_05B208;
    case 0x05B20Au: goto L_05B20A;
    case 0x05B20Du: goto L_05B20D;
    case 0x05B20Fu: goto L_05B20F;
    case 0x05B212u: goto L_05B212;
    case 0x05B215u: goto L_05B215;
    case 0x05B217u: goto L_05B217;
    case 0x05B218u: goto L_05B218;
    case 0x05B21Cu: goto L_05B21C;
    case 0x05B21Eu: goto L_05B21E;
    case 0x05B222u: goto L_05B222;
    case 0x05B223u: goto L_05B223;
    case 0x05B224u: goto L_05B224;
    case 0x05B226u: goto L_05B226;
    case 0x05B228u: goto L_05B228;
    case 0x05B22Au: goto L_05B22A;
    case 0x05B22Cu: goto L_05B22C;
    case 0x05B22Du: goto L_05B22D;
    case 0x05B22Eu: goto L_05B22E;
    case 0x05B22Fu: goto L_05B22F;
    case 0x05B230u: goto L_05B230;
    case 0x05B231u: goto L_05B231;
    case 0x05B232u: goto L_05B232;
    case 0x05B233u: goto L_05B233;
    case 0x05B235u: goto L_05B235;
    case 0x05B238u: goto L_05B238;
    case 0x05B23Cu: goto L_05B23C;
    case 0x05B23Du: goto L_05B23D;
    case 0x05B241u: goto L_05B241;
    case 0x05B243u: goto L_05B243;
    case 0x05B245u: goto L_05B245;
    case 0x05B248u: goto L_05B248;
    case 0x05B24Au: goto L_05B24A;
    case 0x05B24Cu: goto L_05B24C;
    case 0x05B24Eu: goto L_05B24E;
    case 0x05B250u: goto L_05B250;
    case 0x05B253u: goto L_05B253;
    case 0x05B256u: goto L_05B256;
    case 0x05B257u: goto L_05B257;
    case 0x05B25Au: goto L_05B25A;
    case 0x05B25Du: goto L_05B25D;
    case 0x05B25Eu: goto L_05B25E;
    case 0x05B260u: goto L_05B260;
    case 0x05B261u: goto L_05B261;
    case 0x05B263u: goto L_05B263;
    case 0x05B264u: goto L_05B264;
    case 0x05B267u: goto L_05B267;
    case 0x05B269u: goto L_05B269;
    case 0x05B26Bu: goto L_05B26B;
    case 0x05B26Du: goto L_05B26D;
    case 0x05B270u: goto L_05B270;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05B10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05B10C PHB
    cpu.push("PHB", hw);
    goto L_05B10D;
L_05B10D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Du,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05B10D PHK
    cpu.push("PHK", hw);
    goto L_05B10E;
L_05B10E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05B10E PLB
    cpu.pop("PLB", hw);
    goto L_05B10F;
L_05B10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Fu, 4u, 3u, cpu.address("abs", 0x1B88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B10F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1B88u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05B112;
L_05B112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB112u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB112u, 4u, 3u, cpu.address("abs", 0x1B89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B112 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B89u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B115;
L_05B115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB115u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB115u, 4u + ((((0xB108u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xB108u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B115 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0xB108u), cpu.m8?8:16));
    goto L_05B118;
L_05B118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB118u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB118u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B118 BNE -> $05B191
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B191; }
    goto L_05B11A;
L_05B11A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B11A TXA
    cpu.transfer("TXA");
    goto L_05B11B;
L_05B11B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B11B BEQ -> $05B132
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B132; }
    goto L_05B11D;
L_05B11D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Du, 4u, 3u, cpu.address("abs", 0x1426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B11D STZ
    hw.write(cpu.address("abs", 0x1426u), 0, cpu.m8?8:16);
    goto L_05B120;
L_05B120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB120u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB120u, 4u, 3u, cpu.address("abs", 0x1B88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B120 STZ
    hw.write(cpu.address("abs", 0x1B88u), 0, cpu.m8?8:16);
    goto L_05B123;
L_05B123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB123u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB123u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B123 STZ
    hw.write(cpu.address("dp", 0x41u), 0, cpu.m8?8:16);
    goto L_05B125;
L_05B125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB125u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB125u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B125 STZ
    hw.write(cpu.address("dp", 0x42u), 0, cpu.m8?8:16);
    goto L_05B127;
L_05B127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB127u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB127u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B127 STZ
    hw.write(cpu.address("dp", 0x43u), 0, cpu.m8?8:16);
    goto L_05B129;
L_05B129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB129u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB129u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB129u, 4u, 3u, cpu.address("abs", 0x0D9Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B129 STZ
    hw.write(cpu.address("abs", 0xD9Fu), 0, cpu.m8?8:16);
    goto L_05B12C;
L_05B12C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB12Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B12C LDA
    cpu.setA(0x2u, 8);
    goto L_05B12E;
L_05B12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB12Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B12E STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_05B130;
L_05B130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB130u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB130u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B130 BRA -> $05B18E
    goto L_05B18E;
L_05B132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB132u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB132u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB132u, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B132 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B135;
L_05B135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB135u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB135u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB135u, 4u, 3u, cpu.address("abs", 0x13D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B135 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13D2u), cpu.m8?8:16));
    goto L_05B138;
L_05B138:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB138u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB138u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB138u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B138 BEQ -> $05B16E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B16E; }
    goto L_05B13A;
L_05B13A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Au, 4u, 3u, cpu.address("abs", 0x1DF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B13A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DF5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B13D;
L_05B13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B13D BEQ -> $05B16E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B16E; }
    goto L_05B13F;
L_05B13F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B13F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B141;
L_05B141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB141u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB141u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B141 AND
    cpu.logicAnd(0x3u);
    goto L_05B143;
L_05B143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB143u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB143u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B143 BNE -> $05B18E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B18E; }
    goto L_05B145;
L_05B145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB145u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB145u, 6u, 3u, cpu.address("abs", 0x1DF5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B145 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1DF5u), cpu.m8?8:16);
    goto L_05B148;
L_05B148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB148u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB148u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B148 BNE -> $05B18E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B18E; }
    goto L_05B14A;
L_05B14A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Au, 4u, 3u, cpu.address("abs", 0x13D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B14A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13D2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B14D;
L_05B14D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B14D BEQ -> $05B16E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B16E; }
    goto L_05B14F;
L_05B14F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05B14F PLB
    cpu.pop("PLB", hw);
    goto L_05B150;
L_05B150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB150u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB150u, 6u, 3u, cpu.address("abs", 0x1DE9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B150 INC
    cpu.incMem(hw, cpu.address("abs", 0x1DE9u), cpu.m8?8:16);
    goto L_05B153;
L_05B153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB153u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB153u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B153 LDA
    cpu.setA(0x1u, 8);
    goto L_05B155;
L_05B155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB155u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB155u, 4u, 3u, cpu.address("abs", 0x13CEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B155 STA
    hw.write(cpu.address("abs", 0x13CEu), cpu.a, cpu.m8?8:16);
    goto L_05B158;
L_05B158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB158u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB158u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B158 BRA -> $05B165
    hw.requestDispatch(0x05B165u,0x05B158u); return;
L_05B15A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB15Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05B15A PLB
    cpu.pop("PLB", hw);
    goto L_05B15B;
L_05B15B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB15Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B15B LDA
    cpu.setA(0x8Eu, 8);
    goto L_05B15D;
L_05B15D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB15Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Du, 4u, 3u, cpu.address("abs", 0x1F19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B15D STA
    hw.write(cpu.address("abs", 0x1F19u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB160u,0x05B15Du); return;
L_05B16E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB16Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B16E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B170;
L_05B170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB170u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB170u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B170 AND
    cpu.logicAnd(0xF0u);
    goto L_05B172;
L_05B172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB172u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB172u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B172 BEQ -> $05B18E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B18E; }
    goto L_05B174;
L_05B174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB174u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB174u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B174 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_05B176;
L_05B176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB176u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB176u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B176 AND
    cpu.logicAnd(0xF0u);
    goto L_05B178;
L_05B178:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB178u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB178u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB178u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B178 BEQ -> $05B186
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B186; }
    goto L_05B17A;
L_05B17A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB17Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B17A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B17C;
L_05B17C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB17Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B17C AND
    cpu.logicAnd(0xC0u);
    goto L_05B17E;
L_05B17E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB17Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B17E BEQ -> $05B18E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B18E; }
    goto L_05B180;
L_05B180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB180u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB180u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B180 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_05B182;
L_05B182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB182u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB182u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B182 AND
    cpu.logicAnd(0xC0u);
    goto L_05B184;
L_05B184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB184u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB184u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B184 BNE -> $05B18E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B18E; }
    goto L_05B186;
L_05B186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB186u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB186u, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B186 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B189;
L_05B189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB189u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB189u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B189 BNE -> $05B15A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B15A; }
    goto L_05B18B;
L_05B18B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB18Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Bu, 6u, 3u, cpu.address("abs", 0x1B88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B18B INC
    cpu.incMem(hw, cpu.address("abs", 0x1B88u), cpu.m8?8:16);
    goto L_05B18E;
L_05B18E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB18Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Eu, 3u, 3u, cpu.address("abs", 0xB299u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B18E JMP -> $05B299
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB299u),0x05B18Eu); return;
L_05B191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB191u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB191u, 4u + ((((0xB106u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xB106u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B191 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0xB106u), cpu.m8?8:16));
    goto L_05B194;
L_05B194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB194u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB194u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B194 BNE -> $05B1A0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1A0; }
    goto L_05B196;
L_05B196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB196u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB196u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB196u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B196 TXA
    cpu.transfer("TXA");
    goto L_05B197;
L_05B197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB197u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB197u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B197 BEQ -> $05B1A3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1A3; }
    goto L_05B199;
L_05B199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB199u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB199u, 6u, 3u, cpu.address("abs", 0xB31Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05B199 JSR -> $05B31B stack real
    { cpu.push16Value(hw,0xB19Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB19Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB31Bu), 0x05B199u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05B19C;
L_05B19C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB19Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB19Cu,0x05B19Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B19C LDA
    cpu.setA(0x9u, 8);
    goto L_05B19E;
L_05B19E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB19Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B19E STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_05B1A0;
L_05B1A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A0u, 3u, 3u, cpu.address("abs", 0xB250u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1A0 JMP -> $05B250
    goto L_05B250;
L_05B1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1A3 LDX
    cpu.setX(0x16u, 8);
    goto L_05B1A5;
L_05B1A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1A5 LDY
    cpu.setY(0x1u, 8);
    goto L_05B1A7;
L_05B1A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A7u, 4u + ((((0xA590u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA590u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1A7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA590u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B1AA;
L_05B1AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1AAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1AA BPL -> $05B1AF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_05B1AF; }
    goto L_05B1AC;
L_05B1AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ACu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1AC INY
    cpu.inc('Y');
    goto L_05B1AD;
L_05B1AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ADu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1AD AND
    cpu.logicAnd(0x7Fu);
    goto L_05B1AF;
L_05B1AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1AFu,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1AFu, 4u, 3u, cpu.address("abs", 0x1426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1AF CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0x1426u), cpu.x8?8:16));
    goto L_05B1B2;
L_05B1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1B2 BNE -> $05B1B9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1B9; }
    goto L_05B1B4;
L_05B1B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B4u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B4u, 4u, 3u, cpu.address("abs", 0x13BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1B4 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x13BFu), cpu.m8?8:16));
    goto L_05B1B7;
L_05B1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1B7 BEQ -> $05B1BC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1BC; }
    goto L_05B1B9;
L_05B1B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B9u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1B9 DEX
    cpu.decReg('X');
    goto L_05B1BA;
L_05B1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1BA BNE -> $05B1A5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1A5; }
    goto L_05B1BC;
L_05B1BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BCu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BCu, 4u, 3u, cpu.address("abs", 0x1426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1BC LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1426u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05B1BF;
L_05B1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BFu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1BF CPY
    cpu.compareY(0x3u);
    goto L_05B1C1;
L_05B1C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1C1 BNE -> $05B1C5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1C5; }
    goto L_05B1C3;
L_05B1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1C3 LDX
    cpu.setX(0x18u, 8);
    goto L_05B1C5;
L_05B1C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C5u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1C5 CPX
    cpu.compareX(0x4u);
    goto L_05B1C7;
L_05B1C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C7u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1C7 BCS -> $05B1D1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_05B1D1; }
    goto L_05B1C9;
L_05B1C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1C9 INX
    cpu.inc('X');
    goto L_05B1CA;
L_05B1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CAu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CAu, 4u, 3u, cpu.address("abs", 0x13D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1CA STX
    hw.write(cpu.address("abs", 0x13D2u), cpu.x, cpu.x8?8:16);
    goto L_05B1CD;
L_05B1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CDu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1CD DEX
    cpu.decReg('X');
    goto L_05B1CE;
L_05B1CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CEu, 6u, 3u, cpu.address("abs", 0xB2EBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05B1CE JSR -> $05B2EB stack real
    { cpu.push16Value(hw,0xB1D0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1D1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB2EBu), 0x05B1CEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05B1D1;
L_05B1D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1D1u,0x05B1D1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D1u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1D1 CPX
    cpu.compareX(0x16u);
    goto L_05B1D3;
L_05B1D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1D3 BNE -> $05B1DB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1DB; }
    goto L_05B1D5;
L_05B1D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D5u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1D5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B1D8;
L_05B1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1D8 BEQ -> $05B1DB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1DB; }
    goto L_05B1DA;
L_05B1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1DA INX
    cpu.inc('X');
    goto L_05B1DB;
L_05B1DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DBu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1DB TXA
    cpu.transfer("TXA");
    goto L_05B1DC;
L_05B1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1DC ASL
    cpu.aslA();
    goto L_05B1DD;
L_05B1DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DDu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1DD TAX
    cpu.transfer("TAX");
    goto L_05B1DE;
L_05B1DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1DE REP
    cpu.rep(0x20u);
    goto L_05B1E0;
L_05B1E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E0u, 5u + ((((0xA5A7u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA5A7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1E0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA5A7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B1E3;
L_05B1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1E3 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_05B1E5;
L_05B1E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1E5 REP
    cpu.rep(0x10u);
    goto L_05B1E7;
L_05B1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E7u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E7u, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1E7 LDA
    cpu.loadA(hw.readW(0x7F837Bu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B1EB;
L_05B1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1EB TAX
    cpu.transfer("TAX");
    goto L_05B1EC;
L_05B1EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ECu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1EC LDY
    cpu.setY(0xEu, 16);
    goto L_05B1EF;
L_05B1EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu, 5u + 1u, 3u, cpu.address("absy", 0xA580u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1EF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA580u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B1F2;
L_05B1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F2u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F2u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1F2 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05B1F6;
L_05B1F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1F6 LDA
    cpu.setA(0x2300u, 16);
    goto L_05B1F9;
L_05B1F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F9u, 6u, 4u, ((0x7F837Fu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1F9 STA
    hw.write(((0x7F837Fu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05B1FD;
L_05B1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05B1FD PHY
    cpu.push("PHY", hw);
    goto L_05B1FE;
L_05B1FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1FE SEP
    cpu.sep(0x20u);
    goto L_05B200;
L_05B200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB200u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB200u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B200 LDA
    cpu.setA(0x12u, 8);
    goto L_05B202;
L_05B202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB202u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB202u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B202 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_05B204;
L_05B204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B204 STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    goto L_05B206;
L_05B206:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB206u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB206u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB206u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B206 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05B208;
L_05B208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB208u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB208u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B208 LDA
    cpu.setA(0x1Fu, 8);
    goto L_05B20A;
L_05B20A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Au,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Au, 4u, 3u, cpu.address("abs", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B20A BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x3u), cpu.m8?8:16), false);
    goto L_05B20D;
L_05B20D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B20D BMI -> $05B218
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_05B218; }
    goto L_05B20F;
L_05B20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu, 4u + 1u, 3u, cpu.address("absy", 0xA5D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B20F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA5D9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B212;
L_05B212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB212u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB212u, 4u, 3u, cpu.address("abs", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B212 STA
    hw.write(cpu.address("abs", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_05B215;
L_05B215:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB215u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB215u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB215u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B215 AND
    cpu.logicAnd(0x7Fu);
    goto L_05B217;
L_05B217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B217 INY
    cpu.inc('Y');
    goto L_05B218;
L_05B218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB218u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB218u, 5u, 4u, ((0x7F8381u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B218 STA
    hw.write(((0x7F8381u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05B21C;
L_05B21C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB21Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B21C LDA
    cpu.setA(0x39u, 8);
    goto L_05B21E;
L_05B21E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB21Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Eu, 5u, 4u, ((0x7F8382u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B21E STA
    hw.write(((0x7F8382u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05B222;
L_05B222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB222u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB222u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B222 INX
    cpu.inc('X');
    goto L_05B223;
L_05B223:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB223u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB223u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB223u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B223 INX
    cpu.inc('X');
    goto L_05B224;
L_05B224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB224u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB224u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B224 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_05B226;
L_05B226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB226u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB226u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B226 BNE -> $05B208
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B208; }
    goto L_05B228;
L_05B228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB228u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB228u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B228 STY
    hw.write(cpu.address("dp", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_05B22A;
L_05B22A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B22A REP
    cpu.rep(0x20u);
    goto L_05B22C;
L_05B22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B22C INX
    cpu.inc('X');
    goto L_05B22D;
L_05B22D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B22D INX
    cpu.inc('X');
    goto L_05B22E;
L_05B22E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B22E INX
    cpu.inc('X');
    goto L_05B22F;
L_05B22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B22F INX
    cpu.inc('X');
    goto L_05B230;
L_05B230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB230u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB230u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05B230 PLY
    cpu.pop("PLY", hw);
    goto L_05B231;
L_05B231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB231u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB231u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B231 DEY
    cpu.decReg('Y');
    goto L_05B232;
L_05B232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB232u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB232u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B232 DEY
    cpu.decReg('Y');
    goto L_05B233;
L_05B233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB233u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB233u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B233 BPL -> $05B1EF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_05B1EF; }
    goto L_05B235;
L_05B235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB235u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB235u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B235 LDA
    cpu.setA(0xFFu, 16);
    goto L_05B238;
L_05B238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB238u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB238u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B238 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05B23C;
L_05B23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B23C TXA
    cpu.transfer("TXA");
    goto L_05B23D;
L_05B23D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB23Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Du, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B23D STA
    hw.write(0x7F837Bu, cpu.a, cpu.m8?8:16);
    goto L_05B241;
L_05B241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB241u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB241u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B241 SEP
    cpu.sep(0x30u);
    goto L_05B243;
L_05B243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB243u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB243u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B243 LDA
    cpu.setA(0x1u, 8);
    goto L_05B245;
L_05B245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB245u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB245u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB245u, 4u, 3u, cpu.address("abs", 0x13D5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B245 STA
    hw.write(cpu.address("abs", 0x13D5u), cpu.a, cpu.m8?8:16);
    goto L_05B248;
L_05B248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB248u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB248u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B248 STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_05B24A;
L_05B24A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x23u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B24A STZ
    hw.write(cpu.address("dp", 0x23u), 0, cpu.m8?8:16);
    goto L_05B24C;
L_05B24C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B24C STZ
    hw.write(cpu.address("dp", 0x24u), 0, cpu.m8?8:16);
    goto L_05B24E;
L_05B24E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B24E STZ
    hw.write(cpu.address("dp", 0x25u), 0, cpu.m8?8:16);
    goto L_05B250;
L_05B250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB250u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB250u, 4u, 3u, cpu.address("abs", 0x1B88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B250 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1B88u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05B253;
L_05B253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB253u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB253u, 4u, 3u, cpu.address("abs", 0x1B89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B253 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B89u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B256;
L_05B256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB256u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB256u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B256 CLC
    cpu.setFlag('C', false);
    goto L_05B257;
L_05B257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB257u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB257u, 4u + ((((0xB10Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xB10Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B257 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xB10Au), cpu.m8?8:16));
    goto L_05B25A;
L_05B25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Au, 4u, 3u, cpu.address("abs", 0x1B89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B25A STA
    hw.write(cpu.address("abs", 0x1B89u), cpu.a, cpu.m8?8:16);
    goto L_05B25D;
L_05B25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B25D CLC
    cpu.setFlag('C', false);
    goto L_05B25E;
L_05B25E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B25E ADC
    cpu.adc(0x80u);
    goto L_05B260;
L_05B260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB260u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB260u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B260 XBA
    cpu.xba();
    goto L_05B261;
L_05B261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB261u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB261u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B261 LDA
    cpu.setA(0x80u, 8);
    goto L_05B263;
L_05B263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB263u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB263u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B263 SEC
    cpu.setFlag('C', true);
    goto L_05B264;
L_05B264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u, 4u, 3u, cpu.address("abs", 0x1B89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B264 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x1B89u), cpu.m8?8:16));
    goto L_05B267;
L_05B267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB267u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB267u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B267 REP
    cpu.rep(0x20u);
    goto L_05B269;
L_05B269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB269u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB269u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B269 LDX
    cpu.setX(0x0u, 8);
    goto L_05B26B;
L_05B26B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B26B LDY
    cpu.setY(0x50u, 8);
    goto L_05B26D;
L_05B26D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Du,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Du, 4u, 3u, cpu.address("abs", 0x1B89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B26D CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x1B89u), cpu.x8?8:16));
    goto L_05B270;
L_05B270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB270u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB270u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B270 BCC -> $05B275
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x05B275u,0x05B270u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB272u,0x05B270u); return;
}

void sub_05B10C_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05B10Cu: goto L_05B10C;
    case 0x05B10Du: goto L_05B10D;
    case 0x05B10Eu: goto L_05B10E;
    case 0x05B10Fu: goto L_05B10F;
    case 0x05B112u: goto L_05B112;
    case 0x05B115u: goto L_05B115;
    case 0x05B118u: goto L_05B118;
    case 0x05B11Au: goto L_05B11A;
    case 0x05B11Bu: goto L_05B11B;
    case 0x05B11Du: goto L_05B11D;
    case 0x05B120u: goto L_05B120;
    case 0x05B123u: goto L_05B123;
    case 0x05B125u: goto L_05B125;
    case 0x05B127u: goto L_05B127;
    case 0x05B129u: goto L_05B129;
    case 0x05B12Cu: goto L_05B12C;
    case 0x05B12Eu: goto L_05B12E;
    case 0x05B130u: goto L_05B130;
    case 0x05B132u: goto L_05B132;
    case 0x05B135u: goto L_05B135;
    case 0x05B138u: goto L_05B138;
    case 0x05B13Au: goto L_05B13A;
    case 0x05B13Du: goto L_05B13D;
    case 0x05B13Fu: goto L_05B13F;
    case 0x05B141u: goto L_05B141;
    case 0x05B143u: goto L_05B143;
    case 0x05B145u: goto L_05B145;
    case 0x05B148u: goto L_05B148;
    case 0x05B14Au: goto L_05B14A;
    case 0x05B14Du: goto L_05B14D;
    case 0x05B14Fu: goto L_05B14F;
    case 0x05B150u: goto L_05B150;
    case 0x05B153u: goto L_05B153;
    case 0x05B155u: goto L_05B155;
    case 0x05B158u: goto L_05B158;
    case 0x05B15Au: goto L_05B15A;
    case 0x05B15Bu: goto L_05B15B;
    case 0x05B15Du: goto L_05B15D;
    case 0x05B16Eu: goto L_05B16E;
    case 0x05B170u: goto L_05B170;
    case 0x05B172u: goto L_05B172;
    case 0x05B174u: goto L_05B174;
    case 0x05B176u: goto L_05B176;
    case 0x05B178u: goto L_05B178;
    case 0x05B17Au: goto L_05B17A;
    case 0x05B17Cu: goto L_05B17C;
    case 0x05B17Eu: goto L_05B17E;
    case 0x05B180u: goto L_05B180;
    case 0x05B182u: goto L_05B182;
    case 0x05B184u: goto L_05B184;
    case 0x05B186u: goto L_05B186;
    case 0x05B189u: goto L_05B189;
    case 0x05B18Bu: goto L_05B18B;
    case 0x05B18Eu: goto L_05B18E;
    case 0x05B191u: goto L_05B191;
    case 0x05B194u: goto L_05B194;
    case 0x05B196u: goto L_05B196;
    case 0x05B197u: goto L_05B197;
    case 0x05B199u: goto L_05B199;
    case 0x05B19Cu: goto L_05B19C;
    case 0x05B19Eu: goto L_05B19E;
    case 0x05B1A0u: goto L_05B1A0;
    case 0x05B1A3u: goto L_05B1A3;
    case 0x05B1A5u: goto L_05B1A5;
    case 0x05B1A7u: goto L_05B1A7;
    case 0x05B1AAu: goto L_05B1AA;
    case 0x05B1ACu: goto L_05B1AC;
    case 0x05B1ADu: goto L_05B1AD;
    case 0x05B1AFu: goto L_05B1AF;
    case 0x05B1B2u: goto L_05B1B2;
    case 0x05B1B4u: goto L_05B1B4;
    case 0x05B1B7u: goto L_05B1B7;
    case 0x05B1B9u: goto L_05B1B9;
    case 0x05B1BAu: goto L_05B1BA;
    case 0x05B1BCu: goto L_05B1BC;
    case 0x05B1BFu: goto L_05B1BF;
    case 0x05B1C1u: goto L_05B1C1;
    case 0x05B1C3u: goto L_05B1C3;
    case 0x05B1C5u: goto L_05B1C5;
    case 0x05B1C7u: goto L_05B1C7;
    case 0x05B1C9u: goto L_05B1C9;
    case 0x05B1CAu: goto L_05B1CA;
    case 0x05B1CDu: goto L_05B1CD;
    case 0x05B1CEu: goto L_05B1CE;
    case 0x05B1D1u: goto L_05B1D1;
    case 0x05B1D3u: goto L_05B1D3;
    case 0x05B1D5u: goto L_05B1D5;
    case 0x05B1D8u: goto L_05B1D8;
    case 0x05B1DAu: goto L_05B1DA;
    case 0x05B1DBu: goto L_05B1DB;
    case 0x05B1DCu: goto L_05B1DC;
    case 0x05B1DDu: goto L_05B1DD;
    case 0x05B1DEu: goto L_05B1DE;
    case 0x05B1E0u: goto L_05B1E0;
    case 0x05B1E3u: goto L_05B1E3;
    case 0x05B1E5u: goto L_05B1E5;
    case 0x05B1E7u: goto L_05B1E7;
    case 0x05B1EBu: goto L_05B1EB;
    case 0x05B1ECu: goto L_05B1EC;
    case 0x05B1EFu: goto L_05B1EF;
    case 0x05B1F2u: goto L_05B1F2;
    case 0x05B1F6u: goto L_05B1F6;
    case 0x05B1F9u: goto L_05B1F9;
    case 0x05B1FDu: goto L_05B1FD;
    case 0x05B1FEu: goto L_05B1FE;
    case 0x05B200u: goto L_05B200;
    case 0x05B202u: goto L_05B202;
    case 0x05B204u: goto L_05B204;
    case 0x05B206u: goto L_05B206;
    case 0x05B208u: goto L_05B208;
    case 0x05B20Au: goto L_05B20A;
    case 0x05B20Du: goto L_05B20D;
    case 0x05B20Fu: goto L_05B20F;
    case 0x05B212u: goto L_05B212;
    case 0x05B215u: goto L_05B215;
    case 0x05B217u: goto L_05B217;
    case 0x05B218u: goto L_05B218;
    case 0x05B21Cu: goto L_05B21C;
    case 0x05B21Eu: goto L_05B21E;
    case 0x05B222u: goto L_05B222;
    case 0x05B223u: goto L_05B223;
    case 0x05B224u: goto L_05B224;
    case 0x05B226u: goto L_05B226;
    case 0x05B228u: goto L_05B228;
    case 0x05B22Au: goto L_05B22A;
    case 0x05B22Cu: goto L_05B22C;
    case 0x05B22Du: goto L_05B22D;
    case 0x05B22Eu: goto L_05B22E;
    case 0x05B22Fu: goto L_05B22F;
    case 0x05B230u: goto L_05B230;
    case 0x05B231u: goto L_05B231;
    case 0x05B232u: goto L_05B232;
    case 0x05B233u: goto L_05B233;
    case 0x05B235u: goto L_05B235;
    case 0x05B238u: goto L_05B238;
    case 0x05B23Cu: goto L_05B23C;
    case 0x05B23Du: goto L_05B23D;
    case 0x05B241u: goto L_05B241;
    case 0x05B243u: goto L_05B243;
    case 0x05B245u: goto L_05B245;
    case 0x05B248u: goto L_05B248;
    case 0x05B24Au: goto L_05B24A;
    case 0x05B24Cu: goto L_05B24C;
    case 0x05B24Eu: goto L_05B24E;
    case 0x05B250u: goto L_05B250;
    case 0x05B253u: goto L_05B253;
    case 0x05B256u: goto L_05B256;
    case 0x05B257u: goto L_05B257;
    case 0x05B25Au: goto L_05B25A;
    case 0x05B25Du: goto L_05B25D;
    case 0x05B25Eu: goto L_05B25E;
    case 0x05B260u: goto L_05B260;
    case 0x05B261u: goto L_05B261;
    case 0x05B263u: goto L_05B263;
    case 0x05B264u: goto L_05B264;
    case 0x05B267u: goto L_05B267;
    case 0x05B269u: goto L_05B269;
    case 0x05B26Bu: goto L_05B26B;
    case 0x05B26Du: goto L_05B26D;
    case 0x05B270u: goto L_05B270;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05B10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05B10C PHB
    cpu.push("PHB", hw);
    goto L_05B10D;
L_05B10D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Du,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05B10D PHK
    cpu.push("PHK", hw);
    goto L_05B10E;
L_05B10E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05B10E PLB
    cpu.pop("PLB", hw);
    goto L_05B10F;
L_05B10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Fu, 4u, 3u, cpu.address("abs", 0x1B88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B10F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1B88u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05B112;
L_05B112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB112u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB112u, 4u, 3u, cpu.address("abs", 0x1B89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B112 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B89u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B115;
L_05B115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB115u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB115u, 4u + ((((0xB108u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xB108u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B115 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0xB108u), cpu.m8?8:16));
    goto L_05B118;
L_05B118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB118u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB118u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B118 BNE -> $05B191
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B191; }
    goto L_05B11A;
L_05B11A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B11A TXA
    cpu.transfer("TXA");
    goto L_05B11B;
L_05B11B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B11B BEQ -> $05B132
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B132; }
    goto L_05B11D;
L_05B11D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Du, 4u, 3u, cpu.address("abs", 0x1426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B11D STZ
    hw.write(cpu.address("abs", 0x1426u), 0, cpu.m8?8:16);
    goto L_05B120;
L_05B120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB120u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB120u, 4u, 3u, cpu.address("abs", 0x1B88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B120 STZ
    hw.write(cpu.address("abs", 0x1B88u), 0, cpu.m8?8:16);
    goto L_05B123;
L_05B123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB123u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB123u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B123 STZ
    hw.write(cpu.address("dp", 0x41u), 0, cpu.m8?8:16);
    goto L_05B125;
L_05B125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB125u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB125u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B125 STZ
    hw.write(cpu.address("dp", 0x42u), 0, cpu.m8?8:16);
    goto L_05B127;
L_05B127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB127u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB127u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B127 STZ
    hw.write(cpu.address("dp", 0x43u), 0, cpu.m8?8:16);
    goto L_05B129;
L_05B129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB129u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB129u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB129u, 4u, 3u, cpu.address("abs", 0x0D9Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B129 STZ
    hw.write(cpu.address("abs", 0xD9Fu), 0, cpu.m8?8:16);
    goto L_05B12C;
L_05B12C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB12Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B12C LDA
    cpu.setA(0x2u, 8);
    goto L_05B12E;
L_05B12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB12Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B12E STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_05B130;
L_05B130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB130u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB130u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B130 BRA -> $05B18E
    goto L_05B18E;
L_05B132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB132u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB132u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB132u, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B132 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B135;
L_05B135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB135u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB135u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB135u, 4u, 3u, cpu.address("abs", 0x13D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B135 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13D2u), cpu.m8?8:16));
    goto L_05B138;
L_05B138:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB138u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB138u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB138u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B138 BEQ -> $05B16E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B16E; }
    goto L_05B13A;
L_05B13A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Au, 4u, 3u, cpu.address("abs", 0x1DF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B13A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DF5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B13D;
L_05B13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B13D BEQ -> $05B16E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B16E; }
    goto L_05B13F;
L_05B13F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B13F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B141;
L_05B141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB141u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB141u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B141 AND
    cpu.logicAnd(0x3u);
    goto L_05B143;
L_05B143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB143u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB143u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B143 BNE -> $05B18E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B18E; }
    goto L_05B145;
L_05B145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB145u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB145u, 6u, 3u, cpu.address("abs", 0x1DF5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B145 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1DF5u), cpu.m8?8:16);
    goto L_05B148;
L_05B148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB148u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB148u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B148 BNE -> $05B18E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B18E; }
    goto L_05B14A;
L_05B14A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Au, 4u, 3u, cpu.address("abs", 0x13D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B14A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13D2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B14D;
L_05B14D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B14D BEQ -> $05B16E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B16E; }
    goto L_05B14F;
L_05B14F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05B14F PLB
    cpu.pop("PLB", hw);
    goto L_05B150;
L_05B150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB150u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB150u, 6u, 3u, cpu.address("abs", 0x1DE9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B150 INC
    cpu.incMem(hw, cpu.address("abs", 0x1DE9u), cpu.m8?8:16);
    goto L_05B153;
L_05B153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB153u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB153u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B153 LDA
    cpu.setA(0x1u, 8);
    goto L_05B155;
L_05B155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB155u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB155u, 4u, 3u, cpu.address("abs", 0x13CEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B155 STA
    hw.write(cpu.address("abs", 0x13CEu), cpu.a, cpu.m8?8:16);
    goto L_05B158;
L_05B158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB158u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB158u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B158 BRA -> $05B165
    hw.requestDispatch(0x05B165u,0x05B158u); return;
L_05B15A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB15Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05B15A PLB
    cpu.pop("PLB", hw);
    goto L_05B15B;
L_05B15B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB15Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B15B LDA
    cpu.setA(0x8Eu, 8);
    goto L_05B15D;
L_05B15D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB15Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Du, 4u, 3u, cpu.address("abs", 0x1F19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B15D STA
    hw.write(cpu.address("abs", 0x1F19u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB160u,0x05B15Du); return;
L_05B16E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB16Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B16E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B170;
L_05B170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB170u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB170u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B170 AND
    cpu.logicAnd(0xF0u);
    goto L_05B172;
L_05B172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB172u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB172u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B172 BEQ -> $05B18E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B18E; }
    goto L_05B174;
L_05B174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB174u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB174u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B174 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_05B176;
L_05B176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB176u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB176u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B176 AND
    cpu.logicAnd(0xF0u);
    goto L_05B178;
L_05B178:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB178u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB178u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB178u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B178 BEQ -> $05B186
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B186; }
    goto L_05B17A;
L_05B17A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB17Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B17A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B17C;
L_05B17C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB17Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B17C AND
    cpu.logicAnd(0xC0u);
    goto L_05B17E;
L_05B17E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB17Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B17E BEQ -> $05B18E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B18E; }
    goto L_05B180;
L_05B180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB180u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB180u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B180 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_05B182;
L_05B182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB182u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB182u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B182 AND
    cpu.logicAnd(0xC0u);
    goto L_05B184;
L_05B184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB184u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB184u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B184 BNE -> $05B18E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B18E; }
    goto L_05B186;
L_05B186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB186u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB186u, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B186 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B189;
L_05B189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB189u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB189u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B189 BNE -> $05B15A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B15A; }
    goto L_05B18B;
L_05B18B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB18Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Bu, 6u, 3u, cpu.address("abs", 0x1B88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B18B INC
    cpu.incMem(hw, cpu.address("abs", 0x1B88u), cpu.m8?8:16);
    goto L_05B18E;
L_05B18E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB18Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB18Eu, 3u, 3u, cpu.address("abs", 0xB299u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B18E JMP -> $05B299
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB299u),0x05B18Eu); return;
L_05B191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB191u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB191u, 4u + ((((0xB106u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xB106u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B191 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0xB106u), cpu.m8?8:16));
    goto L_05B194;
L_05B194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB194u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB194u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B194 BNE -> $05B1A0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1A0; }
    goto L_05B196;
L_05B196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB196u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB196u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB196u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B196 TXA
    cpu.transfer("TXA");
    goto L_05B197;
L_05B197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB197u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB197u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B197 BEQ -> $05B1A3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1A3; }
    goto L_05B199;
L_05B199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB199u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB199u, 6u, 3u, cpu.address("abs", 0xB31Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05B199 JSR -> $05B31B stack real
    { cpu.push16Value(hw,0xB19Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB19Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB31Bu), 0x05B199u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05B19C;
L_05B19C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB19Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB19Cu,0x05B19Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B19C LDA
    cpu.setA(0x9u, 8);
    goto L_05B19E;
L_05B19E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB19Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB19Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B19E STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_05B1A0;
L_05B1A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A0u, 3u, 3u, cpu.address("abs", 0xB250u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1A0 JMP -> $05B250
    goto L_05B250;
L_05B1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1A3 LDX
    cpu.setX(0x16u, 8);
    goto L_05B1A5;
L_05B1A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1A5 LDY
    cpu.setY(0x1u, 8);
    goto L_05B1A7;
L_05B1A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1A7u, 4u + ((((0xA590u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA590u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1A7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA590u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B1AA;
L_05B1AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1AAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1AA BPL -> $05B1AF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_05B1AF; }
    goto L_05B1AC;
L_05B1AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ACu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1AC INY
    cpu.inc('Y');
    goto L_05B1AD;
L_05B1AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ADu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1AD AND
    cpu.logicAnd(0x7Fu);
    goto L_05B1AF;
L_05B1AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1AFu,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1AFu, 4u, 3u, cpu.address("abs", 0x1426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1AF CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0x1426u), cpu.x8?8:16));
    goto L_05B1B2;
L_05B1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1B2 BNE -> $05B1B9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1B9; }
    goto L_05B1B4;
L_05B1B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B4u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B4u, 4u, 3u, cpu.address("abs", 0x13BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1B4 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x13BFu), cpu.m8?8:16));
    goto L_05B1B7;
L_05B1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1B7 BEQ -> $05B1BC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1BC; }
    goto L_05B1B9;
L_05B1B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B9u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1B9 DEX
    cpu.decReg('X');
    goto L_05B1BA;
L_05B1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1BA BNE -> $05B1A5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1A5; }
    goto L_05B1BC;
L_05B1BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BCu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BCu, 4u, 3u, cpu.address("abs", 0x1426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1BC LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1426u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05B1BF;
L_05B1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BFu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1BF CPY
    cpu.compareY(0x3u);
    goto L_05B1C1;
L_05B1C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1C1 BNE -> $05B1C5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1C5; }
    goto L_05B1C3;
L_05B1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1C3 LDX
    cpu.setX(0x18u, 8);
    goto L_05B1C5;
L_05B1C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C5u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1C5 CPX
    cpu.compareX(0x4u);
    goto L_05B1C7;
L_05B1C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C7u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1C7 BCS -> $05B1D1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_05B1D1; }
    goto L_05B1C9;
L_05B1C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1C9 INX
    cpu.inc('X');
    goto L_05B1CA;
L_05B1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CAu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CAu, 4u, 3u, cpu.address("abs", 0x13D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1CA STX
    hw.write(cpu.address("abs", 0x13D2u), cpu.x, cpu.x8?8:16);
    goto L_05B1CD;
L_05B1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CDu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1CD DEX
    cpu.decReg('X');
    goto L_05B1CE;
L_05B1CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1CEu, 6u, 3u, cpu.address("abs", 0xB2EBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05B1CE JSR -> $05B2EB stack real
    { cpu.push16Value(hw,0xB1D0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1D1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB2EBu), 0x05B1CEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05B1D1;
L_05B1D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1D1u,0x05B1D1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D1u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1D1 CPX
    cpu.compareX(0x16u);
    goto L_05B1D3;
L_05B1D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1D3 BNE -> $05B1DB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1DB; }
    goto L_05B1D5;
L_05B1D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D5u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1D5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B1D8;
L_05B1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1D8 BEQ -> $05B1DB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B1DB; }
    goto L_05B1DA;
L_05B1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1DA INX
    cpu.inc('X');
    goto L_05B1DB;
L_05B1DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DBu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1DB TXA
    cpu.transfer("TXA");
    goto L_05B1DC;
L_05B1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1DC ASL
    cpu.aslA();
    goto L_05B1DD;
L_05B1DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DDu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1DD TAX
    cpu.transfer("TAX");
    goto L_05B1DE;
L_05B1DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1DE REP
    cpu.rep(0x20u);
    goto L_05B1E0;
L_05B1E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E0u, 5u + ((((0xA5A7u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA5A7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1E0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA5A7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B1E3;
L_05B1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1E3 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_05B1E5;
L_05B1E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1E5 REP
    cpu.rep(0x10u);
    goto L_05B1E7;
L_05B1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E7u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E7u, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1E7 LDA
    cpu.loadA(hw.readW(0x7F837Bu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B1EB;
L_05B1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1EB TAX
    cpu.transfer("TAX");
    goto L_05B1EC;
L_05B1EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ECu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1EC LDY
    cpu.setY(0xEu, 16);
    goto L_05B1EF;
L_05B1EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EFu, 5u + 1u, 3u, cpu.address("absy", 0xA580u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1EF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA580u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B1F2;
L_05B1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F2u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F2u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1F2 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05B1F6;
L_05B1F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1F6 LDA
    cpu.setA(0x2300u, 16);
    goto L_05B1F9;
L_05B1F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F9u, 6u, 4u, ((0x7F837Fu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1F9 STA
    hw.write(((0x7F837Fu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05B1FD;
L_05B1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05B1FD PHY
    cpu.push("PHY", hw);
    goto L_05B1FE;
L_05B1FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B1FE SEP
    cpu.sep(0x20u);
    goto L_05B200;
L_05B200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB200u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB200u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B200 LDA
    cpu.setA(0x12u, 8);
    goto L_05B202;
L_05B202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB202u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB202u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B202 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_05B204;
L_05B204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B204 STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    goto L_05B206;
L_05B206:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB206u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB206u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB206u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B206 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05B208;
L_05B208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB208u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB208u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B208 LDA
    cpu.setA(0x1Fu, 8);
    goto L_05B20A;
L_05B20A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Au,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Au, 4u, 3u, cpu.address("abs", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B20A BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x3u), cpu.m8?8:16), false);
    goto L_05B20D;
L_05B20D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B20D BMI -> $05B218
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_05B218; }
    goto L_05B20F;
L_05B20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu, 4u + 1u, 3u, cpu.address("absy", 0xA5D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B20F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA5D9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B212;
L_05B212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB212u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB212u, 4u, 3u, cpu.address("abs", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B212 STA
    hw.write(cpu.address("abs", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_05B215;
L_05B215:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB215u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB215u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB215u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B215 AND
    cpu.logicAnd(0x7Fu);
    goto L_05B217;
L_05B217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B217 INY
    cpu.inc('Y');
    goto L_05B218;
L_05B218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB218u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB218u, 5u, 4u, ((0x7F8381u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B218 STA
    hw.write(((0x7F8381u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05B21C;
L_05B21C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB21Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B21C LDA
    cpu.setA(0x39u, 8);
    goto L_05B21E;
L_05B21E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB21Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Eu, 5u, 4u, ((0x7F8382u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B21E STA
    hw.write(((0x7F8382u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05B222;
L_05B222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB222u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB222u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B222 INX
    cpu.inc('X');
    goto L_05B223;
L_05B223:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB223u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB223u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB223u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B223 INX
    cpu.inc('X');
    goto L_05B224;
L_05B224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB224u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB224u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B224 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_05B226;
L_05B226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB226u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB226u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B226 BNE -> $05B208
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B208; }
    goto L_05B228;
L_05B228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB228u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB228u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B228 STY
    hw.write(cpu.address("dp", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_05B22A;
L_05B22A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B22A REP
    cpu.rep(0x20u);
    goto L_05B22C;
L_05B22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B22C INX
    cpu.inc('X');
    goto L_05B22D;
L_05B22D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B22D INX
    cpu.inc('X');
    goto L_05B22E;
L_05B22E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B22E INX
    cpu.inc('X');
    goto L_05B22F;
L_05B22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B22F INX
    cpu.inc('X');
    goto L_05B230;
L_05B230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB230u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB230u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05B230 PLY
    cpu.pop("PLY", hw);
    goto L_05B231;
L_05B231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB231u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB231u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B231 DEY
    cpu.decReg('Y');
    goto L_05B232;
L_05B232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB232u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB232u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B232 DEY
    cpu.decReg('Y');
    goto L_05B233;
L_05B233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB233u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB233u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B233 BPL -> $05B1EF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_05B1EF; }
    goto L_05B235;
L_05B235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB235u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB235u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B235 LDA
    cpu.setA(0xFFu, 16);
    goto L_05B238;
L_05B238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB238u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB238u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B238 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05B23C;
L_05B23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B23C TXA
    cpu.transfer("TXA");
    goto L_05B23D;
L_05B23D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB23Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Du, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B23D STA
    hw.write(0x7F837Bu, cpu.a, cpu.m8?8:16);
    goto L_05B241;
L_05B241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB241u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB241u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B241 SEP
    cpu.sep(0x30u);
    goto L_05B243;
L_05B243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB243u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB243u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B243 LDA
    cpu.setA(0x1u, 8);
    goto L_05B245;
L_05B245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB245u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB245u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB245u, 4u, 3u, cpu.address("abs", 0x13D5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B245 STA
    hw.write(cpu.address("abs", 0x13D5u), cpu.a, cpu.m8?8:16);
    goto L_05B248;
L_05B248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB248u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB248u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B248 STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_05B24A;
L_05B24A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x23u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B24A STZ
    hw.write(cpu.address("dp", 0x23u), 0, cpu.m8?8:16);
    goto L_05B24C;
L_05B24C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B24C STZ
    hw.write(cpu.address("dp", 0x24u), 0, cpu.m8?8:16);
    goto L_05B24E;
L_05B24E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B24E STZ
    hw.write(cpu.address("dp", 0x25u), 0, cpu.m8?8:16);
    goto L_05B250;
L_05B250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB250u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB250u, 4u, 3u, cpu.address("abs", 0x1B88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B250 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1B88u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05B253;
L_05B253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB253u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB253u, 4u, 3u, cpu.address("abs", 0x1B89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B253 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B89u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B256;
L_05B256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB256u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB256u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B256 CLC
    cpu.setFlag('C', false);
    goto L_05B257;
L_05B257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB257u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB257u, 4u + ((((0xB10Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xB10Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B257 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xB10Au), cpu.m8?8:16));
    goto L_05B25A;
L_05B25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Au, 4u, 3u, cpu.address("abs", 0x1B89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B25A STA
    hw.write(cpu.address("abs", 0x1B89u), cpu.a, cpu.m8?8:16);
    goto L_05B25D;
L_05B25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B25D CLC
    cpu.setFlag('C', false);
    goto L_05B25E;
L_05B25E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B25E ADC
    cpu.adc(0x80u);
    goto L_05B260;
L_05B260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB260u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB260u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B260 XBA
    cpu.xba();
    goto L_05B261;
L_05B261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB261u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB261u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B261 LDA
    cpu.setA(0x80u, 8);
    goto L_05B263;
L_05B263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB263u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB263u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B263 SEC
    cpu.setFlag('C', true);
    goto L_05B264;
L_05B264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB264u, 4u, 3u, cpu.address("abs", 0x1B89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B264 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x1B89u), cpu.m8?8:16));
    goto L_05B267;
L_05B267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB267u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB267u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B267 REP
    cpu.rep(0x20u);
    goto L_05B269;
L_05B269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB269u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB269u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B269 LDX
    cpu.setX(0x0u, 8);
    goto L_05B26B;
L_05B26B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B26B LDY
    cpu.setY(0x50u, 8);
    goto L_05B26D;
L_05B26D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Du,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Du, 4u, 3u, cpu.address("abs", 0x1B89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B26D CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x1B89u), cpu.x8?8:16));
    goto L_05B270;
L_05B270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB270u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB270u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B270 BCC -> $05B275
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x05B275u,0x05B270u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB272u,0x05B270u); return;
}

void sub_0DABFD_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA95Bu: goto L_0DA95B;
    case 0x0DA95Du: goto L_0DA95D;
    case 0x0DA95Eu: goto L_0DA95E;
    case 0x0DA95Fu: goto L_0DA95F;
    case 0x0DA961u: goto L_0DA961;
    case 0x0DA963u: goto L_0DA963;
    case 0x0DA965u: goto L_0DA965;
    case 0x0DA966u: goto L_0DA966;
    case 0x0DA968u: goto L_0DA968;
    case 0x0DA96Au: goto L_0DA96A;
    case 0x0DA96Cu: goto L_0DA96C;
    case 0x0DA96Eu: goto L_0DA96E;
    case 0x0DA970u: goto L_0DA970;
    case 0x0DA972u: goto L_0DA972;
    case 0x0DA974u: goto L_0DA974;
    case 0x0DA977u: goto L_0DA977;
    case 0x0DA979u: goto L_0DA979;
    case 0x0DA97Bu: goto L_0DA97B;
    case 0x0DA97Cu: goto L_0DA97C;
    case 0x0DABFDu: goto L_0DABFD;
    case 0x0DABFFu: goto L_0DABFF;
    case 0x0DAC00u: goto L_0DAC00;
    case 0x0DAC01u: goto L_0DAC01;
    case 0x0DAC03u: goto L_0DAC03;
    case 0x0DAC05u: goto L_0DAC05;
    case 0x0DAC09u: goto L_0DAC09;
    case 0x0DAC0Bu: goto L_0DAC0B;
    case 0x0DAC0Cu: goto L_0DAC0C;
    case 0x0DAC0Eu: goto L_0DAC0E;
    case 0x0DAC11u: goto L_0DAC11;
    case 0x0DAC13u: goto L_0DAC13;
    case 0x0DAC14u: goto L_0DAC14;
    case 0x0DAC18u: goto L_0DAC18;
    case 0x0DAC1Au: goto L_0DAC1A;
    case 0x0DAC1Bu: goto L_0DAC1B;
    case 0x0DAC1Cu: goto L_0DAC1C;
    case 0x0DAC1Eu: goto L_0DAC1E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA95B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Bu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DA95B STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA95D;
L_0DA95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA95D INY
    cpu.inc('Y');
    goto L_0DA95E;
L_0DA95E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA95E TYA
    cpu.transfer("TYA");
    goto L_0DA95F;
L_0DA95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA95F AND
    cpu.logicAnd(0xFu);
    goto L_0DA961;
L_0DA961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA961u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA961u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA961 BNE -> $0DA97C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA97C; }
    goto L_0DA963;
L_0DA963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA963u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA963u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA963 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA965;
L_0DA965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA965u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA965u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA965 CLC
    cpu.setFlag('C', false);
    goto L_0DA966;
L_0DA966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA966u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA966u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA966 ADC
    cpu.adc(0xB0u);
    goto L_0DA968;
L_0DA968:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA968u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA968u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA968u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA968 STA
    hw.write(cpu.address("dp", 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA96A;
L_0DA96A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA96A STA
    hw.write(cpu.address("dp", 0x6Eu), cpu.a, cpu.m8?8:16);
    goto L_0DA96C;
L_0DA96C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA96C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA96E;
L_0DA96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA96E ADC
    cpu.adc(0x1u);
    goto L_0DA970;
L_0DA970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA970u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA970u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA970 STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0DA972;
L_0DA972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA972u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA972u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA972u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA972 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0DA974;
L_0DA974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA974u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA974u, 6u, 3u, cpu.address("abs", 0x1BA1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA974 INC
    cpu.incMem(hw, cpu.address("abs", 0x1BA1u), cpu.m8?8:16);
    goto L_0DA977;
L_0DA977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA977u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA977u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA977 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA979;
L_0DA979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA979u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA979u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA979 AND
    cpu.logicAnd(0xF0u);
    goto L_0DA97B;
L_0DA97B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA97B TAY
    cpu.transfer("TAY");
    goto L_0DA97C;
L_0DA97C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA97C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA97Cu);return;} hw.unresolvedReturn(0x0DA97Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_0DABFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DABFD STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_0DABFF;
L_0DABFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DABFF TXA
    cpu.transfer("TXA");
    goto L_0DAC00;
L_0DAC00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC00u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC00u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DAC00 PHA
    cpu.push("PHA", hw);
    goto L_0DAC01;
L_0DAC01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC01u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAC01 LDX
    cpu.setX(0x2u, 8);
    goto L_0DAC03;
L_0DAC03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC03u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC03u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DAC03 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DAC05;
L_0DAC05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u, 5u, 4u, ((0x0DABF7u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAC05 CMP
    cpu.compareA(hw.readW(((0xDABF7u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DAC09;
L_0DAC09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC09u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAC09 BEQ -> $0DAC11
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DAC11; }
    goto L_0DAC0B;
L_0DAC0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAC0B DEX
    cpu.decReg('X');
    goto L_0DAC0C;
L_0DAC0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAC0C BPL -> $0DAC05
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DAC05; }
    goto L_0DAC0E;
L_0DAC0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Eu, 3u, 3u, cpu.address("abs", 0xAC1Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAC0E JMP -> $0DAC1A
    goto L_0DAC1A;
L_0DAC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC11u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAC11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DAC13;
L_0DAC13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC13u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC13u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAC13 CLC
    cpu.setFlag('C', false);
    goto L_0DAC14;
L_0DAC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC14u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC14u, 5u, 4u, ((0x0DABFAu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAC14 ADC
    cpu.adc(hw.readW(((0xDABFAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DAC18;
L_0DAC18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC18u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAC18 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_0DAC1A;
L_0DAC1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DAC1A PLA
    cpu.pop("PLA", hw);
    goto L_0DAC1B;
L_0DAC1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAC1B TAX
    cpu.transfer("TAX");
    goto L_0DAC1C;
L_0DAC1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAC1C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DAC1E;
L_0DAC1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Eu, 3u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAC1E JMP -> $0DA95B
    goto L_0DA95B;
}

void sub_0DB4D9_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB4D9u: goto L_0DB4D9;
    case 0x0DB4DBu: goto L_0DB4DB;
    case 0x0DB4DDu: goto L_0DB4DD;
    case 0x0DB4DFu: goto L_0DB4DF;
    case 0x0DB4E1u: goto L_0DB4E1;
    case 0x0DB4E5u: goto L_0DB4E5;
    case 0x0DB4E8u: goto L_0DB4E8;
    case 0x0DB4EAu: goto L_0DB4EA;
    case 0x0DB4ECu: goto L_0DB4EC;
    case 0x0DB4F0u: goto L_0DB4F0;
    case 0x0DB4F2u: goto L_0DB4F2;
    case 0x0DB4F5u: goto L_0DB4F5;
    case 0x0DB4F7u: goto L_0DB4F7;
    case 0x0DB4F9u: goto L_0DB4F9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB4D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB4D9 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_0DB4DB;
L_0DB4DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DBu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DBu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB4DB LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB4DD;
L_0DB4DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB4DD CMP
    cpu.compareA(0x8u);
    goto L_0DB4DF;
L_0DB4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB4DF BNE -> $0DB4E8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB4E8; }
    goto L_0DB4E1;
L_0DB4E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E1u, 5u, 4u, ((0x0DB4D5u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB4E1 LDA
    cpu.loadA(hw.readW(((0xDB4D5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB4E5;
L_0DB4E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E5u, 3u, 3u, cpu.address("abs", 0xB4F0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB4E5 JMP -> $0DB4F0
    goto L_0DB4F0;
L_0DB4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB4E8 CMP
    cpu.compareA(0xEu);
    goto L_0DB4EA;
L_0DB4EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB4EA BNE -> $0DB4F2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB4F2; }
    goto L_0DB4EC;
L_0DB4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu, 5u, 4u, ((0x0DB4D7u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB4EC LDA
    cpu.loadA(hw.readW(((0xDB4D7u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB4F0;
L_0DB4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB4F0 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_0DB4F2;
L_0DB4F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F2u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB4F2 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB4F4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4F5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB4F2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB4F5;
L_0DB4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4F5u,0x0DB4F5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB4F5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB4F7;
L_0DB4F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F7u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F7u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB4F7 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DB4F9;
L_0DB4F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB4F9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB4F9u);return;} hw.unresolvedReturn(0x0DB4F9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DDA68_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DDA68u: goto L_0DDA68;
    case 0x0DDA6Au: goto L_0DDA6A;
    case 0x0DDA6Cu: goto L_0DDA6C;
    case 0x0DDA6Du: goto L_0DDA6D;
    case 0x0DDA6Fu: goto L_0DDA6F;
    case 0x0DDA70u: goto L_0DDA70;
    case 0x0DDA73u: goto L_0DDA73;
    case 0x0DDA77u: goto L_0DDA77;
    case 0x0DDA79u: goto L_0DDA79;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DDA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA68u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA68u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDA68 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DDA6A;
L_0DDA6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDA6A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDA6C;
L_0DDA6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDA6C SEC
    cpu.setFlag('C', true);
    goto L_0DDA6D;
L_0DDA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDA6D SBC
    cpu.sbc(0x75u);
    goto L_0DDA6F;
L_0DDA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDA6F TAX
    cpu.transfer("TAX");
    goto L_0DDA70;
L_0DDA70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA70u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA70u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDA70 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xDA72u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDA73u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DDA70u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDA73;
L_0DDA73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA73u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDA73u,0x0DDA73u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA73u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA73u, 5u, 4u, ((0x0DDA61u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDA73 LDA
    cpu.loadA(hw.readW(((0xDDA61u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDA77;
L_0DDA77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA77u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA77u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DDA77 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DDA79;
L_0DDA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA79u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA79u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDA79 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DDA79u);return;} hw.unresolvedReturn(0x0DDA79u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B19098_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB19098u: goto L_B19098;
    case 0xB1909Bu: goto L_B1909B;
    case 0xB1909Du: goto L_B1909D;
    case 0xB1909Fu: goto L_B1909F;
    case 0xB190A2u: goto L_B190A2;
    case 0xB190A4u: goto L_B190A4;
    case 0xB190A6u: goto L_B190A6;
    case 0xB190A7u: goto L_B190A7;
    case 0xB190A9u: goto L_B190A9;
    case 0xB190ACu: goto L_B190AC;
    case 0xB190AEu: goto L_B190AE;
    case 0xB190B1u: goto L_B190B1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B19098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9098u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9098u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19098 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1909B;
L_B1909B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1909B BNE -> $B190B1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B190B1; }
    goto L_B1909D;
L_B1909D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1909D LDA
    cpu.setA(0x8u, 8);
    goto L_B1909F;
L_B1909F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu, 5u, 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1909F STA
    hw.write(cpu.address("absx", 0x15ACu), cpu.a, cpu.m8?8:16);
    goto L_B190A2;
L_B190A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B190A2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B190A4;
L_B190A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A4u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B190A4 EOR
    cpu.logicXor(0xFFu);
    goto L_B190A6;
L_B190A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B190A6 INC
    cpu.inc('A');
    goto L_B190A7;
L_B190A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B190A7 STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B190A9;
L_B190A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B190A9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B190AC;
L_B190AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B190AC EOR
    cpu.logicXor(0x1u);
    goto L_B190AE;
L_B190AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B190AE STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_B190B1;
L_B190B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B190B1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB190B1u);return;} hw.unresolvedReturn(0xB190B1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

