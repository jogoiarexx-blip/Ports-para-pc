#include "generated.hpp"
void sub_0086FA_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0086FAu: goto L_0086FA;
    case 0x0086FCu: goto L_0086FC;
    case 0x0086FDu: goto L_0086FD;
    case 0x0086FFu: goto L_0086FF;
    case 0x008701u: goto L_008701;
    case 0x008704u: goto L_008704;
    case 0x008706u: goto L_008706;
    case 0x008707u: goto L_008707;
    case 0x008709u: goto L_008709;
    case 0x00870Au: goto L_00870A;
    case 0x00870Bu: goto L_00870B;
    case 0x00870Du: goto L_00870D;
    case 0x00870Eu: goto L_00870E;
    case 0x008710u: goto L_008710;
    case 0x008712u: goto L_008712;
    case 0x008713u: goto L_008713;
    case 0x008715u: goto L_008715;
    case 0x008717u: goto L_008717;
    case 0x008719u: goto L_008719;
    case 0x00871Bu: goto L_00871B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0086FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FAu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086FA STY
    hw.write(cpu.address("dp", 0x5u), cpu.y, cpu.x8?8:16);
    goto L_0086FC;
L_0086FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0086FC PLY
    cpu.pop("PLY", hw);
    goto L_0086FD;
L_0086FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FDu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086FD STY
    hw.write(cpu.address("dp", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_0086FF;
L_0086FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086FF REP
    cpu.rep(0x30u);
    goto L_008701;
L_008701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8701u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8701u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008701 AND
    cpu.logicAnd(0xFFu);
    goto L_008704;
L_008704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8704u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8704u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008704 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_008706;
L_008706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8706u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8706u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008706 ASL
    cpu.aslA();
    goto L_008707;
L_008707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008707 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_008709;
L_008709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008709 TAY
    cpu.transfer("TAY");
    goto L_00870A;
L_00870A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00870A PLA
    cpu.pop("PLA", hw);
    goto L_00870B;
L_00870B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00870B STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_00870D;
L_00870D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00870D INY
    cpu.inc('Y');
    goto L_00870E;
L_00870E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x02u) & 0xFFFFu), 3u, 0u);
    // $00870E LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008710;
L_008710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008710 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_008712;
L_008712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008712 INY
    cpu.inc('Y');
    goto L_008713;
L_008713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8713u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8713u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x02u) & 0xFFFFu), 3u, 0u);
    // $008713 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008715;
L_008715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8715u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8715u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008715 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_008717;
L_008717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8717u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8717u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008717 SEP
    cpu.sep(0x30u);
    goto L_008719;
L_008719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8719u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8719u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008719 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00871B;
L_00871B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu,cpu,0xDCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, 0x0000u, 3u, 0u);
    // $00871B JMP [0000] -> dispatcher C++ dinamico
    hw.requestDispatch(hw.read24(0x0000u),0x00871Bu); return;
}

void sub_0086FA_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0086FAu: goto L_0086FA;
    case 0x0086FCu: goto L_0086FC;
    case 0x0086FDu: goto L_0086FD;
    case 0x0086FFu: goto L_0086FF;
    case 0x008701u: goto L_008701;
    case 0x008704u: goto L_008704;
    case 0x008706u: goto L_008706;
    case 0x008707u: goto L_008707;
    case 0x008709u: goto L_008709;
    case 0x00870Au: goto L_00870A;
    case 0x00870Bu: goto L_00870B;
    case 0x00870Du: goto L_00870D;
    case 0x00870Eu: goto L_00870E;
    case 0x008710u: goto L_008710;
    case 0x008712u: goto L_008712;
    case 0x008713u: goto L_008713;
    case 0x008715u: goto L_008715;
    case 0x008717u: goto L_008717;
    case 0x008719u: goto L_008719;
    case 0x00871Bu: goto L_00871B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0086FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FAu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086FA STY
    hw.write(cpu.address("dp", 0x5u), cpu.y, cpu.x8?8:16);
    goto L_0086FC;
L_0086FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0086FC PLY
    cpu.pop("PLY", hw);
    goto L_0086FD;
L_0086FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FDu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086FD STY
    hw.write(cpu.address("dp", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_0086FF;
L_0086FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086FF REP
    cpu.rep(0x30u);
    goto L_008701;
L_008701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8701u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8701u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008701 AND
    cpu.logicAnd(0xFFu);
    goto L_008704;
L_008704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8704u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8704u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008704 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_008706;
L_008706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8706u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8706u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008706 ASL
    cpu.aslA();
    goto L_008707;
L_008707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008707 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_008709;
L_008709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008709 TAY
    cpu.transfer("TAY");
    goto L_00870A;
L_00870A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00870A PLA
    cpu.pop("PLA", hw);
    goto L_00870B;
L_00870B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00870B STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_00870D;
L_00870D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00870D INY
    cpu.inc('Y');
    goto L_00870E;
L_00870E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x02u) & 0xFFFFu), 3u, 0u);
    // $00870E LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008710;
L_008710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008710 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_008712;
L_008712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008712 INY
    cpu.inc('Y');
    goto L_008713;
L_008713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8713u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8713u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x02u) & 0xFFFFu), 3u, 0u);
    // $008713 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008715;
L_008715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8715u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8715u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008715 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_008717;
L_008717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8717u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8717u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008717 SEP
    cpu.sep(0x30u);
    goto L_008719;
L_008719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8719u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8719u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008719 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00871B;
L_00871B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu,cpu,0xDCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, 0x0000u, 3u, 0u);
    // $00871B JMP [0000] -> dispatcher C++ dinamico
    hw.requestDispatch(hw.read24(0x0000u),0x00871Bu); return;
}

void sub_0086FA_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0086FAu: goto L_0086FA;
    case 0x0086FCu: goto L_0086FC;
    case 0x0086FDu: goto L_0086FD;
    case 0x0086FFu: goto L_0086FF;
    case 0x008701u: goto L_008701;
    case 0x008704u: goto L_008704;
    case 0x008706u: goto L_008706;
    case 0x008707u: goto L_008707;
    case 0x008709u: goto L_008709;
    case 0x00870Au: goto L_00870A;
    case 0x00870Bu: goto L_00870B;
    case 0x00870Du: goto L_00870D;
    case 0x00870Eu: goto L_00870E;
    case 0x008710u: goto L_008710;
    case 0x008712u: goto L_008712;
    case 0x008713u: goto L_008713;
    case 0x008715u: goto L_008715;
    case 0x008717u: goto L_008717;
    case 0x008719u: goto L_008719;
    case 0x00871Bu: goto L_00871B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0086FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FAu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086FA STY
    hw.write(cpu.address("dp", 0x5u), cpu.y, cpu.x8?8:16);
    goto L_0086FC;
L_0086FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0086FC PLY
    cpu.pop("PLY", hw);
    goto L_0086FD;
L_0086FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FDu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086FD STY
    hw.write(cpu.address("dp", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_0086FF;
L_0086FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086FF REP
    cpu.rep(0x30u);
    goto L_008701;
L_008701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8701u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8701u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008701 AND
    cpu.logicAnd(0xFFu);
    goto L_008704;
L_008704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8704u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8704u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008704 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_008706;
L_008706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8706u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8706u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008706 ASL
    cpu.aslA();
    goto L_008707;
L_008707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008707 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_008709;
L_008709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008709 TAY
    cpu.transfer("TAY");
    goto L_00870A;
L_00870A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00870A PLA
    cpu.pop("PLA", hw);
    goto L_00870B;
L_00870B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00870B STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_00870D;
L_00870D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00870D INY
    cpu.inc('Y');
    goto L_00870E;
L_00870E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x02u) & 0xFFFFu), 3u, 0u);
    // $00870E LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008710;
L_008710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008710 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_008712;
L_008712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008712 INY
    cpu.inc('Y');
    goto L_008713;
L_008713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8713u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8713u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x02u) & 0xFFFFu), 3u, 0u);
    // $008713 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008715;
L_008715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8715u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8715u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008715 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_008717;
L_008717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8717u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8717u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008717 SEP
    cpu.sep(0x30u);
    goto L_008719;
L_008719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8719u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8719u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008719 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00871B;
L_00871B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu,cpu,0xDCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, 0x0000u, 3u, 0u);
    // $00871B JMP [0000] -> dispatcher C++ dinamico
    hw.requestDispatch(hw.read24(0x0000u),0x00871Bu); return;
}

void sub_008D0F_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008CA0u: goto L_008CA0;
    case 0x008CA1u: goto L_008CA1;
    case 0x008CA2u: goto L_008CA2;
    case 0x008CA3u: goto L_008CA3;
    case 0x008CA6u: goto L_008CA6;
    case 0x008CA7u: goto L_008CA7;
    case 0x008CA8u: goto L_008CA8;
    case 0x008CA9u: goto L_008CA9;
    case 0x008CACu: goto L_008CAC;
    case 0x008CAFu: goto L_008CAF;
    case 0x008CB3u: goto L_008CB3;
    case 0x008CB6u: goto L_008CB6;
    case 0x008CB7u: goto L_008CB7;
    case 0x008CBAu: goto L_008CBA;
    case 0x008CBBu: goto L_008CBB;
    case 0x008CBEu: goto L_008CBE;
    case 0x008CBFu: goto L_008CBF;
    case 0x008D0Fu: goto L_008D0F;
    case 0x008D10u: goto L_008D10;
    case 0x008D11u: goto L_008D11;
    case 0x008D13u: goto L_008D13;
    case 0x008D16u: goto L_008D16;
    case 0x008D17u: goto L_008D17;
    case 0x008D19u: goto L_008D19;
    case 0x008D1Bu: goto L_008D1B;
    case 0x008D1Eu: goto L_008D1E;
    case 0x008D20u: goto L_008D20;
    case 0x008D23u: goto L_008D23;
    case 0x008D25u: goto L_008D25;
    case 0x008D28u: goto L_008D28;
    case 0x008D2Au: goto L_008D2A;
    case 0x008D2Du: goto L_008D2D;
    case 0x008D2Fu: goto L_008D2F;
    case 0x008D32u: goto L_008D32;
    case 0x008D35u: goto L_008D35;
    case 0x008D36u: goto L_008D36;
    case 0x008D38u: goto L_008D38;
    case 0x008D3Au: goto L_008D3A;
    case 0x008D3Du: goto L_008D3D;
    case 0x008D3Fu: goto L_008D3F;
    case 0x008D42u: goto L_008D42;
    case 0x008D44u: goto L_008D44;
    case 0x008D47u: goto L_008D47;
    case 0x008D49u: goto L_008D49;
    case 0x008D4Cu: goto L_008D4C;
    case 0x008D4Eu: goto L_008D4E;
    case 0x008D51u: goto L_008D51;
    case 0x008D54u: goto L_008D54;
    case 0x008D55u: goto L_008D55;
    case 0x008D57u: goto L_008D57;
    case 0x008D59u: goto L_008D59;
    case 0x008D5Cu: goto L_008D5C;
    case 0x008D5Eu: goto L_008D5E;
    case 0x008D61u: goto L_008D61;
    case 0x008D63u: goto L_008D63;
    case 0x008D66u: goto L_008D66;
    case 0x008D68u: goto L_008D68;
    case 0x008D6Bu: goto L_008D6B;
    case 0x008D6Du: goto L_008D6D;
    case 0x008D70u: goto L_008D70;
    case 0x008D73u: goto L_008D73;
    case 0x008D74u: goto L_008D74;
    case 0x008D76u: goto L_008D76;
    case 0x008D78u: goto L_008D78;
    case 0x008D7Bu: goto L_008D7B;
    case 0x008D7Du: goto L_008D7D;
    case 0x008D7Fu: goto L_008D7F;
    case 0x008D82u: goto L_008D82;
    case 0x008D85u: goto L_008D85;
    case 0x008D86u: goto L_008D86;
    case 0x008D87u: goto L_008D87;
    case 0x008D88u: goto L_008D88;
    case 0x008D8Au: goto L_008D8A;
    case 0x008D8Cu: goto L_008D8C;
    case 0x008D8Fu: goto L_008D8F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008CA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CA0 SEC
    cpu.setFlag('C', true);
    goto L_008CA1;
L_008CA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CA1 LSR
    cpu.lsrA();
    goto L_008CA2;
L_008CA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CA2 SEC
    cpu.setFlag('C', true);
    goto L_008CA3;
L_008CA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CA3 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CA5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CA6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CA3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CA6;
L_008CA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CA6u,0x008CA6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CA6 SEC
    cpu.setFlag('C', true);
    goto L_008CA7;
L_008CA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CA7 LSR
    cpu.lsrA();
    goto L_008CA8;
L_008CA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u,cpu,0x78u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CA8 SEI
    cpu.setFlag('I', true);
    goto L_008CA9;
L_008CA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x3D38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CA9 JSR (3D38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x3D38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CACu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CA9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CAC;
L_008CAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CACu,0x008CACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu, 4u + ((((0x3C3Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x3C3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CAC BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x3C3Eu), cpu.m8?8:16), false);
    goto L_008CAF;
L_008CAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu, 5u, 4u, ((0x38FC3Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CAF AND
    cpu.logicAnd(hw.readW(((0x38FC3Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_008CB3;
L_008CB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB3u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB3u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CB3 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CB6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CB6;
L_008CB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CB6u,0x008CB6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CB6 SEC
    cpu.setFlag('C', true);
    goto L_008CB7;
L_008CB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u,cpu,0x2Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u, 6u, 3u, cpu.address("abs", 0x263Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CB7 ROL
    cpu.rolMem(hw, cpu.address("abs", 0x263Cu), cpu.m8?8:16);
    goto L_008CBA;
L_008CBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CBA SEC
    cpu.setFlag('C', true);
    goto L_008CBB;
L_008CBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBBu,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBBu, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CBB JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CBDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CBEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CBBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CBE;
L_008CBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CBEu,0x008CBEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CBE SEC
    cpu.setFlag('C', true);
    goto L_008CBF;
L_008CBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBFu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBFu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $008CBF BRK
    hw.partial(0x008CBFu, "BRK"); return;
L_008D0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D0F ASL
    cpu.aslMem(hw, cpu.address("dp", 0xBDu), cpu.m8?8:16);
    goto L_008D11;
L_008D10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u, 4u + ((((0x8D90u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8D90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D10 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8D90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008D13;
L_008D11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D11u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D11 BCC -> $008CA0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_008CA0; }
    goto L_008D13;
L_008D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D13 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008D16;
L_008D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D16 DEX
    cpu.decReg('X');
    goto L_008D17;
L_008D17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D17 BPL -> $008D10
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008D10; }
    goto L_008D19;
L_008D19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D19 LDA
    cpu.setA(0x2u, 8);
    goto L_008D1B;
L_008D1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Bu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D1B STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008D1E;
L_008D1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D1E LDA
    cpu.setA(0x80u, 8);
    goto L_008D20;
L_008D20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D20u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D20u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D20 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_008D23;
L_008D23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D23u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D23 LDA
    cpu.setA(0x42u, 8);
    goto L_008D25;
L_008D25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D25u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D25u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D25 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008D28;
L_008D28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D28u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D28 LDA
    cpu.setA(0x50u, 8);
    goto L_008D2A;
L_008D2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D2A STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008D2D;
L_008D2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D2D LDX
    cpu.setX(0x6u, 8);
    goto L_008D2F;
L_008D2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Fu, 4u + ((((0x8D97u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8D97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D2F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8D97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008D32;
L_008D32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D32u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D32u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D32 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008D35;
L_008D35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D35u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D35 DEX
    cpu.decReg('X');
    goto L_008D36;
L_008D36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D36u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D36 BPL -> $008D2F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008D2F; }
    goto L_008D38;
L_008D38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D38u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D38 LDA
    cpu.setA(0x2u, 8);
    goto L_008D3A;
L_008D3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Au, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D3A STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008D3D;
L_008D3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D3D LDA
    cpu.setA(0x80u, 8);
    goto L_008D3F;
L_008D3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D3F STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_008D42;
L_008D42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D42u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D42 LDA
    cpu.setA(0x63u, 8);
    goto L_008D44;
L_008D44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D44 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008D47;
L_008D47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D47u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D47 LDA
    cpu.setA(0x50u, 8);
    goto L_008D49;
L_008D49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D49u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D49u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D49 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008D4C;
L_008D4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D4C LDX
    cpu.setX(0x6u, 8);
    goto L_008D4E;
L_008D4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu, 4u + ((((0x8D9Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8D9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D4E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8D9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008D51;
L_008D51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D51u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D51u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D51 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008D54;
L_008D54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D54u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D54 DEX
    cpu.decReg('X');
    goto L_008D55;
L_008D55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D55 BPL -> $008D4E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008D4E; }
    goto L_008D57;
L_008D57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D57u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D57 LDA
    cpu.setA(0x2u, 8);
    goto L_008D59;
L_008D59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D59u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D59u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D59 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008D5C;
L_008D5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D5C LDA
    cpu.setA(0x80u, 8);
    goto L_008D5E;
L_008D5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Eu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D5E STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_008D61;
L_008D61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D61u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D61 LDA
    cpu.setA(0x8Eu, 8);
    goto L_008D63;
L_008D63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D63u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D63u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D63 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008D66;
L_008D66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D66u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D66 LDA
    cpu.setA(0x50u, 8);
    goto L_008D68;
L_008D68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D68u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D68u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D68 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008D6B;
L_008D6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D6B LDX
    cpu.setX(0x6u, 8);
    goto L_008D6D;
L_008D6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Du, 4u + ((((0x8DA5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8DA5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D6D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8DA5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008D70;
L_008D70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D70 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008D73;
L_008D73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D73 DEX
    cpu.decReg('X');
    goto L_008D74;
L_008D74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D74u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D74 BPL -> $008D6D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008D6D; }
    goto L_008D76;
L_008D76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D76 LDA
    cpu.setA(0x2u, 8);
    goto L_008D78;
L_008D78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D78 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008D7B;
L_008D7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D7B LDX
    cpu.setX(0x36u, 8);
    goto L_008D7D;
L_008D7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D7D LDY
    cpu.setY(0x6Cu, 8);
    goto L_008D7F;
L_008D7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu, 4u + ((((0x8C89u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8C89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D7F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8C89u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008D82;
L_008D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 5u, 3u, cpu.address("absx", 0x0EF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D82 STA
    hw.write(cpu.address("absx", 0xEF9u), cpu.a, cpu.m8?8:16);
    goto L_008D85;
L_008D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D85 DEY
    cpu.decReg('Y');
    goto L_008D86;
L_008D86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D86u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D86u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D86 DEY
    cpu.decReg('Y');
    goto L_008D87;
L_008D87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D87 DEX
    cpu.decReg('X');
    goto L_008D88;
L_008D88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D88 BPL -> $008D7F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008D7F; }
    goto L_008D8A;
L_008D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D8A LDA
    cpu.setA(0x28u, 8);
    goto L_008D8C;
L_008D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu, 4u, 3u, cpu.address("abs", 0x0F30u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D8C STA
    hw.write(cpu.address("abs", 0xF30u), cpu.a, cpu.m8?8:16);
    goto L_008D8F;
L_008D8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008D8F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008D8Fu);return;} hw.unresolvedReturn(0x008D8Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_009260_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009260u: goto L_009260;
    case 0x009263u: goto L_009263;
    case 0x009265u: goto L_009265;
    case 0x009268u: goto L_009268;
    case 0x00926Au: goto L_00926A;
    case 0x00926Du: goto L_00926D;
    case 0x009270u: goto L_009270;
    case 0x009271u: goto L_009271;
    case 0x009272u: goto L_009272;
    case 0x009274u: goto L_009274;
    case 0x009276u: goto L_009276;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9260u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9260u, 4u, 3u, cpu.address("abs", 0x0D9Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009260 STZ
    hw.write(cpu.address("abs", 0xD9Fu), 0, cpu.m8?8:16);
    goto L_009263;
L_009263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9263u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9263u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009263 REP
    cpu.rep(0x10u);
    goto L_009265;
L_009265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009265 LDX
    cpu.setX(0x1BEu, 16);
    goto L_009268;
L_009268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009268 LDA
    cpu.setA(0xFFu, 8);
    goto L_00926A;
L_00926A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au, 5u, 3u, cpu.address("absx", 0x04A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00926A STA
    hw.write(cpu.address("absx", 0x4A0u), cpu.a, cpu.m8?8:16);
    goto L_00926D;
L_00926D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Du, 5u, 3u, cpu.address("absx", 0x04A1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00926D STZ
    hw.write(cpu.address("absx", 0x4A1u), 0, cpu.m8?8:16);
    goto L_009270;
L_009270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9270u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9270u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009270 DEX
    cpu.decReg('X');
    goto L_009271;
L_009271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9271u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9271u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009271 DEX
    cpu.decReg('X');
    goto L_009272;
L_009272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9272u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9272u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009272 BPL -> $00926A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00926A; }
    goto L_009274;
L_009274:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9274u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9274u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9274u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009274 SEP
    cpu.sep(0x10u);
    goto L_009276;
L_009276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9276u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9276u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009276 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009276u);return;} hw.unresolvedReturn(0x009276u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_009622_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0093EAu: goto L_0093EA;
    case 0x0093ECu: goto L_0093EC;
    case 0x0093EFu: goto L_0093EF;
    case 0x0093F1u: goto L_0093F1;
    case 0x0093F4u: goto L_0093F4;
    case 0x0093F7u: goto L_0093F7;
    case 0x0093F9u: goto L_0093F9;
    case 0x0093FCu: goto L_0093FC;
    case 0x009622u: goto L_009622;
    case 0x009625u: goto L_009625;
    case 0x009627u: goto L_009627;
    case 0x009629u: goto L_009629;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0093EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EA LDA
    cpu.setA(0x1u, 8);
    goto L_0093EC;
L_0093EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EC STA
    hw.write(cpu.address("abs", 0xD9Bu), cpu.a, cpu.m8?8:16);
    goto L_0093EF;
L_0093EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EF LDA
    cpu.setA(0x20u, 8);
    goto L_0093F1;
L_0093F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u, 6u, 3u, cpu.address("abs", 0x93FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093F1 JSR -> $0093FD stack real
    { cpu.push16Value(hw,0x93F3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93F4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x93FDu), 0x0093F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0093F4;
L_0093F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F4u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F4u,0x0093F4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u, 6u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F4 INC
    cpu.incMem(hw, cpu.address("abs", 0x100u), cpu.m8?8:16);
    goto L_0093F7;
L_0093F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F7 LDA
    cpu.setA(0x81u, 8);
    goto L_0093F9;
L_0093F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F9 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0093FC;
L_0093FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0093FCu);return;} hw.unresolvedReturn(0x0093FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_009622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9622u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9622u, 6u, 3u, cpu.address("abs", 0x9F29u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009622 JSR -> $009F29 stack real
    { cpu.push16Value(hw,0x9624u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9625u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F29u), 0x009622u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009625;
L_009625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9625u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9625u,0x009625u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9625u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9625u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009625 LDA
    cpu.setA(0x9u, 8);
    goto L_009627;
L_009627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9627u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9627u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009627 STA
    hw.write(cpu.address("dp", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_009629;
L_009629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9629u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9629u, 3u, 3u, cpu.address("abs", 0x93EAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009629 JMP -> $0093EA
    goto L_0093EA;
}

void sub_0098A9_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0098A9u: goto L_0098A9;
    case 0x0098ACu: goto L_0098AC;
    case 0x0098ADu: goto L_0098AD;
    case 0x0098AFu: goto L_0098AF;
    case 0x0098B1u: goto L_0098B1;
    case 0x0098B2u: goto L_0098B2;
    case 0x0098B3u: goto L_0098B3;
    case 0x0098B5u: goto L_0098B5;
    case 0x0098B6u: goto L_0098B6;
    case 0x0098B8u: goto L_0098B8;
    case 0x0098BAu: goto L_0098BA;
    case 0x0098BDu: goto L_0098BD;
    case 0x0098C0u: goto L_0098C0;
    case 0x0098C3u: goto L_0098C3;
    case 0x0098C6u: goto L_0098C6;
    case 0x0098C9u: goto L_0098C9;
    case 0x0098CDu: goto L_0098CD;
    case 0x0098D0u: goto L_0098D0;
    case 0x0098D2u: goto L_0098D2;
    case 0x0098D5u: goto L_0098D5;
    case 0x0098D8u: goto L_0098D8;
    case 0x0098DBu: goto L_0098DB;
    case 0x0098DDu: goto L_0098DD;
    case 0x0098E0u: goto L_0098E0;
    case 0x0098E1u: goto L_0098E1;
    case 0x0098E3u: goto L_0098E3;
    case 0x0098E6u: goto L_0098E6;
    case 0x0098E8u: goto L_0098E8;
    case 0x0098EAu: goto L_0098EA;
    case 0x0098EDu: goto L_0098ED;
    case 0x0098EFu: goto L_0098EF;
    case 0x0098F1u: goto L_0098F1;
    case 0x0098F4u: goto L_0098F4;
    case 0x0098F6u: goto L_0098F6;
    case 0x0098F9u: goto L_0098F9;
    case 0x0098FCu: goto L_0098FC;
    case 0x0098FFu: goto L_0098FF;
    case 0x009901u: goto L_009901;
    case 0x009904u: goto L_009904;
    case 0x009906u: goto L_009906;
    case 0x009909u: goto L_009909;
    case 0x00990Cu: goto L_00990C;
    case 0x00990Eu: goto L_00990E;
    case 0x009911u: goto L_009911;
    case 0x009912u: goto L_009912;
    case 0x009914u: goto L_009914;
    case 0x009916u: goto L_009916;
    case 0x009918u: goto L_009918;
    case 0x00991Bu: goto L_00991B;
    case 0x00991Eu: goto L_00991E;
    case 0x00991Fu: goto L_00991F;
    case 0x009920u: goto L_009920;
    case 0x009922u: goto L_009922;
    case 0x009924u: goto L_009924;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0098A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A9u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098A9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0098AC;
L_0098AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ACu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098AC LSR
    cpu.lsrA();
    goto L_0098AD;
L_0098AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ADu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098AD BCS -> $0098E1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_0098E1; }
    goto L_0098AF;
L_0098AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98AFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98AFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098AF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0098B1;
L_0098B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098B1 LSR
    cpu.lsrA();
    goto L_0098B2;
L_0098B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098B2 LSR
    cpu.lsrA();
    goto L_0098B3;
L_0098B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098B3 AND
    cpu.logicAnd(0x6u);
    goto L_0098B5;
L_0098B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098B5 TAX
    cpu.transfer("TAX");
    goto L_0098B6;
L_0098B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098B6 REP
    cpu.rep(0x20u);
    goto L_0098B8;
L_0098B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098B8 LDY
    cpu.setY(0x80u, 8);
    goto L_0098BA;
L_0098BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BAu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BAu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098BA STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_0098BD;
L_0098BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098BD LDA
    cpu.setA(0x1801u, 16);
    goto L_0098C0;
L_0098C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C0u, 5u, 3u, cpu.address("abs", 0x4320u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098C0 STA
    hw.write(cpu.address("abs", 0x4320u), cpu.a, cpu.m8?8:16);
    goto L_0098C3;
L_0098C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098C3 LDA
    cpu.setA(0x7800u, 16);
    goto L_0098C6;
L_0098C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C6u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098C6 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0098C9;
L_0098C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u, 6u, 4u, ((0x05BA39u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098C9 LDA
    cpu.loadA(hw.readW(((0x5BA39u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0098CD;
L_0098CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CDu, 5u, 3u, cpu.address("abs", 0x4322u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098CD STA
    hw.write(cpu.address("abs", 0x4322u), cpu.a, cpu.m8?8:16);
    goto L_0098D0;
L_0098D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098D0 LDY
    cpu.setY(0x7Eu, 8);
    goto L_0098D2;
L_0098D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D2u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D2u, 4u, 3u, cpu.address("abs", 0x4324u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098D2 STY
    hw.write(cpu.address("abs", 0x4324u), cpu.y, cpu.x8?8:16);
    goto L_0098D5;
L_0098D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098D5 LDA
    cpu.setA(0x80u, 16);
    goto L_0098D8;
L_0098D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D8u, 5u, 3u, cpu.address("abs", 0x4325u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098D8 STA
    hw.write(cpu.address("abs", 0x4325u), cpu.a, cpu.m8?8:16);
    goto L_0098DB;
L_0098DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098DB LDY
    cpu.setY(0x4u, 8);
    goto L_0098DD;
L_0098DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DDu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DDu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098DD STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_0098E0;
L_0098E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E0u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098E0 CLC
    cpu.setFlag('C', false);
    goto L_0098E1;
L_0098E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098E1 REP
    cpu.rep(0x20u);
    goto L_0098E3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098E1 REP
    cpu.rep(0x20u);
    goto L_0098E3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98E1u,0x0098E1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0098E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098E3 LDA
    cpu.setA(0x4u, 16);
    goto L_0098E6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098E3 LDA
    cpu.setA(0x4u, 16);
    goto L_0098E6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98E3u,0x0098E3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0098E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098E6 LDY
    cpu.setY(0x6u, 8);
    goto L_0098E8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098E6 LDY
    cpu.setY(0x6u, 8);
    goto L_0098E8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98E6u,0x0098E6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0098E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098E8 BCC -> $0098EF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0098EF; }
    goto L_0098EA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098E8 BCC -> $0098EF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0098EF; }
    goto L_0098EA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98E8u,0x0098E8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0098EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98EAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098EA LDA
    cpu.setA(0x8u, 16);
    goto L_0098ED;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098EA LDA
    cpu.setA(0x8u, 16);
    goto L_0098ED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98EAu,0x0098EAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0098ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98EDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EDu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098ED LDY
    cpu.setY(0x16u, 8);
    goto L_0098EF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EDu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098ED LDY
    cpu.setY(0x16u, 8);
    goto L_0098EF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98EDu,0x0098EDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0098EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98EFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098EF STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0098F1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098EF STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0098F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98EFu,0x0098EFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0098F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098F1 LDA
    cpu.setA(0xC680u, 16);
    goto L_0098F4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098F1 LDA
    cpu.setA(0xC680u, 16);
    goto L_0098F4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98F1u,0x0098F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0098F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098F4 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0098F6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098F4 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0098F6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98F4u,0x0098F4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0098F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F6u, 5u, 3u, cpu.address("abs", 0x2115u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098F6 STZ
    hw.write(cpu.address("abs", 0x2115u), 0, cpu.m8?8:16);
    goto L_0098F9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F6u, 5u, 3u, cpu.address("abs", 0x2115u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098F6 STZ
    hw.write(cpu.address("abs", 0x2115u), 0, cpu.m8?8:16);
    goto L_0098F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98F6u,0x0098F6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0098F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098F9 LDA
    cpu.setA(0x1800u, 16);
    goto L_0098FC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098F9 LDA
    cpu.setA(0x1800u, 16);
    goto L_0098FC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98F9u,0x0098F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0098FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98FCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98FCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98FCu, 5u, 3u, cpu.address("abs", 0x4320u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098FC STA
    hw.write(cpu.address("abs", 0x4320u), cpu.a, cpu.m8?8:16);
    goto L_0098FF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98FCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98FCu, 5u, 3u, cpu.address("abs", 0x4320u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098FC STA
    hw.write(cpu.address("abs", 0x4320u), cpu.a, cpu.m8?8:16);
    goto L_0098FF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98FCu,0x0098FCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0098FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98FFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98FFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098FF LDX
    cpu.setX(0x7Eu, 8);
    goto L_009901;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98FFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0098FF LDX
    cpu.setX(0x7Eu, 8);
    goto L_009901;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98FFu,0x0098FFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9901u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9901u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9901u, 4u, 3u, cpu.address("abs", 0x4324u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009901 STX
    hw.write(cpu.address("abs", 0x4324u), cpu.x, cpu.x8?8:16);
    goto L_009904;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9901u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9901u, 4u, 3u, cpu.address("abs", 0x4324u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009901 STX
    hw.write(cpu.address("abs", 0x4324u), cpu.x, cpu.x8?8:16);
    goto L_009904;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9901u,0x009901u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9904u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9904u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9904u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009904 LDX
    cpu.setX(0x4u, 8);
    goto L_009906;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9904u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9904u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009904 LDX
    cpu.setX(0x4u, 8);
    goto L_009906;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9904u,0x009904u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9906u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9906u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9906u, 5u + ((((0x9891u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9891u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009906 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9891u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009909;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9906u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9906u, 5u + ((((0x9891u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9891u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009906 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9891u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009909;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9906u,0x009906u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9909u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9909u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9909u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009909 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00990C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9909u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9909u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009909 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00990C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9909u,0x009909u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00990C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x990Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x990Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x990Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00990C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00990E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x990Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x990Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00990C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00990E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x990Cu,0x00990Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00990E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x990Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x990Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x990Eu, 5u, 3u, cpu.address("abs", 0x4322u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00990E STA
    hw.write(cpu.address("abs", 0x4322u), cpu.a, cpu.m8?8:16);
    goto L_009911;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x990Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x990Eu, 5u, 3u, cpu.address("abs", 0x4322u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00990E STA
    hw.write(cpu.address("abs", 0x4322u), cpu.a, cpu.m8?8:16);
    goto L_009911;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x990Eu,0x00990Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9911u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9911u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9911u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009911 CLC
    cpu.setFlag('C', false);
    goto L_009912;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9911u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9911u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009911 CLC
    cpu.setFlag('C', false);
    goto L_009912;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9911u,0x009911u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9912u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9912u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009912 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_009914;
L_009914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9914u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9914u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9914u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009914 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_009916;
L_009916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9916u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9916u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9916u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009916 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009918;
L_009918:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9918u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9918u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9918u, 5u, 3u, cpu.address("abs", 0x4325u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009918 STA
    hw.write(cpu.address("abs", 0x4325u), cpu.a, cpu.m8?8:16);
    goto L_00991B;
L_00991B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x991Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x991Bu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x991Bu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00991B STX
    hw.write(cpu.address("abs", 0x420Bu), cpu.x, cpu.x8?8:16);
    goto L_00991E;
L_00991E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x991Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x991Eu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x991Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00991E DEY
    cpu.decReg('Y');
    goto L_00991F;
L_00991F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x991Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x991Fu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x991Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00991F DEY
    cpu.decReg('Y');
    goto L_009920;
L_009920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9920u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9920u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009920 BPL -> $009906
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_009906; }
    goto L_009922;
L_009922:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9922u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9922u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9922u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009922 SEP
    cpu.sep(0x20u);
    goto L_009924;
L_009924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9924u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9924u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9924u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009924 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009924u);return;} hw.unresolvedReturn(0x009924u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00A41C_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A41Cu: goto L_00A41C;
    case 0x00A41Eu: goto L_00A41E;
    case 0x00A421u: goto L_00A421;
    case 0x00A423u: goto L_00A423;
    case 0x00A425u: goto L_00A425;
    case 0x00A426u: goto L_00A426;
    case 0x00A428u: goto L_00A428;
    case 0x00A429u: goto L_00A429;
    case 0x00A42Cu: goto L_00A42C;
    case 0x00A42Fu: goto L_00A42F;
    case 0x00A432u: goto L_00A432;
    case 0x00A435u: goto L_00A435;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A41C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A41C STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_00A41E;
L_00A41E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Eu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A41E STA
    hw.write(cpu.address("abs", 0x2121u), cpu.a, cpu.m8?8:16);
    goto L_00A421;
L_00A421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA421u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA421u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A421 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A423;
L_00A423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA423u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA423u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A423 AND
    cpu.logicAnd(0x1Cu);
    goto L_00A425;
L_00A425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA425u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA425u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A425 LSR
    cpu.lsrA();
    goto L_00A426;
L_00A426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA426u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA426u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A426 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_00A428;
L_00A428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA428u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA428u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA428u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A428 TAY
    cpu.transfer("TAY");
    goto L_00A429;
L_00A429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA429u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA429u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA429u, 4u + ((((0xB60Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xB60Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A429 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB60Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A42C;
L_00A42C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Cu, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A42C STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_00A42F;
L_00A42F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Fu, 4u + ((((0xB60Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xB60Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A42F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB60Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A432;
L_00A432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA432u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA432u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA432u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A432 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_00A435;
L_00A435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA435u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA435u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A435 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A435u);return;} hw.unresolvedReturn(0x00A435u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00A436_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A436u: goto L_00A436;
    case 0x00A439u: goto L_00A439;
    case 0x00A43Bu: goto L_00A43B;
    case 0x00A43Eu: goto L_00A43E;
    case 0x00A440u: goto L_00A440;
    case 0x00A442u: goto L_00A442;
    case 0x00A445u: goto L_00A445;
    case 0x00A448u: goto L_00A448;
    case 0x00A44Bu: goto L_00A44B;
    case 0x00A44Eu: goto L_00A44E;
    case 0x00A451u: goto L_00A451;
    case 0x00A454u: goto L_00A454;
    case 0x00A457u: goto L_00A457;
    case 0x00A459u: goto L_00A459;
    case 0x00A45Cu: goto L_00A45C;
    case 0x00A45Fu: goto L_00A45F;
    case 0x00A462u: goto L_00A462;
    case 0x00A464u: goto L_00A464;
    case 0x00A467u: goto L_00A467;
    case 0x00A46Au: goto L_00A46A;
    case 0x00A46Du: goto L_00A46D;
    case 0x00A470u: goto L_00A470;
    case 0x00A473u: goto L_00A473;
    case 0x00A476u: goto L_00A476;
    case 0x00A479u: goto L_00A479;
    case 0x00A47Cu: goto L_00A47C;
    case 0x00A47Eu: goto L_00A47E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A436:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA436u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA436u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA436u, 4u, 3u, cpu.address("abs", 0x1935u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A436 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1935u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A439;
L_00A439:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA439u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA439u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA439u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A439 BEQ -> $00A47E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A47E; }
    goto L_00A43B;
L_00A43B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Bu, 4u, 3u, cpu.address("abs", 0x1935u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A43B STZ
    hw.write(cpu.address("abs", 0x1935u), 0, cpu.m8?8:16);
    goto L_00A43E;
L_00A43E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A43E REP
    cpu.rep(0x20u);
    goto L_00A440;
L_00A440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA440u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA440u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A440 LDY
    cpu.setY(0x80u, 8);
    goto L_00A442;
L_00A442:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA442u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA442u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA442u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A442 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_00A445;
L_00A445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA445u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA445u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A445 LDA
    cpu.setA(0x64A0u, 16);
    goto L_00A448;
L_00A448:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA448u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA448u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA448u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A448 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00A44B;
L_00A44B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A44B LDA
    cpu.setA(0x1801u, 16);
    goto L_00A44E;
L_00A44E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Eu, 5u, 3u, cpu.address("abs", 0x4320u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A44E STA
    hw.write(cpu.address("abs", 0x4320u), cpu.a, cpu.m8?8:16);
    goto L_00A451;
L_00A451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA451u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA451u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A451 LDA
    cpu.setA(0xBF6u, 16);
    goto L_00A454;
L_00A454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA454u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA454u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA454u, 5u, 3u, cpu.address("abs", 0x4322u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A454 STA
    hw.write(cpu.address("abs", 0x4322u), cpu.a, cpu.m8?8:16);
    goto L_00A457;
L_00A457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA457u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA457u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA457u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A457 LDY
    cpu.setY(0x0u, 8);
    goto L_00A459;
L_00A459:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA459u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA459u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA459u, 4u, 3u, cpu.address("abs", 0x4324u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A459 STY
    hw.write(cpu.address("abs", 0x4324u), cpu.y, cpu.x8?8:16);
    goto L_00A45C;
L_00A45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A45C LDA
    cpu.setA(0xC0u, 16);
    goto L_00A45F;
L_00A45F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Fu, 5u, 3u, cpu.address("abs", 0x4325u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A45F STA
    hw.write(cpu.address("abs", 0x4325u), cpu.a, cpu.m8?8:16);
    goto L_00A462;
L_00A462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA462u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA462u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A462 LDX
    cpu.setX(0x4u, 8);
    goto L_00A464;
L_00A464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA464u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA464u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA464u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A464 STX
    hw.write(cpu.address("abs", 0x420Bu), cpu.x, cpu.x8?8:16);
    goto L_00A467;
L_00A467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA467u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA467u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A467 LDA
    cpu.setA(0x65A0u, 16);
    goto L_00A46A;
L_00A46A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Au, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A46A STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00A46D;
L_00A46D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A46D LDA
    cpu.setA(0xCB6u, 16);
    goto L_00A470;
L_00A470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA470u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA470u, 5u, 3u, cpu.address("abs", 0x4322u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A470 STA
    hw.write(cpu.address("abs", 0x4322u), cpu.a, cpu.m8?8:16);
    goto L_00A473;
L_00A473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A473 LDA
    cpu.setA(0xC0u, 16);
    goto L_00A476;
L_00A476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA476u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA476u, 5u, 3u, cpu.address("abs", 0x4325u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A476 STA
    hw.write(cpu.address("abs", 0x4325u), cpu.a, cpu.m8?8:16);
    goto L_00A479;
L_00A479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA479u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A479 STX
    hw.write(cpu.address("abs", 0x420Bu), cpu.x, cpu.x8?8:16);
    goto L_00A47C;
L_00A47C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A47C SEP
    cpu.sep(0x20u);
    goto L_00A47E;
L_00A47E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA47Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA47Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A47E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A47Eu);return;} hw.unresolvedReturn(0x00A47Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00EADB_E1M1X1CQ_part5(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE36u: goto L_00EE36;
    case 0x00EE37u: goto L_00EE37;
    case 0x00EE38u: goto L_00EE38;
    case 0x00EE39u: goto L_00EE39;
    case 0x00EE3Au: goto L_00EE3A;
    case 0x00EE3Du: goto L_00EE3D;
    case 0x00EE40u: goto L_00EE40;
    case 0x00EE42u: goto L_00EE42;
    case 0x00EE43u: goto L_00EE43;
    case 0x00EE44u: goto L_00EE44;
    case 0x00EE45u: goto L_00EE45;
    case 0x00EE46u: goto L_00EE46;
    case 0x00EE48u: goto L_00EE48;
    case 0x00EE49u: goto L_00EE49;
    case 0x00EE4Au: goto L_00EE4A;
    case 0x00EE4Cu: goto L_00EE4C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE36u))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE36u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE36u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE36 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), false);
    goto L_00EE38;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE36u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE36u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE36 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), false);
    goto L_00EE38;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE36u,0x00EE36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE37u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE37u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE37u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE37 STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00EE39;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE37u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE37u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE37 STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00EE39;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE37u,0x00EE37u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE38u))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE38u,cpu,0x72u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE38u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x60u) & 0xFFFFu), 2u, 0u);
    // $00EE38 ADC
    cpu.adc(hw.readW(cpu.addressDpIndirect(hw, 0x60u), cpu.m8?8:16));
    goto L_00EE3A;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE38u,cpu,0x72u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE38u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x60u) & 0xFFFFu), 2u, 0u);
    // $00EE38 ADC
    cpu.adc(hw.readW(cpu.addressDpIndirect(hw, 0x60u), cpu.m8?8:16));
    goto L_00EE3A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE38u,0x00EE38u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE39u))return;
  // 8 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE39u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE39u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE39 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EE39u);return;} hw.unresolvedReturn(0x00EE39u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE39u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE39u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE39 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EE39u);return;} hw.unresolvedReturn(0x00EE39u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE39u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE39u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE39 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EE39u);return;} hw.unresolvedReturn(0x00EE39u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE39u,0x00EE39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE3Au))return;
  // 13 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Au, 5u, 3u, cpu.address("abs", 0x1693u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE3A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE3D;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Au, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE3A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE3D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Au, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE3A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE3D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE3Au,0x00EE3Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE3Du))return;
  // 13 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Du, 5u, 3u, cpu.address("abs", 0x1931u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE3D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE40;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Du, 5u, 3u, cpu.address("abs", 0x1931u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE3D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE40;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE3Du, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE3D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE40;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE3Du,0x00EE3Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE40u))return;
  // 13 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE40u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE40u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE40 CMP
    cpu.compareA(0xF002u);
    goto L_00EE43;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE40u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE40u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE40 CMP
    cpu.compareA(0xF002u);
    goto L_00EE43;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE40u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE40 CMP
    cpu.compareA(0x2u);
    goto L_00EE42;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE40u,0x00EE40u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE42u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE42u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE42 BEQ -> $00EE48
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE48; }
    goto L_00EE44;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE42u,0x00EE42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE43u))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE43u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE43u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE43 TSB
    cpu.tsb(hw, cpu.address("dp", 0xC9u), cpu.m8?8:16);
    goto L_00EE45;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE43u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE43u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE43 TSB
    cpu.tsb(hw, cpu.address("dp", 0xC9u), cpu.m8?8:16);
    goto L_00EE45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE43u,0x00EE43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE44u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE44u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE44 CMP
    cpu.compareA(0x8u);
    goto L_00EE46;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE44u,0x00EE44u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE45u))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE45u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE45u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EE45 PHP
    cpu.push("PHP", hw);
    goto L_00EE46;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE45u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE45u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EE45 PHP
    cpu.push("PHP", hw);
    goto L_00EE46;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE45u,0x00EE45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE46u))return;
  // 13 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE46u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE46u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE46 BNE -> $00EE57
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE57u,0x00EE46u); return; }
    goto L_00EE48;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE46u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE46u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE46 BNE -> $00EE57
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE57u,0x00EE46u); return; }
    goto L_00EE48;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE46u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE46u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE46 BNE -> $00EE57
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE57u,0x00EE46u); return; }
    goto L_00EE48;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE46u,0x00EE46u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE48u))return;
  // 13 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE48u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE48 TYA
    cpu.transfer("TYA");
    goto L_00EE49;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE48u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE48 TYA
    cpu.transfer("TYA");
    goto L_00EE49;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE48u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE48 TYA
    cpu.transfer("TYA");
    goto L_00EE49;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE48u,0x00EE48u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE49u))return;
  // 13 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE49u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE49 SEC
    cpu.setFlag('C', true);
    goto L_00EE4A;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE49u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE49 SEC
    cpu.setFlag('C', true);
    goto L_00EE4A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE49u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE49 SEC
    cpu.setFlag('C', true);
    goto L_00EE4A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE49u,0x00EE49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE4Au))return;
  // 13 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE4A SBC
    cpu.sbc(0xC90Cu);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Du,0x00EE4Au); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE4A SBC
    cpu.sbc(0xC90Cu);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Du,0x00EE4Au); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE4A SBC
    cpu.sbc(0xCu);
    goto L_00EE4C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Au,0x00EE4Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE4Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE4C CMP
    cpu.compareA(0x2u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Eu,0x00EE4Cu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE4Cu,0x00EE4Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EC21_E0M1X1CQ_part3(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE99u: goto L_00EE99;
    case 0x00EE9Au: goto L_00EE9A;
    case 0x00EE9Bu: goto L_00EE9B;
    case 0x00EE9Cu: goto L_00EE9C;
    case 0x00EE9Du: goto L_00EE9D;
    case 0x00EE9Eu: goto L_00EE9E;
    case 0x00EE9Fu: goto L_00EE9F;
    case 0x00EEA0u: goto L_00EEA0;
    case 0x00EEA2u: goto L_00EEA2;
    case 0x00EEA3u: goto L_00EEA3;
    case 0x00EEA6u: goto L_00EEA6;
    case 0x00EEA8u: goto L_00EEA8;
    case 0x00EEAAu: goto L_00EEAA;
    case 0x00EEABu: goto L_00EEAB;
    case 0x00EEACu: goto L_00EEAC;
    case 0x00EEADu: goto L_00EEAD;
    case 0x00EEAEu: goto L_00EEAE;
    case 0x00EEB1u: goto L_00EEB1;
    case 0x00EEB3u: goto L_00EEB3;
    case 0x00EEB4u: goto L_00EEB4;
    case 0x00EEB7u: goto L_00EEB7;
    case 0x00EEBAu: goto L_00EEBA;
    case 0x00EEBBu: goto L_00EEBB;
    case 0x00EEBEu: goto L_00EEBE;
    case 0x00EEC1u: goto L_00EEC1;
    case 0x00EEC2u: goto L_00EEC2;
    case 0x00EEC4u: goto L_00EEC4;
    case 0x00EEC7u: goto L_00EEC7;
    case 0x00EEC9u: goto L_00EEC9;
    case 0x00EECCu: goto L_00EECC;
    case 0x00EECEu: goto L_00EECE;
    case 0x00EED1u: goto L_00EED1;
    case 0x00EED4u: goto L_00EED4;
    case 0x00EED6u: goto L_00EED6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE99u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE99 BPL -> $00EE64
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE64u,0x00EE99u); return; }
    goto L_00EE9B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE99 BPL -> $00EE64
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE64u,0x00EE99u); return; }
    goto L_00EE9B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE99u,0x00EE99u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9A CMP
    cpu.compareA(0x2u);
    goto L_00EE9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Au,0x00EE9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE9Du,true);
    hw.requestDispatch(0x0082C3u,0x00EE9Bu);return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE9Du,true);
    hw.requestDispatch(0x0082C3u,0x00EE9Bu);return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,0x00EE9Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9C BCS -> $00EED1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EED1; }
    goto L_00EE9E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,0x00EE9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xC2u) & 0xFFFFu), 2u, 0u);
    // $00EE9D AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0xC2u), cpu.m8?8:16));
    goto L_00EE9F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xC2u) & 0xFFFFu), 2u, 0u);
    // $00EE9D AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0xC2u), cpu.m8?8:16));
    goto L_00EE9F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Du,0x00EE9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9E REP
    cpu.rep(0x20u);
    goto L_00EEA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,0x00EE9Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu, 6u, 3u, cpu.address("abs", 0x9AA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE9F JSR -> $009AA5 stack real
    { cpu.push16Value(hw,0xEEA1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEA2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9AA5u), 0x00EE9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEA2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu, 6u, 3u, cpu.address("abs", 0x9AA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE9F JSR -> $009AA5 stack real
    { cpu.push16Value(hw,0xEEA1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEA2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9AA5u), 0x00EE9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,0x00EE9Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA0u,0x00EEA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA2u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA2 SEC
    cpu.setFlag('C', true);
    goto L_00EEA3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA2 SEC
    cpu.setFlag('C', true);
    goto L_00EEA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA2u,0x00EEA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA3u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA3 SBC
    cpu.sbc(0x10u);
    goto L_00EEA6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA3 SBC
    cpu.sbc(0x10u);
    goto L_00EEA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA3u,0x00EEA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA6u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA6 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_00EEA8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA6 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_00EEA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA6u,0x00EEA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA8u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA8 SEP
    cpu.sep(0x20u);
    goto L_00EEAA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA8 SEP
    cpu.sep(0x20u);
    goto L_00EEAA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA8u,0x00EEA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEAAu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAA TXA
    cpu.transfer("TXA");
    goto L_00EEAB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAA TXA
    cpu.transfer("TXA");
    goto L_00EEAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAAu,0x00EEAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEABu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAB LSR
    cpu.lsrA();
    goto L_00EEAC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAB LSR
    cpu.lsrA();
    goto L_00EEAC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEABu,0x00EEABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEACu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAC LSR
    cpu.lsrA();
    goto L_00EEAD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAC LSR
    cpu.lsrA();
    goto L_00EEAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEACu,0x00EEACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEADu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEADu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAD TAX
    cpu.transfer("TAX");
    goto L_00EEAE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEADu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAD TAX
    cpu.transfer("TAX");
    goto L_00EEAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEADu,0x00EEADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEAEu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAEu, 4u + 1u, 3u, cpu.address("absx", 0x1F27u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F27u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEB1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAEu, 4u + ((((0x1F27u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F27u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F27u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEB1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAEu,0x00EEAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB1u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB1 BNE -> $00EED1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EED1; }
    goto L_00EEB3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB1 BNE -> $00EED1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EED1; }
    goto L_00EEB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB1u,0x00EEB1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB3u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB3 INC
    cpu.inc('A');
    goto L_00EEB4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB3 INC
    cpu.inc('A');
    goto L_00EEB4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB3u,0x00EEB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB4u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB4u, 5u, 3u, cpu.address("absx", 0x1F27u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB4 STA
    hw.write(cpu.address("absx", 0x1F27u), cpu.a, cpu.m8?8:16);
    goto L_00EEB7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB4u, 5u, 3u, cpu.address("absx", 0x1F27u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB4 STA
    hw.write(cpu.address("absx", 0x1F27u), cpu.a, cpu.m8?8:16);
    goto L_00EEB7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB4u,0x00EEB4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB7u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB7u, 4u, 3u, cpu.address("abs", 0x13D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB7 STA
    hw.write(cpu.address("abs", 0x13D2u), cpu.a, cpu.m8?8:16);
    goto L_00EEBA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB7u, 4u, 3u, cpu.address("abs", 0x13D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEB7 STA
    hw.write(cpu.address("abs", 0x13D2u), cpu.a, cpu.m8?8:16);
    goto L_00EEBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB7u,0x00EEB7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBAu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBAu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EEBA PHY
    cpu.push("PHY", hw);
    goto L_00EEBB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBAu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EEBA PHY
    cpu.push("PHY", hw);
    goto L_00EEBB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBAu,0x00EEBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBBu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu, 5u, 3u, cpu.address("abs", 0x191Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEBB STX
    hw.write(cpu.address("abs", 0x191Eu), cpu.x, cpu.x8?8:16);
    goto L_00EEBE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu, 4u, 3u, cpu.address("abs", 0x191Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEBB STX
    hw.write(cpu.address("abs", 0x191Eu), cpu.x, cpu.x8?8:16);
    goto L_00EEBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBBu,0x00EEBBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBEu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu, 6u, 3u, cpu.address("abs", 0xFA45u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EEBE JSR -> $00FA45 stack real
    { cpu.push16Value(hw,0xEEC0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEC1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFA45u), 0x00EEBEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEC1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu, 6u, 3u, cpu.address("abs", 0xFA45u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EEBE JSR -> $00FA45 stack real
    { cpu.push16Value(hw,0xEEC0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEC1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFA45u), 0x00EEBEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBEu,0x00EEBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC1u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EEC1 PLY
    cpu.pop("PLY", hw);
    goto L_00EEC2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EEC1 PLY
    cpu.pop("PLY", hw);
    goto L_00EEC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC1u,0x00EEC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC2u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC2 LDA
    cpu.setA(0xCu, 8);
    goto L_00EEC4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC2 LDA
    cpu.setA(0xCu, 8);
    goto L_00EEC4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC2u,0x00EEC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC4u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC4 STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_00EEC7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC4 STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_00EEC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC4u,0x00EEC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC7u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC7 LDA
    cpu.setA(0xFFu, 8);
    goto L_00EEC9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC7 LDA
    cpu.setA(0xFFu, 8);
    goto L_00EEC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC7u,0x00EEC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC9u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC9 STA
    hw.write(cpu.address("abs", 0xDDAu), cpu.a, cpu.m8?8:16);
    goto L_00EECC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEC9 STA
    hw.write(cpu.address("abs", 0xDDAu), cpu.a, cpu.m8?8:16);
    goto L_00EECC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC9u,0x00EEC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EECC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEECCu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EECC LDA
    cpu.setA(0x8u, 8);
    goto L_00EECE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EECC LDA
    cpu.setA(0x8u, 8);
    goto L_00EECE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEECCu,0x00EECCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EECE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEECEu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECEu, 4u, 3u, cpu.address("abs", 0x1493u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EECE STA
    hw.write(cpu.address("abs", 0x1493u), cpu.a, cpu.m8?8:16);
    goto L_00EED1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECEu, 4u, 3u, cpu.address("abs", 0x1493u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EECE STA
    hw.write(cpu.address("abs", 0x1493u), cpu.a, cpu.m8?8:16);
    goto L_00EED1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEECEu,0x00EECEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED1u))return;
  // 8 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED1u,0x00EED1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED4u))return;
  // 8 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED4u,0x00EED4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED6u))return;
  // 8 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED7u,0x00EED6u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED7u,0x00EED6u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED7u,0x00EED6u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED7u,0x00EED6u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED6u,0x00EED6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00F2C9_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F2C9u: goto L_00F2C9;
    case 0x00F2CBu: goto L_00F2CB;
    case 0x00F2CDu: goto L_00F2CD;
    case 0x00F2CFu: goto L_00F2CF;
    case 0x00F2D1u: goto L_00F2D1;
    case 0x00F2D5u: goto L_00F2D5;
    case 0x00F2D8u: goto L_00F2D8;
    case 0x00F2DBu: goto L_00F2DB;
    case 0x00F2DDu: goto L_00F2DD;
    case 0x00F2E0u: goto L_00F2E0;
    case 0x00F2E2u: goto L_00F2E2;
    case 0x00F2E4u: goto L_00F2E4;
    case 0x00F2E6u: goto L_00F2E6;
    case 0x00F2E8u: goto L_00F2E8;
    case 0x00F2EAu: goto L_00F2EA;
    case 0x00F2EDu: goto L_00F2ED;
    case 0x00F2EEu: goto L_00F2EE;
    case 0x00F2F0u: goto L_00F2F0;
    case 0x00F2F2u: goto L_00F2F2;
    case 0x00F2F4u: goto L_00F2F4;
    case 0x00F2F6u: goto L_00F2F6;
    case 0x00F2F8u: goto L_00F2F8;
    case 0x00F2FAu: goto L_00F2FA;
    case 0x00F2FCu: goto L_00F2FC;
    case 0x00F2FEu: goto L_00F2FE;
    case 0x00F300u: goto L_00F300;
    case 0x00F302u: goto L_00F302;
    case 0x00F304u: goto L_00F304;
    case 0x00F306u: goto L_00F306;
    case 0x00F308u: goto L_00F308;
    case 0x00F309u: goto L_00F309;
    case 0x00F30Bu: goto L_00F30B;
    case 0x00F30Du: goto L_00F30D;
    case 0x00F30Fu: goto L_00F30F;
    case 0x00F311u: goto L_00F311;
    case 0x00F313u: goto L_00F313;
    case 0x00F315u: goto L_00F315;
    case 0x00F317u: goto L_00F317;
    case 0x00F31Bu: goto L_00F31B;
    case 0x00F31Eu: goto L_00F31E;
    case 0x00F31Fu: goto L_00F31F;
    case 0x00F322u: goto L_00F322;
    case 0x00F325u: goto L_00F325;
    case 0x00F328u: goto L_00F328;
    case 0x00F329u: goto L_00F329;
    case 0x00F32Bu: goto L_00F32B;
    case 0x00F32Du: goto L_00F32D;
    case 0x00F330u: goto L_00F330;
    case 0x00F332u: goto L_00F332;
    case 0x00F334u: goto L_00F334;
    case 0x00F336u: goto L_00F336;
    case 0x00F338u: goto L_00F338;
    case 0x00F33Au: goto L_00F33A;
    case 0x00F33Bu: goto L_00F33B;
    case 0x00F33Du: goto L_00F33D;
    case 0x00F33Fu: goto L_00F33F;
    case 0x00F343u: goto L_00F343;
    case 0x00F346u: goto L_00F346;
    case 0x00F349u: goto L_00F349;
    case 0x00F34Bu: goto L_00F34B;
    case 0x00F34Du: goto L_00F34D;
    case 0x00F34Eu: goto L_00F34E;
    case 0x00F351u: goto L_00F351;
    case 0x00F354u: goto L_00F354;
    case 0x00F357u: goto L_00F357;
    case 0x00F358u: goto L_00F358;
    case 0x00F35Au: goto L_00F35A;
    case 0x00F35Du: goto L_00F35D;
    case 0x00F35Fu: goto L_00F35F;
    case 0x00F363u: goto L_00F363;
    case 0x00F365u: goto L_00F365;
    case 0x00F367u: goto L_00F367;
    case 0x00F36Bu: goto L_00F36B;
    case 0x00F36Du: goto L_00F36D;
    case 0x00F36Fu: goto L_00F36F;
    case 0x00F373u: goto L_00F373;
    case 0x00F376u: goto L_00F376;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F2C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C9u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2C9 CPY
    cpu.compareY(0x38u);
    goto L_00F2CB;
L_00F2CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2CB BNE -> $00F2EE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F2EE; }
    goto L_00F2CD;
L_00F2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2CD LDA
    cpu.setA(0x2u, 8);
    goto L_00F2CF;
L_00F2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2CF STA
    hw.write(cpu.address("dp", 0x9Cu), cpu.a, cpu.m8?8:16);
    goto L_00F2D1;
L_00F2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D1u, 8u, 4u, 0x00BEB0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F2D1 JSL -> $00BEB0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF2D4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF2D5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00BEB0u, 0x00F2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F2D5;
L_00F2D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2D5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF2D5u,0x00F2D5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D5u, 6u, 3u, cpu.address("abs", 0xFD5Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F2D5 JSR -> $00FD5A stack real
    { cpu.push16Value(hw,0xF2D7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF2D8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFD5Au), 0x00F2D5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F2D8;
L_00F2D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2D8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF2D8u,0x00F2D8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D8u, 4u, 3u, cpu.address("abs", 0x13CDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2D8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13CDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F2DB;
L_00F2DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2DB BEQ -> $00F2E0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F2E0; }
    goto L_00F2DD;
L_00F2DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DDu, 6u, 3u, cpu.address("abs", 0xCA2Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F2DD JSR -> $00CA2B stack real
    { cpu.push16Value(hw,0xF2DFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF2E0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA2Bu), 0x00F2DDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F2E0;
L_00F2E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2E0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF2E0u,0x00F2E0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2E0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F2E2;
L_00F2E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2E2 BNE -> $00F2E8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F2E8; }
    goto L_00F2E4;
L_00F2E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2E4 LDA
    cpu.setA(0x1u, 8);
    goto L_00F2E6;
L_00F2E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2E6 STA
    hw.write(cpu.address("dp", 0x19u), cpu.a, cpu.m8?8:16);
    goto L_00F2E8;
L_00F2E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2E8 LDA
    cpu.setA(0x5u, 8);
    goto L_00F2EA;
L_00F2EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EAu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2EA STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_00F2ED;
L_00F2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F2ED RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F2EDu);return;} hw.unresolvedReturn(0x00F2EDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00F2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EEu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2EE CPY
    cpu.compareY(0x6u);
    goto L_00F2F0;
L_00F2F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2F0 BEQ -> $00F2FC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F2FC; }
    goto L_00F2F2;
L_00F2F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F2u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2F2 CPY
    cpu.compareY(0x7u);
    goto L_00F2F4;
L_00F2F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2F4 BCC -> $00F309
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F309; }
    goto L_00F2F6;
L_00F2F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F6u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2F6 CPY
    cpu.compareY(0x1Du);
    goto L_00F2F8;
L_00F2F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2F8 BCS -> $00F309
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F309; }
    goto L_00F2FA;
L_00F2FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FAu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2FA ORA
    cpu.logicOr(0x80u);
    goto L_00F2FC;
L_00F2FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2FC CMP
    cpu.compareA(0x1u);
    goto L_00F2FE;
L_00F2FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2FE BNE -> $00F302
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F302; }
    goto L_00F300;
L_00F300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF300u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF300u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F300 ORA
    cpu.logicOr(0x18u);
    goto L_00F302;
L_00F302:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF302u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF302u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF302u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F302 TSB
    cpu.tsb(hw, cpu.address("dp", 0x8Bu), cpu.m8?8:16);
    goto L_00F304;
L_00F304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF304u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF304u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x93u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F304 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x93u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F306;
L_00F306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF306u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF306u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F306 STA
    hw.write(cpu.address("dp", 0x8Cu), cpu.a, cpu.m8?8:16);
    goto L_00F308;
L_00F308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF308u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF308u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F308 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F308u);return;} hw.unresolvedReturn(0x00F308u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00F309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF309u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF309u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F309 CPY
    cpu.compareY(0x2Fu);
    goto L_00F30B;
L_00F30B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF30Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F30B BCS -> $00F311
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F311; }
    goto L_00F30D;
L_00F30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF30Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Du,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F30D CPY
    cpu.compareY(0x2Au);
    goto L_00F30F;
L_00F30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F30F BCS -> $00F32B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F32B; }
    goto L_00F311;
L_00F311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF311u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF311u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F311 CPY
    cpu.compareY(0x6Eu);
    goto L_00F313;
L_00F313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF313u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF313u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F313 BNE -> $00F376
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F376; }
    goto L_00F315;
L_00F315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF315u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF315u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F315 LDA
    cpu.setA(0xFu, 8);
    goto L_00F317;
L_00F317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF317u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF317u, 8u, 4u, 0x00F38Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F317 JSL -> $00F38A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF31Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF31Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F38Au, 0x00F317u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F31B;
L_00F31B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF31Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF31Bu,0x00F31Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Bu, 6u, 3u, cpu.address("abs", 0x13C5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F31B INC
    cpu.incMem(hw, cpu.address("abs", 0x13C5u), cpu.m8?8:16);
    goto L_00F31E;
L_00F31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Eu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F31E PHX
    cpu.push("PHX", hw);
    goto L_00F31F;
L_00F31F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF31Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Fu, 6u, 3u, cpu.address("abs", 0xF3B2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F31F JSR -> $00F3B2 stack real
    { cpu.push16Value(hw,0xF321u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF322u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF3B2u), 0x00F31Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F322;
L_00F322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF322u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF322u,0x00F322u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF322u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF322u, 4u + ((((0x1FEEu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1FEEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F322 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x1FEEu), cpu.m8?8:16));
    goto L_00F325;
L_00F325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF325u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF325u, 5u, 3u, cpu.address("absy", 0x1FEEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F325 STA
    hw.write(cpu.address("absy", 0x1FEEu), cpu.a, cpu.m8?8:16);
    goto L_00F328;
L_00F328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF328u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF328u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F328 PLX
    cpu.pop("PLX", hw);
    goto L_00F329;
L_00F329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF329u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF329u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F329 BRA -> $00F36B
    goto L_00F36B;
L_00F32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F32B BNE -> $00F332
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F332; }
    goto L_00F32D;
L_00F32D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF32Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Du, 4u, 3u, cpu.address("abs", 0x14ADu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F32D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14ADu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F330;
L_00F330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF330u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF330u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F330 BEQ -> $00F376
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F376; }
    goto L_00F332;
L_00F332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF332u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF332u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F332 CPY
    cpu.compareY(0x2Du);
    goto L_00F334;
L_00F334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF334u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF334u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F334 BEQ -> $00F33F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F33F; }
    goto L_00F336;
L_00F336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF336u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF336u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F336 BCC -> $00F367
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F367; }
    goto L_00F338;
L_00F338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF338u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF338u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F338 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F33A;
L_00F33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F33A SEC
    cpu.setFlag('C', true);
    goto L_00F33B;
L_00F33B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF33Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F33B SBC
    cpu.sbc(0x10u);
    goto L_00F33D;
L_00F33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F33D STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_00F33F;
L_00F33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Fu, 8u, 4u, 0x00F377u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F33F JSL -> $00F377 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF342u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF343u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F377u, 0x00F33Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F343;
L_00F343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF343u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF343u,0x00F343u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF343u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF343u, 6u, 3u, cpu.address("abs", 0x1422u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F343 INC
    cpu.incMem(hw, cpu.address("abs", 0x1422u), cpu.m8?8:16);
    goto L_00F346;
L_00F346:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF346u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF346u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF346u, 4u, 3u, cpu.address("abs", 0x1422u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F346 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1422u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F349;
L_00F349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF349u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF349u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F349 CMP
    cpu.compareA(0x5u);
    goto L_00F34B;
L_00F34B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF34Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F34B BCC -> $00F358
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F358; }
    goto L_00F34D;
L_00F34D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF34Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Du,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F34D PHX
    cpu.push("PHX", hw);
    goto L_00F34E;
L_00F34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Eu, 6u, 3u, cpu.address("abs", 0xF3B2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F34E JSR -> $00F3B2 stack real
    { cpu.push16Value(hw,0xF350u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF351u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF3B2u), 0x00F34Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F351;
L_00F351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF351u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF351u,0x00F351u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF351u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF351u, 4u + ((((0x1F2Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1F2Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F351 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x1F2Fu), cpu.m8?8:16));
    goto L_00F354;
L_00F354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF354u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF354u, 5u, 3u, cpu.address("absy", 0x1F2Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F354 STA
    hw.write(cpu.address("absy", 0x1F2Fu), cpu.a, cpu.m8?8:16);
    goto L_00F357;
L_00F357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF357u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF357u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F357 PLX
    cpu.pop("PLX", hw);
    goto L_00F358;
L_00F358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF358u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF358u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF358u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F358 LDA
    cpu.setA(0x1Cu, 8);
    goto L_00F35A;
L_00F35A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF35Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Au, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F35A STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_00F35D;
L_00F35D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF35Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F35D LDA
    cpu.setA(0x1u, 8);
    goto L_00F35F;
L_00F35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Fu, 8u, 4u, 0x05B330u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F35F JSL -> $05B330 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF362u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF363u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05B330u, 0x00F35Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F363;
L_00F363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF363u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF363u,0x00F363u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF363u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF363u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F363 LDY
    cpu.setY(0x18u, 8);
    goto L_00F365;
L_00F365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF365u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF365u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F365 BRA -> $00F36D
    goto L_00F36D;
L_00F367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF367u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF367u, 8u, 4u, 0x05B34Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F367 JSL -> $05B34A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF36Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF36Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05B34Au, 0x00F367u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F36B;
L_00F36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF36Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF36Bu,0x00F36Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F36B LDY
    cpu.setY(0x1u, 8);
    goto L_00F36D;
L_00F36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Du,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F36D STY
    hw.write(cpu.address("dp", 0x9Cu), cpu.y, cpu.x8?8:16);
    goto L_00F36F;
L_00F36F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF36Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Fu, 8u, 4u, 0x00BEB0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F36F JSL -> $00BEB0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF372u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF373u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00BEB0u, 0x00F36Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F373;
L_00F373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF373u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF373u,0x00F373u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF373u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF373u, 6u, 3u, cpu.address("abs", 0xFD5Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F373 JSR -> $00FD5A stack real
    { cpu.push16Value(hw,0xF375u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF376u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFD5Au), 0x00F373u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F376;
L_00F376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF376u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF376u,0x00F376u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF376u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF376u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F376 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F376u);return;} hw.unresolvedReturn(0x00F376u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00FE4A_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00FE4Au: goto L_00FE4A;
    case 0x00FE4Cu: goto L_00FE4C;
    case 0x00FE4Eu: goto L_00FE4E;
    case 0x00FE50u: goto L_00FE50;
    case 0x00FE52u: goto L_00FE52;
    case 0x00FE54u: goto L_00FE54;
    case 0x00FE56u: goto L_00FE56;
    case 0x00FE58u: goto L_00FE58;
    case 0x00FE5Au: goto L_00FE5A;
    case 0x00FE5Cu: goto L_00FE5C;
    case 0x00FE5Eu: goto L_00FE5E;
    case 0x00FE60u: goto L_00FE60;
    case 0x00FE61u: goto L_00FE61;
    case 0x00FE63u: goto L_00FE63;
    case 0x00FE65u: goto L_00FE65;
    case 0x00FE67u: goto L_00FE67;
    case 0x00FE69u: goto L_00FE69;
    case 0x00FE6Cu: goto L_00FE6C;
    case 0x00FE6Eu: goto L_00FE6E;
    case 0x00FE6Fu: goto L_00FE6F;
    case 0x00FE71u: goto L_00FE71;
    case 0x00FE72u: goto L_00FE72;
    case 0x00FE74u: goto L_00FE74;
    case 0x00FE77u: goto L_00FE77;
    case 0x00FE79u: goto L_00FE79;
    case 0x00FE7Bu: goto L_00FE7B;
    case 0x00FE7Eu: goto L_00FE7E;
    case 0x00FE80u: goto L_00FE80;
    case 0x00FE82u: goto L_00FE82;
    case 0x00FE83u: goto L_00FE83;
    case 0x00FE86u: goto L_00FE86;
    case 0x00FE88u: goto L_00FE88;
    case 0x00FE8Au: goto L_00FE8A;
    case 0x00FE8Du: goto L_00FE8D;
    case 0x00FE8Eu: goto L_00FE8E;
    case 0x00FE90u: goto L_00FE90;
    case 0x00FE93u: goto L_00FE93;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00FE4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE4Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE4Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE4A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FE4C;
L_00FE4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE4Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE4C AND
    cpu.logicAnd(0x3u);
    goto L_00FE4E;
L_00FE4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE4Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE4Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE4E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16));
    goto L_00FE50;
L_00FE50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE50u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE50u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE50 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x7Fu), cpu.m8?8:16));
    goto L_00FE52;
L_00FE52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE52u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE52u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x81u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE52 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x81u), cpu.m8?8:16));
    goto L_00FE54;
L_00FE54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE54u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE54u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE54 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16));
    goto L_00FE56;
L_00FE56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE56u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE56 BNE -> $00FE71
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FE71; }
    goto L_00FE58;
L_00FE58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE58u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE58u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE58 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FE5A;
L_00FE5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE5A AND
    cpu.logicAnd(0x4u);
    goto L_00FE5C;
L_00FE5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE5C BEQ -> $00FE67
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FE67; }
    goto L_00FE5E;
L_00FE5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE5E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FE60;
L_00FE60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE60u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE60u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE60 CLC
    cpu.setFlag('C', false);
    goto L_00FE61;
L_00FE61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE61u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE61 ADC
    cpu.adc(0x8u);
    goto L_00FE63;
L_00FE63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE63u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE63 CMP
    cpu.compareA(0x10u);
    goto L_00FE65;
L_00FE65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE65u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE65 BCC -> $00FE71
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00FE71; }
    goto L_00FE67;
L_00FE67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE67u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE67 LDY
    cpu.setY(0x3u, 8);
    goto L_00FE69;
L_00FE69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE69u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE69u, 4u + ((((0x17C0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x17C0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE69 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x17C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FE6C;
L_00FE6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE6Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE6C BEQ -> $00FE72
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FE72; }
    goto L_00FE6E;
L_00FE6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE6Eu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE6Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE6E DEY
    cpu.decReg('Y');
    goto L_00FE6F;
L_00FE6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE6Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE6Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE6F BNE -> $00FE69
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FE69; }
    goto L_00FE71;
L_00FE71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE71u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE71u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00FE71 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00FE71u);return;} hw.unresolvedReturn(0x00FE71u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00FE72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE72u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE72 LDA
    cpu.setA(0x3u, 8);
    goto L_00FE74;
L_00FE74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE74u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE74u, 5u, 3u, cpu.address("absy", 0x17C0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE74 STA
    hw.write(cpu.address("absy", 0x17C0u), cpu.a, cpu.m8?8:16);
    goto L_00FE77;
L_00FE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE77u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE77u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE77 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FE79;
L_00FE79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE79u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE79 ADC
    cpu.adc(0x4u);
    goto L_00FE7B;
L_00FE7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE7Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE7Bu, 5u, 3u, cpu.address("absy", 0x17C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE7B STA
    hw.write(cpu.address("absy", 0x17C8u), cpu.a, cpu.m8?8:16);
    goto L_00FE7E;
L_00FE7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE7Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE7Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE7E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FE80;
L_00FE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE80u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE80u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE80 ADC
    cpu.adc(0x1Au);
    goto L_00FE82;
L_00FE82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE82u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE82u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00FE82 PHX
    cpu.push("PHX", hw);
    goto L_00FE83;
L_00FE83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE83u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE83u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE83 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x187Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00FE86;
L_00FE86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE86u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE86u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE86 BEQ -> $00FE8A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FE8A; }
    goto L_00FE88;
L_00FE88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE88u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE88 ADC
    cpu.adc(0x10u);
    goto L_00FE8A;
L_00FE8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Au, 5u, 3u, cpu.address("absy", 0x17C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE8A STA
    hw.write(cpu.address("absy", 0x17C4u), cpu.a, cpu.m8?8:16);
    goto L_00FE8D;
L_00FE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Du,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00FE8D PLX
    cpu.pop("PLX", hw);
    goto L_00FE8E;
L_00FE8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE8E LDA
    cpu.setA(0x13u, 8);
    goto L_00FE90;
L_00FE90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE90u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE90u, 5u, 3u, cpu.address("absy", 0x17CCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE90 STA
    hw.write(cpu.address("absy", 0x17CCu), cpu.a, cpu.m8?8:16);
    goto L_00FE93;
L_00FE93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE93u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE93u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00FE93 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00FE93u);return;} hw.unresolvedReturn(0x00FE93u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_018FC1_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018FC1u: goto L_018FC1;
    case 0x018FC4u: goto L_018FC4;
    case 0x01A7E4u: goto L_01A7E4;
    case 0x01A7E7u: goto L_01A7E7;
    case 0x01A7E9u: goto L_01A7E9;
    case 0x01A7EBu: goto L_01A7EB;
    case 0x01A7ECu: goto L_01A7EC;
    case 0x01A7EEu: goto L_01A7EE;
    case 0x01A7F0u: goto L_01A7F0;
    case 0x01A7F3u: goto L_01A7F3;
    case 0x01A7F5u: goto L_01A7F5;
    case 0x01A7F7u: goto L_01A7F7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018FC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u, 6u, 3u, cpu.address("abs", 0xA40Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018FC1 JSR -> $01A40D stack real
    { cpu.push16Value(hw,0x8FC3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8FC4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA40Du), 0x018FC1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018FC4;
L_018FC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC4u, 3u, 3u, cpu.address("abs", 0xA7E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018FC4 JMP -> $01A7E4
    goto L_01A7E4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC4u, 3u, 3u, cpu.address("abs", 0xA7E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018FC4 JMP -> $01A7E4
    goto L_01A7E4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FC4u,0x018FC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01A7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E4u, 4u + ((((0x167Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x167Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7E4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x167Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A7E7;
L_01A7E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7E7 AND
    cpu.logicAnd(0x20u);
    goto L_01A7E9;
L_01A7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7E9 BNE -> $01A7F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A7F7; }
    goto L_01A7EB;
L_01A7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EBu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7EB TXA
    cpu.transfer("TXA");
    goto L_01A7EC;
L_01A7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ECu,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7EC EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_01A7EE;
L_01A7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7EE AND
    cpu.logicAnd(0x1u);
    goto L_01A7F0;
L_01A7F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F0u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F0u, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7F0 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16));
    goto L_01A7F3;
L_01A7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7F3 BEQ -> $01A7F7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A7F7; }
    goto L_01A7F5;
L_01A7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7F5 CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7F6u,0x01A7F5u); return;
L_01A7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F7u, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A7F7 JSR -> $01AD30 stack real
    { cpu.push16Value(hw,0xA7F9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7FAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0x01A7F7u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7FAu,0x01A7F7u); return;
}

void sub_01928E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01928Eu: goto L_01928E;
    case 0x019290u: goto L_019290;
    case 0x019291u: goto L_019291;
    case 0x019294u: goto L_019294;
    case 0x019297u: goto L_019297;
    case 0x019299u: goto L_019299;
    case 0x01929Cu: goto L_01929C;
    case 0x01929Eu: goto L_01929E;
    case 0x0192A0u: goto L_0192A0;
    case 0x0192A2u: goto L_0192A2;
    case 0x0192A4u: goto L_0192A4;
    case 0x0192A7u: goto L_0192A7;
    case 0x0192AAu: goto L_0192AA;
    case 0x0192ADu: goto L_0192AD;
    case 0x0192B0u: goto L_0192B0;
    case 0x0192B2u: goto L_0192B2;
    case 0x0192B5u: goto L_0192B5;
    case 0x0192B7u: goto L_0192B7;
    case 0x0192BAu: goto L_0192BA;
    case 0x0192BDu: goto L_0192BD;
    case 0x0192C0u: goto L_0192C0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01928E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01928E AND
    cpu.logicAnd(0x1u);
    goto L_019290;
L_019290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9290u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9290u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019290 TAY
    cpu.transfer("TAY");
    goto L_019291;
L_019291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9291u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9291u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9291u, 6u, 3u, cpu.address("abs", 0x9441u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019291 JSR -> $019441 stack real
    { cpu.push16Value(hw,0x9293u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9294u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9441u), 0x019291u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019294;
L_019294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9294u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9294u,0x019294u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9294u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9294u, 4u, 3u, cpu.address("abs", 0x1862u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019294 STA
    hw.write(cpu.address("abs", 0x1862u), cpu.a, cpu.m8?8:16);
    goto L_019297;
L_019297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9297u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9297u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019297 BEQ -> $0192BA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0192BA; }
    goto L_019299;
L_019299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9299u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019299 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01929C;
L_01929C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01929C CMP
    cpu.compareA(0x11u);
    goto L_01929E;
L_01929E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01929E BCC -> $0192BA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0192BA; }
    goto L_0192A0;
L_0192A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0192A0 CMP
    cpu.compareA(0x6Eu);
    goto L_0192A2;
L_0192A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0192A2 BCS -> $0192BA
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_0192BA; }
    goto L_0192A4;
L_0192A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A4u, 6u, 3u, cpu.address("abs", 0x9425u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0192A4 JSR -> $019425 stack real
    { cpu.push16Value(hw,0x92A6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x92A7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9425u), 0x0192A4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0192A7;
L_0192A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92A7u,0x0192A7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A7u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0192A7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0192AA;
L_0192AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92AAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92AAu, 4u, 3u, cpu.address("abs", 0x18A7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0192AA STA
    hw.write(cpu.address("abs", 0x18A7u), cpu.a, cpu.m8?8:16);
    goto L_0192AD;
L_0192AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ADu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ADu, 4u, 3u, cpu.address("abs", 0x185Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0192AD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x185Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0192B0;
L_0192B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0192B0 BEQ -> $0192BA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0192BA; }
    goto L_0192B2;
L_0192B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B2u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0192B2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0192B5;
L_0192B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B5u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0192B5 ORA
    cpu.logicOr(0x40u);
    goto L_0192B7;
L_0192B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B7u, 5u, 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0192B7 STA
    hw.write(cpu.address("absx", 0x1588u), cpu.a, cpu.m8?8:16);
    goto L_0192BA;
L_0192BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BAu, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0192BA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0192BD;
L_0192BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BDu, 4u, 3u, cpu.address("abs", 0x1860u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0192BD STA
    hw.write(cpu.address("abs", 0x1860u), cpu.a, cpu.m8?8:16);
    goto L_0192C0;
L_0192C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0192C0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0192C0u);return;} hw.unresolvedReturn(0x0192C0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02A9E4_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02A9E4u: goto L_02A9E4;
    case 0x02A9E6u: goto L_02A9E6;
    case 0x02A9E7u: goto L_02A9E7;
    case 0x02A9E8u: goto L_02A9E8;
    case 0x02A9E9u: goto L_02A9E9;
    case 0x02A9ECu: goto L_02A9EC;
    case 0x02A9EDu: goto L_02A9ED;
    case 0x02A9EEu: goto L_02A9EE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02A9E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02A9E4 STZ
    hw.write(cpu.address("dp", 0xEu), 0, cpu.m8?8:16);
    goto L_02A9E6;
L_02A9E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E6u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02A9E6 PHB
    cpu.push("PHB", hw);
    goto L_02A9E7;
L_02A9E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02A9E7 PHK
    cpu.push("PHK", hw);
    goto L_02A9E8;
L_02A9E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E8u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02A9E8 PLB
    cpu.pop("PLB", hw);
    goto L_02A9E9;
L_02A9E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E9u, 6u, 3u, cpu.address("abs", 0xA9EFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02A9E9 JSR -> $02A9EF stack real
    { cpu.push16Value(hw,0xA9EBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA9ECu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA9EFu), 0x02A9E9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02A9EC;
L_02A9EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9ECu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA9ECu,0x02A9ECu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ECu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ECu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02A9EC PLB
    cpu.pop("PLB", hw);
    goto L_02A9ED;
L_02A9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02A9ED TYA
    cpu.transfer("TYA");
    goto L_02A9EE;
L_02A9EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02A9EE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02A9EEu);return;} hw.unresolvedReturn(0x02A9EEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0DB5E8_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB5E8u: goto L_0DB5E8;
    case 0x0DB5EAu: goto L_0DB5EA;
    case 0x0DB5EBu: goto L_0DB5EB;
    case 0x0DB5ECu: goto L_0DB5EC;
    case 0x0DB5EDu: goto L_0DB5ED;
    case 0x0DB5EEu: goto L_0DB5EE;
    case 0x0DB5F0u: goto L_0DB5F0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB5E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E8u,cpu,0x07u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $0DB5E8 ORA
    cpu.logicOr(hw.readW(cpu.addressDpLong(hw, 0xAu), cpu.m8?8:16));
    goto L_0DB5EA;
L_0DB5EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5EA ASL
    cpu.aslA();
    goto L_0DB5EB;
L_0DB5EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EBu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DB5EB PHP
    cpu.push("PHP", hw);
    goto L_0DB5EC;
L_0DB5EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5EC ASL
    cpu.aslA();
    goto L_0DB5ED;
L_0DB5ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5ED ASL
    cpu.aslA();
    goto L_0DB5EE;
L_0DB5EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5EE ORA
    cpu.logicOr(0x81u);
    goto L_0DB5F0;
L_0DB5F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F0u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F0u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB5F0 BRL -> $0D3776
    hw.unresolvedFlow(0x0DB5F0u,0x0D3776u,cpu); return;
}

void sub_0DC190_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DC190u: goto L_0DC190;
    case 0x0DC192u: goto L_0DC192;
    case 0x0DC194u: goto L_0DC194;
    case 0x0DC195u: goto L_0DC195;
    case 0x0DC196u: goto L_0DC196;
    case 0x0DC19Au: goto L_0DC19A;
    case 0x0DC19Cu: goto L_0DC19C;
    case 0x0DC19Fu: goto L_0DC19F;
    case 0x0DC1A2u: goto L_0DC1A2;
    case 0x0DC1A5u: goto L_0DC1A5;
    case 0x0DC1A8u: goto L_0DC1A8;
    case 0x0DC1ABu: goto L_0DC1AB;
    case 0x0DC1AEu: goto L_0DC1AE;
    case 0x0DC1B1u: goto L_0DC1B1;
    case 0x0DC1B4u: goto L_0DC1B4;
    case 0x0DC1B7u: goto L_0DC1B7;
    case 0x0DC1BAu: goto L_0DC1BA;
    case 0x0DC1BDu: goto L_0DC1BD;
    case 0x0DC1C0u: goto L_0DC1C0;
    case 0x0DC1C3u: goto L_0DC1C3;
    case 0x0DC1C6u: goto L_0DC1C6;
    case 0x0DC1C9u: goto L_0DC1C9;
    case 0x0DC1CCu: goto L_0DC1CC;
    case 0x0DC1CFu: goto L_0DC1CF;
    case 0x0DC1D2u: goto L_0DC1D2;
    case 0x0DC1D5u: goto L_0DC1D5;
    case 0x0DC1D8u: goto L_0DC1D8;
    case 0x0DC1DBu: goto L_0DC1DB;
    case 0x0DC1DEu: goto L_0DC1DE;
    case 0x0DC1E1u: goto L_0DC1E1;
    case 0x0DC1E4u: goto L_0DC1E4;
    case 0x0DC1E7u: goto L_0DC1E7;
    case 0x0DC1EAu: goto L_0DC1EA;
    case 0x0DC1EDu: goto L_0DC1ED;
    case 0x0DC1F0u: goto L_0DC1F0;
    case 0x0DC1F3u: goto L_0DC1F3;
    case 0x0DC1F6u: goto L_0DC1F6;
    case 0x0DC1F9u: goto L_0DC1F9;
    case 0x0DC1FCu: goto L_0DC1FC;
    case 0x0DC1FFu: goto L_0DC1FF;
    case 0x0DC202u: goto L_0DC202;
    case 0x0DC205u: goto L_0DC205;
    case 0x0DC208u: goto L_0DC208;
    case 0x0DC20Bu: goto L_0DC20B;
    case 0x0DC20Eu: goto L_0DC20E;
    case 0x0DC211u: goto L_0DC211;
    case 0x0DC214u: goto L_0DC214;
    case 0x0DC217u: goto L_0DC217;
    case 0x0DC21Au: goto L_0DC21A;
    case 0x0DC21Du: goto L_0DC21D;
    case 0x0DC220u: goto L_0DC220;
    case 0x0DC223u: goto L_0DC223;
    case 0x0DC226u: goto L_0DC226;
    case 0x0DC229u: goto L_0DC229;
    case 0x0DC22Cu: goto L_0DC22C;
    case 0x0DC22Fu: goto L_0DC22F;
    case 0x0DC232u: goto L_0DC232;
    case 0x0DC235u: goto L_0DC235;
    case 0x0DC238u: goto L_0DC238;
    case 0x0DC23Bu: goto L_0DC23B;
    case 0x0DC23Eu: goto L_0DC23E;
    case 0x0DC241u: goto L_0DC241;
    case 0x0DC244u: goto L_0DC244;
    case 0x0DC247u: goto L_0DC247;
    case 0x0DC24Au: goto L_0DC24A;
    case 0x0DC24Du: goto L_0DC24D;
    case 0x0DC250u: goto L_0DC250;
    case 0x0DC253u: goto L_0DC253;
    case 0x0DC256u: goto L_0DC256;
    case 0x0DC259u: goto L_0DC259;
    case 0x0DC25Bu: goto L_0DC25B;
    case 0x0DC25Du: goto L_0DC25D;
    case 0x0DC25Eu: goto L_0DC25E;
    case 0x0DC260u: goto L_0DC260;
    case 0x0DC261u: goto L_0DC261;
    case 0x0DC264u: goto L_0DC264;
    case 0x0DC268u: goto L_0DC268;
    case 0x0DC26Au: goto L_0DC26A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DC190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC190u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC190u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC190u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC190 SEP
    cpu.sep(0x30u);
    goto L_0DC192;
L_0DC192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC192u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC192u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC192 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DC194;
L_0DC194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC194u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC194u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC194 DEX
    cpu.decReg('X');
    goto L_0DC195;
L_0DC195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC195u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC195u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC195 TXA
    cpu.transfer("TXA");
    goto L_0DC196;
L_0DC196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC196u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC196u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC196u, 8u, 4u, 0x0086FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0DC196 JSL -> $0086FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC199u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC19Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086FAu, 0x0DC196u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC19A;
L_0DC19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC19Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC19Au,0x0DC19Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Au,cpu,0xC3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Au, 4u, 2u, cpu.addressStack(0xA8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC19A CMP
    cpu.compareA(hw.readW(cpu.addressStack(0xA8u), cpu.m8?8:16));
    goto L_0DC19C;
L_0DC19C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC19Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Cu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Cu, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC19C ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DC19F;
L_0DC19F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC19Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Fu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Fu, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC19F ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DC1A2;
L_0DC1A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A2u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A2u, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1A2 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DC1A5;
L_0DC1A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A5u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A5u, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1A5 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DC1A8;
L_0DC1A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A8u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A8u, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1A8 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DC1AB;
L_0DC1AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1ABu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1ABu, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1AB ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DC1AE;
L_0DC1AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1AEu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1AEu, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1AE ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DC1B1;
L_0DC1B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B1u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B1u, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1B1 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DC1B4;
L_0DC1B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B4u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B4u, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1B4 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DC1B7;
L_0DC1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B7u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B7u, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1B7 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DC1BA;
L_0DC1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BAu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BAu, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1BA ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DC1BD;
L_0DC1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BDu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1BDu, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1BD ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DC1C0;
L_0DC1C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C0u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C0u, 4u, 3u, cpu.address("abs", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1C0 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA8C3u), cpu.m8?8:16));
    goto L_0DC1C3;
L_0DC1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C3u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C3u, 4u, 3u, cpu.address("abs", 0xAA26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1C3 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xAA26u), cpu.m8?8:16));
    goto L_0DC1C6;
L_0DC1C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C6u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C6u, 4u, 3u, cpu.address("abs", 0xAAB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1C6 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xAAB4u), cpu.m8?8:16));
    goto L_0DC1C9;
L_0DC1C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C9u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1C9u, 4u, 3u, cpu.address("abs", 0xAB0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1C9 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xAB0Du), cpu.m8?8:16));
    goto L_0DC1CC;
L_0DC1CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CCu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CCu, 4u, 3u, cpu.address("abs", 0xAB3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1CC ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xAB3Eu), cpu.m8?8:16));
    goto L_0DC1CF;
L_0DC1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CFu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1CFu, 4u, 3u, cpu.address("abs", 0xB075u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1CF ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB075u), cpu.m8?8:16));
    goto L_0DC1D2;
L_0DC1D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D2u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D2u, 4u, 3u, cpu.address("abs", 0xB1D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1D2 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB1D4u), cpu.m8?8:16));
    goto L_0DC1D5;
L_0DC1D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D5u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D5u, 4u, 3u, cpu.address("abs", 0xB224u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1D5 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB224u), cpu.m8?8:16));
    goto L_0DC1D8;
L_0DC1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D8u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D8u, 4u, 3u, cpu.address("abs", 0xB336u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1D8 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB336u), cpu.m8?8:16));
    goto L_0DC1DB;
L_0DC1DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DBu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DBu, 4u, 3u, cpu.address("abs", 0xB3BDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1DB ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3BDu), cpu.m8?8:16));
    goto L_0DC1DE;
L_0DC1DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DEu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DEu, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1DE ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC1E1;
L_0DC1E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E1u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E1u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1E1 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC1E4;
L_0DC1E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E4u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E4u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1E4 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC1E7;
L_0DC1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E7u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E7u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1E7 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC1EA;
L_0DC1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1EAu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1EAu, 4u, 3u, cpu.address("abs", 0xB42Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1EA ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB42Du), cpu.m8?8:16));
    goto L_0DC1ED;
L_0DC1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1EDu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1EDu, 4u, 3u, cpu.address("abs", 0xB461u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1ED ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB461u), cpu.m8?8:16));
    goto L_0DC1F0;
L_0DC1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F0u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F0u, 4u, 3u, cpu.address("abs", 0xB49Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1F0 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB49Eu), cpu.m8?8:16));
    goto L_0DC1F3;
L_0DC1F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F3u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F3u, 4u, 3u, cpu.address("abs", 0xB51Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1F3 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB51Fu), cpu.m8?8:16));
    goto L_0DC1F6;
L_0DC1F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F6u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F6u, 4u, 3u, cpu.address("abs", 0xB547u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1F6 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB547u), cpu.m8?8:16));
    goto L_0DC1F9;
L_0DC1F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F9u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F9u, 4u, 3u, cpu.address("abs", 0xB1C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1F9 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB1C8u), cpu.m8?8:16));
    goto L_0DC1FC;
L_0DC1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FCu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FCu, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1FC ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC1FF;
L_0DC1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FFu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FFu, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC1FF ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC202;
L_0DC202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC202u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC202u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC202 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC205;
L_0DC205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC205u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC205u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC205 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC208;
L_0DC208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC208u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC208u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC208 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC20B;
L_0DC20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Bu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Bu, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC20B ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC20E;
L_0DC20E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Eu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Eu, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC20E ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC211;
L_0DC211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC211u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC211u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC211 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC214;
L_0DC214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC214u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC214u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC214 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC217;
L_0DC217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC217u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC217u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC217 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC21A;
L_0DC21A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC21Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Au,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Au, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC21A ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC21D;
L_0DC21D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC21Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Du,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Du, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC21D ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC220;
L_0DC220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC220u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC220u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC220 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC223;
L_0DC223:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC223u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC223u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC223u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC223 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC226;
L_0DC226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC226u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC226u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC226 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC229;
L_0DC229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC229u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC229u, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC229 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC22C;
L_0DC22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Cu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Cu, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC22C ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC22F;
L_0DC22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu, 4u, 3u, cpu.address("abs", 0xB3E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC22F ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB3E3u), cpu.m8?8:16));
    goto L_0DC232;
L_0DC232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC232u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC232u, 4u, 3u, cpu.address("abs", 0xC5D8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC232 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xC5D8u), cpu.m8?8:16));
    goto L_0DC235;
L_0DC235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC235u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC235u, 4u, 3u, cpu.address("abs", 0xC58Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC235 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xC58Au), cpu.m8?8:16));
    goto L_0DC238;
L_0DC238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC238u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC238u, 4u, 3u, cpu.address("abs", 0xC4EFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC238 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xC4EFu), cpu.m8?8:16));
    goto L_0DC23B;
L_0DC23B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu, 4u, 3u, cpu.address("abs", 0xCF12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC23B ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xCF12u), cpu.m8?8:16));
    goto L_0DC23E;
L_0DC23E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Eu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Eu, 4u, 3u, cpu.address("abs", 0xCF33u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC23E ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xCF33u), cpu.m8?8:16));
    goto L_0DC241;
L_0DC241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC241u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC241u, 4u, 3u, cpu.address("abs", 0xB916u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC241 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB916u), cpu.m8?8:16));
    goto L_0DC244;
L_0DC244:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC244u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC244u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC244u, 4u, 3u, cpu.address("abs", 0xB91Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC244 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xB91Eu), cpu.m8?8:16));
    goto L_0DC247;
L_0DC247:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC247u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC247u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC247u, 4u, 3u, cpu.address("abs", 0xC4C9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC247 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xC4C9u), cpu.m8?8:16));
    goto L_0DC24A;
L_0DC24A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Au,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Au, 4u, 3u, cpu.address("abs", 0xC478u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC24A ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xC478u), cpu.m8?8:16));
    goto L_0DC24D;
L_0DC24D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Du,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Du, 4u, 3u, cpu.address("abs", 0xC341u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC24D ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xC341u), cpu.m8?8:16));
    goto L_0DC250;
L_0DC250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC250u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC250u, 4u, 3u, cpu.address("abs", 0xC42Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC250 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xC42Eu), cpu.m8?8:16));
    goto L_0DC253;
L_0DC253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC253u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC253u, 4u, 3u, cpu.address("abs", 0xC44Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC253 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xC44Fu), cpu.m8?8:16));
    goto L_0DC256;
L_0DC256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC256u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC256u, 4u, 3u, cpu.address("abs", 0x0807u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC256 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x807u), cpu.m8?8:16));
    goto L_0DC259;
L_0DC259:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC259u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC259u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC259u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC259 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DC25B;
L_0DC25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC25B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DC25D;
L_0DC25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC25D SEC
    cpu.setFlag('C', true);
    goto L_0DC25E;
L_0DC25E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC25E SBC
    cpu.sbc(0x4Bu);
    goto L_0DC260;
L_0DC260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC260u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC260u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC260 TAX
    cpu.transfer("TAX");
    goto L_0DC261;
L_0DC261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC261u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC261u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC261 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xC263u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC264u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DC261u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC264;
L_0DC264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC264u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC264u,0x0DC264u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC264u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC264u, 5u, 4u, ((0x0DC257u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC264 LDA
    cpu.loadA(hw.readW(((0xDC257u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DC268;
L_0DC268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC268u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC268u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DC268 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DC26A;
L_0DC26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC26A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DC26Au);return;} hw.unresolvedReturn(0x0DC26Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DC4EF_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DC4EFu: goto L_0DC4EF;
    case 0x0DC4F1u: goto L_0DC4F1;
    case 0x0DC4F3u: goto L_0DC4F3;
    case 0x0DC4F5u: goto L_0DC4F5;
    case 0x0DC4F6u: goto L_0DC4F6;
    case 0x0DC4F8u: goto L_0DC4F8;
    case 0x0DC4F9u: goto L_0DC4F9;
    case 0x0DC4FAu: goto L_0DC4FA;
    case 0x0DC4FBu: goto L_0DC4FB;
    case 0x0DC4FCu: goto L_0DC4FC;
    case 0x0DC4FEu: goto L_0DC4FE;
    case 0x0DC501u: goto L_0DC501;
    case 0x0DC503u: goto L_0DC503;
    case 0x0DC505u: goto L_0DC505;
    case 0x0DC508u: goto L_0DC508;
    case 0x0DC50Bu: goto L_0DC50B;
    case 0x0DC50Du: goto L_0DC50D;
    case 0x0DC510u: goto L_0DC510;
    case 0x0DC513u: goto L_0DC513;
    case 0x0DC515u: goto L_0DC515;
    case 0x0DC518u: goto L_0DC518;
    case 0x0DC51Bu: goto L_0DC51B;
    case 0x0DC51Eu: goto L_0DC51E;
    case 0x0DC521u: goto L_0DC521;
    case 0x0DC523u: goto L_0DC523;
    case 0x0DC526u: goto L_0DC526;
    case 0x0DC529u: goto L_0DC529;
    case 0x0DC52Bu: goto L_0DC52B;
    case 0x0DC52Eu: goto L_0DC52E;
    case 0x0DC531u: goto L_0DC531;
    case 0x0DC533u: goto L_0DC533;
    case 0x0DC536u: goto L_0DC536;
    case 0x0DC539u: goto L_0DC539;
    case 0x0DC53Bu: goto L_0DC53B;
    case 0x0DC53Eu: goto L_0DC53E;
    case 0x0DC541u: goto L_0DC541;
    case 0x0DC544u: goto L_0DC544;
    case 0x0DC546u: goto L_0DC546;
    case 0x0DC548u: goto L_0DC548;
    case 0x0DC54Bu: goto L_0DC54B;
    case 0x0DC54Du: goto L_0DC54D;
    case 0x0DC550u: goto L_0DC550;
    case 0x0DC553u: goto L_0DC553;
    case 0x0DC555u: goto L_0DC555;
    case 0x0DC558u: goto L_0DC558;
    case 0x0DC55Bu: goto L_0DC55B;
    case 0x0DC55Du: goto L_0DC55D;
    case 0x0DC560u: goto L_0DC560;
    case 0x0DC563u: goto L_0DC563;
    case 0x0DC565u: goto L_0DC565;
    case 0x0DC568u: goto L_0DC568;
    case 0x0DC56Bu: goto L_0DC56B;
    case 0x0DC56Eu: goto L_0DC56E;
    case 0x0DC570u: goto L_0DC570;
    case 0x0DC572u: goto L_0DC572;
    case 0x0DC574u: goto L_0DC574;
    case 0x0DC576u: goto L_0DC576;
    case 0x0DC579u: goto L_0DC579;
    case 0x0DC57Cu: goto L_0DC57C;
    case 0x0DC57Eu: goto L_0DC57E;
    case 0x0DC581u: goto L_0DC581;
    case 0x0DC584u: goto L_0DC584;
    case 0x0DC586u: goto L_0DC586;
    case 0x0DC589u: goto L_0DC589;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DC4EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EFu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4EF LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DC4F1;
L_0DC4F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4F1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DC4F3;
L_0DC4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4F3 AND
    cpu.logicAnd(0xFu);
    goto L_0DC4F5;
L_0DC4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4F5 TAX
    cpu.transfer("TAX");
    goto L_0DC4F6;
L_0DC4F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4F6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DC4F8;
L_0DC4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4F8 LSR
    cpu.lsrA();
    goto L_0DC4F9;
L_0DC4F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4F9 LSR
    cpu.lsrA();
    goto L_0DC4FA;
L_0DC4FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4FA LSR
    cpu.lsrA();
    goto L_0DC4FB;
L_0DC4FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FBu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4FB LSR
    cpu.lsrA();
    goto L_0DC4FC;
L_0DC4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC4FC STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DC4FE;
L_0DC4FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FEu, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC4FE JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xC500u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC501u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DC4FEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC501;
L_0DC501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC501u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC501u,0x0DC501u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC501u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC501u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC501 CPX
    cpu.compareX(0x0u);
    goto L_0DC503;
L_0DC503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC503u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC503u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC503u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC503 BEQ -> $0DC51E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DC51E; }
    goto L_0DC505;
L_0DC505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC505u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC505u, 6u, 3u, cpu.address("abs", 0xA95Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC505 JSR -> $0DA95D stack real
    { cpu.push16Value(hw,0xC507u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC508u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Du), 0x0DC505u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC508;
L_0DC508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC508u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC508u,0x0DC508u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC508u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC508u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC508 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xC50Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC50Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DC508u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC50B;
L_0DC50B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC50Bu,0x0DC50Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC50B LDA
    cpu.setA(0x87u, 8);
    goto L_0DC50D;
L_0DC50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Du, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC50D JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC50Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC510u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC50Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC510;
L_0DC510:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC510u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC510u,0x0DC510u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC510u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC510u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC510 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xC512u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC513u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DC510u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC513;
L_0DC513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC513u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC513u,0x0DC513u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC513u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC513u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC513 LDA
    cpu.setA(0x88u, 8);
    goto L_0DC515;
L_0DC515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC515u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC515u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC515 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC517u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC518u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC515u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC518;
L_0DC518:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC518u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC518u,0x0DC518u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC518u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC518u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC518 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xC51Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC51Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DC518u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC51B;
L_0DC51B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC51Bu,0x0DC51Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Bu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC51B JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xC51Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC51Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DC51Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC51E;
L_0DC51E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC51Eu,0x0DC51Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Eu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC51E JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xC520u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC521u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DC51Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC521;
L_0DC521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC521u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC521u,0x0DC521u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC521u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC521u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC521 LDA
    cpu.setA(0x89u, 8);
    goto L_0DC523;
L_0DC523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC523u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC523u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC523 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC525u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC526u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC523u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC526;
L_0DC526:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC526u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC526u,0x0DC526u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC526u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC526u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC526 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xC528u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC529u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DC526u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC529;
L_0DC529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC529u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC529u,0x0DC529u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC529u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC529u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC529 LDA
    cpu.setA(0x66u, 8);
    goto L_0DC52B;
L_0DC52B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Bu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC52B JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC52Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC52Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC52Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC52E;
L_0DC52E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC52Eu,0x0DC52Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Eu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC52E JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xC530u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC531u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DC52Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC531;
L_0DC531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC531u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC531u,0x0DC531u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC531u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC531u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC531 LDA
    cpu.setA(0x67u, 8);
    goto L_0DC533;
L_0DC533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC533u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC533u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC533 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC535u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC536u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC533u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC536;
L_0DC536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC536u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC536u,0x0DC536u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC536 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xC538u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC539u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DC536u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC539;
L_0DC539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC539u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC539u,0x0DC539u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC539u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC539u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC539 LDA
    cpu.setA(0x8Au, 8);
    goto L_0DC53B;
L_0DC53B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Bu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC53B JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC53Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC53Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC53Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC53E;
L_0DC53E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC53Eu,0x0DC53Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Eu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC53E JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xC540u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC541u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DC53Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC541;
L_0DC541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC541u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC541u,0x0DC541u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC541u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC541u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC541 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xC543u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC544u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DC541u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC544;
L_0DC544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC544u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC544u,0x0DC544u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC544u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC544u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC544 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DC546;
L_0DC546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC546u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC546u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC546 BMI -> $0DC572
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DC572; }
    goto L_0DC548;
L_0DC548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC548u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC548u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC548 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xC54Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC54Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DC548u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC54B;
L_0DC54B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC54Bu,0x0DC54Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC54B LDA
    cpu.setA(0x8Bu, 8);
    goto L_0DC54D;
L_0DC54D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Du, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC54D JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC54Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC550u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC54Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC550;
L_0DC550:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC550u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC550u,0x0DC550u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC550u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC550u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC550 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xC552u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC553u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DC550u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC553;
L_0DC553:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC553u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC553u,0x0DC553u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC553u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC553u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC553 LDA
    cpu.setA(0x68u, 8);
    goto L_0DC555;
L_0DC555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC555u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC555u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC555 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC557u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC558u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC555u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC558;
L_0DC558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC558u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC558u,0x0DC558u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC558u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC558u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC558 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xC55Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC55Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DC558u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC55B;
L_0DC55B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC55Bu,0x0DC55Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC55B LDA
    cpu.setA(0x69u, 8);
    goto L_0DC55D;
L_0DC55D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Du, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC55D JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC55Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC560u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC55Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC560;
L_0DC560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC560u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC560u,0x0DC560u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC560u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC560u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC560 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xC562u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC563u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DC560u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC563;
L_0DC563:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC563u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC563u,0x0DC563u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC563u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC563u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC563 LDA
    cpu.setA(0x8Cu, 8);
    goto L_0DC565;
L_0DC565:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC565u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC565u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC565u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC565 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC567u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC568u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC565u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC568;
L_0DC568:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC568u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC568u,0x0DC568u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC568u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC568u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC568 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xC56Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC56Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DC568u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC56B;
L_0DC56B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC56Bu,0x0DC56Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Bu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC56B JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xC56Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC56Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DC56Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC56E;
L_0DC56E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC56Eu,0x0DC56Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC56E DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DC570;
L_0DC570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC570u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC570 BPL -> $0DC51E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DC51E; }
    goto L_0DC572;
L_0DC572:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC572u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC572u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC572u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC572 CPX
    cpu.compareX(0x0u);
    goto L_0DC574;
L_0DC574:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC574u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC574u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC574u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC574 BNE -> $0DC589
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DC589; }
    goto L_0DC576;
L_0DC576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC576u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC576u, 6u, 3u, cpu.address("abs", 0xA95Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC576 JSR -> $0DA95D stack real
    { cpu.push16Value(hw,0xC578u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC579u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Du), 0x0DC576u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC579;
L_0DC579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC579u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC579u,0x0DC579u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC579u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC579u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC579 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xC57Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC57Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DC579u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC57C;
L_0DC57C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC57Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC57Cu,0x0DC57Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC57C LDA
    cpu.setA(0x8Du, 8);
    goto L_0DC57E;
L_0DC57E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC57Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC57Eu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC57E JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC580u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC581u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC57Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC581;
L_0DC581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC581u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC581u,0x0DC581u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC581u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC581u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC581 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xC583u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC584u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DC581u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC584;
L_0DC584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC584u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC584u,0x0DC584u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC584u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC584u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC584 LDA
    cpu.setA(0x8Eu, 8);
    goto L_0DC586;
L_0DC586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC586u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC586u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC586 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC588u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC589u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC586u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC589;
L_0DC589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC589u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC589u,0x0DC589u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC589u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC589u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC589 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DC589u);return;} hw.unresolvedReturn(0x0DC589u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DF06C_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DF06Cu: goto L_0DF06C;
    case 0x0DF06Eu: goto L_0DF06E;
    case 0x0DF070u: goto L_0DF070;
    case 0x0DF072u: goto L_0DF072;
    case 0x0DF074u: goto L_0DF074;
    case 0x0DF076u: goto L_0DF076;
    case 0x0DF077u: goto L_0DF077;
    case 0x0DF078u: goto L_0DF078;
    case 0x0DF079u: goto L_0DF079;
    case 0x0DF07Au: goto L_0DF07A;
    case 0x0DF07Bu: goto L_0DF07B;
    case 0x0DF07Eu: goto L_0DF07E;
    case 0x0DF082u: goto L_0DF082;
    case 0x0DF085u: goto L_0DF085;
    case 0x0DF087u: goto L_0DF087;
    case 0x0DF089u: goto L_0DF089;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DF06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF06C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DF06E;
L_0DF06E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF06Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF06E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DF070;
L_0DF070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF070u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF070u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF070u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF070 AND
    cpu.logicAnd(0xFu);
    goto L_0DF072;
L_0DF072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF072u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF072u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF072 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DF074;
L_0DF074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF074u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF074u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF074 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DF076;
L_0DF076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF076u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF076u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF076 LSR
    cpu.lsrA();
    goto L_0DF077;
L_0DF077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF077u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF077u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF077 LSR
    cpu.lsrA();
    goto L_0DF078;
L_0DF078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF078u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF078u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF078 LSR
    cpu.lsrA();
    goto L_0DF079;
L_0DF079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF079u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF079u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF079 LSR
    cpu.lsrA();
    goto L_0DF07A;
L_0DF07A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF07Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF07Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF07Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF07A TAX
    cpu.transfer("TAX");
    goto L_0DF07B;
L_0DF07B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF07Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF07Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF07Bu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DF07B JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xF07Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF07Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DF07Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DF07E;
L_0DF07E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF07Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF07Eu,0x0DF07Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF07Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF07Eu, 5u, 4u, ((0x0DF06Bu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF07E LDA
    cpu.loadA(hw.readW(((0xDF06Bu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DF082;
L_0DF082:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF082u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF082u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF082u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DF082 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xF084u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF085u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DF082u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DF085;
L_0DF085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF085u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF085u,0x0DF085u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF085u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF085u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF085 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DF087;
L_0DF087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF087u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF087u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF087 BPL -> $0DF07B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DF07B; }
    goto L_0DF089;
L_0DF089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF089u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF089u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DF089 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DF089u);return;} hw.unresolvedReturn(0x0DF089u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B180CB_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB180CBu: goto L_B180CB;
    case 0xB180CEu: goto L_B180CE;
    case 0xB180D1u: goto L_B180D1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B180CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B180CB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B180CE;
L_B180CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CEu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CEu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B180CE ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16));
    goto L_B180D1;
L_B180D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B180D1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB180D1u);return;} hw.unresolvedReturn(0xB180D1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B180CB_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB180CBu: goto L_B180CB;
    case 0xB180CEu: goto L_B180CE;
    case 0xB180D1u: goto L_B180D1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B180CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B180CB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B180CE;
L_B180CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CEu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CEu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B180CE ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16));
    goto L_B180D1;
L_B180D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B180D1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB180D1u);return;} hw.unresolvedReturn(0xB180D1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A847_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A847u: goto L_B1A847;
    case 0xB1A84Bu: goto L_B1A84B;
    case 0xB1A84Eu: goto L_B1A84E;
    case 0xB1A851u: goto L_B1A851;
    case 0xB1A853u: goto L_B1A853;
    case 0xB1A855u: goto L_B1A855;
    case 0xB1A857u: goto L_B1A857;
    case 0xB1A85Au: goto L_B1A85A;
    case 0xB1A85Eu: goto L_B1A85E;
    case 0xB1A861u: goto L_B1A861;
    case 0xB1A863u: goto L_B1A863;
    case 0xB1A865u: goto L_B1A865;
    case 0xB1A868u: goto L_B1A868;
    case 0xB1A86Bu: goto L_B1A86B;
    case 0xB1A86Du: goto L_B1A86D;
    case 0xB1A870u: goto L_B1A870;
    case 0xB1A872u: goto L_B1A872;
    case 0xB1A874u: goto L_B1A874;
    case 0xB1A877u: goto L_B1A877;
    case 0xB1A87Au: goto L_B1A87A;
    case 0xB1A87Cu: goto L_B1A87C;
    case 0xB1A87Du: goto L_B1A87D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A847:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA847u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA847u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA847u, 8u, 4u, 0x01AB6Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A847 JSL -> $01AB6F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA84Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA84Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB6Fu, 0xB1A847u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A84B;
L_B1A84B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA84Bu,0xB1A84Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Bu, 6u, 3u, cpu.address("abs", 0x18D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A84B INC
    cpu.incMem(hw, cpu.address("abs", 0x18D2u), cpu.m8?8:16);
    goto L_B1A84E;
L_B1A84E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Eu, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A84E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18D2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A851;
L_B1A851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA851u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA851u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A851 CMP
    cpu.compareA(0x8u);
    goto L_B1A853;
L_B1A853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA853u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA853u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A853 BCC -> $B1A85A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A85A; }
    goto L_B1A855;
L_B1A855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A855 LDA
    cpu.setA(0x8u, 8);
    goto L_B1A857;
L_B1A857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA857u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA857u, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A857 STA
    hw.write(cpu.address("abs", 0x18D2u), cpu.a, cpu.m8?8:16);
    goto L_B1A85A;
L_B1A85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Au, 8u, 4u, 0x02ACE5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A85A JSL -> $02ACE5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA85Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA85Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACE5u, 0xB1A85Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A85E;
L_B1A85E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA85Eu,0xB1A85Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Eu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Eu, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A85E LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x18D2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A861;
L_B1A861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA861u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA861u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A861 CPY
    cpu.compareY(0x8u);
    goto L_B1A863;
L_B1A863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A863 BCS -> $B1A86B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A86B; }
    goto L_B1A865;
L_B1A865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u, 4u + ((((0xA61Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA61Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A865 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA61Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A868;
L_B1A868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A868 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_B1A86B;
L_B1A86B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A86B LDA
    cpu.setA(0x2u, 8);
    goto L_B1A86D;
L_B1A86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Du, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A86D STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A870;
L_B1A870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA870u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA870u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A870 LDA
    cpu.setA(0xD0u, 8);
    goto L_B1A872;
L_B1A872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA872u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA872u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A872 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A874;
L_B1A874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A874 JSR -> $B1AD30 stack real
    { cpu.push16Value(hw,0xA876u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA877u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0xB1A874u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A877;
L_B1A877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA877u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA877u,0xB1A877u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u, 4u + ((((0xA839u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA839u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A877 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA839u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A87A;
L_B1A87A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A87A STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B1A87C;
L_B1A87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A87C CLC
    cpu.setFlag('C', false);
    goto L_B1A87D;
L_B1A87D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A87D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A87Du);return;} hw.unresolvedReturn(0xB1A87Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_E48789_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xE48789u: goto L_E48789;
    case 0xE4878Bu: goto L_E4878B;
    case 0xE4878Cu: goto L_E4878C;
    case 0xE4878Du: goto L_E4878D;
    case 0xE4878Fu: goto L_E4878F;
    case 0xE48790u: goto L_E48790;
    case 0xE48791u: goto L_E48791;
    case 0xE48792u: goto L_E48792;
    case 0xE48795u: goto L_E48795;
    case 0xE48796u: goto L_E48796;
    case 0xE48799u: goto L_E48799;
    case 0xE4879Bu: goto L_E4879B;
    case 0xE4879Du: goto L_E4879D;
    case 0xE4879Fu: goto L_E4879F;
    case 0xE487A2u: goto L_E487A2;
    case 0xE487A3u: goto L_E487A3;
    case 0xE487A5u: goto L_E487A5;
    case 0xE487A8u: goto L_E487A8;
    case 0xE487AAu: goto L_E487AA;
    case 0xE487ABu: goto L_E487AB;
    case 0xE487ADu: goto L_E487AD;
    case 0xE487B0u: goto L_E487B0;
    case 0xE487B3u: goto L_E487B3;
    case 0xE487B5u: goto L_E487B5;
    case 0xE487B8u: goto L_E487B8;
    case 0xE487BBu: goto L_E487BB;
    case 0xE487BDu: goto L_E487BD;
    case 0xE487C0u: goto L_E487C0;
    case 0xE487C2u: goto L_E487C2;
    case 0xE487C5u: goto L_E487C5;
    case 0xE487C7u: goto L_E487C7;
    case 0xE487C8u: goto L_E487C8;
    case 0xE487CAu: goto L_E487CA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_E48789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8789u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8789u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48789 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4878B;
L_E4878B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E4878B PHA
    cpu.push("PHA", hw);
    goto L_E4878C;
L_E4878C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E4878C PHX
    cpu.push("PHX", hw);
    goto L_E4878D;
L_E4878D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4878D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4878F;
L_E4878F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4878F XBA
    cpu.xba();
    goto L_E48790;
L_E48790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8790u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8790u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48790 LSR
    cpu.lsrA();
    goto L_E48791;
L_E48791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8791u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8791u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48791 TAX
    cpu.transfer("TAX");
    goto L_E48792;
L_E48792:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8792u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u, 5u + 1u, 3u, cpu.address("absx", 0x0DB3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48792 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDB3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48795;
L_E48795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8795u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8795u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E48795 PLX
    cpu.pop("PLX", hw);
    goto L_E48796;
L_E48796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8796u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8796u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48796 AND
    cpu.logicAnd(0xFF00u);
    goto L_E48799;
L_E48799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8799u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8799u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48799 BPL -> $E487C7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_E487C7; }
    goto L_E4879B;
L_E4879B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4879B SEP
    cpu.sep(0x20u);
    goto L_E4879D;
L_E4879D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4879D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4879F;
L_E4879F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Fu, 5u, 3u, cpu.address("absx", 0x02B4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4879F STA
    hw.write(cpu.address("absx", 0x2B4u), cpu.a, cpu.m8?8:16);
    goto L_E487A2;
L_E487A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487A2 CLC
    cpu.setFlag('C', false);
    goto L_E487A3;
L_E487A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487A3 ADC
    cpu.adc(0x8u);
    goto L_E487A5;
L_E487A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A5u, 5u, 3u, cpu.address("absx", 0x02B8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487A5 STA
    hw.write(cpu.address("absx", 0x2B8u), cpu.a, cpu.m8?8:16);
    goto L_E487A8;
L_E487A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487A8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E487AA;
L_E487AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487AA CLC
    cpu.setFlag('C', false);
    goto L_E487AB;
L_E487AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ABu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487AB ADC
    cpu.adc(0xF9u);
    goto L_E487AD;
L_E487AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu, 5u, 3u, cpu.address("absx", 0x02B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487AD STA
    hw.write(cpu.address("absx", 0x2B5u), cpu.a, cpu.m8?8:16);
    goto L_E487B0;
L_E487B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B0u, 5u, 3u, cpu.address("absx", 0x02B9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487B0 STA
    hw.write(cpu.address("absx", 0x2B9u), cpu.a, cpu.m8?8:16);
    goto L_E487B3;
L_E487B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487B3 LDA
    cpu.setA(0x7Cu, 8);
    goto L_E487B5;
L_E487B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B5u, 5u, 3u, cpu.address("absx", 0x02B6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487B5 STA
    hw.write(cpu.address("absx", 0x2B6u), cpu.a, cpu.m8?8:16);
    goto L_E487B8;
L_E487B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B8u, 5u, 3u, cpu.address("absx", 0x02BAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487B8 STA
    hw.write(cpu.address("absx", 0x2BAu), cpu.a, cpu.m8?8:16);
    goto L_E487BB;
L_E487BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487BB LDA
    cpu.setA(0x20u, 8);
    goto L_E487BD;
L_E487BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu, 5u, 3u, cpu.address("absx", 0x02B7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487BD STA
    hw.write(cpu.address("absx", 0x2B7u), cpu.a, cpu.m8?8:16);
    goto L_E487C0;
L_E487C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487C0 LDA
    cpu.setA(0x60u, 8);
    goto L_E487C2;
L_E487C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C2u, 5u, 3u, cpu.address("absx", 0x02BBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487C2 STA
    hw.write(cpu.address("absx", 0x2BBu), cpu.a, cpu.m8?8:16);
    goto L_E487C5;
L_E487C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487C5 REP
    cpu.rep(0x20u);
    goto L_E487C7;
L_E487C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C7u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E487C7 PLA
    cpu.pop("PLA", hw);
    goto L_E487C8;
L_E487C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E487C8 STA
    hw.write(cpu.address("dp", 0x8Au), cpu.a, cpu.m8?8:16);
    goto L_E487CA;
L_E487CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E487CA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xE487CAu);return;} hw.unresolvedReturn(0xE487CAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_E48E55_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xE480E0u: goto L_E480E0;
    case 0xE480E2u: goto L_E480E2;
    case 0xE480E4u: goto L_E480E4;
    case 0xE480E6u: goto L_E480E6;
    case 0xE480E8u: goto L_E480E8;
    case 0xE480EBu: goto L_E480EB;
    case 0xE480EDu: goto L_E480ED;
    case 0xE480EEu: goto L_E480EE;
    case 0xE480F0u: goto L_E480F0;
    case 0xE480F2u: goto L_E480F2;
    case 0xE480F4u: goto L_E480F4;
    case 0xE480F7u: goto L_E480F7;
    case 0xE480F9u: goto L_E480F9;
    case 0xE480FBu: goto L_E480FB;
    case 0xE480FEu: goto L_E480FE;
    case 0xE480FFu: goto L_E480FF;
    case 0xE48101u: goto L_E48101;
    case 0xE48103u: goto L_E48103;
    case 0xE48105u: goto L_E48105;
    case 0xE48107u: goto L_E48107;
    case 0xE48109u: goto L_E48109;
    case 0xE4810Cu: goto L_E4810C;
    case 0xE4810Eu: goto L_E4810E;
    case 0xE48110u: goto L_E48110;
    case 0xE48112u: goto L_E48112;
    case 0xE48114u: goto L_E48114;
    case 0xE48117u: goto L_E48117;
    case 0xE48118u: goto L_E48118;
    case 0xE4811Bu: goto L_E4811B;
    case 0xE4811Cu: goto L_E4811C;
    case 0xE4811Eu: goto L_E4811E;
    case 0xE48120u: goto L_E48120;
    case 0xE48123u: goto L_E48123;
    case 0xE48125u: goto L_E48125;
    case 0xE48128u: goto L_E48128;
    case 0xE4812Au: goto L_E4812A;
    case 0xE4812Cu: goto L_E4812C;
    case 0xE4812Fu: goto L_E4812F;
    case 0xE48131u: goto L_E48131;
    case 0xE48134u: goto L_E48134;
    case 0xE48136u: goto L_E48136;
    case 0xE48139u: goto L_E48139;
    case 0xE4813Au: goto L_E4813A;
    case 0xE4813Cu: goto L_E4813C;
    case 0xE4813Du: goto L_E4813D;
    case 0xE4813Eu: goto L_E4813E;
    case 0xE48141u: goto L_E48141;
    case 0xE48143u: goto L_E48143;
    case 0xE48144u: goto L_E48144;
    case 0xE48145u: goto L_E48145;
    case 0xE48147u: goto L_E48147;
    case 0xE48148u: goto L_E48148;
    case 0xE4814Bu: goto L_E4814B;
    case 0xE4814Du: goto L_E4814D;
    case 0xE4814Fu: goto L_E4814F;
    case 0xE48151u: goto L_E48151;
    case 0xE48153u: goto L_E48153;
    case 0xE48155u: goto L_E48155;
    case 0xE48157u: goto L_E48157;
    case 0xE4815Au: goto L_E4815A;
    case 0xE4815Cu: goto L_E4815C;
    case 0xE4815Du: goto L_E4815D;
    case 0xE48160u: goto L_E48160;
    case 0xE48162u: goto L_E48162;
    case 0xE48164u: goto L_E48164;
    case 0xE48165u: goto L_E48165;
    case 0xE48168u: goto L_E48168;
    case 0xE4816Au: goto L_E4816A;
    case 0xE4816Du: goto L_E4816D;
    case 0xE4816Fu: goto L_E4816F;
    case 0xE48171u: goto L_E48171;
    case 0xE48E55u: goto L_E48E55;
    case 0xE48E57u: goto L_E48E57;
    case 0xE48E5Au: goto L_E48E5A;
    case 0xE48E5Du: goto L_E48E5D;
    case 0xE48E5Eu: goto L_E48E5E;
    case 0xE48E5Fu: goto L_E48E5F;
    case 0xE48E62u: goto L_E48E62;
    case 0xE48E65u: goto L_E48E65;
    case 0xE48E68u: goto L_E48E68;
    case 0xE48E6Au: goto L_E48E6A;
    case 0xE48E6Du: goto L_E48E6D;
    case 0xE48E6Fu: goto L_E48E6F;
    case 0xE48E70u: goto L_E48E70;
    case 0xE48E71u: goto L_E48E71;
    case 0xE48E72u: goto L_E48E72;
    case 0xE48E73u: goto L_E48E73;
    case 0xE48E76u: goto L_E48E76;
    case 0xE48E78u: goto L_E48E78;
    case 0xE48E7Au: goto L_E48E7A;
    case 0xE48E7Eu: goto L_E48E7E;
    case 0xE48E81u: goto L_E48E81;
    case 0xE48E82u: goto L_E48E82;
    case 0xE48E83u: goto L_E48E83;
    case 0xE48E86u: goto L_E48E86;
    case 0xE48E88u: goto L_E48E88;
    case 0xE48E8Bu: goto L_E48E8B;
    case 0xE48E8Du: goto L_E48E8D;
    case 0xE48E8Fu: goto L_E48E8F;
    case 0xE48E92u: goto L_E48E92;
    case 0xE48E94u: goto L_E48E94;
    case 0xE48E98u: goto L_E48E98;
    case 0xE48E9Bu: goto L_E48E9B;
    case 0xE48E9Eu: goto L_E48E9E;
    case 0xE48EA0u: goto L_E48EA0;
    case 0xE48EA3u: goto L_E48EA3;
    case 0xE48EA5u: goto L_E48EA5;
    case 0xE48EA7u: goto L_E48EA7;
    case 0xE48EA8u: goto L_E48EA8;
    case 0xE48EAAu: goto L_E48EAA;
    case 0xE48EABu: goto L_E48EAB;
    case 0xE48EAEu: goto L_E48EAE;
    case 0xE48EB1u: goto L_E48EB1;
    case 0xE48EB4u: goto L_E48EB4;
    case 0xE48EB6u: goto L_E48EB6;
    case 0xE48EB7u: goto L_E48EB7;
    case 0xE48EB8u: goto L_E48EB8;
    case 0xE48EBAu: goto L_E48EBA;
    case 0xE48EBDu: goto L_E48EBD;
    case 0xE48EC0u: goto L_E48EC0;
    case 0xE48EC3u: goto L_E48EC3;
    case 0xE48EC6u: goto L_E48EC6;
    case 0xE48EC9u: goto L_E48EC9;
    case 0xE48ECBu: goto L_E48ECB;
    case 0xE48ECDu: goto L_E48ECD;
    case 0xE48ECEu: goto L_E48ECE;
    case 0xE48ED1u: goto L_E48ED1;
    case 0xE48ED4u: goto L_E48ED4;
    case 0xE48ED7u: goto L_E48ED7;
    case 0xE48ED9u: goto L_E48ED9;
    case 0xE48EDCu: goto L_E48EDC;
    case 0xE48EDEu: goto L_E48EDE;
    case 0xE48EE1u: goto L_E48EE1;
    case 0xE48EE3u: goto L_E48EE3;
    case 0xE48EE6u: goto L_E48EE6;
    case 0xE48EE8u: goto L_E48EE8;
    case 0xE48EEBu: goto L_E48EEB;
    case 0xE48EEEu: goto L_E48EEE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_E480E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480E0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E480E2;
L_E480E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480E2 AND
    cpu.logicAnd(0x7u);
    goto L_E480E4;
L_E480E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480E4 BNE -> $E48101
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_E48101; }
    goto L_E480E6;
L_E480E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480E6 LDX
    cpu.setX(0x1Fu, 8);
    goto L_E480E8;
L_E480E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u, 4u + ((((0x0AF6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0AF6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480E8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xAF6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E480EB;
L_E480EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480EB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_E480ED;
L_E480ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480ED TXA
    cpu.transfer("TXA");
    goto L_E480EE;
L_E480EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480EE AND
    cpu.logicAnd(0x8u);
    goto L_E480F0;
L_E480F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480F0 BNE -> $E480F9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_E480F9; }
    goto L_E480F2;
L_E480F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480F2 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_E480F4;
L_E480F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u,cpu,0x3Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u, 7u, 3u, cpu.address("absx", 0x0AF6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480F4 ROL
    cpu.rolMem(hw, cpu.address("absx", 0xAF6u), cpu.m8?8:16);
    goto L_E480F7;
L_E480F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480F7 BRA -> $E480FE
    goto L_E480FE;
L_E480F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480F9 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_E480FB;
L_E480FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu, 7u, 3u, cpu.address("absx", 0x0AF6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480FB ROR
    cpu.rorMem(hw, cpu.address("absx", 0xAF6u), cpu.m8?8:16);
    goto L_E480FE;
L_E480FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480FE DEX
    cpu.decReg('X');
    goto L_E480FF;
L_E480FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480FF BPL -> $E480E8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_E480E8; }
    goto L_E48101;
L_E48101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48101 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48103;
L_E48103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48103 AND
    cpu.logicAnd(0x7u);
    goto L_E48105;
L_E48105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48105 BNE -> $E4810C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_E4810C; }
    goto L_E48107;
L_E48107:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8107u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8107u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8107u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48107 LDX
    cpu.setX(0x20u, 8);
    goto L_E48109;
L_E48109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u, 6u, 3u, cpu.address("abs", 0x8172u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E48109 JSR -> $E48172 stack real
    { cpu.push16Value(hw,0x810Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x810Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8172u), 0xE48109u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E4810C;
L_E4810C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x810Cu,0xE4810Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4810C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4810E;
L_E4810E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4810E AND
    cpu.logicAnd(0x7u);
    goto L_E48110;
L_E48110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8110u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8110u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8110u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48110 BNE -> $E48123
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_E48123; }
    goto L_E48112;
L_E48112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8112u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8112u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48112 LDX
    cpu.setX(0x1Fu, 8);
    goto L_E48114;
L_E48114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u, 4u + ((((0x0B36u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0B36u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48114 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48117;
L_E48117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48117 ASL
    cpu.aslA();
    goto L_E48118;
L_E48118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8118u,cpu,0x3Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8118u, 7u, 3u, cpu.address("absx", 0x0B36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48118 ROL
    cpu.rolMem(hw, cpu.address("absx", 0xB36u), cpu.m8?8:16);
    goto L_E4811B;
L_E4811B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4811B DEX
    cpu.decReg('X');
    goto L_E4811C;
L_E4811C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4811C BPL -> $E48114
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_E48114; }
    goto L_E4811E;
L_E4811E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4811E LDX
    cpu.setX(0x40u, 8);
    goto L_E48120;
L_E48120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u, 6u, 3u, cpu.address("abs", 0x8172u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E48120 JSR -> $E48172 stack real
    { cpu.push16Value(hw,0x8122u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8123u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8172u), 0xE48120u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E48123;
L_E48123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8123u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8123u,0xE48123u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48123 REP
    cpu.rep(0x30u);
    goto L_E48125;
L_E48125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48125 LDA
    cpu.setA(0x60u, 16);
    goto L_E48128;
L_E48128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8128u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8128u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48128 STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_E4812A;
L_E4812A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4812A STZ
    hw.write(cpu.address("dp", 0xBu), 0, cpu.m8?8:16);
    goto L_E4812C;
L_E4812C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4812C LDX
    cpu.setX(0x38u, 16);
    goto L_E4812F;
L_E4812F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4812F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48131;
L_E48131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48131 CMP
    cpu.compareA(0x20u);
    goto L_E48134;
L_E48134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8134u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8134u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48134 BCS -> $E48139
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_E48139; }
    goto L_E48136;
L_E48136:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8136u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8136u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8136u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48136 LDX
    cpu.setX(0x70u, 16);
    goto L_E48139;
L_E48139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8139u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8139u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48139 TXA
    cpu.transfer("TXA");
    goto L_E4813A;
L_E4813A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Au,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4813A AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_E4813C;
L_E4813C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4813C LSR
    cpu.lsrA();
    goto L_E4813D;
L_E4813D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4813D LSR
    cpu.lsrA();
    goto L_E4813E;
L_E4813E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Eu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4813E CPX
    cpu.compareX(0x38u);
    goto L_E48141;
L_E48141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8141u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8141u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48141 BEQ -> $E48144
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_E48144; }
    goto L_E48143;
L_E48143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8143u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8143u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48143 LSR
    cpu.lsrA();
    goto L_E48144;
L_E48144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8144u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8144u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48144 CLC
    cpu.setFlag('C', false);
    goto L_E48145;
L_E48145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8145u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8145u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48145 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16));
    goto L_E48147;
L_E48147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8147u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8147u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48147 TAX
    cpu.transfer("TAX");
    goto L_E48148;
L_E48148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8148u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8148u, 5u + 1u, 3u, cpu.address("absx", 0x8006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48148 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8006u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4814B;
L_E4814B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4814B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_E4814D;
L_E4814D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4814D SEP
    cpu.sep(0x10u);
    goto L_E4814F;
L_E4814F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4814F LDY
    cpu.setY(0x7Eu, 8);
    goto L_E48151;
L_E48151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8151u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8151u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48151 STY
    hw.write(cpu.address("dp", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_E48153;
L_E48153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8153u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8153u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48153 REP
    cpu.rep(0x10u);
    goto L_E48155;
L_E48155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8155u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8155u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48155 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_E48157;
L_E48157:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8157u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8157u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8157u, 6u, 3u, cpu.address("abs", 0x80B9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E48157 JSR -> $E480B9 stack real
    { cpu.push16Value(hw,0x8159u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x815Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80B9u), 0xE48157u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E4815A;
L_E4815A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x815Au,0xE4815Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4815A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4815C;
L_E4815C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4815C CLC
    cpu.setFlag('C', false);
    goto L_E4815D;
L_E4815D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4815D ADC
    cpu.adc(0x20u);
    goto L_E48160;
L_E48160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8160u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8160u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8160u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48160 STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_E48162;
L_E48162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8162u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8162u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48162 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48164;
L_E48164:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8164u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8164u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8164u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48164 CLC
    cpu.setFlag('C', false);
    goto L_E48165;
L_E48165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8165u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8165u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48165 ADC
    cpu.adc(0x10u);
    goto L_E48168;
L_E48168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8168u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8168u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48168 STA
    hw.write(cpu.address("dp", 0xBu), cpu.a, cpu.m8?8:16);
    goto L_E4816A;
L_E4816A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4816A CMP
    cpu.compareA(0x80u);
    goto L_E4816D;
L_E4816D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4816D BNE -> $E4812C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_E4812C; }
    goto L_E4816F;
L_E4816F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4816F SEP
    cpu.sep(0x30u);
    goto L_E48171;
L_E48171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8171u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8171u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E48171 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xE48171u);return;} hw.unresolvedReturn(0xE48171u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_E48E55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E55u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E55u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E55 REP
    cpu.rep(0x30u);
    goto L_E48E57;
L_E48E57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E57u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E57u, 5u, 3u, cpu.address("abs", 0x0DB3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E57 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDB3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48E5A;
L_E48E5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E5A AND
    cpu.logicAnd(0xFFu);
    goto L_E48E5D;
L_E48E5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E5D ASL
    cpu.aslA();
    goto L_E48E5E;
L_E48E5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E5E ASL
    cpu.aslA();
    goto L_E48E5F;
L_E48E5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Fu, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E5F STA
    hw.write(cpu.address("abs", 0xDD6u), cpu.a, cpu.m8?8:16);
    goto L_E48E62;
L_E48E62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E62u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E62u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E62 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_E48E65;
L_E48E65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E65u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E65u, 5u + 1u, 3u, cpu.address("absx", 0x1F1Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E65 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F1Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48E68;
L_E48E68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E68u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E68u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E68 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_E48E6A;
L_E48E6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Au, 5u + 1u, 3u, cpu.address("absx", 0x1F21u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E6A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F21u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48E6D;
L_E48E6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E6D STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_E48E6F;
L_E48E6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E6F TXA
    cpu.transfer("TXA");
    goto L_E48E70;
L_E48E70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E70u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E70u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E70 LSR
    cpu.lsrA();
    goto L_E48E71;
L_E48E71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E71u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E71u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E71 LSR
    cpu.lsrA();
    goto L_E48E72;
L_E48E72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E72u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E72u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E72 TAX
    cpu.transfer("TAX");
    goto L_E48E73;
L_E48E73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E73u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E73u, 6u, 3u, cpu.address("abs", 0x9885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E48E73 JSR -> $E49885 stack real
    { cpu.push16Value(hw,0x8E75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E76u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9885u), 0xE48E73u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E48E76;
L_E48E76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E76u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E76u,0xE48E76u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E76u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E76u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E76 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_E48E78;
L_E48E78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E78u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E78 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_E48E7A;
L_E48E7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Au, 6u, 4u, ((0x7ED000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E7A LDA
    cpu.loadA(hw.readW(((0x7ED000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48E7E;
L_E48E7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E7E AND
    cpu.logicAnd(0xFFu);
    goto L_E48E81;
L_E48E81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E81u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E81u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E81 ASL
    cpu.aslA();
    goto L_E48E82;
L_E48E82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E82u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E82u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E82 TAX
    cpu.transfer("TAX");
    goto L_E48E83;
L_E48E83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E83u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E83u, 5u + 1u, 3u, cpu.address("absx", 0xA0FCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E83 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA0FCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48E86;
L_E48E86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E86u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E86u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E86 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_E48E88;
L_E48E88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E88u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E88u, 6u, 3u, cpu.address("abs", 0x9D07u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E48E88 JSR -> $E49D07 stack real
    { cpu.push16Value(hw,0x8E8Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E8Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D07u), 0xE48E88u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E48E8B;
L_E48E8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E8Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E8Bu,0xE48E8Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E8B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_E48E8D;
L_E48E8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E8D BMI -> $E48E9E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_E48E9E; }
    goto L_E48E8F;
L_E48E8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Fu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E8F CPX
    cpu.compareX(0x800u);
    goto L_E48E92;
L_E48E92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E92u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E92 BCS -> $E48E9E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_E48E9E; }
    goto L_E48E94;
L_E48E94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E94u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E94u, 6u, 4u, ((0x7EC800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E94 LDA
    cpu.loadA(hw.readW(((0x7EC800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48E98;
L_E48E98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E98u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E98u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E98 AND
    cpu.logicAnd(0xFFu);
    goto L_E48E9B;
L_E48E9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Bu, 5u, 3u, cpu.address("abs", 0x13C1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E9B STA
    hw.write(cpu.address("abs", 0x13C1u), cpu.a, cpu.m8?8:16);
    goto L_E48E9E;
L_E48E9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48E9E SEP
    cpu.sep(0x30u);
    goto L_E48EA0;
L_E48EA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA0u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA0u, 4u, 3u, cpu.address("abs", 0x0EF7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EA0 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xEF7u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_E48EA3;
L_E48EA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EA3 BEQ -> $E48EE1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_E48EE1; }
    goto L_E48EA5;
L_E48EA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EA5 BPL -> $E48ED9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_E48ED9; }
    goto L_E48EA7;
L_E48EA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA7u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EA7 TXA
    cpu.transfer("TXA");
    goto L_E48EA8;
L_E48EA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EA8 AND
    cpu.logicAnd(0x7Fu);
    goto L_E48EAA;
L_E48EAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EAAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EAA TAX
    cpu.transfer("TAX");
    goto L_E48EAB;
L_E48EAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EABu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EABu, 5u, 3u, cpu.address("absx", 0x0DF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EAB STZ
    hw.write(cpu.address("absx", 0xDF5u), 0, cpu.m8?8:16);
    goto L_E48EAE;
L_E48EAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EAEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EAEu, 4u, 3u, cpu.address("abs", 0x0EF6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EAE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xEF6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48EB1;
L_E48EB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB1u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB1u, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EB1 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_E48EB4;
L_E48EB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EB4 BPL -> $E48ECD
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_E48ECD; }
    goto L_E48EB6;
L_E48EB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EB6 ASL
    cpu.aslA();
    goto L_E48EB7;
L_E48EB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EB7 TAX
    cpu.transfer("TAX");
    goto L_E48EB8;
L_E48EB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EB8 REP
    cpu.rep(0x20u);
    goto L_E48EBA;
L_E48EBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBAu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBAu, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EBA LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_E48EBD;
L_E48EBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBDu, 5u + ((((0x8E49u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8E49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EBD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8E49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48EC0;
L_E48EC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC0u, 6u, 3u, cpu.address("absy", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EC0 STA
    hw.write(cpu.address("absy", 0x1F17u), cpu.a, cpu.m8?8:16);
    goto L_E48EC3;
L_E48EC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC3u, 5u + ((((0x8E4Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8E4Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EC3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8E4Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48EC6;
L_E48EC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC6u, 6u, 3u, cpu.address("absy", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EC6 STA
    hw.write(cpu.address("absy", 0x1F19u), cpu.a, cpu.m8?8:16);
    goto L_E48EC9;
L_E48EC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EC9 SEP
    cpu.sep(0x20u);
    goto L_E48ECB;
L_E48ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECBu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48ECB BRA -> $E48EE1
    goto L_E48EE1;
L_E48ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48ECD TAX
    cpu.transfer("TAX");
    goto L_E48ECE;
L_E48ECE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECEu, 4u + ((((0xFB85u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xFB85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48ECE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xFB85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48ED1;
L_E48ED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED1u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED1u, 4u, 3u, cpu.address("abs", 0x0EF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48ED1 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xEF5u), cpu.m8?8:16));
    goto L_E48ED4;
L_E48ED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED4u, 4u, 3u, cpu.address("abs", 0x0EF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48ED4 STA
    hw.write(cpu.address("abs", 0xEF5u), cpu.a, cpu.m8?8:16);
    goto L_E48ED7;
L_E48ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48ED7 BRA -> $E48EE1
    goto L_E48EE1;
L_E48ED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED9u, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48ED9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48EDC;
L_E48EDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EDC BMI -> $E48EE1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_E48EE1; }
    goto L_E48EDE;
L_E48EDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu, 5u, 3u, cpu.address("absx", 0x0DE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EDE STZ
    hw.write(cpu.address("absx", 0xDE5u), 0, cpu.m8?8:16);
    goto L_E48EE1;
L_E48EE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EE1 REP
    cpu.rep(0x30u);
    goto L_E48EE3;
L_E48EE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE3u, 6u, 3u, cpu.address("abs", 0x9831u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E48EE3 JSR -> $E49831 stack real
    { cpu.push16Value(hw,0x8EE5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EE6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9831u), 0xE48EE3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E48EE6;
L_E48EE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EE6u,0xE48EE6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EE6 SEP
    cpu.sep(0x30u);
    goto L_E48EE8;
L_E48EE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE8u, 6u, 3u, cpu.address("abs", 0x85A4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E48EE8 JSR -> $E485A4 stack real
    { cpu.push16Value(hw,0x8EEAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EEBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85A4u), 0xE48EE8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E48EEB;
L_E48EEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EEBu,0xE48EEBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEBu, 6u, 3u, cpu.address("abs", 0x8086u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E48EEB JSR -> $E48086 stack real
    { cpu.push16Value(hw,0x8EEDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EEEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8086u), 0xE48EEBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E48EEE;
L_E48EEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EEEu,0xE48EEEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEEu, 3u, 3u, cpu.address("abs", 0x80E0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48EEE JMP -> $E480E0
    goto L_E480E0;
}

