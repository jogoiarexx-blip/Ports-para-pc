#include "generated.hpp"
void sub_009012_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009012u: goto L_009012;
    case 0x009014u: goto L_009014;
    case 0x009017u: goto L_009017;
    case 0x009019u: goto L_009019;
    case 0x00901Bu: goto L_00901B;
    case 0x00901Cu: goto L_00901C;
    case 0x00901Fu: goto L_00901F;
    case 0x009021u: goto L_009021;
    case 0x009023u: goto L_009023;
    case 0x009026u: goto L_009026;
    case 0x009028u: goto L_009028;
    case 0x00902Au: goto L_00902A;
    case 0x00902Cu: goto L_00902C;
    case 0x00902Eu: goto L_00902E;
    case 0x009030u: goto L_009030;
    case 0x009032u: goto L_009032;
    case 0x009034u: goto L_009034;
    case 0x009037u: goto L_009037;
    case 0x009039u: goto L_009039;
    case 0x00903Au: goto L_00903A;
    case 0x00903Bu: goto L_00903B;
    case 0x00903Cu: goto L_00903C;
    case 0x00903Du: goto L_00903D;
    case 0x00903Eu: goto L_00903E;
    case 0x009040u: goto L_009040;
    case 0x009042u: goto L_009042;
    case 0x009044u: goto L_009044;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9012u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009012 SEP
    cpu.sep(0x20u);
    goto L_009014;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009012 SEP
    cpu.sep(0x20u);
    goto L_009014;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9012u,0x009012u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u, 5u, 3u, cpu.address("absx", 0x0F15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009014 STZ
    hw.write(cpu.address("absx", 0xF15u), 0, cpu.m8?8:16);
    goto L_009017;
L_009017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009017 REP
    cpu.rep(0x20u);
    goto L_009019;
L_009019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9019u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9019u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009019 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00901B;
L_00901B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00901B SEC
    cpu.setFlag('C', true);
    goto L_00901C;
L_00901C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Cu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Cu, 5u + ((((0x8FFCu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00901C SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x8FFCu), cpu.m8?8:16));
    goto L_00901F;
L_00901F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00901F STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_009021;
L_009021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9021u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9021u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009021 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009023;
L_009023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u, 5u + ((((0x8FFAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8FFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009023 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x8FFAu), cpu.m8?8:16));
    goto L_009026;
L_009026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009026 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_009028;
L_009028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9028u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9028u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009028 BCC -> $009039
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_009039; }
    goto L_00902A;
L_00902A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00902A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00902C;
L_00902C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00902C STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_00902E;
L_00902E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00902E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009030;
L_009030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9030u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9030u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009030 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_009032;
L_009032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9032u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9032u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9032u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009032 SEP
    cpu.sep(0x20u);
    goto L_009034;
L_009034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9034u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9034u, 7u, 3u, cpu.address("absx", 0x0F15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009034 INC
    cpu.incMem(hw, cpu.address("absx", 0xF15u), cpu.m8?8:16);
    goto L_009037;
L_009037:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9037u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9037u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9037u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009037 BRA -> $009017
    goto L_009017;
L_009039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9039u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9039u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009039 INX
    cpu.inc('X');
    goto L_00903A;
L_00903A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903A INY
    cpu.inc('Y');
    goto L_00903B;
L_00903B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903B INY
    cpu.inc('Y');
    goto L_00903C;
L_00903C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903C INY
    cpu.inc('Y');
    goto L_00903D;
L_00903D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903D INY
    cpu.inc('Y');
    goto L_00903E;
L_00903E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903E CPY
    cpu.compareY(0x18u);
    goto L_009040;
L_009040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9040u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9040u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009040 BNE -> $009012
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009012; }
    goto L_009042;
L_009042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9042u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9042u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009042 SEP
    cpu.sep(0x20u);
    goto L_009044;
L_009044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9044u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9044u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009044 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009044u);return;} hw.unresolvedReturn(0x009044u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_009468_E1M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008494u: goto L_008494;
    case 0x008496u: goto L_008496;
    case 0x008497u: goto L_008497;
    case 0x008499u: goto L_008499;
    case 0x00849Cu: goto L_00849C;
    case 0x00849Du: goto L_00849D;
    case 0x00849Eu: goto L_00849E;
    case 0x0084A1u: goto L_0084A1;
    case 0x0084A2u: goto L_0084A2;
    case 0x0084A3u: goto L_0084A3;
    case 0x0084A6u: goto L_0084A6;
    case 0x0084A7u: goto L_0084A7;
    case 0x0084A8u: goto L_0084A8;
    case 0x0084ABu: goto L_0084AB;
    case 0x0084AEu: goto L_0084AE;
    case 0x0084B1u: goto L_0084B1;
    case 0x0084B2u: goto L_0084B2;
    case 0x0084B3u: goto L_0084B3;
    case 0x0084B6u: goto L_0084B6;
    case 0x0084B7u: goto L_0084B7;
    case 0x0084B8u: goto L_0084B8;
    case 0x0084BBu: goto L_0084BB;
    case 0x0084BCu: goto L_0084BC;
    case 0x0084BDu: goto L_0084BD;
    case 0x0084C0u: goto L_0084C0;
    case 0x0084C3u: goto L_0084C3;
    case 0x0084C4u: goto L_0084C4;
    case 0x0084C5u: goto L_0084C5;
    case 0x0084C7u: goto L_0084C7;
    case 0x009468u: goto L_009468;
    case 0x00946Bu: goto L_00946B;
    case 0x00946Eu: goto L_00946E;
    case 0x009471u: goto L_009471;
    case 0x009474u: goto L_009474;
    case 0x009476u: goto L_009476;
    case 0x009479u: goto L_009479;
    case 0x00947Bu: goto L_00947B;
    case 0x00947Eu: goto L_00947E;
    case 0x009481u: goto L_009481;
    case 0x009484u: goto L_009484;
    case 0x009487u: goto L_009487;
    case 0x00948Au: goto L_00948A;
    case 0x00948Du: goto L_00948D;
    case 0x00948Fu: goto L_00948F;
    case 0x009492u: goto L_009492;
    case 0x009494u: goto L_009494;
    case 0x009496u: goto L_009496;
    case 0x009499u: goto L_009499;
    case 0x00949Bu: goto L_00949B;
    case 0x00949Du: goto L_00949D;
    case 0x0094A0u: goto L_0094A0;
    case 0x0094A3u: goto L_0094A3;
    case 0x0094A7u: goto L_0094A7;
    case 0x0094AAu: goto L_0094AA;
    case 0x0094ADu: goto L_0094AD;
    case 0x0094B0u: goto L_0094B0;
    case 0x0094B2u: goto L_0094B2;
    case 0x0094B4u: goto L_0094B4;
    case 0x0094B7u: goto L_0094B7;
    case 0x0094BAu: goto L_0094BA;
    case 0x0094BCu: goto L_0094BC;
    case 0x0094BFu: goto L_0094BF;
    case 0x0094C1u: goto L_0094C1;
    case 0x0094C3u: goto L_0094C3;
    case 0x0094C6u: goto L_0094C6;
    case 0x0094C8u: goto L_0094C8;
    case 0x0094CBu: goto L_0094CB;
    case 0x0094CDu: goto L_0094CD;
    case 0x0094D0u: goto L_0094D0;
    case 0x0094D2u: goto L_0094D2;
    case 0x0094D4u: goto L_0094D4;
    case 0x0094D7u: goto L_0094D7;
    case 0x0094DAu: goto L_0094DA;
    case 0x0094DDu: goto L_0094DD;
    case 0x0094E0u: goto L_0094E0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8494u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8494u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8494u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008494 LDY
    cpu.setY(0xBE1Eu, 16);
    goto L_008497;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8494u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8494u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008494 LDY
    cpu.setY(0x1Eu, 8);
    goto L_008496;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8494u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8494u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008494 LDY
    cpu.setY(0xBE1Eu, 16);
    goto L_008497;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8494u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8494u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008494 LDY
    cpu.setY(0x1Eu, 8);
    goto L_008496;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8494u,0x008494u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_008496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8496u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u, 5u + 1u, 3u, cpu.address("absy", 0x8475u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008496 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x8475u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008499;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u, 4u + ((((0x8475u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8475u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008496 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x8475u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008499;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u, 5u + 1u, 3u, cpu.address("absy", 0x8475u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008496 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x8475u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008499;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u, 4u + ((((0x8475u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8475u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008496 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x8475u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008499;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8496u,0x008496u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_008497:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8497u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8497u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8497u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008497 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x84u), cpu.m8?8:16));
    goto L_008499;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8497u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8497u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008497 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x84u), cpu.m8?8:16));
    goto L_008499;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8497u,0x008497u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_008499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8499u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u, 4u + 1u, 3u, cpu.address("absx", 0x0423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008499 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x423u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00849C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u, 4u + ((((0x0423u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008499 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x423u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00849C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u, 4u + 1u, 3u, cpu.address("absx", 0x0423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008499 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x423u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00849C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u, 4u + ((((0x0423u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008499 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x423u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00849C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8499u,0x008499u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00849C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849C ASL
    cpu.aslA();
    goto L_00849D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849C ASL
    cpu.aslA();
    goto L_00849D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849C ASL
    cpu.aslA();
    goto L_00849D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849C ASL
    cpu.aslA();
    goto L_00849D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x849Cu,0x00849Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00849D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849D ASL
    cpu.aslA();
    goto L_00849E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849D ASL
    cpu.aslA();
    goto L_00849E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849D ASL
    cpu.aslA();
    goto L_00849E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849D ASL
    cpu.aslA();
    goto L_00849E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x849Du,0x00849Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00849E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu, 4u + 1u, 3u, cpu.address("absx", 0x0422u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849E ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x422u), cpu.m8?8:16));
    goto L_0084A1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu, 4u + ((((0x0422u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0422u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849E ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x422u), cpu.m8?8:16));
    goto L_0084A1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu, 4u + 1u, 3u, cpu.address("absx", 0x0422u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849E ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x422u), cpu.m8?8:16));
    goto L_0084A1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu, 4u + ((((0x0422u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0422u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849E ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x422u), cpu.m8?8:16));
    goto L_0084A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x849Eu,0x00849Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A1u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A1 ASL
    cpu.aslA();
    goto L_0084A2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A1 ASL
    cpu.aslA();
    goto L_0084A2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A1 ASL
    cpu.aslA();
    goto L_0084A2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A1 ASL
    cpu.aslA();
    goto L_0084A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84A1u,0x0084A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A2u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A2 ASL
    cpu.aslA();
    goto L_0084A3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A2 ASL
    cpu.aslA();
    goto L_0084A3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A2 ASL
    cpu.aslA();
    goto L_0084A3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A2 ASL
    cpu.aslA();
    goto L_0084A3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84A2u,0x0084A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A3u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u, 4u + 1u, 3u, cpu.address("absx", 0x0421u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x421u), cpu.m8?8:16));
    goto L_0084A6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u, 4u + ((((0x0421u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0421u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x421u), cpu.m8?8:16));
    goto L_0084A6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u, 4u + 1u, 3u, cpu.address("absx", 0x0421u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x421u), cpu.m8?8:16));
    goto L_0084A6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u, 4u + ((((0x0421u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0421u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x421u), cpu.m8?8:16));
    goto L_0084A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84A3u,0x0084A3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A6u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A6 ASL
    cpu.aslA();
    goto L_0084A7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A6 ASL
    cpu.aslA();
    goto L_0084A7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A6 ASL
    cpu.aslA();
    goto L_0084A7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A6 ASL
    cpu.aslA();
    goto L_0084A7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84A6u,0x0084A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A7u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A7 ASL
    cpu.aslA();
    goto L_0084A8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A7 ASL
    cpu.aslA();
    goto L_0084A8;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A7 ASL
    cpu.aslA();
    goto L_0084A8;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A7 ASL
    cpu.aslA();
    goto L_0084A8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84A7u,0x0084A7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A8u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u, 4u + 1u, 3u, cpu.address("absx", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A8 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x420u), cpu.m8?8:16));
    goto L_0084AB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u, 4u + ((((0x0420u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A8 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x420u), cpu.m8?8:16));
    goto L_0084AB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u, 4u + 1u, 3u, cpu.address("absx", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A8 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x420u), cpu.m8?8:16));
    goto L_0084AB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u, 4u + ((((0x0420u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A8 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x420u), cpu.m8?8:16));
    goto L_0084AB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84A8u,0x0084A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84ABu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu, 5u, 3u, cpu.address("absy", 0x0400u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084AB STA
    hw.write(cpu.address("absy", 0x400u), cpu.a, cpu.m8?8:16);
    goto L_0084AE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu, 5u, 3u, cpu.address("absy", 0x0400u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084AB STA
    hw.write(cpu.address("absy", 0x400u), cpu.a, cpu.m8?8:16);
    goto L_0084AE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu, 5u, 3u, cpu.address("absy", 0x0400u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084AB STA
    hw.write(cpu.address("absy", 0x400u), cpu.a, cpu.m8?8:16);
    goto L_0084AE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu, 5u, 3u, cpu.address("absy", 0x0400u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084AB STA
    hw.write(cpu.address("absy", 0x400u), cpu.a, cpu.m8?8:16);
    goto L_0084AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84ABu,0x0084ABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84AEu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84AEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84AEu, 4u + 1u, 3u, cpu.address("absx", 0x0427u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084AE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x427u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0084B1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84AEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84AEu, 4u + ((((0x0427u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0427u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084AE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x427u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0084B1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84AEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84AEu, 4u + 1u, 3u, cpu.address("absx", 0x0427u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084AE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x427u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0084B1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84AEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84AEu, 4u + ((((0x0427u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0427u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084AE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x427u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0084B1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84AEu,0x0084AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B1u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B1 ASL
    cpu.aslA();
    goto L_0084B2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B1 ASL
    cpu.aslA();
    goto L_0084B2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B1 ASL
    cpu.aslA();
    goto L_0084B2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B1 ASL
    cpu.aslA();
    goto L_0084B2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84B1u,0x0084B1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B2u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B2 ASL
    cpu.aslA();
    goto L_0084B3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B2 ASL
    cpu.aslA();
    goto L_0084B3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B2 ASL
    cpu.aslA();
    goto L_0084B3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B2 ASL
    cpu.aslA();
    goto L_0084B3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84B2u,0x0084B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B3u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u, 4u + 1u, 3u, cpu.address("absx", 0x0426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x426u), cpu.m8?8:16));
    goto L_0084B6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u, 4u + ((((0x0426u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x426u), cpu.m8?8:16));
    goto L_0084B6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u, 4u + 1u, 3u, cpu.address("absx", 0x0426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x426u), cpu.m8?8:16));
    goto L_0084B6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u, 4u + ((((0x0426u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x426u), cpu.m8?8:16));
    goto L_0084B6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84B3u,0x0084B3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B6u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B6 ASL
    cpu.aslA();
    goto L_0084B7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B6 ASL
    cpu.aslA();
    goto L_0084B7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B6 ASL
    cpu.aslA();
    goto L_0084B7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B6 ASL
    cpu.aslA();
    goto L_0084B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84B6u,0x0084B6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B7u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B7 ASL
    cpu.aslA();
    goto L_0084B8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B7 ASL
    cpu.aslA();
    goto L_0084B8;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B7 ASL
    cpu.aslA();
    goto L_0084B8;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B7 ASL
    cpu.aslA();
    goto L_0084B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84B7u,0x0084B7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B8u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u, 4u + 1u, 3u, cpu.address("absx", 0x0425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B8 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x425u), cpu.m8?8:16));
    goto L_0084BB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u, 4u + ((((0x0425u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B8 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x425u), cpu.m8?8:16));
    goto L_0084BB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u, 4u + 1u, 3u, cpu.address("absx", 0x0425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B8 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x425u), cpu.m8?8:16));
    goto L_0084BB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u, 4u + ((((0x0425u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B8 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x425u), cpu.m8?8:16));
    goto L_0084BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84B8u,0x0084B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BBu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BB ASL
    cpu.aslA();
    goto L_0084BC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BB ASL
    cpu.aslA();
    goto L_0084BC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BB ASL
    cpu.aslA();
    goto L_0084BC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BB ASL
    cpu.aslA();
    goto L_0084BC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84BBu,0x0084BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BCu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BC ASL
    cpu.aslA();
    goto L_0084BD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BC ASL
    cpu.aslA();
    goto L_0084BD;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BC ASL
    cpu.aslA();
    goto L_0084BD;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BC ASL
    cpu.aslA();
    goto L_0084BD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84BCu,0x0084BCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BDu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu, 4u + 1u, 3u, cpu.address("absx", 0x0424u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BD ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x424u), cpu.m8?8:16));
    goto L_0084C0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu, 4u + ((((0x0424u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0424u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BD ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x424u), cpu.m8?8:16));
    goto L_0084C0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu, 4u + 1u, 3u, cpu.address("absx", 0x0424u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BD ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x424u), cpu.m8?8:16));
    goto L_0084C0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu, 4u + ((((0x0424u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0424u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BD ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x424u), cpu.m8?8:16));
    goto L_0084C0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84BDu,0x0084BDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C0u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C0u, 5u, 3u, cpu.address("absy", 0x0401u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C0 STA
    hw.write(cpu.address("absy", 0x401u), cpu.a, cpu.m8?8:16);
    goto L_0084C3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C0u, 5u, 3u, cpu.address("absy", 0x0401u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C0 STA
    hw.write(cpu.address("absy", 0x401u), cpu.a, cpu.m8?8:16);
    goto L_0084C3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C0u, 5u, 3u, cpu.address("absy", 0x0401u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C0 STA
    hw.write(cpu.address("absy", 0x401u), cpu.a, cpu.m8?8:16);
    goto L_0084C3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C0u, 5u, 3u, cpu.address("absy", 0x0401u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C0 STA
    hw.write(cpu.address("absy", 0x401u), cpu.a, cpu.m8?8:16);
    goto L_0084C3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84C0u,0x0084C0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C3u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C3 DEY
    cpu.decReg('Y');
    goto L_0084C4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C3 DEY
    cpu.decReg('Y');
    goto L_0084C4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C3 DEY
    cpu.decReg('Y');
    goto L_0084C4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C3 DEY
    cpu.decReg('Y');
    goto L_0084C4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84C3u,0x0084C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C4u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C4 DEY
    cpu.decReg('Y');
    goto L_0084C5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C4 DEY
    cpu.decReg('Y');
    goto L_0084C5;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C4 DEY
    cpu.decReg('Y');
    goto L_0084C5;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C4 DEY
    cpu.decReg('Y');
    goto L_0084C5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84C4u,0x0084C4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C5u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C5 BPL -> $008496
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008496; }
    goto L_0084C7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C5 BPL -> $008496
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008496; }
    goto L_0084C7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C5 BPL -> $008496
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008496; }
    goto L_0084C7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C5 BPL -> $008496
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008496; }
    goto L_0084C7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84C5u,0x0084C5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0084C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C7u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0084C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0084C7u);return;} hw.unresolvedReturn(0x0084C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0084C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0084C7u);return;} hw.unresolvedReturn(0x0084C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0084C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0084C7u);return;} hw.unresolvedReturn(0x0084C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0084C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0084C7u);return;} hw.unresolvedReturn(0x0084C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84C7u,0x0084C7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9468u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9468u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9468u, 6u, 3u, cpu.address("abs", 0x85FAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009468 JSR -> $0085FA stack real
    { cpu.push16Value(hw,0x946Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x946Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85FAu), 0x009468u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00946B;
L_00946B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Bu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x946Bu,0x00946Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Bu, 6u, 3u, cpu.address("abs", 0xA1A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00946B JSR -> $00A1A6 stack real
    { cpu.push16Value(hw,0x946Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x946Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA1A6u), 0x00946Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00946E;
L_00946E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x946Eu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x946Eu,0x00946Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x946Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x946Eu, 6u, 3u, cpu.address("abs", 0x8A79u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00946E JSR -> $008A79 stack real
    { cpu.push16Value(hw,0x9470u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9471u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8A79u), 0x00946Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009471;
L_009471:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9471u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9471u,0x009471u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9471u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9471u, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009471 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13C6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_009474;
L_009474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9474u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009474 LDA
    cpu.setA(0x18u, 8);
    goto L_009476;
L_009476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9476u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9476u, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009476 STA
    hw.write(cpu.address("abs", 0x1931u), cpu.a, cpu.m8?8:16);
    goto L_009479;
L_009479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9479u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9479u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009479 LDA
    cpu.setA(0x14u, 8);
    goto L_00947B;
L_00947B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Bu, 4u, 3u, cpu.address("abs", 0x192Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00947B STA
    hw.write(cpu.address("abs", 0x192Bu), cpu.a, cpu.m8?8:16);
    goto L_00947E;
L_00947E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x947Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x947Eu, 4u + ((((0x9450u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9450u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00947E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9450u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009481;
L_009481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9481u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9481u, 4u, 3u, cpu.address("abs", 0x192Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009481 STA
    hw.write(cpu.address("abs", 0x192Fu), cpu.a, cpu.m8?8:16);
    goto L_009484;
L_009484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9484u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9484u, 4u + ((((0x9458u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9458u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009484 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9458u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009487;
L_009487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9487u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9487u, 4u, 3u, cpu.address("abs", 0x1930u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009487 STA
    hw.write(cpu.address("abs", 0x1930u), cpu.a, cpu.m8?8:16);
    goto L_00948A;
L_00948A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Au, 4u, 3u, cpu.address("abs", 0x192Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00948A STZ
    hw.write(cpu.address("abs", 0x192Eu), 0, cpu.m8?8:16);
    goto L_00948D;
L_00948D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00948D LDA
    cpu.setA(0x1u, 8);
    goto L_00948F;
L_00948F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Fu, 4u, 3u, cpu.address("abs", 0x192Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00948F STA
    hw.write(cpu.address("abs", 0x192Du), cpu.a, cpu.m8?8:16);
    goto L_009492;
L_009492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9492u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009492 CPX
    cpu.compareX(0x8u);
    goto L_009494;
L_009494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009494 BNE -> $0094B2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0094B2; }
    goto L_009496;
L_009496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9496u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9496u, 6u, 3u, cpu.address("abs", 0x955Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009496 JSR -> $00955E stack real
    { cpu.push16Value(hw,0x9498u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9499u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x955Eu), 0x009496u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009499;
L_009499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9499u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9499u,0x009499u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9499u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9499u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009499 LDA
    cpu.setA(0xD2u, 8);
    goto L_00949B;
L_00949B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00949B STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_00949D;
L_00949D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Du, 6u, 3u, cpu.address("abs", 0x85D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00949D JSR -> $0085D2 stack real
    { cpu.push16Value(hw,0x949Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94A0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D2u), 0x00949Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0094A0;
L_0094A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A0u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94A0u,0x0094A0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A0u, 6u, 3u, cpu.address("abs", 0x8159u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0094A0 JSR -> $008159 stack real
    { cpu.push16Value(hw,0x94A2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94A3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8159u), 0x0094A0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0094A3;
L_0094A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A3u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94A3u,0x0094A3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A3u, 8u, 4u, 0x0C93DDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0094A3 JSL -> $0C93DD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x94A6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94A7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0C93DDu, 0x0094A3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0094A7;
L_0094A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A7u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94A7u,0x0094A7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A7u, 6u, 3u, cpu.address("abs", 0x9260u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0094A7 JSR -> $009260 stack real
    { cpu.push16Value(hw,0x94A9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94AAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9260u), 0x0094A7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0094AA;
L_0094AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94AAu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94AAu,0x0094AAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94AAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94AAu, 6u, 3u, cpu.address("abs", 0x1931u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094AA INC
    cpu.incMem(hw, cpu.address("abs", 0x1931u), cpu.m8?8:16);
    goto L_0094AD;
L_0094AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94ADu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94ADu, 6u, 3u, cpu.address("abs", 0x192Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094AD INC
    cpu.incMem(hw, cpu.address("abs", 0x192Bu), cpu.m8?8:16);
    goto L_0094B0;
L_0094B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094B0 BRA -> $0094D7
    goto L_0094D7;
L_0094B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094B2 LDA
    cpu.setA(0x15u, 8);
    goto L_0094B4;
L_0094B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B4u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094B4 STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_0094B7;
L_0094B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B7u, 4u + ((((0x9460u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094B7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9460u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0094BA;
L_0094BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094BA STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_0094BC;
L_0094BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BCu, 6u, 3u, cpu.address("abs", 0x85D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0094BC JSR -> $0085D2 stack real
    { cpu.push16Value(hw,0x94BEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94BFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D2u), 0x0094BCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0094BF;
L_0094BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BFu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94BFu,0x0094BFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094BF LDA
    cpu.setA(0xCFu, 8);
    goto L_0094C1;
L_0094C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094C1 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_0094C3;
L_0094C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C3u, 6u, 3u, cpu.address("abs", 0x85D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0094C3 JSR -> $0085D2 stack real
    { cpu.push16Value(hw,0x94C5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94C6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D2u), 0x0094C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0094C6;
L_0094C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C6u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94C6u,0x0094C6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094C6 REP
    cpu.rep(0x20u);
    goto L_0094C8;
L_0094C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094C8 LDA
    cpu.setA(0x90u, 16);
    goto L_0094CB;
L_0094CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094CB STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_0094CD;
L_0094CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094CD LDA
    cpu.setA(0x58u, 16);
    goto L_0094D0;
L_0094D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094D0 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_0094D2;
L_0094D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094D2 SEP
    cpu.sep(0x20u);
    goto L_0094D4;
L_0094D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D4u, 6u, 3u, cpu.address("abs", 0x148Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094D4 INC
    cpu.incMem(hw, cpu.address("abs", 0x148Fu), cpu.m8?8:16);
    goto L_0094D7;
L_0094D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D7u, 6u, 3u, cpu.address("abs", 0xA9DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0094D7 JSR -> $00A9DA stack real
    { cpu.push16Value(hw,0x94D9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94DAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA9DAu), 0x0094D7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0094DA;
L_0094DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DAu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94DAu,0x0094DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DAu, 6u, 3u, cpu.address("abs", 0xABEDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0094DA JSR -> $00ABED stack real
    { cpu.push16Value(hw,0x94DCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94DDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABEDu), 0x0094DAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0094DD;
L_0094DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DDu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94DDu,0x0094DDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DDu, 6u, 3u, cpu.address("abs", 0x922Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0094DD JSR -> $00922F stack real
    { cpu.push16Value(hw,0x94DFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94E0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x922Fu), 0x0094DDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0094E0;
L_0094E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E0u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94E0u,0x0094E0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0094E0 LDX
    cpu.setX(0xBu, 8);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94E2u,0x0094E0u); return;
}

void sub_00CEB1_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CEB1u: goto L_00CEB1;
    case 0x00CEB4u: goto L_00CEB4;
    case 0x00CEB6u: goto L_00CEB6;
    case 0x00CEB9u: goto L_00CEB9;
    case 0x00CEBBu: goto L_00CEBB;
    case 0x00CEBDu: goto L_00CEBD;
    case 0x00CEBFu: goto L_00CEBF;
    case 0x00CEC1u: goto L_00CEC1;
    case 0x00CEC3u: goto L_00CEC3;
    case 0x00CEC5u: goto L_00CEC5;
    case 0x00CEC7u: goto L_00CEC7;
    case 0x00CEC9u: goto L_00CEC9;
    case 0x00CECBu: goto L_00CECB;
    case 0x00CECDu: goto L_00CECD;
    case 0x00CECEu: goto L_00CECE;
    case 0x00CED0u: goto L_00CED0;
    case 0x00CED2u: goto L_00CED2;
    case 0x00CED4u: goto L_00CED4;
    case 0x00CED6u: goto L_00CED6;
    case 0x00CED8u: goto L_00CED8;
    case 0x00CEDAu: goto L_00CEDA;
    case 0x00CEDCu: goto L_00CEDC;
    case 0x00CEDEu: goto L_00CEDE;
    case 0x00CEE0u: goto L_00CEE0;
    case 0x00CEE2u: goto L_00CEE2;
    case 0x00CEE4u: goto L_00CEE4;
    case 0x00CEE5u: goto L_00CEE5;
    case 0x00CEE7u: goto L_00CEE7;
    case 0x00CEE8u: goto L_00CEE8;
    case 0x00CEEAu: goto L_00CEEA;
    case 0x00CEECu: goto L_00CEEC;
    case 0x00CEEEu: goto L_00CEEE;
    case 0x00CEF0u: goto L_00CEF0;
    case 0x00CEF2u: goto L_00CEF2;
    case 0x00CEF4u: goto L_00CEF4;
    case 0x00CEF5u: goto L_00CEF5;
    case 0x00CEF6u: goto L_00CEF6;
    case 0x00CEF7u: goto L_00CEF7;
    case 0x00CEF8u: goto L_00CEF8;
    case 0x00CEF9u: goto L_00CEF9;
    case 0x00CEFCu: goto L_00CEFC;
    case 0x00CEFDu: goto L_00CEFD;
    case 0x00CEFEu: goto L_00CEFE;
    case 0x00CF00u: goto L_00CF00;
    case 0x00CF02u: goto L_00CF02;
    case 0x00CF04u: goto L_00CF04;
    case 0x00CF06u: goto L_00CF06;
    case 0x00CF08u: goto L_00CF08;
    case 0x00CF0Au: goto L_00CF0A;
    case 0x00CF0Du: goto L_00CF0D;
    case 0x00CF0Eu: goto L_00CF0E;
    case 0x00CF10u: goto L_00CF10;
    case 0x00CF12u: goto L_00CF12;
    case 0x00CF13u: goto L_00CF13;
    case 0x00CF16u: goto L_00CF16;
    case 0x00CF19u: goto L_00CF19;
    case 0x00CF1Cu: goto L_00CF1C;
    case 0x00CF1Eu: goto L_00CF1E;
    case 0x00CF20u: goto L_00CF20;
    case 0x00CF22u: goto L_00CF22;
    case 0x00CF24u: goto L_00CF24;
    case 0x00CF25u: goto L_00CF25;
    case 0x00CF26u: goto L_00CF26;
    case 0x00CF28u: goto L_00CF28;
    case 0x00CF2Au: goto L_00CF2A;
    case 0x00CF2Cu: goto L_00CF2C;
    case 0x00CF2Eu: goto L_00CF2E;
    case 0x00CF2Fu: goto L_00CF2F;
    case 0x00CF32u: goto L_00CF32;
    case 0x00CF35u: goto L_00CF35;
    case 0x00CF37u: goto L_00CF37;
    case 0x00CF39u: goto L_00CF39;
    case 0x00CF3Au: goto L_00CF3A;
    case 0x00CF3Du: goto L_00CF3D;
    case 0x00CF3Fu: goto L_00CF3F;
    case 0x00CF41u: goto L_00CF41;
    case 0x00CF43u: goto L_00CF43;
    case 0x00CF45u: goto L_00CF45;
    case 0x00CF48u: goto L_00CF48;
    case 0x00CF4Bu: goto L_00CF4B;
    case 0x00CF4Eu: goto L_00CF4E;
    case 0x00CF51u: goto L_00CF51;
    case 0x00CF53u: goto L_00CF53;
    case 0x00CF55u: goto L_00CF55;
    case 0x00CF58u: goto L_00CF58;
    case 0x00CF59u: goto L_00CF59;
    case 0x00CF5Au: goto L_00CF5A;
    case 0x00CF5Cu: goto L_00CF5C;
    case 0x00CF5Du: goto L_00CF5D;
    case 0x00CF60u: goto L_00CF60;
    case 0x00CF62u: goto L_00CF62;
    case 0x00CF64u: goto L_00CF64;
    case 0x00CF67u: goto L_00CF67;
    case 0x00CF69u: goto L_00CF69;
    case 0x00CF6Bu: goto L_00CF6B;
    case 0x00CF6Du: goto L_00CF6D;
    case 0x00CF6Fu: goto L_00CF6F;
    case 0x00CF72u: goto L_00CF72;
    case 0x00CF74u: goto L_00CF74;
    case 0x00CF76u: goto L_00CF76;
    case 0x00CF78u: goto L_00CF78;
    case 0x00CF7Au: goto L_00CF7A;
    case 0x00CF7Cu: goto L_00CF7C;
    case 0x00CF7Eu: goto L_00CF7E;
    case 0x00CF80u: goto L_00CF80;
    case 0x00CF83u: goto L_00CF83;
    case 0x00CF85u: goto L_00CF85;
    case 0x00CF88u: goto L_00CF88;
    case 0x00CF8Au: goto L_00CF8A;
    case 0x00CF8Du: goto L_00CF8D;
    case 0x00CF8Fu: goto L_00CF8F;
    case 0x00CF91u: goto L_00CF91;
    case 0x00CF94u: goto L_00CF94;
    case 0x00CF96u: goto L_00CF96;
    case 0x00CF98u: goto L_00CF98;
    case 0x00CF9Bu: goto L_00CF9B;
    case 0x00CF9Du: goto L_00CF9D;
    case 0x00CF9Fu: goto L_00CF9F;
    case 0x00CFA1u: goto L_00CFA1;
    case 0x00CFA4u: goto L_00CFA4;
    case 0x00CFA6u: goto L_00CFA6;
    case 0x00CFA9u: goto L_00CFA9;
    case 0x00CFABu: goto L_00CFAB;
    case 0x00CFAEu: goto L_00CFAE;
    case 0x00CFB1u: goto L_00CFB1;
    case 0x00CFB3u: goto L_00CFB3;
    case 0x00CFB5u: goto L_00CFB5;
    case 0x00CFB7u: goto L_00CFB7;
    case 0x00CFBAu: goto L_00CFBA;
    case 0x00CFBCu: goto L_00CFBC;
    case 0x00CFBEu: goto L_00CFBE;
    case 0x00CFC0u: goto L_00CFC0;
    case 0x00CFC2u: goto L_00CFC2;
    case 0x00CFC3u: goto L_00CFC3;
    case 0x00CFC4u: goto L_00CFC4;
    case 0x00CFC6u: goto L_00CFC6;
    case 0x00CFC7u: goto L_00CFC7;
    case 0x00CFC9u: goto L_00CFC9;
    case 0x00CFCBu: goto L_00CFCB;
    case 0x00CFCDu: goto L_00CFCD;
    case 0x00CFCFu: goto L_00CFCF;
    case 0x00CFD2u: goto L_00CFD2;
    case 0x00CFD4u: goto L_00CFD4;
    case 0x00CFD6u: goto L_00CFD6;
    case 0x00CFD8u: goto L_00CFD8;
    case 0x00CFDAu: goto L_00CFDA;
    case 0x00CFDCu: goto L_00CFDC;
    case 0x00CFDEu: goto L_00CFDE;
    case 0x00CFE0u: goto L_00CFE0;
    case 0x00CFE3u: goto L_00CFE3;
    case 0x00CFE6u: goto L_00CFE6;
    case 0x00CFE9u: goto L_00CFE9;
    case 0x00CFEBu: goto L_00CFEB;
    case 0x00CFECu: goto L_00CFEC;
    case 0x00CFEEu: goto L_00CFEE;
    case 0x00CFF0u: goto L_00CFF0;
    case 0x00CFF3u: goto L_00CFF3;
    case 0x00CFF4u: goto L_00CFF4;
    case 0x00CFF5u: goto L_00CFF5;
    case 0x00CFF6u: goto L_00CFF6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB1u, 4u, 3u, cpu.address("abs", 0x14A2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEB1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CEB4;
L_00CEB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEB4 BNE -> $00CF16
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF16; }
    goto L_00CEB6;
L_00CEB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB6u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB6u, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEB6 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13DFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CEB9;
L_00CEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEB9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CEBB;
L_00CEBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEBB BEQ -> $00CEDE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CEDE; }
    goto L_00CEBD;
L_00CEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBDu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEBD LDY
    cpu.setY(0x4u, 8);
    goto L_00CEBF;
L_00CEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEBF BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), false);
    goto L_00CEC1;
L_00CEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEC1 BPL -> $00CECD
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00CECD; }
    goto L_00CEC3;
L_00CEC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEC3 CMP
    cpu.compareA(0xCu);
    goto L_00CEC5;
L_00CEC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEC5 BEQ -> $00CEFD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CEFD; }
    goto L_00CEC7;
L_00CEC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEC7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CEC9;
L_00CEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEC9 BNE -> $00CEFD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CEFD; }
    goto L_00CECB;
L_00CECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECBu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CECB BRA -> $00CEE4
    goto L_00CEE4;
L_00CECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECDu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CECD INX
    cpu.inc('X');
    goto L_00CECE;
L_00CECE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECEu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CECE CPX
    cpu.compareX(0x5u);
    goto L_00CED0;
L_00CED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CED0 BCS -> $00CED6
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CED6; }
    goto L_00CED2;
L_00CED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CED2 LDX
    cpu.setX(0x5u, 8);
    goto L_00CED4;
L_00CED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CED4 BRA -> $00CF0A
    goto L_00CF0A;
L_00CED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED6u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CED6 CPX
    cpu.compareX(0xBu);
    goto L_00CED8;
L_00CED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CED8 BCC -> $00CF0A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CF0A; }
    goto L_00CEDA;
L_00CEDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDAu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEDA LDX
    cpu.setX(0x7u, 8);
    goto L_00CEDC;
L_00CEDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDCu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEDC BRA -> $00CF0A
    goto L_00CF0A;
L_00CEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEDE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CEE0;
L_00CEE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEE0 BNE -> $00CEF0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CEF0; }
    goto L_00CEE2;
L_00CEE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEE2 LDY
    cpu.setY(0x8u, 8);
    goto L_00CEE4;
L_00CEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEE4 TXA
    cpu.transfer("TXA");
    goto L_00CEE5;
L_00CEE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEE5 BEQ -> $00CF0A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF0A; }
    goto L_00CEE7;
L_00CEE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE7u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEE7 DEX
    cpu.decReg('X');
    goto L_00CEE8;
L_00CEE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE8u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEE8 CPX
    cpu.compareX(0x3u);
    goto L_00CEEA;
L_00CEEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEEA BCC -> $00CF0A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CF0A; }
    goto L_00CEEC;
L_00CEEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEECu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEEC LDX
    cpu.setX(0x2u, 8);
    goto L_00CEEE;
L_00CEEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEEE BRA -> $00CF0A
    goto L_00CF0A;
L_00CEF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF0 BPL -> $00CEF5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00CEF5; }
    goto L_00CEF2;
L_00CEF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF2u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF2 EOR
    cpu.logicXor(0xFFu);
    goto L_00CEF4;
L_00CEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF4 INC
    cpu.inc('A');
    goto L_00CEF5;
L_00CEF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF5 LSR
    cpu.lsrA();
    goto L_00CEF6;
L_00CEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF6 LSR
    cpu.lsrA();
    goto L_00CEF7;
L_00CEF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF7 LSR
    cpu.lsrA();
    goto L_00CEF8;
L_00CEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF8u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF8 TAY
    cpu.transfer("TAY");
    goto L_00CEF9;
L_00CEF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF9u, 4u + ((((0xDC7Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDC7Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDC7Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CEFC;
L_00CEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFCu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEFC TAY
    cpu.transfer("TAY");
    goto L_00CEFD;
L_00CEFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFDu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEFD INX
    cpu.inc('X');
    goto L_00CEFE;
L_00CEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFEu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEFE CPX
    cpu.compareX(0x3u);
    goto L_00CF00;
L_00CF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF00u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF00 BCS -> $00CF04
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CF04; }
    goto L_00CF02;
L_00CF02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF02u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF02 LDX
    cpu.setX(0x5u, 8);
    goto L_00CF04;
L_00CF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF04u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF04 CPX
    cpu.compareX(0x7u);
    goto L_00CF06;
L_00CF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF06u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF06 BCC -> $00CF0A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CF0A; }
    goto L_00CF08;
L_00CF08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF08u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF08 LDX
    cpu.setX(0x3u, 8);
    goto L_00CF0A;
L_00CF0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Au,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Au, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF0A STX
    hw.write(cpu.address("abs", 0x13DFu), cpu.x, cpu.x8?8:16);
    goto L_00CF0D;
L_00CF0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF0D TYA
    cpu.transfer("TYA");
    goto L_00CF0E;
L_00CF0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF0E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x75u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF10;
L_00CF10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF10u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF10 BEQ -> $00CF13
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF13; }
    goto L_00CF12;
L_00CF12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF12u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF12 ASL
    cpu.aslA();
    goto L_00CF13;
L_00CF13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF13u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF13u, 4u, 3u, cpu.address("abs", 0x14A2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF13 STA
    hw.write(cpu.address("abs", 0x14A2u), cpu.a, cpu.m8?8:16);
    goto L_00CF16;
L_00CF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF16u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF16u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF16 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x140Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF19;
L_00CF19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF19u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF19u, 4u, 3u, cpu.address("abs", 0x14A6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF19 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x14A6u), cpu.m8?8:16));
    goto L_00CF1C;
L_00CF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF1C BEQ -> $00CF4E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF4E; }
    goto L_00CF1E;
L_00CF1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF1E STZ
    hw.write(cpu.address("dp", 0x73u), 0, cpu.m8?8:16);
    goto L_00CF20;
L_00CF20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF20u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF20u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF20 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF22;
L_00CF22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF22u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF22 AND
    cpu.logicAnd(0x6u);
    goto L_00CF24;
L_00CF24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF24u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF24 TAX
    cpu.transfer("TAX");
    goto L_00CF25;
L_00CF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF25u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF25 TAY
    cpu.transfer("TAY");
    goto L_00CF26;
L_00CF26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF26u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF26 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF28;
L_00CF28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF28u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF28 BEQ -> $00CF2F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF2F; }
    goto L_00CF2A;
L_00CF2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF2A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF2C;
L_00CF2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF2C BMI -> $00CF2F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00CF2F; }
    goto L_00CF2E;
L_00CF2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF2E INY
    cpu.inc('Y');
    goto L_00CF2F;
L_00CF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Fu, 4u + ((((0xCEA9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCEA9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF2F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCEA9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF32;
L_00CF32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF32u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF32u, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF32 STA
    hw.write(cpu.address("abs", 0x13DFu), cpu.a, cpu.m8?8:16);
    goto L_00CF35;
L_00CF35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF35u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF35u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF35 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF37;
L_00CF37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF37u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF37 BEQ -> $00CF3A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF3A; }
    goto L_00CF39;
L_00CF39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF39u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF39u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF39 INX
    cpu.inc('X');
    goto L_00CF3A;
L_00CF3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Au, 4u + ((((0xCEA1u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCEA1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF3A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xCEA1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF3D;
L_00CF3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF3D STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00CF3F;
L_00CF3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF3F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF41;
L_00CF41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF41u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF41 CPY
    cpu.compareY(0x2u);
    goto L_00CF43;
L_00CF43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF43u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF43 BNE -> $00CF48
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF48; }
    goto L_00CF45;
L_00CF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF45u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF45u, 6u, 3u, cpu.address("abs", 0xD044u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CF45 JSR -> $00D044 stack real
    { cpu.push16Value(hw,0xCF47u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF48u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD044u), 0x00CF45u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CF48;
L_00CF48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF48u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF48u,0x00CF48u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF48u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF48u, 4u + ((((0xCE99u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCE99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF48 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xCE99u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF4B;
L_00CF4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Bu, 3u, 3u, cpu.address("abs", 0xD01Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF4B JMP -> $00D01A
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xD01Au),0x00CF4Bu); return;
L_00CF4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Eu, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF4E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13EDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF51;
L_00CF51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF51u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF51u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF51 BEQ -> $00CF62
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF62; }
    goto L_00CF53;
L_00CF53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF53u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF53 BPL -> $00CF85
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00CF85; }
    goto L_00CF55;
L_00CF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF55u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF55u, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF55 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13E1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF58;
L_00CF58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF58u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF58u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF58 LSR
    cpu.lsrA();
    goto L_00CF59;
L_00CF59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF59u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF59u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF59 LSR
    cpu.lsrA();
    goto L_00CF5A;
L_00CF5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Au,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF5A ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16));
    goto L_00CF5C;
L_00CF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF5C TAY
    cpu.transfer("TAY");
    goto L_00CF5D;
L_00CF5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Du, 4u + ((((0xCE7Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCE7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF5D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCE7Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF60;
L_00CF60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF60u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF60u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF60 BRA -> $00CF85
    goto L_00CF85;
L_00CF62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF62u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF62 LDA
    cpu.setA(0x3Cu, 8);
    goto L_00CF64;
L_00CF64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF64u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF64u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF64 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x148Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF67;
L_00CF67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF67u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF67 BEQ -> $00CF6B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF6B; }
    goto L_00CF69;
L_00CF69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF69u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF69u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF69 LDA
    cpu.setA(0x1Du, 8);
    goto L_00CF6B;
L_00CF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF6B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x73u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF6D;
L_00CF6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF6D BNE -> $00CF85
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF85; }
    goto L_00CF6F;
L_00CF6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Fu, 4u, 3u, cpu.address("abs", 0x149Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF6F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x149Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF72;
L_00CF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF72u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF72 BEQ -> $00CF7E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF7E; }
    goto L_00CF74;
L_00CF74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF74u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF74 LDA
    cpu.setA(0x3Fu, 8);
    goto L_00CF76;
L_00CF76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF76u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF76u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF76 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x72u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF78;
L_00CF78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF78u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF78 BEQ -> $00CF85
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF85; }
    goto L_00CF7A;
L_00CF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF7A LDA
    cpu.setA(0x16u, 8);
    goto L_00CF7C;
L_00CF7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF7C BRA -> $00CF85
    goto L_00CF85;
L_00CF7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF7E LDA
    cpu.setA(0xEu, 8);
    goto L_00CF80;
L_00CF80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF80u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF80u, 4u, 3u, cpu.address("abs", 0x149Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF80 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x149Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF83;
L_00CF83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF83u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF83 BEQ -> $00CF88
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF88; }
    goto L_00CF85;
L_00CF85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF85u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF85u, 3u, 3u, cpu.address("abs", 0xD01Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF85 JMP -> $00D01A
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xD01Au),0x00CF85u); return;
L_00CF88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF88u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF88 LDA
    cpu.setA(0x1Du, 8);
    goto L_00CF8A;
L_00CF8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Au, 4u, 3u, cpu.address("abs", 0x1498u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF8A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1498u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF8D;
L_00CF8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF8D BNE -> $00CF85
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF85; }
    goto L_00CF8F;
L_00CF8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF8F LDA
    cpu.setA(0xFu, 8);
    goto L_00CF91;
L_00CF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF91u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF91u, 4u, 3u, cpu.address("abs", 0x1499u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF91 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1499u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF94;
L_00CF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF94u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF94 BNE -> $00CF85
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF85; }
    goto L_00CF96;
L_00CF96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF96u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF96 LDA
    cpu.setA(0x0u, 8);
    goto L_00CF98;
L_00CF98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF98u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF98u, 4u, 3u, cpu.address("abs", 0x18C2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF98 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x18C2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF9B;
L_00CF9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF9B BNE -> $00CFC3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CFC3; }
    goto L_00CF9D;
L_00CF9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF9D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF9F;
L_00CF9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF9F BEQ -> $00CFB7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CFB7; }
    goto L_00CFA1;
L_00CFA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA1u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA1u, 4u, 3u, cpu.address("abs", 0x14A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFA1 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x14A0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CFA4;
L_00CFA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFA4 BNE -> $00CFBC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CFBC; }
    goto L_00CFA6;
L_00CFA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA6u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA6u, 4u, 3u, cpu.address("abs", 0x1407u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFA6 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1407u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CFA9;
L_00CFA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFA9 BEQ -> $00CFAE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CFAE; }
    goto L_00CFAB;
L_00CFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFABu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFABu, 4u + ((((0xCE78u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCE78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFAB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCE78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFAE;
L_00CFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAEu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAEu, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFAE LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x148Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CFB1;
L_00CFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFB1 BEQ -> $00D01A
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00D01Au,0x00CFB1u); return; }
    goto L_00CFB3;
L_00CFB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFB3 LDA
    cpu.setA(0x9u, 8);
    goto L_00CFB5;
L_00CFB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFB5 BRA -> $00D01A
    hw.requestDispatch(0x00D01Au,0x00CFB5u); return;
L_00CFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB7u, 4u, 3u, cpu.address("abs", 0x13DDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFB7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13DDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFBA;
L_00CFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFBA BNE -> $00D01A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00D01Au,0x00CFBAu); return; }
    goto L_00CFBC;
L_00CFBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFBC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFBE;
L_00CFBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFBE BPL -> $00CFC3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00CFC3; }
    goto L_00CFC0;
L_00CFC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC0u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFC0 EOR
    cpu.logicXor(0xFFu);
    goto L_00CFC2;
L_00CFC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC2u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFC2 INC
    cpu.inc('A');
    goto L_00CFC3;
L_00CFC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFC3 TAX
    cpu.transfer("TAX");
    goto L_00CFC4;
L_00CFC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFC4 BNE -> $00CFD4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CFD4; }
    goto L_00CFC6;
L_00CFC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC6u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFC6 XBA
    cpu.xba();
    goto L_00CFC7;
L_00CFC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFC7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFC9;
L_00CFC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFC9 AND
    cpu.logicAnd(0x8u);
    goto L_00CFCB;
L_00CFCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFCB BEQ -> $00D002
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00D002u,0x00CFCBu); return; }
    goto L_00CFCD;
L_00CFCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFCD LDA
    cpu.setA(0x3u, 8);
    goto L_00CFCF;
L_00CFCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCFu, 4u, 3u, cpu.address("abs", 0x13DEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFCF STA
    hw.write(cpu.address("abs", 0x13DEu), cpu.a, cpu.m8?8:16);
    goto L_00CFD2;
L_00CFD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFD2 BRA -> $00D002
    hw.requestDispatch(0x00D002u,0x00CFD2u); return;
L_00CFD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFD4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFD6;
L_00CFD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFD6 BEQ -> $00CFE3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CFE3; }
    goto L_00CFD8;
L_00CFD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFD8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFDA;
L_00CFDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFDA AND
    cpu.logicAnd(0x3u);
    goto L_00CFDC;
L_00CFDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFDC BEQ -> $00D003
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00D003u,0x00CFDCu); return; }
    goto L_00CFDE;
L_00CFDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFDE LDA
    cpu.setA(0x68u, 8);
    goto L_00CFE0;
L_00CFE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE0u, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFE0 STA
    hw.write(cpu.address("abs", 0x13E5u), cpu.a, cpu.m8?8:16);
    goto L_00CFE3;
L_00CFE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE3u, 4u, 3u, cpu.address("abs", 0x13DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFE3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13DBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFE6;
L_00CFE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE6u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE6u, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFE6 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1496u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CFE9;
L_00CFE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFE9 BNE -> $00D003
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00D003u,0x00CFE9u); return; }
    goto L_00CFEB;
L_00CFEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEBu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFEB DEC
    cpu.decReg('A');
    goto L_00CFEC;
L_00CFEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFECu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFEC BPL -> $00CFF3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00CFF3; }
    goto L_00CFEE;
L_00CFEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEEu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFEE LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CFF0;
L_00CFF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF0u, 4u + ((((0xDC78u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDC78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFF0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDC78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFF3;
L_00CFF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF3u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFF3 XBA
    cpu.xba();
    goto L_00CFF4;
L_00CFF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFF4 TXA
    cpu.transfer("TXA");
    goto L_00CFF5;
L_00CFF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFF5 LSR
    cpu.lsrA();
    goto L_00CFF6;
L_00CFF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFF6 LSR
    cpu.lsrA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCFF7u,0x00CFF6u); return;
}

void sub_00D062_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00D062u: goto L_00D062;
    case 0x00D064u: goto L_00D064;
    case 0x00D066u: goto L_00D066;
    case 0x00D068u: goto L_00D068;
    case 0x00D06Au: goto L_00D06A;
    case 0x00D06Cu: goto L_00D06C;
    case 0x00D06Eu: goto L_00D06E;
    case 0x00D071u: goto L_00D071;
    case 0x00D074u: goto L_00D074;
    case 0x00D076u: goto L_00D076;
    case 0x00D078u: goto L_00D078;
    case 0x00D07Bu: goto L_00D07B;
    case 0x00D07Du: goto L_00D07D;
    case 0x00D080u: goto L_00D080;
    case 0x00D081u: goto L_00D081;
    case 0x00D083u: goto L_00D083;
    case 0x00D085u: goto L_00D085;
    case 0x00D087u: goto L_00D087;
    case 0x00D08Au: goto L_00D08A;
    case 0x00D08Cu: goto L_00D08C;
    case 0x00D08Eu: goto L_00D08E;
    case 0x00D090u: goto L_00D090;
    case 0x00D093u: goto L_00D093;
    case 0x00D095u: goto L_00D095;
    case 0x00D098u: goto L_00D098;
    case 0x00D09Bu: goto L_00D09B;
    case 0x00D09Du: goto L_00D09D;
    case 0x00D09Fu: goto L_00D09F;
    case 0x00D0A0u: goto L_00D0A0;
    case 0x00D0A3u: goto L_00D0A3;
    case 0x00D0A5u: goto L_00D0A5;
    case 0x00D0A7u: goto L_00D0A7;
    case 0x00D0A8u: goto L_00D0A8;
    case 0x00D0AAu: goto L_00D0AA;
    case 0x00D0ADu: goto L_00D0AD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00D062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD062u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD062u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D062 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D064;
L_00D064:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD064u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD064u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD064u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D064 CMP
    cpu.compareA(0x2u);
    goto L_00D066;
L_00D066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD066u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD066u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D066 BNE -> $00D081
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D081; }
    goto L_00D068;
L_00D068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD068u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD068u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD068u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D068 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), false);
    goto L_00D06A;
L_00D06A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD06Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Au,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D06A BVC -> $00D0AD
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_00D0AD; }
    goto L_00D06C;
L_00D06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D06C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x73u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D06E;
L_00D06E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD06Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Eu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Eu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D06E ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16));
    goto L_00D071;
L_00D071:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD071u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD071u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD071u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D071 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x140Du), cpu.m8?8:16));
    goto L_00D074;
L_00D074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD074u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD074u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D074 BNE -> $00D0AD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D0AD; }
    goto L_00D076;
L_00D076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD076u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD076u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D076 LDA
    cpu.setA(0x12u, 8);
    goto L_00D078;
L_00D078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD078u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD078u, 4u, 3u, cpu.address("abs", 0x14A6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D078 STA
    hw.write(cpu.address("abs", 0x14A6u), cpu.a, cpu.m8?8:16);
    goto L_00D07B;
L_00D07B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD07Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD07Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD07Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D07B LDA
    cpu.setA(0x4u, 8);
    goto L_00D07D;
L_00D07D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD07Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD07Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD07Du, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D07D STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00D080;
L_00D080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD080u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD080u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D080 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00D080u);return;} hw.unresolvedReturn(0x00D080u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00D081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD081u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD081u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D081 CMP
    cpu.compareA(0x3u);
    goto L_00D083;
L_00D083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD083u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD083u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D083 BNE -> $00D0AD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D0AD; }
    goto L_00D085;
L_00D085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD085u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD085u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D085 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x73u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D087;
L_00D087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD087u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD087u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D087 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16));
    goto L_00D08A;
L_00D08A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD08Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D08A BNE -> $00D0AD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D0AD; }
    goto L_00D08C;
L_00D08C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD08Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Cu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D08C BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), false);
    goto L_00D08E;
L_00D08E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD08Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Eu,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD08Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D08E BVS -> $00D0AA
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_00D0AA; }
    goto L_00D090;
L_00D090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD090u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD090u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD090u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D090 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x140Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D093;
L_00D093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD093u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD093u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD093u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D093 BEQ -> $00D0AD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D0AD; }
    goto L_00D095;
L_00D095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD095u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD095u, 6u, 3u, cpu.address("abs", 0x13E2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D095 INC
    cpu.incMem(hw, cpu.address("abs", 0x13E2u), cpu.m8?8:16);
    goto L_00D098;
L_00D098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD098u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD098u, 4u, 3u, cpu.address("abs", 0x13E2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D098 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13E2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D09B;
L_00D09B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD09Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D09B AND
    cpu.logicAnd(0xFu);
    goto L_00D09D;
L_00D09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD09Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D09D BNE -> $00D0AD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D0AD; }
    goto L_00D09F;
L_00D09F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD09Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD09Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D09F TAY
    cpu.transfer("TAY");
    goto L_00D0A0;
L_00D0A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A0u, 4u, 3u, cpu.address("abs", 0x13E2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D0A0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13E2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D0A3;
L_00D0A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D0A3 AND
    cpu.logicAnd(0x10u);
    goto L_00D0A5;
L_00D0A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D0A5 BEQ -> $00D0A8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D0A8; }
    goto L_00D0A7;
L_00D0A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D0A7 INY
    cpu.inc('Y');
    goto L_00D0A8;
L_00D0A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A8u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0A8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D0A8 STY
    hw.write(cpu.address("dp", 0x76u), cpu.y, cpu.x8?8:16);
    goto L_00D0AA;
L_00D0AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0AAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0AAu, 6u, 3u, cpu.address("abs", 0xFEA8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D0AA JSR -> $00FEA8 stack real
    { cpu.push16Value(hw,0xD0ACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0ADu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFEA8u), 0x00D0AAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00D0AD;
L_00D0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0ADu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0ADu,0x00D0ADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ADu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0ADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D0AD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00D0ADu);return;} hw.unresolvedReturn(0x00D0ADu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CC68_E0M1X1C0_part6(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00DB8Cu: goto L_00DB8C;
    case 0x00DB8Fu: goto L_00DB8F;
    case 0x00DB92u: goto L_00DB92;
    case 0x00DB95u: goto L_00DB95;
    case 0x00DB96u: goto L_00DB96;
    case 0x00DB98u: goto L_00DB98;
    case 0x00DB9Au: goto L_00DB9A;
    case 0x00DB9Cu: goto L_00DB9C;
    case 0x00DB9Eu: goto L_00DB9E;
    case 0x00DB9Fu: goto L_00DB9F;
    case 0x00DBA0u: goto L_00DBA0;
    case 0x00DBA1u: goto L_00DBA1;
    case 0x00DBA2u: goto L_00DBA2;
    case 0x00DBA3u: goto L_00DBA3;
    case 0x00DBA5u: goto L_00DBA5;
    case 0x00DBA7u: goto L_00DBA7;
    case 0x00DBA8u: goto L_00DBA8;
    case 0x00DBA9u: goto L_00DBA9;
    case 0x00DBAAu: goto L_00DBAA;
    case 0x00DBACu: goto L_00DBAC;
    case 0x00DBAEu: goto L_00DBAE;
    case 0x00DBB0u: goto L_00DBB0;
    case 0x00DBB2u: goto L_00DBB2;
    case 0x00DBB4u: goto L_00DBB4;
    case 0x00DBB5u: goto L_00DBB5;
    case 0x00DBB7u: goto L_00DBB7;
    case 0x00DBB8u: goto L_00DBB8;
    case 0x00DBBAu: goto L_00DBBA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00DB8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB8Cu))return;
  // 7 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu, 6u, 3u, cpu.address("abs", 0xD044u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DB8C JSR -> $00D044 stack real
    { cpu.push16Value(hw,0xDB8Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD044u), 0x00DB8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DB8F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu, 6u, 3u, cpu.address("abs", 0xD044u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DB8C JSR -> $00D044 stack real
    { cpu.push16Value(hw,0xDB8Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD044u), 0x00DB8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DB8F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu, 6u, 3u, cpu.address("abs", 0xD044u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DB8C JSR -> $00D044 stack real
    { cpu.push16Value(hw,0xDB8Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD044u), 0x00DB8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DB8F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu, 6u, 3u, cpu.address("abs", 0xD044u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DB8C JSR -> $00D044 stack real
    { cpu.push16Value(hw,0xDB8Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD044u), 0x00DB8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DB8F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu, 6u, 3u, cpu.address("abs", 0xD044u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DB8C JSR -> $00D044 stack real
    { cpu.push16Value(hw,0xDB8Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD044u), 0x00DB8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DB8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB8Cu,0x00DB8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB8Fu))return;
  // 7 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu, 4u + ((((0xDADDu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDADDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB8F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB92;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu, 5u + ((((0xDADDu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDADDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB8F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB92;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu, 4u + 1u, 3u, cpu.address("absx", 0xDADDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB8F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB92;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu, 4u + ((((0xDADDu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDADDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB8F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB92;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu, 4u + ((((0xDADDu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDADDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB8F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB92;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,0x00DB8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB92u))return;
  // 9 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB92 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00DB95;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u, 5u, 3u, cpu.address("abs", 0x13E0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB92 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00DB95;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB92 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00DB95;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB92 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00DB95;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB92 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00DB95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB92u,0x00DB92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB95u))return;
  // 9 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB95u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB95u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DB95 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DB95u);return;} hw.unresolvedReturn(0x00DB95u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB95u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB95u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DB95 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DB95u);return;} hw.unresolvedReturn(0x00DB95u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB95u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB95u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DB95 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DB95u);return;} hw.unresolvedReturn(0x00DB95u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB95u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB95u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DB95 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DB95u);return;} hw.unresolvedReturn(0x00DB95u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB95u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB95u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DB95 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DB95u);return;} hw.unresolvedReturn(0x00DB95u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB95u,0x00DB95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB96u))return;
  // 7 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB96u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB96u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB96 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x75u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB98;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB96u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB96u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB96 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x75u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB98;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB96u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB96u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB96 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x75u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB98;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB96u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB96u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB96 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x75u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB98;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB96u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB96u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB96 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x75u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB96u,0x00DB96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB98u))return;
  // 7 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB98u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB98u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB98 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), false);
    goto L_00DB9A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB98u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB98u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB98 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), false);
    goto L_00DB9A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB98u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB98u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB98 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), false);
    goto L_00DB9A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB98u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB98u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB98 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), false);
    goto L_00DB9A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB98u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB98u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB98 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), false);
    goto L_00DB9A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB98u,0x00DB98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB9Au))return;
  // 7 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB9A BPL -> $00DBAC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DBAC; }
    goto L_00DB9C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB9A BPL -> $00DBAC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DBAC; }
    goto L_00DB9C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB9A BPL -> $00DBAC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DBAC; }
    goto L_00DB9C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB9A BPL -> $00DBAC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DBAC; }
    goto L_00DB9C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB9A BPL -> $00DBAC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DBAC; }
    goto L_00DB9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB9Au,0x00DB9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB9Cu))return;
  // 7 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB9C LDA
    cpu.setA(0xBu, 8);
    goto L_00DB9E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB9C LDA
    cpu.setA(0x850Bu, 16);
    goto L_00DB9F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB9C LDA
    cpu.setA(0xBu, 8);
    goto L_00DB9E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB9C LDA
    cpu.setA(0xBu, 8);
    goto L_00DB9E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB9C LDA
    cpu.setA(0xBu, 8);
    goto L_00DB9E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB9Cu,0x00DB9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB9Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB9E STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00DBA0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB9E STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00DBA0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB9E STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00DBA0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB9E STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00DBA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB9Eu,0x00DB9Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB9Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Fu,cpu,0x72u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xB9u) & 0xFFFFu), 2u, 0u);
    // $00DB9F ADC
    cpu.adc(hw.readW(cpu.addressDpIndirect(hw, 0xB9u), cpu.m8?8:16));
    goto L_00DBA1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB9Fu,0x00DB9Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA0u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA0u, 4u + ((((0xDABBu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDABBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDABBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBA3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA0u, 4u + 1u, 3u, cpu.address("absy", 0xDABBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDABBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBA3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA0u, 4u + ((((0xDABBu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDABBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDABBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBA3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA0u, 4u + ((((0xDABBu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDABBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDABBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBA0u,0x00DBA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA1u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA1u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA1 TYX
    cpu.transfer("TYX");
    goto L_00DBA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBA1u,0x00DBA1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA2u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00DBA2 PHX
    cpu.push("PHX", hw);
    goto L_00DBA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBA2u,0x00DBA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA3u))return;
  // 7 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA3 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00DBA5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA3 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00DBA5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA3 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00DBA5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA3 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00DBA5;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA3 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00DBA5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBA3u,0x00DBA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA5u))return;
  // 7 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA5 LDA
    cpu.setA(0x1u, 8);
    goto L_00DBA7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA5 LDA
    cpu.setA(0x8D01u, 16);
    goto L_00DBA8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA5 LDA
    cpu.setA(0x1u, 8);
    goto L_00DBA7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA5 LDA
    cpu.setA(0x1u, 8);
    goto L_00DBA7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA5 LDA
    cpu.setA(0x1u, 8);
    goto L_00DBA7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBA5u,0x00DBA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA7u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA7u, 4u, 3u, cpu.address("abs", 0x1DFAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA7 STA
    hw.write(cpu.address("abs", 0x1DFAu), cpu.a, cpu.m8?8:16);
    goto L_00DBAA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA7u, 4u, 3u, cpu.address("abs", 0x1DFAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA7 STA
    hw.write(cpu.address("abs", 0x1DFAu), cpu.a, cpu.m8?8:16);
    goto L_00DBAA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA7u, 4u, 3u, cpu.address("abs", 0x1DFAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA7 STA
    hw.write(cpu.address("abs", 0x1DFAu), cpu.a, cpu.m8?8:16);
    goto L_00DBAA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA7u, 4u, 3u, cpu.address("abs", 0x1DFAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA7 STA
    hw.write(cpu.address("abs", 0x1DFAu), cpu.a, cpu.m8?8:16);
    goto L_00DBAA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBA7u,0x00DBA7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA8u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00DBA8 PLX
    cpu.pop("PLX", hw);
    goto L_00DBA9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBA8u,0x00DBA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA9u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA9u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA9u, 5u + ((((0x5480u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x5480u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBA9 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x5480u), cpu.m8?8:16));
    goto L_00DBAC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBA9u,0x00DBA9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBAAu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBAA BRA -> $00DC00
    hw.requestDispatch(0x00DC00u,0x00DBAAu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBAA BRA -> $00DC00
    hw.requestDispatch(0x00DC00u,0x00DBAAu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBAA BRA -> $00DC00
    hw.requestDispatch(0x00DC00u,0x00DBAAu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBAA BRA -> $00DC00
    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao
    hw.requestDispatch(0x00DC00u,0x00DBAAu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBAAu,0x00DBAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBACu))return;
  // 7 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBACu,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBAC BVC -> $00DBCA
    if (!cpu.v) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DBCAu,0x00DBACu); return; }
    goto L_00DBAE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBACu,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBAC BVC -> $00DBCA
    if (!cpu.v) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DBCAu,0x00DBACu); return; }
    goto L_00DBAE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBACu,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBAC BVC -> $00DBCA
    if (!cpu.v) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DBCAu,0x00DBACu); return; }
    goto L_00DBAE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBACu,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBAC BVC -> $00DBCA
    if (!cpu.v) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DBCAu,0x00DBACu); return; }
    goto L_00DBAE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBACu,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBAC BVC -> $00DBCA
    if (!cpu.v) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DBCAu,0x00DBACu); return; }
    goto L_00DBAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBACu,0x00DBACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBAEu))return;
  // 7 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBB0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBB0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBB0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBB0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBAEu,0x00DBAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB0u))return;
  // 7 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB0 BPL -> $00DBCA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DBCAu,0x00DBB0u); return; }
    goto L_00DBB2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB0 BPL -> $00DBCA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DBCAu,0x00DBB0u); return; }
    goto L_00DBB2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB0 BPL -> $00DBCA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DBCAu,0x00DBB0u); return; }
    goto L_00DBB2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB0 BPL -> $00DBCA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DBCAu,0x00DBB0u); return; }
    goto L_00DBB2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB0 BPL -> $00DBCA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DBCAu,0x00DBB0u); return; }
    goto L_00DBB2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBB0u,0x00DBB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB2u))return;
  // 7 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB2 LDA
    cpu.setA(0x1u, 8);
    goto L_00DBB4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB2 LDA
    cpu.setA(0x8D01u, 16);
    goto L_00DBB5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB2 LDA
    cpu.setA(0x1u, 8);
    goto L_00DBB4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB2 LDA
    cpu.setA(0x1u, 8);
    goto L_00DBB4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB2 LDA
    cpu.setA(0x1u, 8);
    goto L_00DBB4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBB2u,0x00DBB2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB4u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB4u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB4 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_00DBB7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB4u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB4 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_00DBB7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB4u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB4 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_00DBB7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB4u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB4 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_00DBB7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBB4u,0x00DBB4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB5u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB5u, 5u + ((((0x8E1Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8E1Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB5 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x8E1Du), cpu.m8?8:16));
    goto L_00DBB8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBB5u,0x00DBB5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB7u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB7u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB7u, 4u, 3u, cpu.address("abs", 0x13F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB7 STX
    hw.write(cpu.address("abs", 0x13F0u), cpu.x, cpu.x8?8:16);
    goto L_00DBBA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB7u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB7u, 5u, 3u, cpu.address("abs", 0x13F0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB7 STX
    hw.write(cpu.address("abs", 0x13F0u), cpu.x, cpu.x8?8:16);
    goto L_00DBBA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB7u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB7u, 4u, 3u, cpu.address("abs", 0x13F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB7 STX
    hw.write(cpu.address("abs", 0x13F0u), cpu.x, cpu.x8?8:16);
    goto L_00DBBA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB7u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB7u, 4u, 3u, cpu.address("abs", 0x13F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB7 STX
    hw.write(cpu.address("abs", 0x13F0u), cpu.x, cpu.x8?8:16);
    goto L_00DBBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBB7u,0x00DBB7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBB8 BEQ -> $00DBCD
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DBCDu,0x00DBB8u); return; }
    goto L_00DBBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBB8u,0x00DBB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBBAu))return;
  // 7 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBBA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBBCu,0x00DBBAu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBBA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBBCu,0x00DBBAu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBBA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBBCu,0x00DBBAu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBBA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBBCu,0x00DBBAu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBBA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBBCu,0x00DBBAu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBBAu,0x00DBBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00E92B_E1M1X1CQ_part5(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EA96u: goto L_00EA96;
    case 0x00EA98u: goto L_00EA98;
    case 0x00EA9Bu: goto L_00EA9B;
    case 0x00EA9Du: goto L_00EA9D;
    case 0x00EA9Fu: goto L_00EA9F;
    case 0x00EAA1u: goto L_00EAA1;
    case 0x00EAA3u: goto L_00EAA3;
    case 0x00EAA5u: goto L_00EAA5;
    case 0x00FD08u: goto L_00FD08;
    case 0x00FD0Au: goto L_00FD0A;
    case 0x00FD0Bu: goto L_00FD0B;
    case 0x00FD0Cu: goto L_00FD0C;
    case 0x00FD0Du: goto L_00FD0D;
    case 0x00FD0Eu: goto L_00FD0E;
    case 0x00FD0Fu: goto L_00FD0F;
    case 0x00FD10u: goto L_00FD10;
    case 0x00FD11u: goto L_00FD11;
    case 0x00FD12u: goto L_00FD12;
    case 0x00FD13u: goto L_00FD13;
    case 0x00FD15u: goto L_00FD15;
    case 0x00FD17u: goto L_00FD17;
    case 0x00FD19u: goto L_00FD19;
    case 0x00FD1Bu: goto L_00FD1B;
    case 0x00FD1Cu: goto L_00FD1C;
    case 0x00FD1Du: goto L_00FD1D;
    case 0x00FD1Eu: goto L_00FD1E;
    case 0x00FD1Fu: goto L_00FD1F;
    case 0x00FD20u: goto L_00FD20;
    case 0x00FD21u: goto L_00FD21;
    case 0x00FD23u: goto L_00FD23;
    case 0x00FD26u: goto L_00FD26;
    case 0x00FD28u: goto L_00FD28;
    case 0x00FD2Bu: goto L_00FD2B;
    case 0x00FD2Du: goto L_00FD2D;
    case 0x00FD2Fu: goto L_00FD2F;
    case 0x00FD30u: goto L_00FD30;
    case 0x00FD33u: goto L_00FD33;
    case 0x00FD36u: goto L_00FD36;
    case 0x00FD38u: goto L_00FD38;
    case 0x00FD3Au: goto L_00FD3A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EA96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA96u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA96u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA96 BNE -> $00EA62
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA62u,0x00EA96u); return; }
    goto L_00EA98;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA96u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA96 BNE -> $00EA62
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA62u,0x00EA96u); return; }
    goto L_00EA98;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA96u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA96 BNE -> $00EA62
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA62u,0x00EA96u); return; }
    goto L_00EA98;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA96u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA96 BNE -> $00EA62
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EA62u,0x00EA96u); return; }
    goto L_00EA98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA96u,0x00EA96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA98u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA98u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA98u, 6u, 3u, cpu.address("abs", 0xFDA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA98 JSR -> $00FDA5 stack real
    { cpu.push16Value(hw,0xEA9Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA9Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA5u), 0x00EA98u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA9B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA98u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA98u, 6u, 3u, cpu.address("abs", 0xFDA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA98 JSR -> $00FDA5 stack real
    { cpu.push16Value(hw,0xEA9Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA9Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA5u), 0x00EA98u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA9B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA98u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA98u, 6u, 3u, cpu.address("abs", 0xFDA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA98 JSR -> $00FDA5 stack real
    { cpu.push16Value(hw,0xEA9Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA9Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA5u), 0x00EA98u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA9B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA98u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA98u, 6u, 3u, cpu.address("abs", 0xFDA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA98 JSR -> $00FDA5 stack real
    { cpu.push16Value(hw,0xEA9Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA9Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA5u), 0x00EA98u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA9B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA98u,0x00EA98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA9Bu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA9B LDA
    cpu.setA(0xBu, 8);
    goto L_00EA9D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA9B LDA
    cpu.setA(0xBu, 8);
    goto L_00EA9D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA9B LDA
    cpu.setA(0xBu, 8);
    goto L_00EA9D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA9B LDA
    cpu.setA(0xBu, 8);
    goto L_00EA9D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA9Bu,0x00EA9Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA9Du))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA9D STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00EA9F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA9D STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00EA9F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA9D STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00EA9F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA9D STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00EA9F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA9Du,0x00EA9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA9Fu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA9F LDA
    cpu.setA(0xAAu, 8);
    goto L_00EAA1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA9F LDA
    cpu.setA(0xAAu, 8);
    goto L_00EAA1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA9F LDA
    cpu.setA(0xAAu, 8);
    goto L_00EAA1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA9F LDA
    cpu.setA(0xAAu, 8);
    goto L_00EAA1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA9Fu,0x00EA9Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA1u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAA1 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EAA3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAA1 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EAA3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAA1 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EAA3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAA1 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EAA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEAA1u,0x00EAA1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EAA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA3u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAA3 STZ
    hw.write(cpu.address("dp", 0x75u), 0, cpu.m8?8:16);
    goto L_00EAA5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAA3 STZ
    hw.write(cpu.address("dp", 0x75u), 0, cpu.m8?8:16);
    goto L_00EAA5;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAA3 STZ
    hw.write(cpu.address("dp", 0x75u), 0, cpu.m8?8:16);
    goto L_00EAA5;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAA3 STZ
    hw.write(cpu.address("dp", 0x75u), 0, cpu.m8?8:16);
    goto L_00EAA5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEAA3u,0x00EAA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA5u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EAA5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EAA5u);return;} hw.unresolvedReturn(0x00EAA5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EAA5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EAA5u);return;} hw.unresolvedReturn(0x00EAA5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EAA5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EAA5u);return;} hw.unresolvedReturn(0x00EAA5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EAA5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EAA5u);return;} hw.unresolvedReturn(0x00EAA5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEAA5u,0x00EAA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD08u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD08u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD08u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD08 LDY
    cpu.setY(0xA53Fu, 16);
    goto L_00FD0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD08u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD08 LDY
    cpu.setY(0x3Fu, 8);
    goto L_00FD0A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD08u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD08u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD08 LDY
    cpu.setY(0xA53Fu, 16);
    goto L_00FD0B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD08u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD08 LDY
    cpu.setY(0x3Fu, 8);
    goto L_00FD0A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD08u,0x00FD08u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD0Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD0A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD0C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD0A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD0C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD0Au,0x00FD0Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD0Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Bu,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD0B ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0x29u), cpu.m8?8:16));
    goto L_00FD0D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Bu,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD0B ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0x29u), cpu.m8?8:16));
    goto L_00FD0D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD0Bu,0x00FD0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD0Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD0C AND
    cpu.logicAnd(0x83u);
    goto L_00FD0E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD0C AND
    cpu.logicAnd(0x83u);
    goto L_00FD0E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD0Cu,0x00FD0Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD0Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Du,cpu,0x83u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Du, 4u, 2u, cpu.addressStack(0xD0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD0D STA
    hw.write(cpu.addressStack(0xD0u), cpu.a, cpu.m8?8:16);
    goto L_00FD0F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Du,cpu,0x83u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Du, 4u, 2u, cpu.addressStack(0xD0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD0D STA
    hw.write(cpu.addressStack(0xD0u), cpu.a, cpu.m8?8:16);
    goto L_00FD0F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD0Du,0x00FD0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD0Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD0E BNE -> $00FD12
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FD12; }
    goto L_00FD10;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD0E BNE -> $00FD12
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FD12; }
    goto L_00FD10;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD0Eu,0x00FD0Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD0Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Fu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Fu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xFD11u,true);
    hw.requestDispatch(0x0082C3u,0x00FD0Fu);return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Fu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Fu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xFD11u,true);
    hw.requestDispatch(0x0082C3u,0x00FD0Fu);return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD0Fu,0x00FD0Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD10u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD10u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD10 LDY
    cpu.setY(0x7Fu, 8);
    goto L_00FD12;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD10u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD10 LDY
    cpu.setY(0x7Fu, 8);
    goto L_00FD12;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD10u,0x00FD10u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD11u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD11u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD11u, 5u, 4u, ((0x142598u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD11 ADC
    cpu.adc(hw.readW(((0x142598u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD15;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD11u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD11u, 5u, 4u, ((0x142598u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD11 ADC
    cpu.adc(hw.readW(((0x142598u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD15;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD11u,0x00FD11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD12u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD12u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD12 TYA
    cpu.transfer("TYA");
    goto L_00FD13;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD12u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD12 TYA
    cpu.transfer("TYA");
    goto L_00FD13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD12u,0x00FD12u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD13u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD13u,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD13u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD13 AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16));
    goto L_00FD15;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD13u,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD13u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD13 AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16));
    goto L_00FD15;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD13u,0x00FD13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD15u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD15u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD15 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16));
    goto L_00FD17;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD15u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD15 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16));
    goto L_00FD17;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD15u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD15 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16));
    goto L_00FD17;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD15u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD15 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16));
    goto L_00FD17;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD15u,0x00FD15u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD17u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD17u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD17 BNE -> $00FD23
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FD23; }
    goto L_00FD19;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD17u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD17 BNE -> $00FD23
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FD23; }
    goto L_00FD19;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD17u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD17 BNE -> $00FD23
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FD23; }
    goto L_00FD19;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD17u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD17 BNE -> $00FD23
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FD23; }
    goto L_00FD19;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD17u,0x00FD17u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD19u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD19u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD19 LDX
    cpu.setX(0xBD07u, 16);
    goto L_00FD1C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD19u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD19 LDX
    cpu.setX(0x7u, 8);
    goto L_00FD1B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD19u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD19 LDX
    cpu.setX(0xBD07u, 16);
    goto L_00FD1C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD19u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD19 LDX
    cpu.setX(0x7u, 8);
    goto L_00FD1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD19u,0x00FD19u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD1Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Bu, 4u + 1u, 3u, cpu.address("absx", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD1B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x170Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD1E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Bu, 4u + ((((0x170Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD1B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x170Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD1E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Bu, 4u + 1u, 3u, cpu.address("absx", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD1B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x170Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD1E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Bu, 4u + ((((0x170Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD1B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x170Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD1E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD1Bu,0x00FD1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD1Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Cu,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00FD1C PHD
    cpu.push("PHD", hw);
    goto L_00FD1D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Cu,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00FD1C PHD
    cpu.push("PHD", hw);
    goto L_00FD1D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD1Cu,0x00FD1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD1Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Du,cpu,0x17u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xF0u) & 0xFFFFu), 3u, 0u);
    // $00FD1D ORA
    cpu.logicOr(hw.readW(cpu.addressDpLongY(hw, 0xF0u), cpu.m8?8:16));
    goto L_00FD1F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Du,cpu,0x17u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xF0u) & 0xFFFFu), 3u, 0u);
    // $00FD1D ORA
    cpu.logicOr(hw.readW(cpu.addressDpLongY(hw, 0xF0u), cpu.m8?8:16));
    goto L_00FD1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD1Du,0x00FD1Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD1Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD1E BEQ -> $00FD26
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FD26; }
    goto L_00FD20;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD1E BEQ -> $00FD26
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FD26; }
    goto L_00FD20;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD1E BEQ -> $00FD26
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FD26; }
    goto L_00FD20;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD1E BEQ -> $00FD26
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FD26; }
    goto L_00FD20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD1Eu,0x00FD1Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD1Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Fu,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD1F ASL
    cpu.aslMem(hw, cpu.address("dp", 0xCAu), cpu.m8?8:16);
    goto L_00FD21;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Fu,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD1F ASL
    cpu.aslMem(hw, cpu.address("dp", 0xCAu), cpu.m8?8:16);
    goto L_00FD21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD1Fu,0x00FD1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD20u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD20u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD20 DEX
    cpu.decReg('X');
    goto L_00FD21;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD20u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD20 DEX
    cpu.decReg('X');
    goto L_00FD21;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD20u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD20 DEX
    cpu.decReg('X');
    goto L_00FD21;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD20u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD20 DEX
    cpu.decReg('X');
    goto L_00FD21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD20u,0x00FD20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD21u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD21 BPL -> $00FD1B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00FD1B; }
    goto L_00FD23;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD21 BPL -> $00FD1B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00FD1B; }
    goto L_00FD23;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD21 BPL -> $00FD1B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00FD1B; }
    goto L_00FD23;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD21 BPL -> $00FD1B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00FD1B; }
    goto L_00FD23;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD21u,0x00FD21u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD23u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD23u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD23u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00FD23 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00FD23u);return;} hw.unresolvedReturn(0x00FD23u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD23u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD23u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00FD23 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00FD23u);return;} hw.unresolvedReturn(0x00FD23u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD23u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD23u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00FD23 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00FD23u);return;} hw.unresolvedReturn(0x00FD23u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD23u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD23u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00FD23 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00FD23u);return;} hw.unresolvedReturn(0x00FD23u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD23u,0x00FD23u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD26u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD26 LDA
    cpu.setA(0x12u, 8);
    goto L_00FD28;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD26 LDA
    cpu.setA(0x12u, 8);
    goto L_00FD28;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD26 LDA
    cpu.setA(0x12u, 8);
    goto L_00FD28;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD26 LDA
    cpu.setA(0x12u, 8);
    goto L_00FD28;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD26u,0x00FD26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD28u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD28u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD28u, 5u, 3u, cpu.address("absx", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD28 STA
    hw.write(cpu.address("absx", 0x170Bu), cpu.a, cpu.m8?8:16);
    goto L_00FD2B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD28u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD28u, 5u, 3u, cpu.address("absx", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD28 STA
    hw.write(cpu.address("absx", 0x170Bu), cpu.a, cpu.m8?8:16);
    goto L_00FD2B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD28u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD28u, 5u, 3u, cpu.address("absx", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD28 STA
    hw.write(cpu.address("absx", 0x170Bu), cpu.a, cpu.m8?8:16);
    goto L_00FD2B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD28u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD28u, 5u, 3u, cpu.address("absx", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD28 STA
    hw.write(cpu.address("absx", 0x170Bu), cpu.a, cpu.m8?8:16);
    goto L_00FD2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD28u,0x00FD28u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD2Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD2B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x76u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00FD2D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD2B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x76u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00FD2D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD2B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x76u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00FD2D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD2B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x76u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00FD2D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD2Bu,0x00FD2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD2Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD2F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD2F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD2F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD2F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD2Du,0x00FD2Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD2Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD2F CLC
    cpu.setFlag('C', false);
    goto L_00FD30;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD2F CLC
    cpu.setFlag('C', false);
    goto L_00FD30;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD2F CLC
    cpu.setFlag('C', false);
    goto L_00FD30;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD2F CLC
    cpu.setFlag('C', false);
    goto L_00FD30;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD2Fu,0x00FD2Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD30u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD30u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD30u, 4u + 1u, 3u, cpu.address("absy", 0xFD24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD30 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xFD24u), cpu.m8?8:16));
    goto L_00FD33;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD30u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD30u, 4u + ((((0xFD24u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xFD24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD30 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xFD24u), cpu.m8?8:16));
    goto L_00FD33;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD30u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD30u, 4u + 1u, 3u, cpu.address("absy", 0xFD24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD30 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xFD24u), cpu.m8?8:16));
    goto L_00FD33;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD30u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD30u, 4u + ((((0xFD24u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xFD24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD30 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xFD24u), cpu.m8?8:16));
    goto L_00FD33;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD30u,0x00FD30u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD33u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD33u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD33u, 5u, 3u, cpu.address("absx", 0x171Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD33 STA
    hw.write(cpu.address("absx", 0x171Fu), cpu.a, cpu.m8?8:16);
    goto L_00FD36;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD33u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD33u, 5u, 3u, cpu.address("absx", 0x171Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD33 STA
    hw.write(cpu.address("absx", 0x171Fu), cpu.a, cpu.m8?8:16);
    goto L_00FD36;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD33u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD33u, 5u, 3u, cpu.address("absx", 0x171Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD33 STA
    hw.write(cpu.address("absx", 0x171Fu), cpu.a, cpu.m8?8:16);
    goto L_00FD36;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD33u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD33u, 5u, 3u, cpu.address("absx", 0x171Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD33 STA
    hw.write(cpu.address("absx", 0x171Fu), cpu.a, cpu.m8?8:16);
    goto L_00FD36;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD33u,0x00FD33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD36u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD36u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD36u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD36 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD38;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD36u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD36u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD36 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD38;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD36u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD36u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD36 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD38;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD36u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD36u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD36 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD38;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD36u,0x00FD36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD38u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD38u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD38 ADC
    cpu.adc(0x0u);
    goto L_00FD3A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD38u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD38 ADC
    cpu.adc(0x0u);
    goto L_00FD3A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD38u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD38 ADC
    cpu.adc(0x0u);
    goto L_00FD3A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD38u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD38 ADC
    cpu.adc(0x0u);
    goto L_00FD3A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD38u,0x00FD38u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00FD3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD3Au))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Au, 5u, 3u, cpu.address("absx", 0x1733u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD3A STA
    hw.write(cpu.address("absx", 0x1733u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD3Du,0x00FD3Au); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Au, 5u, 3u, cpu.address("absx", 0x1733u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD3A STA
    hw.write(cpu.address("absx", 0x1733u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD3Du,0x00FD3Au); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Au, 5u, 3u, cpu.address("absx", 0x1733u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD3A STA
    hw.write(cpu.address("absx", 0x1733u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD3Du,0x00FD3Au); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Au, 5u, 3u, cpu.address("absx", 0x1733u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD3A STA
    hw.write(cpu.address("absx", 0x1733u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD3Du,0x00FD3Au); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD3Au,0x00FD3Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EC21_E0M1X1CQ_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EED7u: goto L_00EED7;
    case 0x00EED9u: goto L_00EED9;
    case 0x00EEDBu: goto L_00EEDB;
    case 0x00EEDDu: goto L_00EEDD;
    case 0x00EEDFu: goto L_00EEDF;
    case 0x00EEE1u: goto L_00EEE1;
    case 0x00EEE4u: goto L_00EEE4;
    case 0x00EEE6u: goto L_00EEE6;
    case 0x00EEE9u: goto L_00EEE9;
    case 0x00EEEBu: goto L_00EEEB;
    case 0x00EEEDu: goto L_00EEED;
    case 0x00EEEFu: goto L_00EEEF;
    case 0x00EEF2u: goto L_00EEF2;
    case 0x00EEF4u: goto L_00EEF4;
    case 0x00EEF6u: goto L_00EEF6;
    case 0x00EEF7u: goto L_00EEF7;
    case 0x00EEF8u: goto L_00EEF8;
    case 0x00EEFAu: goto L_00EEFA;
    case 0x00EEFBu: goto L_00EEFB;
    case 0x00EEFCu: goto L_00EEFC;
    case 0x00EEFEu: goto L_00EEFE;
    case 0x00EEFFu: goto L_00EEFF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED7u))return;
  // 8 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED7u,0x00EED7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED9u))return;
  // 8 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED9u,0x00EED9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEDBu))return;
  // 8 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEDD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEDD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEDD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDBu,0x00EEDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEDDu))return;
  // 8 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16));
    goto L_00EEDF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16));
    goto L_00EEDF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16));
    goto L_00EEDF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16));
    goto L_00EEDF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEDFu))return;
  // 8 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDF STA
    hw.write(cpu.address("dp", 0x97u), cpu.a, cpu.m8?8:16);
    goto L_00EEE1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDF STA
    hw.write(cpu.address("dp", 0x97u), cpu.a, cpu.m8?8:16);
    goto L_00EEE1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDF STA
    hw.write(cpu.address("dp", 0x97u), cpu.a, cpu.m8?8:16);
    goto L_00EEE1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDF STA
    hw.write(cpu.address("dp", 0x97u), cpu.a, cpu.m8?8:16);
    goto L_00EEE1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDFu,0x00EEDFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE1u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u, 5u + 1u, 3u, cpu.address("absy", 0xE53Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEE4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u, 5u + ((((0xE53Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE53Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEE4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u, 4u + 1u, 3u, cpu.address("absy", 0xE53Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEE4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u, 4u + ((((0xE53Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE53Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEE4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE1u,0x00EEE1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE4u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE4 BNE -> $00EEEF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EEEF; }
    goto L_00EEE6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE4 BNE -> $00EEEF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EEEF; }
    goto L_00EEE6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE4 BNE -> $00EEEF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EEEF; }
    goto L_00EEE6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE4 BNE -> $00EEEF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EEEF; }
    goto L_00EEE6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE4u,0x00EEE4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE6u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u, 5u, 3u, cpu.address("abs", 0x13EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE6 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13EDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEE9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE6 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13EDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEE9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u, 5u, 3u, cpu.address("abs", 0x13EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE6 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13EDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEE9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE6 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13EDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEE9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE6u,0x00EEE6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE9u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEE9u); return; }
    goto L_00EEEB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEE9u); return; }
    goto L_00EEEB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEE9u); return; }
    goto L_00EEEB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEE9u); return; }
    goto L_00EEEB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE9u,0x00EEE9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEBu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEBu,0x00EEEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEDu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF02u,0x00EEEDu); return; }
    goto L_00EEEF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEDu,0x00EEEDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEFu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 5u, 3u, cpu.address("abs", 0x13EEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 5u, 3u, cpu.address("abs", 0x13EEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEFu,0x00EEEFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF2u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEF4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEF4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEF4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEF4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF2u,0x00EEF2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF4u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF4 AND
    cpu.logicAnd(0xF004u);
    goto L_00EEF7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF4 AND
    cpu.logicAnd(0xF004u);
    goto L_00EEF7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF4 AND
    cpu.logicAnd(0x4u);
    goto L_00EEF6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF4 AND
    cpu.logicAnd(0x4u);
    goto L_00EEF6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF4u,0x00EEF4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF6u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF6 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEF6u); return; }
    goto L_00EEF8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF6 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEF6u); return; }
    goto L_00EEF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF6u,0x00EEF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF7u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF7u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF7u, 5u, 3u, cpu.address("abs", 0x8FADu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF7 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x8FADu), cpu.m8?8:16));
    goto L_00EEFA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF7u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF7u, 5u, 3u, cpu.address("abs", 0x8FADu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF7 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x8FADu), cpu.m8?8:16));
    goto L_00EEFA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF7u,0x00EEF7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF8u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF8u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEFB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF8u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEFB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF8u,0x00EEF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFAu))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFAu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEFA TRB
    cpu.trb(hw, cpu.address("dp", 0xDu), cpu.m8?8:16);
    goto L_00EEFC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFAu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEFA TRB
    cpu.trb(hw, cpu.address("dp", 0xDu), cpu.m8?8:16);
    goto L_00EEFC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEFAu,0x00EEFAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFBu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFBu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFBu, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEFB ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13EDu), cpu.m8?8:16));
    goto L_00EEFE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFBu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFBu, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEFB ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13EDu), cpu.m8?8:16));
    goto L_00EEFE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEFBu,0x00EEFBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFCu))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFCu,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFCu, 5u, 3u, cpu.address("abs", 0xD013u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEFC SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0xD013u), cpu.m8?8:16));
    goto L_00EEFF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFCu,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFCu, 5u, 3u, cpu.address("abs", 0xD013u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEFC SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0xD013u), cpu.m8?8:16));
    goto L_00EEFF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEFCu,0x00EEFCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFEu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEFE BNE -> $00EF05
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEFEu); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF00u,0x00EEFEu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEFE BNE -> $00EF05
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF05u,0x00EEFEu); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF00u,0x00EEFEu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEFEu,0x00EEFEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFFu))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFFu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEFF ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xA2u), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF01u,0x00EEFFu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFFu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEFF ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xA2u), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF01u,0x00EEFFu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEFFu,0x00EEFFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E1M1X1CQ_part29(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF75u: goto L_00EF75;
    case 0x00EF77u: goto L_00EF77;
    case 0x00EF78u: goto L_00EF78;
    case 0x00EF79u: goto L_00EF79;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF75u))return;
  // 57 variantes de decodificacao M/X para este endereco; 8 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF75 LDA
    cpu.setA(0x404u, 16);
    goto L_00EF78;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF75 LDA
    cpu.setA(0x404u, 16);
    goto L_00EF78;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF75 LDA
    cpu.setA(0x4u, 8);
    goto L_00EF77;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF75 LDA
    cpu.setA(0x4u, 8);
    goto L_00EF77;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF75 LDA
    cpu.setA(0x404u, 16);
    goto L_00EF78;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF75 LDA
    cpu.setA(0x404u, 16);
    goto L_00EF78;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF75 LDA
    cpu.setA(0x4u, 8);
    goto L_00EF77;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF75 LDA
    cpu.setA(0x4u, 8);
    goto L_00EF77;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF75u,0x00EF75u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF77u))return;
  // 37 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF77u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF77u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF77 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00EF79;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF77u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF77u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF77 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00EF79;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF77u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF77u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF77 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00EF79;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF77u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF77u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF77 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00EF79;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF77u,0x00EF77u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF78u))return;
  // 20 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF78u,cpu,0x77u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF78u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xACu) & 0xFFFFu), 3u, 0u);
    // $00EF78 ADC
    cpu.adc(hw.readW(cpu.addressDpLongY(hw, 0xACu), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF7Au,0x00EF78u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF78u,cpu,0x77u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF78u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xACu) & 0xFFFFu), 3u, 0u);
    // $00EF78 ADC
    cpu.adc(hw.readW(cpu.addressDpLongY(hw, 0xACu), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF7Au,0x00EF78u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF78u,cpu,0x77u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF78u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xACu) & 0xFFFFu), 3u, 0u);
    // $00EF78 ADC
    cpu.adc(hw.readW(cpu.addressDpLongY(hw, 0xACu), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF7Au,0x00EF78u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF78u,cpu,0x77u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF78u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xACu) & 0xFFFFu), 3u, 0u);
    // $00EF78 ADC
    cpu.adc(hw.readW(cpu.addressDpLongY(hw, 0xACu), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF7Au,0x00EF78u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF78u,0x00EF78u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF79u))return;
  // 37 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF79u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF79u, 5u, 3u, cpu.address("abs", 0x1407u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF79 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1407u), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,0x00EF79u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF79u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF79u, 4u, 3u, cpu.address("abs", 0x1407u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF79 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1407u), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,0x00EF79u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF79u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF79u, 5u, 3u, cpu.address("abs", 0x1407u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF79 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1407u), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,0x00EF79u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF79u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF79u, 4u, 3u, cpu.address("abs", 0x1407u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF79 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1407u), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,0x00EF79u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF79u,0x00EF79u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_0180D2_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0180D2u: goto L_0180D2;
    case 0x0180D3u: goto L_0180D3;
    case 0x0180D4u: goto L_0180D4;
    case 0x0180D7u: goto L_0180D7;
    case 0x0180D8u: goto L_0180D8;
    case 0x0180DCu: goto L_0180DC;
    case 0x0180DDu: goto L_0180DD;
    case 0x0180E1u: goto L_0180E1;
    case 0x0180E2u: goto L_0180E2;
    case 0x0180E5u: goto L_0180E5;
    case 0x0180E8u: goto L_0180E8;
    case 0x0180EAu: goto L_0180EA;
    case 0x0180ECu: goto L_0180EC;
    case 0x0180EEu: goto L_0180EE;
    case 0x0180F1u: goto L_0180F1;
    case 0x0180F3u: goto L_0180F3;
    case 0x0180F6u: goto L_0180F6;
    case 0x0180F9u: goto L_0180F9;
    case 0x0180FBu: goto L_0180FB;
    case 0x0180FEu: goto L_0180FE;
    case 0x018101u: goto L_018101;
    case 0x018103u: goto L_018103;
    case 0x018106u: goto L_018106;
    case 0x018109u: goto L_018109;
    case 0x01810Bu: goto L_01810B;
    case 0x01810Eu: goto L_01810E;
    case 0x018111u: goto L_018111;
    case 0x018113u: goto L_018113;
    case 0x018116u: goto L_018116;
    case 0x018119u: goto L_018119;
    case 0x01811Bu: goto L_01811B;
    case 0x01811Eu: goto L_01811E;
    case 0x018121u: goto L_018121;
    case 0x018123u: goto L_018123;
    case 0x018126u: goto L_018126;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0180D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0180D2 PHX
    cpu.push("PHX", hw);
    goto L_0180D3;
L_0180D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180D3 TXA
    cpu.transfer("TXA");
    goto L_0180D4;
L_0180D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D4u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D4u, 4u, 3u, cpu.address("abs", 0x1692u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180D4 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1692u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0180D7;
L_0180D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180D7 CLC
    cpu.setFlag('C', false);
    goto L_0180D8;
L_0180D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u, 5u, 4u, ((0x07F0B4u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180D8 ADC
    cpu.adc(hw.readW(((0x7F0B4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0180DC;
L_0180DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180DC TAX
    cpu.transfer("TAX");
    goto L_0180DD;
L_0180DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu, 5u, 4u, ((0x07F000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180DD LDA
    cpu.loadA(hw.readW(((0x7F000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180E1;
L_0180E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0180E1 PLX
    cpu.pop("PLX", hw);
    goto L_0180E2;
L_0180E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u, 5u, 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180E2 STA
    hw.write(cpu.address("absx", 0x15EAu), cpu.a, cpu.m8?8:16);
    goto L_0180E5;
L_0180E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180E5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180E8;
L_0180E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180E8 BEQ -> $018126
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018126; }
    goto L_0180EA;
L_0180EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180EA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180EC;
L_0180EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180EC BNE -> $018126
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_018126; }
    goto L_0180EE;
L_0180EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EEu, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180EE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180F1;
L_0180F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180F1 BEQ -> $0180F6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0180F6; }
    goto L_0180F3;
L_0180F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u, 7u, 3u, cpu.address("absx", 0x1540u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180F3 DEC
    cpu.decMem(hw, cpu.address("absx", 0x1540u), cpu.m8?8:16);
    goto L_0180F6;
L_0180F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u, 4u + ((((0x154Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180F6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x154Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180F9;
L_0180F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180F9 BEQ -> $0180FE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0180FE; }
    goto L_0180FB;
L_0180FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu, 7u, 3u, cpu.address("absx", 0x154Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180FB DEC
    cpu.decMem(hw, cpu.address("absx", 0x154Cu), cpu.m8?8:16);
    goto L_0180FE;
L_0180FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180FE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018101;
L_018101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018101 BEQ -> $018106
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018106; }
    goto L_018103;
L_018103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u, 7u, 3u, cpu.address("absx", 0x1558u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018103 DEC
    cpu.decMem(hw, cpu.address("absx", 0x1558u), cpu.m8?8:16);
    goto L_018106;
L_018106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8106u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8106u, 4u + ((((0x1564u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018106 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1564u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018109;
L_018109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018109 BEQ -> $01810E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01810E; }
    goto L_01810B;
L_01810B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu, 7u, 3u, cpu.address("absx", 0x1564u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01810B DEC
    cpu.decMem(hw, cpu.address("absx", 0x1564u), cpu.m8?8:16);
    goto L_01810E;
L_01810E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu, 4u + ((((0x1FE2u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1FE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01810E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1FE2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018111;
L_018111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018111 BEQ -> $018116
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018116; }
    goto L_018113;
L_018113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8113u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8113u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8113u, 7u, 3u, cpu.address("absx", 0x1FE2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018113 DEC
    cpu.decMem(hw, cpu.address("absx", 0x1FE2u), cpu.m8?8:16);
    goto L_018116;
L_018116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8116u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8116u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018116 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018119;
L_018119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018119 BEQ -> $01811E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01811E; }
    goto L_01811B;
L_01811B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Bu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Bu, 7u, 3u, cpu.address("absx", 0x15ACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01811B DEC
    cpu.decMem(hw, cpu.address("absx", 0x15ACu), cpu.m8?8:16);
    goto L_01811E;
L_01811E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu, 4u + ((((0x163Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01811E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x163Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018121;
L_018121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8121u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8121u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018121 BEQ -> $018126
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018126; }
    goto L_018123;
L_018123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u, 7u, 3u, cpu.address("absx", 0x163Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018123 DEC
    cpu.decMem(hw, cpu.address("absx", 0x163Eu), cpu.m8?8:16);
    goto L_018126;
L_018126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8126u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8126u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018126 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018126u);return;} hw.unresolvedReturn(0x018126u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0180D2_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0180D2u: goto L_0180D2;
    case 0x0180D3u: goto L_0180D3;
    case 0x0180D4u: goto L_0180D4;
    case 0x0180D7u: goto L_0180D7;
    case 0x0180D8u: goto L_0180D8;
    case 0x0180DCu: goto L_0180DC;
    case 0x0180DDu: goto L_0180DD;
    case 0x0180E1u: goto L_0180E1;
    case 0x0180E2u: goto L_0180E2;
    case 0x0180E5u: goto L_0180E5;
    case 0x0180E8u: goto L_0180E8;
    case 0x0180EAu: goto L_0180EA;
    case 0x0180ECu: goto L_0180EC;
    case 0x0180EEu: goto L_0180EE;
    case 0x0180F1u: goto L_0180F1;
    case 0x0180F3u: goto L_0180F3;
    case 0x0180F6u: goto L_0180F6;
    case 0x0180F9u: goto L_0180F9;
    case 0x0180FBu: goto L_0180FB;
    case 0x0180FEu: goto L_0180FE;
    case 0x018101u: goto L_018101;
    case 0x018103u: goto L_018103;
    case 0x018106u: goto L_018106;
    case 0x018109u: goto L_018109;
    case 0x01810Bu: goto L_01810B;
    case 0x01810Eu: goto L_01810E;
    case 0x018111u: goto L_018111;
    case 0x018113u: goto L_018113;
    case 0x018116u: goto L_018116;
    case 0x018119u: goto L_018119;
    case 0x01811Bu: goto L_01811B;
    case 0x01811Eu: goto L_01811E;
    case 0x018121u: goto L_018121;
    case 0x018123u: goto L_018123;
    case 0x018126u: goto L_018126;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0180D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0180D2 PHX
    cpu.push("PHX", hw);
    goto L_0180D3;
L_0180D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180D3 TXA
    cpu.transfer("TXA");
    goto L_0180D4;
L_0180D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D4u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D4u, 4u, 3u, cpu.address("abs", 0x1692u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180D4 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1692u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0180D7;
L_0180D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180D7 CLC
    cpu.setFlag('C', false);
    goto L_0180D8;
L_0180D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u, 5u, 4u, ((0x07F0B4u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180D8 ADC
    cpu.adc(hw.readW(((0x7F0B4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0180DC;
L_0180DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180DC TAX
    cpu.transfer("TAX");
    goto L_0180DD;
L_0180DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu, 5u, 4u, ((0x07F000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180DD LDA
    cpu.loadA(hw.readW(((0x7F000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180E1;
L_0180E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0180E1 PLX
    cpu.pop("PLX", hw);
    goto L_0180E2;
L_0180E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u, 5u, 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180E2 STA
    hw.write(cpu.address("absx", 0x15EAu), cpu.a, cpu.m8?8:16);
    goto L_0180E5;
L_0180E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180E5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180E8;
L_0180E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180E8 BEQ -> $018126
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018126; }
    goto L_0180EA;
L_0180EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180EA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180EC;
L_0180EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180EC BNE -> $018126
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_018126; }
    goto L_0180EE;
L_0180EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EEu, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180EE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180F1;
L_0180F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180F1 BEQ -> $0180F6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0180F6; }
    goto L_0180F3;
L_0180F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u, 7u, 3u, cpu.address("absx", 0x1540u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180F3 DEC
    cpu.decMem(hw, cpu.address("absx", 0x1540u), cpu.m8?8:16);
    goto L_0180F6;
L_0180F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u, 4u + ((((0x154Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180F6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x154Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180F9;
L_0180F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180F9 BEQ -> $0180FE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0180FE; }
    goto L_0180FB;
L_0180FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu, 7u, 3u, cpu.address("absx", 0x154Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180FB DEC
    cpu.decMem(hw, cpu.address("absx", 0x154Cu), cpu.m8?8:16);
    goto L_0180FE;
L_0180FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180FE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018101;
L_018101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018101 BEQ -> $018106
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018106; }
    goto L_018103;
L_018103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u, 7u, 3u, cpu.address("absx", 0x1558u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018103 DEC
    cpu.decMem(hw, cpu.address("absx", 0x1558u), cpu.m8?8:16);
    goto L_018106;
L_018106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8106u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8106u, 4u + ((((0x1564u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018106 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1564u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018109;
L_018109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018109 BEQ -> $01810E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01810E; }
    goto L_01810B;
L_01810B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu, 7u, 3u, cpu.address("absx", 0x1564u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01810B DEC
    cpu.decMem(hw, cpu.address("absx", 0x1564u), cpu.m8?8:16);
    goto L_01810E;
L_01810E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu, 4u + ((((0x1FE2u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1FE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01810E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1FE2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018111;
L_018111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018111 BEQ -> $018116
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018116; }
    goto L_018113;
L_018113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8113u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8113u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8113u, 7u, 3u, cpu.address("absx", 0x1FE2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018113 DEC
    cpu.decMem(hw, cpu.address("absx", 0x1FE2u), cpu.m8?8:16);
    goto L_018116;
L_018116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8116u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8116u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018116 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018119;
L_018119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018119 BEQ -> $01811E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01811E; }
    goto L_01811B;
L_01811B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Bu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Bu, 7u, 3u, cpu.address("absx", 0x15ACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01811B DEC
    cpu.decMem(hw, cpu.address("absx", 0x15ACu), cpu.m8?8:16);
    goto L_01811E;
L_01811E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu, 4u + ((((0x163Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01811E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x163Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018121;
L_018121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8121u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8121u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018121 BEQ -> $018126
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018126; }
    goto L_018123;
L_018123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u, 7u, 3u, cpu.address("absx", 0x163Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018123 DEC
    cpu.decMem(hw, cpu.address("absx", 0x163Eu), cpu.m8?8:16);
    goto L_018126;
L_018126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8126u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8126u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018126 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018126u);return;} hw.unresolvedReturn(0x018126u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01ABD8_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01ABD8u: goto L_01ABD8;
    case 0x01ABDAu: goto L_01ABDA;
    case 0x01ABDCu: goto L_01ABDC;
    case 0x01AC09u: goto L_01AC09;
    case 0x01AC0Cu: goto L_01AC0C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01ABD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD8u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABD8 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ABDA;
L_01ABDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABDAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABDA BEQ -> $01AC09
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AC09; }
    goto L_01ABDC;
L_01ABDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABDCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABDC ASL
    cpu.aslA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABDDu,0x01ABDCu); return;
L_01AC09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC09u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC09u, 4u, 3u, cpu.address("abs", 0x1491u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC09 STA
    hw.write(cpu.address("abs", 0x1491u), cpu.a, cpu.m8?8:16);
    goto L_01AC0C;
L_01AC0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01AC0C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01AC0Cu);return;} hw.unresolvedReturn(0x01AC0Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01ABD8_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01ABD8u: goto L_01ABD8;
    case 0x01ABDAu: goto L_01ABDA;
    case 0x01ABDCu: goto L_01ABDC;
    case 0x01AC09u: goto L_01AC09;
    case 0x01AC0Cu: goto L_01AC0C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01ABD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD8u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABD8 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ABDA;
L_01ABDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABDAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABDA BEQ -> $01AC09
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AC09; }
    goto L_01ABDC;
L_01ABDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABDCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABDC ASL
    cpu.aslA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABDDu,0x01ABDCu); return;
L_01AC09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC09u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC09u, 4u, 3u, cpu.address("abs", 0x1491u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC09 STA
    hw.write(cpu.address("abs", 0x1491u), cpu.a, cpu.m8?8:16);
    goto L_01AC0C;
L_01AC0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01AC0C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01AC0Cu);return;} hw.unresolvedReturn(0x01AC0Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01ABD8_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01ABD8u: goto L_01ABD8;
    case 0x01ABDAu: goto L_01ABDA;
    case 0x01ABDCu: goto L_01ABDC;
    case 0x01ABDDu: goto L_01ABDD;
    case 0x01ABDEu: goto L_01ABDE;
    case 0x01ABDFu: goto L_01ABDF;
    case 0x01ABE0u: goto L_01ABE0;
    case 0x01ABE1u: goto L_01ABE1;
    case 0x01ABE4u: goto L_01ABE4;
    case 0x01ABE7u: goto L_01ABE7;
    case 0x01ABE8u: goto L_01ABE8;
    case 0x01ABE9u: goto L_01ABE9;
    case 0x01ABEBu: goto L_01ABEB;
    case 0x01ABEDu: goto L_01ABED;
    case 0x01ABEEu: goto L_01ABEE;
    case 0x01ABEFu: goto L_01ABEF;
    case 0x01ABF0u: goto L_01ABF0;
    case 0x01ABF1u: goto L_01ABF1;
    case 0x01ABF3u: goto L_01ABF3;
    case 0x01ABF5u: goto L_01ABF5;
    case 0x01ABF7u: goto L_01ABF7;
    case 0x01ABF8u: goto L_01ABF8;
    case 0x01ABF9u: goto L_01ABF9;
    case 0x01ABFAu: goto L_01ABFA;
    case 0x01ABFCu: goto L_01ABFC;
    case 0x01ABFEu: goto L_01ABFE;
    case 0x01ABFFu: goto L_01ABFF;
    case 0x01AC02u: goto L_01AC02;
    case 0x01AC05u: goto L_01AC05;
    case 0x01AC06u: goto L_01AC06;
    case 0x01AC07u: goto L_01AC07;
    case 0x01AC09u: goto L_01AC09;
    case 0x01AC0Cu: goto L_01AC0C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01ABD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD8u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABD8 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ABDA;
L_01ABDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABDAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABDA BEQ -> $01AC09
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AC09; }
    goto L_01ABDC;
L_01ABDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABDCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABDC ASL
    cpu.aslA();
    goto L_01ABDD;
L_01ABDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABDDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABDDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABDD ASL
    cpu.aslA();
    goto L_01ABDE;
L_01ABDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABDEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABDE ASL
    cpu.aslA();
    goto L_01ABDF;
L_01ABDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABDFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABDFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABDF ASL
    cpu.aslA();
    goto L_01ABE0;
L_01ABE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABE0u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABE0 CLC
    cpu.setFlag('C', false);
    goto L_01ABE1;
L_01ABE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABE1u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABE1u, 4u + ((((0x14ECu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14ECu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABE1 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x14ECu), cpu.m8?8:16));
    goto L_01ABE4;
L_01ABE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABE4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABE4u, 5u, 3u, cpu.address("absx", 0x14ECu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABE4 STA
    hw.write(cpu.address("absx", 0x14ECu), cpu.a, cpu.m8?8:16);
    goto L_01ABE7;
L_01ABE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABE7u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABE7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01ABE7 PHP
    cpu.push("PHP", hw);
    goto L_01ABE8;
L_01ABE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABE8u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABE8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01ABE8 PHP
    cpu.push("PHP", hw);
    goto L_01ABE9;
L_01ABE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABE9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABE9 LDY
    cpu.setY(0x0u, 8);
    goto L_01ABEB;
L_01ABEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABEBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABEB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ABED;
L_01ABED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABEDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABEDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABED LSR
    cpu.lsrA();
    goto L_01ABEE;
L_01ABEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABEEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABEEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABEE LSR
    cpu.lsrA();
    goto L_01ABEF;
L_01ABEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABEFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABEF LSR
    cpu.lsrA();
    goto L_01ABF0;
L_01ABF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABF0 LSR
    cpu.lsrA();
    goto L_01ABF1;
L_01ABF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABF1 CMP
    cpu.compareA(0x8u);
    goto L_01ABF3;
L_01ABF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABF3 BCC -> $01ABF8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01ABF8; }
    goto L_01ABF5;
L_01ABF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF5u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABF5 ORA
    cpu.logicOr(0xF0u);
    goto L_01ABF7;
L_01ABF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF7u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABF7 DEY
    cpu.decReg('Y');
    goto L_01ABF8;
L_01ABF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF8u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01ABF8 PLP
    cpu.pop("PLP", hw);
    goto L_01ABF9;
L_01ABF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABF9u,0x01ABF9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF9u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01ABF9 PHA
    cpu.push("PHA", hw);
    goto L_01ABFA;
L_01ABFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFAu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABFA ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16));
    goto L_01ABFC;
L_01ABFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABFC STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_01ABFE;
L_01ABFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFEu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABFE TYA
    cpu.transfer("TYA");
    goto L_01ABFF;
L_01ABFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ABFF ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16));
    goto L_01AC02;
L_01AC02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC02u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC02u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC02 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_01AC05;
L_01AC05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AC05 PLA
    cpu.pop("PLA", hw);
    goto L_01AC06;
L_01AC06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC06u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC06u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AC06 PLP
    cpu.pop("PLP", hw);
    goto L_01AC07;
L_01AC07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC07u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC07u,0x01AC07u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC07u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC07 ADC
    cpu.adc(0x0u);
    goto L_01AC09;
L_01AC09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC09u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC09u, 4u, 3u, cpu.address("abs", 0x1491u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC09 STA
    hw.write(cpu.address("abs", 0x1491u), cpu.a, cpu.m8?8:16);
    goto L_01AC0C;
L_01AC0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01AC0C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01AC0Cu);return;} hw.unresolvedReturn(0x01AC0Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02E0CD_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02E0CDu: goto L_02E0CD;
    case 0x02E0D1u: goto L_02E0D1;
    case 0x02E0D3u: goto L_02E0D3;
    case 0x02E0D4u: goto L_02E0D4;
    case 0x02E0D6u: goto L_02E0D6;
    case 0x02E0D8u: goto L_02E0D8;
    case 0x02E0DBu: goto L_02E0DB;
    case 0x02E0DDu: goto L_02E0DD;
    case 0x02E0DEu: goto L_02E0DE;
    case 0x02E0DFu: goto L_02E0DF;
    case 0x02E0E1u: goto L_02E0E1;
    case 0x02E0E4u: goto L_02E0E4;
    case 0x02E0E8u: goto L_02E0E8;
    case 0x02E0EBu: goto L_02E0EB;
    case 0x02E0ECu: goto L_02E0EC;
    case 0x02E0EEu: goto L_02E0EE;
    case 0x02E0F1u: goto L_02E0F1;
    case 0x02E0F4u: goto L_02E0F4;
    case 0x02E0F6u: goto L_02E0F6;
    case 0x02E0F7u: goto L_02E0F7;
    case 0x02E0F8u: goto L_02E0F8;
    case 0x02E0F9u: goto L_02E0F9;
    case 0x02E0FCu: goto L_02E0FC;
    case 0x02E0FEu: goto L_02E0FE;
    case 0x02E0FFu: goto L_02E0FF;
    case 0x02E100u: goto L_02E100;
    case 0x02E102u: goto L_02E102;
    case 0x02E104u: goto L_02E104;
    case 0x02E107u: goto L_02E107;
    case 0x02E108u: goto L_02E108;
    case 0x02E10Au: goto L_02E10A;
    case 0x02E10Du: goto L_02E10D;
    case 0x02E10Fu: goto L_02E10F;
    case 0x02E112u: goto L_02E112;
    case 0x02E114u: goto L_02E114;
    case 0x02E118u: goto L_02E118;
    case 0x02E119u: goto L_02E119;
    case 0x02E11Cu: goto L_02E11C;
    case 0x02E11Du: goto L_02E11D;
    case 0x02E11Fu: goto L_02E11F;
    case 0x02E120u: goto L_02E120;
    case 0x02E122u: goto L_02E122;
    case 0x02E124u: goto L_02E124;
    case 0x02E126u: goto L_02E126;
    case 0x02E129u: goto L_02E129;
    case 0x02E12Du: goto L_02E12D;
    case 0x02E130u: goto L_02E130;
    case 0x02E132u: goto L_02E132;
    case 0x02E136u: goto L_02E136;
    case 0x02E139u: goto L_02E139;
    case 0x02E13Bu: goto L_02E13B;
    case 0x02E13Du: goto L_02E13D;
    case 0x02E13Eu: goto L_02E13E;
    case 0x02E141u: goto L_02E141;
    case 0x02E143u: goto L_02E143;
    case 0x02E146u: goto L_02E146;
    case 0x02E148u: goto L_02E148;
    case 0x02E149u: goto L_02E149;
    case 0x02E14Bu: goto L_02E14B;
    case 0x02E14Du: goto L_02E14D;
    case 0x02E14Fu: goto L_02E14F;
    case 0x02E151u: goto L_02E151;
    case 0x02E153u: goto L_02E153;
    case 0x02E155u: goto L_02E155;
    case 0x02E158u: goto L_02E158;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02E0CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CDu, 8u, 4u, 0x07F78Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02E0CD JSL -> $07F78B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE0D0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE0D1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F78Bu, 0x02E0CDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02E0D1;
L_02E0D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE0D1u,0x02E0D1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0D1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E0D3;
L_02E0D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D3u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02E0D3 PHA
    cpu.push("PHA", hw);
    goto L_02E0D4;
L_02E0D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0D4 LDA
    cpu.setA(0x10u, 8);
    goto L_02E0D6;
L_02E0D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0D6 STA
    hw.write(cpu.address("dp", 0x64u), cpu.a, cpu.m8?8:16);
    goto L_02E0D8;
L_02E0D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D8u, 4u + ((((0x1570u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0D8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1570u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E0DB;
L_02E0DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0DB AND
    cpu.logicAnd(0x8u);
    goto L_02E0DD;
L_02E0DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0DD LSR
    cpu.lsrA();
    goto L_02E0DE;
L_02E0DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0DE LSR
    cpu.lsrA();
    goto L_02E0DF;
L_02E0DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DFu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0DF EOR
    cpu.logicXor(0x2u);
    goto L_02E0E1;
L_02E0E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E1u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0E1 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_02E0E4;
L_02E0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E4u, 8u, 4u, 0x0190B2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02E0E4 JSL -> $0190B2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE0E7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE0E8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0190B2u, 0x02E0E4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02E0E8;
L_02E0E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE0E8u,0x02E0E8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E8u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0E8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E0EB;
L_02E0EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0EB CLC
    cpu.setFlag('C', false);
    goto L_02E0EC;
L_02E0EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0ECu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0EC ADC
    cpu.adc(0x4u);
    goto L_02E0EE;
L_02E0EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EEu, 5u, 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0EE STA
    hw.write(cpu.address("absx", 0x15EAu), cpu.a, cpu.m8?8:16);
    goto L_02E0F1;
L_02E0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F1u, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0F1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E0F4;
L_02E0F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0F4 AND
    cpu.logicAnd(0x4u);
    goto L_02E0F6;
L_02E0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0F6 LSR
    cpu.lsrA();
    goto L_02E0F7;
L_02E0F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0F7 LSR
    cpu.lsrA();
    goto L_02E0F8;
L_02E0F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F8u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0F8 INC
    cpu.inc('A');
    goto L_02E0F9;
L_02E0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0F9 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_02E0FC;
L_02E0FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FCu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0FC LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E0FE;
L_02E0FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02E0FE PHA
    cpu.push("PHA", hw);
    goto L_02E0FF;
L_02E0FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E0FF CLC
    cpu.setFlag('C', false);
    goto L_02E100;
L_02E100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE100u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE100u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E100 ADC
    cpu.adc(0x8u);
    goto L_02E102;
L_02E102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E102 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_02E104;
L_02E104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE104u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE104u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E104 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E107;
L_02E107:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE107u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE107u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE107u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02E107 PHA
    cpu.push("PHA", hw);
    goto L_02E108;
L_02E108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE108u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE108u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E108 ADC
    cpu.adc(0x0u);
    goto L_02E10A;
L_02E10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Au, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E10A STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_02E10D;
L_02E10D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E10D LDA
    cpu.setA(0xAu, 8);
    goto L_02E10F;
L_02E10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Fu, 5u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E10F STA
    hw.write(cpu.address("absx", 0x15F6u), cpu.a, cpu.m8?8:16);
    goto L_02E112;
L_02E112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE112u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE112u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E112 LDA
    cpu.setA(0x1u, 8);
    goto L_02E114;
L_02E114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE114u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE114u, 8u, 4u, 0x018042u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02E114 JSL -> $018042 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE117u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE118u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x018042u, 0x02E114u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02E118;
L_02E118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE118u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE118u,0x02E118u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE118u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE118u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02E118 PLA
    cpu.pop("PLA", hw);
    goto L_02E119;
L_02E119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE119u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE119u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E119 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_02E11C;
L_02E11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Cu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02E11C PLA
    cpu.pop("PLA", hw);
    goto L_02E11D;
L_02E11D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E11D STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_02E11F;
L_02E11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Fu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02E11F PLA
    cpu.pop("PLA", hw);
    goto L_02E120;
L_02E120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE120u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE120u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E120 STA
    hw.write(cpu.address("dp", 0x64u), cpu.a, cpu.m8?8:16);
    goto L_02E122;
L_02E122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE122u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE122u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E122 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E124;
L_02E124:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE124u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE124u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE124u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E124 BNE -> $02E158
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02E158; }
    goto L_02E126;
L_02E126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE126u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE126u, 6u, 3u, cpu.address("abs", 0xD025u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02E126 JSR -> $02D025 stack real
    { cpu.push16Value(hw,0xE128u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE129u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD025u), 0x02E126u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02E129;
L_02E129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE129u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE129u,0x02E129u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE129u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE129u, 8u, 4u, 0x01803Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02E129 JSL -> $01803A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE12Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE12Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01803Au, 0x02E129u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02E12D;
L_02E12D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE12Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE12Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE12Du, 6u, 3u, cpu.address("abs", 0xD294u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02E12D JSR -> $02D294 stack real
    { cpu.push16Value(hw,0xE12Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE130u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD294u), 0x02E12Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02E130;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE12Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE12Du, 6u, 3u, cpu.address("abs", 0xD294u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02E12D JSR -> $02D294 stack real
    { cpu.push16Value(hw,0xE12Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE130u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD294u), 0x02E12Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02E130;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE12Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE12Du, 6u, 3u, cpu.address("abs", 0xD294u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02E12D JSR -> $02D294 stack real
    { cpu.push16Value(hw,0xE12Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE130u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD294u), 0x02E12Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02E130;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE12Du,0x02E12Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02E130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE130u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE130u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE130u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E130 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E132;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE130u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE130u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E130 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E132;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE130u,0x02E130u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02E132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE132u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE132u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE132u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02E132 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE135u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE136u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x02E132u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02E136;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE132u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE132u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02E132 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE135u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE136u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x02E132u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02E136;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE132u,0x02E132u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02E136:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE136u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE136u,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE136u, 4u + ((((0x59E1u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x59E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E136 BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x59E1u), cpu.m8?8:16), false);
    goto L_02E139;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE136u,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE136u, 4u + ((((0x59E1u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x59E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E136 BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x59E1u), cpu.m8?8:16), false);
    goto L_02E139;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE136u,0x02E136u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02E139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE139u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE139u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE139u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x77u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $02E139 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0x77u), cpu.m8?8:16));
    goto L_02E13B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE139u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE139u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x77u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $02E139 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0x77u), cpu.m8?8:16));
    goto L_02E13B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE139u,0x02E139u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02E13B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE13Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE13Bu,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE13Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x74u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $02E13B SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0x74u), cpu.m8?8:16));
    goto L_02E13D;
L_02E13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE13Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE13Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE13Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E13D TAX
    cpu.transfer("TAX");
    goto L_02E13E;
L_02E13E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE13Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE13Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE13Eu, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E13E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E141;
L_02E141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE141u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE141u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E141 BNE -> $02E158
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02E158; }
    goto L_02E143;
L_02E143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE143u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE143u, 6u, 3u, cpu.address("abs", 0xD4FAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02E143 JSR -> $02D4FA stack real
    { cpu.push16Value(hw,0xE145u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE146u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD4FAu), 0x02E143u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02E146;
L_02E146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE146u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE146u,0x02E146u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE146u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE146u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E146 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E148;
L_02E148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE148u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE148u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E148 CLC
    cpu.setFlag('C', false);
    goto L_02E149;
L_02E149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE149u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE149u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E149 ADC
    cpu.adc(0x1Bu);
    goto L_02E14B;
L_02E14B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE14Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE14Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE14Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E14B CMP
    cpu.compareA(0x37u);
    goto L_02E14D;
L_02E14D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE14Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE14Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE14Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E14D BCC -> $02E158
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_02E158; }
    goto L_02E14F;
L_02E14F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE14Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE14Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE14Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E14F LDA
    cpu.setA(0xC0u, 8);
    goto L_02E151;
L_02E151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE151u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE151u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E151 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_02E153;
L_02E153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE153u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE153u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E153 INC
    cpu.incMem(hw, cpu.address("dpx", 0xC2u), cpu.m8?8:16);
    goto L_02E155;
L_02E155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE155u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE155u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E155 STZ
    hw.write(cpu.address("absx", 0x1602u), 0, cpu.m8?8:16);
    goto L_02E158;
L_02E158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE158u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE158u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02E158 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02E158u);return;} hw.unresolvedReturn(0x02E158u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_03C1F5_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x03C1F5u: goto L_03C1F5;
    case 0x03C1F7u: goto L_03C1F7;
    case 0x03C1F9u: goto L_03C1F9;
    case 0x03C1FDu: goto L_03C1FD;
    case 0x03C200u: goto L_03C200;
    case 0x03C203u: goto L_03C203;
    case 0x03C205u: goto L_03C205;
    case 0x03C207u: goto L_03C207;
    case 0x03C209u: goto L_03C209;
    case 0x03C20Bu: goto L_03C20B;
    case 0x03C20Eu: goto L_03C20E;
    case 0x03C20Fu: goto L_03C20F;
    case 0x03C211u: goto L_03C211;
    case 0x03C214u: goto L_03C214;
    case 0x03C216u: goto L_03C216;
    case 0x03C218u: goto L_03C218;
    case 0x03C21Bu: goto L_03C21B;
    case 0x03C21Du: goto L_03C21D;
    case 0x03C21Fu: goto L_03C21F;
    case 0x03C222u: goto L_03C222;
    case 0x03C224u: goto L_03C224;
    case 0x03C227u: goto L_03C227;
    case 0x03C228u: goto L_03C228;
    case 0x03C22Au: goto L_03C22A;
    case 0x03C22Bu: goto L_03C22B;
    case 0x03C22Eu: goto L_03C22E;
    case 0x03C22Fu: goto L_03C22F;
    case 0x03C230u: goto L_03C230;
    case 0x03C232u: goto L_03C232;
    case 0x03C233u: goto L_03C233;
    case 0x03C234u: goto L_03C234;
    case 0x03C237u: goto L_03C237;
    case 0x03C239u: goto L_03C239;
    case 0x03C23Bu: goto L_03C23B;
    case 0x03C23Cu: goto L_03C23C;
    case 0x03C23Eu: goto L_03C23E;
    case 0x03C240u: goto L_03C240;
    case 0x03C244u: goto L_03C244;
    case 0x03C247u: goto L_03C247;
    case 0x03C249u: goto L_03C249;
    case 0x03C24Cu: goto L_03C24C;
    case 0x03C24Fu: goto L_03C24F;
    case 0x03C251u: goto L_03C251;
    case 0x03C254u: goto L_03C254;
    case 0x03C255u: goto L_03C255;
    case 0x03C257u: goto L_03C257;
    case 0x03C258u: goto L_03C258;
    case 0x03C25Au: goto L_03C25A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_03C1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C1F5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C1F7;
L_03C1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C1F7 BNE -> $03C22B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_03C22B; }
    goto L_03C1F9;
L_03C1F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F9u, 8u, 4u, 0x01B44Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $03C1F9 JSL -> $01B44F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC1FCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1FDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01B44Fu, 0x03C1F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_03C1FD;
L_03C1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1FDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FDu, 6u, 3u, cpu.address("abs", 0xB85Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $03C1FD JSR -> $03B85D stack real
    { cpu.push16Value(hw,0xC1FFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC200u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB85Du), 0x03C1FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_03C200;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FDu, 6u, 3u, cpu.address("abs", 0xB85Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $03C1FD JSR -> $03B85D stack real
    { cpu.push16Value(hw,0xC1FFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC200u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB85Du), 0x03C1FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_03C200;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1FDu,0x03C1FDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC200u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC200u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC200u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C200 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C203;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC200u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC200u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C200 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C203;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC200u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC200u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C200 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C203;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC200u,0x03C200u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC203u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC203u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC203u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C203 CMP
    cpu.compareA(0x5u);
    goto L_03C205;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC203u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC203u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C203 CMP
    cpu.compareA(0x5u);
    goto L_03C205;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC203u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC203u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C203 CMP
    cpu.compareA(0x5u);
    goto L_03C205;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC203u,0x03C203u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC205u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC205u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C205 BNE -> $03C22B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_03C22B; }
    goto L_03C207;
L_03C207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC207u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC207u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C207 STZ
    hw.write(cpu.address("dpx", 0xC2u), 0, cpu.m8?8:16);
    goto L_03C209;
L_03C209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC209u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC209u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C209 LDY
    cpu.setY(0xBu, 8);
    goto L_03C20B;
L_03C20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Bu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Bu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C20B STY
    hw.write(cpu.address("abs", 0x1DF9u), cpu.y, cpu.x8?8:16);
    goto L_03C20E;
L_03C20E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Eu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $03C20E PHA
    cpu.push("PHA", hw);
    goto L_03C20F;
L_03C20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C20F LDY
    cpu.setY(0x9u, 8);
    goto L_03C211;
L_03C211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC211u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC211u, 4u + ((((0x14C8u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C211 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C214;
L_03C214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC214u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC214u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C214 CMP
    cpu.compareA(0x8u);
    goto L_03C216;
L_03C216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC216u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC216u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC216u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C216 BNE -> $03C227
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_03C227; }
    goto L_03C218;
L_03C218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC218u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC218u, 4u + ((((0x009Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x009Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C218 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C21B;
L_03C21B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC21Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C21B CMP
    cpu.compareA(0xC6u);
    goto L_03C21D;
L_03C21D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC21Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C21D BNE -> $03C227
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_03C227; }
    goto L_03C21F;
L_03C21F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC21Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Fu, 4u + ((((0x00C2u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x00C2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C21F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C222;
L_03C222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC222u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC222u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C222 EOR
    cpu.logicXor(0x1u);
    goto L_03C224;
L_03C224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC224u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC224u, 5u, 3u, cpu.address("absy", 0x00C2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C224 STA
    hw.write(cpu.address("absy", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_03C227;
L_03C227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC227u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC227u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C227 DEY
    cpu.decReg('Y');
    goto L_03C228;
L_03C228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC228u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC228u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C228 BPL -> $03C211
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_03C211; }
    goto L_03C22A;
L_03C22A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $03C22A PLA
    cpu.pop("PLA", hw);
    goto L_03C22B;
L_03C22B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Bu, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C22B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C22E;
L_03C22E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C22E LSR
    cpu.lsrA();
    goto L_03C22F;
L_03C22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C22F TAY
    cpu.transfer("TAY");
    goto L_03C230;
L_03C230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC230u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC230u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C230 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C232;
L_03C232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC232u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC232u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $03C232 PHA
    cpu.push("PHA", hw);
    goto L_03C233;
L_03C233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC233u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC233u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C233 CLC
    cpu.setFlag('C', false);
    goto L_03C234;
L_03C234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC234u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC234u, 4u + ((((0xC1ECu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xC1ECu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C234 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xC1ECu), cpu.m8?8:16));
    goto L_03C237;
L_03C237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC237u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC237u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C237 STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_03C239;
L_03C239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC239u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC239u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C239 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C23B;
L_03C23B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $03C23B PHA
    cpu.push("PHA", hw);
    goto L_03C23C;
L_03C23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C23C ADC
    cpu.adc(0x0u);
    goto L_03C23E;
L_03C23E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C23E STA
    hw.write(cpu.address("dp", 0x1Du), cpu.a, cpu.m8?8:16);
    goto L_03C240;
L_03C240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC240u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC240u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC240u, 8u, 4u, 0x0190B2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $03C240 JSL -> $0190B2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC243u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC244u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0190B2u, 0x03C240u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_03C244;
L_03C244:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC244u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC244u,0x03C244u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC244u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC244u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C244 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_03C247;
L_03C247:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC247u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC247u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC247u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C247 LDA
    cpu.setA(0x2Au, 8);
    goto L_03C249;
L_03C249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC249u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC249u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C249 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_03C24C;
L_03C24C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Cu, 4u + ((((0x0303u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C24C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x303u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C24F;
L_03C24F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C24F AND
    cpu.logicAnd(0xBFu);
    goto L_03C251;
L_03C251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC251u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC251u, 5u, 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C251 STA
    hw.write(cpu.address("absy", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_03C254;
L_03C254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC254u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC254u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $03C254 PLA
    cpu.pop("PLA", hw);
    goto L_03C255;
L_03C255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC255u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC255u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C255 STA
    hw.write(cpu.address("dp", 0x1Du), cpu.a, cpu.m8?8:16);
    goto L_03C257;
L_03C257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC257u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC257u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $03C257 PLA
    cpu.pop("PLA", hw);
    goto L_03C258;
L_03C258:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC258u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC258u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC258u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C258 STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_03C25A;
L_03C25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $03C25A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x03C25Au);return;} hw.unresolvedReturn(0x03C25Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04E677_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04E677u: goto L_04E677;
    case 0x04E679u: goto L_04E679;
    case 0x04E67Bu: goto L_04E67B;
    case 0x04E67Fu: goto L_04E67F;
    case 0x04E681u: goto L_04E681;
    case 0x04E682u: goto L_04E682;
    case 0x04E684u: goto L_04E684;
    case 0x04E686u: goto L_04E686;
    case 0x04E689u: goto L_04E689;
    case 0x04E68Au: goto L_04E68A;
    case 0x04E68Du: goto L_04E68D;
    case 0x04E68Eu: goto L_04E68E;
    case 0x04E68Fu: goto L_04E68F;
    case 0x04E690u: goto L_04E690;
    case 0x04E692u: goto L_04E692;
    case 0x04E694u: goto L_04E694;
    case 0x04E696u: goto L_04E696;
    case 0x04E699u: goto L_04E699;
    case 0x04E69Bu: goto L_04E69B;
    case 0x04E69Fu: goto L_04E69F;
    case 0x04E6A0u: goto L_04E6A0;
    case 0x04E6A2u: goto L_04E6A2;
    case 0x04E6A5u: goto L_04E6A5;
    case 0x04E6A7u: goto L_04E6A7;
    case 0x04E6ABu: goto L_04E6AB;
    case 0x04E6ADu: goto L_04E6AD;
    case 0x04E6AEu: goto L_04E6AE;
    case 0x04E6B0u: goto L_04E6B0;
    case 0x04E6B3u: goto L_04E6B3;
    case 0x04E6B4u: goto L_04E6B4;
    case 0x04E6B7u: goto L_04E6B7;
    case 0x04E6BAu: goto L_04E6BA;
    case 0x04E6BCu: goto L_04E6BC;
    case 0x04E6C0u: goto L_04E6C0;
    case 0x04E6C2u: goto L_04E6C2;
    case 0x04E6C4u: goto L_04E6C4;
    case 0x04E6C5u: goto L_04E6C5;
    case 0x04E6C6u: goto L_04E6C6;
    case 0x04E6C9u: goto L_04E6C9;
    case 0x04E6CAu: goto L_04E6CA;
    case 0x04E6CCu: goto L_04E6CC;
    case 0x04E6D0u: goto L_04E6D0;
    case 0x04E6D2u: goto L_04E6D2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04E677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE677u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE677u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E677 SEP
    cpu.sep(0x30u);
    goto L_04E679;
L_04E679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE679u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE679u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E679 LDX
    cpu.setX(0x17u, 8);
    goto L_04E67B;
L_04E67B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE67Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Bu,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Bu, 5u, 4u, ((0x04E5D6u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E67B CMP
    cpu.compareA(hw.readW(((0x4E5D6u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_04E67F;
L_04E67F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE67Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E67F BEQ -> $04E68A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04E68A; }
    goto L_04E681;
L_04E681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE681u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE681u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E681 DEX
    cpu.decReg('X');
    goto L_04E682;
L_04E682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE682u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE682u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E682 BPL -> $04E67B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04E67B; }
    goto L_04E684;
L_04E684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE684u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE684u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE684u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E684 LDA
    cpu.setA(0x2u, 8);
    goto L_04E686;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE684u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE684u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E684 LDA
    cpu.setA(0x2u, 8);
    goto L_04E686;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE684u,0x04E684u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04E686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE686u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE686u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE686u, 4u, 3u, cpu.address("abs", 0x1B86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E686 STA
    hw.write(cpu.address("abs", 0x1B86u), cpu.a, cpu.m8?8:16);
    goto L_04E689;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE686u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE686u, 4u, 3u, cpu.address("abs", 0x1B86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E686 STA
    hw.write(cpu.address("abs", 0x1B86u), cpu.a, cpu.m8?8:16);
    goto L_04E689;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE686u,0x04E686u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04E689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE689u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE689u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE689u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04E689 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04E689u);return;} hw.unresolvedReturn(0x04E689u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE689u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE689u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04E689 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04E689u);return;} hw.unresolvedReturn(0x04E689u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE689u,0x04E689u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04E68A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE68Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Au,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Au, 4u, 3u, cpu.address("abs", 0x13D1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E68A STX
    hw.write(cpu.address("abs", 0x13D1u), cpu.x, cpu.x8?8:16);
    goto L_04E68D;
L_04E68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE68Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E68D TXA
    cpu.transfer("TXA");
    goto L_04E68E;
L_04E68E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE68Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E68E ASL
    cpu.aslA();
    goto L_04E68F;
L_04E68F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE68Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E68F TAX
    cpu.transfer("TAX");
    goto L_04E690;
L_04E690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE690u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE690u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E690 LDA
    cpu.setA(0x7Eu, 8);
    goto L_04E692;
L_04E692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE692u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE692u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E692 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_04E694;
L_04E694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE694u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE694u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E694 REP
    cpu.rep(0x30u);
    goto L_04E696;
L_04E696:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE696u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE696u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE696u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E696 LDA
    cpu.setA(0xC800u, 16);
    goto L_04E699;
L_04E699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE699u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE699u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E699 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_04E69B;
L_04E69B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE69Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Bu, 6u, 4u, ((0x04E5B6u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E69B LDA
    cpu.loadA(hw.readW(((0x4E5B6u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E69F;
L_04E69F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE69Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E69F TAY
    cpu.transfer("TAY");
    goto L_04E6A0;
L_04E6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6A0 SEP
    cpu.sep(0x20u);
    goto L_04E6A2;
L_04E6A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6A2 LDX
    cpu.setX(0x4u, 16);
    goto L_04E6A5;
L_04E6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A5u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A5u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $04E6A5 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E6A7;
L_04E6A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A7u,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A7u, 5u, 4u, ((0x04E5A7u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6A7 CMP
    cpu.compareA(hw.readW(((0x4E5A7u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_04E6AB;
L_04E6AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6ABu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6AB BEQ -> $04E6B3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04E6B3; }
    goto L_04E6AD;
L_04E6AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6ADu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6AD DEX
    cpu.decReg('X');
    goto L_04E6AE;
L_04E6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6AEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6AE BPL -> $04E6A7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04E6A7; }
    goto L_04E6B0;
L_04E6B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B0u, 3u, 3u, cpu.address("abs", 0xE684u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6B0 JMP -> $04E684
    goto L_04E684;
L_04E6B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B3u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6B3 TXA
    cpu.transfer("TXA");
    goto L_04E6B4;
L_04E6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B4u, 4u, 3u, cpu.address("abs", 0x13D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6B4 STA
    hw.write(cpu.address("abs", 0x13D0u), cpu.a, cpu.m8?8:16);
    goto L_04E6B7;
L_04E6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B7u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6B7 CPX
    cpu.compareX(0x3u);
    goto L_04E6BA;
L_04E6BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6BAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6BA BMI -> $04E6CA
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_04E6CA; }
    goto L_04E6BC;
L_04E6BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6BCu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6BCu, 5u, 4u, ((0x04E5ACu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6BC LDA
    cpu.loadA(hw.readW(((0x4E5ACu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E6C0;
L_04E6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C0u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C0u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $04E6C0 STA
    hw.write(cpu.addressDpLongY(hw, 0xAu), cpu.a, cpu.m8?8:16);
    goto L_04E6C2;
L_04E6C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6C2 REP
    cpu.rep(0x20u);
    goto L_04E6C4;
L_04E6C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C4u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6C4 TYA
    cpu.transfer("TYA");
    goto L_04E6C5;
L_04E6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6C5 CLC
    cpu.setFlag('C', false);
    goto L_04E6C6;
L_04E6C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C6u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6C6 ADC
    cpu.adc(0x10u);
    goto L_04E6C9;
L_04E6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C9u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6C9 TAY
    cpu.transfer("TAY");
    goto L_04E6CA;
L_04E6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6CAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6CA SEP
    cpu.sep(0x20u);
    goto L_04E6CC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6CA SEP
    cpu.sep(0x20u);
    goto L_04E6CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE6CAu,0x04E6CAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04E6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CCu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CCu, 5u, 4u, ((0x04E5B1u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E6CC LDA
    cpu.loadA(hw.readW(((0x4E5B1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E6D0;
L_04E6D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D0u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D0u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $04E6D0 STA
    hw.write(cpu.addressDpLongY(hw, 0xAu), cpu.a, cpu.m8?8:16);
    goto L_04E6D2;
L_04E6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04E6D2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04E6D2u);return;} hw.unresolvedReturn(0x04E6D2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0589CE_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0589CEu: goto L_0589CE;
    case 0x0589CFu: goto L_0589CF;
    case 0x0589D1u: goto L_0589D1;
    case 0x0589D4u: goto L_0589D4;
    case 0x0589D7u: goto L_0589D7;
    case 0x0589D8u: goto L_0589D8;
    case 0x0589D9u: goto L_0589D9;
    case 0x0589DBu: goto L_0589DB;
    case 0x0589DFu: goto L_0589DF;
    case 0x0589E1u: goto L_0589E1;
    case 0x0589E5u: goto L_0589E5;
    case 0x0589E7u: goto L_0589E7;
    case 0x0589EBu: goto L_0589EB;
    case 0x0589EDu: goto L_0589ED;
    case 0x0589F1u: goto L_0589F1;
    case 0x0589F3u: goto L_0589F3;
    case 0x0589F5u: goto L_0589F5;
    case 0x0589F7u: goto L_0589F7;
    case 0x0589F9u: goto L_0589F9;
    case 0x0589FBu: goto L_0589FB;
    case 0x0589FCu: goto L_0589FC;
    case 0x0589FEu: goto L_0589FE;
    case 0x058A00u: goto L_058A00;
    case 0x058A01u: goto L_058A01;
    case 0x058A04u: goto L_058A04;
    case 0x058A07u: goto L_058A07;
    case 0x058A09u: goto L_058A09;
    case 0x058A0Bu: goto L_058A0B;
    case 0x058A0Du: goto L_058A0D;
    case 0x058A10u: goto L_058A10;
    case 0x058A11u: goto L_058A11;
    case 0x058A14u: goto L_058A14;
    case 0x058A16u: goto L_058A16;
    case 0x058A18u: goto L_058A18;
    case 0x058A1Bu: goto L_058A1B;
    case 0x058A1Cu: goto L_058A1C;
    case 0x058A1Du: goto L_058A1D;
    case 0x058A1Eu: goto L_058A1E;
    case 0x058A1Fu: goto L_058A1F;
    case 0x058A21u: goto L_058A21;
    case 0x058A22u: goto L_058A22;
    case 0x058A23u: goto L_058A23;
    case 0x058A25u: goto L_058A25;
    case 0x058A26u: goto L_058A26;
    case 0x058A28u: goto L_058A28;
    case 0x058A2Au: goto L_058A2A;
    case 0x058A2Cu: goto L_058A2C;
    case 0x058A2Eu: goto L_058A2E;
    case 0x058A30u: goto L_058A30;
    case 0x058A31u: goto L_058A31;
    case 0x058A32u: goto L_058A32;
    case 0x058A34u: goto L_058A34;
    case 0x058A36u: goto L_058A36;
    case 0x058A38u: goto L_058A38;
    case 0x058A3Au: goto L_058A3A;
    case 0x058A3Cu: goto L_058A3C;
    case 0x058A3Eu: goto L_058A3E;
    case 0x058A41u: goto L_058A41;
    case 0x058A43u: goto L_058A43;
    case 0x058A45u: goto L_058A45;
    case 0x058A47u: goto L_058A47;
    case 0x058A49u: goto L_058A49;
    case 0x058A4Bu: goto L_058A4B;
    case 0x058A4Du: goto L_058A4D;
    case 0x058A50u: goto L_058A50;
    case 0x058A52u: goto L_058A52;
    case 0x058A55u: goto L_058A55;
    case 0x058A57u: goto L_058A57;
    case 0x058A59u: goto L_058A59;
    case 0x058A5Cu: goto L_058A5C;
    case 0x058A5Eu: goto L_058A5E;
    case 0x058A60u: goto L_058A60;
    case 0x058A62u: goto L_058A62;
    case 0x058A64u: goto L_058A64;
    case 0x058A65u: goto L_058A65;
    case 0x058A66u: goto L_058A66;
    case 0x058A69u: goto L_058A69;
    case 0x058A6Bu: goto L_058A6B;
    case 0x058A6Eu: goto L_058A6E;
    case 0x058A70u: goto L_058A70;
    case 0x058A73u: goto L_058A73;
    case 0x058A74u: goto L_058A74;
    case 0x058A75u: goto L_058A75;
    case 0x058A77u: goto L_058A77;
    case 0x058A7Au: goto L_058A7A;
    case 0x058A7Bu: goto L_058A7B;
    case 0x058A7Cu: goto L_058A7C;
    case 0x058A7Eu: goto L_058A7E;
    case 0x058A81u: goto L_058A81;
    case 0x058A82u: goto L_058A82;
    case 0x058A83u: goto L_058A83;
    case 0x058A85u: goto L_058A85;
    case 0x058A88u: goto L_058A88;
    case 0x058A89u: goto L_058A89;
    case 0x058A8Au: goto L_058A8A;
    case 0x058A8Bu: goto L_058A8B;
    case 0x058A8Cu: goto L_058A8C;
    case 0x058A8Eu: goto L_058A8E;
    case 0x058A8Fu: goto L_058A8F;
    case 0x058A92u: goto L_058A92;
    case 0x058A94u: goto L_058A94;
    case 0x058A97u: goto L_058A97;
    case 0x058A99u: goto L_058A99;
    case 0x058A9Au: goto L_058A9A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0589CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89CEu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89CEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0589CE PHP
    cpu.push("PHP", hw);
    goto L_0589CF;
L_0589CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89CFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89CFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589CF REP
    cpu.rep(0x30u);
    goto L_0589D1;
L_0589D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D1u, 5u, 3u, cpu.address("abs", 0x1925u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589D1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1925u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0589D4;
L_0589D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589D4 AND
    cpu.logicAnd(0xFFu);
    goto L_0589D7;
L_0589D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589D7 ASL
    cpu.aslA();
    goto L_0589D8;
L_0589D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589D8 TAX
    cpu.transfer("TAX");
    goto L_0589D9;
L_0589D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589D9 SEP
    cpu.sep(0x20u);
    goto L_0589DB;
L_0589DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89DBu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89DBu, 5u, 4u, ((0x00BDA8u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589DB LDA
    cpu.loadA(hw.readW(((0xBDA8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0589DF;
L_0589DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89DFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589DF STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_0589E1;
L_0589E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89E1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89E1u, 5u, 4u, ((0x00BDA9u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589E1 LDA
    cpu.loadA(hw.readW(((0xBDA9u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0589E5;
L_0589E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89E5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89E5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589E5 STA
    hw.write(cpu.address("dp", 0xBu), cpu.a, cpu.m8?8:16);
    goto L_0589E7;
L_0589E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89E7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89E7u, 5u, 4u, ((0x00BE28u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589E7 LDA
    cpu.loadA(hw.readW(((0xBE28u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0589EB;
L_0589EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89EBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589EB STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_0589ED;
L_0589ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89EDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89EDu, 5u, 4u, ((0x00BE29u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589ED LDA
    cpu.loadA(hw.readW(((0xBE29u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0589F1;
L_0589F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589F1 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0589F3;
L_0589F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589F3 LDA
    cpu.setA(0x0u, 8);
    goto L_0589F5;
L_0589F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589F5 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_0589F7;
L_0589F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589F7 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_0589F9;
L_0589F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x55u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589F9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x55u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0589FB;
L_0589FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89FBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589FB TAX
    cpu.transfer("TAX");
    goto L_0589FC;
L_0589FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89FCu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589FC LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0589FE;
L_0589FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89FEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589FE AND
    cpu.logicAnd(0xFu);
    goto L_058A00;
L_058A00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A00u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A00u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A00 ASL
    cpu.aslA();
    goto L_058A01;
L_058A01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A01u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A01u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A01 STA
    hw.write(cpu.address("abs", 0x1BE5u), cpu.a, cpu.m8?8:16);
    goto L_058A04;
L_058A04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A04u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A04 LDY
    cpu.setY(0x20u, 16);
    goto L_058A07;
L_058A07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A07u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A07u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A07 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A09;
L_058A09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A09u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A09 AND
    cpu.logicAnd(0x10u);
    goto L_058A0B;
L_058A0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A0B BEQ -> $058A10
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_058A10; }
    goto L_058A0D;
L_058A0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A0D LDY
    cpu.setY(0x24u, 16);
    goto L_058A10;
L_058A10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A10u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A10u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A10 TYA
    cpu.transfer("TYA");
    goto L_058A11;
L_058A11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A11u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A11u, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A11 STA
    hw.write(cpu.address("abs", 0x1BE4u), cpu.a, cpu.m8?8:16);
    goto L_058A14;
L_058A14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A14u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A14u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A14 REP
    cpu.rep(0x20u);
    goto L_058A16;
L_058A16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A16u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A16u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x45u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A16 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A18;
L_058A18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A18 AND
    cpu.logicAnd(0x1F0u);
    goto L_058A1B;
L_058A1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A1B LSR
    cpu.lsrA();
    goto L_058A1C;
L_058A1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A1C LSR
    cpu.lsrA();
    goto L_058A1D;
L_058A1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A1D LSR
    cpu.lsrA();
    goto L_058A1E;
L_058A1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A1E LSR
    cpu.lsrA();
    goto L_058A1F;
L_058A1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A1F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_058A21;
L_058A21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A21 ASL
    cpu.aslA();
    goto L_058A22;
L_058A22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A22u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A22 CLC
    cpu.setFlag('C', false);
    goto L_058A23;
L_058A23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A23u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A23u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A23 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_058A25;
L_058A25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A25u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A25 TAY
    cpu.transfer("TAY");
    goto L_058A26;
L_058A26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A26u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A26u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $058A26 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A28;
L_058A28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A28u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A28u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A28 STA
    hw.write(cpu.address("dp", 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_058A2A;
L_058A2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Du) & 0xFFFFu), 3u, 0u);
    // $058A2A LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A2C;
L_058A2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A2C STA
    hw.write(cpu.address("dp", 0x6Eu), cpu.a, cpu.m8?8:16);
    goto L_058A2E;
L_058A2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A2E SEP
    cpu.sep(0x20u);
    goto L_058A30;
L_058A30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A30u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A30u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A30 INY
    cpu.inc('Y');
    goto L_058A31;
L_058A31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A31u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A31 INY
    cpu.inc('Y');
    goto L_058A32;
L_058A32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A32u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A32u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $058A32 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A34;
L_058A34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A34u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A34u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A34 STA
    hw.write(cpu.address("dp", 0x6Du), cpu.a, cpu.m8?8:16);
    goto L_058A36;
L_058A36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A36u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A36u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Du) & 0xFFFFu), 3u, 0u);
    // $058A36 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A38;
L_058A38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A38u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A38u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x70u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A38 STA
    hw.write(cpu.address("dp", 0x70u), cpu.a, cpu.m8?8:16);
    goto L_058A3A;
L_058A3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A3A SEP
    cpu.sep(0x10u);
    goto L_058A3C;
L_058A3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A3C LDY
    cpu.setY(0xDu, 8);
    goto L_058A3E;
L_058A3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Eu, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A3E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A41;
L_058A41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A41u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A41 CMP
    cpu.compareA(0x10u);
    goto L_058A43;
L_058A43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A43u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A43 BMI -> $058A47
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_058A47; }
    goto L_058A45;
L_058A45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A45u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A45 LDY
    cpu.setY(0x5u, 8);
    goto L_058A47;
L_058A47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A47u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A47u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A47 STY
    hw.write(cpu.address("dp", 0xCu), cpu.y, cpu.x8?8:16);
    goto L_058A49;
L_058A49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A49u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A49u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A49 REP
    cpu.rep(0x30u);
    goto L_058A4B;
L_058A4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x45u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A4B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A4D;
L_058A4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A4D AND
    cpu.logicAnd(0xFu);
    goto L_058A50;
L_058A50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A50u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A50 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_058A52;
L_058A52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A52u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A52u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A52 LDX
    cpu.setX(0x0u, 16);
    goto L_058A55;
L_058A55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A55u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A55u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A55 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_058A57;
L_058A57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A57u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A57u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $058A57 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A59;
L_058A59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A59u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A59 AND
    cpu.logicAnd(0xFFu);
    goto L_058A5C;
L_058A5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A5C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_058A5E;
L_058A5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Eu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Eu) & 0xFFFFu), 3u, 0u);
    // $058A5E LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x6Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A60;
L_058A60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A60 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_058A62;
L_058A62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A62u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A62u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A62 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A64;
L_058A64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A64u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A64u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A64 ASL
    cpu.aslA();
    goto L_058A65;
L_058A65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A65u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A65 TAY
    cpu.transfer("TAY");
    goto L_058A66;
L_058A66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A66u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A66u, 5u + 1u, 3u, cpu.address("absy", 0x0FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A66 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xFBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A69;
L_058A69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A69u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A69u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A69 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_058A6B;
L_058A6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A6B LDY
    cpu.setY(0x0u, 16);
    goto L_058A6E;
L_058A6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Eu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $058A6E LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A70;
L_058A70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A70u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A70u, 6u, 3u, cpu.address("absx", 0x1BE6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A70 STA
    hw.write(cpu.address("absx", 0x1BE6u), cpu.a, cpu.m8?8:16);
    goto L_058A73;
L_058A73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A73u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A73u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A73 INY
    cpu.inc('Y');
    goto L_058A74;
L_058A74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A74u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A74u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A74 INY
    cpu.inc('Y');
    goto L_058A75;
L_058A75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A75u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A75u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $058A75 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A77;
L_058A77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A77u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A77u, 6u, 3u, cpu.address("absx", 0x1BE8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A77 STA
    hw.write(cpu.address("absx", 0x1BE8u), cpu.a, cpu.m8?8:16);
    goto L_058A7A;
L_058A7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A7A INY
    cpu.inc('Y');
    goto L_058A7B;
L_058A7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A7B INY
    cpu.inc('Y');
    goto L_058A7C;
L_058A7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $058A7C LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A7E;
L_058A7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Eu, 6u, 3u, cpu.address("absx", 0x1C66u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A7E STA
    hw.write(cpu.address("absx", 0x1C66u), cpu.a, cpu.m8?8:16);
    goto L_058A81;
L_058A81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A81 INY
    cpu.inc('Y');
    goto L_058A82;
L_058A82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A82u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A82u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A82 INY
    cpu.inc('Y');
    goto L_058A83;
L_058A83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A83u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A83u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $058A83 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A85;
L_058A85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A85u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A85u, 6u, 3u, cpu.address("absx", 0x1C68u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A85 STA
    hw.write(cpu.address("absx", 0x1C68u), cpu.a, cpu.m8?8:16);
    goto L_058A88;
L_058A88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A88u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A88u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A88 INX
    cpu.inc('X');
    goto L_058A89;
L_058A89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A89 INX
    cpu.inc('X');
    goto L_058A8A;
L_058A8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Au,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A8A INX
    cpu.inc('X');
    goto L_058A8B;
L_058A8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A8B INX
    cpu.inc('X');
    goto L_058A8C;
L_058A8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A8C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A8E;
L_058A8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A8E CLC
    cpu.setFlag('C', false);
    goto L_058A8F;
L_058A8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A8F ADC
    cpu.adc(0x10u);
    goto L_058A92;
L_058A92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A92u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A92u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A92 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_058A94;
L_058A94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A94u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A94 CMP
    cpu.compareA(0x1B0u);
    goto L_058A97;
L_058A97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A97u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A97 BCC -> $058A55
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_058A55; }
    goto L_058A99;
L_058A99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A99u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A99u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058A99 PLP
    cpu.pop("PLP", hw);
    goto L_058A9A;
L_058A9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A9Au,0x058A9Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058A9A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058A9Au);return;} hw.unresolvedReturn(0x058A9Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0589CE_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0589CEu: goto L_0589CE;
    case 0x0589CFu: goto L_0589CF;
    case 0x0589D1u: goto L_0589D1;
    case 0x0589D4u: goto L_0589D4;
    case 0x0589D7u: goto L_0589D7;
    case 0x0589D8u: goto L_0589D8;
    case 0x0589D9u: goto L_0589D9;
    case 0x0589DBu: goto L_0589DB;
    case 0x0589DFu: goto L_0589DF;
    case 0x0589E1u: goto L_0589E1;
    case 0x0589E5u: goto L_0589E5;
    case 0x0589E7u: goto L_0589E7;
    case 0x0589EBu: goto L_0589EB;
    case 0x0589EDu: goto L_0589ED;
    case 0x0589F1u: goto L_0589F1;
    case 0x0589F3u: goto L_0589F3;
    case 0x0589F5u: goto L_0589F5;
    case 0x0589F7u: goto L_0589F7;
    case 0x0589F9u: goto L_0589F9;
    case 0x0589FBu: goto L_0589FB;
    case 0x0589FCu: goto L_0589FC;
    case 0x0589FEu: goto L_0589FE;
    case 0x058A00u: goto L_058A00;
    case 0x058A01u: goto L_058A01;
    case 0x058A04u: goto L_058A04;
    case 0x058A07u: goto L_058A07;
    case 0x058A09u: goto L_058A09;
    case 0x058A0Bu: goto L_058A0B;
    case 0x058A0Du: goto L_058A0D;
    case 0x058A10u: goto L_058A10;
    case 0x058A11u: goto L_058A11;
    case 0x058A14u: goto L_058A14;
    case 0x058A16u: goto L_058A16;
    case 0x058A18u: goto L_058A18;
    case 0x058A1Bu: goto L_058A1B;
    case 0x058A1Cu: goto L_058A1C;
    case 0x058A1Du: goto L_058A1D;
    case 0x058A1Eu: goto L_058A1E;
    case 0x058A1Fu: goto L_058A1F;
    case 0x058A21u: goto L_058A21;
    case 0x058A22u: goto L_058A22;
    case 0x058A23u: goto L_058A23;
    case 0x058A25u: goto L_058A25;
    case 0x058A26u: goto L_058A26;
    case 0x058A28u: goto L_058A28;
    case 0x058A2Au: goto L_058A2A;
    case 0x058A2Cu: goto L_058A2C;
    case 0x058A2Eu: goto L_058A2E;
    case 0x058A30u: goto L_058A30;
    case 0x058A31u: goto L_058A31;
    case 0x058A32u: goto L_058A32;
    case 0x058A34u: goto L_058A34;
    case 0x058A36u: goto L_058A36;
    case 0x058A38u: goto L_058A38;
    case 0x058A3Au: goto L_058A3A;
    case 0x058A3Cu: goto L_058A3C;
    case 0x058A3Eu: goto L_058A3E;
    case 0x058A41u: goto L_058A41;
    case 0x058A43u: goto L_058A43;
    case 0x058A45u: goto L_058A45;
    case 0x058A47u: goto L_058A47;
    case 0x058A49u: goto L_058A49;
    case 0x058A4Bu: goto L_058A4B;
    case 0x058A4Du: goto L_058A4D;
    case 0x058A50u: goto L_058A50;
    case 0x058A52u: goto L_058A52;
    case 0x058A55u: goto L_058A55;
    case 0x058A57u: goto L_058A57;
    case 0x058A59u: goto L_058A59;
    case 0x058A5Cu: goto L_058A5C;
    case 0x058A5Eu: goto L_058A5E;
    case 0x058A60u: goto L_058A60;
    case 0x058A62u: goto L_058A62;
    case 0x058A64u: goto L_058A64;
    case 0x058A65u: goto L_058A65;
    case 0x058A66u: goto L_058A66;
    case 0x058A69u: goto L_058A69;
    case 0x058A6Bu: goto L_058A6B;
    case 0x058A6Eu: goto L_058A6E;
    case 0x058A70u: goto L_058A70;
    case 0x058A73u: goto L_058A73;
    case 0x058A74u: goto L_058A74;
    case 0x058A75u: goto L_058A75;
    case 0x058A77u: goto L_058A77;
    case 0x058A7Au: goto L_058A7A;
    case 0x058A7Bu: goto L_058A7B;
    case 0x058A7Cu: goto L_058A7C;
    case 0x058A7Eu: goto L_058A7E;
    case 0x058A81u: goto L_058A81;
    case 0x058A82u: goto L_058A82;
    case 0x058A83u: goto L_058A83;
    case 0x058A85u: goto L_058A85;
    case 0x058A88u: goto L_058A88;
    case 0x058A89u: goto L_058A89;
    case 0x058A8Au: goto L_058A8A;
    case 0x058A8Bu: goto L_058A8B;
    case 0x058A8Cu: goto L_058A8C;
    case 0x058A8Eu: goto L_058A8E;
    case 0x058A8Fu: goto L_058A8F;
    case 0x058A92u: goto L_058A92;
    case 0x058A94u: goto L_058A94;
    case 0x058A97u: goto L_058A97;
    case 0x058A99u: goto L_058A99;
    case 0x058A9Au: goto L_058A9A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0589CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89CEu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89CEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0589CE PHP
    cpu.push("PHP", hw);
    goto L_0589CF;
L_0589CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89CFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89CFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589CF REP
    cpu.rep(0x30u);
    goto L_0589D1;
L_0589D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D1u, 5u, 3u, cpu.address("abs", 0x1925u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589D1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1925u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0589D4;
L_0589D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589D4 AND
    cpu.logicAnd(0xFFu);
    goto L_0589D7;
L_0589D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589D7 ASL
    cpu.aslA();
    goto L_0589D8;
L_0589D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589D8 TAX
    cpu.transfer("TAX");
    goto L_0589D9;
L_0589D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89D9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89D9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589D9 SEP
    cpu.sep(0x20u);
    goto L_0589DB;
L_0589DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89DBu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89DBu, 5u, 4u, ((0x00BDA8u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589DB LDA
    cpu.loadA(hw.readW(((0xBDA8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0589DF;
L_0589DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89DFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589DF STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_0589E1;
L_0589E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89E1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89E1u, 5u, 4u, ((0x00BDA9u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589E1 LDA
    cpu.loadA(hw.readW(((0xBDA9u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0589E5;
L_0589E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89E5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89E5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589E5 STA
    hw.write(cpu.address("dp", 0xBu), cpu.a, cpu.m8?8:16);
    goto L_0589E7;
L_0589E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89E7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89E7u, 5u, 4u, ((0x00BE28u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589E7 LDA
    cpu.loadA(hw.readW(((0xBE28u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0589EB;
L_0589EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89EBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589EB STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_0589ED;
L_0589ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89EDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89EDu, 5u, 4u, ((0x00BE29u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589ED LDA
    cpu.loadA(hw.readW(((0xBE29u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0589F1;
L_0589F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589F1 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0589F3;
L_0589F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589F3 LDA
    cpu.setA(0x0u, 8);
    goto L_0589F5;
L_0589F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589F5 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_0589F7;
L_0589F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589F7 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_0589F9;
L_0589F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x55u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589F9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x55u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0589FB;
L_0589FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89FBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589FB TAX
    cpu.transfer("TAX");
    goto L_0589FC;
L_0589FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89FCu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589FC LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0589FE;
L_0589FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89FEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589FE AND
    cpu.logicAnd(0xFu);
    goto L_058A00;
L_058A00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A00u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A00u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A00 ASL
    cpu.aslA();
    goto L_058A01;
L_058A01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A01u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A01u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A01 STA
    hw.write(cpu.address("abs", 0x1BE5u), cpu.a, cpu.m8?8:16);
    goto L_058A04;
L_058A04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A04u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A04 LDY
    cpu.setY(0x20u, 16);
    goto L_058A07;
L_058A07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A07u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A07u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A07 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A09;
L_058A09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A09u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A09 AND
    cpu.logicAnd(0x10u);
    goto L_058A0B;
L_058A0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A0B BEQ -> $058A10
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_058A10; }
    goto L_058A0D;
L_058A0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A0Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A0D LDY
    cpu.setY(0x24u, 16);
    goto L_058A10;
L_058A10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A10u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A10u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A10 TYA
    cpu.transfer("TYA");
    goto L_058A11;
L_058A11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A11u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A11u, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A11 STA
    hw.write(cpu.address("abs", 0x1BE4u), cpu.a, cpu.m8?8:16);
    goto L_058A14;
L_058A14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A14u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A14u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A14 REP
    cpu.rep(0x20u);
    goto L_058A16;
L_058A16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A16u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A16u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x45u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A16 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A18;
L_058A18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A18 AND
    cpu.logicAnd(0x1F0u);
    goto L_058A1B;
L_058A1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A1B LSR
    cpu.lsrA();
    goto L_058A1C;
L_058A1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A1C LSR
    cpu.lsrA();
    goto L_058A1D;
L_058A1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A1D LSR
    cpu.lsrA();
    goto L_058A1E;
L_058A1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A1E LSR
    cpu.lsrA();
    goto L_058A1F;
L_058A1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A1F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_058A21;
L_058A21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A21 ASL
    cpu.aslA();
    goto L_058A22;
L_058A22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A22u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A22 CLC
    cpu.setFlag('C', false);
    goto L_058A23;
L_058A23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A23u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A23u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A23 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_058A25;
L_058A25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A25u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A25 TAY
    cpu.transfer("TAY");
    goto L_058A26;
L_058A26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A26u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A26u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $058A26 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A28;
L_058A28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A28u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A28u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A28 STA
    hw.write(cpu.address("dp", 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_058A2A;
L_058A2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Du) & 0xFFFFu), 3u, 0u);
    // $058A2A LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A2C;
L_058A2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A2C STA
    hw.write(cpu.address("dp", 0x6Eu), cpu.a, cpu.m8?8:16);
    goto L_058A2E;
L_058A2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A2E SEP
    cpu.sep(0x20u);
    goto L_058A30;
L_058A30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A30u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A30u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A30 INY
    cpu.inc('Y');
    goto L_058A31;
L_058A31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A31u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A31 INY
    cpu.inc('Y');
    goto L_058A32;
L_058A32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A32u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A32u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $058A32 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A34;
L_058A34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A34u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A34u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A34 STA
    hw.write(cpu.address("dp", 0x6Du), cpu.a, cpu.m8?8:16);
    goto L_058A36;
L_058A36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A36u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A36u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Du) & 0xFFFFu), 3u, 0u);
    // $058A36 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A38;
L_058A38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A38u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A38u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x70u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A38 STA
    hw.write(cpu.address("dp", 0x70u), cpu.a, cpu.m8?8:16);
    goto L_058A3A;
L_058A3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A3A SEP
    cpu.sep(0x10u);
    goto L_058A3C;
L_058A3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A3C LDY
    cpu.setY(0xDu, 8);
    goto L_058A3E;
L_058A3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Eu, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A3E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A41;
L_058A41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A41u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A41 CMP
    cpu.compareA(0x10u);
    goto L_058A43;
L_058A43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A43u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A43 BMI -> $058A47
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_058A47; }
    goto L_058A45;
L_058A45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A45u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A45 LDY
    cpu.setY(0x5u, 8);
    goto L_058A47;
L_058A47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A47u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A47u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A47 STY
    hw.write(cpu.address("dp", 0xCu), cpu.y, cpu.x8?8:16);
    goto L_058A49;
L_058A49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A49u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A49u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A49 REP
    cpu.rep(0x30u);
    goto L_058A4B;
L_058A4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x45u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A4B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A4D;
L_058A4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A4D AND
    cpu.logicAnd(0xFu);
    goto L_058A50;
L_058A50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A50u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A50 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_058A52;
L_058A52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A52u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A52u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A52 LDX
    cpu.setX(0x0u, 16);
    goto L_058A55;
L_058A55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A55u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A55u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A55 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_058A57;
L_058A57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A57u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A57u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $058A57 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A59;
L_058A59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A59u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A59 AND
    cpu.logicAnd(0xFFu);
    goto L_058A5C;
L_058A5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A5C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_058A5E;
L_058A5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Eu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Eu) & 0xFFFFu), 3u, 0u);
    // $058A5E LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x6Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A60;
L_058A60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A60 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_058A62;
L_058A62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A62u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A62u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A62 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A64;
L_058A64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A64u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A64u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A64 ASL
    cpu.aslA();
    goto L_058A65;
L_058A65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A65u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A65 TAY
    cpu.transfer("TAY");
    goto L_058A66;
L_058A66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A66u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A66u, 5u + 1u, 3u, cpu.address("absy", 0x0FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A66 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xFBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A69;
L_058A69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A69u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A69u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A69 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_058A6B;
L_058A6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A6B LDY
    cpu.setY(0x0u, 16);
    goto L_058A6E;
L_058A6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Eu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $058A6E LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A70;
L_058A70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A70u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A70u, 6u, 3u, cpu.address("absx", 0x1BE6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A70 STA
    hw.write(cpu.address("absx", 0x1BE6u), cpu.a, cpu.m8?8:16);
    goto L_058A73;
L_058A73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A73u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A73u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A73 INY
    cpu.inc('Y');
    goto L_058A74;
L_058A74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A74u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A74u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A74 INY
    cpu.inc('Y');
    goto L_058A75;
L_058A75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A75u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A75u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $058A75 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A77;
L_058A77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A77u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A77u, 6u, 3u, cpu.address("absx", 0x1BE8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A77 STA
    hw.write(cpu.address("absx", 0x1BE8u), cpu.a, cpu.m8?8:16);
    goto L_058A7A;
L_058A7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A7A INY
    cpu.inc('Y');
    goto L_058A7B;
L_058A7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A7B INY
    cpu.inc('Y');
    goto L_058A7C;
L_058A7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $058A7C LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A7E;
L_058A7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Eu, 6u, 3u, cpu.address("absx", 0x1C66u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A7E STA
    hw.write(cpu.address("absx", 0x1C66u), cpu.a, cpu.m8?8:16);
    goto L_058A81;
L_058A81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A81 INY
    cpu.inc('Y');
    goto L_058A82;
L_058A82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A82u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A82u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A82 INY
    cpu.inc('Y');
    goto L_058A83;
L_058A83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A83u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A83u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $058A83 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A85;
L_058A85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A85u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A85u, 6u, 3u, cpu.address("absx", 0x1C68u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A85 STA
    hw.write(cpu.address("absx", 0x1C68u), cpu.a, cpu.m8?8:16);
    goto L_058A88;
L_058A88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A88u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A88u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A88 INX
    cpu.inc('X');
    goto L_058A89;
L_058A89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A89 INX
    cpu.inc('X');
    goto L_058A8A;
L_058A8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Au,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A8A INX
    cpu.inc('X');
    goto L_058A8B;
L_058A8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A8B INX
    cpu.inc('X');
    goto L_058A8C;
L_058A8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A8C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058A8E;
L_058A8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A8E CLC
    cpu.setFlag('C', false);
    goto L_058A8F;
L_058A8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A8F ADC
    cpu.adc(0x10u);
    goto L_058A92;
L_058A92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A92u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A92u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A92 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_058A94;
L_058A94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A94u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A94 CMP
    cpu.compareA(0x1B0u);
    goto L_058A97;
L_058A97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A97u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058A97 BCC -> $058A55
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_058A55; }
    goto L_058A99;
L_058A99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A99u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A99u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058A99 PLP
    cpu.pop("PLP", hw);
    goto L_058A9A;
L_058A9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A9Au,0x058A9Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058A9A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058A9Au);return;} hw.unresolvedReturn(0x058A9Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0CCF49_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CCF49u: goto L_0CCF49;
    case 0x0CCF4Cu: goto L_0CCF4C;
    case 0x0CCF4Eu: goto L_0CCF4E;
    case 0x0CCF50u: goto L_0CCF50;
    case 0x0CCF52u: goto L_0CCF52;
    case 0x0CCF55u: goto L_0CCF55;
    case 0x0CCF58u: goto L_0CCF58;
    case 0x0CCF5Bu: goto L_0CCF5B;
    case 0x0CCF5Eu: goto L_0CCF5E;
    case 0x0CCF61u: goto L_0CCF61;
    case 0x0CCF64u: goto L_0CCF64;
    case 0x0CCF67u: goto L_0CCF67;
    case 0x0CCF6Au: goto L_0CCF6A;
    case 0x0CCF6Bu: goto L_0CCF6B;
    case 0x0CCF6Cu: goto L_0CCF6C;
    case 0x0CCF6Du: goto L_0CCF6D;
    case 0x0CCF6Eu: goto L_0CCF6E;
    case 0x0CCF71u: goto L_0CCF71;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CCF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF49u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF49u, 4u, 3u, cpu.address("abs", 0x1440u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF49 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1440u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0CCF4C;
L_0CCF4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Cu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF4C CPY
    cpu.compareY(0xFFu);
    goto L_0CCF4E;
L_0CCF4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF4E BEQ -> $0CCF71
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CCF71; }
    goto L_0CCF50;
L_0CCF50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF50u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF50 LDX
    cpu.setX(0x4u, 8);
    goto L_0CCF52;
L_0CCF52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF52u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF52u, 4u, 3u, cpu.address("abs", 0x0B52u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF52 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xB52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCF55;
L_0CCF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF55u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF55u, 5u, 3u, cpu.address("absx", 0x0200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF55 STA
    hw.write(cpu.address("absx", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_0CCF58;
L_0CCF58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF58u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF58u, 4u, 3u, cpu.address("abs", 0x0B43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF58 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xB43u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCF5B;
L_0CCF5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Bu, 5u, 3u, cpu.address("absx", 0x0201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF5B STA
    hw.write(cpu.address("absx", 0x201u), cpu.a, cpu.m8?8:16);
    goto L_0CCF5E;
L_0CCF5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Eu, 4u + ((((0xCF3Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCF3Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF5E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCF3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCF61;
L_0CCF61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF61u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF61u, 5u, 3u, cpu.address("absx", 0x0202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF61 STA
    hw.write(cpu.address("absx", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_0CCF64;
L_0CCF64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF64u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF64u, 4u + ((((0xCF42u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCF42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF64 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCF42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCF67;
L_0CCF67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF67u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF67u, 5u, 3u, cpu.address("absx", 0x0203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF67 STA
    hw.write(cpu.address("absx", 0x203u), cpu.a, cpu.m8?8:16);
    goto L_0CCF6A;
L_0CCF6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF6A TXA
    cpu.transfer("TXA");
    goto L_0CCF6B;
L_0CCF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF6B LSR
    cpu.lsrA();
    goto L_0CCF6C;
L_0CCF6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF6C LSR
    cpu.lsrA();
    goto L_0CCF6D;
L_0CCF6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF6D TAX
    cpu.transfer("TAX");
    goto L_0CCF6E;
L_0CCF6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Eu, 5u, 3u, cpu.address("absx", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCF6E STZ
    hw.write(cpu.address("absx", 0x420u), 0, cpu.m8?8:16);
    goto L_0CCF71;
L_0CCF71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF71u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF71u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CCF71 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CCF71u);return;} hw.unresolvedReturn(0x0CCF71u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0CD22D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CD22Du: goto L_0CD22D;
    case 0x0CD231u: goto L_0CD231;
    case 0x0CD233u: goto L_0CD233;
    case 0x0CD235u: goto L_0CD235;
    case 0x0CD236u: goto L_0CD236;
    case 0x0CD237u: goto L_0CD237;
    case 0x0CD23Bu: goto L_0CD23B;
    case 0x0CD23Cu: goto L_0CD23C;
    case 0x0CD23Fu: goto L_0CD23F;
    case 0x0CD243u: goto L_0CD243;
    case 0x0CD244u: goto L_0CD244;
    case 0x0CD245u: goto L_0CD245;
    case 0x0CD247u: goto L_0CD247;
    case 0x0CD249u: goto L_0CD249;
    case 0x0CD24Au: goto L_0CD24A;
    case 0x0CD24Eu: goto L_0CD24E;
    case 0x0CD252u: goto L_0CD252;
    case 0x0CD254u: goto L_0CD254;
    case 0x0CD255u: goto L_0CD255;
    case 0x0CD257u: goto L_0CD257;
    case 0x0CD259u: goto L_0CD259;
    case 0x0CD25Cu: goto L_0CD25C;
    case 0x0CD25Du: goto L_0CD25D;
    case 0x0CD25Fu: goto L_0CD25F;
    case 0x0CD260u: goto L_0CD260;
    case 0x0CD261u: goto L_0CD261;
    case 0x0CD262u: goto L_0CD262;
    case 0x0CD264u: goto L_0CD264;
    case 0x0CD265u: goto L_0CD265;
    case 0x0CD267u: goto L_0CD267;
    case 0x0CD269u: goto L_0CD269;
    case 0x0CD26Cu: goto L_0CD26C;
    case 0x0CD270u: goto L_0CD270;
    case 0x0CD273u: goto L_0CD273;
    case 0x0CD277u: goto L_0CD277;
    case 0x0CD279u: goto L_0CD279;
    case 0x0CD27Bu: goto L_0CD27B;
    case 0x0CD27Du: goto L_0CD27D;
    case 0x0CD27Fu: goto L_0CD27F;
    case 0x0CD282u: goto L_0CD282;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CD22D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD22Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD22Du,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD22Du, 5u, 4u, 0x7F837Bu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD22D LDA
    cpu.loadA(hw.readW(0x7F837Bu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD231;
L_0CD231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD231u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD231u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD231 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0CD233;
L_0CD233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD233u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD233u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD233 LDY
    cpu.setY(0xCu, 8);
    goto L_0CD235;
L_0CD235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD235u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD235u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD235 TYA
    cpu.transfer("TYA");
    goto L_0CD236;
L_0CD236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD236u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD236u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD236 CLC
    cpu.setFlag('C', false);
    goto L_0CD237;
L_0CD237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD237u,cpu,0x6Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD237u, 5u, 4u, 0x7F837Bu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD237 ADC
    cpu.adc(hw.readW(0x7F837Bu, cpu.m8?8:16));
    goto L_0CD23B;
L_0CD23B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD23Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD23B TAX
    cpu.transfer("TAX");
    goto L_0CD23C;
L_0CD23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Cu, 4u + ((((0xD1F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD1F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD23C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD1F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD23F;
L_0CD23F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD23Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Fu, 5u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD23F STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0CD243;
L_0CD243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD243u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD243u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD243 DEX
    cpu.decReg('X');
    goto L_0CD244;
L_0CD244:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD244u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD244u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD244u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD244 DEY
    cpu.decReg('Y');
    goto L_0CD245;
L_0CD245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD245u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD245u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD245u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD245 BPL -> $0CD23C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0CD23C; }
    goto L_0CD247;
L_0CD247:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD247u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD247u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD247u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD247 LDA
    cpu.setA(0xCu, 8);
    goto L_0CD249;
L_0CD249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD249u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD249u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD249 CLC
    cpu.setFlag('C', false);
    goto L_0CD24A;
L_0CD24A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD24Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD24Au,cpu,0x6Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD24Au, 5u, 4u, 0x7F837Bu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD24A ADC
    cpu.adc(hw.readW(0x7F837Bu, cpu.m8?8:16));
    goto L_0CD24E;
L_0CD24E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD24Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD24Eu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD24Eu, 5u, 4u, 0x7F837Bu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD24E STA
    hw.write(0x7F837Bu, cpu.a, cpu.m8?8:16);
    goto L_0CD252;
L_0CD252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD252u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD252u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD252 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD254;
L_0CD254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD254u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD254u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD254 SEC
    cpu.setFlag('C', true);
    goto L_0CD255;
L_0CD255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD255u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD255u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD255 SBC
    cpu.sbc(0xA0u);
    goto L_0CD257;
L_0CD257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD257u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD257u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD257 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0CD259;
L_0CD259:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD259u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD259u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD259u, 4u, 3u, cpu.address("abs", 0x1446u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD259 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1446u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD25C;
L_0CD25C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD25Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD25C SEC
    cpu.setFlag('C', true);
    goto L_0CD25D;
L_0CD25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD25D SBC
    cpu.sbc(0x38u);
    goto L_0CD25F;
L_0CD25F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD25Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD25F LSR
    cpu.lsrA();
    goto L_0CD260;
L_0CD260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD260u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD260u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD260 LSR
    cpu.lsrA();
    goto L_0CD261;
L_0CD261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD261u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD261u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD261 CLC
    cpu.setFlag('C', false);
    goto L_0CD262;
L_0CD262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD262u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD262u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD262 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_0CD264;
L_0CD264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD264u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD264u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD264 TAY
    cpu.transfer("TAY");
    goto L_0CD265;
L_0CD265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD265u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD265u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD265 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0CD267;
L_0CD267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD267u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD267u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD267 REP
    cpu.rep(0x20u);
    goto L_0CD269;
L_0CD269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD269u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD269u, 5u + ((((0xD1FDu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD1FDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD269 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD1FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD26C;
L_0CD26C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD26Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD26Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD26Cu, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD26C STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0CD270;
L_0CD270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD270u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD270u, 5u + ((((0xD1FFu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD1FFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD270 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD1FFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD273;
L_0CD273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD273u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD273u, 6u, 4u, ((0x7F8383u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD273 STA
    hw.write(((0x7F8383u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0CD277;
L_0CD277:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD277u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD277u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD277u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD277 SEP
    cpu.sep(0x20u);
    goto L_0CD279;
L_0CD279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD279u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD279u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD279 CPY
    cpu.compareY(0x1Cu);
    goto L_0CD27B;
L_0CD27B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD27Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD27B BNE -> $0CD282
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CD282; }
    goto L_0CD27D;
L_0CD27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD27Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD27D LDA
    cpu.setA(0x1u, 8);
    goto L_0CD27F;
L_0CD27F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD27Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Fu, 4u, 3u, cpu.address("abs", 0x1444u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD27F STA
    hw.write(cpu.address("abs", 0x1444u), cpu.a, cpu.m8?8:16);
    goto L_0CD282;
L_0CD282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD282u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD282u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CD282 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CD282u);return;} hw.unresolvedReturn(0x0CD282u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DA106_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA106u: goto L_0DA106;
    case 0x0DA108u: goto L_0DA108;
    case 0x0DA10Au: goto L_0DA10A;
    case 0x0DA10Bu: goto L_0DA10B;
    case 0x0DA10Fu: goto L_0DA10F;
    case 0x0DA111u: goto L_0DA111;
    case 0x0DA114u: goto L_0DA114;
    case 0x0DA117u: goto L_0DA117;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA106u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA106u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA106 SEP
    cpu.sep(0x30u);
    goto L_0DA108;
L_0DA108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA108u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA108u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA108 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA10A;
L_0DA10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA10A TAX
    cpu.transfer("TAX");
    goto L_0DA10B;
L_0DA10B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Bu, 8u, 4u, 0x0086FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0DA10B JSL -> $0086FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA10Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA10Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086FAu, 0x0DA10Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA10F;
L_0DA10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA10Fu,0x0DA10Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Fu,cpu,0x12u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA5u) & 0xFFFFu), 2u, 0u);
    // $0DA10F ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirect(hw, 0xA5u), cpu.m8?8:16));
    goto L_0DA111;
L_0DA111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA111u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA111u, 4u, 3u, cpu.address("abs", 0xA53Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA111 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xA53Du), cpu.m8?8:16));
    goto L_0DA114;
L_0DA114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA114u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA114u, 4u, 3u, cpu.address("abs", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA114 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x0u), cpu.m8?8:16));
    goto L_0DA117;
L_0DA117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA117u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA117u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0DA117 BRK
    hw.partial(0x0DA117u, "BRK"); return;
}

void sub_0DB2CA_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB2C9u: goto L_0DB2C9;
    case 0x0DB2CAu: goto L_0DB2CA;
    case 0x0DB2CDu: goto L_0DB2CD;
    case 0x0DB2CEu: goto L_0DB2CE;
    case 0x0DB2CFu: goto L_0DB2CF;
    case 0x0DB2D0u: goto L_0DB2D0;
    case 0x0DB2D1u: goto L_0DB2D1;
    case 0x0DB2D4u: goto L_0DB2D4;
    case 0x0DB2D6u: goto L_0DB2D6;
    case 0x0DB2D7u: goto L_0DB2D7;
    case 0x0DB2DAu: goto L_0DB2DA;
    case 0x0DB2DEu: goto L_0DB2DE;
    case 0x0DB2E0u: goto L_0DB2E0;
    case 0x0DB2E3u: goto L_0DB2E3;
    case 0x0DB2E5u: goto L_0DB2E5;
    case 0x0DB2E6u: goto L_0DB2E6;
    case 0x0DB2EAu: goto L_0DB2EA;
    case 0x0DB2ECu: goto L_0DB2EC;
    case 0x0DB2EEu: goto L_0DB2EE;
    case 0x0DB2F2u: goto L_0DB2F2;
    case 0x0DB2F4u: goto L_0DB2F4;
    case 0x0DB2F7u: goto L_0DB2F7;
    case 0x0DB2F8u: goto L_0DB2F8;
    case 0x0DB2F9u: goto L_0DB2F9;
    case 0x0DB2FBu: goto L_0DB2FB;
    case 0x0DB2FDu: goto L_0DB2FD;
    case 0x0DB2FFu: goto L_0DB2FF;
    case 0x0DB301u: goto L_0DB301;
    case 0x0DB303u: goto L_0DB303;
    case 0x0DB305u: goto L_0DB305;
    case 0x0DB307u: goto L_0DB307;
    case 0x0DB309u: goto L_0DB309;
    case 0x0DB30Au: goto L_0DB30A;
    case 0x0DB30Cu: goto L_0DB30C;
    case 0x0DB30Eu: goto L_0DB30E;
    case 0x0DB310u: goto L_0DB310;
    case 0x0DB312u: goto L_0DB312;
    case 0x0DB314u: goto L_0DB314;
    case 0x0DB315u: goto L_0DB315;
    case 0x0DB317u: goto L_0DB317;
    case 0x0DB318u: goto L_0DB318;
    case 0x0DB31Au: goto L_0DB31A;
    case 0x0DB31Cu: goto L_0DB31C;
    case 0x0DB320u: goto L_0DB320;
    case 0x0DB322u: goto L_0DB322;
    case 0x0DB324u: goto L_0DB324;
    case 0x0DB327u: goto L_0DB327;
    case 0x0DB329u: goto L_0DB329;
    case 0x0DB32Bu: goto L_0DB32B;
    case 0x0DB32Eu: goto L_0DB32E;
    case 0x0DB331u: goto L_0DB331;
    case 0x0DB333u: goto L_0DB333;
    case 0x0DB335u: goto L_0DB335;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB2C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB2C9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB2C9u);return;} hw.unresolvedReturn(0x0DB2C9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_0DB2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CAu, 4u, 3u, cpu.address("abs", 0x13BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2CA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13BFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB2CD;
L_0DB2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2CD LSR
    cpu.lsrA();
    goto L_0DB2CE;
L_0DB2CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2CE LSR
    cpu.lsrA();
    goto L_0DB2CF;
L_0DB2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2CF LSR
    cpu.lsrA();
    goto L_0DB2D0;
L_0DB2D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2D0 TAY
    cpu.transfer("TAY");
    goto L_0DB2D1;
L_0DB2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 4u, 3u, cpu.address("abs", 0x13BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2D1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13BFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB2D4;
L_0DB2D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2D4 AND
    cpu.logicAnd(0x7u);
    goto L_0DB2D6;
L_0DB2D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2D6 TAX
    cpu.transfer("TAX");
    goto L_0DB2D7;
L_0DB2D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D7u, 4u + ((((0x1F2Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1F2Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2D7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1F2Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB2DA;
L_0DB2DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DAu,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DAu, 5u, 4u, ((0x0DA8A6u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2DA AND
    cpu.logicAnd(hw.readW(((0xDA8A6u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DB2DE;
L_0DB2DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2DE BNE -> $0DB2C9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB2C9; }
    goto L_0DB2E0;
L_0DB2E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E0u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E0u, 4u, 3u, cpu.address("abs", 0x13BEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2E0 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13BEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB2E3;
L_0DB2E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2E3 LDA
    cpu.setA(0xF8u, 8);
    goto L_0DB2E5;
L_0DB2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2E5 CLC
    cpu.setFlag('C', false);
    goto L_0DB2E6;
L_0DB2E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E6u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E6u, 5u, 4u, ((0x0DA8AEu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2E6 ADC
    cpu.adc(hw.readW(((0xDA8AEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DB2EA;
L_0DB2EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2EA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_0DB2EC;
L_0DB2EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2EC LDA
    cpu.setA(0x19u, 8);
    goto L_0DB2EE;
L_0DB2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 5u, 4u, ((0x0DA8B1u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2EE ADC
    cpu.adc(hw.readW(((0xDA8B1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DB2F2;
L_0DB2F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2F2 STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_0DB2F4;
L_0DB2F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F4u, 4u, 3u, cpu.address("abs", 0x1BA1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2F4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB2F7;
L_0DB2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2F7 ASL
    cpu.aslA();
    goto L_0DB2F8;
L_0DB2F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2F8 ASL
    cpu.aslA();
    goto L_0DB2F9;
L_0DB2F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2F9 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0DB2FB;
L_0DB2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB2FD;
L_0DB2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2FD AND
    cpu.logicAnd(0x10u);
    goto L_0DB2FF;
L_0DB2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2FF BEQ -> $0DB307
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB307; }
    goto L_0DB301;
L_0DB301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB301u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB301 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB303;
L_0DB303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB303 ORA
    cpu.logicOr(0x2u);
    goto L_0DB305;
L_0DB305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB305 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0DB307;
L_0DB307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB307 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB309;
L_0DB309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB309 TYA
    cpu.transfer("TYA");
    goto L_0DB30A;
L_0DB30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB30A AND
    cpu.logicAnd(0x8u);
    goto L_0DB30C;
L_0DB30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB30C BEQ -> $0DB314
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB314; }
    goto L_0DB30E;
L_0DB30E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB30E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB310;
L_0DB310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB310u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB310u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB310 ORA
    cpu.logicOr(0x1u);
    goto L_0DB312;
L_0DB312:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB312u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB312u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB312u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB312 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0DB314;
L_0DB314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB314 TYA
    cpu.transfer("TYA");
    goto L_0DB315;
L_0DB315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB315u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB315u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB315 AND
    cpu.logicAnd(0x7u);
    goto L_0DB317;
L_0DB317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB317u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB317u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB317 TAX
    cpu.transfer("TAX");
    goto L_0DB318;
L_0DB318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB318u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB318u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB318 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB31A;
L_0DB31A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Au,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $0DB31A LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB31C;
L_0DB31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Cu,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Cu, 5u, 4u, ((0x0DA8A6u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB31C AND
    cpu.logicAnd(hw.readW(((0xDA8A6u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DB320;
L_0DB320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB320u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB320u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB320 BNE -> $0DB335
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB335; }
    goto L_0DB322;
L_0DB322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB322 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB324;
L_0DB324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB324u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB324u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB324 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB326u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB327u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB324u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB327;
L_0DB327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB327u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB327u,0x0DB327u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB327u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB327u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB327 LDA
    cpu.setA(0x2Du, 8);
    goto L_0DB329;
L_0DB329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB329u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB329u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB329 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DB32B;
L_0DB32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Bu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB32B JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xB32Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB32Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DB32Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB32E;
L_0DB32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB32Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB32Eu,0x0DB32Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Eu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB32E JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB330u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB331u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB32Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB331;
L_0DB331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB331u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB331u,0x0DB331u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB331u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB331u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB331 LDA
    cpu.setA(0x2Eu, 8);
    goto L_0DB333;
L_0DB333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB333u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB333u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB333 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DB335;
L_0DB335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB335u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB335u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB335 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB335u);return;} hw.unresolvedReturn(0x0DB335u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB461_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB461u: goto L_0DB461;
    case 0x0DB463u: goto L_0DB463;
    case 0x0DB465u: goto L_0DB465;
    case 0x0DB466u: goto L_0DB466;
    case 0x0DB467u: goto L_0DB467;
    case 0x0DB468u: goto L_0DB468;
    case 0x0DB469u: goto L_0DB469;
    case 0x0DB46Bu: goto L_0DB46B;
    case 0x0DB46Du: goto L_0DB46D;
    case 0x0DB46Fu: goto L_0DB46F;
    case 0x0DB471u: goto L_0DB471;
    case 0x0DB472u: goto L_0DB472;
    case 0x0DB475u: goto L_0DB475;
    case 0x0DB477u: goto L_0DB477;
    case 0x0DB479u: goto L_0DB479;
    case 0x0DB47Cu: goto L_0DB47C;
    case 0x0DB47Eu: goto L_0DB47E;
    case 0x0DB481u: goto L_0DB481;
    case 0x0DB482u: goto L_0DB482;
    case 0x0DB484u: goto L_0DB484;
    case 0x0DB487u: goto L_0DB487;
    case 0x0DB48Au: goto L_0DB48A;
    case 0x0DB48Cu: goto L_0DB48C;
    case 0x0DB48Eu: goto L_0DB48E;
    case 0x0DB490u: goto L_0DB490;
    case 0x0DB493u: goto L_0DB493;
    case 0x0DB495u: goto L_0DB495;
    case 0x0DB498u: goto L_0DB498;
    case 0x0DB499u: goto L_0DB499;
    case 0x0DB49Bu: goto L_0DB49B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB461u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB461u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB461 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB463;
L_0DB463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB463u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB463u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB463 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB465;
L_0DB465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB465u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB465u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB465 LSR
    cpu.lsrA();
    goto L_0DB466;
L_0DB466:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB466u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB466u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB466u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB466 LSR
    cpu.lsrA();
    goto L_0DB467;
L_0DB467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB467u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB467u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB467 LSR
    cpu.lsrA();
    goto L_0DB468;
L_0DB468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB468u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB468u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB468u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB468 LSR
    cpu.lsrA();
    goto L_0DB469;
L_0DB469:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB469u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB469u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB469u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB469 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB46B;
L_0DB46B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB46Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB46B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB46D;
L_0DB46D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB46Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB46D AND
    cpu.logicAnd(0xFu);
    goto L_0DB46F;
L_0DB46F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB46Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB46F STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DB471;
L_0DB471:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB471u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB471u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB471u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB471 TAX
    cpu.transfer("TAX");
    goto L_0DB472;
L_0DB472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB472u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB472u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB472 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xB474u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB475u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DB472u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB475;
L_0DB475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB475u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB475u,0x0DB475u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB475u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB475u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB475 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB477;
L_0DB477:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB477u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB477u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB477u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB477 BEQ -> $0DB490
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB490; }
    goto L_0DB479;
L_0DB479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB479u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB479u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB479 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB47Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB47Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB479u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB47C;
L_0DB47C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB47Cu,0x0DB47Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB47C LDA
    cpu.setA(0xBu, 8);
    goto L_0DB47E;
L_0DB47E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Eu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB47E JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB480u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB481u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB47Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB481;
L_0DB481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB481u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB481u,0x0DB481u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB481u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB481u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB481 DEX
    cpu.decReg('X');
    goto L_0DB482;
L_0DB482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB482u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB482u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB482 BPL -> $0DB479
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB479; }
    goto L_0DB484;
L_0DB484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB484u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB484u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB484 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xB486u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB487u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DB484u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB487;
L_0DB487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB487u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB487u,0x0DB487u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB487u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB487u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB487 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xB489u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB48Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DB487u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB48A;
L_0DB48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB48Au,0x0DB48Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Au,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB48A LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB48C;
L_0DB48C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB48C DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DB48E;
L_0DB48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB48E BNE -> $0DB479
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB479; }
    goto L_0DB490;
L_0DB490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB490u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB490u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB490 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB492u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB493u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB490u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB493;
L_0DB493:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB493u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB493u,0x0DB493u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB493u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB493u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB493 LDA
    cpu.setA(0xEu, 8);
    goto L_0DB495;
L_0DB495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB495u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB495u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB495 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB497u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB498u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB495u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB498;
L_0DB498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB498u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB498u,0x0DB498u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB498u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB498u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB498 DEX
    cpu.decReg('X');
    goto L_0DB499;
L_0DB499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB499u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB499u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB499 BPL -> $0DB490
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB490; }
    goto L_0DB49B;
L_0DB49B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB49B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB49Bu);return;} hw.unresolvedReturn(0x0DB49Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB705_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB705u: goto L_0DB705;
    case 0x0DB707u: goto L_0DB707;
    case 0x0DB709u: goto L_0DB709;
    case 0x0DB70Au: goto L_0DB70A;
    case 0x0DB70Bu: goto L_0DB70B;
    case 0x0DB70Cu: goto L_0DB70C;
    case 0x0DB70Du: goto L_0DB70D;
    case 0x0DB70Fu: goto L_0DB70F;
    case 0x0DB711u: goto L_0DB711;
    case 0x0DB713u: goto L_0DB713;
    case 0x0DB714u: goto L_0DB714;
    case 0x0DB717u: goto L_0DB717;
    case 0x0DB71Bu: goto L_0DB71B;
    case 0x0DB71Eu: goto L_0DB71E;
    case 0x0DB721u: goto L_0DB721;
    case 0x0DB725u: goto L_0DB725;
    case 0x0DB727u: goto L_0DB727;
    case 0x0DB72Au: goto L_0DB72A;
    case 0x0DB72Cu: goto L_0DB72C;
    case 0x0DB72Eu: goto L_0DB72E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB705u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB705u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB705 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB707;
L_0DB707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB707u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB707u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB707 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB709;
L_0DB709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB709u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB709u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB709 LSR
    cpu.lsrA();
    goto L_0DB70A;
L_0DB70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB70A LSR
    cpu.lsrA();
    goto L_0DB70B;
L_0DB70B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB70B LSR
    cpu.lsrA();
    goto L_0DB70C;
L_0DB70C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB70C LSR
    cpu.lsrA();
    goto L_0DB70D;
L_0DB70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB70D STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB70F;
L_0DB70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB70F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB711;
L_0DB711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB711u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB711u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB711 AND
    cpu.logicAnd(0xFu);
    goto L_0DB713;
L_0DB713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB713u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB713u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB713 TAX
    cpu.transfer("TAX");
    goto L_0DB714;
L_0DB714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB714u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB714u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB714 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB716u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB717u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB714u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB717;
L_0DB717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB717u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB717u,0x0DB717u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB717u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB717u, 5u, 4u, ((0x0DB6F5u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB717 LDA
    cpu.loadA(hw.readW(((0xDB6F5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB71B;
L_0DB71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Bu, 3u, 3u, cpu.address("abs", 0xB725u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB71B JMP -> $0DB725
    goto L_0DB725;
L_0DB71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Eu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB71E JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB720u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB721u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB71Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB721;
L_0DB721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB721u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB721u,0x0DB721u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB721u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB721u, 5u, 4u, ((0x0DB6FDu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB721 LDA
    cpu.loadA(hw.readW(((0xDB6FDu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB725;
L_0DB725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB725u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB725u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB725 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DB727;
L_0DB727:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB727u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB727u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB727u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB727 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xB729u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB72Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DB727u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB72A;
L_0DB72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB72Au,0x0DB72Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Au,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB72A DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DB72C;
L_0DB72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB72C BPL -> $0DB71E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB71E; }
    goto L_0DB72E;
L_0DB72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB72E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB72Eu);return;} hw.unresolvedReturn(0x0DB72Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DEA3E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DEA3Eu: goto L_0DEA3E;
    case 0x0DEA40u: goto L_0DEA40;
    case 0x0DEA42u: goto L_0DEA42;
    case 0x0DEA43u: goto L_0DEA43;
    case 0x0DEA45u: goto L_0DEA45;
    case 0x0DEA46u: goto L_0DEA46;
    case 0x0DEA47u: goto L_0DEA47;
    case 0x0DEA48u: goto L_0DEA48;
    case 0x0DEA49u: goto L_0DEA49;
    case 0x0DEA4Au: goto L_0DEA4A;
    case 0x0DEA4Cu: goto L_0DEA4C;
    case 0x0DEA4Eu: goto L_0DEA4E;
    case 0x0DEA50u: goto L_0DEA50;
    case 0x0DEA53u: goto L_0DEA53;
    case 0x0DEA56u: goto L_0DEA56;
    case 0x0DEA5Au: goto L_0DEA5A;
    case 0x0DEA5Du: goto L_0DEA5D;
    case 0x0DEA5Eu: goto L_0DEA5E;
    case 0x0DEA60u: goto L_0DEA60;
    case 0x0DEA62u: goto L_0DEA62;
    case 0x0DEA65u: goto L_0DEA65;
    case 0x0DEA68u: goto L_0DEA68;
    case 0x0DEA6Au: goto L_0DEA6A;
    case 0x0DEA6Cu: goto L_0DEA6C;
    case 0x0DEA6Eu: goto L_0DEA6E;
    case 0x0DEA70u: goto L_0DEA70;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DEA3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA3E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DEA40;
L_0DEA40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA40u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA40u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA40 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DEA42;
L_0DEA42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA42 SEC
    cpu.setFlag('C', true);
    goto L_0DEA43;
L_0DEA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA43u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA43 SBC
    cpu.sbc(0x66u);
    goto L_0DEA45;
L_0DEA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA45 ASL
    cpu.aslA();
    goto L_0DEA46;
L_0DEA46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA46u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA46 ASL
    cpu.aslA();
    goto L_0DEA47;
L_0DEA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA47 ASL
    cpu.aslA();
    goto L_0DEA48;
L_0DEA48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA48u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA48 ASL
    cpu.aslA();
    goto L_0DEA49;
L_0DEA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA49 TAX
    cpu.transfer("TAX");
    goto L_0DEA4A;
L_0DEA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA4A LDA
    cpu.setA(0x3u, 8);
    goto L_0DEA4C;
L_0DEA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA4C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DEA4E;
L_0DEA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA4E STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DEA50;
L_0DEA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA50u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA50u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEA50 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xEA52u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA53u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DEA50u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEA53;
L_0DEA53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA53u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA53u,0x0DEA53u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEA53 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xEA55u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA56u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DEA53u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEA56;
L_0DEA56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA56u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA56u,0x0DEA56u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA56u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA56u, 5u, 4u, ((0x0DEA1Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA56 LDA
    cpu.loadA(hw.readW(((0xDEA1Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DEA5A;
L_0DEA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Au, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEA5A JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xEA5Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA5Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DEA5Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEA5D;
L_0DEA5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA5Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA5Du,0x0DEA5Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA5D INX
    cpu.inc('X');
    goto L_0DEA5E;
L_0DEA5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA5E DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DEA60;
L_0DEA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA60 BPL -> $0DEA53
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DEA53; }
    goto L_0DEA62;
L_0DEA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEA62 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xEA64u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA65u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DEA62u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEA65;
L_0DEA65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA65u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA65u,0x0DEA65u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEA65 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xEA67u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA68u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DEA65u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEA68;
L_0DEA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA68u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA68u,0x0DEA68u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA68u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA68 LDA
    cpu.setA(0x3u, 8);
    goto L_0DEA6A;
L_0DEA6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA6A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DEA6C;
L_0DEA6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA6C DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DEA6E;
L_0DEA6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA6E BPL -> $0DEA53
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DEA53; }
    goto L_0DEA70;
L_0DEA70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA70u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA70u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEA70 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DEA70u);return;} hw.unresolvedReturn(0x0DEA70u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A87E_E0M1X1C0_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A87Eu: goto L_B1A87E;
    case 0xB1A881u: goto L_B1A881;
    case 0xB1A884u: goto L_B1A884;
    case 0xB1A886u: goto L_B1A886;
    case 0xB1A888u: goto L_B1A888;
    case 0xB1A88Bu: goto L_B1A88B;
    case 0xB1A88Eu: goto L_B1A88E;
    case 0xB1A890u: goto L_B1A890;
    case 0xB1A892u: goto L_B1A892;
    case 0xB1A895u: goto L_B1A895;
    case 0xB1A896u: goto L_B1A896;
    case 0xB1A897u: goto L_B1A897;
    case 0xB1A899u: goto L_B1A899;
    case 0xB1A89Bu: goto L_B1A89B;
    case 0xB1A89Du: goto L_B1A89D;
    case 0xB1A89Eu: goto L_B1A89E;
    case 0xB1A8A0u: goto L_B1A8A0;
    case 0xB1A8A2u: goto L_B1A8A2;
    case 0xB1A8A4u: goto L_B1A8A4;
    case 0xB1A8A5u: goto L_B1A8A5;
    case 0xB1A8A7u: goto L_B1A8A7;
    case 0xB1A8A9u: goto L_B1A8A9;
    case 0xB1A8ABu: goto L_B1A8AB;
    case 0xB1A8ACu: goto L_B1A8AC;
    case 0xB1A8AEu: goto L_B1A8AE;
    case 0xB1A8B0u: goto L_B1A8B0;
    case 0xB1A8B2u: goto L_B1A8B2;
    case 0xB1A8B4u: goto L_B1A8B4;
    case 0xB1A8B7u: goto L_B1A8B7;
    case 0xB1A8B9u: goto L_B1A8B9;
    case 0xB1A8BBu: goto L_B1A8BB;
    case 0xB1A8BEu: goto L_B1A8BE;
    case 0xB1A8C0u: goto L_B1A8C0;
    case 0xB1A8C3u: goto L_B1A8C3;
    case 0xB1A8C5u: goto L_B1A8C5;
    case 0xB1A8C7u: goto L_B1A8C7;
    case 0xB1A8C9u: goto L_B1A8C9;
    case 0xB1A8CCu: goto L_B1A8CC;
    case 0xB1A8CEu: goto L_B1A8CE;
    case 0xB1A8D0u: goto L_B1A8D0;
    case 0xB1A8D3u: goto L_B1A8D3;
    case 0xB1A8D6u: goto L_B1A8D6;
    case 0xB1A8D8u: goto L_B1A8D8;
    case 0xB1A8DAu: goto L_B1A8DA;
    case 0xB1A8DDu: goto L_B1A8DD;
    case 0xB1A8E1u: goto L_B1A8E1;
    case 0xB1A8E5u: goto L_B1A8E5;
    case 0xB1A8E6u: goto L_B1A8E6;
    case 0xB1A8E9u: goto L_B1A8E9;
    case 0xB1A8EBu: goto L_B1A8EB;
    case 0xB1A8EEu: goto L_B1A8EE;
    case 0xB1A8F0u: goto L_B1A8F0;
    case 0xB1A8F2u: goto L_B1A8F2;
    case 0xB1A8F5u: goto L_B1A8F5;
    case 0xB1A8F8u: goto L_B1A8F8;
    case 0xB1A8F9u: goto L_B1A8F9;
    case 0xB1A8FCu: goto L_B1A8FC;
    case 0xB1A8FEu: goto L_B1A8FE;
    case 0xB1A901u: goto L_B1A901;
    case 0xB1A903u: goto L_B1A903;
    case 0xB1A906u: goto L_B1A906;
    case 0xB1A908u: goto L_B1A908;
    case 0xB1A90Au: goto L_B1A90A;
    case 0xB1A90Du: goto L_B1A90D;
    case 0xB1A90Eu: goto L_B1A90E;
    case 0xB1A911u: goto L_B1A911;
    case 0xB1A913u: goto L_B1A913;
    case 0xB1A915u: goto L_B1A915;
    case 0xB1A917u: goto L_B1A917;
    case 0xB1A91Bu: goto L_B1A91B;
    case 0xB1A91Cu: goto L_B1A91C;
    case 0xB1A91Fu: goto L_B1A91F;
    case 0xB1A922u: goto L_B1A922;
    case 0xB1A924u: goto L_B1A924;
    case 0xB1A928u: goto L_B1A928;
    case 0xB1A92Au: goto L_B1A92A;
    case 0xB1A92Cu: goto L_B1A92C;
    case 0xB1A92Fu: goto L_B1A92F;
    case 0xB1A931u: goto L_B1A931;
    case 0xB1A935u: goto L_B1A935;
    case 0xB1A938u: goto L_B1A938;
    case 0xB1A93Cu: goto L_B1A93C;
    case 0xB1A93Fu: goto L_B1A93F;
    case 0xB1A941u: goto L_B1A941;
    case 0xB1A944u: goto L_B1A944;
    case 0xB1A947u: goto L_B1A947;
    case 0xB1A94Au: goto L_B1A94A;
    case 0xB1A94Du: goto L_B1A94D;
    case 0xB1A94Fu: goto L_B1A94F;
    case 0xB1A952u: goto L_B1A952;
    case 0xB1A954u: goto L_B1A954;
    case 0xB1A956u: goto L_B1A956;
    case 0xB1A958u: goto L_B1A958;
    case 0xB1A95Au: goto L_B1A95A;
    case 0xB1A95Cu: goto L_B1A95C;
    case 0xB1A95Du: goto L_B1A95D;
    case 0xB1A960u: goto L_B1A960;
    case 0xB1A962u: goto L_B1A962;
    case 0xB1A965u: goto L_B1A965;
    case 0xB1A967u: goto L_B1A967;
    case 0xB1A969u: goto L_B1A969;
    case 0xB1A96Bu: goto L_B1A96B;
    case 0xB1A96Du: goto L_B1A96D;
    case 0xB1A96Eu: goto L_B1A96E;
    case 0xB1A96Fu: goto L_B1A96F;
    case 0xB1A973u: goto L_B1A973;
    case 0xB1A974u: goto L_B1A974;
    case 0xB1A975u: goto L_B1A975;
    case 0xB1A977u: goto L_B1A977;
    case 0xB1A979u: goto L_B1A979;
    case 0xB1A97Bu: goto L_B1A97B;
    case 0xB1A97Du: goto L_B1A97D;
    case 0xB1A97Fu: goto L_B1A97F;
    case 0xB1A981u: goto L_B1A981;
    case 0xB1A983u: goto L_B1A983;
    case 0xB1A986u: goto L_B1A986;
    case 0xB1A988u: goto L_B1A988;
    case 0xB1A98Au: goto L_B1A98A;
    case 0xB1A98Cu: goto L_B1A98C;
    case 0xB1A98Eu: goto L_B1A98E;
    case 0xB1A990u: goto L_B1A990;
    case 0xB1A993u: goto L_B1A993;
    case 0xB1A996u: goto L_B1A996;
    case 0xB1A998u: goto L_B1A998;
    case 0xB1A99Bu: goto L_B1A99B;
    case 0xB1A99Du: goto L_B1A99D;
    case 0xB1A9A0u: goto L_B1A9A0;
    case 0xB1A9A2u: goto L_B1A9A2;
    case 0xB1A9A4u: goto L_B1A9A4;
    case 0xB1A9A8u: goto L_B1A9A8;
    case 0xB1A9ABu: goto L_B1A9AB;
    case 0xB1A9ADu: goto L_B1A9AD;
    case 0xB1A9AFu: goto L_B1A9AF;
    case 0xB1A9B2u: goto L_B1A9B2;
    case 0xB1A9B4u: goto L_B1A9B4;
    case 0xB1A9B6u: goto L_B1A9B6;
    case 0xB1A9B8u: goto L_B1A9B8;
    case 0xB1A9BAu: goto L_B1A9BA;
    case 0xB1A9BDu: goto L_B1A9BD;
    case 0xB1A9BEu: goto L_B1A9BE;
    case 0xB1A9C0u: goto L_B1A9C0;
    case 0xB1A9C1u: goto L_B1A9C1;
    case 0xB1A9C3u: goto L_B1A9C3;
    case 0xB1A9C5u: goto L_B1A9C5;
    case 0xB1A9C7u: goto L_B1A9C7;
    case 0xB1A9CAu: goto L_B1A9CA;
    case 0xB1A9CCu: goto L_B1A9CC;
    case 0xB1A9CFu: goto L_B1A9CF;
    case 0xB1A9D1u: goto L_B1A9D1;
    case 0xB1A9D3u: goto L_B1A9D3;
    case 0xB1A9D5u: goto L_B1A9D5;
    case 0xB1A9D8u: goto L_B1A9D8;
    case 0xB1A9DAu: goto L_B1A9DA;
    case 0xB1A9DDu: goto L_B1A9DD;
    case 0xB1A9DFu: goto L_B1A9DF;
    case 0xB1A9E1u: goto L_B1A9E1;
    case 0xB1A9E2u: goto L_B1A9E2;
    case 0xB1A9E5u: goto L_B1A9E5;
    case 0xB1A9E7u: goto L_B1A9E7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A87E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Eu, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A87E STZ
    hw.write(cpu.address("abs", 0x18D2u), 0, cpu.m8?8:16);
    goto L_B1A881;
L_B1A881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u, 4u + ((((0x154Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A881 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x154Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A884;
L_B1A884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A884 BNE -> $B1A895
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A895; }
    goto L_B1A886;
L_B1A886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA886u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA886u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A886 LDA
    cpu.setA(0x8u, 8);
    goto L_B1A888;
L_B1A888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA888u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA888u, 5u, 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A888 STA
    hw.write(cpu.address("absx", 0x154Cu), cpu.a, cpu.m8?8:16);
    goto L_B1A88B;
L_B1A88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Bu, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A88B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A88E;
L_B1A88E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A88E CMP
    cpu.compareA(0x9u);
    goto L_B1A890;
L_B1A890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA890u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA890u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA890u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A890 BNE -> $B1A897
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A897; }
    goto L_B1A892;
L_B1A892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA892u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA892u, 6u, 3u, cpu.address("abs", 0xAA42u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A892 JSR -> $B1AA42 stack real
    { cpu.push16Value(hw,0xA894u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA895u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA42u), 0xB1A892u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A895;
L_B1A895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA895u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA895u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA895u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A895 CLC
    cpu.setFlag('C', false);
    goto L_B1A896;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA895u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA895u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A895 CLC
    cpu.setFlag('C', false);
    goto L_B1A896;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA895u,0xB1A895u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA896u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA896u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A896 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A896u);return;} hw.unresolvedReturn(0xB1A896u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A897 LDA
    cpu.setA(0x14u, 8);
    goto L_B1A899;
L_B1A899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A899 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_B1A89B;
L_B1A89B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A89B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A89D;
L_B1A89D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A89D SEC
    cpu.setFlag('C', true);
    goto L_B1A89E;
L_B1A89E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Eu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A89E SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16));
    goto L_B1A8A0;
L_B1A8A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A0u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8A0 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_B1A8A2;
L_B1A8A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A2u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8A2 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xD3u), cpu.m8?8:16));
    goto L_B1A8A4;
L_B1A8A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A4u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A8A4 PHP
    cpu.push("PHP", hw);
    goto L_B1A8A5;
L_B1A8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A5u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8A5 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_B1A8A7;
L_B1A8A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8A7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8A9;
L_B1A8A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8A9 SBC
    cpu.sbc(0x0u);
    goto L_B1A8AB;
L_B1A8AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ABu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ABu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A8AB PLP
    cpu.pop("PLP", hw);
    goto L_B1A8AC;
L_B1A8AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8ACu,0xB1A8ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ACu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8AC SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xD4u), cpu.m8?8:16));
    goto L_B1A8AE;
L_B1A8AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8AEu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8AE BMI -> $B1A8E6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_B1A8E6; }
    goto L_B1A8B0;
L_B1A8B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8B0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8B2;
L_B1A8B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8B2 BPL -> $B1A8C0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_B1A8C0; }
    goto L_B1A8B4;
L_B1A8B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B4u, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8B4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8B7;
L_B1A8B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8B7 AND
    cpu.logicAnd(0x10u);
    goto L_B1A8B9;
L_B1A8B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8B9 BNE -> $B1A8C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A8C0; }
    goto L_B1A8BB;
L_B1A8BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BBu, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8BB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1697u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8BE;
L_B1A8BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8BE BEQ -> $B1A8E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A8E6; }
    goto L_B1A8C0;
L_B1A8C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C0u, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A8C0 JSR -> $B1800E stack real
    { cpu.push16Value(hw,0xA8C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8C3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0xB1A8C0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A8C3;
L_B1A8C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8C3u,0xB1A8C3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8C3 BEQ -> $B1A8C9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A8C9; }
    goto L_B1A8C5;
L_B1A8C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8C7;
L_B1A8C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8C7 BEQ -> $B1A8E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A8E6; }
    goto L_B1A8C9;
L_B1A8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C9u, 4u + ((((0x1656u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1656u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8C9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1656u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8CC;
L_B1A8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8CC AND
    cpu.logicAnd(0x10u);
    goto L_B1A8CE;
L_B1A8CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8CE BNE -> $B1A91C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A91C; }
    goto L_B1A8D0;
L_B1A8D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D0u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8D0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x140Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8D3;
L_B1A8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D3u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D3u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8D3 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16));
    goto L_B1A8D6;
L_B1A8D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8D6 BEQ -> $B1A8E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A8E6; }
    goto L_B1A8D8;
L_B1A8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8D8 LDA
    cpu.setA(0x2u, 8);
    goto L_B1A8DA;
L_B1A8DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8DA STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_B1A8DD;
L_B1A8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DDu, 8u, 4u, 0x01AA33u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A8DD JSL -> $01AA33 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA8E0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8E1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AA33u, 0xB1A8DDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A8E1;
L_B1A8E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8E1u,0xB1A8E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E1u, 8u, 4u, 0x01AB99u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A8E1 JSL -> $01AB99 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA8E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8E5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB99u, 0xB1A8E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A8E5;
L_B1A8E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8E5u,0xB1A8E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A8E5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A8E5u);return;} hw.unresolvedReturn(0xB1A8E5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E6u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8E6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13EDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8E9;
L_B1A8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8E9 BEQ -> $B1A8F9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A8F9; }
    goto L_B1A8EB;
L_B1A8EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EBu, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8EB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8EE;
L_B1A8EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8EE AND
    cpu.logicAnd(0x4u);
    goto L_B1A8F0;
L_B1A8F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8F0 BNE -> $B1A8F9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A8F9; }
    goto L_B1A8F2;
L_B1A8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u, 6u, 3u, cpu.address("abs", 0xA728u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A8F2 JSR -> $B1A728 stack real
    { cpu.push16Value(hw,0xA8F4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8F5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA728u), 0xB1A8F2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A8F5;
L_B1A8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8F5u,0xB1A8F5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F5u, 6u, 3u, cpu.address("abs", 0xA847u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A8F5 JSR -> $B1A847 stack real
    { cpu.push16Value(hw,0xA8F7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8F8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA847u), 0xB1A8F5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A8F8;
L_B1A8F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8F8u,0xB1A8F8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A8F8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A8F8u);return;} hw.unresolvedReturn(0xB1A8F8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u, 4u, 3u, cpu.address("abs", 0x1497u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8F9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1497u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A8FC;
L_B1A8FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8FC BNE -> $B1A91B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A91B; }
    goto L_B1A8FE;
L_B1A8FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FEu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A8FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A901;
L_B1A901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA901u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA901u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A901 BNE -> $B1A91B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A91B; }
    goto L_B1A903;
L_B1A903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u, 4u + ((((0x1686u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A903 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1686u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A906;
L_B1A906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA906u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA906u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A906 AND
    cpu.logicAnd(0x10u);
    goto L_B1A908;
L_B1A908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A908 BNE -> $B1A911
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A911; }
    goto L_B1A90A;
L_B1A90A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Au, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A90A JSR -> $B1AD30 stack real
    { cpu.push16Value(hw,0xA90Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA90Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0xB1A90Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A90D;
L_B1A90D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA90Du,0xB1A90Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A90D TYA
    cpu.transfer("TYA");
    goto L_B1A90E;
L_B1A90E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A90E STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_B1A911;
L_B1A911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA911u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA911u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A911 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A913;
L_B1A913:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA913u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A913 CMP
    cpu.compareA(0x53u);
    goto L_B1A915;
L_B1A915:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA915u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA915u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA915u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A915 BEQ -> $B1A91B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A91B; }
    goto L_B1A917;
L_B1A917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA917u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA917u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA917u, 8u, 4u, 0x00F5B7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A917 JSL -> $00F5B7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA91Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA91Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F5B7u, 0xB1A917u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A91B;
L_B1A91B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA91Bu,0xB1A91Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A91B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A91Bu);return;} hw.unresolvedReturn(0xB1A91Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A91C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Cu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A91C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x140Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A91F;
L_B1A91F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Fu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Fu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A91F ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16));
    goto L_B1A922;
L_B1A922:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA922u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA922u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA922u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A922 BEQ -> $B1A947
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A947; }
    goto L_B1A924;
L_B1A924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA924u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA924u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA924u, 8u, 4u, 0x01AB99u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A924 JSL -> $01AB99 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA927u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA928u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB99u, 0xB1A924u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A928;
L_B1A928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA928u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA928u,0xB1A928u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA928u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA928u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A928 LDA
    cpu.setA(0xF8u, 8);
    goto L_B1A92A;
L_B1A92A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A92A STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_B1A92C;
L_B1A92C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Cu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A92C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A92F;
L_B1A92F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A92F BEQ -> $B1A935
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A935; }
    goto L_B1A931;
L_B1A931:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA931u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA931u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA931u, 8u, 4u, 0x01AA33u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A931 JSL -> $01AA33 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA934u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA935u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AA33u, 0xB1A931u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A935;
L_B1A935:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA935u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA935u,0xB1A935u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA935u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA935u, 6u, 3u, cpu.address("abs", 0x9ACBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A935 JSR -> $B19ACB stack real
    { cpu.push16Value(hw,0xA937u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA938u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9ACBu), 0xB1A935u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A938;
L_B1A938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA938u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA938u,0xB1A938u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA938u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA938u, 8u, 4u, 0x07FC3Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A938 JSL -> $07FC3B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA93Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA93Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07FC3Bu, 0xB1A938u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A93C;
L_B1A93C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA93Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA93Cu,0xB1A93Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Cu, 6u, 3u, cpu.address("abs", 0xAB46u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A93C JSR -> $B1AB46 stack real
    { cpu.push16Value(hw,0xA93Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA93Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAB46u), 0xB1A93Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A93F;
L_B1A93F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA93Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA93Fu,0xB1A93Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A93F LDA
    cpu.setA(0x8u, 8);
    goto L_B1A941;
L_B1A941:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA941u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA941u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA941u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A941 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_B1A944;
L_B1A944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA944u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA944u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA944u, 3u, 3u, cpu.address("abs", 0xA9F2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A944 JMP -> $B1A9F2
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xA9F2u),0xB1A944u); return;
L_B1A947:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA947u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA947u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA947u, 6u, 3u, cpu.address("abs", 0xA8D8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A947 JSR -> $B1A8D8 stack real
    { cpu.push16Value(hw,0xA949u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA94Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA8D8u), 0xB1A947u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A94A;
L_B1A94A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA94Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA94Au,0xB1A94Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Au, 4u + ((((0x187Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x187Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A94A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x187Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A94D;
L_B1A94D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA94Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A94D BEQ -> $B1A95D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A95D; }
    goto L_B1A94F;
L_B1A94F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA94Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Fu, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A94F JSR -> $B1AD30 stack real
    { cpu.push16Value(hw,0xA951u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA952u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0xB1A94Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A952;
L_B1A952:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA952u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA952u,0xB1A952u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA952u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA952u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A952 LDA
    cpu.setA(0x18u, 8);
    goto L_B1A954;
L_B1A954:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA954u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA954u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA954u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A954 CPY
    cpu.compareY(0x0u);
    goto L_B1A956;
L_B1A956:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA956u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA956u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA956u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A956 BEQ -> $B1A95A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A95A; }
    goto L_B1A958;
L_B1A958:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA958u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA958u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA958u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A958 LDA
    cpu.setA(0xE8u, 8);
    goto L_B1A95A;
L_B1A95A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A95A STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_B1A95C;
L_B1A95C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A95C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A95Cu);return;} hw.unresolvedReturn(0xB1A95Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Du, 6u, 3u, cpu.address("abs", 0xAB46u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A95D JSR -> $B1AB46 stack real
    { cpu.push16Value(hw,0xA95Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA960u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAB46u), 0xB1A95Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A960;
L_B1A960:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA960u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA960u,0xB1A960u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA960u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA960u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A960 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A962;
L_B1A962:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA962u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA962u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA962u, 4u + ((((0x1686u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A962 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1686u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A965;
L_B1A965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA965u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA965u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A965 AND
    cpu.logicAnd(0x40u);
    goto L_B1A967;
L_B1A967:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA967u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA967u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA967u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A967 BEQ -> $B1A9BE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A9BE; }
    goto L_B1A969;
L_B1A969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA969u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA969u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA969u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A969 CPY
    cpu.compareY(0x72u);
    goto L_B1A96B;
L_B1A96B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A96B BCC -> $B1A979
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A979; }
    goto L_B1A96D;
L_B1A96D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Du,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A96D PHX
    cpu.push("PHX", hw);
    goto L_B1A96E;
L_B1A96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Eu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A96E PHY
    cpu.push("PHY", hw);
    goto L_B1A96F;
L_B1A96F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Fu, 8u, 4u, 0x02EAF2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A96F JSL -> $02EAF2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA972u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA973u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02EAF2u, 0xB1A96Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A973;
L_B1A973:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA973u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA973u,0xB1A973u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA973u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA973u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A973 PLY
    cpu.pop("PLY", hw);
    goto L_B1A974;
L_B1A974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA974u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA974u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A974 PLX
    cpu.pop("PLX", hw);
    goto L_B1A975;
L_B1A975:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA975u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA975u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA975u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A975 LDA
    cpu.setA(0x2u, 8);
    goto L_B1A977;
L_B1A977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA977u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA977u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A977 BRA -> $B1A99B
    goto L_B1A99B;
L_B1A979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA979u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA979u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A979 CPY
    cpu.compareY(0x6Eu);
    goto L_B1A97B;
L_B1A97B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A97B BNE -> $B1A98A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A98A; }
    goto L_B1A97D;
L_B1A97D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A97D LDA
    cpu.setA(0x2u, 8);
    goto L_B1A97F;
L_B1A97F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA97Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA97Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A97F STA
    hw.write(cpu.address("dpx", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_B1A981;
L_B1A981:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA981u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA981u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA981u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A981 LDA
    cpu.setA(0xFFu, 8);
    goto L_B1A983;
L_B1A983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA983u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA983u, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A983 STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B1A986;
L_B1A986:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA986u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA986u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA986u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A986 LDA
    cpu.setA(0x6Fu, 8);
    goto L_B1A988;
L_B1A988:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA988u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA988u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA988u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A988 BRA -> $B1A99B
    goto L_B1A99B;
L_B1A98A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Au,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A98A CPY
    cpu.compareY(0x3Fu);
    goto L_B1A98C;
L_B1A98C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A98C BCC -> $B1A998
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A998; }
    goto L_B1A98E;
L_B1A98E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A98E LDA
    cpu.setA(0x80u, 8);
    goto L_B1A990;
L_B1A990:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA990u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA990u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA990u, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A990 STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B1A993;
L_B1A993:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA993u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA993u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA993u, 4u + ((((0xA79Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA79Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A993 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA79Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A996;
L_B1A996:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA996u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA996u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA996u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A996 BRA -> $B1A99B
    goto L_B1A99B;
L_B1A998:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA998u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA998u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA998u, 4u + ((((0xA7C9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA7C9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A998 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA7C9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A99B;
L_B1A99B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA99Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA99Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA99Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A99B STA
    hw.write(cpu.address("dpx", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_B1A99D;
L_B1A99D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA99Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA99Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA99Du, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A99D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9A0;
L_B1A9A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9A0 AND
    cpu.logicAnd(0xEu);
    goto L_B1A9A2;
L_B1A9A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9A2 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_B1A9A4;
L_B1A9A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A4u, 8u, 4u, 0x07F78Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A9A4 JSL -> $07F78B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA9A7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA9A8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F78Bu, 0xB1A9A4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A9A8;
L_B1A9A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9A8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA9A8u,0xB1A9A8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A8u, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9A8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9AB;
L_B1A9AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ABu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9AB AND
    cpu.logicAnd(0xF1u);
    goto L_B1A9AD;
L_B1A9AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ADu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9AD ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16));
    goto L_B1A9AF;
L_B1A9AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9AFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9AFu, 5u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9AF STA
    hw.write(cpu.address("absx", 0x15F6u), cpu.a, cpu.m8?8:16);
    goto L_B1A9B2;
L_B1A9B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B2u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9B2 STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_B1A9B4;
L_B1A9B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9B4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9B6;
L_B1A9B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9B6 CMP
    cpu.compareA(0x2u);
    goto L_B1A9B8;
L_B1A9B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9B8 BNE -> $B1A9BD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A9BD; }
    goto L_B1A9BA;
L_B1A9BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9BAu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9BAu, 7u, 3u, cpu.address("absx", 0x151Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9BA INC
    cpu.incMem(hw, cpu.address("absx", 0x151Cu), cpu.m8?8:16);
    goto L_B1A9BD;
L_B1A9BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9BDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9BDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A9BD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A9BDu);return;} hw.unresolvedReturn(0xB1A9BDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A9BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9BEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9BE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9C0;
L_B1A9C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9C0 SEC
    cpu.setFlag('C', true);
    goto L_B1A9C1;
L_B1A9C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C1u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9C1 SBC
    cpu.sbc(0x4u);
    goto L_B1A9C3;
L_B1A9C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9C3 CMP
    cpu.compareA(0xDu);
    goto L_B1A9C5;
L_B1A9C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9C5 BCS -> $B1A9CC
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A9CC; }
    goto L_B1A9C7;
L_B1A9C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C7u, 4u, 3u, cpu.address("abs", 0x1407u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9C7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1407u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9CA;
L_B1A9CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9CA BNE -> $B1A9D3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A9D3; }
    goto L_B1A9CC;
L_B1A9CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CCu, 4u + ((((0x1656u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1656u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9CC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1656u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9CF;
L_B1A9CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9CF AND
    cpu.logicAnd(0x20u);
    goto L_B1A9D1;
L_B1A9D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9D1 BEQ -> $B1A9E2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A9E2; }
    goto L_B1A9D3;
L_B1A9D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9D3 LDA
    cpu.setA(0x3u, 8);
    goto L_B1A9D5;
L_B1A9D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D5u, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9D5 STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A9D8;
L_B1A9D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9D8 LDA
    cpu.setA(0x20u, 8);
    goto L_B1A9DA;
L_B1A9DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DAu, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9DA STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B1A9DD;
L_B1A9DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DDu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9DD STZ
    hw.write(cpu.address("dpx", 0xB6u), 0, cpu.m8?8:16);
    goto L_B1A9DF;
L_B1A9DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DFu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9DF STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_B1A9E1;
L_B1A9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A9E1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A9E1u);return;} hw.unresolvedReturn(0xB1A9E1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A9E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E2u, 4u + ((((0x1662u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1662u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9E2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1662u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A9E5;
L_B1A9E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9E5 AND
    cpu.logicAnd(0x80u);
    goto L_B1A9E7;
L_B1A9E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A9E7 BEQ -> $B1AA01
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0xB1AA01u,0xB1A9E7u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA9E9u,0xB1A9E7u); return;
}

