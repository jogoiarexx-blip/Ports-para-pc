#include "generated.hpp"
void sub_008DD6_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008DD6u: goto L_008DD6;
    case 0x008DD8u: goto L_008DD8;
    case 0x008DDBu: goto L_008DDB;
    case 0x008DDEu: goto L_008DDE;
    case 0x008DDFu: goto L_008DDF;
    case 0x008DE1u: goto L_008DE1;
    case 0x008DE3u: goto L_008DE3;
    case 0x008DE6u: goto L_008DE6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008DD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DD6 LDX
    cpu.setX(0x6u, 8);
    goto L_008DD8;
L_008DD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD8u, 4u + ((((0x8DEEu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8DEEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DD8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8DEEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008DDB;
L_008DDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDBu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DDB STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008DDE;
L_008DDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDEu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DDE DEX
    cpu.decReg('X');
    goto L_008DDF;
L_008DDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DDF BPL -> $008DD8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008DD8; }
    goto L_008DE1;
L_008DE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DE1 LDA
    cpu.setA(0x2u, 8);
    goto L_008DE3;
L_008DE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE3u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DE3 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008DE6;
L_008DE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008DE6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008DE6u);return;} hw.unresolvedReturn(0x008DE6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_008ED7_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008ED7u: goto L_008ED7;
    case 0x008ED9u: goto L_008ED9;
    case 0x008EDBu: goto L_008EDB;
    case 0x008EDEu: goto L_008EDE;
    case 0x008EE0u: goto L_008EE0;
    case 0x008EE3u: goto L_008EE3;
    case 0x008EE5u: goto L_008EE5;
    case 0x008EE7u: goto L_008EE7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008ED7 LDX
    cpu.setX(0x14u, 8);
    goto L_008ED9;
L_008ED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008ED9 LDY
    cpu.setY(0x0u, 8);
    goto L_008EDB;
L_008EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu, 6u, 3u, cpu.address("abs", 0x9012u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008EDB JSR -> $009012 stack real
    { cpu.push16Value(hw,0x8EDDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EDEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9012u), 0x008EDBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008EDE;
L_008EDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EDEu,0x008EDEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EDE LDX
    cpu.setX(0x0u, 8);
    goto L_008EE0;
L_008EE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE0u, 4u + ((((0x0F29u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EE0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF29u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EE3;
L_008EE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EE3 BNE -> $008EEF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x008EEFu,0x008EE3u); return; }
    goto L_008EE5;
L_008EE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EE5 LDA
    cpu.setA(0xFCu, 8);
    goto L_008EE7;
L_008EE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u, 5u, 3u, cpu.address("absx", 0x0F29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EE7 STA
    hw.write(cpu.address("absx", 0xF29u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EEAu,0x008EE7u); return;
}

void sub_0095AB_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008494u: goto L_008494;
    case 0x008496u: goto L_008496;
    case 0x008499u: goto L_008499;
    case 0x00849Cu: goto L_00849C;
    case 0x00849Du: goto L_00849D;
    case 0x00849Eu: goto L_00849E;
    case 0x0084A1u: goto L_0084A1;
    case 0x0084A2u: goto L_0084A2;
    case 0x0084A3u: goto L_0084A3;
    case 0x0084A6u: goto L_0084A6;
    case 0x0084A7u: goto L_0084A7;
    case 0x0084A8u: goto L_0084A8;
    case 0x0084ABu: goto L_0084AB;
    case 0x0084AEu: goto L_0084AE;
    case 0x0084B1u: goto L_0084B1;
    case 0x0084B2u: goto L_0084B2;
    case 0x0084B3u: goto L_0084B3;
    case 0x0084B6u: goto L_0084B6;
    case 0x0084B7u: goto L_0084B7;
    case 0x0084B8u: goto L_0084B8;
    case 0x0084BBu: goto L_0084BB;
    case 0x0084BCu: goto L_0084BC;
    case 0x0084BDu: goto L_0084BD;
    case 0x0084C0u: goto L_0084C0;
    case 0x0084C3u: goto L_0084C3;
    case 0x0084C4u: goto L_0084C4;
    case 0x0084C5u: goto L_0084C5;
    case 0x0084C7u: goto L_0084C7;
    case 0x0095ABu: goto L_0095AB;
    case 0x0095AFu: goto L_0095AF;
    case 0x0095B3u: goto L_0095B3;
    case 0x0095B5u: goto L_0095B5;
    case 0x0095B9u: goto L_0095B9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8494u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8494u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008494 LDY
    cpu.setY(0x1Eu, 8);
    goto L_008496;
L_008496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u, 4u + ((((0x8475u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8475u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008496 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x8475u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008499;
L_008499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u, 4u + ((((0x0423u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008499 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x423u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00849C;
L_00849C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849C ASL
    cpu.aslA();
    goto L_00849D;
L_00849D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849D ASL
    cpu.aslA();
    goto L_00849E;
L_00849E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu, 4u + ((((0x0422u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0422u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849E ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x422u), cpu.m8?8:16));
    goto L_0084A1;
L_0084A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A1 ASL
    cpu.aslA();
    goto L_0084A2;
L_0084A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A2 ASL
    cpu.aslA();
    goto L_0084A3;
L_0084A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u, 4u + ((((0x0421u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0421u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x421u), cpu.m8?8:16));
    goto L_0084A6;
L_0084A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A6 ASL
    cpu.aslA();
    goto L_0084A7;
L_0084A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A7 ASL
    cpu.aslA();
    goto L_0084A8;
L_0084A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u, 4u + ((((0x0420u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A8 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x420u), cpu.m8?8:16));
    goto L_0084AB;
L_0084AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu, 5u, 3u, cpu.address("absy", 0x0400u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084AB STA
    hw.write(cpu.address("absy", 0x400u), cpu.a, cpu.m8?8:16);
    goto L_0084AE;
L_0084AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84AEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84AEu, 4u + ((((0x0427u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0427u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084AE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x427u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0084B1;
L_0084B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B1 ASL
    cpu.aslA();
    goto L_0084B2;
L_0084B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B2 ASL
    cpu.aslA();
    goto L_0084B3;
L_0084B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u, 4u + ((((0x0426u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x426u), cpu.m8?8:16));
    goto L_0084B6;
L_0084B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B6 ASL
    cpu.aslA();
    goto L_0084B7;
L_0084B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B7 ASL
    cpu.aslA();
    goto L_0084B8;
L_0084B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u, 4u + ((((0x0425u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B8 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x425u), cpu.m8?8:16));
    goto L_0084BB;
L_0084BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BB ASL
    cpu.aslA();
    goto L_0084BC;
L_0084BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BC ASL
    cpu.aslA();
    goto L_0084BD;
L_0084BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu, 4u + ((((0x0424u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0424u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BD ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x424u), cpu.m8?8:16));
    goto L_0084C0;
L_0084C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C0u, 5u, 3u, cpu.address("absy", 0x0401u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C0 STA
    hw.write(cpu.address("absy", 0x401u), cpu.a, cpu.m8?8:16);
    goto L_0084C3;
L_0084C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C3 DEY
    cpu.decReg('Y');
    goto L_0084C4;
L_0084C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C4 DEY
    cpu.decReg('Y');
    goto L_0084C5;
L_0084C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C5 BPL -> $008496
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008496; }
    goto L_0084C7;
L_0084C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0084C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0084C7u);return;} hw.unresolvedReturn(0x0084C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_0095AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ABu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ABu, 8u, 4u, 0x7F8000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0095AB JSL -> $7F8000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x95AEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x95AFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x7F8000u, 0x0095ABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0095AF;
L_0095AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95AFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x95AFu,0x0095AFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95AFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95AFu, 8u, 4u, 0x0C939Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0095AF JSL -> $0C939A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x95B2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x95B3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0C939Au, 0x0095AFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0095B3;
L_0095B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x95B3u,0x0095B3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B3u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0095B3 INC
    cpu.incMem(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_0095B5;
L_0095B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B5u, 8u, 4u, 0x05BB39u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0095B5 JSL -> $05BB39 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x95B8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x95B9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05BB39u, 0x0095B5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0095B9;
L_0095B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x95B9u,0x0095B9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B9u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B9u, 3u, 3u, cpu.address("abs", 0x8494u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0095B9 JMP -> $008494
    goto L_008494;
}

void sub_009A3D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009A3Du: goto L_009A3D;
    case 0x009A3Fu: goto L_009A3F;
    case 0x009A41u: goto L_009A41;
    case 0x009A45u: goto L_009A45;
    case 0x009A49u: goto L_009A49;
    case 0x009A4Au: goto L_009A4A;
    case 0x009A4Bu: goto L_009A4B;
    case 0x009A4Du: goto L_009A4D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009A3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A3D LDY
    cpu.setY(0x10u, 8);
    goto L_009A3F;
L_009A3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A3F LDA
    cpu.setA(0x5u, 8);
    goto L_009A41;
L_009A41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A41u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A41u, 5u, 4u, ((0x7EC800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A41 STA
    hw.write(((0x7EC800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_009A45;
L_009A45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A45u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A45u, 5u, 4u, ((0x7EC9B0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A45 STA
    hw.write(((0x7EC9B0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_009A49;
L_009A49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A49u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A49 INX
    cpu.inc('X');
    goto L_009A4A;
L_009A4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A4A DEY
    cpu.decReg('Y');
    goto L_009A4B;
L_009A4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A4B BNE -> $009A41
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009A41; }
    goto L_009A4D;
L_009A4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009A4D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009A4Du);return;} hw.unresolvedReturn(0x009A4Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00A4E3_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A41Eu: goto L_00A41E;
    case 0x00A421u: goto L_00A421;
    case 0x00A423u: goto L_00A423;
    case 0x00A425u: goto L_00A425;
    case 0x00A426u: goto L_00A426;
    case 0x00A428u: goto L_00A428;
    case 0x00A429u: goto L_00A429;
    case 0x00A42Cu: goto L_00A42C;
    case 0x00A42Fu: goto L_00A42F;
    case 0x00A432u: goto L_00A432;
    case 0x00A435u: goto L_00A435;
    case 0x00A4E2u: goto L_00A4E2;
    case 0x00A4E3u: goto L_00A4E3;
    case 0x00A4E5u: goto L_00A4E5;
    case 0x00A4E7u: goto L_00A4E7;
    case 0x00A4EAu: goto L_00A4EA;
    case 0x00A4EDu: goto L_00A4ED;
    case 0x00A4F0u: goto L_00A4F0;
    case 0x00A4F3u: goto L_00A4F3;
    case 0x00A4F6u: goto L_00A4F6;
    case 0x00A4F9u: goto L_00A4F9;
    case 0x00A4FCu: goto L_00A4FC;
    case 0x00A4FFu: goto L_00A4FF;
    case 0x00A502u: goto L_00A502;
    case 0x00A505u: goto L_00A505;
    case 0x00A507u: goto L_00A507;
    case 0x00A50Au: goto L_00A50A;
    case 0x00A50Cu: goto L_00A50C;
    case 0x00A50Fu: goto L_00A50F;
    case 0x00A511u: goto L_00A511;
    case 0x00A513u: goto L_00A513;
    case 0x00A515u: goto L_00A515;
    case 0x00A518u: goto L_00A518;
    case 0x00A51Au: goto L_00A51A;
    case 0x00A51Cu: goto L_00A51C;
    case 0x00A51Eu: goto L_00A51E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A41E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Eu, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A41E STA
    hw.write(cpu.address("abs", 0x2121u), cpu.a, cpu.m8?8:16);
    goto L_00A421;
L_00A421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA421u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA421u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A421 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A423;
L_00A423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA423u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA423u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A423 AND
    cpu.logicAnd(0x1Cu);
    goto L_00A425;
L_00A425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA425u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA425u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A425 LSR
    cpu.lsrA();
    goto L_00A426;
L_00A426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA426u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA426u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A426 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_00A428;
L_00A428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA428u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA428u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA428u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A428 TAY
    cpu.transfer("TAY");
    goto L_00A429;
L_00A429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA429u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA429u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA429u, 4u + ((((0xB60Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xB60Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A429 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB60Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A42C;
L_00A42C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Cu, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A42C STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_00A42F;
L_00A42F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Fu, 4u + ((((0xB60Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xB60Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A42F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB60Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A432;
L_00A432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA432u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA432u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA432u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A432 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_00A435;
L_00A435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA435u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA435u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A435 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A435u);return;} hw.unresolvedReturn(0x00A435u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00A4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A4E2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A4E2u);return;} hw.unresolvedReturn(0x00A4E2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00A4E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4E3 REP
    cpu.rep(0x10u);
    goto L_00A4E5;
L_00A4E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4E5 LDA
    cpu.setA(0x80u, 8);
    goto L_00A4E7;
L_00A4E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E7u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4E7 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_00A4EA;
L_00A4EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4EA LDY
    cpu.setY(0x750u, 16);
    goto L_00A4ED;
L_00A4ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EDu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EDu, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4ED STY
    hw.write(cpu.address("abs", 0x2116u), cpu.y, cpu.x8?8:16);
    goto L_00A4F0;
L_00A4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4F0 LDY
    cpu.setY(0x1801u, 16);
    goto L_00A4F3;
L_00A4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F3u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F3u, 5u, 3u, cpu.address("abs", 0x4320u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4F3 STY
    hw.write(cpu.address("abs", 0x4320u), cpu.y, cpu.x8?8:16);
    goto L_00A4F6;
L_00A4F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4F6 LDY
    cpu.setY(0xAF6u, 16);
    goto L_00A4F9;
L_00A4F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F9u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F9u, 5u, 3u, cpu.address("abs", 0x4322u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4F9 STY
    hw.write(cpu.address("abs", 0x4322u), cpu.y, cpu.x8?8:16);
    goto L_00A4FC;
L_00A4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FCu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FCu, 4u, 3u, cpu.address("abs", 0x4324u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4FC STZ
    hw.write(cpu.address("abs", 0x4324u), 0, cpu.m8?8:16);
    goto L_00A4FF;
L_00A4FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4FF LDY
    cpu.setY(0x160u, 16);
    goto L_00A502;
L_00A502:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA502u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA502u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA502u, 5u, 3u, cpu.address("abs", 0x4325u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A502 STY
    hw.write(cpu.address("abs", 0x4325u), cpu.y, cpu.x8?8:16);
    goto L_00A505;
L_00A505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA505u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA505u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A505 LDA
    cpu.setA(0x4u, 8);
    goto L_00A507;
L_00A507:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA507u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA507u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA507u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A507 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_00A50A;
L_00A50A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A50A SEP
    cpu.sep(0x10u);
    goto L_00A50C;
L_00A50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Cu, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A50C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13D9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A50F;
L_00A50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A50F CMP
    cpu.compareA(0xAu);
    goto L_00A511;
L_00A511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA511u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA511u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A511 BEQ -> $00A4E2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A4E2; }
    goto L_00A513;
L_00A513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA513u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA513u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A513 LDA
    cpu.setA(0x6Du, 8);
    goto L_00A515;
L_00A515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA515u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA515u, 6u, 3u, cpu.address("abs", 0xA41Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A515 JSR -> $00A41C stack real
    { cpu.push16Value(hw,0xA517u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA518u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA41Cu), 0x00A515u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A518;
L_00A518:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA518u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA518u,0x00A518u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA518u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA518u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A518 LDA
    cpu.setA(0x10u, 8);
    goto L_00A51A;
L_00A51A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA51Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A51A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00A51C;
L_00A51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A51C LDA
    cpu.setA(0x7Du, 8);
    goto L_00A51E;
L_00A51E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA51Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Eu, 3u, 3u, cpu.address("abs", 0xA41Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A51E JMP -> $00A41E
    goto L_00A41E;
}

void sub_00AF17_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00AF17u: goto L_00AF17;
    case 0x00AF1Au: goto L_00AF1A;
    case 0x00AF1Cu: goto L_00AF1C;
    case 0x00AF1Du: goto L_00AF1D;
    case 0x00AF1Fu: goto L_00AF1F;
    case 0x00AF20u: goto L_00AF20;
    case 0x00AF22u: goto L_00AF22;
    case 0x00AF25u: goto L_00AF25;
    case 0x00AF27u: goto L_00AF27;
    case 0x00AF29u: goto L_00AF29;
    case 0x00AF2Bu: goto L_00AF2B;
    case 0x00AF2Du: goto L_00AF2D;
    case 0x00AF2Fu: goto L_00AF2F;
    case 0x00AF31u: goto L_00AF31;
    case 0x00AF35u: goto L_00AF35;
    case 0x00AF37u: goto L_00AF37;
    case 0x00AF39u: goto L_00AF39;
    case 0x00AF3Bu: goto L_00AF3B;
    case 0x00AF3Eu: goto L_00AF3E;
    case 0x00AF40u: goto L_00AF40;
    case 0x00AF42u: goto L_00AF42;
    case 0x00AF45u: goto L_00AF45;
    case 0x00AF47u: goto L_00AF47;
    case 0x00AF49u: goto L_00AF49;
    case 0x00AF4Bu: goto L_00AF4B;
    case 0x00AF4Du: goto L_00AF4D;
    case 0x00AFA2u: goto L_00AFA2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00AF17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF17u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF17u, 4u, 3u, cpu.address("abs", 0x1493u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF17 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1493u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00AF1A;
L_00AF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF1A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AF1C;
L_00AF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF1C LSR
    cpu.lsrA();
    goto L_00AF1D;
L_00AF1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF1D BCC -> $00AF25
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00AF25; }
    goto L_00AF1F;
L_00AF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF1F DEY
    cpu.decReg('Y');
    goto L_00AF20;
L_00AF20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF20 BEQ -> $00AF25
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00AF25; }
    goto L_00AF22;
L_00AF22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF22u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF22u, 4u, 3u, cpu.address("abs", 0x1493u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF22 STY
    hw.write(cpu.address("abs", 0x1493u), cpu.y, cpu.x8?8:16);
    goto L_00AF25;
L_00AF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF25u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF25 CPY
    cpu.compareY(0xA0u);
    goto L_00AF27;
L_00AF27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF27u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF27u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF27 BCS -> $00AF35
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00AF35; }
    goto L_00AF29;
L_00AF29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF29u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF29 LDA
    cpu.setA(0x4u, 8);
    goto L_00AF2B;
L_00AF2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Bu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF2B TRB
    cpu.trb(hw, cpu.address("dp", 0x40u), cpu.m8?8:16);
    goto L_00AF2D;
L_00AF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF2D LDA
    cpu.setA(0x9u, 8);
    goto L_00AF2F;
L_00AF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF2F STA
    hw.write(cpu.address("dp", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_00AF31;
L_00AF31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF31u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF31u, 8u, 4u, 0x05CBFFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00AF31 JSL -> $05CBFF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF34u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF35u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05CBFFu, 0x00AF31u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AF35;
L_00AF35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF35u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF35u,0x00AF35u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF35u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF35u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF35 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AF37;
L_00AF37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF37u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF37 AND
    cpu.logicAnd(0x3u);
    goto L_00AF39;
L_00AF39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF39u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF39 BNE -> $00AFA2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00AFA2; }
    goto L_00AF3B;
L_00AF3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Bu, 4u, 3u, cpu.address("abs", 0x1495u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF3B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1495u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AF3E;
L_00AF3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF3E CMP
    cpu.compareA(0x40u);
    goto L_00AF40;
L_00AF40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF40u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF40 BCS -> $00AFA2
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00AFA2; }
    goto L_00AF42;
L_00AF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u, 6u, 3u, cpu.address("abs", 0xAFA3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AF42 JSR -> $00AFA3 stack real
    { cpu.push16Value(hw,0xAF44u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF45u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAFA3u), 0x00AF42u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AF45;
L_00AF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF45u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF45u,0x00AF45u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF45u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF45 LDA
    cpu.setA(0xFEu, 8);
    goto L_00AF47;
L_00AF47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Du + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00AF47 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0x8Du), cpu.m8?8:16));
    goto L_00AF49;
L_00AF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF49u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF49u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF49 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9u), cpu.m8?8:16));
    goto L_00AF4B;
L_00AF4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF4B LDX
    cpu.setX(0xEEu, 8);
    goto L_00AF4D;
L_00AF4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Du,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $00AF4D BRK
    hw.partial(0x00AF4Du, "BRK"); return;
L_00AFA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AFA2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00AFA2u);return;} hw.unresolvedReturn(0x00AFA2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00AF17_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00AF17u: goto L_00AF17;
    case 0x00AF1Au: goto L_00AF1A;
    case 0x00AF1Cu: goto L_00AF1C;
    case 0x00AF1Du: goto L_00AF1D;
    case 0x00AF1Fu: goto L_00AF1F;
    case 0x00AF20u: goto L_00AF20;
    case 0x00AF22u: goto L_00AF22;
    case 0x00AF25u: goto L_00AF25;
    case 0x00AF27u: goto L_00AF27;
    case 0x00AF29u: goto L_00AF29;
    case 0x00AF2Bu: goto L_00AF2B;
    case 0x00AF2Du: goto L_00AF2D;
    case 0x00AF2Fu: goto L_00AF2F;
    case 0x00AF31u: goto L_00AF31;
    case 0x00AF35u: goto L_00AF35;
    case 0x00AF37u: goto L_00AF37;
    case 0x00AF39u: goto L_00AF39;
    case 0x00AF3Bu: goto L_00AF3B;
    case 0x00AF3Eu: goto L_00AF3E;
    case 0x00AF40u: goto L_00AF40;
    case 0x00AF42u: goto L_00AF42;
    case 0x00AF45u: goto L_00AF45;
    case 0x00AF47u: goto L_00AF47;
    case 0x00AF49u: goto L_00AF49;
    case 0x00AF4Bu: goto L_00AF4B;
    case 0x00AF4Du: goto L_00AF4D;
    case 0x00AFA2u: goto L_00AFA2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00AF17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF17u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF17u, 4u, 3u, cpu.address("abs", 0x1493u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF17 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1493u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00AF1A;
L_00AF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF1A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AF1C;
L_00AF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF1C LSR
    cpu.lsrA();
    goto L_00AF1D;
L_00AF1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF1D BCC -> $00AF25
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00AF25; }
    goto L_00AF1F;
L_00AF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF1F DEY
    cpu.decReg('Y');
    goto L_00AF20;
L_00AF20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF20 BEQ -> $00AF25
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00AF25; }
    goto L_00AF22;
L_00AF22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF22u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF22u, 4u, 3u, cpu.address("abs", 0x1493u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF22 STY
    hw.write(cpu.address("abs", 0x1493u), cpu.y, cpu.x8?8:16);
    goto L_00AF25;
L_00AF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF25u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF25 CPY
    cpu.compareY(0xA0u);
    goto L_00AF27;
L_00AF27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF27u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF27u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF27 BCS -> $00AF35
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00AF35; }
    goto L_00AF29;
L_00AF29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF29u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF29 LDA
    cpu.setA(0x4u, 8);
    goto L_00AF2B;
L_00AF2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Bu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF2B TRB
    cpu.trb(hw, cpu.address("dp", 0x40u), cpu.m8?8:16);
    goto L_00AF2D;
L_00AF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF2D LDA
    cpu.setA(0x9u, 8);
    goto L_00AF2F;
L_00AF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF2F STA
    hw.write(cpu.address("dp", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_00AF31;
L_00AF31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF31u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF31u, 8u, 4u, 0x05CBFFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00AF31 JSL -> $05CBFF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF34u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF35u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05CBFFu, 0x00AF31u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AF35;
L_00AF35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF35u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF35u,0x00AF35u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF35u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF35u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF35 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AF37;
L_00AF37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF37u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF37 AND
    cpu.logicAnd(0x3u);
    goto L_00AF39;
L_00AF39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF39u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF39 BNE -> $00AFA2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00AFA2; }
    goto L_00AF3B;
L_00AF3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Bu, 4u, 3u, cpu.address("abs", 0x1495u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF3B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1495u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AF3E;
L_00AF3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF3E CMP
    cpu.compareA(0x40u);
    goto L_00AF40;
L_00AF40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF40u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF40 BCS -> $00AFA2
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00AFA2; }
    goto L_00AF42;
L_00AF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u, 6u, 3u, cpu.address("abs", 0xAFA3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AF42 JSR -> $00AFA3 stack real
    { cpu.push16Value(hw,0xAF44u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF45u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAFA3u), 0x00AF42u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AF45;
L_00AF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF45u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF45u,0x00AF45u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF45u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF45 LDA
    cpu.setA(0xFEu, 8);
    goto L_00AF47;
L_00AF47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF47u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Du + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00AF47 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0x8Du), cpu.m8?8:16));
    goto L_00AF49;
L_00AF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF49u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF49u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF49 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9u), cpu.m8?8:16));
    goto L_00AF4B;
L_00AF4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AF4B LDX
    cpu.setX(0xEEu, 8);
    goto L_00AF4D;
L_00AF4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Du,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $00AF4D BRK
    hw.partial(0x00AF4Du, "BRK"); return;
L_00AFA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFA2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AFA2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00AFA2u);return;} hw.unresolvedReturn(0x00AFA2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00BA4D_E0M1X1CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00BAE0u: goto L_00BAE0;
    case 0x00BAE3u: goto L_00BAE3;
    case 0x00BAE6u: goto L_00BAE6;
    case 0x00BAE9u: goto L_00BAE9;
    case 0x00BAECu: goto L_00BAEC;
    case 0x00BAEFu: goto L_00BAEF;
    case 0x00BAF2u: goto L_00BAF2;
    case 0x00BAF5u: goto L_00BAF5;
    case 0x00BAF8u: goto L_00BAF8;
    case 0x00BAFBu: goto L_00BAFB;
    case 0x00BAFEu: goto L_00BAFE;
    case 0x00BB01u: goto L_00BB01;
    case 0x00BB04u: goto L_00BB04;
    case 0x00BB07u: goto L_00BB07;
    case 0x00BB0Au: goto L_00BB0A;
    case 0x00BB0Du: goto L_00BB0D;
    case 0x00BB10u: goto L_00BB10;
    case 0x00BB13u: goto L_00BB13;
    case 0x00BB16u: goto L_00BB16;
    case 0x00BB19u: goto L_00BB19;
    case 0x00BB1Cu: goto L_00BB1C;
    case 0x00BB1Fu: goto L_00BB1F;
    case 0x00BB22u: goto L_00BB22;
    case 0x00BB25u: goto L_00BB25;
    case 0x00BB28u: goto L_00BB28;
    case 0x00BB2Bu: goto L_00BB2B;
    case 0x00BB2Eu: goto L_00BB2E;
    case 0x00BB31u: goto L_00BB31;
    case 0x00BB34u: goto L_00BB34;
    case 0x00BB37u: goto L_00BB37;
    case 0x00BB3Au: goto L_00BB3A;
    case 0x00BB3Du: goto L_00BB3D;
    case 0x00BB40u: goto L_00BB40;
    case 0x00BB43u: goto L_00BB43;
    case 0x00BB46u: goto L_00BB46;
    case 0x00BB49u: goto L_00BB49;
    case 0x00BB4Cu: goto L_00BB4C;
    case 0x00BB4Fu: goto L_00BB4F;
    case 0x00BB52u: goto L_00BB52;
    case 0x00BB55u: goto L_00BB55;
    case 0x00BB58u: goto L_00BB58;
    case 0x00BB5Bu: goto L_00BB5B;
    case 0x00BB5Eu: goto L_00BB5E;
    case 0x00BB61u: goto L_00BB61;
    case 0x00BB64u: goto L_00BB64;
    case 0x00BB67u: goto L_00BB67;
    case 0x00BB6Au: goto L_00BB6A;
    case 0x00BB6Du: goto L_00BB6D;
    case 0x00BB70u: goto L_00BB70;
    case 0x00BB73u: goto L_00BB73;
    case 0x00BB76u: goto L_00BB76;
    case 0x00BB79u: goto L_00BB79;
    case 0x00BB7Cu: goto L_00BB7C;
    case 0x00BB7Fu: goto L_00BB7F;
    case 0x00BB82u: goto L_00BB82;
    case 0x00BB85u: goto L_00BB85;
    case 0x00BB88u: goto L_00BB88;
    case 0x00BB8Bu: goto L_00BB8B;
    case 0x00BB8Eu: goto L_00BB8E;
    case 0x00BB91u: goto L_00BB91;
    case 0x00BB94u: goto L_00BB94;
    case 0x00BB97u: goto L_00BB97;
    case 0x00BB9Au: goto L_00BB9A;
    case 0x00BB9Du: goto L_00BB9D;
    case 0x00BBA0u: goto L_00BBA0;
    case 0x00BBA3u: goto L_00BBA3;
    case 0x00BBA6u: goto L_00BBA6;
    case 0x00BBA9u: goto L_00BBA9;
    case 0x00BBACu: goto L_00BBAC;
    case 0x00BBAFu: goto L_00BBAF;
    case 0x00BBB2u: goto L_00BBB2;
    case 0x00BBB5u: goto L_00BBB5;
    case 0x00BBB8u: goto L_00BBB8;
    case 0x00BBBBu: goto L_00BBBB;
    case 0x00BBBEu: goto L_00BBBE;
    case 0x00BBC1u: goto L_00BBC1;
    case 0x00BBC4u: goto L_00BBC4;
    case 0x00BBC7u: goto L_00BBC7;
    case 0x00BBCAu: goto L_00BBCA;
    case 0x00BBCDu: goto L_00BBCD;
    case 0x00BBD0u: goto L_00BBD0;
    case 0x00BBD3u: goto L_00BBD3;
    case 0x00BBD6u: goto L_00BBD6;
    case 0x00BBD9u: goto L_00BBD9;
    case 0x00BBDCu: goto L_00BBDC;
    case 0x00BBDFu: goto L_00BBDF;
    case 0x00BBE2u: goto L_00BBE2;
    case 0x00BBE5u: goto L_00BBE5;
    case 0x00BBE8u: goto L_00BBE8;
    case 0x00BBEBu: goto L_00BBEB;
    case 0x00BBEEu: goto L_00BBEE;
    case 0x00BBF1u: goto L_00BBF1;
    case 0x00BBF4u: goto L_00BBF4;
    case 0x00BBF7u: goto L_00BBF7;
    case 0x00BBFAu: goto L_00BBFA;
    case 0x00BBFDu: goto L_00BBFD;
    case 0x00BC00u: goto L_00BC00;
    case 0x00BC03u: goto L_00BC03;
    case 0x00BC06u: goto L_00BC06;
    case 0x00BC09u: goto L_00BC09;
    case 0x00BC0Cu: goto L_00BC0C;
    case 0x00BC0Fu: goto L_00BC0F;
    case 0x00BC12u: goto L_00BC12;
    case 0x00BC15u: goto L_00BC15;
    case 0x00BC18u: goto L_00BC18;
    case 0x00BC1Bu: goto L_00BC1B;
    case 0x00BC1Eu: goto L_00BC1E;
    case 0x00BC21u: goto L_00BC21;
    case 0x00BC24u: goto L_00BC24;
    case 0x00BC27u: goto L_00BC27;
    case 0x00BC2Au: goto L_00BC2A;
    case 0x00BC2Du: goto L_00BC2D;
    case 0x00BC30u: goto L_00BC30;
    case 0x00BC33u: goto L_00BC33;
    case 0x00BC36u: goto L_00BC36;
    case 0x00BC39u: goto L_00BC39;
    case 0x00BC3Cu: goto L_00BC3C;
    case 0x00BC3Fu: goto L_00BC3F;
    case 0x00BC42u: goto L_00BC42;
    case 0x00BC46u: goto L_00BC46;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00BAE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE0u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE0u, 7u, 3u, cpu.address("absx", 0xCD10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BAE0 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xCD10u), cpu.m8?8:16);
    goto L_00BAE3;
L_00BAE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE3u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE3u, 7u, 3u, cpu.address("absx", 0xCEC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BAE3 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xCEC0u), cpu.m8?8:16);
    goto L_00BAE6;
L_00BAE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE6u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE6u, 7u, 3u, cpu.address("absx", 0xD070u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BAE6 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD070u), cpu.m8?8:16);
    goto L_00BAE9;
L_00BAE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE9u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE9u, 7u, 3u, cpu.address("absx", 0xD220u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BAE9 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD220u), cpu.m8?8:16);
    goto L_00BAEC;
L_00BAEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAECu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAECu, 7u, 3u, cpu.address("absx", 0xD3D0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BAEC ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD3D0u), cpu.m8?8:16);
    goto L_00BAEF;
L_00BAEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEFu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEFu, 7u, 3u, cpu.address("absx", 0xD580u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BAEF ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD580u), cpu.m8?8:16);
    goto L_00BAF2;
L_00BAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF2u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF2u, 7u, 3u, cpu.address("absx", 0xD730u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BAF2 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD730u), cpu.m8?8:16);
    goto L_00BAF5;
L_00BAF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF5u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF5u, 7u, 3u, cpu.address("absx", 0xD8E0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BAF5 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD8E0u), cpu.m8?8:16);
    goto L_00BAF8;
L_00BAF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF8u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF8u, 7u, 3u, cpu.address("absx", 0xDA90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BAF8 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDA90u), cpu.m8?8:16);
    goto L_00BAFB;
L_00BAFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFBu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFBu, 7u, 3u, cpu.address("absx", 0xDC40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BAFB ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDC40u), cpu.m8?8:16);
    goto L_00BAFE;
L_00BAFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFEu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFEu, 7u, 3u, cpu.address("absx", 0xDDF0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BAFE ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDDF0u), cpu.m8?8:16);
    goto L_00BB01;
L_00BB01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB01u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB01u, 7u, 3u, cpu.address("absx", 0xDFA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB01 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDFA0u), cpu.m8?8:16);
    goto L_00BB04;
L_00BB04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB04u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB04u, 7u, 3u, cpu.address("absx", 0xE150u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB04 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE150u), cpu.m8?8:16);
    goto L_00BB07;
L_00BB07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB07u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB07u, 7u, 3u, cpu.address("absx", 0xE300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB07 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE300u), cpu.m8?8:16);
    goto L_00BB0A;
L_00BB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Au,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Au, 7u, 3u, cpu.address("absx", 0xE4B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB0A ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE4B0u), cpu.m8?8:16);
    goto L_00BB0D;
L_00BB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Du,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Du, 7u, 3u, cpu.address("absx", 0xE660u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB0D ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE660u), cpu.m8?8:16);
    goto L_00BB10;
L_00BB10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB10u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB10u, 7u, 3u, cpu.address("absx", 0xE810u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB10 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE810u), cpu.m8?8:16);
    goto L_00BB13;
L_00BB13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB13u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB13u, 7u, 3u, cpu.address("absx", 0xE9C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB13 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE9C0u), cpu.m8?8:16);
    goto L_00BB16;
L_00BB16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB16u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB16u, 7u, 3u, cpu.address("absx", 0xEB70u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB16 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xEB70u), cpu.m8?8:16);
    goto L_00BB19;
L_00BB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB19u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB19u, 7u, 3u, cpu.address("absx", 0xED20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB19 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xED20u), cpu.m8?8:16);
    goto L_00BB1C;
L_00BB1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Cu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Cu, 7u, 3u, cpu.address("absx", 0xEED0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB1C ROR
    cpu.rorMem(hw, cpu.address("absx", 0xEED0u), cpu.m8?8:16);
    goto L_00BB1F;
L_00BB1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Fu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Fu, 7u, 3u, cpu.address("absx", 0xF080u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB1F ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF080u), cpu.m8?8:16);
    goto L_00BB22;
L_00BB22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB22u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB22u, 7u, 3u, cpu.address("absx", 0xF230u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB22 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF230u), cpu.m8?8:16);
    goto L_00BB25;
L_00BB25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB25u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB25u, 7u, 3u, cpu.address("absx", 0xF3E0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB25 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF3E0u), cpu.m8?8:16);
    goto L_00BB28;
L_00BB28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB28u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB28u, 7u, 3u, cpu.address("absx", 0xF590u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB28 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF590u), cpu.m8?8:16);
    goto L_00BB2B;
L_00BB2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Bu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Bu, 7u, 3u, cpu.address("absx", 0xF740u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB2B ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF740u), cpu.m8?8:16);
    goto L_00BB2E;
L_00BB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Eu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Eu, 7u, 3u, cpu.address("absx", 0xF8F0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB2E ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF8F0u), cpu.m8?8:16);
    goto L_00BB31;
L_00BB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB31u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB31u, 7u, 3u, cpu.address("absx", 0xFAA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB31 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xFAA0u), cpu.m8?8:16);
    goto L_00BB34;
L_00BB34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB34u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB34u, 7u, 3u, cpu.address("absx", 0xFC50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB34 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xFC50u), cpu.m8?8:16);
    goto L_00BB37;
L_00BB37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB37u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB37u, 7u, 3u, cpu.address("absx", 0xC800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB37 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xC800u), cpu.m8?8:16);
    goto L_00BB3A;
L_00BB3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Au,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Au, 7u, 3u, cpu.address("absx", 0xCA00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB3A ROR
    cpu.rorMem(hw, cpu.address("absx", 0xCA00u), cpu.m8?8:16);
    goto L_00BB3D;
L_00BB3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Du,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Du, 7u, 3u, cpu.address("absx", 0xCC00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB3D ROR
    cpu.rorMem(hw, cpu.address("absx", 0xCC00u), cpu.m8?8:16);
    goto L_00BB40;
L_00BB40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB40u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB40u, 7u, 3u, cpu.address("absx", 0xCE00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB40 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xCE00u), cpu.m8?8:16);
    goto L_00BB43;
L_00BB43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB43u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB43u, 7u, 3u, cpu.address("absx", 0xD000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB43 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD000u), cpu.m8?8:16);
    goto L_00BB46;
L_00BB46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB46u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB46u, 7u, 3u, cpu.address("absx", 0xD200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB46 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD200u), cpu.m8?8:16);
    goto L_00BB49;
L_00BB49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB49u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB49u, 7u, 3u, cpu.address("absx", 0xD400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB49 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD400u), cpu.m8?8:16);
    goto L_00BB4C;
L_00BB4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Cu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Cu, 7u, 3u, cpu.address("absx", 0xD600u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB4C ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD600u), cpu.m8?8:16);
    goto L_00BB4F;
L_00BB4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Fu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Fu, 7u, 3u, cpu.address("absx", 0xD800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB4F ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD800u), cpu.m8?8:16);
    goto L_00BB52;
L_00BB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB52u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB52u, 7u, 3u, cpu.address("absx", 0xDA00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB52 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDA00u), cpu.m8?8:16);
    goto L_00BB55;
L_00BB55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB55u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB55u, 7u, 3u, cpu.address("absx", 0xDC00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB55 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDC00u), cpu.m8?8:16);
    goto L_00BB58;
L_00BB58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB58u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB58u, 7u, 3u, cpu.address("absx", 0xDE00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB58 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDE00u), cpu.m8?8:16);
    goto L_00BB5B;
L_00BB5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Bu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Bu, 7u, 3u, cpu.address("absx", 0xE000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB5B ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE000u), cpu.m8?8:16);
    goto L_00BB5E;
L_00BB5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Eu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Eu, 7u, 3u, cpu.address("absx", 0xE200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB5E ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE200u), cpu.m8?8:16);
    goto L_00BB61;
L_00BB61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB61u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB61u, 7u, 3u, cpu.address("absx", 0xE300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB61 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE300u), cpu.m8?8:16);
    goto L_00BB64;
L_00BB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB64u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB64u, 7u, 3u, cpu.address("absx", 0xE4B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB64 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE4B0u), cpu.m8?8:16);
    goto L_00BB67;
L_00BB67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB67u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB67u, 7u, 3u, cpu.address("absx", 0xE660u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB67 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE660u), cpu.m8?8:16);
    goto L_00BB6A;
L_00BB6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Au,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Au, 7u, 3u, cpu.address("absx", 0xE810u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB6A ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE810u), cpu.m8?8:16);
    goto L_00BB6D;
L_00BB6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Du,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Du, 7u, 3u, cpu.address("absx", 0xE9C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB6D ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE9C0u), cpu.m8?8:16);
    goto L_00BB70;
L_00BB70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB70u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB70u, 7u, 3u, cpu.address("absx", 0xEB70u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB70 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xEB70u), cpu.m8?8:16);
    goto L_00BB73;
L_00BB73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB73u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB73u, 7u, 3u, cpu.address("absx", 0xED20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB73 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xED20u), cpu.m8?8:16);
    goto L_00BB76;
L_00BB76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB76u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB76u, 7u, 3u, cpu.address("absx", 0xEED0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB76 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xEED0u), cpu.m8?8:16);
    goto L_00BB79;
L_00BB79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB79u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB79u, 7u, 3u, cpu.address("absx", 0xF080u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB79 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF080u), cpu.m8?8:16);
    goto L_00BB7C;
L_00BB7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Cu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Cu, 7u, 3u, cpu.address("absx", 0xF230u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB7C ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF230u), cpu.m8?8:16);
    goto L_00BB7F;
L_00BB7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Fu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Fu, 7u, 3u, cpu.address("absx", 0xF3E0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB7F ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF3E0u), cpu.m8?8:16);
    goto L_00BB82;
L_00BB82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB82u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB82u, 7u, 3u, cpu.address("absx", 0xF590u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB82 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF590u), cpu.m8?8:16);
    goto L_00BB85;
L_00BB85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB85u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB85u, 7u, 3u, cpu.address("absx", 0xF740u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB85 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF740u), cpu.m8?8:16);
    goto L_00BB88;
L_00BB88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB88u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB88u, 7u, 3u, cpu.address("absx", 0xF8F0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB88 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF8F0u), cpu.m8?8:16);
    goto L_00BB8B;
L_00BB8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Bu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Bu, 7u, 3u, cpu.address("absx", 0xFAA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB8B ROR
    cpu.rorMem(hw, cpu.address("absx", 0xFAA0u), cpu.m8?8:16);
    goto L_00BB8E;
L_00BB8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Eu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Eu, 7u, 3u, cpu.address("absx", 0xFC50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB8E ROR
    cpu.rorMem(hw, cpu.address("absx", 0xFC50u), cpu.m8?8:16);
    goto L_00BB91;
L_00BB91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB91u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB91u, 7u, 3u, cpu.address("absx", 0xC800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB91 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xC800u), cpu.m8?8:16);
    goto L_00BB94;
L_00BB94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB94u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB94u, 7u, 3u, cpu.address("absx", 0xC9B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB94 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xC9B0u), cpu.m8?8:16);
    goto L_00BB97;
L_00BB97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB97u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB97u, 7u, 3u, cpu.address("absx", 0xCB60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB97 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xCB60u), cpu.m8?8:16);
    goto L_00BB9A;
L_00BB9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Au,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Au, 7u, 3u, cpu.address("absx", 0xCD10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB9A ROR
    cpu.rorMem(hw, cpu.address("absx", 0xCD10u), cpu.m8?8:16);
    goto L_00BB9D;
L_00BB9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Du,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Du, 7u, 3u, cpu.address("absx", 0xCEC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BB9D ROR
    cpu.rorMem(hw, cpu.address("absx", 0xCEC0u), cpu.m8?8:16);
    goto L_00BBA0;
L_00BBA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA0u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA0u, 7u, 3u, cpu.address("absx", 0xD070u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBA0 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD070u), cpu.m8?8:16);
    goto L_00BBA3;
L_00BBA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA3u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA3u, 7u, 3u, cpu.address("absx", 0xD220u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBA3 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD220u), cpu.m8?8:16);
    goto L_00BBA6;
L_00BBA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA6u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA6u, 7u, 3u, cpu.address("absx", 0xD3D0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBA6 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD3D0u), cpu.m8?8:16);
    goto L_00BBA9;
L_00BBA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA9u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA9u, 7u, 3u, cpu.address("absx", 0xD580u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBA9 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD580u), cpu.m8?8:16);
    goto L_00BBAC;
L_00BBAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBACu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBACu, 7u, 3u, cpu.address("absx", 0xD730u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBAC ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD730u), cpu.m8?8:16);
    goto L_00BBAF;
L_00BBAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBAFu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBAFu, 7u, 3u, cpu.address("absx", 0xD8E0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBAF ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD8E0u), cpu.m8?8:16);
    goto L_00BBB2;
L_00BBB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB2u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB2u, 7u, 3u, cpu.address("absx", 0xDA90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBB2 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDA90u), cpu.m8?8:16);
    goto L_00BBB5;
L_00BBB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB5u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB5u, 7u, 3u, cpu.address("absx", 0xDC40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBB5 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDC40u), cpu.m8?8:16);
    goto L_00BBB8;
L_00BBB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB8u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB8u, 7u, 3u, cpu.address("absx", 0xDDF0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBB8 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDDF0u), cpu.m8?8:16);
    goto L_00BBBB;
L_00BBBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBBu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBBu, 7u, 3u, cpu.address("absx", 0xDFA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBBB ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDFA0u), cpu.m8?8:16);
    goto L_00BBBE;
L_00BBBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBEu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBEu, 7u, 3u, cpu.address("absx", 0xE150u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBBE ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE150u), cpu.m8?8:16);
    goto L_00BBC1;
L_00BBC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC1u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC1u, 7u, 3u, cpu.address("absx", 0xE400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBC1 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE400u), cpu.m8?8:16);
    goto L_00BBC4;
L_00BBC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC4u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC4u, 7u, 3u, cpu.address("absx", 0xE600u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBC4 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE600u), cpu.m8?8:16);
    goto L_00BBC7;
L_00BBC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC7u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC7u, 7u, 3u, cpu.address("absx", 0xE800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBC7 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE800u), cpu.m8?8:16);
    goto L_00BBCA;
L_00BBCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCAu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCAu, 7u, 3u, cpu.address("absx", 0xEA00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBCA ROR
    cpu.rorMem(hw, cpu.address("absx", 0xEA00u), cpu.m8?8:16);
    goto L_00BBCD;
L_00BBCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCDu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCDu, 7u, 3u, cpu.address("absx", 0xEC00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBCD ROR
    cpu.rorMem(hw, cpu.address("absx", 0xEC00u), cpu.m8?8:16);
    goto L_00BBD0;
L_00BBD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD0u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD0u, 7u, 3u, cpu.address("absx", 0xEE00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBD0 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xEE00u), cpu.m8?8:16);
    goto L_00BBD3;
L_00BBD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD3u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD3u, 7u, 3u, cpu.address("absx", 0xF000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBD3 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF000u), cpu.m8?8:16);
    goto L_00BBD6;
L_00BBD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD6u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD6u, 7u, 3u, cpu.address("absx", 0xF200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBD6 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF200u), cpu.m8?8:16);
    goto L_00BBD9;
L_00BBD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD9u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD9u, 7u, 3u, cpu.address("absx", 0xF400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBD9 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF400u), cpu.m8?8:16);
    goto L_00BBDC;
L_00BBDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDCu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDCu, 7u, 3u, cpu.address("absx", 0xF600u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBDC ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF600u), cpu.m8?8:16);
    goto L_00BBDF;
L_00BBDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDFu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDFu, 7u, 3u, cpu.address("absx", 0xF800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBDF ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF800u), cpu.m8?8:16);
    goto L_00BBE2;
L_00BBE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE2u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE2u, 7u, 3u, cpu.address("absx", 0xFA00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBE2 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xFA00u), cpu.m8?8:16);
    goto L_00BBE5;
L_00BBE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE5u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE5u, 7u, 3u, cpu.address("absx", 0xFC00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBE5 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xFC00u), cpu.m8?8:16);
    goto L_00BBE8;
L_00BBE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE8u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE8u, 7u, 3u, cpu.address("absx", 0xFE00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBE8 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xFE00u), cpu.m8?8:16);
    goto L_00BBEB;
L_00BBEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEBu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEBu, 7u, 3u, cpu.address("absx", 0xC800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBEB ROR
    cpu.rorMem(hw, cpu.address("absx", 0xC800u), cpu.m8?8:16);
    goto L_00BBEE;
L_00BBEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEEu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEEu, 7u, 3u, cpu.address("absx", 0xCA00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBEE ROR
    cpu.rorMem(hw, cpu.address("absx", 0xCA00u), cpu.m8?8:16);
    goto L_00BBF1;
L_00BBF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF1u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF1u, 7u, 3u, cpu.address("absx", 0xCC00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBF1 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xCC00u), cpu.m8?8:16);
    goto L_00BBF4;
L_00BBF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF4u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF4u, 7u, 3u, cpu.address("absx", 0xCE00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBF4 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xCE00u), cpu.m8?8:16);
    goto L_00BBF7;
L_00BBF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF7u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF7u, 7u, 3u, cpu.address("absx", 0xD000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBF7 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD000u), cpu.m8?8:16);
    goto L_00BBFA;
L_00BBFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFAu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFAu, 7u, 3u, cpu.address("absx", 0xD200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBFA ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD200u), cpu.m8?8:16);
    goto L_00BBFD;
L_00BBFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFDu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFDu, 7u, 3u, cpu.address("absx", 0xD400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BBFD ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD400u), cpu.m8?8:16);
    goto L_00BC00;
L_00BC00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC00u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC00u, 7u, 3u, cpu.address("absx", 0xD600u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC00 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD600u), cpu.m8?8:16);
    goto L_00BC03;
L_00BC03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC03u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC03u, 7u, 3u, cpu.address("absx", 0xD800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC03 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xD800u), cpu.m8?8:16);
    goto L_00BC06;
L_00BC06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC06u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC06u, 7u, 3u, cpu.address("absx", 0xDA00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC06 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDA00u), cpu.m8?8:16);
    goto L_00BC09;
L_00BC09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC09u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC09u, 7u, 3u, cpu.address("absx", 0xDC00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC09 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDC00u), cpu.m8?8:16);
    goto L_00BC0C;
L_00BC0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Cu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Cu, 7u, 3u, cpu.address("absx", 0xDE00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC0C ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDE00u), cpu.m8?8:16);
    goto L_00BC0F;
L_00BC0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Fu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Fu, 7u, 3u, cpu.address("absx", 0xE000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC0F ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE000u), cpu.m8?8:16);
    goto L_00BC12;
L_00BC12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC12u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC12u, 7u, 3u, cpu.address("absx", 0xE200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC12 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE200u), cpu.m8?8:16);
    goto L_00BC15;
L_00BC15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC15u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC15u, 7u, 3u, cpu.address("absx", 0xE400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC15 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE400u), cpu.m8?8:16);
    goto L_00BC18;
L_00BC18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC18u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC18u, 7u, 3u, cpu.address("absx", 0xE600u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC18 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE600u), cpu.m8?8:16);
    goto L_00BC1B;
L_00BC1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Bu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Bu, 7u, 3u, cpu.address("absx", 0xE800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC1B ROR
    cpu.rorMem(hw, cpu.address("absx", 0xE800u), cpu.m8?8:16);
    goto L_00BC1E;
L_00BC1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu, 7u, 3u, cpu.address("absx", 0xEA00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC1E ROR
    cpu.rorMem(hw, cpu.address("absx", 0xEA00u), cpu.m8?8:16);
    goto L_00BC21;
L_00BC21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC21u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC21u, 7u, 3u, cpu.address("absx", 0xEC00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC21 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xEC00u), cpu.m8?8:16);
    goto L_00BC24;
L_00BC24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u, 7u, 3u, cpu.address("absx", 0xEE00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC24 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xEE00u), cpu.m8?8:16);
    goto L_00BC27;
L_00BC27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC27u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC27u, 7u, 3u, cpu.address("absx", 0xF000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC27 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF000u), cpu.m8?8:16);
    goto L_00BC2A;
L_00BC2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Au,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Au, 7u, 3u, cpu.address("absx", 0xF200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC2A ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF200u), cpu.m8?8:16);
    goto L_00BC2D;
L_00BC2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Du,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Du, 7u, 3u, cpu.address("absx", 0xF400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC2D ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF400u), cpu.m8?8:16);
    goto L_00BC30;
L_00BC30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC30u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC30u, 7u, 3u, cpu.address("absx", 0xF600u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC30 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF600u), cpu.m8?8:16);
    goto L_00BC33;
L_00BC33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC33u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC33u, 7u, 3u, cpu.address("absx", 0xF800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC33 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xF800u), cpu.m8?8:16);
    goto L_00BC36;
L_00BC36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC36u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC36u, 7u, 3u, cpu.address("absx", 0xFA00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC36 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xFA00u), cpu.m8?8:16);
    goto L_00BC39;
L_00BC39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC39u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC39u, 7u, 3u, cpu.address("absx", 0xFC00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC39 ROR
    cpu.rorMem(hw, cpu.address("absx", 0xFC00u), cpu.m8?8:16);
    goto L_00BC3C;
L_00BC3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Cu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Cu, 7u, 3u, cpu.address("absx", 0xFE00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC3C ROR
    cpu.rorMem(hw, cpu.address("absx", 0xFE00u), cpu.m8?8:16);
    goto L_00BC3F;
L_00BC3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Fu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Fu, 7u, 3u, cpu.address("absx", 0xC800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC3F ROR
    cpu.rorMem(hw, cpu.address("absx", 0xC800u), cpu.m8?8:16);
    goto L_00BC42;
L_00BC42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC42u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC42u, 5u, 4u, ((0x7FC9B0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00BC42 ADC
    cpu.adc(hw.readW(((0x7FC9B0u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00BC46;
L_00BC46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC46u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC46u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00BC46 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00BC46u);return;} hw.unresolvedReturn(0x00BC46u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CA6D_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CA6Du: goto L_00CA6D;
    case 0x00CA6Eu: goto L_00CA6E;
    case 0x00CA71u: goto L_00CA71;
    case 0x00CA74u: goto L_00CA74;
    case 0x00CA76u: goto L_00CA76;
    case 0x00CA77u: goto L_00CA77;
    case 0x00CA79u: goto L_00CA79;
    case 0x00CA7Bu: goto L_00CA7B;
    case 0x00CA7Du: goto L_00CA7D;
    case 0x00CA7Fu: goto L_00CA7F;
    case 0x00CA81u: goto L_00CA81;
    case 0x00CA83u: goto L_00CA83;
    case 0x00CA84u: goto L_00CA84;
    case 0x00CA86u: goto L_00CA86;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA6D CLC
    cpu.setFlag('C', false);
    goto L_00CA6E;
L_00CA6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Eu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Eu, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA6E ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1433u), cpu.m8?8:16));
    goto L_00CA71;
L_00CA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA71u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA71u, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA71 STA
    hw.write(cpu.address("abs", 0x1433u), cpu.a, cpu.m8?8:16);
    goto L_00CA74;
L_00CA74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA74u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA74u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA74 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CA76;
L_00CA76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA76u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA76u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA76 CLC
    cpu.setFlag('C', false);
    goto L_00CA77;
L_00CA77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA77u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA77u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA77 ADC
    cpu.adc(0x8u);
    goto L_00CA79;
L_00CA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA79u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA79u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA79 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00CA7B;
L_00CA7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA7B LDA
    cpu.setA(0x18u, 8);
    goto L_00CA7D;
L_00CA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA7D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CA7F;
L_00CA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA7F BEQ -> $00CA83
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA83; }
    goto L_00CA81;
L_00CA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA81u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA81 LDA
    cpu.setA(0x10u, 8);
    goto L_00CA83;
L_00CA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA83u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA83u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA83 CLC
    cpu.setFlag('C', false);
    goto L_00CA84;
L_00CA84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA84u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA84u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA84 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16));
    goto L_00CA86;
L_00CA86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA86u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA86u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA86 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA88u,0x00CA86u); return;
}

void sub_00CA6D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CA6Du: goto L_00CA6D;
    case 0x00CA6Eu: goto L_00CA6E;
    case 0x00CA71u: goto L_00CA71;
    case 0x00CA74u: goto L_00CA74;
    case 0x00CA76u: goto L_00CA76;
    case 0x00CA77u: goto L_00CA77;
    case 0x00CA79u: goto L_00CA79;
    case 0x00CA7Bu: goto L_00CA7B;
    case 0x00CA7Du: goto L_00CA7D;
    case 0x00CA7Fu: goto L_00CA7F;
    case 0x00CA81u: goto L_00CA81;
    case 0x00CA83u: goto L_00CA83;
    case 0x00CA84u: goto L_00CA84;
    case 0x00CA86u: goto L_00CA86;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA6D CLC
    cpu.setFlag('C', false);
    goto L_00CA6E;
L_00CA6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Eu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Eu, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA6E ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1433u), cpu.m8?8:16));
    goto L_00CA71;
L_00CA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA71u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA71u, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA71 STA
    hw.write(cpu.address("abs", 0x1433u), cpu.a, cpu.m8?8:16);
    goto L_00CA74;
L_00CA74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA74u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA74u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA74 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CA76;
L_00CA76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA76u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA76u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA76 CLC
    cpu.setFlag('C', false);
    goto L_00CA77;
L_00CA77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA77u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA77u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA77 ADC
    cpu.adc(0x8u);
    goto L_00CA79;
L_00CA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA79u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA79u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA79 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00CA7B;
L_00CA7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA7B LDA
    cpu.setA(0x18u, 8);
    goto L_00CA7D;
L_00CA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA7D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CA7F;
L_00CA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA7F BEQ -> $00CA83
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA83; }
    goto L_00CA81;
L_00CA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA81u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA81 LDA
    cpu.setA(0x10u, 8);
    goto L_00CA83;
L_00CA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA83u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA83u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA83 CLC
    cpu.setFlag('C', false);
    goto L_00CA84;
L_00CA84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA84u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA84u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA84 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16));
    goto L_00CA86;
L_00CA86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA86u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA86u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA86 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA88u,0x00CA86u); return;
}

void sub_00E2BD_E1M1X1C0_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00E32Eu: goto L_00E32E;
    case 0x00E330u: goto L_00E330;
    case 0x00E333u: goto L_00E333;
    case 0x00E335u: goto L_00E335;
    case 0x00E337u: goto L_00E337;
    case 0x00E339u: goto L_00E339;
    case 0x00E33Au: goto L_00E33A;
    case 0x00E33Bu: goto L_00E33B;
    case 0x00E33Cu: goto L_00E33C;
    case 0x00E33Du: goto L_00E33D;
    case 0x00E33Eu: goto L_00E33E;
    case 0x00E340u: goto L_00E340;
    case 0x00E342u: goto L_00E342;
    case 0x00E344u: goto L_00E344;
    case 0x00E346u: goto L_00E346;
    case 0x00E349u: goto L_00E349;
    case 0x00E34Cu: goto L_00E34C;
    case 0x00E34Du: goto L_00E34D;
    case 0x00E34Fu: goto L_00E34F;
    case 0x00E351u: goto L_00E351;
    case 0x00E353u: goto L_00E353;
    case 0x00E354u: goto L_00E354;
    case 0x00E355u: goto L_00E355;
    case 0x00E356u: goto L_00E356;
    case 0x00E357u: goto L_00E357;
    case 0x00E358u: goto L_00E358;
    case 0x00E359u: goto L_00E359;
    case 0x00E35Bu: goto L_00E35B;
    case 0x00E35Cu: goto L_00E35C;
    case 0x00E35Du: goto L_00E35D;
    case 0x00E35Eu: goto L_00E35E;
    case 0x00E360u: goto L_00E360;
    case 0x00E362u: goto L_00E362;
    case 0x00E364u: goto L_00E364;
    case 0x00E366u: goto L_00E366;
    case 0x00E369u: goto L_00E369;
    case 0x00E36Bu: goto L_00E36B;
    case 0x00E36Du: goto L_00E36D;
    case 0x00E370u: goto L_00E370;
    case 0x00E372u: goto L_00E372;
    case 0x00E373u: goto L_00E373;
    case 0x00E374u: goto L_00E374;
    case 0x00E375u: goto L_00E375;
    case 0x00E376u: goto L_00E376;
    case 0x00E379u: goto L_00E379;
    case 0x00E37Cu: goto L_00E37C;
    case 0x00E37Eu: goto L_00E37E;
    case 0x00E381u: goto L_00E381;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00E32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Eu))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E32E BCS -> $00E33E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00E33E; }
    goto L_00E330;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E32E BCS -> $00E33E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00E33E; }
    goto L_00E330;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E32E BCS -> $00E33E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00E33E; }
    goto L_00E330;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE32Eu,0x00E32Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE330u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u, 4u, 3u, cpu.address("abs", 0x13E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E330 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13E3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E333;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u, 4u, 3u, cpu.address("abs", 0x13E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E330 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13E3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E333;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u, 4u, 3u, cpu.address("abs", 0x13E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E330 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13E3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E333;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE330u,0x00E330u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE333u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E333 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00E335;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E333 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00E335;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E333 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00E335;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE333u,0x00E333u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE335u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE335u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE335u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E335 BEQ -> $00E33B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E33B; }
    goto L_00E337;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE335u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE335u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E335 BEQ -> $00E33B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E33B; }
    goto L_00E337;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE335u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE335u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E335 BEQ -> $00E33B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E33B; }
    goto L_00E337;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE335u,0x00E335u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE337u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E337 CPX
    cpu.compareX(0xD013u);
    goto L_00E33A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E337 CPX
    cpu.compareX(0xD013u);
    goto L_00E33A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E337 CPX
    cpu.compareX(0x13u);
    goto L_00E339;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE337u,0x00E337u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE339u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE339u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE339u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E339 BNE -> $00E33D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E33D; }
    goto L_00E33B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE339u,0x00E339u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xE33Cu,true);
    hw.requestDispatch(0x0082C3u,0x00E33Au);return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xE33Cu,true);
    hw.requestDispatch(0x0082C3u,0x00E33Au);return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE33Au,0x00E33Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E33B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Bu))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E33B EOR
    cpu.logicXor(0x1u);
    goto L_00E33D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E33B EOR
    cpu.logicXor(0x1u);
    goto L_00E33D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E33B EOR
    cpu.logicXor(0x1u);
    goto L_00E33D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE33Bu,0x00E33Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Cu,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Cu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x4Au + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00E33C ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0x4Au), cpu.m8?8:16));
    goto L_00E33E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Cu,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Cu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x4Au + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00E33C ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0x4Au), cpu.m8?8:16));
    goto L_00E33E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE33Cu,0x00E33Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Du))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E33D LSR
    cpu.lsrA();
    goto L_00E33E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E33D LSR
    cpu.lsrA();
    goto L_00E33E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E33D LSR
    cpu.lsrA();
    goto L_00E33E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE33Du,0x00E33Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E33E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Eu))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E33E REP
    cpu.rep(0x20u);
    goto L_00E340;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E33E REP
    cpu.rep(0x20u);
    goto L_00E340;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E33E REP
    cpu.rep(0x20u);
    goto L_00E340;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE33Eu,0x00E33Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE340u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE340u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE340u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E340 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E342;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE340u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE340u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E340 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E342;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE340u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE340u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E340 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E342;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE340u,0x00E340u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE342u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE342u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE342u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E342 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_00E344;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE342u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE342u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E342 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_00E344;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE342u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE342u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E342 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_00E344;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE342u,0x00E342u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE344u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE344u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE344u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E344 STA
    hw.write(cpu.address("dp", 0x7Eu), cpu.a, cpu.m8?8:16);
    goto L_00E346;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE344u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE344u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E344 STA
    hw.write(cpu.address("dp", 0x7Eu), cpu.a, cpu.m8?8:16);
    goto L_00E346;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE344u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE344u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E344 STA
    hw.write(cpu.address("dp", 0x7Eu), cpu.a, cpu.m8?8:16);
    goto L_00E346;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE344u,0x00E344u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E346:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE346u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE346u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE346u, 5u, 3u, cpu.address("abs", 0x188Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E346 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x188Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E349;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE346u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE346u, 5u, 3u, cpu.address("abs", 0x188Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E346 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x188Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E349;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE346u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE346u, 5u, 3u, cpu.address("abs", 0x188Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E346 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x188Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E349;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE346u,0x00E346u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE349u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E349 AND
    cpu.logicAnd(0xFFu);
    goto L_00E34C;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E349 AND
    cpu.logicAnd(0xFFu);
    goto L_00E34C;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E349 AND
    cpu.logicAnd(0xFFu);
    goto L_00E34C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE349u,0x00E349u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Cu))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E34C CLC
    cpu.setFlag('C', false);
    goto L_00E34D;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E34C CLC
    cpu.setFlag('C', false);
    goto L_00E34D;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E34C CLC
    cpu.setFlag('C', false);
    goto L_00E34D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE34Cu,0x00E34Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E34D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Du))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E34D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16));
    goto L_00E34F;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E34D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16));
    goto L_00E34F;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E34D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16));
    goto L_00E34F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE34Du,0x00E34Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Fu))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E34F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00E351;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E34F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00E351;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E34F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00E351;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE34Fu,0x00E34Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE351u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE351u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE351u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E351 CPY
    cpu.compareY(0xA001u);
    goto L_00E354;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE351u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE351u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E351 CPY
    cpu.compareY(0xA001u);
    goto L_00E354;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE351u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE351u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E351 CPY
    cpu.compareY(0x1u);
    goto L_00E353;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE351u,0x00E351u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E353:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE353u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE353u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE353u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E353 LDY
    cpu.setY(0x1u, 8);
    goto L_00E355;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE353u,0x00E353u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE354u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE354u,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE354u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xB0u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00E354 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0xB0u), cpu.m8?8:16));
    goto L_00E356;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE354u,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE354u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xB0u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00E354 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0xB0u), cpu.m8?8:16));
    goto L_00E356;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE354u,0x00E354u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE355u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE355u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE355u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E355 BCS -> $00E359
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00E359; }
    goto L_00E357;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE355u,0x00E355u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE356u))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE356u,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE356u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xE358u,true);
    hw.requestDispatch(0x0082C3u,0x00E356u);return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE356u,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE356u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xE358u,true);
    hw.requestDispatch(0x0082C3u,0x00E356u);return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE356u,0x00E356u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE357u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE357u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE357u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E357 DEC
    cpu.decReg('A');
    goto L_00E358;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE357u,0x00E357u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE358u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE358u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE358u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E358 DEY
    cpu.decReg('Y');
    goto L_00E359;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE358u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE358u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E358 DEY
    cpu.decReg('Y');
    goto L_00E359;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE358u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE358u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E358 DEY
    cpu.decReg('Y');
    goto L_00E359;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE358u,0x00E358u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE359u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE359u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE359u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E359 CPX
    cpu.compareX(0xB00Au);
    goto L_00E35C;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE359u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE359u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E359 CPX
    cpu.compareX(0xB00Au);
    goto L_00E35C;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE359u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE359u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E359 CPX
    cpu.compareX(0xAu);
    goto L_00E35B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE359u,0x00E359u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E35B BCS -> $00E360
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00E360; }
    goto L_00E35D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE35Bu,0x00E35Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E35C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Cu,cpu,0x03u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Cu, 5u, 2u, cpu.addressStack(0xCCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E35C ORA
    cpu.logicOr(hw.readW(cpu.addressStack(0xCCu), cpu.m8?8:16));
    goto L_00E35E;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Cu,cpu,0x03u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Cu, 5u, 2u, cpu.addressStack(0xCCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E35C ORA
    cpu.logicOr(hw.readW(cpu.addressStack(0xCCu), cpu.m8?8:16));
    goto L_00E35E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE35Cu,0x00E35Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E35D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Du,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Du, 4u, 3u, cpu.address("abs", 0x13DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E35D CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0x13DBu), cpu.x8?8:16));
    goto L_00E360;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE35Du,0x00E35Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E35E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE35Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Eu,cpu,0xDBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E35E STP
    hw.stopped=true; return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Eu,cpu,0xDBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE35Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E35E STP
    hw.stopped=true; return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE35Eu,0x00E35Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E360:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE360u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE360u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE360u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E360 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_00E362;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE360u,0x00E360u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE362u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE362u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE362u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E362 CPX
    cpu.compareX(0x1Cu);
    goto L_00E364;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE362u,0x00E362u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E364:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE364u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE364u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE364u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E364 BNE -> $00E369
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E369; }
    goto L_00E366;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE364u,0x00E364u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE366u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE366u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE366u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E366 ADC
    cpu.adc(0x1u);
    goto L_00E369;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE366u,0x00E366u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE369u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE369u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE369u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E369 STA
    hw.write(cpu.address("dp", 0x80u), cpu.a, cpu.m8?8:16);
    goto L_00E36B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE369u,0x00E369u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE36Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E36B SEP
    cpu.sep(0x20u);
    goto L_00E36D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE36Bu,0x00E36Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE36Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE36Du, 4u, 3u, cpu.address("abs", 0x1497u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E36D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1497u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E370;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE36Du,0x00E36Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE370u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE370u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE370u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E370 BEQ -> $00E385
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00E385u,0x00E370u); return; }
    goto L_00E372;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE370u,0x00E370u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE372u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE372u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE372u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E372 LSR
    cpu.lsrA();
    goto L_00E373;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE372u,0x00E372u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE373u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE373u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE373u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E373 LSR
    cpu.lsrA();
    goto L_00E374;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE373u,0x00E373u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE374u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE374u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE374u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E374 LSR
    cpu.lsrA();
    goto L_00E375;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE374u,0x00E374u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E375:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE375u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE375u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE375u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E375 TAY
    cpu.transfer("TAY");
    goto L_00E376;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE375u,0x00E375u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE376u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE376u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE376u, 4u + ((((0xE292u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE292u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E376 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE292u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E379;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE376u,0x00E376u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE379u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE379u,cpu,0x2Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE379u, 4u, 3u, cpu.address("abs", 0x1497u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E379 AND
    cpu.logicAnd(hw.readW(cpu.address("abs", 0x1497u), cpu.m8?8:16));
    goto L_00E37C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE379u,0x00E379u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E37C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E37C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16));
    goto L_00E37E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE37Cu,0x00E37Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Eu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Eu, 4u, 3u, cpu.address("abs", 0x13FBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E37E ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13FBu), cpu.m8?8:16));
    goto L_00E381;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE37Eu,0x00E37Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE381u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE381u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE381u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E381 BNE -> $00E385
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00E385u,0x00E381u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE383u,0x00E381u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE381u,0x00E381u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E0M1X1CQ_part30(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF62u: goto L_00EF62;
    case 0x00EF63u: goto L_00EF63;
    case 0x00EF65u: goto L_00EF65;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF62u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF62u,0x00EF62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF63u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    goto L_00EF65;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    goto L_00EF65;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    goto L_00EF65;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    goto L_00EF65;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF68u,0x00EF63u); return; }
    goto L_00EF65;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF63u,0x00EF63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF65u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF68u,0x00EF65u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF68u,0x00EF65u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF68u,0x00EF65u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF68u,0x00EF65u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF68u,0x00EF65u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00F62D_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F62Du: goto L_00F62D;
    case 0x00F62Fu: goto L_00F62F;
    case 0x00F631u: goto L_00F631;
    case 0x00F633u: goto L_00F633;
    case 0x00F635u: goto L_00F635;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F62D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62D STZ
    hw.write(cpu.address("dp", 0x15u), 0, cpu.m8?8:16);
    goto L_00F62F;
L_00F62F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62F STZ
    hw.write(cpu.address("dp", 0x16u), 0, cpu.m8?8:16);
    goto L_00F631;
L_00F631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF631u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F631 STZ
    hw.write(cpu.address("dp", 0x17u), 0, cpu.m8?8:16);
    goto L_00F633;
L_00F633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F633 STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_00F635;
L_00F635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF635u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F635 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F635u);return;} hw.unresolvedReturn(0x00F635u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00F62D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F62Du: goto L_00F62D;
    case 0x00F62Fu: goto L_00F62F;
    case 0x00F631u: goto L_00F631;
    case 0x00F633u: goto L_00F633;
    case 0x00F635u: goto L_00F635;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F62D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62D STZ
    hw.write(cpu.address("dp", 0x15u), 0, cpu.m8?8:16);
    goto L_00F62F;
L_00F62F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62F STZ
    hw.write(cpu.address("dp", 0x16u), 0, cpu.m8?8:16);
    goto L_00F631;
L_00F631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF631u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F631 STZ
    hw.write(cpu.address("dp", 0x17u), 0, cpu.m8?8:16);
    goto L_00F633;
L_00F633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F633 STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_00F635;
L_00F635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF635u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F635 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F635u);return;} hw.unresolvedReturn(0x00F635u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00FB00_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00FB00u: goto L_00FB00;
    case 0x00FB02u: goto L_00FB02;
    case 0x00FB05u: goto L_00FB05;
    case 0x00FB07u: goto L_00FB07;
    case 0x00FB09u: goto L_00FB09;
    case 0x00FB0Cu: goto L_00FB0C;
    case 0x00FB0Eu: goto L_00FB0E;
    case 0x00FB10u: goto L_00FB10;
    case 0x00FB13u: goto L_00FB13;
    case 0x00FB15u: goto L_00FB15;
    case 0x00FB17u: goto L_00FB17;
    case 0x00FB19u: goto L_00FB19;
    case 0x00FB1Bu: goto L_00FB1B;
    case 0x00FB1Du: goto L_00FB1D;
    case 0x00FB1Fu: goto L_00FB1F;
    case 0x00FB21u: goto L_00FB21;
    case 0x00FB23u: goto L_00FB23;
    case 0x00FB24u: goto L_00FB24;
    case 0x00FB25u: goto L_00FB25;
    case 0x00FB27u: goto L_00FB27;
    case 0x00FB28u: goto L_00FB28;
    case 0x00FB29u: goto L_00FB29;
    case 0x00FB2Au: goto L_00FB2A;
    case 0x00FB2Cu: goto L_00FB2C;
    case 0x00FB2Du: goto L_00FB2D;
    case 0x00FB2Eu: goto L_00FB2E;
    case 0x00FB2Fu: goto L_00FB2F;
    case 0x00FB31u: goto L_00FB31;
    case 0x00FB32u: goto L_00FB32;
    case 0x00FB36u: goto L_00FB36;
    case 0x00FB39u: goto L_00FB39;
    case 0x00FB3Du: goto L_00FB3D;
    case 0x00FB3Fu: goto L_00FB3F;
    case 0x00FB41u: goto L_00FB41;
    case 0x00FB43u: goto L_00FB43;
    case 0x00FB45u: goto L_00FB45;
    case 0x00FB47u: goto L_00FB47;
    case 0x00FB48u: goto L_00FB48;
    case 0x00FB4Au: goto L_00FB4A;
    case 0x00FB4Cu: goto L_00FB4C;
    case 0x00FB4Du: goto L_00FB4D;
    case 0x00FB4Fu: goto L_00FB4F;
    case 0x00FB51u: goto L_00FB51;
    case 0x00FB53u: goto L_00FB53;
    case 0x00FB55u: goto L_00FB55;
    case 0x00FB58u: goto L_00FB58;
    case 0x00FB5Au: goto L_00FB5A;
    case 0x00FB5Cu: goto L_00FB5C;
    case 0x00FB5Fu: goto L_00FB5F;
    case 0x00FB60u: goto L_00FB60;
    case 0x00FB64u: goto L_00FB64;
    case 0x00FB66u: goto L_00FB66;
    case 0x00FB69u: goto L_00FB69;
    case 0x00FB6Bu: goto L_00FB6B;
    case 0x00FB6Eu: goto L_00FB6E;
    case 0x00FB70u: goto L_00FB70;
    case 0x00FB73u: goto L_00FB73;
    case 0x00FB75u: goto L_00FB75;
    case 0x00FB78u: goto L_00FB78;
    case 0x00FB7Au: goto L_00FB7A;
    case 0x00FB7Du: goto L_00FB7D;
    case 0x00FB7Fu: goto L_00FB7F;
    case 0x00FB82u: goto L_00FB82;
    case 0x00FB84u: goto L_00FB84;
    case 0x00FB87u: goto L_00FB87;
    case 0x00FB89u: goto L_00FB89;
    case 0x00FB8Au: goto L_00FB8A;
    case 0x00FB8Cu: goto L_00FB8C;
    case 0x00FB8Du: goto L_00FB8D;
    case 0x00FB8Fu: goto L_00FB8F;
    case 0x00FB92u: goto L_00FB92;
    case 0x00FB95u: goto L_00FB95;
    case 0x00FB98u: goto L_00FB98;
    case 0x00FB9Bu: goto L_00FB9B;
    case 0x00FB9Eu: goto L_00FB9E;
    case 0x00FBA0u: goto L_00FBA0;
    case 0x00FBA3u: goto L_00FBA3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00FB00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB00u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB00u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB00 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00FB02;
L_00FB02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB02u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB02u, 4u, 3u, cpu.address("abs", 0x1490u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB02 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1490u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FB05;
L_00FB05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB05u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB05u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB05 BEQ -> $00FB09
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FB09; }
    goto L_00FB07;
L_00FB07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB07u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB07 LDX
    cpu.setX(0x4u, 8);
    goto L_00FB09;
L_00FB09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB09u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB09u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB09 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FB0C;
L_00FB0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB0C BEQ -> $00FB10
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FB10; }
    goto L_00FB0E;
L_00FB0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB0E LDX
    cpu.setX(0x5u, 8);
    goto L_00FB10;
L_00FB10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB10u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB10u, 4u + ((((0x009Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x009Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB10 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FB13;
L_00FB13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB13u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB13 CMP
    cpu.compareA(0x2Fu);
    goto L_00FB15;
L_00FB15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB15u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB15u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB15 BEQ -> $00FB2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FB2D; }
    goto L_00FB17;
L_00FB17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB17u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB17 CMP
    cpu.compareA(0x3Eu);
    goto L_00FB19;
L_00FB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB19u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB19 BEQ -> $00FB2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FB2D; }
    goto L_00FB1B;
L_00FB1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB1B CMP
    cpu.compareA(0x80u);
    goto L_00FB1D;
L_00FB1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB1D BEQ -> $00FB28
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FB28; }
    goto L_00FB1F;
L_00FB1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB1F CMP
    cpu.compareA(0x2Du);
    goto L_00FB21;
L_00FB21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB21u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB21 BNE -> $00FB32
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FB32; }
    goto L_00FB23;
L_00FB23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB23u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB23 TXA
    cpu.transfer("TXA");
    goto L_00FB24;
L_00FB24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB24u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB24 CLC
    cpu.setFlag('C', false);
    goto L_00FB25;
L_00FB25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB25u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB25 ADC
    cpu.adc(0x7u);
    goto L_00FB27;
L_00FB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB27u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB27u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB27 TAX
    cpu.transfer("TAX");
    goto L_00FB28;
L_00FB28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB28u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB28u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB28 TXA
    cpu.transfer("TXA");
    goto L_00FB29;
L_00FB29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB29 CLC
    cpu.setFlag('C', false);
    goto L_00FB2A;
L_00FB2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB2A ADC
    cpu.adc(0x7u);
    goto L_00FB2C;
L_00FB2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB2C TAX
    cpu.transfer("TAX");
    goto L_00FB2D;
L_00FB2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB2D TXA
    cpu.transfer("TXA");
    goto L_00FB2E;
L_00FB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB2E CLC
    cpu.setFlag('C', false);
    goto L_00FB2F;
L_00FB2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB2F ADC
    cpu.adc(0x7u);
    goto L_00FB31;
L_00FB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB31 TAX
    cpu.transfer("TAX");
    goto L_00FB32;
L_00FB32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB32u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB32u, 5u, 4u, ((0x00FADFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB32 LDA
    cpu.loadA(hw.readW(((0xFADFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FB36;
L_00FB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u, 4u, 3u, cpu.address("abs", 0x0DC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB36 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDC2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00FB39;
L_00FB39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB39u,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB39u, 5u, 4u, ((0x00FAFBu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB39 CMP
    cpu.compareA(hw.readW(((0xFAFBu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB3D;
L_00FB3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB3D BNE -> $00FB41
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FB41; }
    goto L_00FB3F;
L_00FB3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB3F LDA
    cpu.setA(0x78u, 8);
    goto L_00FB41;
L_00FB41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB41u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB41u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB41 STZ
    hw.write(cpu.address("dp", 0xFu), 0, cpu.m8?8:16);
    goto L_00FB43;
L_00FB43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB43u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB43 CMP
    cpu.compareA(0xE0u);
    goto L_00FB45;
L_00FB45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB45u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB45 BCC -> $00FB55
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00FB55; }
    goto L_00FB47;
L_00FB47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB47u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB47u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00FB47 PHA
    cpu.push("PHA", hw);
    goto L_00FB48;
L_00FB48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB48u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB48u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB48 AND
    cpu.logicAnd(0xFu);
    goto L_00FB4A;
L_00FB4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB4A STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_00FB4C;
L_00FB4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Cu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00FB4C PLA
    cpu.pop("PLA", hw);
    goto L_00FB4D;
L_00FB4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB4D CMP
    cpu.compareA(0xF0u);
    goto L_00FB4F;
L_00FB4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB4F LDA
    cpu.setA(0x78u, 8);
    goto L_00FB51;
L_00FB51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB51u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB51u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB51 BCS -> $00FB55
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00FB55; }
    goto L_00FB53;
L_00FB53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB53u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB53 LDA
    cpu.setA(0x78u, 8);
    goto L_00FB55;
L_00FB55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB55u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB55u, 5u, 3u, cpu.address("absy", 0x009Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB55 STA
    hw.write(cpu.address("absy", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_00FB58;
L_00FB58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB58u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB58 CMP
    cpu.compareA(0x76u);
    goto L_00FB5A;
L_00FB5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB5A BNE -> $00FB5F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FB5F; }
    goto L_00FB5C;
L_00FB5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Cu, 6u, 3u, cpu.address("abs", 0x13CBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB5C INC
    cpu.incMem(hw, cpu.address("abs", 0x13CBu), cpu.m8?8:16);
    goto L_00FB5F;
L_00FB5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Fu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB5F TYX
    cpu.transfer("TYX");
    goto L_00FB60;
L_00FB60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB60u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB60u, 8u, 4u, 0x07F7D2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00FB60 JSL -> $07F7D2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xFB63u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFB64u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F7D2u, 0x00FB60u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00FB64;
L_00FB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB64u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFB64u,0x00FB64u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB64u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB64u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB64 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FB66;
L_00FB66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB66u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB66u, 5u, 3u, cpu.address("absy", 0x1594u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB66 STA
    hw.write(cpu.address("absy", 0x1594u), cpu.a, cpu.m8?8:16);
    goto L_00FB69;
L_00FB69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB69u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB69u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB69 LDA
    cpu.setA(0xCu, 8);
    goto L_00FB6B;
L_00FB6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB6Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB6Bu, 5u, 3u, cpu.address("absy", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB6B STA
    hw.write(cpu.address("absy", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_00FB6E;
L_00FB6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB6Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB6E LDA
    cpu.setA(0xD0u, 8);
    goto L_00FB70;
L_00FB70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB70u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB70u, 5u, 3u, cpu.address("absy", 0x00AAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB70 STA
    hw.write(cpu.address("absy", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_00FB73;
L_00FB73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB73u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB73u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB73 LDA
    cpu.setA(0x5u, 8);
    goto L_00FB75;
L_00FB75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB75u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB75u, 5u, 3u, cpu.address("absy", 0x00B6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB75 STA
    hw.write(cpu.address("absy", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_00FB78;
L_00FB78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB78u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB78 LDA
    cpu.setA(0x20u, 8);
    goto L_00FB7A;
L_00FB7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB7Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB7Au, 5u, 3u, cpu.address("absy", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB7A STA
    hw.write(cpu.address("absy", 0x154Cu), cpu.a, cpu.m8?8:16);
    goto L_00FB7D;
L_00FB7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB7Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB7D LDA
    cpu.setA(0xCu, 8);
    goto L_00FB7F;
L_00FB7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB7Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB7Fu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB7F STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_00FB82;
L_00FB82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB82u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB82 LDX
    cpu.setX(0x3u, 8);
    goto L_00FB84;
L_00FB84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB84u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB84u, 4u + ((((0x17C0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x17C0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB84 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x17C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FB87;
L_00FB87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB87u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB87 BEQ -> $00FB8D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FB8D; }
    goto L_00FB89;
L_00FB89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB89u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB89 DEX
    cpu.decReg('X');
    goto L_00FB8A;
L_00FB8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB8Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB8A BPL -> $00FB84
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00FB84; }
    goto L_00FB8C;
L_00FB8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB8Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB8Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00FB8C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00FB8Cu);return;} hw.unresolvedReturn(0x00FB8Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00FB8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB8Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB8D LDA
    cpu.setA(0x1u, 8);
    goto L_00FB8F;
L_00FB8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB8Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB8Fu, 5u, 3u, cpu.address("absx", 0x17C0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB8F STA
    hw.write(cpu.address("absx", 0x17C0u), cpu.a, cpu.m8?8:16);
    goto L_00FB92;
L_00FB92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB92u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB92u, 4u + ((((0x00D8u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x00D8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB92 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FB95;
L_00FB95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB95u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB95u, 5u, 3u, cpu.address("absx", 0x17C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB95 STA
    hw.write(cpu.address("absx", 0x17C4u), cpu.a, cpu.m8?8:16);
    goto L_00FB98;
L_00FB98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB98u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB98u, 4u + ((((0x00E4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x00E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB98 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FB9B;
L_00FB9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB9Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB9Bu, 5u, 3u, cpu.address("absx", 0x17C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB9B STA
    hw.write(cpu.address("absx", 0x17C8u), cpu.a, cpu.m8?8:16);
    goto L_00FB9E;
L_00FB9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB9Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB9Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB9E LDA
    cpu.setA(0x1Bu, 8);
    goto L_00FBA0;
L_00FBA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBA0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBA0u, 5u, 3u, cpu.address("absx", 0x17CCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBA0 STA
    hw.write(cpu.address("absx", 0x17CCu), cpu.a, cpu.m8?8:16);
    goto L_00FBA3;
L_00FBA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBA3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBA3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00FBA3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00FBA3u);return;} hw.unresolvedReturn(0x00FBA3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0180CB_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0180CBu: goto L_0180CB;
    case 0x0180CEu: goto L_0180CE;
    case 0x0180D1u: goto L_0180D1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0180CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180CB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0180CE;
L_0180CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CEu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CEu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0180CE ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16));
    goto L_0180D1;
L_0180D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0180D1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0180D1u);return;} hw.unresolvedReturn(0x0180D1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02ACE5_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02ACE5u: goto L_02ACE5;
    case 0x02ACE6u: goto L_02ACE6;
    case 0x02ACE7u: goto L_02ACE7;
    case 0x02ACE9u: goto L_02ACE9;
    case 0x02ACEDu: goto L_02ACED;
    case 0x02ACEEu: goto L_02ACEE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02ACE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE5u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE5u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02ACE5 PHX
    cpu.push("PHX", hw);
    goto L_02ACE6;
L_02ACE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ACE6 CLC
    cpu.setFlag('C', false);
    goto L_02ACE7;
L_02ACE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ACE7 ADC
    cpu.adc(0x5u);
    goto L_02ACE9;
L_02ACE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE9u, 8u, 4u, 0x02ACEFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02ACE9 JSL -> $02ACEF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xACECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xACEDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACEFu, 0x02ACE9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02ACED;
L_02ACED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEDu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACEDu,0x02ACEDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEDu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02ACED PLX
    cpu.pop("PLX", hw);
    goto L_02ACEE;
L_02ACEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02ACEE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02ACEEu);return;} hw.unresolvedReturn(0x02ACEEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_02B9BD_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02B9BDu: goto L_02B9BD;
    case 0x02B9BFu: goto L_02B9BF;
    case 0x02B9C2u: goto L_02B9C2;
    case 0x02B9C4u: goto L_02B9C4;
    case 0x02B9C7u: goto L_02B9C7;
    case 0x02B9C9u: goto L_02B9C9;
    case 0x02B9CBu: goto L_02B9CB;
    case 0x02B9CEu: goto L_02B9CE;
    case 0x02B9D0u: goto L_02B9D0;
    case 0x02B9D2u: goto L_02B9D2;
    case 0x02B9D5u: goto L_02B9D5;
    case 0x02B9D6u: goto L_02B9D6;
    case 0x02B9D8u: goto L_02B9D8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02B9BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B9BD LDA
    cpu.setA(0x2u, 8);
    goto L_02B9BF;
L_02B9BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BFu, 4u, 3u, cpu.address("abs", 0x18DDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B9BF STA
    hw.write(cpu.address("abs", 0x18DDu), cpu.a, cpu.m8?8:16);
    goto L_02B9C2;
L_02B9C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B9C2 LDY
    cpu.setY(0x9u, 8);
    goto L_02B9C4;
L_02B9C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C4u, 4u + ((((0x14C8u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B9C4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02B9C7;
L_02B9C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B9C7 CMP
    cpu.compareA(0x8u);
    goto L_02B9C9;
L_02B9C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B9C9 BCC -> $02B9D5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_02B9D5; }
    goto L_02B9CB;
L_02B9CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CBu, 4u + ((((0x190Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B9CB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02B9CE;
L_02B9CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B9CE AND
    cpu.logicAnd(0x40u);
    goto L_02B9D0;
L_02B9D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B9D0 BNE -> $02B9D5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02B9D5; }
    goto L_02B9D2;
L_02B9D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D2u, 6u, 3u, cpu.address("abs", 0xB9D9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02B9D2 JSR -> $02B9D9 stack real
    { cpu.push16Value(hw,0xB9D4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB9D5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB9D9u), 0x02B9D2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02B9D5;
L_02B9D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9D5u,0x02B9D5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D5u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B9D5 DEY
    cpu.decReg('Y');
    goto L_02B9D6;
L_02B9D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B9D6 BPL -> $02B9C4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02B9C4; }
    goto L_02B9D8;
L_02B9D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02B9D8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02B9D8u);return;} hw.unresolvedReturn(0x02B9D8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_02EAF2_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02EAF2u: goto L_02EAF2;
    case 0x02EAF6u: goto L_02EAF6;
    case 0x02EAF8u: goto L_02EAF8;
    case 0x02EAFAu: goto L_02EAFA;
    case 0x02EAFDu: goto L_02EAFD;
    case 0x02EAFFu: goto L_02EAFF;
    case 0x02EB02u: goto L_02EB02;
    case 0x02EB04u: goto L_02EB04;
    case 0x02EB07u: goto L_02EB07;
    case 0x02EB0Au: goto L_02EB0A;
    case 0x02EB0Du: goto L_02EB0D;
    case 0x02EB0Fu: goto L_02EB0F;
    case 0x02EB12u: goto L_02EB12;
    case 0x02EB15u: goto L_02EB15;
    case 0x02EB18u: goto L_02EB18;
    case 0x02EB19u: goto L_02EB19;
    case 0x02EB1Du: goto L_02EB1D;
    case 0x02EB1Fu: goto L_02EB1F;
    case 0x02EB22u: goto L_02EB22;
    case 0x02EB24u: goto L_02EB24;
    case 0x02EB26u: goto L_02EB26;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02EAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF2u, 8u, 4u, 0x02A9E4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02EAF2 JSL -> $02A9E4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEAF5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEAF6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02A9E4u, 0x02EAF2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02EAF6;
L_02EAF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAF6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEAF6u,0x02EAF6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EAF6 BMI -> $02EB26
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_02EB26; }
    goto L_02EAF8;
L_02EAF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EAF8 LDA
    cpu.setA(0x8u, 8);
    goto L_02EAFA;
L_02EAFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAFAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAFAu, 5u, 3u, cpu.address("absy", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EAFA STA
    hw.write(cpu.address("absy", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_02EAFD;
L_02EAFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAFDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EAFD LDA
    cpu.setA(0x77u, 8);
    goto L_02EAFF;
L_02EAFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAFFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAFFu, 5u, 3u, cpu.address("absy", 0x009Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EAFF STA
    hw.write(cpu.address("absy", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_02EB02;
L_02EB02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB02u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB02u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EB02 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02EB04;
L_02EB04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB04u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB04u, 5u, 3u, cpu.address("absy", 0x00E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EB04 STA
    hw.write(cpu.address("absy", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_02EB07;
L_02EB07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB07u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB07u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EB07 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02EB0A;
L_02EB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Au, 5u, 3u, cpu.address("absy", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EB0A STA
    hw.write(cpu.address("absy", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_02EB0D;
L_02EB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EB0D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02EB0F;
L_02EB0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB0Fu, 5u, 3u, cpu.address("absy", 0x00D8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EB0F STA
    hw.write(cpu.address("absy", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_02EB12;
L_02EB12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB12u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB12u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EB12 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02EB15;
L_02EB15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB15u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB15u, 5u, 3u, cpu.address("absy", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EB15 STA
    hw.write(cpu.address("absy", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_02EB18;
L_02EB18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB18u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EB18 TYX
    cpu.transfer("TYX");
    goto L_02EB19;
L_02EB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB19u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB19u, 8u, 4u, 0x07F7D2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02EB19 JSL -> $07F7D2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEB1Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEB1Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F7D2u, 0x02EB19u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02EB1D;
L_02EB1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB1Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEB1Du,0x02EB1Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EB1D LDA
    cpu.setA(0x30u, 8);
    goto L_02EB1F;
L_02EB1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB1Fu, 5u, 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EB1F STA
    hw.write(cpu.address("absx", 0x154Cu), cpu.a, cpu.m8?8:16);
    goto L_02EB22;
L_02EB22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB22u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EB22 LDA
    cpu.setA(0xD0u, 8);
    goto L_02EB24;
L_02EB24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB24u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB24u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02EB24 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_02EB26;
L_02EB26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEB26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEB26u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEB26u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02EB26 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02EB26u);return;} hw.unresolvedReturn(0x02EB26u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_05877E_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05877Eu: goto L_05877E;
    case 0x05877Fu: goto L_05877F;
    case 0x058781u: goto L_058781;
    case 0x058783u: goto L_058783;
    case 0x058785u: goto L_058785;
    case 0x058787u: goto L_058787;
    case 0x058789u: goto L_058789;
    case 0x05878Bu: goto L_05878B;
    case 0x05878Cu: goto L_05878C;
    case 0x05878Du: goto L_05878D;
    case 0x05878Eu: goto L_05878E;
    case 0x05878Fu: goto L_05878F;
    case 0x058790u: goto L_058790;
    case 0x058791u: goto L_058791;
    case 0x058794u: goto L_058794;
    case 0x058796u: goto L_058796;
    case 0x058797u: goto L_058797;
    case 0x058798u: goto L_058798;
    case 0x05879Bu: goto L_05879B;
    case 0x05879Du: goto L_05879D;
    case 0x05879Fu: goto L_05879F;
    case 0x0587A1u: goto L_0587A1;
    case 0x0587A2u: goto L_0587A2;
    case 0x0587A4u: goto L_0587A4;
    case 0x0587A5u: goto L_0587A5;
    case 0x0587A6u: goto L_0587A6;
    case 0x0587A7u: goto L_0587A7;
    case 0x0587A9u: goto L_0587A9;
    case 0x0587ACu: goto L_0587AC;
    case 0x0587ADu: goto L_0587AD;
    case 0x0587B0u: goto L_0587B0;
    case 0x0587B1u: goto L_0587B1;
    case 0x0587B2u: goto L_0587B2;
    case 0x0587B5u: goto L_0587B5;
    case 0x0587B7u: goto L_0587B7;
    case 0x0587BBu: goto L_0587BB;
    case 0x0587BEu: goto L_0587BE;
    case 0x0587BFu: goto L_0587BF;
    case 0x0587C0u: goto L_0587C0;
    case 0x0587C1u: goto L_0587C1;
    case 0x0587C4u: goto L_0587C4;
    case 0x0587C6u: goto L_0587C6;
    case 0x0587C8u: goto L_0587C8;
    case 0x0587CBu: goto L_0587CB;
    case 0x0587CDu: goto L_0587CD;
    case 0x0587CFu: goto L_0587CF;
    case 0x0587D0u: goto L_0587D0;
    case 0x0587D1u: goto L_0587D1;
    case 0x0587D2u: goto L_0587D2;
    case 0x0587D3u: goto L_0587D3;
    case 0x0587D4u: goto L_0587D4;
    case 0x0587D5u: goto L_0587D5;
    case 0x0587D8u: goto L_0587D8;
    case 0x0587DAu: goto L_0587DA;
    case 0x0587DBu: goto L_0587DB;
    case 0x0587DCu: goto L_0587DC;
    case 0x0587DFu: goto L_0587DF;
    case 0x0587E1u: goto L_0587E1;
    case 0x0587E3u: goto L_0587E3;
    case 0x0587E5u: goto L_0587E5;
    case 0x0587E7u: goto L_0587E7;
    case 0x0587E9u: goto L_0587E9;
    case 0x0587EBu: goto L_0587EB;
    case 0x0587EDu: goto L_0587ED;
    case 0x0587EEu: goto L_0587EE;
    case 0x0587EFu: goto L_0587EF;
    case 0x0587F0u: goto L_0587F0;
    case 0x0587F1u: goto L_0587F1;
    case 0x0587F2u: goto L_0587F2;
    case 0x0587F3u: goto L_0587F3;
    case 0x0587F6u: goto L_0587F6;
    case 0x0587F8u: goto L_0587F8;
    case 0x0587F9u: goto L_0587F9;
    case 0x0587FAu: goto L_0587FA;
    case 0x0587FDu: goto L_0587FD;
    case 0x0587FFu: goto L_0587FF;
    case 0x058802u: goto L_058802;
    case 0x058804u: goto L_058804;
    case 0x058806u: goto L_058806;
    case 0x058807u: goto L_058807;
    case 0x058808u: goto L_058808;
    case 0x058809u: goto L_058809;
    case 0x05880Au: goto L_05880A;
    case 0x05880Bu: goto L_05880B;
    case 0x05880Cu: goto L_05880C;
    case 0x05880Fu: goto L_05880F;
    case 0x058811u: goto L_058811;
    case 0x058812u: goto L_058812;
    case 0x058813u: goto L_058813;
    case 0x058816u: goto L_058816;
    case 0x058818u: goto L_058818;
    case 0x058819u: goto L_058819;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05877E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05877E PHP
    cpu.push("PHP", hw);
    goto L_05877F;
L_05877F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05877F SEP
    cpu.sep(0x20u);
    goto L_058781;
L_058781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8781u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8781u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058781 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058783;
L_058783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058783 AND
    cpu.logicAnd(0x1u);
    goto L_058785;
L_058785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058785 BNE -> $0587CB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0587CB; }
    goto L_058787;
L_058787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8787u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8787u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058787 REP
    cpu.rep(0x20u);
    goto L_058789;
L_058789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8789u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8789u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058789 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05878B;
L_05878B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05878B LSR
    cpu.lsrA();
    goto L_05878C;
L_05878C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05878C LSR
    cpu.lsrA();
    goto L_05878D;
L_05878D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05878D LSR
    cpu.lsrA();
    goto L_05878E;
L_05878E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05878E LSR
    cpu.lsrA();
    goto L_05878F;
L_05878F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05878F TAY
    cpu.transfer("TAY");
    goto L_058790;
L_058790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8790u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8790u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058790 SEC
    cpu.setFlag('C', true);
    goto L_058791;
L_058791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8791u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8791u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058791 SBC
    cpu.sbc(0x8u);
    goto L_058794;
L_058794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8794u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8794u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x45u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058794 STA
    hw.write(cpu.address("dp", 0x45u), cpu.a, cpu.m8?8:16);
    goto L_058796;
L_058796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8796u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8796u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058796 TYA
    cpu.transfer("TYA");
    goto L_058797;
L_058797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058797 CLC
    cpu.setFlag('C', false);
    goto L_058798;
L_058798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8798u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8798u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058798 ADC
    cpu.adc(0x17u);
    goto L_05879B;
L_05879B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05879B STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_05879D;
L_05879D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05879D SEP
    cpu.sep(0x30u);
    goto L_05879F;
L_05879F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x55u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05879F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x55u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0587A1;
L_0587A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587A1 TAX
    cpu.transfer("TAX");
    goto L_0587A2;
L_0587A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587A2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0587A4;
L_0587A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587A4 LSR
    cpu.lsrA();
    goto L_0587A5;
L_0587A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587A5 LSR
    cpu.lsrA();
    goto L_0587A6;
L_0587A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587A6 LSR
    cpu.lsrA();
    goto L_0587A7;
L_0587A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587A7 REP
    cpu.rep(0x30u);
    goto L_0587A9;
L_0587A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587A9 AND
    cpu.logicAnd(0x6u);
    goto L_0587AC;
L_0587AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ACu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587AC TAX
    cpu.transfer("TAX");
    goto L_0587AD;
L_0587AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587AD LDA
    cpu.setA(0x133u, 16);
    goto L_0587B0;
L_0587B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587B0 ASL
    cpu.aslA();
    goto L_0587B1;
L_0587B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587B1 TAY
    cpu.transfer("TAY");
    goto L_0587B2;
L_0587B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587B2 LDA
    cpu.setA(0x7u, 16);
    goto L_0587B5;
L_0587B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587B5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0587B7;
L_0587B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u, 6u, 4u, ((0x058776u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587B7 LDA
    cpu.loadA(hw.readW(((0x58776u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0587BB;
L_0587BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BBu, 6u, 3u, cpu.address("absy", 0x0FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587BB STA
    hw.write(cpu.address("absy", 0xFBEu), cpu.a, cpu.m8?8:16);
    goto L_0587BE;
L_0587BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587BE INY
    cpu.inc('Y');
    goto L_0587BF;
L_0587BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587BF INY
    cpu.inc('Y');
    goto L_0587C0;
L_0587C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587C0 CLC
    cpu.setFlag('C', false);
    goto L_0587C1;
L_0587C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587C1 ADC
    cpu.adc(0x8u);
    goto L_0587C4;
L_0587C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C4u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587C4 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0587C6;
L_0587C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587C6 BPL -> $0587BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0587BB; }
    goto L_0587C8;
L_0587C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u, 3u, 3u, cpu.address("abs", 0x87E1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587C8 JMP -> $0587E1
    goto L_0587E1;
L_0587CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587CB REP
    cpu.rep(0x20u);
    goto L_0587CD;
L_0587CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587CD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0587CF;
L_0587CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587CF LSR
    cpu.lsrA();
    goto L_0587D0;
L_0587D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587D0 LSR
    cpu.lsrA();
    goto L_0587D1;
L_0587D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587D1 LSR
    cpu.lsrA();
    goto L_0587D2;
L_0587D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587D2 LSR
    cpu.lsrA();
    goto L_0587D3;
L_0587D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587D3 TAY
    cpu.transfer("TAY");
    goto L_0587D4;
L_0587D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587D4 SEC
    cpu.setFlag('C', true);
    goto L_0587D5;
L_0587D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D5u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587D5 SBC
    cpu.sbc(0x8u);
    goto L_0587D8;
L_0587D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x45u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587D8 STA
    hw.write(cpu.address("dp", 0x45u), cpu.a, cpu.m8?8:16);
    goto L_0587DA;
L_0587DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587DA TYA
    cpu.transfer("TYA");
    goto L_0587DB;
L_0587DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587DB CLC
    cpu.setFlag('C', false);
    goto L_0587DC;
L_0587DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587DC ADC
    cpu.adc(0x17u);
    goto L_0587DF;
L_0587DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587DF STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_0587E1;
L_0587E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587E1 SEP
    cpu.sep(0x20u);
    goto L_0587E3;
L_0587E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587E3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0587E5;
L_0587E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587E5 AND
    cpu.logicAnd(0x2u);
    goto L_0587E7;
L_0587E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587E7 BNE -> $058802
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_058802; }
    goto L_0587E9;
L_0587E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587E9 REP
    cpu.rep(0x20u);
    goto L_0587EB;
L_0587EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587EB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0587ED;
L_0587ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587ED LSR
    cpu.lsrA();
    goto L_0587EE;
L_0587EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587EE LSR
    cpu.lsrA();
    goto L_0587EF;
L_0587EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587EF LSR
    cpu.lsrA();
    goto L_0587F0;
L_0587F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587F0 LSR
    cpu.lsrA();
    goto L_0587F1;
L_0587F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587F1 TAY
    cpu.transfer("TAY");
    goto L_0587F2;
L_0587F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587F2 SEC
    cpu.setFlag('C', true);
    goto L_0587F3;
L_0587F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587F3 SBC
    cpu.sbc(0x8u);
    goto L_0587F6;
L_0587F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587F6 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_0587F8;
L_0587F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F8u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587F8 TYA
    cpu.transfer("TYA");
    goto L_0587F9;
L_0587F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587F9 CLC
    cpu.setFlag('C', false);
    goto L_0587FA;
L_0587FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587FA ADC
    cpu.adc(0x17u);
    goto L_0587FD;
L_0587FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587FD STA
    hw.write(cpu.address("dp", 0x4Bu), cpu.a, cpu.m8?8:16);
    goto L_0587FF;
L_0587FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FFu, 3u, 3u, cpu.address("abs", 0x8818u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587FF JMP -> $058818
    goto L_058818;
L_058802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8802u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8802u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058802 REP
    cpu.rep(0x20u);
    goto L_058804;
L_058804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8804u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8804u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058804 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058806;
L_058806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058806 LSR
    cpu.lsrA();
    goto L_058807;
L_058807:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8807u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8807u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8807u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058807 LSR
    cpu.lsrA();
    goto L_058808;
L_058808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8808u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8808u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058808 LSR
    cpu.lsrA();
    goto L_058809;
L_058809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8809u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8809u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058809 LSR
    cpu.lsrA();
    goto L_05880A;
L_05880A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05880A TAY
    cpu.transfer("TAY");
    goto L_05880B;
L_05880B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05880B SEC
    cpu.setFlag('C', true);
    goto L_05880C;
L_05880C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05880C SBC
    cpu.sbc(0x8u);
    goto L_05880F;
L_05880F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05880F STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_058811;
L_058811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8811u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8811u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058811 TYA
    cpu.transfer("TYA");
    goto L_058812;
L_058812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8812u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8812u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058812 CLC
    cpu.setFlag('C', false);
    goto L_058813;
L_058813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058813 ADC
    cpu.adc(0x17u);
    goto L_058816;
L_058816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8816u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8816u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058816 STA
    hw.write(cpu.address("dp", 0x4Bu), cpu.a, cpu.m8?8:16);
    goto L_058818;
L_058818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058818 PLP
    cpu.pop("PLP", hw);
    goto L_058819;
L_058819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8819u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8819u,0x058819u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8819u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8819u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $058819 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x058819u);return;} hw.unresolvedReturn(0x058819u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_05877E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05877Eu: goto L_05877E;
    case 0x05877Fu: goto L_05877F;
    case 0x058781u: goto L_058781;
    case 0x058783u: goto L_058783;
    case 0x058785u: goto L_058785;
    case 0x058787u: goto L_058787;
    case 0x058789u: goto L_058789;
    case 0x05878Bu: goto L_05878B;
    case 0x05878Cu: goto L_05878C;
    case 0x05878Du: goto L_05878D;
    case 0x05878Eu: goto L_05878E;
    case 0x05878Fu: goto L_05878F;
    case 0x058790u: goto L_058790;
    case 0x058791u: goto L_058791;
    case 0x058794u: goto L_058794;
    case 0x058796u: goto L_058796;
    case 0x058797u: goto L_058797;
    case 0x058798u: goto L_058798;
    case 0x05879Bu: goto L_05879B;
    case 0x05879Du: goto L_05879D;
    case 0x05879Fu: goto L_05879F;
    case 0x0587A1u: goto L_0587A1;
    case 0x0587A2u: goto L_0587A2;
    case 0x0587A4u: goto L_0587A4;
    case 0x0587A5u: goto L_0587A5;
    case 0x0587A6u: goto L_0587A6;
    case 0x0587A7u: goto L_0587A7;
    case 0x0587A9u: goto L_0587A9;
    case 0x0587ACu: goto L_0587AC;
    case 0x0587ADu: goto L_0587AD;
    case 0x0587B0u: goto L_0587B0;
    case 0x0587B1u: goto L_0587B1;
    case 0x0587B2u: goto L_0587B2;
    case 0x0587B5u: goto L_0587B5;
    case 0x0587B7u: goto L_0587B7;
    case 0x0587BBu: goto L_0587BB;
    case 0x0587BEu: goto L_0587BE;
    case 0x0587BFu: goto L_0587BF;
    case 0x0587C0u: goto L_0587C0;
    case 0x0587C1u: goto L_0587C1;
    case 0x0587C4u: goto L_0587C4;
    case 0x0587C6u: goto L_0587C6;
    case 0x0587C8u: goto L_0587C8;
    case 0x0587CBu: goto L_0587CB;
    case 0x0587CDu: goto L_0587CD;
    case 0x0587CFu: goto L_0587CF;
    case 0x0587D0u: goto L_0587D0;
    case 0x0587D1u: goto L_0587D1;
    case 0x0587D2u: goto L_0587D2;
    case 0x0587D3u: goto L_0587D3;
    case 0x0587D4u: goto L_0587D4;
    case 0x0587D5u: goto L_0587D5;
    case 0x0587D8u: goto L_0587D8;
    case 0x0587DAu: goto L_0587DA;
    case 0x0587DBu: goto L_0587DB;
    case 0x0587DCu: goto L_0587DC;
    case 0x0587DFu: goto L_0587DF;
    case 0x0587E1u: goto L_0587E1;
    case 0x0587E3u: goto L_0587E3;
    case 0x0587E5u: goto L_0587E5;
    case 0x0587E7u: goto L_0587E7;
    case 0x0587E9u: goto L_0587E9;
    case 0x0587EBu: goto L_0587EB;
    case 0x0587EDu: goto L_0587ED;
    case 0x0587EEu: goto L_0587EE;
    case 0x0587EFu: goto L_0587EF;
    case 0x0587F0u: goto L_0587F0;
    case 0x0587F1u: goto L_0587F1;
    case 0x0587F2u: goto L_0587F2;
    case 0x0587F3u: goto L_0587F3;
    case 0x0587F6u: goto L_0587F6;
    case 0x0587F8u: goto L_0587F8;
    case 0x0587F9u: goto L_0587F9;
    case 0x0587FAu: goto L_0587FA;
    case 0x0587FDu: goto L_0587FD;
    case 0x0587FFu: goto L_0587FF;
    case 0x058802u: goto L_058802;
    case 0x058804u: goto L_058804;
    case 0x058806u: goto L_058806;
    case 0x058807u: goto L_058807;
    case 0x058808u: goto L_058808;
    case 0x058809u: goto L_058809;
    case 0x05880Au: goto L_05880A;
    case 0x05880Bu: goto L_05880B;
    case 0x05880Cu: goto L_05880C;
    case 0x05880Fu: goto L_05880F;
    case 0x058811u: goto L_058811;
    case 0x058812u: goto L_058812;
    case 0x058813u: goto L_058813;
    case 0x058816u: goto L_058816;
    case 0x058818u: goto L_058818;
    case 0x058819u: goto L_058819;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05877E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05877E PHP
    cpu.push("PHP", hw);
    goto L_05877F;
L_05877F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05877F SEP
    cpu.sep(0x20u);
    goto L_058781;
L_058781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8781u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8781u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058781 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058783;
L_058783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058783 AND
    cpu.logicAnd(0x1u);
    goto L_058785;
L_058785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058785 BNE -> $0587CB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0587CB; }
    goto L_058787;
L_058787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8787u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8787u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058787 REP
    cpu.rep(0x20u);
    goto L_058789;
L_058789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8789u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8789u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058789 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05878B;
L_05878B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05878B LSR
    cpu.lsrA();
    goto L_05878C;
L_05878C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05878C LSR
    cpu.lsrA();
    goto L_05878D;
L_05878D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05878D LSR
    cpu.lsrA();
    goto L_05878E;
L_05878E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05878E LSR
    cpu.lsrA();
    goto L_05878F;
L_05878F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05878F TAY
    cpu.transfer("TAY");
    goto L_058790;
L_058790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8790u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8790u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058790 SEC
    cpu.setFlag('C', true);
    goto L_058791;
L_058791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8791u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8791u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058791 SBC
    cpu.sbc(0x8u);
    goto L_058794;
L_058794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8794u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8794u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x45u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058794 STA
    hw.write(cpu.address("dp", 0x45u), cpu.a, cpu.m8?8:16);
    goto L_058796;
L_058796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8796u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8796u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058796 TYA
    cpu.transfer("TYA");
    goto L_058797;
L_058797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058797 CLC
    cpu.setFlag('C', false);
    goto L_058798;
L_058798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8798u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8798u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058798 ADC
    cpu.adc(0x17u);
    goto L_05879B;
L_05879B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05879B STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_05879D;
L_05879D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05879D SEP
    cpu.sep(0x30u);
    goto L_05879F;
L_05879F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x55u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05879F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x55u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0587A1;
L_0587A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587A1 TAX
    cpu.transfer("TAX");
    goto L_0587A2;
L_0587A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587A2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0587A4;
L_0587A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587A4 LSR
    cpu.lsrA();
    goto L_0587A5;
L_0587A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587A5 LSR
    cpu.lsrA();
    goto L_0587A6;
L_0587A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587A6 LSR
    cpu.lsrA();
    goto L_0587A7;
L_0587A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587A7 REP
    cpu.rep(0x30u);
    goto L_0587A9;
L_0587A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587A9 AND
    cpu.logicAnd(0x6u);
    goto L_0587AC;
L_0587AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ACu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587AC TAX
    cpu.transfer("TAX");
    goto L_0587AD;
L_0587AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587AD LDA
    cpu.setA(0x133u, 16);
    goto L_0587B0;
L_0587B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587B0 ASL
    cpu.aslA();
    goto L_0587B1;
L_0587B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587B1 TAY
    cpu.transfer("TAY");
    goto L_0587B2;
L_0587B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587B2 LDA
    cpu.setA(0x7u, 16);
    goto L_0587B5;
L_0587B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587B5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0587B7;
L_0587B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u, 6u, 4u, ((0x058776u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587B7 LDA
    cpu.loadA(hw.readW(((0x58776u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0587BB;
L_0587BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BBu, 6u, 3u, cpu.address("absy", 0x0FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587BB STA
    hw.write(cpu.address("absy", 0xFBEu), cpu.a, cpu.m8?8:16);
    goto L_0587BE;
L_0587BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587BE INY
    cpu.inc('Y');
    goto L_0587BF;
L_0587BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587BF INY
    cpu.inc('Y');
    goto L_0587C0;
L_0587C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587C0 CLC
    cpu.setFlag('C', false);
    goto L_0587C1;
L_0587C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587C1 ADC
    cpu.adc(0x8u);
    goto L_0587C4;
L_0587C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C4u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587C4 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0587C6;
L_0587C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587C6 BPL -> $0587BB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0587BB; }
    goto L_0587C8;
L_0587C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u, 3u, 3u, cpu.address("abs", 0x87E1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587C8 JMP -> $0587E1
    goto L_0587E1;
L_0587CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587CB REP
    cpu.rep(0x20u);
    goto L_0587CD;
L_0587CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587CD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0587CF;
L_0587CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587CF LSR
    cpu.lsrA();
    goto L_0587D0;
L_0587D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587D0 LSR
    cpu.lsrA();
    goto L_0587D1;
L_0587D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587D1 LSR
    cpu.lsrA();
    goto L_0587D2;
L_0587D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587D2 LSR
    cpu.lsrA();
    goto L_0587D3;
L_0587D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587D3 TAY
    cpu.transfer("TAY");
    goto L_0587D4;
L_0587D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587D4 SEC
    cpu.setFlag('C', true);
    goto L_0587D5;
L_0587D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D5u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587D5 SBC
    cpu.sbc(0x8u);
    goto L_0587D8;
L_0587D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x45u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587D8 STA
    hw.write(cpu.address("dp", 0x45u), cpu.a, cpu.m8?8:16);
    goto L_0587DA;
L_0587DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587DA TYA
    cpu.transfer("TYA");
    goto L_0587DB;
L_0587DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587DB CLC
    cpu.setFlag('C', false);
    goto L_0587DC;
L_0587DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587DC ADC
    cpu.adc(0x17u);
    goto L_0587DF;
L_0587DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587DF STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_0587E1;
L_0587E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587E1 SEP
    cpu.sep(0x20u);
    goto L_0587E3;
L_0587E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587E3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0587E5;
L_0587E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587E5 AND
    cpu.logicAnd(0x2u);
    goto L_0587E7;
L_0587E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587E7 BNE -> $058802
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_058802; }
    goto L_0587E9;
L_0587E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587E9 REP
    cpu.rep(0x20u);
    goto L_0587EB;
L_0587EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587EB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0587ED;
L_0587ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587ED LSR
    cpu.lsrA();
    goto L_0587EE;
L_0587EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587EE LSR
    cpu.lsrA();
    goto L_0587EF;
L_0587EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587EF LSR
    cpu.lsrA();
    goto L_0587F0;
L_0587F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587F0 LSR
    cpu.lsrA();
    goto L_0587F1;
L_0587F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587F1 TAY
    cpu.transfer("TAY");
    goto L_0587F2;
L_0587F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587F2 SEC
    cpu.setFlag('C', true);
    goto L_0587F3;
L_0587F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587F3 SBC
    cpu.sbc(0x8u);
    goto L_0587F6;
L_0587F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587F6 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_0587F8;
L_0587F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F8u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587F8 TYA
    cpu.transfer("TYA");
    goto L_0587F9;
L_0587F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587F9 CLC
    cpu.setFlag('C', false);
    goto L_0587FA;
L_0587FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587FA ADC
    cpu.adc(0x17u);
    goto L_0587FD;
L_0587FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587FD STA
    hw.write(cpu.address("dp", 0x4Bu), cpu.a, cpu.m8?8:16);
    goto L_0587FF;
L_0587FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FFu, 3u, 3u, cpu.address("abs", 0x8818u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0587FF JMP -> $058818
    goto L_058818;
L_058802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8802u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8802u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058802 REP
    cpu.rep(0x20u);
    goto L_058804;
L_058804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8804u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8804u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058804 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058806;
L_058806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058806 LSR
    cpu.lsrA();
    goto L_058807;
L_058807:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8807u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8807u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8807u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058807 LSR
    cpu.lsrA();
    goto L_058808;
L_058808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8808u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8808u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058808 LSR
    cpu.lsrA();
    goto L_058809;
L_058809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8809u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8809u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058809 LSR
    cpu.lsrA();
    goto L_05880A;
L_05880A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05880A TAY
    cpu.transfer("TAY");
    goto L_05880B;
L_05880B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05880B SEC
    cpu.setFlag('C', true);
    goto L_05880C;
L_05880C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05880C SBC
    cpu.sbc(0x8u);
    goto L_05880F;
L_05880F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05880F STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_058811;
L_058811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8811u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8811u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058811 TYA
    cpu.transfer("TYA");
    goto L_058812;
L_058812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8812u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8812u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058812 CLC
    cpu.setFlag('C', false);
    goto L_058813;
L_058813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058813 ADC
    cpu.adc(0x17u);
    goto L_058816;
L_058816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8816u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8816u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058816 STA
    hw.write(cpu.address("dp", 0x4Bu), cpu.a, cpu.m8?8:16);
    goto L_058818;
L_058818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058818 PLP
    cpu.pop("PLP", hw);
    goto L_058819;
L_058819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8819u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8819u,0x058819u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8819u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8819u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $058819 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x058819u);return;} hw.unresolvedReturn(0x058819u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0CCA8F_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CCA8Fu: goto L_0CCA8F;
    case 0x0CCA92u: goto L_0CCA92;
    case 0x0CCA94u: goto L_0CCA94;
    case 0x0CCA96u: goto L_0CCA96;
    case 0x0CCA97u: goto L_0CCA97;
    case 0x0CCA9Au: goto L_0CCA9A;
    case 0x0CCA9Du: goto L_0CCA9D;
    case 0x0CCAA0u: goto L_0CCAA0;
    case 0x0CCAA3u: goto L_0CCAA3;
    case 0x0CCAA6u: goto L_0CCAA6;
    case 0x0CCAA9u: goto L_0CCAA9;
    case 0x0CCAACu: goto L_0CCAAC;
    case 0x0CCAAEu: goto L_0CCAAE;
    case 0x0CCAB0u: goto L_0CCAB0;
    case 0x0CCAB3u: goto L_0CCAB3;
    case 0x0CCAB4u: goto L_0CCAB4;
    case 0x0CCAB5u: goto L_0CCAB5;
    case 0x0CCAB6u: goto L_0CCAB6;
    case 0x0CCAB7u: goto L_0CCAB7;
    case 0x0CCAB8u: goto L_0CCAB8;
    case 0x0CCABBu: goto L_0CCABB;
    case 0x0CCABDu: goto L_0CCABD;
    case 0x0CCABEu: goto L_0CCABE;
    case 0x0CCABFu: goto L_0CCABF;
    case 0x0CCAC0u: goto L_0CCAC0;
    case 0x0CCAC3u: goto L_0CCAC3;
    case 0x0CCAC4u: goto L_0CCAC4;
    case 0x0CCAC5u: goto L_0CCAC5;
    case 0x0CCAC6u: goto L_0CCAC6;
    case 0x0CCAC7u: goto L_0CCAC7;
    case 0x0CCAC8u: goto L_0CCAC8;
    case 0x0CCAC9u: goto L_0CCAC9;
    case 0x0CCACBu: goto L_0CCACB;
    case 0x0CCACDu: goto L_0CCACD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CCA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Fu, 4u, 3u, cpu.address("abs", 0x144Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCA8F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x144Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCA92;
L_0CCA92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCA92 BEQ -> $0CCACD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CCACD; }
    goto L_0CCA94;
L_0CCA94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA94u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCA94 LDY
    cpu.setY(0x0u, 8);
    goto L_0CCA96;
L_0CCA96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA96u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCA96 TYX
    cpu.transfer("TYX");
    goto L_0CCA97;
L_0CCA97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA97u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA97u, 4u + ((((0xCA83u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCA83u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCA97 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCA83u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCA9A;
L_0CCA9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Au, 5u, 3u, cpu.address("absx", 0x03E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCA9A STA
    hw.write(cpu.address("absx", 0x3E0u), cpu.a, cpu.m8?8:16);
    goto L_0CCA9D;
L_0CCA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du, 4u + ((((0xCA84u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCA84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCA9D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCA84u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCAA0;
L_0CCAA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA0u, 5u, 3u, cpu.address("absx", 0x03E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAA0 STA
    hw.write(cpu.address("absx", 0x3E1u), cpu.a, cpu.m8?8:16);
    goto L_0CCAA3;
L_0CCAA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA3u, 4u + ((((0xCA85u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCA85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAA3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCA85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCAA6;
L_0CCAA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA6u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA6u, 5u, 3u, cpu.address("absx", 0x03E2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAA6 STA
    hw.write(cpu.address("absx", 0x3E2u), cpu.a, cpu.m8?8:16);
    goto L_0CCAA9;
L_0CCAA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA9u, 4u + ((((0xCA86u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCA86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAA9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCA86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCAAC;
L_0CCAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAACu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAAC AND
    cpu.logicAnd(0xCFu);
    goto L_0CCAAE;
L_0CCAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAEu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAAE ORA
    cpu.logicOr(0x20u);
    goto L_0CCAB0;
L_0CCAB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB0u, 5u, 3u, cpu.address("absx", 0x03E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAB0 STA
    hw.write(cpu.address("absx", 0x3E3u), cpu.a, cpu.m8?8:16);
    goto L_0CCAB3;
L_0CCAB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB3u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CCAB3 PHX
    cpu.push("PHX", hw);
    goto L_0CCAB4;
L_0CCAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAB4 TXA
    cpu.transfer("TXA");
    goto L_0CCAB5;
L_0CCAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAB5 LSR
    cpu.lsrA();
    goto L_0CCAB6;
L_0CCAB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAB6 LSR
    cpu.lsrA();
    goto L_0CCAB7;
L_0CCAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAB7 TAX
    cpu.transfer("TAX");
    goto L_0CCAB8;
L_0CCAB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u, 4u + ((((0xCA86u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCA86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAB8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCA86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCABB;
L_0CCABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCABB AND
    cpu.logicAnd(0x10u);
    goto L_0CCABD;
L_0CCABD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCABD LSR
    cpu.lsrA();
    goto L_0CCABE;
L_0CCABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCABE LSR
    cpu.lsrA();
    goto L_0CCABF;
L_0CCABF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCABF LSR
    cpu.lsrA();
    goto L_0CCAC0;
L_0CCAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u, 5u, 3u, cpu.address("absx", 0x0498u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAC0 STA
    hw.write(cpu.address("absx", 0x498u), cpu.a, cpu.m8?8:16);
    goto L_0CCAC3;
L_0CCAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC3u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CCAC3 PLX
    cpu.pop("PLX", hw);
    goto L_0CCAC4;
L_0CCAC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAC4 INX
    cpu.inc('X');
    goto L_0CCAC5;
L_0CCAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAC5 INX
    cpu.inc('X');
    goto L_0CCAC6;
L_0CCAC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC6u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAC6 INX
    cpu.inc('X');
    goto L_0CCAC7;
L_0CCAC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAC7 INX
    cpu.inc('X');
    goto L_0CCAC8;
L_0CCAC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC8u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAC8 TXY
    cpu.transfer("TXY");
    goto L_0CCAC9;
L_0CCAC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC9u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCAC9 CPY
    cpu.compareY(0xCu);
    goto L_0CCACB;
L_0CCACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCACB BNE -> $0CCA97
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CCA97; }
    goto L_0CCACD;
L_0CCACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CCACD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CCACDu);return;} hw.unresolvedReturn(0x0CCACDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DDB8F_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DDB8Fu: goto L_0DDB8F;
    case 0x0DDB91u: goto L_0DDB91;
    case 0x0DDB93u: goto L_0DDB93;
    case 0x0DDB95u: goto L_0DDB95;
    case 0x0DDB97u: goto L_0DDB97;
    case 0x0DDB9Au: goto L_0DDB9A;
    case 0x0DDB9Cu: goto L_0DDB9C;
    case 0x0DDB9Du: goto L_0DDB9D;
    case 0x0DDB9Eu: goto L_0DDB9E;
    case 0x0DDB9Fu: goto L_0DDB9F;
    case 0x0DDBA0u: goto L_0DDBA0;
    case 0x0DDBA2u: goto L_0DDBA2;
    case 0x0DDBA4u: goto L_0DDBA4;
    case 0x0DDBA6u: goto L_0DDBA6;
    case 0x0DDBA9u: goto L_0DDBA9;
    case 0x0DDBABu: goto L_0DDBAB;
    case 0x0DDBAEu: goto L_0DDBAE;
    case 0x0DDBAFu: goto L_0DDBAF;
    case 0x0DDBB1u: goto L_0DDBB1;
    case 0x0DDBB4u: goto L_0DDBB4;
    case 0x0DDBB6u: goto L_0DDBB6;
    case 0x0DDBB9u: goto L_0DDBB9;
    case 0x0DDBBCu: goto L_0DDBBC;
    case 0x0DDBBFu: goto L_0DDBBF;
    case 0x0DDBC1u: goto L_0DDBC1;
    case 0x0DDBC4u: goto L_0DDBC4;
    case 0x0DDBC5u: goto L_0DDBC5;
    case 0x0DDBC7u: goto L_0DDBC7;
    case 0x0DDBCAu: goto L_0DDBCA;
    case 0x0DDBCCu: goto L_0DDBCC;
    case 0x0DDBCEu: goto L_0DDBCE;
    case 0x0DDBD0u: goto L_0DDBD0;
    case 0x0DDBD2u: goto L_0DDBD2;
    case 0x0DDBD5u: goto L_0DDBD5;
    case 0x0DDBD7u: goto L_0DDBD7;
    case 0x0DDBD8u: goto L_0DDBD8;
    case 0x0DDBDAu: goto L_0DDBDA;
    case 0x0DDBDBu: goto L_0DDBDB;
    case 0x0DDBDDu: goto L_0DDBDD;
    case 0x0DDBE0u: goto L_0DDBE0;
    case 0x0DDBE1u: goto L_0DDBE1;
    case 0x0DDBE3u: goto L_0DDBE3;
    case 0x0DDBE5u: goto L_0DDBE5;
    case 0x0DDBE7u: goto L_0DDBE7;
    case 0x0DDBE8u: goto L_0DDBE8;
    case 0x0DDBE9u: goto L_0DDBE9;
    case 0x0DDBEBu: goto L_0DDBEB;
    case 0x0DDBECu: goto L_0DDBEC;
    case 0x0DDBEEu: goto L_0DDBEE;
    case 0x0DDBF1u: goto L_0DDBF1;
    case 0x0DDBF4u: goto L_0DDBF4;
    case 0x0DDBF6u: goto L_0DDBF6;
    case 0x0DDBF9u: goto L_0DDBF9;
    case 0x0DDBFBu: goto L_0DDBFB;
    case 0x0DDBFEu: goto L_0DDBFE;
    case 0x0DDC01u: goto L_0DDC01;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DDB8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDB8F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DDB91;
L_0DDB91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB91u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDB91 LDA
    cpu.setA(0x0u, 8);
    goto L_0DDB93;
L_0DDB93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB93u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB93u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDB93 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DDB95;
L_0DDB95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB95u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB95u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDB95 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DDB97;
L_0DDB97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB97u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB97u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDB97 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xDB99u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB9Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DDB97u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDB9A;
L_0DDB9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB9Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB9Au,0x0DDB9Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDB9A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDB9C;
L_0DDB9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDB9C LSR
    cpu.lsrA();
    goto L_0DDB9D;
L_0DDB9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDB9D LSR
    cpu.lsrA();
    goto L_0DDB9E;
L_0DDB9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDB9E LSR
    cpu.lsrA();
    goto L_0DDB9F;
L_0DDB9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDB9F LSR
    cpu.lsrA();
    goto L_0DDBA0;
L_0DDBA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBA0 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DDBA2;
L_0DDBA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA2u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBA2 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DDBA4;
L_0DDBA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA4u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBA4 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DDBA6;
L_0DDBA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA6u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDBA6 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDBA8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBA9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDBA6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDBA9;
L_0DDBA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBA9u,0x0DDBA9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBA9 LDA
    cpu.setA(0xD6u, 8);
    goto L_0DDBAB;
L_0DDBAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBABu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBABu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDBAB JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xDBADu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBAEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DDBABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDBAE;
L_0DDBAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBAEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBAEu,0x0DDBAEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAEu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBAE DEX
    cpu.decReg('X');
    goto L_0DDBAF;
L_0DDBAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAFu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBAF BMI -> $0DDBC7
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DDBC7; }
    goto L_0DDBB1;
L_0DDBB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB1u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDBB1 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDBB3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBB4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDBB1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDBB4;
L_0DDBB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBB4u,0x0DDBB4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBB4 LDA
    cpu.setA(0xFDu, 8);
    goto L_0DDBB6;
L_0DDBB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB6u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDBB6 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xDBB8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBB9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DDBB6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDBB9;
L_0DDBB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBB9u,0x0DDBB9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB9u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB9u, 3u, 3u, cpu.address("abs", 0xDBC4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBB9 JMP -> $0DDBC4
    goto L_0DDBC4;
L_0DDBBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBCu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDBBC JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDBBEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBBFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDBBCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDBBF;
L_0DDBBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBBFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBBFu,0x0DDBBFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBBF LDA
    cpu.setA(0xFFu, 8);
    goto L_0DDBC1;
L_0DDBC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBC1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBC1u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDBC1 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xDBC3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBC4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DDBC1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDBC4;
L_0DDBC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBC4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBC4u,0x0DDBC4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBC4u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBC4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBC4 DEX
    cpu.decReg('X');
    goto L_0DDBC5;
L_0DDBC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBC5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBC5 BPL -> $0DDBBC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DDBBC; }
    goto L_0DDBC7;
L_0DDBC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBC7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBC7u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDBC7 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xDBC9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBCAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DDBC7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDBCA;
L_0DDBCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBCAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBCAu,0x0DDBCAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBCAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBCAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBCA INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DDBCC;
L_0DDBCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBCCu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBCCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBCC DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DDBCE;
L_0DDBCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBCEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBCE BEQ -> $0DDBF9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DDBF9; }
    goto L_0DDBD0;
L_0DDBD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBD0 BPL -> $0DDBD5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DDBD5; }
    goto L_0DDBD2;
L_0DDBD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD2u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD2u, 3u, 3u, cpu.address("abs", 0xDC01u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBD2 JMP -> $0DDC01
    goto L_0DDC01;
L_0DDBD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBD5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDBD7;
L_0DDBD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBD7 CLC
    cpu.setFlag('C', false);
    goto L_0DDBD8;
L_0DDBD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD8u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBD8 ADC
    cpu.adc(0xFu);
    goto L_0DDBDA;
L_0DDBDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBDA TAY
    cpu.transfer("TAY");
    goto L_0DDBDB;
L_0DDBDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBDB BCC -> $0DDBE0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DDBE0; }
    goto L_0DDBDD;
L_0DDBDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDDu, 6u, 3u, cpu.address("abs", 0xA987u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDBDD JSR -> $0DA987 stack real
    { cpu.push16Value(hw,0xDBDFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBE0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA987u), 0x0DDBDDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDBE0;
L_0DDBE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBE0u,0x0DDBE0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE0u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBE0 TYA
    cpu.transfer("TYA");
    goto L_0DDBE1;
L_0DDBE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBE1 AND
    cpu.logicAnd(0xFu);
    goto L_0DDBE3;
L_0DDBE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBE3 CMP
    cpu.compareA(0xFu);
    goto L_0DDBE5;
L_0DDBE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBE5 BNE -> $0DDBF4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DDBF4; }
    goto L_0DDBE7;
L_0DDBE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE7u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBE7 TYA
    cpu.transfer("TYA");
    goto L_0DDBE8;
L_0DDBE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBE8 CLC
    cpu.setFlag('C', false);
    goto L_0DDBE9;
L_0DDBE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBE9 ADC
    cpu.adc(0x10u);
    goto L_0DDBEB;
L_0DDBEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBEB TAY
    cpu.transfer("TAY");
    goto L_0DDBEC;
L_0DDBEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBEC BCC -> $0DDBF1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DDBF1; }
    goto L_0DDBEE;
L_0DDBEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEEu, 6u, 3u, cpu.address("abs", 0xA987u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDBEE JSR -> $0DA987 stack real
    { cpu.push16Value(hw,0xDBF0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBF1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA987u), 0x0DDBEEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDBF1;
L_0DDBF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF1u,0x0DDBF1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF1u, 6u, 3u, cpu.address("abs", 0xA9D6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDBF1 JSR -> $0DA9D6 stack real
    { cpu.push16Value(hw,0xDBF3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBF4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA9D6u), 0x0DDBF1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDBF4;
L_0DDBF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF4u,0x0DDBF4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBF4 STY
    hw.write(cpu.address("dp", 0x57u), cpu.y, cpu.x8?8:16);
    goto L_0DDBF6;
L_0DDBF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u, 3u, 3u, cpu.address("abs", 0xDBA4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBF6 JMP -> $0DDBA4
    goto L_0DDBA4;
L_0DDBF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBF9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DDBFB;
L_0DDBFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFBu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDBFB JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xDBFDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBFEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DDBFBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDBFE;
L_0DDBFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBFEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBFEu,0x0DDBFEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFEu, 3u, 3u, cpu.address("abs", 0xDBAEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDBFE JMP -> $0DDBAE
    goto L_0DDBAE;
L_0DDC01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC01u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC01u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC01 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DDC01u);return;} hw.unresolvedReturn(0x0DDC01u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DE9ED_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DE9EDu: goto L_0DE9ED;
    case 0x0DE9EFu: goto L_0DE9EF;
    case 0x0DE9F0u: goto L_0DE9F0;
    case 0x0DE9F2u: goto L_0DE9F2;
    case 0x0DE9F3u: goto L_0DE9F3;
    case 0x0DE9F4u: goto L_0DE9F4;
    case 0x0DE9F5u: goto L_0DE9F5;
    case 0x0DE9F7u: goto L_0DE9F7;
    case 0x0DE9F9u: goto L_0DE9F9;
    case 0x0DE9FBu: goto L_0DE9FB;
    case 0x0DE9FDu: goto L_0DE9FD;
    case 0x0DEA00u: goto L_0DEA00;
    case 0x0DEA03u: goto L_0DEA03;
    case 0x0DEA07u: goto L_0DEA07;
    case 0x0DEA0Au: goto L_0DEA0A;
    case 0x0DEA0Bu: goto L_0DEA0B;
    case 0x0DEA0Du: goto L_0DEA0D;
    case 0x0DEA0Fu: goto L_0DEA0F;
    case 0x0DEA12u: goto L_0DEA12;
    case 0x0DEA15u: goto L_0DEA15;
    case 0x0DEA17u: goto L_0DEA17;
    case 0x0DEA19u: goto L_0DEA19;
    case 0x0DEA1Bu: goto L_0DEA1B;
    case 0x0DEA1Du: goto L_0DEA1D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DE9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9ED LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DE9EF;
L_0DE9EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9EF SEC
    cpu.setFlag('C', true);
    goto L_0DE9F0;
L_0DE9F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9F0 SBC
    cpu.sbc(0x64u);
    goto L_0DE9F2;
L_0DE9F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9F2 ASL
    cpu.aslA();
    goto L_0DE9F3;
L_0DE9F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9F3 ASL
    cpu.aslA();
    goto L_0DE9F4;
L_0DE9F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9F4 TAX
    cpu.transfer("TAX");
    goto L_0DE9F5;
L_0DE9F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F5u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9F5 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DE9F7;
L_0DE9F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9F7 LDA
    cpu.setA(0x1u, 8);
    goto L_0DE9F9;
L_0DE9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9F9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DE9FB;
L_0DE9FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9FB STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DE9FD;
L_0DE9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9FDu, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE9FD JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xE9FFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA00u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DE9FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEA00;
L_0DEA00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA00u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA00u,0x0DEA00u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA00u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA00u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEA00 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xEA02u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA03u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DEA00u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEA03;
L_0DEA03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA03u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA03u,0x0DEA03u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA03u, 5u, 4u, ((0x0DE9E1u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA03 LDA
    cpu.loadA(hw.readW(((0xDE9E1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DEA07;
L_0DEA07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA07u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA07u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEA07 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xEA09u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA0Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DEA07u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEA0A;
L_0DEA0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA0Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA0Au,0x0DEA0Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Au,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA0A INX
    cpu.inc('X');
    goto L_0DEA0B;
L_0DEA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA0B DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DEA0D;
L_0DEA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA0D BPL -> $0DEA00
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DEA00; }
    goto L_0DEA0F;
L_0DEA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA0Fu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEA0F JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xEA11u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA12u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DEA0Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEA12;
L_0DEA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA12u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA12u,0x0DEA12u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA12u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA12u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEA12 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xEA14u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA15u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DEA12u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEA15;
L_0DEA15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA15u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA15u,0x0DEA15u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA15 LDA
    cpu.setA(0x1u, 8);
    goto L_0DEA17;
L_0DEA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA17u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA17u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA17 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DEA19;
L_0DEA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA19u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA19u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA19 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DEA1B;
L_0DEA1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEA1B BPL -> $0DEA00
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DEA00; }
    goto L_0DEA1D;
L_0DEA1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEA1D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DEA1Du);return;} hw.unresolvedReturn(0x0DEA1Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0F8D0F_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0F8D0Fu: goto L_0F8D0F;
    case 0x0F8D12u: goto L_0F8D12;
    case 0x0F8D15u: goto L_0F8D15;
    case 0x0F8D17u: goto L_0F8D17;
    case 0x0F8D19u: goto L_0F8D19;
    case 0x0F8D1Au: goto L_0F8D1A;
    case 0x0F8D1Du: goto L_0F8D1D;
    case 0x0F8D20u: goto L_0F8D20;
    case 0x0F8D22u: goto L_0F8D22;
    case 0x0F8D25u: goto L_0F8D25;
    case 0x0F8D27u: goto L_0F8D27;
    case 0x0F8D29u: goto L_0F8D29;
    case 0x0F8D3Au: goto L_0F8D3A;
    case 0x0F8D3Cu: goto L_0F8D3C;
    case 0x0F8D3Fu: goto L_0F8D3F;
    case 0x0F8D42u: goto L_0F8D42;
    case 0x0F8D44u: goto L_0F8D44;
    case 0x0F8D46u: goto L_0F8D46;
    case 0x0F8D4Au: goto L_0F8D4A;
    case 0x0F8D6Fu: goto L_0F8D6F;
    case 0x0F8D71u: goto L_0F8D71;
    case 0x0F8D73u: goto L_0F8D73;
    case 0x0F8D75u: goto L_0F8D75;
    case 0x0F8D78u: goto L_0F8D78;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0F8D0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu, 4u, 3u, cpu.address("abs", 0xDE0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D0F SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0xDE0Fu), cpu.m8?8:16));
    goto L_0F8D12;
L_0F8D12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D12u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D12u, 4u, 3u, cpu.address("abs", 0x0EF0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D12 STX
    hw.write(cpu.address("abs", 0xEF0u), cpu.x, cpu.x8?8:16);
    goto L_0F8D15;
L_0F8D15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D15u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D15u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D15 CPX
    cpu.compareX(0xFFu);
    goto L_0F8D17;
L_0F8D17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u,cpu,0x21u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x31u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $0F8D17 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirectX(hw, 0x31u), cpu.m8?8:16));
    goto L_0F8D19;
L_0F8D19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D19u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D19u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D19 XBA
    cpu.xba();
    goto L_0F8D1A;
L_0F8D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au, 6u, 3u, cpu.address("abs", 0x118Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D1A DEC
    cpu.decMem(hw, cpu.address("abs", 0x118Eu), cpu.m8?8:16);
    goto L_0F8D1D;
L_0F8D1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Du,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Du, 7u, 3u, cpu.address("absx", 0xFFECu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D1D INC
    cpu.incMem(hw, cpu.address("absx", 0xFFECu), cpu.m8?8:16);
    goto L_0F8D20;
L_0F8D20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D20u,cpu,0xF1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D20u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Eu) & 0xFFFFu), 2u, 0u);
    // $0F8D20 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectY(hw, 0x1Eu), cpu.m8?8:16));
    goto L_0F8D22;
L_0F8D22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u, 4u, 3u, cpu.address("abs", 0x8601u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D22 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x8601u), cpu.m8?8:16));
    goto L_0F8D25;
L_0F8D25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D25u,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D25u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D25 TRB
    cpu.trb(hw, cpu.address("dp", 0x52u), cpu.m8?8:16);
    goto L_0F8D27;
L_0F8D27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D27u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D27u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D27 BPL -> $0F8D3A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0F8D3A; }
    goto L_0F8D29;
L_0F8D29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D29u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D29u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0F8D29 BRK
    hw.partial(0x0F8D29u, "BRK"); return;
L_0F8D3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D3A BEQ -> $0F8D6F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0F8D6F; }
    goto L_0F8D3C;
L_0F8D3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Cu,cpu,0x44u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8D3Cu, (std::uint32_t(cpu.a)+1u), 0x30u, 0x33u);
    // $0F8D3C MVP
    cpu.blockMove(hw, 0x33u, 0x30u, true);
    goto L_0F8D3F;
L_0F8D3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu, 7u, 3u, cpu.address("absx", 0xDE0Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D3F ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDE0Bu), cpu.m8?8:16);
    goto L_0F8D42;
L_0F8D42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D42u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D42u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x21u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D42 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x21u), cpu.m8?8:16), false);
    goto L_0F8D44;
L_0F8D44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x41u) & 0xFFFFu), 2u, 0u);
    // $0F8D44 AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0x41u), cpu.m8?8:16));
    goto L_0F8D46;
L_0F8D46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D46u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D46u, 5u, 4u, ((0x416E10u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D46 ORA
    cpu.logicOr(hw.readW(((0x416E10u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0F8D4A;
L_0F8D4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Au,cpu,0xDCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Au, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, 0x0EF1u, 3u, 0u);
    // $0F8D4A JMP [0EF1] -> dispatcher C++ dinamico
    hw.requestDispatch(hw.read24(0x0EF1u),0x0F8D4Au); return;
L_0F8D6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Fu,cpu,0x13u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Fu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x10u) & 0xFFFFu), 2u, 0u);
    // $0F8D6F ORA
    cpu.logicOr(hw.readW(cpu.addressStackIndirectY(hw, 0x10u), cpu.m8?8:16));
    goto L_0F8D71;
L_0F8D71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D71u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D71u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x12u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $0F8D71 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0x12u), cpu.m8?8:16));
    goto L_0F8D73;
L_0F8D73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u,cpu,0x32u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $0F8D73 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirect(hw, 0x0u), cpu.m8?8:16));
    goto L_0F8D75;
L_0F8D75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D75u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D75u, 7u, 3u, cpu.address("absx", 0x1F20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D75 ROR
    cpu.rorMem(hw, cpu.address("absx", 0x1F20u), cpu.m8?8:16);
    goto L_0F8D78;
L_0F8D78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0F8D78 BRK
    hw.partial(0x0F8D78u, "BRK"); return;
}

void sub_E480B9_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xE480B9u: goto L_E480B9;
    case 0xE480BCu: goto L_E480BC;
    case 0xE480BFu: goto L_E480BF;
    case 0xE480C1u: goto L_E480C1;
    case 0xE480C3u: goto L_E480C3;
    case 0xE480C5u: goto L_E480C5;
    case 0xE480C8u: goto L_E480C8;
    case 0xE480C9u: goto L_E480C9;
    case 0xE480CAu: goto L_E480CA;
    case 0xE480CBu: goto L_E480CB;
    case 0xE480CCu: goto L_E480CC;
    case 0xE480CEu: goto L_E480CE;
    case 0xE480D0u: goto L_E480D0;
    case 0xE480D2u: goto L_E480D2;
    case 0xE480D5u: goto L_E480D5;
    case 0xE480D8u: goto L_E480D8;
    case 0xE480D9u: goto L_E480D9;
    case 0xE480DAu: goto L_E480DA;
    case 0xE480DBu: goto L_E480DB;
    case 0xE480DDu: goto L_E480DD;
    case 0xE480DFu: goto L_E480DF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_E480B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480B9 LDY
    cpu.setY(0x0u, 16);
    goto L_E480BC;
L_E480BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480BC LDA
    cpu.setA(0x8u, 16);
    goto L_E480BF;
L_E480BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480BF STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_E480C1;
L_E480C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480C1 STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_E480C3;
L_E480C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $E480C3 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E480C5;
L_E480C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C5u, 6u, 3u, cpu.address("absx", 0x0AF6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480C5 STA
    hw.write(cpu.address("absx", 0xAF6u), cpu.a, cpu.m8?8:16);
    goto L_E480C8;
L_E480C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480C8 INY
    cpu.inc('Y');
    goto L_E480C9;
L_E480C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480C9 INY
    cpu.inc('Y');
    goto L_E480CA;
L_E480CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480CA INX
    cpu.inc('X');
    goto L_E480CB;
L_E480CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480CB INX
    cpu.inc('X');
    goto L_E480CC;
L_E480CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CCu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480CC DEC
    cpu.decMem(hw, cpu.address("dp", 0x7u), cpu.m8?8:16);
    goto L_E480CE;
L_E480CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480CE BNE -> $E480C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_E480C3; }
    goto L_E480D0;
L_E480D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D0u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $E480D0 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E480D2;
L_E480D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480D2 AND
    cpu.logicAnd(0xFFu);
    goto L_E480D5;
L_E480D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u, 6u, 3u, cpu.address("absx", 0x0AF6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480D5 STA
    hw.write(cpu.address("absx", 0xAF6u), cpu.a, cpu.m8?8:16);
    goto L_E480D8;
L_E480D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480D8 INY
    cpu.inc('Y');
    goto L_E480D9;
L_E480D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480D9 INX
    cpu.inc('X');
    goto L_E480DA;
L_E480DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480DA INX
    cpu.inc('X');
    goto L_E480DB;
L_E480DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DBu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480DB DEC
    cpu.decMem(hw, cpu.address("dp", 0x9u), cpu.m8?8:16);
    goto L_E480DD;
L_E480DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E480DD BNE -> $E480D0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_E480D0; }
    goto L_E480DF;
L_E480DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E480DF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xE480DFu);return;} hw.unresolvedReturn(0xE480DFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

