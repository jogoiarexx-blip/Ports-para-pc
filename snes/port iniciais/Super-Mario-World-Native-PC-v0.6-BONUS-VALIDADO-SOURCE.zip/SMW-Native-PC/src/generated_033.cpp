#include "generated.hpp"
void sub_00816A_E0M1X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0082EEu: goto L_0082EE;
    case 0x0082F1u: goto L_0082F1;
    case 0x0082F4u: goto L_0082F4;
    case 0x0082F7u: goto L_0082F7;
    case 0x0082F9u: goto L_0082F9;
    case 0x0082FCu: goto L_0082FC;
    case 0x0082FEu: goto L_0082FE;
    case 0x0082FFu: goto L_0082FF;
    case 0x008301u: goto L_008301;
    case 0x008304u: goto L_008304;
    case 0x008306u: goto L_008306;
    case 0x008308u: goto L_008308;
    case 0x00830Bu: goto L_00830B;
    case 0x00830Du: goto L_00830D;
    case 0x00830Eu: goto L_00830E;
    case 0x008310u: goto L_008310;
    case 0x008313u: goto L_008313;
    case 0x008315u: goto L_008315;
    case 0x008317u: goto L_008317;
    case 0x00831Au: goto L_00831A;
    case 0x00831Cu: goto L_00831C;
    case 0x00831Fu: goto L_00831F;
    case 0x008321u: goto L_008321;
    case 0x008324u: goto L_008324;
    case 0x008326u: goto L_008326;
    case 0x008329u: goto L_008329;
    case 0x00832Bu: goto L_00832B;
    case 0x00832Eu: goto L_00832E;
    case 0x008330u: goto L_008330;
    case 0x008333u: goto L_008333;
    case 0x008335u: goto L_008335;
    case 0x008338u: goto L_008338;
    case 0x00833Au: goto L_00833A;
    case 0x00833Du: goto L_00833D;
    case 0x00833Fu: goto L_00833F;
    case 0x008342u: goto L_008342;
    case 0x008345u: goto L_008345;
    case 0x008348u: goto L_008348;
    case 0x008349u: goto L_008349;
    case 0x00834Bu: goto L_00834B;
    case 0x00834Eu: goto L_00834E;
    case 0x008351u: goto L_008351;
    case 0x008354u: goto L_008354;
    case 0x008357u: goto L_008357;
    case 0x008359u: goto L_008359;
    case 0x00835Cu: goto L_00835C;
    case 0x00835Eu: goto L_00835E;
    case 0x008361u: goto L_008361;
    case 0x008363u: goto L_008363;
    case 0x008366u: goto L_008366;
    case 0x008367u: goto L_008367;
    case 0x008368u: goto L_008368;
    case 0x00836Bu: goto L_00836B;
    case 0x00836Du: goto L_00836D;
    case 0x00836Fu: goto L_00836F;
    case 0x008371u: goto L_008371;
    case 0x00838Cu: goto L_00838C;
    case 0x00838Fu: goto L_00838F;
    case 0x008391u: goto L_008391;
    case 0x008394u: goto L_008394;
    case 0x008396u: goto L_008396;
    case 0x008399u: goto L_008399;
    case 0x00839Bu: goto L_00839B;
    case 0x00839Eu: goto L_00839E;
    case 0x0083A0u: goto L_0083A0;
    case 0x0083A3u: goto L_0083A3;
    case 0x0083A5u: goto L_0083A5;
    case 0x0083A8u: goto L_0083A8;
    case 0x0083AAu: goto L_0083AA;
    case 0x0083ADu: goto L_0083AD;
    case 0x0083AFu: goto L_0083AF;
    case 0x0083B2u: goto L_0083B2;
    case 0x0083B4u: goto L_0083B4;
    case 0x0083B5u: goto L_0083B5;
    case 0x0083B6u: goto L_0083B6;
    case 0x0083B7u: goto L_0083B7;
    case 0x0083B8u: goto L_0083B8;
    case 0x0083B9u: goto L_0083B9;
    case 0x0083F3u: goto L_0083F3;
    case 0x0083F6u: goto L_0083F6;
    case 0x0083F9u: goto L_0083F9;
    case 0x0083FAu: goto L_0083FA;
    case 0x0083FBu: goto L_0083FB;
    case 0x0083FDu: goto L_0083FD;
    case 0x008400u: goto L_008400;
    case 0x008402u: goto L_008402;
    case 0x008405u: goto L_008405;
    case 0x008407u: goto L_008407;
    case 0x00840Au: goto L_00840A;
    case 0x00840Cu: goto L_00840C;
    case 0x00840Fu: goto L_00840F;
    case 0x008411u: goto L_008411;
    case 0x008414u: goto L_008414;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0082EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82EEu,0x0082EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EEu, 6u, 3u, cpu.address("abs", 0x85D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082EE JSR -> $0085D2 stack real
    { cpu.push16Value(hw,0x82F0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82F1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D2u), 0x0082EEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082F1;
L_0082F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82F1u,0x0082F1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F1u, 6u, 3u, cpu.address("abs", 0x8449u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082F1 JSR -> $008449 stack real
    { cpu.push16Value(hw,0x82F3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82F4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8449u), 0x0082F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082F4;
L_0082F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82F4u,0x0082F4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F4u, 6u, 3u, cpu.address("abs", 0x8650u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082F4 JSR -> $008650 stack real
    { cpu.push16Value(hw,0x82F6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82F7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8650u), 0x0082F4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082F7;
L_0082F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82F7u,0x0082F7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082F7 LDA
    cpu.setA(0x9u, 8);
    goto L_0082F9;
L_0082F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F9u, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082F9 STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_0082FC;
L_0082FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082FC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0082FE;
L_0082FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082FE CLC
    cpu.setFlag('C', false);
    goto L_0082FF;
L_0082FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082FF ADC
    cpu.adc(0x80u);
    goto L_008301;
L_008301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8301u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8301u, 4u, 3u, cpu.address("abs", 0x211Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008301 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_008304;
L_008304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8304u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8304u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008304 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008306;
L_008306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8306u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8306u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008306 ADC
    cpu.adc(0x0u);
    goto L_008308;
L_008308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8308u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8308u, 4u, 3u, cpu.address("abs", 0x211Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008308 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_00830B;
L_00830B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00830B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00830D;
L_00830D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00830D CLC
    cpu.setFlag('C', false);
    goto L_00830E;
L_00830E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00830E ADC
    cpu.adc(0x80u);
    goto L_008310;
L_008310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8310u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8310u, 4u, 3u, cpu.address("abs", 0x2120u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008310 STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_008313;
L_008313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8313u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8313u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008313 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008315;
L_008315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8315u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8315u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008315 ADC
    cpu.adc(0x0u);
    goto L_008317;
L_008317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8317u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8317u, 4u, 3u, cpu.address("abs", 0x2120u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008317 STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_00831A;
L_00831A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00831A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00831C;
L_00831C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00831C STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_00831F;
L_00831F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00831F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008321;
L_008321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8321u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8321u, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008321 STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_008324;
L_008324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x30u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008324 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008326;
L_008326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8326u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8326u, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008326 STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_008329;
L_008329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8329u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8329u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x31u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008329 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x31u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00832B;
L_00832B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Bu, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00832B STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_00832E;
L_00832E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00832E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x32u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008330;
L_008330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8330u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8330u, 4u, 3u, cpu.address("abs", 0x211Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008330 STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_008333;
L_008333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8333u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8333u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x33u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008333 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x33u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008335;
L_008335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8335u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8335u, 4u, 3u, cpu.address("abs", 0x211Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008335 STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_008338;
L_008338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8338u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8338u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x34u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008338 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x34u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00833A;
L_00833A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Au, 4u, 3u, cpu.address("abs", 0x211Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00833A STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_00833D;
L_00833D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00833D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x35u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00833F;
L_00833F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Fu, 4u, 3u, cpu.address("abs", 0x211Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00833F STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_008342;
L_008342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8342u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8342u, 6u, 3u, cpu.address("abs", 0x8416u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008342 JSR -> $008416 stack real
    { cpu.push16Value(hw,0x8344u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8345u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8416u), 0x008342u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008345;
L_008345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8345u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8345u,0x008345u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008345 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008348;
L_008348:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8348u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8348u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8348u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008348 LSR
    cpu.lsrA();
    goto L_008349;
L_008349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8349u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8349u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008349 BCC -> $00835C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00835C; }
    goto L_00834B;
L_00834B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Bu, 4u, 3u, cpu.address("abs", 0x0DAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00834B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDAEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00834E;
L_00834E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Eu, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00834E STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_008351;
L_008351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8351u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8351u, 4u, 3u, cpu.address("abs", 0x0D9Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008351 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008354;
L_008354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8354u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8354u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008354 STA
    hw.write(cpu.address("abs", 0x420Cu), cpu.a, cpu.m8?8:16);
    goto L_008357;
L_008357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8357u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8357u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008357 LDA
    cpu.setA(0x81u, 8);
    goto L_008359;
L_008359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u, 3u, 3u, cpu.address("abs", 0x83F3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008359 JMP -> $0083F3
    goto L_0083F3;
L_00835C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00835C LDY
    cpu.setY(0x24u, 8);
    goto L_00835E;
L_00835E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Eu,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Eu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00835E BIT
    cpu.bit(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), false);
    goto L_008361;
L_008361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8361u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8361u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008361 BVC -> $008371
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_008371; }
    goto L_008363;
L_008363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8363u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8363u, 4u, 3u, cpu.address("abs", 0x13FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008363 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13FCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008366;
L_008366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8366u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8366u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008366 ASL
    cpu.aslA();
    goto L_008367;
L_008367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8367u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8367u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008367 TAX
    cpu.transfer("TAX");
    goto L_008368;
L_008368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u, 4u + ((((0xF8E8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF8E8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008368 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF8E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00836B;
L_00836B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00836B CMP
    cpu.compareA(0x2Au);
    goto L_00836D;
L_00836D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00836D BNE -> $008371
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008371; }
    goto L_00836F;
L_00836F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00836F LDY
    cpu.setY(0x2Du, 8);
    goto L_008371;
L_008371:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8371u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8371u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8371u, 3u, 3u, cpu.address("abs", 0x8294u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008371 JMP -> $008294
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8294u),0x008371u); return;
L_00838C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Cu, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00838C STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_00838F;
L_00838F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00838F LDY
    cpu.setY(0x1Fu, 8);
    goto L_008391;
L_008391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8391u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8391u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8391u, 6u, 3u, cpu.address("abs", 0x843Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008391 JSR -> $00843B stack real
    { cpu.push16Value(hw,0x8393u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8394u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x843Bu), 0x008391u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008394;
L_008394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8394u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8394u,0x008394u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8394u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8394u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008394 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008396;
L_008396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8396u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8396u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8396u, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008396 STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_008399;
L_008399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8399u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8399u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x23u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008399 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x23u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00839B;
L_00839B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Bu, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00839B STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_00839E;
L_00839E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00839E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0083A0;
L_0083A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A0u, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083A0 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_0083A3;
L_0083A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083A3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0083A5;
L_0083A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083A5 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_0083A8;
L_0083A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083A8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0083AA;
L_0083AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AAu, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083AA STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_0083AD;
L_0083AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x40u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0083AF;
L_0083AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083AF STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_0083B2;
L_0083B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083B2 REP
    cpu.rep(0x30u);
    goto L_0083B4;
L_0083B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B4u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0083B4 PLB
    cpu.pop("PLB", hw);
    goto L_0083B5;
L_0083B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0083B5 PLY
    cpu.pop("PLY", hw);
    goto L_0083B6;
L_0083B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0083B6 PLX
    cpu.pop("PLX", hw);
    goto L_0083B7;
L_0083B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0083B7 PLA
    cpu.pop("PLA", hw);
    goto L_0083B8;
L_0083B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B8u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0083B8 PLP
    cpu.pop("PLP", hw);
    goto L_0083B9;
L_0083B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83B9u,0x0083B9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0083B9 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x0083B9u);return;}
L_0083F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F3u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083F3 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0083F6;
L_0083F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F6u, 6u, 3u, cpu.address("abs", 0x8439u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0083F6 JSR -> $008439 stack real
    { cpu.push16Value(hw,0x83F8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83F9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8439u), 0x0083F6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0083F9;
L_0083F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83F9u,0x0083F9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F9u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083F9 NOP
    ;
    goto L_0083FA;
L_0083FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FAu,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083FA NOP
    ;
    goto L_0083FB;
L_0083FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083FB LDA
    cpu.setA(0x7u, 8);
    goto L_0083FD;
L_0083FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FDu, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083FD STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_008400;
L_008400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8400u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8400u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008400 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008402;
L_008402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8402u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8402u, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008402 STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_008405;
L_008405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8405u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8405u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8405u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008405 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008407;
L_008407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8407u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8407u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8407u, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008407 STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_00840A;
L_00840A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00840A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00840C;
L_00840C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Cu, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00840C STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_00840F;
L_00840F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00840F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008411;
L_008411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8411u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8411u, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008411 STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_008414;
L_008414:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8414u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8414u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8414u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008414 BRA -> $0083B2
    goto L_0083B2;
}

void sub_00843B_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008439u: goto L_008439;
    case 0x00843Bu: goto L_00843B;
    case 0x00843Eu: goto L_00843E;
    case 0x008440u: goto L_008440;
    case 0x008443u: goto L_008443;
    case 0x008445u: goto L_008445;
    case 0x008446u: goto L_008446;
    case 0x008448u: goto L_008448;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008439:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8439u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8439u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8439u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008439 LDY
    cpu.setY(0x20u, 8);
    goto L_00843B;
L_00843B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x843Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x843Bu,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x843Bu, 4u, 3u, cpu.address("abs", 0x4212u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00843B BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x4212u), cpu.m8?8:16), false);
    goto L_00843E;
L_00843E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x843Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x843Eu,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x843Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00843E BVS -> $008439
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_008439; }
    goto L_008440;
L_008440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8440u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8440u, 4u, 3u, cpu.address("abs", 0x4212u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008440 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x4212u), cpu.m8?8:16), false);
    goto L_008443;
L_008443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8443u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8443u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8443u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008443 BVC -> $008440
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_008440; }
    goto L_008445;
L_008445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8445u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8445u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008445 DEY
    cpu.decReg('Y');
    goto L_008446;
L_008446:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8446u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8446u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8446u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008446 BNE -> $008445
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008445; }
    goto L_008448;
L_008448:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8448u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8448u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8448u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008448 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008448u);return;} hw.unresolvedReturn(0x008448u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00A6C7_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A6C7u: goto L_00A6C7;
    case 0x00A6C9u: goto L_00A6C9;
    case 0x00A6CBu: goto L_00A6CB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6C7 STX
    hw.write(cpu.address("dp", 0x71u), cpu.x, cpu.x8?8:16);
    goto L_00A6C9;
L_00A6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C9u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6C9 STY
    hw.write(cpu.address("dp", 0x88u), cpu.y, cpu.x8?8:16);
    goto L_00A6CB;
L_00A6CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A6CB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A6CBu);return;} hw.unresolvedReturn(0x00A6CBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00A9D2_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A9D2u: goto L_00A9D2;
    case 0x00A9D3u: goto L_00A9D3;
    case 0x00A9D5u: goto L_00A9D5;
    case 0x00AA35u: goto L_00AA35;
    case 0x00AA37u: goto L_00AA37;
    case 0x00AA3Au: goto L_00AA3A;
    case 0x00AA3Du: goto L_00AA3D;
    case 0x00AA40u: goto L_00AA40;
    case 0x00AA42u: goto L_00AA42;
    case 0x00AA45u: goto L_00AA45;
    case 0x00AA47u: goto L_00AA47;
    case 0x00AA49u: goto L_00AA49;
    case 0x00AA4Cu: goto L_00AA4C;
    case 0x00AA4Eu: goto L_00AA4E;
    case 0x00AA50u: goto L_00AA50;
    case 0x00AA52u: goto L_00AA52;
    case 0x00AA54u: goto L_00AA54;
    case 0x00AA57u: goto L_00AA57;
    case 0x00AA58u: goto L_00AA58;
    case 0x00AA5Au: goto L_00AA5A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A9D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D2u,cpu,0x78u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9D2 SEI
    cpu.setFlag('I', true);
    goto L_00A9D3;
L_00A9D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D3u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9D3 BVS -> $00AA3D
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_00AA3D; }
    goto L_00A9D5;
L_00A9D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A9D5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A9D5u);return;} hw.unresolvedReturn(0x00A9D5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00AA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA35 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00AA37;
L_00AA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA37 STZ
    hw.write(cpu.address("abs", 0x2116u), 0, cpu.m8?8:16);
    goto L_00AA3A;
L_00AA3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Au, 4u + ((((0xA9D6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA9D6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA3A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA9D6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA3D;
L_00AA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA3D STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_00AA40;
L_00AA40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA40u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA40u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA40 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00AA42;
L_00AA42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA42u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA42u, 4u + ((((0x0105u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA42 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x105u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA45;
L_00AA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA45u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA45u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA45 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16));
    goto L_00AA47;
L_00AA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA47u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA47 BEQ -> $00AA4C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00AA4C; }
    goto L_00AA49;
L_00AA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u, 6u, 3u, cpu.address("abs", 0xAA6Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AA49 JSR -> $00AA6B stack real
    { cpu.push16Value(hw,0xAA4Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA4Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA6Bu), 0x00AA49u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AA4C;
L_00AA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA4Cu,0x00AA4Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA4C DEC
    cpu.decMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_00AA4E;
L_00AA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA4E BPL -> $00AA35
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AA35; }
    goto L_00AA50;
L_00AA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA50u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA50 LDX
    cpu.setX(0x3u, 8);
    goto L_00AA52;
L_00AA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA52u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA52 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA54;
L_00AA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u, 5u, 3u, cpu.address("absx", 0x0105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA54 STA
    hw.write(cpu.address("absx", 0x105u), cpu.a, cpu.m8?8:16);
    goto L_00AA57;
L_00AA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA57u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA57u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA57 DEX
    cpu.decReg('X');
    goto L_00AA58;
L_00AA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA58 BPL -> $00AA52
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AA52; }
    goto L_00AA5A;
L_00AA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AA5A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00AA5Au);return;} hw.unresolvedReturn(0x00AA5Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00AFC0_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00AFC0u: goto L_00AFC0;
    case 0x00AFC2u: goto L_00AFC2;
    case 0x00AFC5u: goto L_00AFC5;
    case 0x00AFC6u: goto L_00AFC6;
    case 0x00AFC7u: goto L_00AFC7;
    case 0x00AFC9u: goto L_00AFC9;
    case 0x00AFCBu: goto L_00AFCB;
    case 0x00AFCEu: goto L_00AFCE;
    case 0x00AFCFu: goto L_00AFCF;
    case 0x00AFD0u: goto L_00AFD0;
    case 0x00AFD1u: goto L_00AFD1;
    case 0x00AFD3u: goto L_00AFD3;
    case 0x00AFD5u: goto L_00AFD5;
    case 0x00AFD8u: goto L_00AFD8;
    case 0x00AFDAu: goto L_00AFDA;
    case 0x00AFDCu: goto L_00AFDC;
    case 0x00AFDFu: goto L_00AFDF;
    case 0x00AFE0u: goto L_00AFE0;
    case 0x00AFE3u: goto L_00AFE3;
    case 0x00AFE5u: goto L_00AFE5;
    case 0x00AFE6u: goto L_00AFE6;
    case 0x00AFE9u: goto L_00AFE9;
    case 0x00AFEAu: goto L_00AFEA;
    case 0x00AFECu: goto L_00AFEC;
    case 0x00AFEEu: goto L_00AFEE;
    case 0x00AFF1u: goto L_00AFF1;
    case 0x00AFF4u: goto L_00AFF4;
    case 0x00AFF6u: goto L_00AFF6;
    case 0x00AFF9u: goto L_00AFF9;
    case 0x00AFFAu: goto L_00AFFA;
    case 0x00AFFCu: goto L_00AFFC;
    case 0x00AFFFu: goto L_00AFFF;
    case 0x00B001u: goto L_00B001;
    case 0x00B002u: goto L_00B002;
    case 0x00B003u: goto L_00B003;
    case 0x00B005u: goto L_00B005;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00AFC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFC0 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_00AFC2;
L_00AFC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFC2 AND
    cpu.logicAnd(0x1Fu);
    goto L_00AFC5;
L_00AFC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFC5 ASL
    cpu.aslA();
    goto L_00AFC6;
L_00AFC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFC6 ASL
    cpu.aslA();
    goto L_00AFC7;
L_00AFC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFC7 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_00AFC9;
L_00AFC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFC9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AFCB;
L_00AFCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFCB AND
    cpu.logicAnd(0x3E0u);
    goto L_00AFCE;
L_00AFCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFCE LSR
    cpu.lsrA();
    goto L_00AFCF;
L_00AFCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFCF LSR
    cpu.lsrA();
    goto L_00AFD0;
L_00AFD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFD0 LSR
    cpu.lsrA();
    goto L_00AFD1;
L_00AFD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFD1 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_00AFD3;
L_00AFD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFD3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AFD5;
L_00AFD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFD5 AND
    cpu.logicAnd(0x7Cu);
    goto L_00AFD8;
L_00AFD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFD8 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_00AFDA;
L_00AFDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFDA STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_00AFDC;
L_00AFDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDCu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFDC LDY
    cpu.setY(0x4u, 16);
    goto L_00AFDF;
L_00AFDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDFu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AFDF PHY
    cpu.push("PHY", hw);
    goto L_00AFE0;
L_00AFE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE0u, 5u + 1u, 3u, cpu.address("absy", 0x0006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFE0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AFE3;
L_00AFE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE3u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFE3 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_00AFE5;
L_00AFE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFE5 TAY
    cpu.transfer("TAY");
    goto L_00AFE6;
L_00AFE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE6u, 5u + 1u, 3u, cpu.address("absy", 0xAE77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFE6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAE77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AFE9;
L_00AFE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE9u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE9u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AFE9 PLY
    cpu.pop("PLY", hw);
    goto L_00AFEA;
L_00AFEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEAu,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFEA AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_00AFEC;
L_00AFEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFECu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFEC BEQ -> $00AFF9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00AFF9; }
    goto L_00AFEE;
L_00AFEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEEu, 5u + 1u, 3u, cpu.address("absy", 0xAE6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFEE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAE6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AFF1;
L_00AFF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF1u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF1u, 5u, 3u, cpu.address("abs", 0x1493u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFF1 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x1493u), cpu.m8?8:16), false);
    goto L_00AFF4;
L_00AFF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFF4 BPL -> $00AFF9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AFF9; }
    goto L_00AFF6;
L_00AFF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF6u, 5u + 1u, 3u, cpu.address("absy", 0xAE71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFF6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAE71u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AFF9;
L_00AFF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFF9 CLC
    cpu.setFlag('C', false);
    goto L_00AFFA;
L_00AFFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFAu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFFA ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_00AFFC;
L_00AFFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFCu,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFCu, 5u + 1u, 3u, cpu.address("absy", 0xAE65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFFC AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAE65u), cpu.m8?8:16));
    goto L_00AFFF;
L_00AFFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFFu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFFF TSB
    cpu.tsb(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_00B001;
L_00B001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB001u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB001u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B001 DEY
    cpu.decReg('Y');
    goto L_00B002;
L_00B002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB002u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB002u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B002 DEY
    cpu.decReg('Y');
    goto L_00B003;
L_00B003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB003u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB003u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B003 BPL -> $00AFDF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AFDF; }
    goto L_00B005;
L_00B005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB005u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB005u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B005 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00B005u);return;} hw.unresolvedReturn(0x00B005u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00AFC0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00AFC0u: goto L_00AFC0;
    case 0x00AFC2u: goto L_00AFC2;
    case 0x00AFC5u: goto L_00AFC5;
    case 0x00AFC6u: goto L_00AFC6;
    case 0x00AFC7u: goto L_00AFC7;
    case 0x00AFC9u: goto L_00AFC9;
    case 0x00AFCBu: goto L_00AFCB;
    case 0x00AFCEu: goto L_00AFCE;
    case 0x00AFCFu: goto L_00AFCF;
    case 0x00AFD0u: goto L_00AFD0;
    case 0x00AFD1u: goto L_00AFD1;
    case 0x00AFD3u: goto L_00AFD3;
    case 0x00AFD5u: goto L_00AFD5;
    case 0x00AFD8u: goto L_00AFD8;
    case 0x00AFDAu: goto L_00AFDA;
    case 0x00AFDCu: goto L_00AFDC;
    case 0x00AFDFu: goto L_00AFDF;
    case 0x00AFE0u: goto L_00AFE0;
    case 0x00AFE3u: goto L_00AFE3;
    case 0x00AFE5u: goto L_00AFE5;
    case 0x00AFE6u: goto L_00AFE6;
    case 0x00AFE9u: goto L_00AFE9;
    case 0x00AFEAu: goto L_00AFEA;
    case 0x00AFECu: goto L_00AFEC;
    case 0x00AFEEu: goto L_00AFEE;
    case 0x00AFF1u: goto L_00AFF1;
    case 0x00AFF4u: goto L_00AFF4;
    case 0x00AFF6u: goto L_00AFF6;
    case 0x00AFF9u: goto L_00AFF9;
    case 0x00AFFAu: goto L_00AFFA;
    case 0x00AFFCu: goto L_00AFFC;
    case 0x00AFFFu: goto L_00AFFF;
    case 0x00B001u: goto L_00B001;
    case 0x00B002u: goto L_00B002;
    case 0x00B003u: goto L_00B003;
    case 0x00B005u: goto L_00B005;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00AFC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFC0 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_00AFC2;
L_00AFC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFC2 AND
    cpu.logicAnd(0x1Fu);
    goto L_00AFC5;
L_00AFC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFC5 ASL
    cpu.aslA();
    goto L_00AFC6;
L_00AFC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFC6 ASL
    cpu.aslA();
    goto L_00AFC7;
L_00AFC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFC7 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_00AFC9;
L_00AFC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFC9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AFCB;
L_00AFCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFCB AND
    cpu.logicAnd(0x3E0u);
    goto L_00AFCE;
L_00AFCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFCE LSR
    cpu.lsrA();
    goto L_00AFCF;
L_00AFCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFCF LSR
    cpu.lsrA();
    goto L_00AFD0;
L_00AFD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFD0 LSR
    cpu.lsrA();
    goto L_00AFD1;
L_00AFD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFD1 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_00AFD3;
L_00AFD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFD3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AFD5;
L_00AFD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFD5 AND
    cpu.logicAnd(0x7Cu);
    goto L_00AFD8;
L_00AFD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFD8 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_00AFDA;
L_00AFDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFDA STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_00AFDC;
L_00AFDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDCu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFDC LDY
    cpu.setY(0x4u, 16);
    goto L_00AFDF;
L_00AFDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDFu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AFDF PHY
    cpu.push("PHY", hw);
    goto L_00AFE0;
L_00AFE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE0u, 5u + 1u, 3u, cpu.address("absy", 0x0006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFE0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AFE3;
L_00AFE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE3u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFE3 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_00AFE5;
L_00AFE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFE5 TAY
    cpu.transfer("TAY");
    goto L_00AFE6;
L_00AFE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE6u, 5u + 1u, 3u, cpu.address("absy", 0xAE77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFE6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAE77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AFE9;
L_00AFE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE9u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE9u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AFE9 PLY
    cpu.pop("PLY", hw);
    goto L_00AFEA;
L_00AFEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEAu,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFEA AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_00AFEC;
L_00AFEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFECu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFEC BEQ -> $00AFF9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00AFF9; }
    goto L_00AFEE;
L_00AFEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFEEu, 5u + 1u, 3u, cpu.address("absy", 0xAE6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFEE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAE6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AFF1;
L_00AFF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF1u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF1u, 5u, 3u, cpu.address("abs", 0x1493u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFF1 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x1493u), cpu.m8?8:16), false);
    goto L_00AFF4;
L_00AFF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFF4 BPL -> $00AFF9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AFF9; }
    goto L_00AFF6;
L_00AFF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF6u, 5u + 1u, 3u, cpu.address("absy", 0xAE71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFF6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAE71u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AFF9;
L_00AFF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFF9 CLC
    cpu.setFlag('C', false);
    goto L_00AFFA;
L_00AFFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFAu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFFA ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_00AFFC;
L_00AFFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFCu,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFCu, 5u + 1u, 3u, cpu.address("absy", 0xAE65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFFC AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0xAE65u), cpu.m8?8:16));
    goto L_00AFFF;
L_00AFFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFFu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AFFF TSB
    cpu.tsb(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_00B001;
L_00B001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB001u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB001u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B001 DEY
    cpu.decReg('Y');
    goto L_00B002;
L_00B002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB002u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB002u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B002 DEY
    cpu.decReg('Y');
    goto L_00B003;
L_00B003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB003u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB003u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B003 BPL -> $00AFDF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AFDF; }
    goto L_00B005;
L_00B005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB005u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB005u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B005 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00B005u);return;} hw.unresolvedReturn(0x00B005u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CA2B_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CA2Bu: goto L_00CA2B;
    case 0x00CA2Du: goto L_00CA2D;
    case 0x00CA30u: goto L_00CA30;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA2B LDA
    cpu.setA(0x1u, 8);
    goto L_00CA2D;
L_00CA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du, 4u, 3u, cpu.address("abs", 0x13CEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA2D STA
    hw.write(cpu.address("abs", 0x13CEu), cpu.a, cpu.m8?8:16);
    goto L_00CA30;
L_00CA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA30u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA30u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA30 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CA30u);return;} hw.unresolvedReturn(0x00CA30u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00E92B_E1M1X1CQ_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EA5Eu: goto L_00EA5E;
    case 0x00EA60u: goto L_00EA60;
    case 0x00EA62u: goto L_00EA62;
    case 0x00EA65u: goto L_00EA65;
    case 0x00EA67u: goto L_00EA67;
    case 0x00EA69u: goto L_00EA69;
    case 0x00EA6Bu: goto L_00EA6B;
    case 0x00EA6Du: goto L_00EA6D;
    case 0x00EA6Fu: goto L_00EA6F;
    case 0x00EA71u: goto L_00EA71;
    case 0x00EA73u: goto L_00EA73;
    case 0x00EA75u: goto L_00EA75;
    case 0x00EA78u: goto L_00EA78;
    case 0x00EA7Au: goto L_00EA7A;
    case 0x00EA7Cu: goto L_00EA7C;
    case 0x00EA7Eu: goto L_00EA7E;
    case 0x00EA80u: goto L_00EA80;
    case 0x00EA82u: goto L_00EA82;
    case 0x00EA84u: goto L_00EA84;
    case 0x00EA87u: goto L_00EA87;
    case 0x00EA89u: goto L_00EA89;
    case 0x00EA8Au: goto L_00EA8A;
    case 0x00EA8Du: goto L_00EA8D;
    case 0x00EA8Fu: goto L_00EA8F;
    case 0x00EA92u: goto L_00EA92;
    case 0x00EA94u: goto L_00EA94;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EA5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA5Eu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA5E LDA
    cpu.setA(0x1u, 8);
    goto L_00EA60;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA5E LDA
    cpu.setA(0x1u, 8);
    goto L_00EA60;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA5E LDA
    cpu.setA(0x1u, 8);
    goto L_00EA60;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA5E LDA
    cpu.setA(0x1u, 8);
    goto L_00EA60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA5Eu,0x00EA5Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA60u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA60 STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_00EA62;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA60 STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_00EA62;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA60 STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_00EA62;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA60 STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_00EA62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA60u,0x00EA60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA62u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u, 3u, 3u, cpu.address("abs", 0xFD08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA62 JMP -> $00FD08
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xFD08u),0x00EA62u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u, 3u, 3u, cpu.address("abs", 0xFD08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA62 JMP -> $00FD08
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xFD08u),0x00EA62u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u, 3u, 3u, cpu.address("abs", 0xFD08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA62 JMP -> $00FD08
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xFD08u),0x00EA62u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u, 3u, 3u, cpu.address("abs", 0xFD08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA62 JMP -> $00FD08
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xFD08u),0x00EA62u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA62u,0x00EA62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA65u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA65 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA67;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA65 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA67;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA65 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA67;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA65 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA67;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA65u,0x00EA65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA67u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA67u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA67 BCS -> $00EA5E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EA5E; }
    goto L_00EA69;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA67u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA67 BCS -> $00EA5E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EA5E; }
    goto L_00EA69;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA67u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA67 BCS -> $00EA5E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EA5E; }
    goto L_00EA69;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA67u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA67 BCS -> $00EA5E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EA5E; }
    goto L_00EA69;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA67u,0x00EA67u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA69u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA69u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA69u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA69 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA69u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA69u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA69 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA6B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA69u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA69u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA69 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA6B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA69u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA69u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA69 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA69u,0x00EA69u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA6Bu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA6B BEQ -> $00EAA5
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA5u,0x00EA6Bu); return; }
    goto L_00EA6D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA6B BEQ -> $00EAA5
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA5u,0x00EA6Bu); return; }
    goto L_00EA6D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA6B BEQ -> $00EAA5
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA5u,0x00EA6Bu); return; }
    goto L_00EA6D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA6B BEQ -> $00EAA5
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA5u,0x00EA6Bu); return; }
    goto L_00EA6D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA6Bu,0x00EA6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA6Du))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA6D LDA
    cpu.setA(0xFCu, 8);
    goto L_00EA6F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA6D LDA
    cpu.setA(0xFCu, 8);
    goto L_00EA6F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA6D LDA
    cpu.setA(0xFCu, 8);
    goto L_00EA6F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA6D LDA
    cpu.setA(0xFCu, 8);
    goto L_00EA6F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA6Du,0x00EA6Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA6Fu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Fu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA6F CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16));
    goto L_00EA71;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Fu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA6F CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16));
    goto L_00EA71;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Fu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA6F CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16));
    goto L_00EA71;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Fu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA6Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA6F CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16));
    goto L_00EA71;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA6Fu,0x00EA6Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA71u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA71u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA71u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA71 BMI -> $00EA75
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA75; }
    goto L_00EA73;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA71u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA71u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA71 BMI -> $00EA75
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA75; }
    goto L_00EA73;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA71u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA71u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA71 BMI -> $00EA75
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA75; }
    goto L_00EA73;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA71u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA71u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA71 BMI -> $00EA75
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA75; }
    goto L_00EA73;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA71u,0x00EA71u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA73u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA73u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA73u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA73 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EA75;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA73u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA73u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA73 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EA75;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA73u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA73u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA73 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EA75;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA73u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA73u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA73 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EA75;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA73u,0x00EA73u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA75u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA75u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA75u, 6u, 3u, cpu.address("abs", 0x13FAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA75 INC
    cpu.incMem(hw, cpu.address("abs", 0x13FAu), cpu.m8?8:16);
    goto L_00EA78;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA75u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA75u, 6u, 3u, cpu.address("abs", 0x13FAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA75 INC
    cpu.incMem(hw, cpu.address("abs", 0x13FAu), cpu.m8?8:16);
    goto L_00EA78;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA75u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA75u, 6u, 3u, cpu.address("abs", 0x13FAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA75 INC
    cpu.incMem(hw, cpu.address("abs", 0x13FAu), cpu.m8?8:16);
    goto L_00EA78;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA75u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA75u, 6u, 3u, cpu.address("abs", 0x13FAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA75 INC
    cpu.incMem(hw, cpu.address("abs", 0x13FAu), cpu.m8?8:16);
    goto L_00EA78;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA75u,0x00EA75u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA78u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA78u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA78u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA78 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA7A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA78u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA78u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA78 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA7A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA78u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA78u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA78 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA7A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA78u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA78u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA78 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA7A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA78u,0x00EA78u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA7Au))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA7A AND
    cpu.logicAnd(0x88u);
    goto L_00EA7C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA7A AND
    cpu.logicAnd(0x88u);
    goto L_00EA7C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA7A AND
    cpu.logicAnd(0x88u);
    goto L_00EA7C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA7A AND
    cpu.logicAnd(0x88u);
    goto L_00EA7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA7Au,0x00EA7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA7Cu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA7C CMP
    cpu.compareA(0x88u);
    goto L_00EA7E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA7C CMP
    cpu.compareA(0x88u);
    goto L_00EA7E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA7C CMP
    cpu.compareA(0x88u);
    goto L_00EA7E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA7C CMP
    cpu.compareA(0x88u);
    goto L_00EA7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA7Cu,0x00EA7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA7Eu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA7E BNE -> $00EA62
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA62; }
    goto L_00EA80;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA7E BNE -> $00EA62
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA62; }
    goto L_00EA80;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA7E BNE -> $00EA62
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA62; }
    goto L_00EA80;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA7E BNE -> $00EA62
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA62; }
    goto L_00EA80;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA7Eu,0x00EA7Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA80u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA80u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA80u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA80 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA82;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA80u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA80u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA80 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA82;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA80u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA80u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA80 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA82;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA80u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA80u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA80 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA82;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA80u,0x00EA80u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA82u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA82u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA82 BPL -> $00EA92
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA92; }
    goto L_00EA84;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA82u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA82 BPL -> $00EA92
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA92; }
    goto L_00EA84;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA82u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA82 BPL -> $00EA92
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA92; }
    goto L_00EA84;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA82u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA82 BPL -> $00EA92
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA92; }
    goto L_00EA84;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA82u,0x00EA82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA84u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA84u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA84u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA84 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA87;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA84u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA84u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA84 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA87;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA84u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA84u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA84 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA87;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA84u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA84u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA84 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA84u,0x00EA84u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA87u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA87u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA87 BNE -> $00EA92
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA92; }
    goto L_00EA89;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA87u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA87 BNE -> $00EA92
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA92; }
    goto L_00EA89;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA87u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA87 BNE -> $00EA92
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA92; }
    goto L_00EA89;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA87u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA87 BNE -> $00EA92
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA92; }
    goto L_00EA89;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA87u,0x00EA87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA89u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA89u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA89 INC
    cpu.inc('A');
    goto L_00EA8A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA89u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA89 INC
    cpu.inc('A');
    goto L_00EA8A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA89u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA89 INC
    cpu.inc('A');
    goto L_00EA8A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA89u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA89 INC
    cpu.inc('A');
    goto L_00EA8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA89u,0x00EA89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA8Au))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Au, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA8A STA
    hw.write(cpu.address("abs", 0x140Du), cpu.a, cpu.m8?8:16);
    goto L_00EA8D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Au, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA8A STA
    hw.write(cpu.address("abs", 0x140Du), cpu.a, cpu.m8?8:16);
    goto L_00EA8D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Au, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA8A STA
    hw.write(cpu.address("abs", 0x140Du), cpu.a, cpu.m8?8:16);
    goto L_00EA8D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Au, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA8A STA
    hw.write(cpu.address("abs", 0x140Du), cpu.a, cpu.m8?8:16);
    goto L_00EA8D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA8Au,0x00EA8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA8Du))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA8D LDA
    cpu.setA(0x4u, 8);
    goto L_00EA8F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA8D LDA
    cpu.setA(0x4u, 8);
    goto L_00EA8F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA8D LDA
    cpu.setA(0x4u, 8);
    goto L_00EA8F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA8D LDA
    cpu.setA(0x4u, 8);
    goto L_00EA8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA8Du,0x00EA8Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA8Fu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Fu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA8F STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EA92;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Fu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA8F STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EA92;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Fu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA8F STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EA92;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA8Fu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA8F STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EA92;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA8Fu,0x00EA8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA92u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA92u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA92u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA92 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA94;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA92u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA92u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA92 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA94;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA92u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA92u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA92 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA94;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA92u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA92u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA92 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA92u,0x00EA92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA94u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA94u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA94 AND
    cpu.logicAnd(0x8u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA96u,0x00EA94u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA94u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA94 AND
    cpu.logicAnd(0x8u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA96u,0x00EA94u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA94u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA94 AND
    cpu.logicAnd(0x8u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA96u,0x00EA94u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA94u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA94 AND
    cpu.logicAnd(0x8u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA96u,0x00EA94u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA94u,0x00EA94u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1C1_part3(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EDEEu: goto L_00EDEE;
    case 0x00EDF1u: goto L_00EDF1;
    case 0x00EDF3u: goto L_00EDF3;
    case 0x00EDF5u: goto L_00EDF5;
    case 0x00EDF6u: goto L_00EDF6;
    case 0x00EDF7u: goto L_00EDF7;
    case 0x00EDF8u: goto L_00EDF8;
    case 0x00EDF9u: goto L_00EDF9;
    case 0x00EDFBu: goto L_00EDFB;
    case 0x00EDFEu: goto L_00EDFE;
    case 0x00EE00u: goto L_00EE00;
    case 0x00EE01u: goto L_00EE01;
    case 0x00EE02u: goto L_00EE02;
    case 0x00EE03u: goto L_00EE03;
    case 0x00EE04u: goto L_00EE04;
    case 0x00EE06u: goto L_00EE06;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EDEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDEEu))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu, 6u, 3u, cpu.address("abs", 0xF309u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDEE JSR -> $00F309 stack real
    { cpu.push16Value(hw,0xEDF0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDF1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF309u), 0x00EDEEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDF1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu, 6u, 3u, cpu.address("abs", 0xF309u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDEE JSR -> $00F309 stack real
    { cpu.push16Value(hw,0xEDF0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDF1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF309u), 0x00EDEEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDF1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu, 6u, 3u, cpu.address("abs", 0xF309u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDEE JSR -> $00F309 stack real
    { cpu.push16Value(hw,0xEDF0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDF1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF309u), 0x00EDEEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDF1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDEEu,0x00EDEEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF1u))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF1 BRA -> $00EE1D
    hw.requestDispatch(0x00EE1Du,0x00EDF1u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF1 BRA -> $00EE1D
    hw.requestDispatch(0x00EE1Du,0x00EDF1u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF1 BRA -> $00EE1D
    hw.requestDispatch(0x00EE1Du,0x00EDF1u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF1u,0x00EDF1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF3u))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF3 CPY
    cpu.compareY(0xB06Eu);
    goto L_00EDF6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF3 CPY
    cpu.compareY(0x6Eu);
    goto L_00EDF5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF3 CPY
    cpu.compareY(0x6Eu);
    goto L_00EDF5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF3u,0x00EDF3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF5u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF5 BCS -> $00EE1D
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE1Du,0x00EDF5u); return; }
    goto L_00EDF7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF5 BCS -> $00EE1D
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE1Du,0x00EDF5u); return; }
    goto L_00EDF7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF5u,0x00EDF5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF6u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF6u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA5u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF6 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xA5u), cpu.m8?8:16);
    goto L_00EDF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF6u,0x00EDF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF7u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EDF9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EDF9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF7u,0x00EDF7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF8u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF8u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF8u, 5u + 1u, 3u, cpu.address("absx", 0x3E30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF8 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x3E30u), cpu.m8?8:16));
    goto L_00EDFB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF8u,0x00EDF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF9u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF9 BMI -> $00EE39
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE39u,0x00EDF9u); return; }
    goto L_00EDFB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF9 BMI -> $00EE39
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE39u,0x00EDF9u); return; }
    goto L_00EDFB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF9u,0x00EDF9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDFBu))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu, 5u, 3u, cpu.address("abs", 0x1931u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDFB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EDFE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu, 5u, 3u, cpu.address("abs", 0x1931u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDFB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EDFE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDFB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EDFE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDFBu,0x00EDFBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDFEu))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDFE CMP
    cpu.compareA(0xF003u);
    goto L_00EE01;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDFE CMP
    cpu.compareA(0xF003u);
    goto L_00EE01;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDFE CMP
    cpu.compareA(0x3u);
    goto L_00EE00;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDFEu,0x00EDFEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE00u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE00u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE00 BEQ -> $00EE06
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE06; }
    goto L_00EE02;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE00u,0x00EE00u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE01u))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE01u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE01u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE01 TSB
    cpu.tsb(hw, cpu.address("dp", 0xC9u), cpu.m8?8:16);
    goto L_00EE03;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE01u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE01u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE01 TSB
    cpu.tsb(hw, cpu.address("dp", 0xC9u), cpu.m8?8:16);
    goto L_00EE03;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE01u,0x00EE01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE02u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE02u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE02 CMP
    cpu.compareA(0xEu);
    goto L_00EE04;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE02u,0x00EE02u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE03u))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE03u,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE03u, 8u, 3u, cpu.address("abs", 0x0BD0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE03 ASL
    cpu.aslMem(hw, cpu.address("abs", 0xBD0u), cpu.m8?8:16);
    goto L_00EE06;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE03u,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE03u, 8u, 3u, cpu.address("abs", 0x0BD0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE03 ASL
    cpu.aslMem(hw, cpu.address("abs", 0xBD0u), cpu.m8?8:16);
    goto L_00EE06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE03u,0x00EE03u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE04u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE04u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE04 BNE -> $00EE11
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE11u,0x00EE04u); return; }
    goto L_00EE06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE04u,0x00EE04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE06u))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u, 5u, 3u, cpu.address("abs", 0x1693u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE06 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE09u,0x00EE06u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE06 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE09u,0x00EE06u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE06 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE09u,0x00EE06u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE06u,0x00EE06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part3(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EDEEu: goto L_00EDEE;
    case 0x00EDF1u: goto L_00EDF1;
    case 0x00EDF3u: goto L_00EDF3;
    case 0x00EDF5u: goto L_00EDF5;
    case 0x00EDF6u: goto L_00EDF6;
    case 0x00EDF7u: goto L_00EDF7;
    case 0x00EDF8u: goto L_00EDF8;
    case 0x00EDF9u: goto L_00EDF9;
    case 0x00EDFBu: goto L_00EDFB;
    case 0x00EDFEu: goto L_00EDFE;
    case 0x00EE00u: goto L_00EE00;
    case 0x00EE01u: goto L_00EE01;
    case 0x00EE02u: goto L_00EE02;
    case 0x00EE03u: goto L_00EE03;
    case 0x00EE04u: goto L_00EE04;
    case 0x00EE06u: goto L_00EE06;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EDEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDEEu))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu, 6u, 3u, cpu.address("abs", 0xF309u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDEE JSR -> $00F309 stack real
    { cpu.push16Value(hw,0xEDF0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDF1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF309u), 0x00EDEEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDF1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu, 6u, 3u, cpu.address("abs", 0xF309u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDEE JSR -> $00F309 stack real
    { cpu.push16Value(hw,0xEDF0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDF1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF309u), 0x00EDEEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDF1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu, 6u, 3u, cpu.address("abs", 0xF309u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDEE JSR -> $00F309 stack real
    { cpu.push16Value(hw,0xEDF0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDF1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF309u), 0x00EDEEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDF1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDEEu,0x00EDEEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF1u))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF1 BRA -> $00EE1D
    hw.requestDispatch(0x00EE1Du,0x00EDF1u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF1 BRA -> $00EE1D
    hw.requestDispatch(0x00EE1Du,0x00EDF1u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF1 BRA -> $00EE1D
    hw.requestDispatch(0x00EE1Du,0x00EDF1u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF1u,0x00EDF1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF3u))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF3 CPY
    cpu.compareY(0xB06Eu);
    goto L_00EDF6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF3 CPY
    cpu.compareY(0x6Eu);
    goto L_00EDF5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF3 CPY
    cpu.compareY(0x6Eu);
    goto L_00EDF5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF3u,0x00EDF3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF5u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF5 BCS -> $00EE1D
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE1Du,0x00EDF5u); return; }
    goto L_00EDF7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF5 BCS -> $00EE1D
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE1Du,0x00EDF5u); return; }
    goto L_00EDF7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF5u,0x00EDF5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF6u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF6u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA5u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF6 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xA5u), cpu.m8?8:16);
    goto L_00EDF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF6u,0x00EDF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF7u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EDF9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EDF9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF7u,0x00EDF7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF8u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF8u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF8u, 5u + 1u, 3u, cpu.address("absx", 0x3E30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF8 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x3E30u), cpu.m8?8:16));
    goto L_00EDFB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF8u,0x00EDF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF9u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF9 BMI -> $00EE39
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE39u,0x00EDF9u); return; }
    goto L_00EDFB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF9 BMI -> $00EE39
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE39u,0x00EDF9u); return; }
    goto L_00EDFB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF9u,0x00EDF9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDFBu))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu, 5u, 3u, cpu.address("abs", 0x1931u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDFB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EDFE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu, 5u, 3u, cpu.address("abs", 0x1931u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDFB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EDFE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFBu, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDFB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EDFE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDFBu,0x00EDFBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDFEu))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDFE CMP
    cpu.compareA(0xF003u);
    goto L_00EE01;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDFE CMP
    cpu.compareA(0xF003u);
    goto L_00EE01;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDFE CMP
    cpu.compareA(0x3u);
    goto L_00EE00;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDFEu,0x00EDFEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE00u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE00u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE00 BEQ -> $00EE06
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE06; }
    goto L_00EE02;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE00u,0x00EE00u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE01u))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE01u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE01u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE01 TSB
    cpu.tsb(hw, cpu.address("dp", 0xC9u), cpu.m8?8:16);
    goto L_00EE03;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE01u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE01u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE01 TSB
    cpu.tsb(hw, cpu.address("dp", 0xC9u), cpu.m8?8:16);
    goto L_00EE03;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE01u,0x00EE01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE02u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE02u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE02 CMP
    cpu.compareA(0xEu);
    goto L_00EE04;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE02u,0x00EE02u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE03u))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE03u,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE03u, 8u, 3u, cpu.address("abs", 0x0BD0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE03 ASL
    cpu.aslMem(hw, cpu.address("abs", 0xBD0u), cpu.m8?8:16);
    goto L_00EE06;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE03u,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE03u, 8u, 3u, cpu.address("abs", 0x0BD0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE03 ASL
    cpu.aslMem(hw, cpu.address("abs", 0xBD0u), cpu.m8?8:16);
    goto L_00EE06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE03u,0x00EE03u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE04u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE04u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE04 BNE -> $00EE11
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE11u,0x00EE04u); return; }
    goto L_00EE06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE04u,0x00EE04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE06u))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u, 5u, 3u, cpu.address("abs", 0x1693u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE06 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE09u,0x00EE06u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE06 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE09u,0x00EE06u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE06u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE06 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1693u), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE09u,0x00EE06u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE06u,0x00EE06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E1M1X1CQ_part8(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE85u: goto L_00EE85;
    case 0x00EE86u: goto L_00EE86;
    case 0x00EE87u: goto L_00EE87;
    case 0x00EE89u: goto L_00EE89;
    case 0x00EE8Bu: goto L_00EE8B;
    case 0x00EE8Du: goto L_00EE8D;
    case 0x00EE8Eu: goto L_00EE8E;
    case 0x00EE8Fu: goto L_00EE8F;
    case 0x00EE92u: goto L_00EE92;
    case 0x00EE94u: goto L_00EE94;
    case 0x00EE95u: goto L_00EE95;
    case 0x00EE96u: goto L_00EE96;
    case 0x00EE98u: goto L_00EE98;
    case 0x00EE99u: goto L_00EE99;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE85u))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE85u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE85u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE85 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE87;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE85u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE85u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE85 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE85u,0x00EE85u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE86u))return;
  // 6 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE86u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE86u, 5u + 1u, 3u, cpu.address("absx", 0x0610u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE86 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x610u), cpu.m8?8:16));
    goto L_00EE89;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE86u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE86u, 4u + 1u, 3u, cpu.address("absx", 0x0610u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE86 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x610u), cpu.m8?8:16));
    goto L_00EE89;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE86u,0x00EE86u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE87u))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE87 BPL -> $00EE8F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EE8F; }
    goto L_00EE89;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE87 BPL -> $00EE8F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EE8F; }
    goto L_00EE89;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE87u,0x00EE87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE89u))return;
  // 15 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE89 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE8B;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE89 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE8B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE89 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE8B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE89 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE8B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE89u,0x00EE89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Bu))return;
  // 15 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8B CMP
    cpu.compareA(0x9002u);
    goto L_00EE8E;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8B CMP
    cpu.compareA(0x9002u);
    goto L_00EE8E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8B CMP
    cpu.compareA(0x2u);
    goto L_00EE8D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8B CMP
    cpu.compareA(0x2u);
    goto L_00EE8D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Bu,0x00EE8Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Du))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8D BCC -> $00EE39
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE39u,0x00EE8Du); return; }
    goto L_00EE8F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8D BCC -> $00EE39
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE39u,0x00EE8Du); return; }
    goto L_00EE8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Du,0x00EE8Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Eu))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8E TAX
    cpu.transfer("TAX");
    goto L_00EE8F;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8E TAX
    cpu.transfer("TAX");
    goto L_00EE8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Eu,0x00EE8Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Fu))return;
  // 15 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu, 5u, 3u, cpu.address("abs", 0x1423u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1423u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE92;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu, 4u, 3u, cpu.address("abs", 0x1423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1423u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE92;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu, 5u, 3u, cpu.address("abs", 0x1423u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1423u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE92;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu, 4u, 3u, cpu.address("abs", 0x1423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1423u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE92;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,0x00EE8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE92u))return;
  // 15 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE92 BEQ -> $00EED1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EE92u); return; }
    goto L_00EE94;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE92 BEQ -> $00EED1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EE92u); return; }
    goto L_00EE94;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE92 BEQ -> $00EED1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EE92u); return; }
    goto L_00EE94;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE92 BEQ -> $00EED1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EE92u); return; }
    goto L_00EE94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE92u,0x00EE92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE94u))return;
  // 15 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE94 DEX
    cpu.decReg('X');
    goto L_00EE95;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE94 DEX
    cpu.decReg('X');
    goto L_00EE95;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE94 DEX
    cpu.decReg('X');
    goto L_00EE95;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE94 DEX
    cpu.decReg('X');
    goto L_00EE95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE94u,0x00EE94u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE95u))return;
  // 15 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE95 TXA
    cpu.transfer("TXA");
    goto L_00EE96;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE95 TXA
    cpu.transfer("TXA");
    goto L_00EE96;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE95 TXA
    cpu.transfer("TXA");
    goto L_00EE96;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE95 TXA
    cpu.transfer("TXA");
    goto L_00EE96;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE95u,0x00EE95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE96u))return;
  // 15 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0xF003u);
    goto L_00EE99;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0xF003u);
    goto L_00EE99;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0x3u);
    goto L_00EE98;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0x3u);
    goto L_00EE98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE96u,0x00EE96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE98u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE98 BEQ -> $00EEAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EEAAu,0x00EE98u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Au,0x00EE98u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE98 BEQ -> $00EEAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EEAAu,0x00EE98u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Au,0x00EE98u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE98u,0x00EE98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE99u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE99 BPL -> $00EE64
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE64u,0x00EE99u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,0x00EE99u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE99 BPL -> $00EE64
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE64u,0x00EE99u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,0x00EE99u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE99u,0x00EE99u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_01953C_E0M1X1C0_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A329u: goto L_01A329;
    case 0x01A32Bu: goto L_01A32B;
    case 0x01A32Cu: goto L_01A32C;
    case 0x01A32Eu: goto L_01A32E;
    case 0x01A331u: goto L_01A331;
    case 0x01A332u: goto L_01A332;
    case 0x01A334u: goto L_01A334;
    case 0x01A337u: goto L_01A337;
    case 0x01A33Au: goto L_01A33A;
    case 0x01A33Cu: goto L_01A33C;
    case 0x01A33Fu: goto L_01A33F;
    case 0x01A341u: goto L_01A341;
    case 0x01A342u: goto L_01A342;
    case 0x01A344u: goto L_01A344;
    case 0x01A347u: goto L_01A347;
    case 0x01A34Au: goto L_01A34A;
    case 0x01A34Cu: goto L_01A34C;
    case 0x01A34Fu: goto L_01A34F;
    case 0x01A352u: goto L_01A352;
    case 0x01A355u: goto L_01A355;
    case 0x01A359u: goto L_01A359;
    case 0x01E6F0u: goto L_01E6F0;
    case 0x01E6F3u: goto L_01E6F3;
    case 0x01E6F6u: goto L_01E6F6;
    case 0x01E6F7u: goto L_01E6F7;
    case 0x01E6F9u: goto L_01E6F9;
    case 0x01E6FCu: goto L_01E6FC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA329u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA329u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A329 EOR
    cpu.logicXor(0xFFu);
    goto L_01A32B;
L_01A32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A32B INC
    cpu.inc('A');
    goto L_01A32C;
L_01A32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A32C DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_01A32E;
L_01A32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA32Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Eu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Eu, 4u + ((((0x160Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x160Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A32E LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x160Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A331;
L_01A331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA331u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA331u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A331 CLC
    cpu.setFlag('C', false);
    goto L_01A332;
L_01A332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA332u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA332u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A332 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16));
    goto L_01A334;
L_01A334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA334u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA334u, 5u, 3u, cpu.address("absy", 0x00E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A334 STA
    hw.write(cpu.address("absy", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_01A337;
L_01A337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA337u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA337u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A337 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A33A;
L_01A33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A33A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16));
    goto L_01A33C;
L_01A33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA33Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Cu, 5u, 3u, cpu.address("absy", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A33C STA
    hw.write(cpu.address("absy", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_01A33F;
L_01A33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A33F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A341;
L_01A341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA341u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA341u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A341 SEC
    cpu.setFlag('C', true);
    goto L_01A342;
L_01A342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA342u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA342u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A342 SBC
    cpu.sbc(0x2u);
    goto L_01A344;
L_01A344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA344u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA344u, 5u, 3u, cpu.address("absy", 0x00D8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A344 STA
    hw.write(cpu.address("absy", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_01A347;
L_01A347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA347u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA347u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A347 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A34A;
L_01A34A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A34A SBC
    cpu.sbc(0x0u);
    goto L_01A34C;
L_01A34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Cu, 5u, 3u, cpu.address("absy", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A34C STA
    hw.write(cpu.address("absy", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_01A34F;
L_01A34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Fu, 6u, 3u, cpu.address("abs", 0xA169u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A34F JSR -> $01A169 stack real
    { cpu.push16Value(hw,0xA351u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA352u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA169u), 0x01A34Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A352;
L_01A352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA352u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA352u,0x01A352u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA352u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA352u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A352 JSR -> $019F0D stack real
    { cpu.push16Value(hw,0xA354u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA355u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x01A352u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A355;
L_01A355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA355u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA355u,0x01A355u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA355u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA355u, 8u, 4u, 0x02EA25u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A355 JSL -> $02EA25 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA358u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA359u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02EA25u, 0x01A355u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A359;
L_01A359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA359u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA359u,0x01A359u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA359u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA359u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A359 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A359u);return;} hw.unresolvedReturn(0x01A359u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01E6F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F0u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F0u, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E6F0 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1602u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01E6F3;
L_01E6F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F3u, 4u + ((((0xE6FDu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE6FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E6F3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E6F6;
L_01E6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E6F6 TAY
    cpu.transfer("TAY");
    goto L_01E6F7;
L_01E6F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E6F7 LDA
    cpu.setA(0x2u, 8);
    goto L_01E6F9;
L_01E6F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F9u, 6u, 3u, cpu.address("abs", 0x9CF5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E6F9 JSR -> $019CF5 stack real
    { cpu.push16Value(hw,0xE6FBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE6FCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CF5u), 0x01E6F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E6FC;
L_01E6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6FCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE6FCu,0x01E6FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E6FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01E6FCu);return;} hw.unresolvedReturn(0x01E6FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01953C_E0M1X1CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A329u: goto L_01A329;
    case 0x01A32Bu: goto L_01A32B;
    case 0x01A32Cu: goto L_01A32C;
    case 0x01A32Eu: goto L_01A32E;
    case 0x01A331u: goto L_01A331;
    case 0x01A332u: goto L_01A332;
    case 0x01A334u: goto L_01A334;
    case 0x01A337u: goto L_01A337;
    case 0x01A33Au: goto L_01A33A;
    case 0x01A33Cu: goto L_01A33C;
    case 0x01A33Fu: goto L_01A33F;
    case 0x01A341u: goto L_01A341;
    case 0x01A342u: goto L_01A342;
    case 0x01A344u: goto L_01A344;
    case 0x01A347u: goto L_01A347;
    case 0x01A34Au: goto L_01A34A;
    case 0x01A34Cu: goto L_01A34C;
    case 0x01A34Fu: goto L_01A34F;
    case 0x01A352u: goto L_01A352;
    case 0x01A355u: goto L_01A355;
    case 0x01A359u: goto L_01A359;
    case 0x01E6F0u: goto L_01E6F0;
    case 0x01E6F3u: goto L_01E6F3;
    case 0x01E6F6u: goto L_01E6F6;
    case 0x01E6F7u: goto L_01E6F7;
    case 0x01E6F9u: goto L_01E6F9;
    case 0x01E6FCu: goto L_01E6FC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA329u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA329u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A329 EOR
    cpu.logicXor(0xFFu);
    goto L_01A32B;
L_01A32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A32B INC
    cpu.inc('A');
    goto L_01A32C;
L_01A32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A32C DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_01A32E;
L_01A32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA32Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Eu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Eu, 4u + ((((0x160Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x160Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A32E LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x160Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A331;
L_01A331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA331u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA331u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A331 CLC
    cpu.setFlag('C', false);
    goto L_01A332;
L_01A332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA332u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA332u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A332 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16));
    goto L_01A334;
L_01A334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA334u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA334u, 5u, 3u, cpu.address("absy", 0x00E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A334 STA
    hw.write(cpu.address("absy", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_01A337;
L_01A337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA337u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA337u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A337 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A33A;
L_01A33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A33A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16));
    goto L_01A33C;
L_01A33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA33Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Cu, 5u, 3u, cpu.address("absy", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A33C STA
    hw.write(cpu.address("absy", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_01A33F;
L_01A33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A33F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A341;
L_01A341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA341u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA341u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A341 SEC
    cpu.setFlag('C', true);
    goto L_01A342;
L_01A342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA342u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA342u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A342 SBC
    cpu.sbc(0x2u);
    goto L_01A344;
L_01A344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA344u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA344u, 5u, 3u, cpu.address("absy", 0x00D8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A344 STA
    hw.write(cpu.address("absy", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_01A347;
L_01A347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA347u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA347u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A347 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A34A;
L_01A34A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A34A SBC
    cpu.sbc(0x0u);
    goto L_01A34C;
L_01A34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Cu, 5u, 3u, cpu.address("absy", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A34C STA
    hw.write(cpu.address("absy", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_01A34F;
L_01A34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Fu, 6u, 3u, cpu.address("abs", 0xA169u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A34F JSR -> $01A169 stack real
    { cpu.push16Value(hw,0xA351u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA352u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA169u), 0x01A34Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A352;
L_01A352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA352u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA352u,0x01A352u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA352u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA352u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A352 JSR -> $019F0D stack real
    { cpu.push16Value(hw,0xA354u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA355u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x01A352u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A355;
L_01A355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA355u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA355u,0x01A355u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA355u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA355u, 8u, 4u, 0x02EA25u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A355 JSL -> $02EA25 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA358u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA359u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02EA25u, 0x01A355u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A359;
L_01A359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA359u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA359u,0x01A359u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA359u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA359u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A359 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A359u);return;} hw.unresolvedReturn(0x01A359u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01E6F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F0u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F0u, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E6F0 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1602u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01E6F3;
L_01E6F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F3u, 4u + ((((0xE6FDu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE6FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E6F3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01E6F6;
L_01E6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E6F6 TAY
    cpu.transfer("TAY");
    goto L_01E6F7;
L_01E6F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01E6F7 LDA
    cpu.setA(0x2u, 8);
    goto L_01E6F9;
L_01E6F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F9u, 6u, 3u, cpu.address("abs", 0x9CF5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E6F9 JSR -> $019CF5 stack real
    { cpu.push16Value(hw,0xE6FBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE6FCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CF5u), 0x01E6F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01E6FC;
L_01E6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6FCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE6FCu,0x01E6FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01E6FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01E6FCu);return;} hw.unresolvedReturn(0x01E6FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01EF18_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01EF18u: goto L_01EF18;
    case 0x01EF1Bu: goto L_01EF1B;
    case 0x01EF1Eu: goto L_01EF1E;
    case 0x01EF21u: goto L_01EF21;
    case 0x01EF24u: goto L_01EF24;
    case 0x01EF26u: goto L_01EF26;
    case 0x01EF28u: goto L_01EF28;
    case 0x01EF29u: goto L_01EF29;
    case 0x01EF2Au: goto L_01EF2A;
    case 0x01EF2Du: goto L_01EF2D;
    case 0x01EF2Fu: goto L_01EF2F;
    case 0x01EF32u: goto L_01EF32;
    case 0x01EF33u: goto L_01EF33;
    case 0x01EF35u: goto L_01EF35;
    case 0x01EF38u: goto L_01EF38;
    case 0x01EF39u: goto L_01EF39;
    case 0x01EF3Cu: goto L_01EF3C;
    case 0x01EF3Eu: goto L_01EF3E;
    case 0x01EF3Fu: goto L_01EF3F;
    case 0x01EF41u: goto L_01EF41;
    case 0x01EF42u: goto L_01EF42;
    case 0x01EF44u: goto L_01EF44;
    case 0x01EF45u: goto L_01EF45;
    case 0x01EF46u: goto L_01EF46;
    case 0x01EF49u: goto L_01EF49;
    case 0x01EF4Bu: goto L_01EF4B;
    case 0x01EF4Eu: goto L_01EF4E;
    case 0x01EF4Fu: goto L_01EF4F;
    case 0x01EF52u: goto L_01EF52;
    case 0x01EF55u: goto L_01EF55;
    case 0x01EF58u: goto L_01EF58;
    case 0x01EF59u: goto L_01EF59;
    case 0x01EF5Cu: goto L_01EF5C;
    case 0x01EF5Fu: goto L_01EF5F;
    case 0x01EF61u: goto L_01EF61;
    case 0x01EF63u: goto L_01EF63;
    case 0x01EF66u: goto L_01EF66;
    case 0x01EF69u: goto L_01EF69;
    case 0x01EF6Bu: goto L_01EF6B;
    case 0x01EF6Eu: goto L_01EF6E;
    case 0x01EF6Fu: goto L_01EF6F;
    case 0x01EF72u: goto L_01EF72;
    case 0x01EF75u: goto L_01EF75;
    case 0x01EF78u: goto L_01EF78;
    case 0x01EF79u: goto L_01EF79;
    case 0x01EF7Cu: goto L_01EF7C;
    case 0x01EF7Fu: goto L_01EF7F;
    case 0x01EF80u: goto L_01EF80;
    case 0x01EF81u: goto L_01EF81;
    case 0x01EF82u: goto L_01EF82;
    case 0x01EF84u: goto L_01EF84;
    case 0x01EF87u: goto L_01EF87;
    case 0x01EF88u: goto L_01EF88;
    case 0x01EF8Bu: goto L_01EF8B;
    case 0x01EF8Cu: goto L_01EF8C;
    case 0x01EF8Eu: goto L_01EF8E;
    case 0x01EF91u: goto L_01EF91;
    case 0x01EF94u: goto L_01EF94;
    case 0x01EF97u: goto L_01EF97;
    case 0x01EF99u: goto L_01EF99;
    case 0x01EF9Au: goto L_01EF9A;
    case 0x01EF9Cu: goto L_01EF9C;
    case 0x01EF9Eu: goto L_01EF9E;
    case 0x01EFA0u: goto L_01EFA0;
    case 0x01EFA3u: goto L_01EFA3;
    case 0x01EFA6u: goto L_01EFA6;
    case 0x01EFA7u: goto L_01EFA7;
    case 0x01EFAAu: goto L_01EFAA;
    case 0x01EFABu: goto L_01EFAB;
    case 0x01EFADu: goto L_01EFAD;
    case 0x01EFAFu: goto L_01EFAF;
    case 0x01EFB1u: goto L_01EFB1;
    case 0x01EFB3u: goto L_01EFB3;
    case 0x01EFB5u: goto L_01EFB5;
    case 0x01EFB8u: goto L_01EFB8;
    case 0x01EFBAu: goto L_01EFBA;
    case 0x01EFBCu: goto L_01EFBC;
    case 0x01EFBEu: goto L_01EFBE;
    case 0x01EFC0u: goto L_01EFC0;
    case 0x01EFC2u: goto L_01EFC2;
    case 0x01EFC4u: goto L_01EFC4;
    case 0x01EFC6u: goto L_01EFC6;
    case 0x01EFC8u: goto L_01EFC8;
    case 0x01EFCAu: goto L_01EFCA;
    case 0x01EFCDu: goto L_01EFCD;
    case 0x01EFD0u: goto L_01EFD0;
    case 0x01EFD2u: goto L_01EFD2;
    case 0x01EFD4u: goto L_01EFD4;
    case 0x01EFD6u: goto L_01EFD6;
    case 0x01EFD8u: goto L_01EFD8;
    case 0x01EFDAu: goto L_01EFDA;
    case 0x01EFDBu: goto L_01EFDB;
    case 0x01EFDEu: goto L_01EFDE;
    case 0x01EFE0u: goto L_01EFE0;
    case 0x01EFE2u: goto L_01EFE2;
    case 0x01EFE5u: goto L_01EFE5;
    case 0x01EFE7u: goto L_01EFE7;
    case 0x01EFEAu: goto L_01EFEA;
    case 0x01EFECu: goto L_01EFEC;
    case 0x01EFEEu: goto L_01EFEE;
    case 0x01EFF0u: goto L_01EFF0;
    case 0x01EFF3u: goto L_01EFF3;
    case 0x01EFF6u: goto L_01EFF6;
    case 0x01EFF8u: goto L_01EFF8;
    case 0x01EFFAu: goto L_01EFFA;
    case 0x01EFFDu: goto L_01EFFD;
    case 0x01F000u: goto L_01F000;
    case 0x01F003u: goto L_01F003;
    case 0x01F005u: goto L_01F005;
    case 0x01F007u: goto L_01F007;
    case 0x01F009u: goto L_01F009;
    case 0x01F00Bu: goto L_01F00B;
    case 0x01F00Du: goto L_01F00D;
    case 0x01F00Fu: goto L_01F00F;
    case 0x01F012u: goto L_01F012;
    case 0x01F014u: goto L_01F014;
    case 0x01F016u: goto L_01F016;
    case 0x01F018u: goto L_01F018;
    case 0x01F01Au: goto L_01F01A;
    case 0x01F01Cu: goto L_01F01C;
    case 0x01F01Eu: goto L_01F01E;
    case 0x01F020u: goto L_01F020;
    case 0x01F022u: goto L_01F022;
    case 0x01F024u: goto L_01F024;
    case 0x01F025u: goto L_01F025;
    case 0x01F029u: goto L_01F029;
    case 0x01F02Cu: goto L_01F02C;
    case 0x01F02Du: goto L_01F02D;
    case 0x01F02Fu: goto L_01F02F;
    case 0x01F032u: goto L_01F032;
    case 0x01F034u: goto L_01F034;
    case 0x01F036u: goto L_01F036;
    case 0x01F038u: goto L_01F038;
    case 0x01F03Au: goto L_01F03A;
    case 0x01F03Bu: goto L_01F03B;
    case 0x01F03Cu: goto L_01F03C;
    case 0x01F03Eu: goto L_01F03E;
    case 0x01F041u: goto L_01F041;
    case 0x01F042u: goto L_01F042;
    case 0x01F044u: goto L_01F044;
    case 0x01F046u: goto L_01F046;
    case 0x01F048u: goto L_01F048;
    case 0x01F04Au: goto L_01F04A;
    case 0x01F04Cu: goto L_01F04C;
    case 0x01F04Fu: goto L_01F04F;
    case 0x01F051u: goto L_01F051;
    case 0x01F052u: goto L_01F052;
    case 0x01F054u: goto L_01F054;
    case 0x01F057u: goto L_01F057;
    case 0x01F059u: goto L_01F059;
    case 0x01F05Bu: goto L_01F05B;
    case 0x01F05Cu: goto L_01F05C;
    case 0x01F05Eu: goto L_01F05E;
    case 0x01F060u: goto L_01F060;
    case 0x01F063u: goto L_01F063;
    case 0x01F065u: goto L_01F065;
    case 0x01F067u: goto L_01F067;
    case 0x01F068u: goto L_01F068;
    case 0x01F06Au: goto L_01F06A;
    case 0x01F06Cu: goto L_01F06C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01EF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF18u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF18u, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF18 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1602u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EF1B;
L_01EF1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Bu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Bu, 4u, 3u, cpu.address("abs", 0x185Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF1B STY
    hw.write(cpu.address("abs", 0x185Eu), cpu.y, cpu.x8?8:16);
    goto L_01EF1E;
L_01EF1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Eu, 4u + ((((0xEDF9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEDF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF1E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEDF9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EF21;
L_01EF21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF21 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_01EF24;
L_01EF24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF24u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF24u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF24 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_01EF26;
L_01EF26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF26 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EF28;
L_01EF28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF28u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF28u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EF28 PHA
    cpu.push("PHA", hw);
    goto L_01EF29;
L_01EF29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF29u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF29 CLC
    cpu.setFlag('C', false);
    goto L_01EF2A;
L_01EF2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Au,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Au, 4u + ((((0xEE47u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEE47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF2A ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xEE47u), cpu.m8?8:16));
    goto L_01EF2D;
L_01EF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF2D STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_01EF2F;
L_01EF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Fu, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF2F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EF32;
L_01EF32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF32u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF32u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EF32 PHA
    cpu.push("PHA", hw);
    goto L_01EF33;
L_01EF33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF33 ADC
    cpu.adc(0x0u);
    goto L_01EF35;
L_01EF35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF35u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF35u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF35 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_01EF38;
L_01EF38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF38 TYA
    cpu.transfer("TYA");
    goto L_01EF39;
L_01EF39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF39u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF39u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF39 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x157Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EF3C;
L_01EF3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF3C BEQ -> $01EF41
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EF41; }
    goto L_01EF3E;
L_01EF3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF3E CLC
    cpu.setFlag('C', false);
    goto L_01EF3F;
L_01EF3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF3F ADC
    cpu.adc(0xDu);
    goto L_01EF41;
L_01EF41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF41u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF41u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF41 TAY
    cpu.transfer("TAY");
    goto L_01EF42;
L_01EF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF42 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EF44;
L_01EF44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF44u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF44u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EF44 PHA
    cpu.push("PHA", hw);
    goto L_01EF45;
L_01EF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF45 CLC
    cpu.setFlag('C', false);
    goto L_01EF46;
L_01EF46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF46u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF46u, 4u + ((((0xEE13u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEE13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF46 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xEE13u), cpu.m8?8:16));
    goto L_01EF49;
L_01EF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF49u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF49u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF49 STA
    hw.write(cpu.address("dpx", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_01EF4B;
L_01EF4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Bu, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF4B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EF4E;
L_01EF4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Eu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EF4E PHA
    cpu.push("PHA", hw);
    goto L_01EF4F;
L_01EF4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Fu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Fu, 4u + ((((0xEE2Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEE2Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF4F ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xEE2Du), cpu.m8?8:16));
    goto L_01EF52;
L_01EF52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF52u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF52u, 5u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF52 STA
    hw.write(cpu.address("absx", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_01EF55;
L_01EF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF55 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EF58;
L_01EF58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EF58 PHA
    cpu.push("PHA", hw);
    goto L_01EF59;
L_01EF59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF59u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF59u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF59 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EF5C;
L_01EF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Cu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Cu, 4u, 3u, cpu.address("abs", 0x1419u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF5C ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1419u), cpu.m8?8:16));
    goto L_01EF5F;
L_01EF5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF5F BEQ -> $01EF66
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EF66; }
    goto L_01EF61;
L_01EF61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF61u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF61 LDA
    cpu.setA(0x4u, 8);
    goto L_01EF63;
L_01EF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 5u, 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF63 STA
    hw.write(cpu.address("absx", 0x15EAu), cpu.a, cpu.m8?8:16);
    goto L_01EF66;
L_01EF66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF66u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF66u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF66 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EF69;
L_01EF69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF69u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF69u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF69 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_01EF6B;
L_01EF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01EF6B JSR -> $019F0D stack real
    { cpu.push16Value(hw,0xEF6Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF6Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x01EF6Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01EF6E;
L_01EF6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF6Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Eu,0x01EF6Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Eu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EF6E PHX
    cpu.push("PHX", hw);
    goto L_01EF6F;
L_01EF6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF6F LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EF72;
L_01EF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u, 4u, 3u, cpu.address("abs", 0x185Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF72 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x185Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EF75;
L_01EF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u, 4u + ((((0x0301u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF75 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x301u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EF78;
L_01EF78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF78u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF78u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF78 CLC
    cpu.setFlag('C', false);
    goto L_01EF79;
L_01EF79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF79u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF79u, 4u + ((((0xEE54u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xEE54u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF79 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xEE54u), cpu.m8?8:16));
    goto L_01EF7C;
L_01EF7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF7C STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_01EF7F;
L_01EF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Fu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EF7F PLX
    cpu.pop("PLX", hw);
    goto L_01EF80;
L_01EF80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF80u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF80u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EF80 PLA
    cpu.pop("PLA", hw);
    goto L_01EF81;
L_01EF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF81 CLC
    cpu.setFlag('C', false);
    goto L_01EF82;
L_01EF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF82u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF82 ADC
    cpu.adc(0x4u);
    goto L_01EF84;
L_01EF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF84u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF84u, 5u, 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF84 STA
    hw.write(cpu.address("absx", 0x15EAu), cpu.a, cpu.m8?8:16);
    goto L_01EF87;
L_01EF87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF87u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF87u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EF87 PLA
    cpu.pop("PLA", hw);
    goto L_01EF88;
L_01EF88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF88u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF88u, 5u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF88 STA
    hw.write(cpu.address("absx", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_01EF8B;
L_01EF8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Bu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EF8B PLA
    cpu.pop("PLA", hw);
    goto L_01EF8C;
L_01EF8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF8C STA
    hw.write(cpu.address("dpx", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_01EF8E;
L_01EF8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Eu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Eu, 4u, 3u, cpu.address("abs", 0x185Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF8E LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x185Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EF91;
L_01EF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF91u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF91u, 4u + ((((0xEE06u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEE06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF91 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEE06u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EF94;
L_01EF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF94u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF94u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF94 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_01EF97;
L_01EF97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF97u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF97u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF97 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EF99;
L_01EF99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF99 CLC
    cpu.setFlag('C', false);
    goto L_01EF9A;
L_01EF9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF9Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF9A ADC
    cpu.adc(0x10u);
    goto L_01EF9C;
L_01EF9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF9Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF9Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF9C STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_01EF9E;
L_01EF9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF9Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF9Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF9E BCC -> $01EFA3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01EFA3; }
    goto L_01EFA0;
L_01EFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA0u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA0u, 7u, 3u, cpu.address("absx", 0x14D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFA0 INC
    cpu.incMem(hw, cpu.address("absx", 0x14D4u), cpu.m8?8:16);
    goto L_01EFA3;
L_01EFA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA3u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01EFA3 JSR -> $019F0D stack real
    { cpu.push16Value(hw,0xEFA5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFA6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x01EFA3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01EFA6;
L_01EFA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFA6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFA6u,0x01EFA6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA6u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EFA6 PLA
    cpu.pop("PLA", hw);
    goto L_01EFA7;
L_01EFA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA7u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFA7 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_01EFAA;
L_01EFAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAAu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EFAA PLA
    cpu.pop("PLA", hw);
    goto L_01EFAB;
L_01EFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFABu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFAB STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_01EFAD;
L_01EFAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFAD LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EFAF;
L_01EFAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFAF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EFB1;
L_01EFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFB1 BPL -> $01EFB8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01EFB8; }
    goto L_01EFB3;
L_01EFB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFB3 LDA
    cpu.setA(0xF0u, 8);
    goto L_01EFB5;
L_01EFB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB5u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB5u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFB5 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_01EFB8;
L_01EFB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB8u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFB8 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EFBA;
L_01EFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFBA BNE -> $01EFC6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EFC6; }
    goto L_01EFBC;
L_01EFBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFBC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EFBE;
L_01EFBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFBE AND
    cpu.logicAnd(0x30u);
    goto L_01EFC0;
L_01EFC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFC0 BNE -> $01EFDB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EFDB; }
    goto L_01EFC2;
L_01EFC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFC2 LDA
    cpu.setA(0x2Au, 8);
    goto L_01EFC4;
L_01EFC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFC4 BRA -> $01EFFA
    goto L_01EFFA;
L_01EFC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFC6 CMP
    cpu.compareA(0x2u);
    goto L_01EFC8;
L_01EFC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFC8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFC8 BNE -> $01EFDB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EFDB; }
    goto L_01EFCA;
L_01EFCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFCAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFCAu, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFCA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EFCD;
L_01EFCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFCDu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFCDu, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFCD ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13C6u), cpu.m8?8:16));
    goto L_01EFD0;
L_01EFD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFD0 BNE -> $01EFDB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EFDB; }
    goto L_01EFD2;
L_01EFD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFD2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EFD4;
L_01EFD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFD4 AND
    cpu.logicAnd(0x10u);
    goto L_01EFD6;
L_01EFD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFD6 BEQ -> $01EFFD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EFFD; }
    goto L_01EFD8;
L_01EFD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFD8 BRA -> $01EFF8
    goto L_01EFF8;
L_01EFDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01EFDA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01EFDAu);return;} hw.unresolvedReturn(0x01EFDAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01EFDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDBu, 4u + ((((0x1594u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1594u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFDB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1594u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EFDE;
L_01EFDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFDE CMP
    cpu.compareA(0x3u);
    goto L_01EFE0;
L_01EFE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFE0 BEQ -> $01EFEE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EFEE; }
    goto L_01EFE2;
L_01EFE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE2u, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFE2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EFE5;
L_01EFE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFE5 BEQ -> $01EFF3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EFF3; }
    goto L_01EFE7;
L_01EFE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE7u, 4u + ((((0x0302u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFE7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x302u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EFEA;
L_01EFEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFEAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFEA CMP
    cpu.compareA(0x24u);
    goto L_01EFEC;
L_01EFEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFECu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFEC BEQ -> $01EFF3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EFF3; }
    goto L_01EFEE;
L_01EFEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFEEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFEEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFEE LDA
    cpu.setA(0x2Au, 8);
    goto L_01EFF0;
L_01EFF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF0u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFF0 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01EFF3;
L_01EFF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF3u, 4u, 3u, cpu.address("abs", 0x18AEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFF3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18AEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EFF6;
L_01EFF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFF6 BEQ -> $01EFFD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EFFD; }
    goto L_01EFF8;
L_01EFF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFF8 LDA
    cpu.setA(0xCu, 8);
    goto L_01EFFA;
L_01EFFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFFAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFFAu, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFFA STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01EFFD;
L_01EFFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFFDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFFDu, 4u + ((((0x1564u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EFFD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1564u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F000;
L_01F000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF000u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF000u, 4u, 3u, cpu.address("abs", 0x18ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F000 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x18ACu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01F003;
L_01F003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF003u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF003u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F003 BEQ -> $01F00F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F00F; }
    goto L_01F005;
L_01F005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF005u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF005u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F005 CPY
    cpu.compareY(0x26u);
    goto L_01F007;
L_01F007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF007u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF007u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F007 BCS -> $01F038
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01F038; }
    goto L_01F009;
L_01F009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF009u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF009u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF009u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F009 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F00B;
L_01F00B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF00Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF00Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF00Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F00B AND
    cpu.logicAnd(0x18u);
    goto L_01F00D;
L_01F00D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF00Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF00Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF00Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F00D BNE -> $01F038
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F038; }
    goto L_01F00F;
L_01F00F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF00Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF00Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF00Fu, 4u + ((((0x1564u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F00F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1564u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F012;
L_01F012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF012u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF012u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F012 CMP
    cpu.compareA(0x0u);
    goto L_01F014;
L_01F014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF014u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF014u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F014 BEQ -> $01EFDA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EFDA; }
    goto L_01F016;
L_01F016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF016u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF016u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F016 LDY
    cpu.setY(0x0u, 8);
    goto L_01F018;
L_01F018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF018u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF018u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F018 CMP
    cpu.compareA(0xFu);
    goto L_01F01A;
L_01F01A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF01Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF01Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF01Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F01A BCC -> $01F03A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01F03A; }
    goto L_01F01C;
L_01F01C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF01Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF01Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF01Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F01C CMP
    cpu.compareA(0x1Cu);
    goto L_01F01E;
L_01F01E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF01Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF01Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF01Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F01E BCC -> $01F038
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01F038; }
    goto L_01F020;
L_01F020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF020u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF020u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F020 BNE -> $01F02F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F02F; }
    goto L_01F022;
L_01F022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF022u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF022u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F022 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F024;
L_01F024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF024u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF024u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01F024 PHA
    cpu.push("PHA", hw);
    goto L_01F025;
L_01F025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF025u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF025u, 8u, 4u, 0x02D1F3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01F025 JSL -> $02D1F3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF028u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF029u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02D1F3u, 0x01F025u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01F029;
L_01F029:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF029u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF029u,0x01F029u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF029u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF029u, 6u, 3u, cpu.address("abs", 0xF0D3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F029 JSR -> $01F0D3 stack real
    { cpu.push16Value(hw,0xF02Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF02Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF0D3u), 0x01F029u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01F02C;
L_01F02C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF02Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF02Cu,0x01F02Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF02Cu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF02Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01F02C PLA
    cpu.pop("PLA", hw);
    goto L_01F02D;
L_01F02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF02Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF02Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF02Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F02D STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_01F02F;
L_01F02F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF02Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF02Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF02Fu, 6u, 3u, cpu.address("abs", 0x13FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F02F INC
    cpu.incMem(hw, cpu.address("abs", 0x13FBu), cpu.m8?8:16);
    goto L_01F032;
L_01F032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF032u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF032u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF032u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F032 LDA
    cpu.setA(0x0u, 8);
    goto L_01F034;
L_01F034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF034u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF034u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F034 LDY
    cpu.setY(0x2Au, 8);
    goto L_01F036;
L_01F036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF036u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF036u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F036 BRA -> $01F03A
    goto L_01F03A;
L_01F038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF038u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF038u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F038 LDY
    cpu.setY(0x4u, 8);
    goto L_01F03A;
L_01F03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01F03A PHA
    cpu.push("PHA", hw);
    goto L_01F03B;
L_01F03B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF03Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F03B TYA
    cpu.transfer("TYA");
    goto L_01F03C;
L_01F03C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF03Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F03C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01F03E;
L_01F03E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF03Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Eu, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F03E STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01F041;
L_01F041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF041u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF041u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01F041 PLA
    cpu.pop("PLA", hw);
    goto L_01F042;
L_01F042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF042u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF042u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F042 CMP
    cpu.compareA(0xFu);
    goto L_01F044;
L_01F044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF044u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF044u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F044 BCS -> $01F0A0
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x01F0A0u,0x01F044u); return; }
    goto L_01F046;
L_01F046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF046u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF046u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F046 CMP
    cpu.compareA(0x5u);
    goto L_01F048;
L_01F048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF048u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF048u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F048 BCC -> $01F0A0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x01F0A0u,0x01F048u); return; }
    goto L_01F04A;
L_01F04A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF04Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F04A SBC
    cpu.sbc(0x5u);
    goto L_01F04C;
L_01F04C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF04Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Cu, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F04C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x157Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01F04F;
L_01F04F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF04Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F04F BEQ -> $01F054
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F054; }
    goto L_01F051;
L_01F051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF051u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF051u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F051 CLC
    cpu.setFlag('C', false);
    goto L_01F052;
L_01F052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF052u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF052u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF052u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F052 ADC
    cpu.adc(0xAu);
    goto L_01F054;
L_01F054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF054u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF054u, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F054 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1602u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01F057;
L_01F057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF057u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF057u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F057 CPY
    cpu.compareY(0xAu);
    goto L_01F059;
L_01F059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF059u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF059u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F059 BNE -> $01F05E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F05E; }
    goto L_01F05B;
L_01F05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF05Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F05B CLC
    cpu.setFlag('C', false);
    goto L_01F05C;
L_01F05C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF05Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F05C ADC
    cpu.adc(0x14u);
    goto L_01F05E;
L_01F05E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF05Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F05E STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_01F060;
L_01F060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF060u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF060u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF060u, 6u, 3u, cpu.address("abs", 0x80CBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F060 JSR -> $0180CB stack real
    { cpu.push16Value(hw,0xF062u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF063u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80CBu), 0x01F060u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01F063;
L_01F063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF063u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF063u,0x01F063u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF063u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF063u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F063 BNE -> $01F0A0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x01F0A0u,0x01F063u); return; }
    goto L_01F065;
L_01F065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF065u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF065u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F065 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F067;
L_01F067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF067u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF067u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF067u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F067 SEC
    cpu.setFlag('C', true);
    goto L_01F068;
L_01F068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF068u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF068u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF068u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F068 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_01F06A;
L_01F06A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF06Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F06A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_01F06C;
L_01F06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF06Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F06C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF06Eu,0x01F06Cu); return;
}

void sub_02AD34_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02AD34u: goto L_02AD34;
    case 0x02AD36u: goto L_02AD36;
    case 0x02AD39u: goto L_02AD39;
    case 0x02AD3Bu: goto L_02AD3B;
    case 0x02AD3Cu: goto L_02AD3C;
    case 0x02AD3Eu: goto L_02AD3E;
    case 0x02AD41u: goto L_02AD41;
    case 0x02AD43u: goto L_02AD43;
    case 0x02AD45u: goto L_02AD45;
    case 0x02AD48u: goto L_02AD48;
    case 0x02AD4Bu: goto L_02AD4B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02AD34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD34u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD34u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD34 LDY
    cpu.setY(0x5u, 8);
    goto L_02AD36;
L_02AD36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD36u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD36u, 4u + ((((0x16E1u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x16E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD36 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x16E1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02AD39;
L_02AD39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD39u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD39 BEQ -> $02AD4B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02AD4B; }
    goto L_02AD3B;
L_02AD3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD3B DEY
    cpu.decReg('Y');
    goto L_02AD3C;
L_02AD3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD3C BPL -> $02AD36
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02AD36; }
    goto L_02AD3E;
L_02AD3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Eu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD3Eu, 6u, 3u, cpu.address("abs", 0x18F7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD3E DEC
    cpu.decMem(hw, cpu.address("abs", 0x18F7u), cpu.m8?8:16);
    goto L_02AD41;
L_02AD41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD41u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD41 BPL -> $02AD48
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02AD48; }
    goto L_02AD43;
L_02AD43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD43 LDA
    cpu.setA(0x5u, 8);
    goto L_02AD45;
L_02AD45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD45u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD45u, 4u, 3u, cpu.address("abs", 0x18F7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD45 STA
    hw.write(cpu.address("abs", 0x18F7u), cpu.a, cpu.m8?8:16);
    goto L_02AD48;
L_02AD48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD48u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD48u, 4u, 3u, cpu.address("abs", 0x18F7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD48 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x18F7u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02AD4B;
L_02AD4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02AD4B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02AD4Bu);return;} hw.unresolvedReturn(0x02AD4Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_02ADA4_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02ADA4u: goto L_02ADA4;
    case 0x02ADA7u: goto L_02ADA7;
    case 0x02ADA9u: goto L_02ADA9;
    case 0x02ADACu: goto L_02ADAC;
    case 0x02ADAEu: goto L_02ADAE;
    case 0x02ADB0u: goto L_02ADB0;
    case 0x02ADB2u: goto L_02ADB2;
    case 0x02ADB5u: goto L_02ADB5;
    case 0x02ADB8u: goto L_02ADB8;
    case 0x02ADBAu: goto L_02ADBA;
    case 0x02ADBDu: goto L_02ADBD;
    case 0x02ADC0u: goto L_02ADC0;
    case 0x02ADC2u: goto L_02ADC2;
    case 0x02ADC5u: goto L_02ADC5;
    case 0x02ADC6u: goto L_02ADC6;
    case 0x02ADC8u: goto L_02ADC8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02ADA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA4u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA4u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADA4 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), false);
    goto L_02ADA7;
L_02ADA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADA7 BVC -> $02ADB8
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_02ADB8; }
    goto L_02ADA9;
L_02ADA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADA9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02ADAC;
L_02ADAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADACu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADAC CMP
    cpu.compareA(0xC1u);
    goto L_02ADAE;
L_02ADAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADAE BEQ -> $02ADC8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02ADC8; }
    goto L_02ADB0;
L_02ADB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADB0 LDA
    cpu.setA(0xF0u, 8);
    goto L_02ADB2;
L_02ADB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u, 4u, 3u, cpu.address("abs", 0x0205u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADB2 STA
    hw.write(cpu.address("abs", 0x205u), cpu.a, cpu.m8?8:16);
    goto L_02ADB5;
L_02ADB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB5u, 4u, 3u, cpu.address("abs", 0x0209u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADB5 STA
    hw.write(cpu.address("abs", 0x209u), cpu.a, cpu.m8?8:16);
    goto L_02ADB8;
L_02ADB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADB8 LDX
    cpu.setX(0x5u, 8);
    goto L_02ADBA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADB8 LDX
    cpu.setX(0x5u, 8);
    goto L_02ADBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADB8u,0x02ADB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02ADBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADBA STX
    hw.write(cpu.address("abs", 0x15E9u), cpu.x, cpu.x8?8:16);
    goto L_02ADBD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADBA STX
    hw.write(cpu.address("abs", 0x15E9u), cpu.x, cpu.x8?8:16);
    goto L_02ADBD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADBAu,0x02ADBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02ADBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBDu, 4u + ((((0x16E1u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x16E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADBD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x16E1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02ADC0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBDu, 4u + ((((0x16E1u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x16E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADBD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x16E1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02ADC0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADBDu,0x02ADBDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02ADC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADC0 BEQ -> $02ADC5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02ADC5; }
    goto L_02ADC2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADC0 BEQ -> $02ADC5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02ADC5; }
    goto L_02ADC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADC0u,0x02ADC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02ADC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC2u, 6u, 3u, cpu.address("abs", 0xADC9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02ADC2 JSR -> $02ADC9 stack real
    { cpu.push16Value(hw,0xADC4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADC5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xADC9u), 0x02ADC2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02ADC5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC2u, 6u, 3u, cpu.address("abs", 0xADC9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02ADC2 JSR -> $02ADC9 stack real
    { cpu.push16Value(hw,0xADC4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADC5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xADC9u), 0x02ADC2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02ADC5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADC2u,0x02ADC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02ADC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADC5 DEX
    cpu.decReg('X');
    goto L_02ADC6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADC5 DEX
    cpu.decReg('X');
    goto L_02ADC6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADC5u,0x02ADC5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02ADC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADC6 BPL -> $02ADBA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02ADBA; }
    goto L_02ADC8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADC6 BPL -> $02ADBA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02ADBA; }
    goto L_02ADC8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADC6u,0x02ADC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02ADC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02ADC8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02ADC8u);return;} hw.unresolvedReturn(0x02ADC8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02ADC8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02ADC8u);return;} hw.unresolvedReturn(0x02ADC8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADC8u,0x02ADC8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_02ADA4_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02ADA4u: goto L_02ADA4;
    case 0x02ADA7u: goto L_02ADA7;
    case 0x02ADA9u: goto L_02ADA9;
    case 0x02ADACu: goto L_02ADAC;
    case 0x02ADAEu: goto L_02ADAE;
    case 0x02ADB0u: goto L_02ADB0;
    case 0x02ADB2u: goto L_02ADB2;
    case 0x02ADB5u: goto L_02ADB5;
    case 0x02ADB8u: goto L_02ADB8;
    case 0x02ADBAu: goto L_02ADBA;
    case 0x02ADBDu: goto L_02ADBD;
    case 0x02ADC0u: goto L_02ADC0;
    case 0x02ADC2u: goto L_02ADC2;
    case 0x02ADC5u: goto L_02ADC5;
    case 0x02ADC6u: goto L_02ADC6;
    case 0x02ADC8u: goto L_02ADC8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02ADA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA4u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA4u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADA4 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), false);
    goto L_02ADA7;
L_02ADA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADA7 BVC -> $02ADB8
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_02ADB8; }
    goto L_02ADA9;
L_02ADA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADA9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02ADAC;
L_02ADAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADACu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADAC CMP
    cpu.compareA(0xC1u);
    goto L_02ADAE;
L_02ADAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADAE BEQ -> $02ADC8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02ADC8; }
    goto L_02ADB0;
L_02ADB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADB0 LDA
    cpu.setA(0xF0u, 8);
    goto L_02ADB2;
L_02ADB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u, 4u, 3u, cpu.address("abs", 0x0205u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADB2 STA
    hw.write(cpu.address("abs", 0x205u), cpu.a, cpu.m8?8:16);
    goto L_02ADB5;
L_02ADB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB5u, 4u, 3u, cpu.address("abs", 0x0209u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADB5 STA
    hw.write(cpu.address("abs", 0x209u), cpu.a, cpu.m8?8:16);
    goto L_02ADB8;
L_02ADB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADB8 LDX
    cpu.setX(0x5u, 8);
    goto L_02ADBA;
L_02ADBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADBA STX
    hw.write(cpu.address("abs", 0x15E9u), cpu.x, cpu.x8?8:16);
    goto L_02ADBD;
L_02ADBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBDu, 4u + ((((0x16E1u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x16E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADBD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x16E1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02ADC0;
L_02ADC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADC0 BEQ -> $02ADC5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02ADC5; }
    goto L_02ADC2;
L_02ADC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC2u, 6u, 3u, cpu.address("abs", 0xADC9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02ADC2 JSR -> $02ADC9 stack real
    { cpu.push16Value(hw,0xADC4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADC5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xADC9u), 0x02ADC2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02ADC5;
L_02ADC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADC5u,0x02ADC5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADC5 DEX
    cpu.decReg('X');
    goto L_02ADC6;
L_02ADC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ADC6 BPL -> $02ADBA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02ADBA; }
    goto L_02ADC8;
L_02ADC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02ADC8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02ADC8u);return;} hw.unresolvedReturn(0x02ADC8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02AFFE_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02AFFEu: goto L_02AFFE;
    case 0x02B001u: goto L_02B001;
    case 0x02B003u: goto L_02B003;
    case 0x02B005u: goto L_02B005;
    case 0x02B007u: goto L_02B007;
    case 0x02B008u: goto L_02B008;
    case 0x02B00Cu: goto L_02B00C;
    case 0x02B00Eu: goto L_02B00E;
    case 0x02B010u: goto L_02B010;
    case 0x02B012u: goto L_02B012;
    case 0x02B014u: goto L_02B014;
    case 0x02B02Au: goto L_02B02A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02AFFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFEu, 4u, 3u, cpu.address("abs", 0x18B9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AFFE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18B9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02B001;
L_02B001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB001u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB001u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B001 BEQ -> $02B02A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02B02A; }
    goto L_02B003;
L_02B003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB003u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB003u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B003 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x9Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02B005;
L_02B005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB005u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB005u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B005 BNE -> $02B02A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02B02A; }
    goto L_02B007;
L_02B007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB007u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB007u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B007 DEC
    cpu.decReg('A');
    goto L_02B008;
L_02B008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB008u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB008u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02B008 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB00Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB00Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x02B008u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02B00C;
L_02B00C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB00Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB00Cu,0x02B00Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Cu,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Cu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B00C DEC
    cpu.decMem(hw, cpu.address("dpx", 0xB2u), cpu.m8?8:16);
    goto L_02B00E;
L_02B00E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB00Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B00E AND
    cpu.logicAnd(0xB3u);
    goto L_02B010;
L_02B010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB010u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB010u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B010 AND
    cpu.logicAnd(0xB3u);
    goto L_02B012;
L_02B012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB012u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB012u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B012 AND
    cpu.logicAnd(0xB3u);
    goto L_02B014;
L_02B014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB014u,cpu,0x6Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB014u, 5u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, 0x6CB2u, 2u, 0u);
    // $02B014 JMP (6CB2) dinamico
    { auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(0x6CB2u); hw.requestDispatch(dst,0x02B014u); return; }
L_02B02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB02Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02B02A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02B02Au);return;} hw.unresolvedReturn(0x02B02Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02AFFE_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02AFFEu: goto L_02AFFE;
    case 0x02B001u: goto L_02B001;
    case 0x02B003u: goto L_02B003;
    case 0x02B005u: goto L_02B005;
    case 0x02B007u: goto L_02B007;
    case 0x02B008u: goto L_02B008;
    case 0x02B00Cu: goto L_02B00C;
    case 0x02B00Eu: goto L_02B00E;
    case 0x02B010u: goto L_02B010;
    case 0x02B012u: goto L_02B012;
    case 0x02B014u: goto L_02B014;
    case 0x02B02Au: goto L_02B02A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02AFFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFEu, 4u, 3u, cpu.address("abs", 0x18B9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AFFE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18B9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02B001;
L_02B001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB001u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB001u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B001 BEQ -> $02B02A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02B02A; }
    goto L_02B003;
L_02B003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB003u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB003u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B003 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x9Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02B005;
L_02B005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB005u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB005u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B005 BNE -> $02B02A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02B02A; }
    goto L_02B007;
L_02B007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB007u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB007u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B007 DEC
    cpu.decReg('A');
    goto L_02B008;
L_02B008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB008u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB008u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02B008 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB00Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB00Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x02B008u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02B00C;
L_02B00C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB00Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB00Cu,0x02B00Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Cu,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Cu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B00C DEC
    cpu.decMem(hw, cpu.address("dpx", 0xB2u), cpu.m8?8:16);
    goto L_02B00E;
L_02B00E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB00Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B00E AND
    cpu.logicAnd(0xB3u);
    goto L_02B010;
L_02B010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB010u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB010u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B010 AND
    cpu.logicAnd(0xB3u);
    goto L_02B012;
L_02B012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB012u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB012u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02B012 AND
    cpu.logicAnd(0xB3u);
    goto L_02B014;
L_02B014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB014u,cpu,0x6Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB014u, 5u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, 0x6CB2u, 2u, 0u);
    // $02B014 JMP (6CB2) dinamico
    { auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(0x6CB2u); hw.requestDispatch(dst,0x02B014u); return; }
L_02B02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB02Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02B02A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02B02Au);return;} hw.unresolvedReturn(0x02B02Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02D0C9_E1M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02D0C9u: goto L_02D0C9;
    case 0x02D0CCu: goto L_02D0CC;
    case 0x02D0CFu: goto L_02D0CF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02D0C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0C9u, 4u + 1u, 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0C9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D0CC;
L_02D0CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CCu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CCu, 4u + 1u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0CC ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16));
    goto L_02D0CF;
L_02D0CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02D0CF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02D0CFu);return;} hw.unresolvedReturn(0x02D0CFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02D4FA_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02D4FAu: goto L_02D4FA;
    case 0x02D4FCu: goto L_02D4FC;
    case 0x02D4FEu: goto L_02D4FE;
    case 0x02D4FFu: goto L_02D4FF;
    case 0x02D501u: goto L_02D501;
    case 0x02D503u: goto L_02D503;
    case 0x02D505u: goto L_02D505;
    case 0x02D508u: goto L_02D508;
    case 0x02D50Au: goto L_02D50A;
    case 0x02D50Bu: goto L_02D50B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02D4FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D4FA LDY
    cpu.setY(0x0u, 8);
    goto L_02D4FC;
L_02D4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D4FC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D4FE;
L_02D4FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D4FE SEC
    cpu.setFlag('C', true);
    goto L_02D4FF;
L_02D4FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FFu,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D4FF SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16));
    goto L_02D501;
L_02D501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD501u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD501u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D501 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_02D503;
L_02D503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD503u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD503u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD503u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D503 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D505;
L_02D505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD505u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD505u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D505 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16));
    goto L_02D508;
L_02D508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD508u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD508u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D508 BPL -> $02D50B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02D50B; }
    goto L_02D50A;
L_02D50A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD50Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D50A INY
    cpu.inc('Y');
    goto L_02D50B;
L_02D50B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD50Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02D50B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02D50Bu);return;} hw.unresolvedReturn(0x02D50Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_048F87_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x048F87u: goto L_048F87;
    case 0x048F8Au: goto L_048F8A;
    case 0x048F8Cu: goto L_048F8C;
    case 0x048F8Fu: goto L_048F8F;
    case 0x048F92u: goto L_048F92;
    case 0x048F94u: goto L_048F94;
    case 0x048F96u: goto L_048F96;
    case 0x048F99u: goto L_048F99;
    case 0x048F9Cu: goto L_048F9C;
    case 0x048F9Du: goto L_048F9D;
    case 0x048F9Fu: goto L_048F9F;
    case 0x048FA1u: goto L_048FA1;
    case 0x048FA4u: goto L_048FA4;
    case 0x048FA5u: goto L_048FA5;
    case 0x048FA8u: goto L_048FA8;
    case 0x048FA9u: goto L_048FA9;
    case 0x048FACu: goto L_048FAC;
    case 0x048FAFu: goto L_048FAF;
    case 0x048FB2u: goto L_048FB2;
    case 0x048FB5u: goto L_048FB5;
    case 0x048FB8u: goto L_048FB8;
    case 0x048FBBu: goto L_048FBB;
    case 0x048FBEu: goto L_048FBE;
    case 0x048FC1u: goto L_048FC1;
    case 0x048FC2u: goto L_048FC2;
    case 0x048FC3u: goto L_048FC3;
    case 0x048FC4u: goto L_048FC4;
    case 0x048FC7u: goto L_048FC7;
    case 0x048FC8u: goto L_048FC8;
    case 0x048FCBu: goto L_048FCB;
    case 0x048FCEu: goto L_048FCE;
    case 0x048FCFu: goto L_048FCF;
    case 0x048FD1u: goto L_048FD1;
    case 0x048FD2u: goto L_048FD2;
    case 0x048FD3u: goto L_048FD3;
    case 0x048FD5u: goto L_048FD5;
    case 0x048FD6u: goto L_048FD6;
    case 0x048FD9u: goto L_048FD9;
    case 0x048FDCu: goto L_048FDC;
    case 0x048FDFu: goto L_048FDF;
    case 0x048FE1u: goto L_048FE1;
    case 0x048FE3u: goto L_048FE3;
    case 0x048FE6u: goto L_048FE6;
    case 0x048FE8u: goto L_048FE8;
    case 0x048FE9u: goto L_048FE9;
    case 0x048FECu: goto L_048FEC;
    case 0x048FEFu: goto L_048FEF;
    case 0x048FF1u: goto L_048FF1;
    case 0x048FF4u: goto L_048FF4;
    case 0x048FF6u: goto L_048FF6;
    case 0x048FF9u: goto L_048FF9;
    case 0x048FFBu: goto L_048FFB;
    case 0x048FFEu: goto L_048FFE;
    case 0x049000u: goto L_049000;
    case 0x049001u: goto L_049001;
    case 0x049003u: goto L_049003;
    case 0x049005u: goto L_049005;
    case 0x049007u: goto L_049007;
    case 0x04900Au: goto L_04900A;
    case 0x04900Du: goto L_04900D;
    case 0x04900Eu: goto L_04900E;
    case 0x04900Fu: goto L_04900F;
    case 0x049010u: goto L_049010;
    case 0x049011u: goto L_049011;
    case 0x049013u: goto L_049013;
    case 0x049016u: goto L_049016;
    case 0x049017u: goto L_049017;
    case 0x049018u: goto L_049018;
    case 0x049019u: goto L_049019;
    case 0x04901Au: goto L_04901A;
    case 0x04901Cu: goto L_04901C;
    case 0x04901Du: goto L_04901D;
    case 0x04901Eu: goto L_04901E;
    case 0x04901Fu: goto L_04901F;
    case 0x049020u: goto L_049020;
    case 0x049023u: goto L_049023;
    case 0x049025u: goto L_049025;
    case 0x049027u: goto L_049027;
    case 0x04902Bu: goto L_04902B;
    case 0x04902Eu: goto L_04902E;
    case 0x049031u: goto L_049031;
    case 0x049033u: goto L_049033;
    case 0x049036u: goto L_049036;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_048F87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F87u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F87u, 6u, 3u, cpu.address("abs", 0x9903u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048F87 JSR -> $049903 stack real
    { cpu.push16Value(hw,0x8F89u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F8Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9903u), 0x048F87u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048F8A;
L_048F8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F8Au,0x048F8Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F8A LDX
    cpu.setX(0x7u, 8);
    goto L_048F8C;
L_048F8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Cu, 4u, 3u, cpu.address("abs", 0x13C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F8C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048F8F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Cu, 4u, 3u, cpu.address("abs", 0x13C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F8C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048F8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F8Cu,0x048F8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_048F8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu, 4u + ((((0x8F7Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8F7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F8F CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x8F7Fu), cpu.m8?8:16));
    goto L_048F92;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu, 4u + ((((0x8F7Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8F7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F8F CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x8F7Fu), cpu.m8?8:16));
    goto L_048F92;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F8Fu,0x048F8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_048F92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F92u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F92 BNE -> $049000
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049000; }
    goto L_048F94;
L_048F94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F94u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F94 LDX
    cpu.setX(0x2Cu, 8);
    goto L_048F96;
L_048F96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F96u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F96u, 4u + ((((0x1F02u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F96 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F02u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048F99;
L_048F99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F99u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F99u, 5u, 3u, cpu.address("absx", 0x1FA9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F99 STA
    hw.write(cpu.address("absx", 0x1FA9u), cpu.a, cpu.m8?8:16);
    goto L_048F9C;
L_048F9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F9C DEX
    cpu.decReg('X');
    goto L_048F9D;
L_048F9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F9D BPL -> $048F96
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_048F96; }
    goto L_048F9F;
L_048F9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F9F REP
    cpu.rep(0x30u);
    goto L_048FA1;
L_048FA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA1u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA1u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FA1 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_048FA4;
L_048FA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FA4 TXA
    cpu.transfer("TXA");
    goto L_048FA5;
L_048FA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA5u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FA5 EOR
    cpu.logicXor(0x4u);
    goto L_048FA8;
L_048FA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA8u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FA8 TAY
    cpu.transfer("TAY");
    goto L_048FA9;
L_048FA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA9u, 5u + 1u, 3u, cpu.address("absx", 0x1FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FA9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1FBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048FAC;
L_048FAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FACu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FACu, 6u, 3u, cpu.address("absy", 0x1FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FAC STA
    hw.write(cpu.address("absy", 0x1FBEu), cpu.a, cpu.m8?8:16);
    goto L_048FAF;
L_048FAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAFu, 5u + 1u, 3u, cpu.address("absx", 0x1FC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FAF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1FC0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048FB2;
L_048FB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u, 6u, 3u, cpu.address("absy", 0x1FC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FB2 STA
    hw.write(cpu.address("absy", 0x1FC0u), cpu.a, cpu.m8?8:16);
    goto L_048FB5;
L_048FB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB5u, 5u + 1u, 3u, cpu.address("absx", 0x1FC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FB5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1FC6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048FB8;
L_048FB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB8u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB8u, 6u, 3u, cpu.address("absy", 0x1FC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FB8 STA
    hw.write(cpu.address("absy", 0x1FC6u), cpu.a, cpu.m8?8:16);
    goto L_048FBB;
L_048FBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBBu, 5u + 1u, 3u, cpu.address("absx", 0x1FC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FBB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1FC8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048FBE;
L_048FBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBEu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBEu, 6u, 3u, cpu.address("absy", 0x1FC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FBE STA
    hw.write(cpu.address("absy", 0x1FC8u), cpu.a, cpu.m8?8:16);
    goto L_048FC1;
L_048FC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FC1 TXA
    cpu.transfer("TXA");
    goto L_048FC2;
L_048FC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FC2 LSR
    cpu.lsrA();
    goto L_048FC3;
L_048FC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FC3 TAX
    cpu.transfer("TAX");
    goto L_048FC4;
L_048FC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC4u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FC4 EOR
    cpu.logicXor(0x2u);
    goto L_048FC7;
L_048FC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FC7 TAY
    cpu.transfer("TAY");
    goto L_048FC8;
L_048FC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC8u, 5u + 1u, 3u, cpu.address("absx", 0x1FBAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FC8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1FBAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048FCB;
L_048FCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCBu, 6u, 3u, cpu.address("absy", 0x1FBAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FCB STA
    hw.write(cpu.address("absy", 0x1FBAu), cpu.a, cpu.m8?8:16);
    goto L_048FCE;
L_048FCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCEu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FCE TXA
    cpu.transfer("TXA");
    goto L_048FCF;
L_048FCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FCF SEP
    cpu.sep(0x30u);
    goto L_048FD1;
L_048FD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FD1 LSR
    cpu.lsrA();
    goto L_048FD2;
L_048FD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FD2 TAX
    cpu.transfer("TAX");
    goto L_048FD3;
L_048FD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD3u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FD3 EOR
    cpu.logicXor(0x1u);
    goto L_048FD5;
L_048FD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FD5 TAY
    cpu.transfer("TAY");
    goto L_048FD6;
L_048FD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD6u, 4u + ((((0x1FB8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1FB8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FD6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1FB8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048FD9;
L_048FD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD9u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD9u, 5u, 3u, cpu.address("absy", 0x1FB8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FD9 STA
    hw.write(cpu.address("absy", 0x1FB8u), cpu.a, cpu.m8?8:16);
    goto L_048FDC;
L_048FDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDCu, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FDC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048FDF;
L_048FDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FDF CMP
    cpu.compareA(0xE0u);
    goto L_048FE1;
L_048FE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FE1 BNE -> $048FFB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_048FFB; }
    goto L_048FE3;
L_048FE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE3u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE3u, 6u, 3u, cpu.address("abs", 0x0DB1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FE3 DEC
    cpu.decMem(hw, cpu.address("abs", 0xDB1u), cpu.m8?8:16);
    goto L_048FE6;
L_048FE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FE6 BMI -> $048FE9
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_048FE9; }
    goto L_048FE8;
L_048FE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048FE8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x048FE8u);return;} hw.unresolvedReturn(0x048FE8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_048FE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE9u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE9u, 6u, 3u, cpu.address("abs", 0x13CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FE9 INC
    cpu.incMem(hw, cpu.address("abs", 0x13CAu), cpu.m8?8:16);
    goto L_048FEC;
L_048FEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FECu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FECu, 6u, 3u, cpu.address("abs", 0x9037u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048FEC JSR -> $049037 stack real
    { cpu.push16Value(hw,0x8FEEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8FEFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9037u), 0x048FECu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048FEF;
L_048FEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FEFu,0x048FEFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FEF LDA
    cpu.setA(0x2u, 8);
    goto L_048FF1;
L_048FF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF1u, 4u, 3u, cpu.address("abs", 0x0DB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FF1 STA
    hw.write(cpu.address("abs", 0xDB1u), cpu.a, cpu.m8?8:16);
    goto L_048FF4;
L_048FF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FF4 LDA
    cpu.setA(0x4u, 8);
    goto L_048FF6;
L_048FF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF6u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FF6 STA
    hw.write(cpu.address("abs", 0x13D9u), cpu.a, cpu.m8?8:16);
    goto L_048FF9;
L_048FF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FF9 BRA -> $049003
    goto L_049003;
L_048FFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFBu, 6u, 3u, cpu.address("abs", 0x13CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FFB INC
    cpu.incMem(hw, cpu.address("abs", 0x13CAu), cpu.m8?8:16);
    goto L_048FFE;
L_048FFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FFE BRA -> $049003
    goto L_049003;
L_049000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049000 DEX
    cpu.decReg('X');
    goto L_049001;
L_049001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9001u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9001u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049001 BPL -> $048F8C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_048F8C; }
    goto L_049003;
L_049003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9003u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9003u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049003 REP
    cpu.rep(0x20u);
    goto L_049005;
L_049005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9005u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9005u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049005 STZ
    hw.write(cpu.address("dp", 0x6u), 0, cpu.m8?8:16);
    goto L_049007;
L_049007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9007u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9007u, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049007 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04900A;
L_04900A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au, 5u + ((((0x1F17u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04900A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04900D;
L_04900D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04900D LSR
    cpu.lsrA();
    goto L_04900E;
L_04900E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04900E LSR
    cpu.lsrA();
    goto L_04900F;
L_04900F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04900F LSR
    cpu.lsrA();
    goto L_049010;
L_049010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049010 LSR
    cpu.lsrA();
    goto L_049011;
L_049011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9011u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9011u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049011 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_049013;
L_049013:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9013u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9013u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9013u, 5u + ((((0x1F19u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049013 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049016;
L_049016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9016u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9016u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049016 LSR
    cpu.lsrA();
    goto L_049017;
L_049017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049017 LSR
    cpu.lsrA();
    goto L_049018;
L_049018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9018u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9018u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049018 LSR
    cpu.lsrA();
    goto L_049019;
L_049019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9019u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9019u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049019 LSR
    cpu.lsrA();
    goto L_04901A;
L_04901A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04901A STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04901C;
L_04901C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04901C TXA
    cpu.transfer("TXA");
    goto L_04901D;
L_04901D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04901D LSR
    cpu.lsrA();
    goto L_04901E;
L_04901E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04901E LSR
    cpu.lsrA();
    goto L_04901F;
L_04901F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04901F TAX
    cpu.transfer("TAX");
    goto L_049020;
L_049020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9020u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9020u, 6u, 3u, cpu.address("abs", 0x9885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049020 JSR -> $049885 stack real
    { cpu.push16Value(hw,0x9022u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9023u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9885u), 0x049020u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_049023;
L_049023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9023u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9023u,0x049023u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049023 REP
    cpu.rep(0x10u);
    goto L_049025;
L_049025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9025u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9025u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049025 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049027;
L_049027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9027u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9027u, 6u, 4u, ((0x7EC800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049027 LDA
    cpu.loadA(hw.readW(((0x7EC800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04902B;
L_04902B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04902B AND
    cpu.logicAnd(0xFFu);
    goto L_04902E;
L_04902E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Eu, 5u, 3u, cpu.address("abs", 0x13C1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04902E STA
    hw.write(cpu.address("abs", 0x13C1u), cpu.a, cpu.m8?8:16);
    goto L_049031;
L_049031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9031u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9031u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049031 SEP
    cpu.sep(0x30u);
    goto L_049033;
L_049033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u, 6u, 3u, cpu.address("abs", 0x13D9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049033 INC
    cpu.incMem(hw, cpu.address("abs", 0x13D9u), cpu.m8?8:16);
    goto L_049036;
L_049036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9036u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9036u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049036 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x049036u);return;} hw.unresolvedReturn(0x049036u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_048F87_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x048F87u: goto L_048F87;
    case 0x048F8Au: goto L_048F8A;
    case 0x048F8Cu: goto L_048F8C;
    case 0x048F8Fu: goto L_048F8F;
    case 0x048F92u: goto L_048F92;
    case 0x048F94u: goto L_048F94;
    case 0x048F96u: goto L_048F96;
    case 0x048F99u: goto L_048F99;
    case 0x048F9Cu: goto L_048F9C;
    case 0x048F9Du: goto L_048F9D;
    case 0x048F9Fu: goto L_048F9F;
    case 0x048FA1u: goto L_048FA1;
    case 0x048FA4u: goto L_048FA4;
    case 0x048FA5u: goto L_048FA5;
    case 0x048FA8u: goto L_048FA8;
    case 0x048FA9u: goto L_048FA9;
    case 0x048FACu: goto L_048FAC;
    case 0x048FAFu: goto L_048FAF;
    case 0x048FB2u: goto L_048FB2;
    case 0x048FB5u: goto L_048FB5;
    case 0x048FB8u: goto L_048FB8;
    case 0x048FBBu: goto L_048FBB;
    case 0x048FBEu: goto L_048FBE;
    case 0x048FC1u: goto L_048FC1;
    case 0x048FC2u: goto L_048FC2;
    case 0x048FC3u: goto L_048FC3;
    case 0x048FC4u: goto L_048FC4;
    case 0x048FC7u: goto L_048FC7;
    case 0x048FC8u: goto L_048FC8;
    case 0x048FCBu: goto L_048FCB;
    case 0x048FCEu: goto L_048FCE;
    case 0x048FCFu: goto L_048FCF;
    case 0x048FD1u: goto L_048FD1;
    case 0x048FD2u: goto L_048FD2;
    case 0x048FD3u: goto L_048FD3;
    case 0x048FD5u: goto L_048FD5;
    case 0x048FD6u: goto L_048FD6;
    case 0x048FD9u: goto L_048FD9;
    case 0x048FDCu: goto L_048FDC;
    case 0x048FDFu: goto L_048FDF;
    case 0x048FE1u: goto L_048FE1;
    case 0x048FE3u: goto L_048FE3;
    case 0x048FE6u: goto L_048FE6;
    case 0x048FE8u: goto L_048FE8;
    case 0x048FE9u: goto L_048FE9;
    case 0x048FECu: goto L_048FEC;
    case 0x048FEFu: goto L_048FEF;
    case 0x048FF1u: goto L_048FF1;
    case 0x048FF4u: goto L_048FF4;
    case 0x048FF6u: goto L_048FF6;
    case 0x048FF9u: goto L_048FF9;
    case 0x048FFBu: goto L_048FFB;
    case 0x048FFEu: goto L_048FFE;
    case 0x049000u: goto L_049000;
    case 0x049001u: goto L_049001;
    case 0x049003u: goto L_049003;
    case 0x049005u: goto L_049005;
    case 0x049007u: goto L_049007;
    case 0x04900Au: goto L_04900A;
    case 0x04900Du: goto L_04900D;
    case 0x04900Eu: goto L_04900E;
    case 0x04900Fu: goto L_04900F;
    case 0x049010u: goto L_049010;
    case 0x049011u: goto L_049011;
    case 0x049013u: goto L_049013;
    case 0x049016u: goto L_049016;
    case 0x049017u: goto L_049017;
    case 0x049018u: goto L_049018;
    case 0x049019u: goto L_049019;
    case 0x04901Au: goto L_04901A;
    case 0x04901Cu: goto L_04901C;
    case 0x04901Du: goto L_04901D;
    case 0x04901Eu: goto L_04901E;
    case 0x04901Fu: goto L_04901F;
    case 0x049020u: goto L_049020;
    case 0x049023u: goto L_049023;
    case 0x049025u: goto L_049025;
    case 0x049027u: goto L_049027;
    case 0x04902Bu: goto L_04902B;
    case 0x04902Eu: goto L_04902E;
    case 0x049031u: goto L_049031;
    case 0x049033u: goto L_049033;
    case 0x049036u: goto L_049036;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_048F87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F87u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F87u, 6u, 3u, cpu.address("abs", 0x9903u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048F87 JSR -> $049903 stack real
    { cpu.push16Value(hw,0x8F89u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F8Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9903u), 0x048F87u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048F8A;
L_048F8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F8Au,0x048F8Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F8A LDX
    cpu.setX(0x7u, 8);
    goto L_048F8C;
L_048F8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Cu, 4u, 3u, cpu.address("abs", 0x13C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F8C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048F8F;
L_048F8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu, 4u + ((((0x8F7Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8F7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F8F CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x8F7Fu), cpu.m8?8:16));
    goto L_048F92;
L_048F92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F92u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F92 BNE -> $049000
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049000; }
    goto L_048F94;
L_048F94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F94u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F94 LDX
    cpu.setX(0x2Cu, 8);
    goto L_048F96;
L_048F96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F96u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F96u, 4u + ((((0x1F02u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F96 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F02u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048F99;
L_048F99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F99u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F99u, 5u, 3u, cpu.address("absx", 0x1FA9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F99 STA
    hw.write(cpu.address("absx", 0x1FA9u), cpu.a, cpu.m8?8:16);
    goto L_048F9C;
L_048F9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F9C DEX
    cpu.decReg('X');
    goto L_048F9D;
L_048F9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F9D BPL -> $048F96
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_048F96; }
    goto L_048F9F;
L_048F9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048F9F REP
    cpu.rep(0x30u);
    goto L_048FA1;
L_048FA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA1u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA1u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FA1 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_048FA4;
L_048FA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FA4 TXA
    cpu.transfer("TXA");
    goto L_048FA5;
L_048FA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA5u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FA5 EOR
    cpu.logicXor(0x4u);
    goto L_048FA8;
L_048FA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA8u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FA8 TAY
    cpu.transfer("TAY");
    goto L_048FA9;
L_048FA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA9u, 5u + 1u, 3u, cpu.address("absx", 0x1FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FA9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1FBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048FAC;
L_048FAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FACu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FACu, 6u, 3u, cpu.address("absy", 0x1FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FAC STA
    hw.write(cpu.address("absy", 0x1FBEu), cpu.a, cpu.m8?8:16);
    goto L_048FAF;
L_048FAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAFu, 5u + 1u, 3u, cpu.address("absx", 0x1FC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FAF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1FC0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048FB2;
L_048FB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u, 6u, 3u, cpu.address("absy", 0x1FC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FB2 STA
    hw.write(cpu.address("absy", 0x1FC0u), cpu.a, cpu.m8?8:16);
    goto L_048FB5;
L_048FB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB5u, 5u + 1u, 3u, cpu.address("absx", 0x1FC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FB5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1FC6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048FB8;
L_048FB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB8u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB8u, 6u, 3u, cpu.address("absy", 0x1FC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FB8 STA
    hw.write(cpu.address("absy", 0x1FC6u), cpu.a, cpu.m8?8:16);
    goto L_048FBB;
L_048FBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBBu, 5u + 1u, 3u, cpu.address("absx", 0x1FC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FBB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1FC8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048FBE;
L_048FBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBEu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBEu, 6u, 3u, cpu.address("absy", 0x1FC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FBE STA
    hw.write(cpu.address("absy", 0x1FC8u), cpu.a, cpu.m8?8:16);
    goto L_048FC1;
L_048FC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FC1 TXA
    cpu.transfer("TXA");
    goto L_048FC2;
L_048FC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FC2 LSR
    cpu.lsrA();
    goto L_048FC3;
L_048FC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FC3 TAX
    cpu.transfer("TAX");
    goto L_048FC4;
L_048FC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC4u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FC4 EOR
    cpu.logicXor(0x2u);
    goto L_048FC7;
L_048FC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FC7 TAY
    cpu.transfer("TAY");
    goto L_048FC8;
L_048FC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC8u, 5u + 1u, 3u, cpu.address("absx", 0x1FBAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FC8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1FBAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048FCB;
L_048FCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCBu, 6u, 3u, cpu.address("absy", 0x1FBAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FCB STA
    hw.write(cpu.address("absy", 0x1FBAu), cpu.a, cpu.m8?8:16);
    goto L_048FCE;
L_048FCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCEu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FCE TXA
    cpu.transfer("TXA");
    goto L_048FCF;
L_048FCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FCF SEP
    cpu.sep(0x30u);
    goto L_048FD1;
L_048FD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FD1 LSR
    cpu.lsrA();
    goto L_048FD2;
L_048FD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FD2 TAX
    cpu.transfer("TAX");
    goto L_048FD3;
L_048FD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD3u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FD3 EOR
    cpu.logicXor(0x1u);
    goto L_048FD5;
L_048FD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FD5 TAY
    cpu.transfer("TAY");
    goto L_048FD6;
L_048FD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD6u, 4u + ((((0x1FB8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1FB8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FD6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1FB8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048FD9;
L_048FD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD9u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD9u, 5u, 3u, cpu.address("absy", 0x1FB8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FD9 STA
    hw.write(cpu.address("absy", 0x1FB8u), cpu.a, cpu.m8?8:16);
    goto L_048FDC;
L_048FDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDCu, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FDC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048FDF;
L_048FDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FDF CMP
    cpu.compareA(0xE0u);
    goto L_048FE1;
L_048FE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FE1 BNE -> $048FFB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_048FFB; }
    goto L_048FE3;
L_048FE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE3u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE3u, 6u, 3u, cpu.address("abs", 0x0DB1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FE3 DEC
    cpu.decMem(hw, cpu.address("abs", 0xDB1u), cpu.m8?8:16);
    goto L_048FE6;
L_048FE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FE6 BMI -> $048FE9
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_048FE9; }
    goto L_048FE8;
L_048FE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048FE8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x048FE8u);return;} hw.unresolvedReturn(0x048FE8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_048FE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE9u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE9u, 6u, 3u, cpu.address("abs", 0x13CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FE9 INC
    cpu.incMem(hw, cpu.address("abs", 0x13CAu), cpu.m8?8:16);
    goto L_048FEC;
L_048FEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FECu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FECu, 6u, 3u, cpu.address("abs", 0x9037u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048FEC JSR -> $049037 stack real
    { cpu.push16Value(hw,0x8FEEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8FEFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9037u), 0x048FECu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048FEF;
L_048FEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FEFu,0x048FEFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FEF LDA
    cpu.setA(0x2u, 8);
    goto L_048FF1;
L_048FF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF1u, 4u, 3u, cpu.address("abs", 0x0DB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FF1 STA
    hw.write(cpu.address("abs", 0xDB1u), cpu.a, cpu.m8?8:16);
    goto L_048FF4;
L_048FF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FF4 LDA
    cpu.setA(0x4u, 8);
    goto L_048FF6;
L_048FF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF6u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FF6 STA
    hw.write(cpu.address("abs", 0x13D9u), cpu.a, cpu.m8?8:16);
    goto L_048FF9;
L_048FF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FF9 BRA -> $049003
    goto L_049003;
L_048FFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFBu, 6u, 3u, cpu.address("abs", 0x13CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FFB INC
    cpu.incMem(hw, cpu.address("abs", 0x13CAu), cpu.m8?8:16);
    goto L_048FFE;
L_048FFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048FFE BRA -> $049003
    goto L_049003;
L_049000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049000 DEX
    cpu.decReg('X');
    goto L_049001;
L_049001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9001u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9001u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049001 BPL -> $048F8C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_048F8C; }
    goto L_049003;
L_049003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9003u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9003u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049003 REP
    cpu.rep(0x20u);
    goto L_049005;
L_049005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9005u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9005u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049005 STZ
    hw.write(cpu.address("dp", 0x6u), 0, cpu.m8?8:16);
    goto L_049007;
L_049007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9007u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9007u, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049007 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04900A;
L_04900A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au, 5u + ((((0x1F17u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04900A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04900D;
L_04900D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04900D LSR
    cpu.lsrA();
    goto L_04900E;
L_04900E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04900E LSR
    cpu.lsrA();
    goto L_04900F;
L_04900F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04900F LSR
    cpu.lsrA();
    goto L_049010;
L_049010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049010 LSR
    cpu.lsrA();
    goto L_049011;
L_049011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9011u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9011u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049011 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_049013;
L_049013:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9013u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9013u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9013u, 5u + ((((0x1F19u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049013 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049016;
L_049016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9016u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9016u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049016 LSR
    cpu.lsrA();
    goto L_049017;
L_049017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049017 LSR
    cpu.lsrA();
    goto L_049018;
L_049018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9018u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9018u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049018 LSR
    cpu.lsrA();
    goto L_049019;
L_049019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9019u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9019u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049019 LSR
    cpu.lsrA();
    goto L_04901A;
L_04901A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04901A STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04901C;
L_04901C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04901C TXA
    cpu.transfer("TXA");
    goto L_04901D;
L_04901D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04901D LSR
    cpu.lsrA();
    goto L_04901E;
L_04901E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04901E LSR
    cpu.lsrA();
    goto L_04901F;
L_04901F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04901F TAX
    cpu.transfer("TAX");
    goto L_049020;
L_049020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9020u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9020u, 6u, 3u, cpu.address("abs", 0x9885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049020 JSR -> $049885 stack real
    { cpu.push16Value(hw,0x9022u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9023u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9885u), 0x049020u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_049023;
L_049023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9023u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9023u,0x049023u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049023 REP
    cpu.rep(0x10u);
    goto L_049025;
L_049025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9025u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9025u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049025 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049027;
L_049027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9027u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9027u, 6u, 4u, ((0x7EC800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049027 LDA
    cpu.loadA(hw.readW(((0x7EC800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04902B;
L_04902B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04902B AND
    cpu.logicAnd(0xFFu);
    goto L_04902E;
L_04902E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Eu, 5u, 3u, cpu.address("abs", 0x13C1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04902E STA
    hw.write(cpu.address("abs", 0x13C1u), cpu.a, cpu.m8?8:16);
    goto L_049031;
L_049031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9031u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9031u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049031 SEP
    cpu.sep(0x30u);
    goto L_049033;
L_049033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u, 6u, 3u, cpu.address("abs", 0x13D9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049033 INC
    cpu.incMem(hw, cpu.address("abs", 0x13D9u), cpu.m8?8:16);
    goto L_049036;
L_049036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9036u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9036u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049036 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x049036u);return;} hw.unresolvedReturn(0x049036u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0582C8_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0582C8u: goto L_0582C8;
    case 0x0582CCu: goto L_0582CC;
    case 0x0582D0u: goto L_0582D0;
    case 0x0582D4u: goto L_0582D4;
    case 0x0582D8u: goto L_0582D8;
    case 0x0582DCu: goto L_0582DC;
    case 0x0582E0u: goto L_0582E0;
    case 0x0582E4u: goto L_0582E4;
    case 0x0582E8u: goto L_0582E8;
    case 0x0582ECu: goto L_0582EC;
    case 0x0582F0u: goto L_0582F0;
    case 0x0582F4u: goto L_0582F4;
    case 0x0582F8u: goto L_0582F8;
    case 0x0582FCu: goto L_0582FC;
    case 0x058300u: goto L_058300;
    case 0x058304u: goto L_058304;
    case 0x058308u: goto L_058308;
    case 0x05830Cu: goto L_05830C;
    case 0x058310u: goto L_058310;
    case 0x058314u: goto L_058314;
    case 0x058318u: goto L_058318;
    case 0x05831Cu: goto L_05831C;
    case 0x058320u: goto L_058320;
    case 0x058324u: goto L_058324;
    case 0x058328u: goto L_058328;
    case 0x05832Cu: goto L_05832C;
    case 0x058330u: goto L_058330;
    case 0x058334u: goto L_058334;
    case 0x058338u: goto L_058338;
    case 0x058339u: goto L_058339;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0582C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C8u, 5u, 4u, ((0x7EC800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0582C8 STA
    hw.write(((0x7EC800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0582CC;
L_0582CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CCu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CCu, 5u, 4u, ((0x7ECA00u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0582CC STA
    hw.write(((0x7ECA00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0582D0;
L_0582D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D0u, 5u, 4u, ((0x7ECC00u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0582D0 STA
    hw.write(((0x7ECC00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0582D4;
L_0582D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D4u, 5u, 4u, ((0x7ECE00u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0582D4 STA
    hw.write(((0x7ECE00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0582D8;
L_0582D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D8u, 5u, 4u, ((0x7ED000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0582D8 STA
    hw.write(((0x7ED000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0582DC;
L_0582DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DCu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DCu, 5u, 4u, ((0x7ED200u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0582DC STA
    hw.write(((0x7ED200u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0582E0;
L_0582E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u, 5u, 4u, ((0x7ED400u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0582E0 STA
    hw.write(((0x7ED400u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0582E4;
L_0582E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E4u, 5u, 4u, ((0x7ED600u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0582E4 STA
    hw.write(((0x7ED600u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0582E8;
L_0582E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E8u, 5u, 4u, ((0x7ED800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0582E8 STA
    hw.write(((0x7ED800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0582EC;
L_0582EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82ECu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82ECu, 5u, 4u, ((0x7EDA00u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0582EC STA
    hw.write(((0x7EDA00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0582F0;
L_0582F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F0u, 5u, 4u, ((0x7EDC00u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0582F0 STA
    hw.write(((0x7EDC00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0582F4;
L_0582F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F4u, 5u, 4u, ((0x7EDE00u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0582F4 STA
    hw.write(((0x7EDE00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0582F8;
L_0582F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F8u, 5u, 4u, ((0x7EE000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0582F8 STA
    hw.write(((0x7EE000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0582FC;
L_0582FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu, 5u, 4u, ((0x7EE200u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0582FC STA
    hw.write(((0x7EE200u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_058300;
L_058300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8300u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8300u, 5u, 4u, ((0x7EE400u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058300 STA
    hw.write(((0x7EE400u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_058304;
L_058304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8304u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8304u, 5u, 4u, ((0x7EE600u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058304 STA
    hw.write(((0x7EE600u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_058308;
L_058308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8308u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8308u, 5u, 4u, ((0x7EE800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058308 STA
    hw.write(((0x7EE800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05830C;
L_05830C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Cu, 5u, 4u, ((0x7EEA00u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05830C STA
    hw.write(((0x7EEA00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_058310;
L_058310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8310u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8310u, 5u, 4u, ((0x7EEC00u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058310 STA
    hw.write(((0x7EEC00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_058314;
L_058314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8314u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8314u, 5u, 4u, ((0x7EEE00u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058314 STA
    hw.write(((0x7EEE00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_058318;
L_058318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8318u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8318u, 5u, 4u, ((0x7EF000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058318 STA
    hw.write(((0x7EF000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05831C;
L_05831C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu, 5u, 4u, ((0x7EF200u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05831C STA
    hw.write(((0x7EF200u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_058320;
L_058320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8320u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8320u, 5u, 4u, ((0x7EF400u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058320 STA
    hw.write(((0x7EF400u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_058324;
L_058324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u, 5u, 4u, ((0x7EF600u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058324 STA
    hw.write(((0x7EF600u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_058328;
L_058328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8328u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8328u, 5u, 4u, ((0x7EF800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058328 STA
    hw.write(((0x7EF800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05832C;
L_05832C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Cu, 5u, 4u, ((0x7EFA00u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05832C STA
    hw.write(((0x7EFA00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_058330;
L_058330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8330u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8330u, 5u, 4u, ((0x7EFC00u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058330 STA
    hw.write(((0x7EFC00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_058334;
L_058334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8334u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8334u, 5u, 4u, ((0x7EFE00u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058334 STA
    hw.write(((0x7EFE00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_058338;
L_058338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8338u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8338u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058338 INX
    cpu.inc('X');
    goto L_058339;
L_058339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8339u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8339u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $058339 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x058339u);return;} hw.unresolvedReturn(0x058339u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0583AC_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0583ACu: goto L_0583AC;
    case 0x0583ADu: goto L_0583AD;
    case 0x0583AFu: goto L_0583AF;
    case 0x0583B2u: goto L_0583B2;
    case 0x0583B5u: goto L_0583B5;
    case 0x0583B8u: goto L_0583B8;
    case 0x0583BBu: goto L_0583BB;
    case 0x0583BDu: goto L_0583BD;
    case 0x0583BFu: goto L_0583BF;
    case 0x0583C1u: goto L_0583C1;
    case 0x0583C3u: goto L_0583C3;
    case 0x0583C5u: goto L_0583C5;
    case 0x0583C7u: goto L_0583C7;
    case 0x0583C9u: goto L_0583C9;
    case 0x0583CBu: goto L_0583CB;
    case 0x0583CDu: goto L_0583CD;
    case 0x0583CFu: goto L_0583CF;
    case 0x0583D2u: goto L_0583D2;
    case 0x0583D4u: goto L_0583D4;
    case 0x0583D7u: goto L_0583D7;
    case 0x0583D9u: goto L_0583D9;
    case 0x0583DBu: goto L_0583DB;
    case 0x0583DDu: goto L_0583DD;
    case 0x0583DFu: goto L_0583DF;
    case 0x0583E1u: goto L_0583E1;
    case 0x0583E3u: goto L_0583E3;
    case 0x0583E5u: goto L_0583E5;
    case 0x0583E7u: goto L_0583E7;
    case 0x0583E9u: goto L_0583E9;
    case 0x0583EBu: goto L_0583EB;
    case 0x0583EDu: goto L_0583ED;
    case 0x0583EFu: goto L_0583EF;
    case 0x0583F1u: goto L_0583F1;
    case 0x0583F4u: goto L_0583F4;
    case 0x0583F7u: goto L_0583F7;
    case 0x0583F9u: goto L_0583F9;
    case 0x0583FBu: goto L_0583FB;
    case 0x0583FDu: goto L_0583FD;
    case 0x0583FEu: goto L_0583FE;
    case 0x058400u: goto L_058400;
    case 0x058402u: goto L_058402;
    case 0x058404u: goto L_058404;
    case 0x058406u: goto L_058406;
    case 0x058408u: goto L_058408;
    case 0x05840Au: goto L_05840A;
    case 0x05840Cu: goto L_05840C;
    case 0x05840Fu: goto L_05840F;
    case 0x058412u: goto L_058412;
    case 0x058415u: goto L_058415;
    case 0x058416u: goto L_058416;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0583AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ACu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ACu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0583AC PHP
    cpu.push("PHP", hw);
    goto L_0583AD;
L_0583AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583AD SEP
    cpu.sep(0x30u);
    goto L_0583AF;
L_0583AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu, 4u, 3u, cpu.address("abs", 0x1933u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583AF STZ
    hw.write(cpu.address("abs", 0x1933u), 0, cpu.m8?8:16);
    goto L_0583B2;
L_0583B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u, 6u, 3u, cpu.address("abs", 0x84E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0583B2 JSR -> $0584E3 stack real
    { cpu.push16Value(hw,0x83B4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83B5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x84E3u), 0x0583B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0583B5;
L_0583B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83B5u,0x0583B5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u, 6u, 3u, cpu.address("abs", 0x81FBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0583B5 JSR -> $0581FB stack real
    { cpu.push16Value(hw,0x83B7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83B8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x81FBu), 0x0583B5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0583B8;
L_0583B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83B8u,0x0583B8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B8u, 4u, 3u, cpu.address("abs", 0x1925u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583B8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1925u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0583BB;
L_0583BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583BB CMP
    cpu.compareA(0x9u);
    goto L_0583BD;
L_0583BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583BD BEQ -> $058412
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_058412; }
    goto L_0583BF;
L_0583BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583BF CMP
    cpu.compareA(0xBu);
    goto L_0583C1;
L_0583C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583C1 BEQ -> $058412
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_058412; }
    goto L_0583C3;
L_0583C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583C3 CMP
    cpu.compareA(0x10u);
    goto L_0583C5;
L_0583C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583C5 BEQ -> $058412
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_058412; }
    goto L_0583C7;
L_0583C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583C7 LDY
    cpu.setY(0x0u, 8);
    goto L_0583C9;
L_0583C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $0583C9 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0583CB;
L_0583CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583CB CMP
    cpu.compareA(0xFFu);
    goto L_0583CD;
L_0583CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583CD BEQ -> $0583D2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0583D2; }
    goto L_0583CF;
L_0583CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu, 6u, 3u, cpu.address("abs", 0x85FFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0583CF JSR -> $0585FF stack real
    { cpu.push16Value(hw,0x83D1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83D2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85FFu), 0x0583CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0583D2;
L_0583D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583D2 SEP
    cpu.sep(0x30u);
    goto L_0583D4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583D2 SEP
    cpu.sep(0x30u);
    goto L_0583D4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83D2u,0x0583D2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0583D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D4u, 4u, 3u, cpu.address("abs", 0x1925u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583D4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1925u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0583D7;
L_0583D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583D7 BEQ -> $058412
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_058412; }
    goto L_0583D9;
L_0583D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583D9 CMP
    cpu.compareA(0xAu);
    goto L_0583DB;
L_0583DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583DB BEQ -> $058412
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_058412; }
    goto L_0583DD;
L_0583DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583DD CMP
    cpu.compareA(0xCu);
    goto L_0583DF;
L_0583DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583DF BEQ -> $058412
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_058412; }
    goto L_0583E1;
L_0583E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583E1 CMP
    cpu.compareA(0xDu);
    goto L_0583E3;
L_0583E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583E3 BEQ -> $058412
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_058412; }
    goto L_0583E5;
L_0583E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583E5 CMP
    cpu.compareA(0xEu);
    goto L_0583E7;
L_0583E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583E7 BEQ -> $058412
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_058412; }
    goto L_0583E9;
L_0583E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583E9 CMP
    cpu.compareA(0x11u);
    goto L_0583EB;
L_0583EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583EB BEQ -> $058412
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_058412; }
    goto L_0583ED;
L_0583ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583ED CMP
    cpu.compareA(0x1Eu);
    goto L_0583EF;
L_0583EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583EF BEQ -> $058412
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_058412; }
    goto L_0583F1;
L_0583F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F1u, 6u, 3u, cpu.address("abs", 0x1933u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583F1 INC
    cpu.incMem(hw, cpu.address("abs", 0x1933u), cpu.m8?8:16);
    goto L_0583F4;
L_0583F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F4u, 4u, 3u, cpu.address("abs", 0x1933u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583F4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1933u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0583F7;
L_0583F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583F7 CMP
    cpu.compareA(0x2u);
    goto L_0583F9;
L_0583F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583F9 BEQ -> $058412
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_058412; }
    goto L_0583FB;
L_0583FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x68u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x68u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0583FD;
L_0583FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583FD CLC
    cpu.setFlag('C', false);
    goto L_0583FE;
L_0583FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0583FE ADC
    cpu.adc(0x5u);
    goto L_058400;
L_058400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8400u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8400u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058400 STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_058402;
L_058402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8402u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8402u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058402 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x69u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058404;
L_058404:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8404u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8404u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8404u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058404 ADC
    cpu.adc(0x0u);
    goto L_058406;
L_058406:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8406u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8406u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8406u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058406 STA
    hw.write(cpu.address("dp", 0x66u), cpu.a, cpu.m8?8:16);
    goto L_058408;
L_058408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8408u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8408u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058408 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05840A;
L_05840A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05840A STA
    hw.write(cpu.address("dp", 0x67u), cpu.a, cpu.m8?8:16);
    goto L_05840C;
L_05840C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Cu, 4u, 3u, cpu.address("abs", 0x1928u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05840C STZ
    hw.write(cpu.address("abs", 0x1928u), 0, cpu.m8?8:16);
    goto L_05840F;
L_05840F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu, 3u, 3u, cpu.address("abs", 0x83B8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05840F JMP -> $0583B8
    goto L_0583B8;
L_058412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8412u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8412u, 4u, 3u, cpu.address("abs", 0x1933u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058412 STZ
    hw.write(cpu.address("abs", 0x1933u), 0, cpu.m8?8:16);
    goto L_058415;
L_058415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8415u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8415u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058415 PLP
    cpu.pop("PLP", hw);
    goto L_058416;
L_058416:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8416u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8416u,0x058416u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8416u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8416u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $058416 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x058416u);return;} hw.unresolvedReturn(0x058416u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DA7E7_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA7E7u: goto L_0DA7E7;
    case 0x0DA7E9u: goto L_0DA7E9;
    case 0x0DA7EBu: goto L_0DA7EB;
    case 0x0DA7EEu: goto L_0DA7EE;
    case 0x0DA7F1u: goto L_0DA7F1;
    case 0x0DA7F5u: goto L_0DA7F5;
    case 0x0DA7F8u: goto L_0DA7F8;
    case 0x0DA7F9u: goto L_0DA7F9;
    case 0x0DA7FAu: goto L_0DA7FA;
    case 0x0DA7FCu: goto L_0DA7FC;
    case 0x0DA7FEu: goto L_0DA7FE;
    case 0x0DA801u: goto L_0DA801;
    case 0x0DA804u: goto L_0DA804;
    case 0x0DA806u: goto L_0DA806;
    case 0x0DA808u: goto L_0DA808;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA7E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E7u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7E7 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DA7E9;
L_0DA7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7E9 LDX
    cpu.setX(0x0u, 8);
    goto L_0DA7EB;
L_0DA7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EBu, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA7EB JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xA7EDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7EEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DA7EBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA7EE;
L_0DA7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EEu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA7EE JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xA7F0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7F1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DA7EEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA7F1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EEu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA7EE JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xA7F0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7F1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DA7EEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA7F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7EEu,0x0DA7EEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DA7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F1u, 5u, 4u, ((0x0DA7E3u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7F1 LDA
    cpu.loadA(hw.readW(((0xDA7E3u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA7F5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F1u, 5u, 4u, ((0x0DA7E3u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7F1 LDA
    cpu.loadA(hw.readW(((0xDA7E3u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA7F5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7F1u,0x0DA7F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DA7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA7F5 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xA7F7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7F8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DA7F5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA7F8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA7F5 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xA7F7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7F8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DA7F5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA7F8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7F5u,0x0DA7F5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DA7F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7F8 INX
    cpu.inc('X');
    goto L_0DA7F9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7F8 INX
    cpu.inc('X');
    goto L_0DA7F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7F8u,0x0DA7F8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DA7F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F9u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7F9 TXA
    cpu.transfer("TXA");
    goto L_0DA7FA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F9u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7F9 TXA
    cpu.transfer("TXA");
    goto L_0DA7FA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7F9u,0x0DA7F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DA7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7FA AND
    cpu.logicAnd(0x1u);
    goto L_0DA7FC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7FA AND
    cpu.logicAnd(0x1u);
    goto L_0DA7FC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7FAu,0x0DA7FAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DA7FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7FC BNE -> $0DA7EE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA7EE; }
    goto L_0DA7FE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7FC BNE -> $0DA7EE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA7EE; }
    goto L_0DA7FE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7FCu,0x0DA7FCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DA7FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FEu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA7FE JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xA800u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA801u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DA7FEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA801;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FEu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA7FE JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xA800u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA801u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DA7FEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA801;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7FEu,0x0DA7FEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DA801:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA801u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA801u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA801u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA801 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xA803u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA804u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DA801u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA804;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA801u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA801u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA801 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xA803u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA804u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DA801u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA804;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA801u,0x0DA801u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DA804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA804u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA804u,0x0DA804u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA804u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA804u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA804 CPX
    cpu.compareX(0x4u);
    goto L_0DA806;
L_0DA806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA806u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA806u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA806 BNE -> $0DA7EE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA7EE; }
    goto L_0DA808;
L_0DA808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA808u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA808u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA808 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA808u);return;} hw.unresolvedReturn(0x0DA808u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DA7E7_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA7E7u: goto L_0DA7E7;
    case 0x0DA7E9u: goto L_0DA7E9;
    case 0x0DA7EBu: goto L_0DA7EB;
    case 0x0DA7EEu: goto L_0DA7EE;
    case 0x0DA7F1u: goto L_0DA7F1;
    case 0x0DA7F5u: goto L_0DA7F5;
    case 0x0DA7F8u: goto L_0DA7F8;
    case 0x0DA7F9u: goto L_0DA7F9;
    case 0x0DA7FAu: goto L_0DA7FA;
    case 0x0DA7FCu: goto L_0DA7FC;
    case 0x0DA7FEu: goto L_0DA7FE;
    case 0x0DA801u: goto L_0DA801;
    case 0x0DA804u: goto L_0DA804;
    case 0x0DA806u: goto L_0DA806;
    case 0x0DA808u: goto L_0DA808;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA7E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E7u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7E7 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DA7E9;
L_0DA7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7E9 LDX
    cpu.setX(0x0u, 8);
    goto L_0DA7EB;
L_0DA7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EBu, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA7EB JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xA7EDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7EEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DA7EBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA7EE;
L_0DA7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7EEu,0x0DA7EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EEu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA7EE JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xA7F0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7F1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DA7EEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA7F1;
L_0DA7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7F1u,0x0DA7F1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F1u, 5u, 4u, ((0x0DA7E3u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7F1 LDA
    cpu.loadA(hw.readW(((0xDA7E3u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA7F5;
L_0DA7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA7F5 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xA7F7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7F8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DA7F5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA7F8;
L_0DA7F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7F8u,0x0DA7F8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7F8 INX
    cpu.inc('X');
    goto L_0DA7F9;
L_0DA7F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F9u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7F9 TXA
    cpu.transfer("TXA");
    goto L_0DA7FA;
L_0DA7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7FA AND
    cpu.logicAnd(0x1u);
    goto L_0DA7FC;
L_0DA7FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA7FC BNE -> $0DA7EE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA7EE; }
    goto L_0DA7FE;
L_0DA7FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FEu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA7FE JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xA800u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA801u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DA7FEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA801;
L_0DA801:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA801u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA801u,0x0DA801u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA801u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA801u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA801 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xA803u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA804u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DA801u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA804;
L_0DA804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA804u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA804u,0x0DA804u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA804u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA804u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA804 CPX
    cpu.compareX(0x4u);
    goto L_0DA806;
L_0DA806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA806u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA806u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA806 BNE -> $0DA7EE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA7EE; }
    goto L_0DA808;
L_0DA808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA808u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA808u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA808 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA808u);return;} hw.unresolvedReturn(0x0DA808u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DC44F_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DC44Fu: goto L_0DC44F;
    case 0x0DC451u: goto L_0DC451;
    case 0x0DC453u: goto L_0DC453;
    case 0x0DC454u: goto L_0DC454;
    case 0x0DC455u: goto L_0DC455;
    case 0x0DC456u: goto L_0DC456;
    case 0x0DC457u: goto L_0DC457;
    case 0x0DC459u: goto L_0DC459;
    case 0x0DC45Bu: goto L_0DC45B;
    case 0x0DC45Du: goto L_0DC45D;
    case 0x0DC45Eu: goto L_0DC45E;
    case 0x0DC461u: goto L_0DC461;
    case 0x0DC465u: goto L_0DC465;
    case 0x0DC467u: goto L_0DC467;
    case 0x0DC46Au: goto L_0DC46A;
    case 0x0DC46Cu: goto L_0DC46C;
    case 0x0DC46Eu: goto L_0DC46E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DC44F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC44Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC44F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DC451;
L_0DC451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC451u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC451u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC451 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DC453;
L_0DC453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC453u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC453u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC453 LSR
    cpu.lsrA();
    goto L_0DC454;
L_0DC454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC454u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC454u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC454u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC454 LSR
    cpu.lsrA();
    goto L_0DC455;
L_0DC455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC455u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC455u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC455 LSR
    cpu.lsrA();
    goto L_0DC456;
L_0DC456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC456u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC456u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC456 LSR
    cpu.lsrA();
    goto L_0DC457;
L_0DC457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC457u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC457u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC457u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC457 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DC459;
L_0DC459:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC459u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC459u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC459u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC459 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DC45B;
L_0DC45B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC45Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC45B AND
    cpu.logicAnd(0xFu);
    goto L_0DC45D;
L_0DC45D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC45Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC45D TAX
    cpu.transfer("TAX");
    goto L_0DC45E;
L_0DC45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Eu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC45E JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xC460u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC461u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DC45Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC461;
L_0DC461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC461u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC461u,0x0DC461u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC461u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC461u, 5u, 4u, ((0x0DC44Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC461 LDA
    cpu.loadA(hw.readW(((0xDC44Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DC465;
L_0DC465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC465u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC465u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DC465 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DC467;
L_0DC467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC467u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC467u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC467 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xC469u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC46Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DC467u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC46A;
L_0DC46A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC46Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC46Au,0x0DC46Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC46Au,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC46Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC46A DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DC46C;
L_0DC46C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC46Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC46Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC46Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC46C BPL -> $0DC45E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DC45E; }
    goto L_0DC46E;
L_0DC46E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC46Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC46Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC46Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC46E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DC46Eu);return;} hw.unresolvedReturn(0x0DC46Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DC5D8_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DC5D8u: goto L_0DC5D8;
    case 0x0DC5DAu: goto L_0DC5DA;
    case 0x0DC5DCu: goto L_0DC5DC;
    case 0x0DC5DDu: goto L_0DC5DD;
    case 0x0DC5DEu: goto L_0DC5DE;
    case 0x0DC5DFu: goto L_0DC5DF;
    case 0x0DC5E0u: goto L_0DC5E0;
    case 0x0DC5E2u: goto L_0DC5E2;
    case 0x0DC5E5u: goto L_0DC5E5;
    case 0x0DC5E8u: goto L_0DC5E8;
    case 0x0DC5EAu: goto L_0DC5EA;
    case 0x0DC5EDu: goto L_0DC5ED;
    case 0x0DC5F0u: goto L_0DC5F0;
    case 0x0DC5F2u: goto L_0DC5F2;
    case 0x0DC5F4u: goto L_0DC5F4;
    case 0x0DC5F7u: goto L_0DC5F7;
    case 0x0DC5FAu: goto L_0DC5FA;
    case 0x0DC5FCu: goto L_0DC5FC;
    case 0x0DC5FFu: goto L_0DC5FF;
    case 0x0DC602u: goto L_0DC602;
    case 0x0DC604u: goto L_0DC604;
    case 0x0DC606u: goto L_0DC606;
    case 0x0DC609u: goto L_0DC609;
    case 0x0DC60Cu: goto L_0DC60C;
    case 0x0DC60Eu: goto L_0DC60E;
    case 0x0DC610u: goto L_0DC610;
    case 0x0DC613u: goto L_0DC613;
    case 0x0DC615u: goto L_0DC615;
    case 0x0DC618u: goto L_0DC618;
    case 0x0DC61Bu: goto L_0DC61B;
    case 0x0DC61Du: goto L_0DC61D;
    case 0x0DC61Fu: goto L_0DC61F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DC5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D8u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC5D8 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DC5DA;
L_0DC5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC5DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DC5DC;
L_0DC5DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DCu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC5DC LSR
    cpu.lsrA();
    goto L_0DC5DD;
L_0DC5DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC5DD LSR
    cpu.lsrA();
    goto L_0DC5DE;
L_0DC5DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC5DE LSR
    cpu.lsrA();
    goto L_0DC5DF;
L_0DC5DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC5DF LSR
    cpu.lsrA();
    goto L_0DC5E0;
L_0DC5E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC5E0 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DC5E2;
L_0DC5E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E2u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC5E2 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xC5E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC5E5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DC5E2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC5E5;
L_0DC5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5E5u,0x0DC5E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E5u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC5E5 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xC5E7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC5E8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DC5E5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC5E8;
L_0DC5E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5E8u,0x0DC5E8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC5E8 LDA
    cpu.setA(0x33u, 8);
    goto L_0DC5EA;
L_0DC5EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EAu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC5EA JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC5ECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC5EDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC5EAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC5ED;
L_0DC5ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5EDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5EDu,0x0DC5EDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EDu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC5ED JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xC5EFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC5F0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DC5EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC5F0;
L_0DC5F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5F0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5F0u,0x0DC5F0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC5F0 LDA
    cpu.setA(0x34u, 8);
    goto L_0DC5F2;
L_0DC5F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F2u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F2u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DC5F2 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DC5F4;
L_0DC5F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F4u, 3u, 3u, cpu.address("abs", 0xC606u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC5F4 JMP -> $0DC606
    goto L_0DC606;
L_0DC5F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F7u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC5F7 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xC5F9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC5FAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DC5F7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC5FA;
L_0DC5FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5FAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5FAu,0x0DC5FAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5FAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC5FA LDA
    cpu.setA(0x9Du, 8);
    goto L_0DC5FC;
L_0DC5FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5FCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5FCu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC5FC JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC5FEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC5FFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC5FCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC5FF;
L_0DC5FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5FFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC5FFu,0x0DC5FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5FFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5FFu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC5FF JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xC601u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC602u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DC5FFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC602;
L_0DC602:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC602u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC602u,0x0DC602u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC602u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC602u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC602 LDA
    cpu.setA(0x9Eu, 8);
    goto L_0DC604;
L_0DC604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC604u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC604u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC604u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DC604 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DC606;
L_0DC606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC606u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC606u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC606 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xC608u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC609u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DC606u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC609;
L_0DC609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC609u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC609u,0x0DC609u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC609u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC609u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC609 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xC60Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC60Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DC609u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC60C;
L_0DC60C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC60Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC60Cu,0x0DC60Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC60Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC60Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC60C DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DC60E;
L_0DC60E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC60Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC60Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC60Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC60E BNE -> $0DC5F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DC5F7; }
    goto L_0DC610;
L_0DC610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC610u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC610u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC610 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xC612u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC613u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DC610u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC613;
L_0DC613:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC613u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC613u,0x0DC613u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC613u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC613u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC613 LDA
    cpu.setA(0x33u, 8);
    goto L_0DC615;
L_0DC615:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC615u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC615u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC615u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC615 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC617u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC618u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC615u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC618;
L_0DC618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC618u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC618u,0x0DC618u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC618u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC618u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC618 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xC61Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC61Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DC618u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC61B;
L_0DC61B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC61Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC61Bu,0x0DC61Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC61Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC61Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC61B LDA
    cpu.setA(0x34u, 8);
    goto L_0DC61D;
L_0DC61D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC61Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC61Du,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC61Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DC61D STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DC61F;
L_0DC61F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC61Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC61Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC61Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC61F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DC61Fu);return;} hw.unresolvedReturn(0x0DC61Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DE135_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DE135u: goto L_0DE135;
    case 0x0DE137u: goto L_0DE137;
    case 0x0DE139u: goto L_0DE139;
    case 0x0DE13Bu: goto L_0DE13B;
    case 0x0DE13Du: goto L_0DE13D;
    case 0x0DE13Fu: goto L_0DE13F;
    case 0x0DE140u: goto L_0DE140;
    case 0x0DE141u: goto L_0DE141;
    case 0x0DE142u: goto L_0DE142;
    case 0x0DE143u: goto L_0DE143;
    case 0x0DE145u: goto L_0DE145;
    case 0x0DE148u: goto L_0DE148;
    case 0x0DE14Au: goto L_0DE14A;
    case 0x0DE14Cu: goto L_0DE14C;
    case 0x0DE14Eu: goto L_0DE14E;
    case 0x0DE151u: goto L_0DE151;
    case 0x0DE155u: goto L_0DE155;
    case 0x0DE158u: goto L_0DE158;
    case 0x0DE15Bu: goto L_0DE15B;
    case 0x0DE15Eu: goto L_0DE15E;
    case 0x0DE162u: goto L_0DE162;
    case 0x0DE165u: goto L_0DE165;
    case 0x0DE167u: goto L_0DE167;
    case 0x0DE169u: goto L_0DE169;
    case 0x0DE16Cu: goto L_0DE16C;
    case 0x0DE170u: goto L_0DE170;
    case 0x0DE172u: goto L_0DE172;
    case 0x0DE175u: goto L_0DE175;
    case 0x0DE178u: goto L_0DE178;
    case 0x0DE17Au: goto L_0DE17A;
    case 0x0DE17Cu: goto L_0DE17C;
    case 0x0DE17Eu: goto L_0DE17E;
    case 0x0DE180u: goto L_0DE180;
    case 0x0DE182u: goto L_0DE182;
    case 0x0DE185u: goto L_0DE185;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DE135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE135u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE135u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE135u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE135 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DE137;
L_0DE137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE137u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE137u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE137 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DE139;
L_0DE139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE139u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE139u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE139 AND
    cpu.logicAnd(0xFu);
    goto L_0DE13B;
L_0DE13B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE13Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE13Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE13Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE13B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DE13D;
L_0DE13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE13Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE13Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE13Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE13D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DE13F;
L_0DE13F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE13Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE13Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE13Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE13F LSR
    cpu.lsrA();
    goto L_0DE140;
L_0DE140:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE140u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE140u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE140u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE140 LSR
    cpu.lsrA();
    goto L_0DE141;
L_0DE141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE141u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE141u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE141 LSR
    cpu.lsrA();
    goto L_0DE142;
L_0DE142:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE142u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE142u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE142u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE142 LSR
    cpu.lsrA();
    goto L_0DE143;
L_0DE143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE143u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE143u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE143 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DE145;
L_0DE145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE145u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE145u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE145 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xE147u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE148u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DE145u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE148;
L_0DE148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE148u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE148u,0x0DE148u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE148u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE148u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE148 LDX
    cpu.setX(0x0u, 8);
    goto L_0DE14A;
L_0DE14A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE14Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE14Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE14Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE14A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DE14C;
L_0DE14C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE14Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE14Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE14Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE14C STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DE14E;
L_0DE14E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE14Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE14Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE14Eu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE14E JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xE150u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE151u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DE14Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE151;
L_0DE151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE151u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE151u,0x0DE151u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE151u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE151u, 5u, 4u, ((0x0DE12Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE151 LDA
    cpu.loadA(hw.readW(((0xDE12Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DE155;
L_0DE155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE155u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE155u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE155 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xE157u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE158u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DE155u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE158;
L_0DE158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE158u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE158u,0x0DE158u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE158u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE158u, 3u, 3u, cpu.address("abs", 0xE165u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE158 JMP -> $0DE165
    goto L_0DE165;
L_0DE15B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE15Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Bu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE15B JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xE15Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE15Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DE15Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE15E;
L_0DE15E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE15Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE15Eu,0x0DE15Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Eu, 5u, 4u, ((0x0DE12Fu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE15E LDA
    cpu.loadA(hw.readW(((0xDE12Fu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DE162;
L_0DE162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE162u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE162u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE162 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xE164u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE165u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DE162u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE165;
L_0DE165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE165u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE165u,0x0DE165u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE165u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE165u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE165 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DE167;
L_0DE167:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE167u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE167u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE167u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE167 BNE -> $0DE15B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DE15B; }
    goto L_0DE169;
L_0DE169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE169u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE169u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE169u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE169 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xE16Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE16Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DE169u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE16C;
L_0DE16C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE16Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE16Cu,0x0DE16Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE16Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE16Cu, 5u, 4u, ((0x0DE132u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE16C LDA
    cpu.loadA(hw.readW(((0xDE132u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DE170;
L_0DE170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE170u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE170u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DE170 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DE172;
L_0DE172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE172u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE172u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE172 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xE174u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE175u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DE172u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE175;
L_0DE175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE175u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE175u,0x0DE175u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE175u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE175u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE175 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xE177u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE178u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DE175u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE178;
L_0DE178:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE178u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE178u,0x0DE178u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE178u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE178u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE178 LDX
    cpu.setX(0x1u, 8);
    goto L_0DE17A;
L_0DE17A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE17Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE17Au,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE17Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE17A DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DE17C;
L_0DE17C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE17Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE17Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE17Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE17C BMI -> $0DE185
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DE185; }
    goto L_0DE17E;
L_0DE17E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE17Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE17Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE17Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE17E BNE -> $0DE182
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DE182; }
    goto L_0DE180;
L_0DE180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE180u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE180u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE180 LDX
    cpu.setX(0x2u, 8);
    goto L_0DE182;
L_0DE182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE182u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE182u, 3u, 3u, cpu.address("abs", 0xE14Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE182 JMP -> $0DE14A
    goto L_0DE14A;
L_0DE185:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE185u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE185u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE185u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE185 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DE185u);return;} hw.unresolvedReturn(0x0DE185u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DEF45_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DEF45u: goto L_0DEF45;
    case 0x0DEF47u: goto L_0DEF47;
    case 0x0DEF49u: goto L_0DEF49;
    case 0x0DEF4Bu: goto L_0DEF4B;
    case 0x0DEF4Cu: goto L_0DEF4C;
    case 0x0DEF4Fu: goto L_0DEF4F;
    case 0x0DEF51u: goto L_0DEF51;
    case 0x0DEF54u: goto L_0DEF54;
    case 0x0DEF57u: goto L_0DEF57;
    case 0x0DEF59u: goto L_0DEF59;
    case 0x0DEF5Cu: goto L_0DEF5C;
    case 0x0DEF5Du: goto L_0DEF5D;
    case 0x0DEF5Fu: goto L_0DEF5F;
    case 0x0DEF62u: goto L_0DEF62;
    case 0x0DEF64u: goto L_0DEF64;
    case 0x0DEF66u: goto L_0DEF66;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DEF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEF45 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DEF47;
L_0DEF47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF47u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF47u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEF47 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DEF49;
L_0DEF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF49u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF49u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEF49 AND
    cpu.logicAnd(0xFu);
    goto L_0DEF4B;
L_0DEF4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEF4B TAX
    cpu.transfer("TAX");
    goto L_0DEF4C;
L_0DEF4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Cu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEF4C JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xEF4Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF4Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DEF4Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEF4F;
L_0DEF4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF4Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF4Fu,0x0DEF4Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEF4F LDA
    cpu.setA(0xA0u, 8);
    goto L_0DEF51;
L_0DEF51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF51u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF51u, 3u, 3u, cpu.address("abs", 0xEF59u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEF51 JMP -> $0DEF59
    goto L_0DEF59;
L_0DEF54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEF54 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xEF56u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF57u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DEF54u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEF57;
L_0DEF57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF57u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF57u,0x0DEF57u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF57u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEF57 LDA
    cpu.setA(0xA1u, 8);
    goto L_0DEF59;
L_0DEF59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF59u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF59u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEF59 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xEF5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF5Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DEF59u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEF5C;
L_0DEF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF5Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF5Cu,0x0DEF5Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEF5C DEX
    cpu.decReg('X');
    goto L_0DEF5D;
L_0DEF5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEF5D BNE -> $0DEF54
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DEF54; }
    goto L_0DEF5F;
L_0DEF5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Fu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEF5F JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xEF61u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF62u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DEF5Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEF62;
L_0DEF62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF62u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF62u,0x0DEF62u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEF62 LDA
    cpu.setA(0xA2u, 8);
    goto L_0DEF64;
L_0DEF64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF64u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF64u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DEF64 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DEF66;
L_0DEF66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF66u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF66u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEF66 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DEF66u);return;} hw.unresolvedReturn(0x0DEF66u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A77C_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A77Cu: goto L_B1A77C;
    case 0xB1A77Eu: goto L_B1A77E;
    case 0xB1A780u: goto L_B1A780;
    case 0xB1A782u: goto L_B1A782;
    case 0xB1A785u: goto L_B1A785;
    case 0xB1A787u: goto L_B1A787;
    case 0xB1A78Au: goto L_B1A78A;
    case 0xB1A78Du: goto L_B1A78D;
    case 0xB1A78Fu: goto L_B1A78F;
    case 0xB1A791u: goto L_B1A791;
    case 0xB1A794u: goto L_B1A794;
    case 0xB1A796u: goto L_B1A796;
    case 0xB1A799u: goto L_B1A799;
    case 0xB1A79Cu: goto L_B1A79C;
    case 0xB1A79Du: goto L_B1A79D;
    case 0xB1A79Fu: goto L_B1A79F;
    case 0xB1A7A1u: goto L_B1A7A1;
    case 0xB1A7A2u: goto L_B1A7A2;
    case 0xB1A7A5u: goto L_B1A7A5;
    case 0xB1A7A7u: goto L_B1A7A7;
    case 0xB1A7AAu: goto L_B1A7AA;
    case 0xB1A7ADu: goto L_B1A7AD;
    case 0xB1A7AFu: goto L_B1A7AF;
    case 0xB1A7B2u: goto L_B1A7B2;
    case 0xB1A7B4u: goto L_B1A7B4;
    case 0xB1A7B7u: goto L_B1A7B7;
    case 0xB1A7B8u: goto L_B1A7B8;
    case 0xB1A7BBu: goto L_B1A7BB;
    case 0xB1A7BDu: goto L_B1A7BD;
    case 0xB1A7C0u: goto L_B1A7C0;
    case 0xB1A7C1u: goto L_B1A7C1;
    case 0xB1A7C2u: goto L_B1A7C2;
    case 0xB1A7C5u: goto L_B1A7C5;
    case 0xB1A7C8u: goto L_B1A7C8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A77C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A77E;
L_B1A77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A77E CMP
    cpu.compareA(0x2u);
    goto L_B1A780;
L_B1A780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA780u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA780u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A780 BNE -> $B1A7C2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A7C2; }
    goto L_B1A782;
L_B1A782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA782u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA782u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA782u, 4u + ((((0x187Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x187Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A782 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x187Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A785;
L_B1A785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA785u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA785u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A785 BNE -> $B1A7C2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A7C2; }
    goto L_B1A787;
L_B1A787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA787u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA787u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A787 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A78A;
L_B1A78A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Au,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Au, 4u + ((((0x157Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A78A CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x157Cu), cpu.m8?8:16));
    goto L_B1A78D;
L_B1A78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A78D BEQ -> $B1A7C2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A7C2; }
    goto L_B1A78F;
L_B1A78F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Fu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A78F STY
    hw.write(cpu.address("dp", 0x1u), cpu.y, cpu.x8?8:16);
    goto L_B1A791;
L_B1A791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA791u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA791u, 4u + ((((0x1534u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A791 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1534u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A794;
L_B1A794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA794u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA794u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A794 BNE -> $B1A7C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A7C0; }
    goto L_B1A796;
L_B1A796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA796u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA796u, 5u, 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A796 STZ
    hw.write(cpu.address("absx", 0x1528u), 0, cpu.m8?8:16);
    goto L_B1A799;
L_B1A799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA799u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA799u, 5u, 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A799 STZ
    hw.write(cpu.address("absx", 0x163Eu), 0, cpu.m8?8:16);
    goto L_B1A79C;
L_B1A79C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA79Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A79C TAY
    cpu.transfer("TAY");
    goto L_B1A79D;
L_B1A79D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA79Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Du,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A79D STY
    hw.write(cpu.address("dp", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_B1A79F;
L_B1A79F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA79Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A79F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A7A1;
L_B1A7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7A1 CLC
    cpu.setFlag('C', false);
    goto L_B1A7A2;
L_B1A7A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A2u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A2u, 4u + ((((0xA778u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA778u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7A2 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xA778u), cpu.m8?8:16));
    goto L_B1A7A5;
L_B1A7A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A5u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7A5 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A7A7;
L_B1A7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A7u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A7u, 5u, 3u, cpu.address("absy", 0x00E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7A7 STA
    hw.write(cpu.address("absy", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_B1A7AA;
L_B1A7AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AAu, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7AA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A7AD;
L_B1A7AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ADu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7AD LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A7AF;
L_B1A7AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AFu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AFu, 4u + ((((0xA77Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA77Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7AF ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xA77Au), cpu.m8?8:16));
    goto L_B1A7B2;
L_B1A7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7B2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A7B4;
L_B1A7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B4u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B4u, 5u, 3u, cpu.address("absy", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7B4 STA
    hw.write(cpu.address("absy", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_B1A7B7;
L_B1A7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B7u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7B7 TYA
    cpu.transfer("TYA");
    goto L_B1A7B8;
L_B1A7B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B8u, 5u, 3u, cpu.address("absx", 0x160Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7B8 STA
    hw.write(cpu.address("absx", 0x160Eu), cpu.a, cpu.m8?8:16);
    goto L_B1A7BB;
L_B1A7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7BB LDA
    cpu.setA(0x1u, 8);
    goto L_B1A7BD;
L_B1A7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BDu, 5u, 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7BD STA
    hw.write(cpu.address("absx", 0x1534u), cpu.a, cpu.m8?8:16);
    goto L_B1A7C0;
L_B1A7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C0u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A7C0 PLA
    cpu.pop("PLA", hw);
    goto L_B1A7C1;
L_B1A7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C1u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A7C1 PLA
    cpu.pop("PLA", hw);
    goto L_B1A7C2;
L_B1A7C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C2u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C2u, 4u, 3u, cpu.address("abs", 0x1695u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7C2 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1695u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A7C5;
L_B1A7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C5u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C5u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7C5 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A7C8;
L_B1A7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A7C8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A7C8u);return;} hw.unresolvedReturn(0xB1A7C8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A77C_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A77Cu: goto L_B1A77C;
    case 0xB1A77Eu: goto L_B1A77E;
    case 0xB1A780u: goto L_B1A780;
    case 0xB1A782u: goto L_B1A782;
    case 0xB1A785u: goto L_B1A785;
    case 0xB1A787u: goto L_B1A787;
    case 0xB1A78Au: goto L_B1A78A;
    case 0xB1A78Du: goto L_B1A78D;
    case 0xB1A78Fu: goto L_B1A78F;
    case 0xB1A791u: goto L_B1A791;
    case 0xB1A794u: goto L_B1A794;
    case 0xB1A796u: goto L_B1A796;
    case 0xB1A799u: goto L_B1A799;
    case 0xB1A79Cu: goto L_B1A79C;
    case 0xB1A79Du: goto L_B1A79D;
    case 0xB1A79Fu: goto L_B1A79F;
    case 0xB1A7A1u: goto L_B1A7A1;
    case 0xB1A7A2u: goto L_B1A7A2;
    case 0xB1A7A5u: goto L_B1A7A5;
    case 0xB1A7A7u: goto L_B1A7A7;
    case 0xB1A7AAu: goto L_B1A7AA;
    case 0xB1A7ADu: goto L_B1A7AD;
    case 0xB1A7AFu: goto L_B1A7AF;
    case 0xB1A7B2u: goto L_B1A7B2;
    case 0xB1A7B4u: goto L_B1A7B4;
    case 0xB1A7B7u: goto L_B1A7B7;
    case 0xB1A7B8u: goto L_B1A7B8;
    case 0xB1A7BBu: goto L_B1A7BB;
    case 0xB1A7BDu: goto L_B1A7BD;
    case 0xB1A7C0u: goto L_B1A7C0;
    case 0xB1A7C1u: goto L_B1A7C1;
    case 0xB1A7C2u: goto L_B1A7C2;
    case 0xB1A7C5u: goto L_B1A7C5;
    case 0xB1A7C8u: goto L_B1A7C8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A77C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A77E;
L_B1A77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A77E CMP
    cpu.compareA(0x2u);
    goto L_B1A780;
L_B1A780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA780u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA780u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A780 BNE -> $B1A7C2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A7C2; }
    goto L_B1A782;
L_B1A782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA782u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA782u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA782u, 4u + ((((0x187Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x187Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A782 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x187Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A785;
L_B1A785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA785u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA785u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A785 BNE -> $B1A7C2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A7C2; }
    goto L_B1A787;
L_B1A787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA787u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA787u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A787 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A78A;
L_B1A78A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Au,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Au, 4u + ((((0x157Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A78A CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x157Cu), cpu.m8?8:16));
    goto L_B1A78D;
L_B1A78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A78D BEQ -> $B1A7C2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A7C2; }
    goto L_B1A78F;
L_B1A78F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Fu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A78F STY
    hw.write(cpu.address("dp", 0x1u), cpu.y, cpu.x8?8:16);
    goto L_B1A791;
L_B1A791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA791u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA791u, 4u + ((((0x1534u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A791 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1534u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A794;
L_B1A794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA794u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA794u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A794 BNE -> $B1A7C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A7C0; }
    goto L_B1A796;
L_B1A796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA796u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA796u, 5u, 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A796 STZ
    hw.write(cpu.address("absx", 0x1528u), 0, cpu.m8?8:16);
    goto L_B1A799;
L_B1A799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA799u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA799u, 5u, 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A799 STZ
    hw.write(cpu.address("absx", 0x163Eu), 0, cpu.m8?8:16);
    goto L_B1A79C;
L_B1A79C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA79Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A79C TAY
    cpu.transfer("TAY");
    goto L_B1A79D;
L_B1A79D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA79Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Du,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A79D STY
    hw.write(cpu.address("dp", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_B1A79F;
L_B1A79F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA79Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A79F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A7A1;
L_B1A7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7A1 CLC
    cpu.setFlag('C', false);
    goto L_B1A7A2;
L_B1A7A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A2u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A2u, 4u + ((((0xA778u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA778u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7A2 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xA778u), cpu.m8?8:16));
    goto L_B1A7A5;
L_B1A7A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A5u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7A5 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A7A7;
L_B1A7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A7u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A7u, 5u, 3u, cpu.address("absy", 0x00E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7A7 STA
    hw.write(cpu.address("absy", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_B1A7AA;
L_B1A7AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AAu, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7AA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A7AD;
L_B1A7AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ADu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7AD LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A7AF;
L_B1A7AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AFu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AFu, 4u + ((((0xA77Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA77Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7AF ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xA77Au), cpu.m8?8:16));
    goto L_B1A7B2;
L_B1A7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7B2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A7B4;
L_B1A7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B4u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B4u, 5u, 3u, cpu.address("absy", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7B4 STA
    hw.write(cpu.address("absy", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_B1A7B7;
L_B1A7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B7u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7B7 TYA
    cpu.transfer("TYA");
    goto L_B1A7B8;
L_B1A7B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B8u, 5u, 3u, cpu.address("absx", 0x160Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7B8 STA
    hw.write(cpu.address("absx", 0x160Eu), cpu.a, cpu.m8?8:16);
    goto L_B1A7BB;
L_B1A7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7BB LDA
    cpu.setA(0x1u, 8);
    goto L_B1A7BD;
L_B1A7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BDu, 5u, 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7BD STA
    hw.write(cpu.address("absx", 0x1534u), cpu.a, cpu.m8?8:16);
    goto L_B1A7C0;
L_B1A7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C0u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A7C0 PLA
    cpu.pop("PLA", hw);
    goto L_B1A7C1;
L_B1A7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C1u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A7C1 PLA
    cpu.pop("PLA", hw);
    goto L_B1A7C2;
L_B1A7C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C2u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C2u, 4u, 3u, cpu.address("abs", 0x1695u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7C2 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1695u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A7C5;
L_B1A7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C5u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C5u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A7C5 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A7C8;
L_B1A7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A7C8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A7C8u);return;} hw.unresolvedReturn(0xB1A7C8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

