#include "generated.hpp"
void sub_008650_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008650u: goto L_008650;
    case 0x008653u: goto L_008653;
    case 0x008655u: goto L_008655;
    case 0x008658u: goto L_008658;
    case 0x008659u: goto L_008659;
    case 0x00865Cu: goto L_00865C;
    case 0x00865Fu: goto L_00865F;
    case 0x008662u: goto L_008662;
    case 0x008665u: goto L_008665;
    case 0x008668u: goto L_008668;
    case 0x00866Bu: goto L_00866B;
    case 0x00866Cu: goto L_00866C;
    case 0x00866Fu: goto L_00866F;
    case 0x008672u: goto L_008672;
    case 0x008675u: goto L_008675;
    case 0x008678u: goto L_008678;
    case 0x00867Bu: goto L_00867B;
    case 0x00867Du: goto L_00867D;
    case 0x008680u: goto L_008680;
    case 0x008681u: goto L_008681;
    case 0x008684u: goto L_008684;
    case 0x008687u: goto L_008687;
    case 0x00868Au: goto L_00868A;
    case 0x00868Du: goto L_00868D;
    case 0x008690u: goto L_008690;
    case 0x008693u: goto L_008693;
    case 0x008694u: goto L_008694;
    case 0x008697u: goto L_008697;
    case 0x00869Au: goto L_00869A;
    case 0x00869Du: goto L_00869D;
    case 0x0086A0u: goto L_0086A0;
    case 0x0086A3u: goto L_0086A3;
    case 0x0086A5u: goto L_0086A5;
    case 0x0086A8u: goto L_0086A8;
    case 0x0086ABu: goto L_0086AB;
    case 0x0086ADu: goto L_0086AD;
    case 0x0086B0u: goto L_0086B0;
    case 0x0086B2u: goto L_0086B2;
    case 0x0086B5u: goto L_0086B5;
    case 0x0086B7u: goto L_0086B7;
    case 0x0086BAu: goto L_0086BA;
    case 0x0086BCu: goto L_0086BC;
    case 0x0086BFu: goto L_0086BF;
    case 0x0086C1u: goto L_0086C1;
    case 0x0086C4u: goto L_0086C4;
    case 0x0086C6u: goto L_0086C6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8650u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8650u, 4u, 3u, cpu.address("abs", 0x4218u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008650 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4218u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008653;
L_008653:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8653u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8653u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8653u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008653 AND
    cpu.logicAnd(0xF0u);
    goto L_008655;
L_008655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u, 4u, 3u, cpu.address("abs", 0x0DA4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008655 STA
    hw.write(cpu.address("abs", 0xDA4u), cpu.a, cpu.m8?8:16);
    goto L_008658;
L_008658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8658u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8658u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008658 TAY
    cpu.transfer("TAY");
    goto L_008659;
L_008659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8659u,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8659u, 4u, 3u, cpu.address("abs", 0x0DACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008659 EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0xDACu), cpu.m8?8:16));
    goto L_00865C;
L_00865C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Cu,cpu,0x2Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Cu, 4u, 3u, cpu.address("abs", 0x0DA4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00865C AND
    cpu.logicAnd(hw.readW(cpu.address("abs", 0xDA4u), cpu.m8?8:16));
    goto L_00865F;
L_00865F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Fu, 4u, 3u, cpu.address("abs", 0x0DA8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00865F STA
    hw.write(cpu.address("abs", 0xDA8u), cpu.a, cpu.m8?8:16);
    goto L_008662;
L_008662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8662u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8662u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8662u, 4u, 3u, cpu.address("abs", 0x0DACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008662 STY
    hw.write(cpu.address("abs", 0xDACu), cpu.y, cpu.x8?8:16);
    goto L_008665;
L_008665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8665u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8665u, 4u, 3u, cpu.address("abs", 0x4219u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008665 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4219u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008668;
L_008668:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8668u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8668u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8668u, 4u, 3u, cpu.address("abs", 0x0DA2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008668 STA
    hw.write(cpu.address("abs", 0xDA2u), cpu.a, cpu.m8?8:16);
    goto L_00866B;
L_00866B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00866B TAY
    cpu.transfer("TAY");
    goto L_00866C;
L_00866C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Cu,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Cu, 4u, 3u, cpu.address("abs", 0x0DAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00866C EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0xDAAu), cpu.m8?8:16));
    goto L_00866F;
L_00866F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Fu,cpu,0x2Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Fu, 4u, 3u, cpu.address("abs", 0x0DA2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00866F AND
    cpu.logicAnd(hw.readW(cpu.address("abs", 0xDA2u), cpu.m8?8:16));
    goto L_008672;
L_008672:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8672u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8672u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8672u, 4u, 3u, cpu.address("abs", 0x0DA6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008672 STA
    hw.write(cpu.address("abs", 0xDA6u), cpu.a, cpu.m8?8:16);
    goto L_008675;
L_008675:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8675u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8675u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8675u, 4u, 3u, cpu.address("abs", 0x0DAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008675 STY
    hw.write(cpu.address("abs", 0xDAAu), cpu.y, cpu.x8?8:16);
    goto L_008678;
L_008678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8678u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8678u, 4u, 3u, cpu.address("abs", 0x421Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008678 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x421Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00867B;
L_00867B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00867B AND
    cpu.logicAnd(0xF0u);
    goto L_00867D;
L_00867D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Du, 4u, 3u, cpu.address("abs", 0x0DA5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00867D STA
    hw.write(cpu.address("abs", 0xDA5u), cpu.a, cpu.m8?8:16);
    goto L_008680;
L_008680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8680u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8680u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008680 TAY
    cpu.transfer("TAY");
    goto L_008681;
L_008681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8681u,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8681u, 4u, 3u, cpu.address("abs", 0x0DADu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008681 EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0xDADu), cpu.m8?8:16));
    goto L_008684;
L_008684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8684u,cpu,0x2Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8684u, 4u, 3u, cpu.address("abs", 0x0DA5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008684 AND
    cpu.logicAnd(hw.readW(cpu.address("abs", 0xDA5u), cpu.m8?8:16));
    goto L_008687;
L_008687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8687u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8687u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8687u, 4u, 3u, cpu.address("abs", 0x0DA9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008687 STA
    hw.write(cpu.address("abs", 0xDA9u), cpu.a, cpu.m8?8:16);
    goto L_00868A;
L_00868A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Au, 4u, 3u, cpu.address("abs", 0x0DADu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00868A STY
    hw.write(cpu.address("abs", 0xDADu), cpu.y, cpu.x8?8:16);
    goto L_00868D;
L_00868D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Du, 4u, 3u, cpu.address("abs", 0x421Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00868D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x421Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008690;
L_008690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8690u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8690u, 4u, 3u, cpu.address("abs", 0x0DA3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008690 STA
    hw.write(cpu.address("abs", 0xDA3u), cpu.a, cpu.m8?8:16);
    goto L_008693;
L_008693:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8693u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8693u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8693u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008693 TAY
    cpu.transfer("TAY");
    goto L_008694;
L_008694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8694u,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8694u, 4u, 3u, cpu.address("abs", 0x0DABu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008694 EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0xDABu), cpu.m8?8:16));
    goto L_008697;
L_008697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u,cpu,0x2Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u, 4u, 3u, cpu.address("abs", 0x0DA3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008697 AND
    cpu.logicAnd(hw.readW(cpu.address("abs", 0xDA3u), cpu.m8?8:16));
    goto L_00869A;
L_00869A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au, 4u, 3u, cpu.address("abs", 0x0DA7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00869A STA
    hw.write(cpu.address("abs", 0xDA7u), cpu.a, cpu.m8?8:16);
    goto L_00869D;
L_00869D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du, 4u, 3u, cpu.address("abs", 0x0DABu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00869D STY
    hw.write(cpu.address("abs", 0xDABu), cpu.y, cpu.x8?8:16);
    goto L_0086A0;
L_0086A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A0u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A0u, 4u, 3u, cpu.address("abs", 0x0DA0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086A0 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0086A3;
L_0086A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A3u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086A3 BPL -> $0086A8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0086A8; }
    goto L_0086A5;
L_0086A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A5u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A5u, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086A5 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0086A8;
L_0086A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A8u, 4u + ((((0x0DA4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DA4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086A8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0086AB;
L_0086AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ABu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086AB AND
    cpu.logicAnd(0xC0u);
    goto L_0086AD;
L_0086AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ADu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ADu, 4u + ((((0x0DA2u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DA2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086AD ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0xDA2u), cpu.m8?8:16));
    goto L_0086B0;
L_0086B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086B0 STA
    hw.write(cpu.address("dp", 0x15u), cpu.a, cpu.m8?8:16);
    goto L_0086B2;
L_0086B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u, 4u + ((((0x0DA4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DA4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086B2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0086B5;
L_0086B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086B5 STA
    hw.write(cpu.address("dp", 0x17u), cpu.a, cpu.m8?8:16);
    goto L_0086B7;
L_0086B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u, 4u + ((((0x0DA8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DA8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086B7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDA8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0086BA;
L_0086BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086BA AND
    cpu.logicAnd(0x40u);
    goto L_0086BC;
L_0086BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BCu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BCu, 4u + ((((0x0DA6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DA6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086BC ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0xDA6u), cpu.m8?8:16));
    goto L_0086BF;
L_0086BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086BF STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_0086C1;
L_0086C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u, 4u + ((((0x0DA8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DA8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086C1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDA8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0086C4;
L_0086C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086C4 STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_0086C6;
L_0086C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0086C6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0086C6u);return;} hw.unresolvedReturn(0x0086C6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_008DD6_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008DD6u: goto L_008DD6;
    case 0x008DD8u: goto L_008DD8;
    case 0x008DDBu: goto L_008DDB;
    case 0x008DDEu: goto L_008DDE;
    case 0x008DDFu: goto L_008DDF;
    case 0x008DE1u: goto L_008DE1;
    case 0x008DE3u: goto L_008DE3;
    case 0x008DE6u: goto L_008DE6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008DD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DD6 LDX
    cpu.setX(0x6u, 8);
    goto L_008DD8;
L_008DD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD8u, 4u + ((((0x8DEEu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8DEEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DD8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8DEEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008DDB;
L_008DDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDBu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DDB STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008DDE;
L_008DDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDEu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DDE DEX
    cpu.decReg('X');
    goto L_008DDF;
L_008DDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DDF BPL -> $008DD8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008DD8; }
    goto L_008DE1;
L_008DE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DE1 LDA
    cpu.setA(0x2u, 8);
    goto L_008DE3;
L_008DE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE3u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DE3 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008DE6;
L_008DE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008DE6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008DE6u);return;} hw.unresolvedReturn(0x008DE6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00EBDD_E0M1X1C1_part17(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF04u: goto L_00EF04;
    case 0x00EF05u: goto L_00EF05;
    case 0x00EF06u: goto L_00EF06;
    case 0x00EF08u: goto L_00EF08;
    case 0x00EF09u: goto L_00EF09;
    case 0x00EF0Bu: goto L_00EF0B;
    case 0x00EF0Du: goto L_00EF0D;
    case 0x00EF0Eu: goto L_00EF0E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF04u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u,cpu,0x13u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xBEu) & 0xFFFFu), 2u, 0u);
    // $00EF04 ORA
    cpu.logicOr(hw.readW(cpu.addressStackIndirectY(hw, 0xBEu), cpu.m8?8:16));
    goto L_00EF06;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u,cpu,0x13u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xBEu) & 0xFFFFu), 2u, 0u);
    // $00EF04 ORA
    cpu.logicOr(hw.readW(cpu.addressStackIndirectY(hw, 0xBEu), cpu.m8?8:16));
    goto L_00EF06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF04u,0x00EF04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF05u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u, 5u + 1u, 3u, cpu.address("absy", 0xE4B9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF05 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xE4B9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF08;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u, 4u + ((((0xE4B9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4B9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF05 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xE4B9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF08;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u, 5u + 1u, 3u, cpu.address("absy", 0xE4B9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF05 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xE4B9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF08;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u, 4u + ((((0xE4B9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4B9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF05 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xE4B9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF08;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF05u,0x00EF05u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF06u))return;
  // 16 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u, 5u + 1u, 3u, cpu.address("absy", 0x8EE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF06 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8EE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF09;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u, 5u + ((((0x8EE4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8EE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF06 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8EE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF09;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u, 4u + 1u, 3u, cpu.address("absy", 0x8EE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF06 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8EE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF06u,0x00EF06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF08u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 5u, 3u, cpu.address("abs", 0x13E1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF08 STX
    hw.write(cpu.address("abs", 0x13E1u), cpu.x, cpu.x8?8:16);
    goto L_00EF0B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF08 STX
    hw.write(cpu.address("abs", 0x13E1u), cpu.x, cpu.x8?8:16);
    goto L_00EF0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 5u, 3u, cpu.address("abs", 0x13E1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF08 STX
    hw.write(cpu.address("abs", 0x13E1u), cpu.x, cpu.x8?8:16);
    goto L_00EF0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF08 STX
    hw.write(cpu.address("abs", 0x13E1u), cpu.x, cpu.x8?8:16);
    goto L_00EF0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF08u,0x00EF08u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF09u))return;
  // 16 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x13u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00EF09 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0x13u), cpu.m8?8:16));
    goto L_00EF0B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x13u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00EF09 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0x13u), cpu.m8?8:16));
    goto L_00EF0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x13u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00EF09 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0x13u), cpu.m8?8:16));
    goto L_00EF0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF09u,0x00EF09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Bu))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0B CPY
    cpu.compareY(0xB01Cu);
    goto L_00EF0E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0B CPY
    cpu.compareY(0x1Cu);
    goto L_00EF0D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0B CPY
    cpu.compareY(0xB01Cu);
    goto L_00EF0E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0B CPY
    cpu.compareY(0x1Cu);
    goto L_00EF0D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,0x00EF0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Du))return;
  // 17 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0D BCS -> $00EF38
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF38u,0x00EF0Du); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Fu,0x00EF0Du); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0D BCS -> $00EF38
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF38u,0x00EF0Du); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Fu,0x00EF0Du); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Du,0x00EF0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Eu))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0E AND
    cpu.logicAnd(0x7BA5u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF11u,0x00EF0Eu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0E AND
    cpu.logicAnd(0xA5u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF10u,0x00EF0Eu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Eu,0x00EF0Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part17(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF04u: goto L_00EF04;
    case 0x00EF05u: goto L_00EF05;
    case 0x00EF06u: goto L_00EF06;
    case 0x00EF08u: goto L_00EF08;
    case 0x00EF09u: goto L_00EF09;
    case 0x00EF0Bu: goto L_00EF0B;
    case 0x00EF0Du: goto L_00EF0D;
    case 0x00EF0Eu: goto L_00EF0E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF04u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u,cpu,0x13u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xBEu) & 0xFFFFu), 2u, 0u);
    // $00EF04 ORA
    cpu.logicOr(hw.readW(cpu.addressStackIndirectY(hw, 0xBEu), cpu.m8?8:16));
    goto L_00EF06;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u,cpu,0x13u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xBEu) & 0xFFFFu), 2u, 0u);
    // $00EF04 ORA
    cpu.logicOr(hw.readW(cpu.addressStackIndirectY(hw, 0xBEu), cpu.m8?8:16));
    goto L_00EF06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF04u,0x00EF04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF05u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u, 5u + 1u, 3u, cpu.address("absy", 0xE4B9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF05 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xE4B9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF08;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u, 4u + ((((0xE4B9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4B9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF05 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xE4B9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF08;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u, 5u + 1u, 3u, cpu.address("absy", 0xE4B9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF05 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xE4B9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF08;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u, 4u + ((((0xE4B9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4B9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF05 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xE4B9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF08;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF05u,0x00EF05u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF06u))return;
  // 16 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u, 5u + 1u, 3u, cpu.address("absy", 0x8EE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF06 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8EE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF09;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u, 5u + ((((0x8EE4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8EE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF06 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8EE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF09;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u, 4u + 1u, 3u, cpu.address("absy", 0x8EE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF06 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8EE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF06u,0x00EF06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF08u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 5u, 3u, cpu.address("abs", 0x13E1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF08 STX
    hw.write(cpu.address("abs", 0x13E1u), cpu.x, cpu.x8?8:16);
    goto L_00EF0B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF08 STX
    hw.write(cpu.address("abs", 0x13E1u), cpu.x, cpu.x8?8:16);
    goto L_00EF0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 5u, 3u, cpu.address("abs", 0x13E1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF08 STX
    hw.write(cpu.address("abs", 0x13E1u), cpu.x, cpu.x8?8:16);
    goto L_00EF0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF08 STX
    hw.write(cpu.address("abs", 0x13E1u), cpu.x, cpu.x8?8:16);
    goto L_00EF0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF08u,0x00EF08u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF09u))return;
  // 16 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x13u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00EF09 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0x13u), cpu.m8?8:16));
    goto L_00EF0B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x13u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00EF09 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0x13u), cpu.m8?8:16));
    goto L_00EF0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x13u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00EF09 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0x13u), cpu.m8?8:16));
    goto L_00EF0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF09u,0x00EF09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Bu))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0B CPY
    cpu.compareY(0xB01Cu);
    goto L_00EF0E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0B CPY
    cpu.compareY(0x1Cu);
    goto L_00EF0D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0B CPY
    cpu.compareY(0xB01Cu);
    goto L_00EF0E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0B CPY
    cpu.compareY(0x1Cu);
    goto L_00EF0D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,0x00EF0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Du))return;
  // 17 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0D BCS -> $00EF38
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF38u,0x00EF0Du); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Fu,0x00EF0Du); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0D BCS -> $00EF38
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF38u,0x00EF0Du); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Fu,0x00EF0Du); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Du,0x00EF0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Eu))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0E AND
    cpu.logicAnd(0x7BA5u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF11u,0x00EF0Eu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0E AND
    cpu.logicAnd(0xA5u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF10u,0x00EF0Eu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Eu,0x00EF0Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E1M1X1CQ_part19(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF33u: goto L_00EF33;
    case 0x00EF35u: goto L_00EF35;
    case 0x00EF36u: goto L_00EF36;
    case 0x00EF37u: goto L_00EF37;
    case 0x00EF38u: goto L_00EF38;
    case 0x00EF39u: goto L_00EF39;
    case 0x00EF3Au: goto L_00EF3A;
    case 0x00EF3Bu: goto L_00EF3B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF33u))return;
  // 36 variantes de decodificacao M/X para este endereco; 6 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u, 5u + 1u, 3u, cpu.address("absy", 0xE4DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF33 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16));
    goto L_00EF36;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u, 5u + ((((0xE4DAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF33 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16));
    goto L_00EF36;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u, 5u + 1u, 3u, cpu.address("absy", 0xE4DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF33 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16));
    goto L_00EF36;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u, 5u + ((((0xE4DAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF33 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16));
    goto L_00EF36;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u, 4u + 1u, 3u, cpu.address("absy", 0xE4DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF33 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16));
    goto L_00EF36;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u, 4u + ((((0xE4DAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF33 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16));
    goto L_00EF36;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF33u,0x00EF33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF35u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF35u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF35u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF35 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x90u), cpu.x8?8:16));
    goto L_00EF37;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF35u,0x00EF35u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF36u))return;
  // 36 variantes de decodificacao M/X para este endereco; 6 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF36 BCC -> $00EF3B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EF3B; }
    goto L_00EF38;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF36 BCC -> $00EF3B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EF3B; }
    goto L_00EF38;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF36 BCC -> $00EF3B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EF3B; }
    goto L_00EF38;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF36 BCC -> $00EF3B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EF3B; }
    goto L_00EF38;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF36 BCC -> $00EF3B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EF3B; }
    goto L_00EF38;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF36 BCC -> $00EF3B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EF3B; }
    goto L_00EF38;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF36u,0x00EF36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF37u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF37u,cpu,0x03u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF37u, 4u, 2u, cpu.addressStack(0xB9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF37 ORA
    cpu.logicOr(hw.readW(cpu.addressStack(0xB9u), cpu.m8?8:16));
    goto L_00EF39;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF37u,0x00EF37u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF38u))return;
  // 36 variantes de decodificacao M/X para este endereco; 6 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u, 5u + 1u, 3u, cpu.address("absy", 0xE4DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF38 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF3B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u, 5u + ((((0xE4DAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF38 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF3B;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u, 5u + 1u, 3u, cpu.address("absy", 0xE4DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF38 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF3B;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u, 5u + ((((0xE4DAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF38 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF3B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u, 4u + 1u, 3u, cpu.address("absy", 0xE4DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF38 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF3B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u, 4u + ((((0xE4DAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF38 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF3B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF38u,0x00EF38u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF39u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF39u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF39u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF39 PHX
    cpu.push("PHX", hw);
    goto L_00EF3A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF39u,0x00EF39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF3Au))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Au,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF3A CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0xA6u), cpu.x8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF3Cu,0x00EF3Au); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF3Au,0x00EF3Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF3Bu))return;
  // 36 variantes de decodificacao M/X para este endereco; 6 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF3B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Eu), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF3Du,0x00EF3Bu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF3B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Eu), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF3Du,0x00EF3Bu); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF3B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Eu), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF3Du,0x00EF3Bu); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF3B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Eu), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF3Du,0x00EF3Bu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF3B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Eu), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF3Du,0x00EF3Bu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF3B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Eu), cpu.x8?8:16), cpu.x8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF3Du,0x00EF3Bu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF3Bu,0x00EF3Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_018042_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018042u: goto L_018042;
    case 0x018043u: goto L_018043;
    case 0x018044u: goto L_018044;
    case 0x018045u: goto L_018045;
    case 0x018048u: goto L_018048;
    case 0x018049u: goto L_018049;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8042u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8042u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018042 PHB
    cpu.push("PHB", hw);
    goto L_018043;
L_018043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8043u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8043u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018043 PHK
    cpu.push("PHK", hw);
    goto L_018044;
L_018044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8044u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8044u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018044 PLB
    cpu.pop("PLB", hw);
    goto L_018045;
L_018045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8045u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8045u, 6u, 3u, cpu.address("abs", 0x9CF3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018045 JSR -> $019CF3 stack real
    { cpu.push16Value(hw,0x8047u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8048u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CF3u), 0x018045u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018048;
L_018048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8048u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8048u,0x018048u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8048u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8048u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018048 PLB
    cpu.pop("PLB", hw);
    goto L_018049;
L_018049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8049u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8049u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $018049 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x018049u);return;} hw.unresolvedReturn(0x018049u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_019AA2_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019AA2u: goto L_019AA2;
    case 0x019AA4u: goto L_019AA4;
    case 0x019AA6u: goto L_019AA6;
    case 0x019AA8u: goto L_019AA8;
    case 0x019AABu: goto L_019AAB;
    case 0x019AADu: goto L_019AAD;
    case 0x019AAFu: goto L_019AAF;
    case 0x019AB1u: goto L_019AB1;
    case 0x019AB4u: goto L_019AB4;
    case 0x019AB6u: goto L_019AB6;
    case 0x019AB8u: goto L_019AB8;
    case 0x019ABBu: goto L_019ABB;
    case 0x019ABCu: goto L_019ABC;
    case 0x019ABEu: goto L_019ABE;
    case 0x019AC0u: goto L_019AC0;
    case 0x019AC4u: goto L_019AC4;
    case 0x019AC7u: goto L_019AC7;
    case 0x019AC9u: goto L_019AC9;
    case 0x019AD6u: goto L_019AD6;
    case 0x019AD8u: goto L_019AD8;
    case 0x019ADAu: goto L_019ADA;
    case 0x019ADDu: goto L_019ADD;
    case 0x019AE0u: goto L_019AE0;
    case 0x019AE3u: goto L_019AE3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019AA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AA2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019AA4;
L_019AA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AA4 CMP
    cpu.compareA(0x86u);
    goto L_019AA6;
L_019AA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AA6 BNE -> $019AAB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019AAB; }
    goto L_019AA8;
L_019AA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA8u, 3u, 3u, cpu.address("abs", 0x85C3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AA8 JMP -> $0185C3
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x85C3u),0x019AA8u); return;
L_019AAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AABu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AAB CMP
    cpu.compareA(0x1Eu);
    goto L_019AAD;
L_019AAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AADu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AAD BNE -> $019AB4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019AB4; }
    goto L_019AAF;
L_019AAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AAFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AAF LDY
    cpu.setY(0xFFu, 8);
    goto L_019AB1;
L_019AB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB1u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB1u, 4u, 3u, cpu.address("abs", 0x18E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AB1 STY
    hw.write(cpu.address("abs", 0x18E0u), cpu.y, cpu.x8?8:16);
    goto L_019AB4;
L_019AB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AB4 CMP
    cpu.compareA(0x53u);
    goto L_019AB6;
L_019AB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AB6 BNE -> $019ABC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019ABC; }
    goto L_019AB8;
L_019AB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB8u, 6u, 3u, cpu.address("abs", 0x99DCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019AB8 JSR -> $0199DC stack real
    { cpu.push16Value(hw,0x9ABAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9ABBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99DCu), 0x019AB8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019ABB;
L_019ABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ABBu,0x019ABBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019ABB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x019ABBu);return;} hw.unresolvedReturn(0x019ABBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_019ABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019ABC CMP
    cpu.compareA(0x4Cu);
    goto L_019ABE;
L_019ABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019ABE BNE -> $019AC4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019AC4; }
    goto L_019AC0;
L_019AC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC0u, 8u, 4u, 0x02E463u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $019AC0 JSL -> $02E463 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9AC3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9AC4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02E463u, 0x019AC0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019AC4;
L_019AC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AC4u,0x019AC4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC4u, 4u + ((((0x1656u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1656u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AC4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1656u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019AC7;
L_019AC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AC7 AND
    cpu.logicAnd(0x80u);
    goto L_019AC9;
L_019AC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AC9 BEQ -> $019AD6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_019AD6; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ACBu,0x019AC9u); return;
L_019AD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AD6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019AD8;
L_019AD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AD8 BNE -> $019ADD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019ADD; }
    goto L_019ADA;
L_019ADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADAu, 6u, 3u, cpu.address("abs", 0x9032u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019ADA JSR -> $019032 stack real
    { cpu.push16Value(hw,0x9ADCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9ADDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9032u), 0x019ADAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019ADD;
L_019ADD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ADDu,0x019ADDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADDu, 6u, 3u, cpu.address("abs", 0xAC31u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019ADD JSR -> $01AC31 stack real
    { cpu.push16Value(hw,0x9ADFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9AE0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC31u), 0x019ADDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019AE0;
L_019AE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AE0u,0x019AE0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u, 6u, 3u, cpu.address("abs", 0x9B13u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019AE0 JSR -> $019B13 stack real
    { cpu.push16Value(hw,0x9AE2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9AE3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9B13u), 0x019AE0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019AE3;
L_019AE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AE3u,0x019AE3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019AE3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x019AE3u);return;} hw.unresolvedReturn(0x019AE3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_019AA2_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019AA2u: goto L_019AA2;
    case 0x019AA4u: goto L_019AA4;
    case 0x019AA6u: goto L_019AA6;
    case 0x019AA8u: goto L_019AA8;
    case 0x019AABu: goto L_019AAB;
    case 0x019AADu: goto L_019AAD;
    case 0x019AAFu: goto L_019AAF;
    case 0x019AB1u: goto L_019AB1;
    case 0x019AB4u: goto L_019AB4;
    case 0x019AB6u: goto L_019AB6;
    case 0x019AB8u: goto L_019AB8;
    case 0x019ABBu: goto L_019ABB;
    case 0x019ABCu: goto L_019ABC;
    case 0x019ABEu: goto L_019ABE;
    case 0x019AC0u: goto L_019AC0;
    case 0x019AC4u: goto L_019AC4;
    case 0x019AC7u: goto L_019AC7;
    case 0x019AC9u: goto L_019AC9;
    case 0x019AD6u: goto L_019AD6;
    case 0x019AD8u: goto L_019AD8;
    case 0x019ADAu: goto L_019ADA;
    case 0x019ADDu: goto L_019ADD;
    case 0x019AE0u: goto L_019AE0;
    case 0x019AE3u: goto L_019AE3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019AA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AA2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019AA4;
L_019AA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AA4 CMP
    cpu.compareA(0x86u);
    goto L_019AA6;
L_019AA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AA6 BNE -> $019AAB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019AAB; }
    goto L_019AA8;
L_019AA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA8u, 3u, 3u, cpu.address("abs", 0x85C3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AA8 JMP -> $0185C3
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x85C3u),0x019AA8u); return;
L_019AAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AABu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AAB CMP
    cpu.compareA(0x1Eu);
    goto L_019AAD;
L_019AAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AADu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AAD BNE -> $019AB4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019AB4; }
    goto L_019AAF;
L_019AAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AAFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AAF LDY
    cpu.setY(0xFFu, 8);
    goto L_019AB1;
L_019AB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB1u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB1u, 4u, 3u, cpu.address("abs", 0x18E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AB1 STY
    hw.write(cpu.address("abs", 0x18E0u), cpu.y, cpu.x8?8:16);
    goto L_019AB4;
L_019AB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AB4 CMP
    cpu.compareA(0x53u);
    goto L_019AB6;
L_019AB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AB6 BNE -> $019ABC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019ABC; }
    goto L_019AB8;
L_019AB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB8u, 6u, 3u, cpu.address("abs", 0x99DCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019AB8 JSR -> $0199DC stack real
    { cpu.push16Value(hw,0x9ABAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9ABBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99DCu), 0x019AB8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019ABB;
L_019ABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ABBu,0x019ABBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019ABB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x019ABBu);return;} hw.unresolvedReturn(0x019ABBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_019ABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019ABC CMP
    cpu.compareA(0x4Cu);
    goto L_019ABE;
L_019ABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019ABE BNE -> $019AC4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019AC4; }
    goto L_019AC0;
L_019AC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC0u, 8u, 4u, 0x02E463u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $019AC0 JSL -> $02E463 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9AC3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9AC4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02E463u, 0x019AC0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019AC4;
L_019AC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AC4u,0x019AC4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC4u, 4u + ((((0x1656u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1656u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AC4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1656u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019AC7;
L_019AC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AC7 AND
    cpu.logicAnd(0x80u);
    goto L_019AC9;
L_019AC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AC9 BEQ -> $019AD6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_019AD6; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ACBu,0x019AC9u); return;
L_019AD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AD6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019AD8;
L_019AD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019AD8 BNE -> $019ADD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019ADD; }
    goto L_019ADA;
L_019ADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADAu, 6u, 3u, cpu.address("abs", 0x9032u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019ADA JSR -> $019032 stack real
    { cpu.push16Value(hw,0x9ADCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9ADDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9032u), 0x019ADAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019ADD;
L_019ADD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ADDu,0x019ADDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADDu, 6u, 3u, cpu.address("abs", 0xAC31u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019ADD JSR -> $01AC31 stack real
    { cpu.push16Value(hw,0x9ADFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9AE0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC31u), 0x019ADDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019AE0;
L_019AE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AE0u,0x019AE0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u, 6u, 3u, cpu.address("abs", 0x9B13u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019AE0 JSR -> $019B13 stack real
    { cpu.push16Value(hw,0x9AE2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9AE3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9B13u), 0x019AE0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019AE3;
L_019AE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AE3u,0x019AE3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019AE3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x019AE3u);return;} hw.unresolvedReturn(0x019AE3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_019E35_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019E35u: goto L_019E35;
    case 0x019E37u: goto L_019E37;
    case 0x019E3Au: goto L_019E3A;
    case 0x019E3Cu: goto L_019E3C;
    case 0x019E3Eu: goto L_019E3E;
    case 0x019E40u: goto L_019E40;
    case 0x019E43u: goto L_019E43;
    case 0x019E45u: goto L_019E45;
    case 0x019E47u: goto L_019E47;
    case 0x019E49u: goto L_019E49;
    case 0x019E4Cu: goto L_019E4C;
    case 0x019E4Du: goto L_019E4D;
    case 0x019E50u: goto L_019E50;
    case 0x019E51u: goto L_019E51;
    case 0x019E53u: goto L_019E53;
    case 0x019E54u: goto L_019E54;
    case 0x019E56u: goto L_019E56;
    case 0x019E57u: goto L_019E57;
    case 0x019E5Au: goto L_019E5A;
    case 0x019E5Cu: goto L_019E5C;
    case 0x019E5Eu: goto L_019E5E;
    case 0x019E61u: goto L_019E61;
    case 0x019E62u: goto L_019E62;
    case 0x019E64u: goto L_019E64;
    case 0x019E65u: goto L_019E65;
    case 0x019E67u: goto L_019E67;
    case 0x019E6Au: goto L_019E6A;
    case 0x019E6Bu: goto L_019E6B;
    case 0x019E6Du: goto L_019E6D;
    case 0x019E6Fu: goto L_019E6F;
    case 0x019E71u: goto L_019E71;
    case 0x019E72u: goto L_019E72;
    case 0x019E74u: goto L_019E74;
    case 0x019E75u: goto L_019E75;
    case 0x019E78u: goto L_019E78;
    case 0x019E7Bu: goto L_019E7B;
    case 0x019E7Eu: goto L_019E7E;
    case 0x019E81u: goto L_019E81;
    case 0x019E83u: goto L_019E83;
    case 0x019E86u: goto L_019E86;
    case 0x019E89u: goto L_019E89;
    case 0x019E8Au: goto L_019E8A;
    case 0x019E8Bu: goto L_019E8B;
    case 0x019E8Cu: goto L_019E8C;
    case 0x019E8Du: goto L_019E8D;
    case 0x019E90u: goto L_019E90;
    case 0x019E93u: goto L_019E93;
    case 0x019E94u: goto L_019E94;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019E35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E35u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E35u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E35 STY
    hw.write(cpu.address("dp", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_019E37;
L_019E37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E37u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E37u, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E37 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019E3A;
L_019E3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E3Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E3Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E3A BNE -> $019E94
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019E94; }
    goto L_019E3C;
L_019E3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E3Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E3Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E3C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019E3E;
L_019E3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E3E STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_019E40;
L_019E40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E40u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E40u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E40 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019E43;
L_019E43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E43u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E43u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E43 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_019E45;
L_019E45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E45u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E45u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E45 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019E47;
L_019E47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E47u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E47u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E47 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_019E49;
L_019E49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E49u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E49u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E49 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019E4C;
L_019E4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Cu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019E4C PHX
    cpu.push("PHX", hw);
    goto L_019E4D;
L_019E4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Du, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E4D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019E50;
L_019E50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E50u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E50 ASL
    cpu.aslA();
    goto L_019E51;
L_019E51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E51u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E51u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E51 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_019E53;
L_019E53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E53u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E53 TAX
    cpu.transfer("TAX");
    goto L_019E54;
L_019E54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E54u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E54u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E54 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019E56;
L_019E56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E56u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E56u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E56 CLC
    cpu.setFlag('C', false);
    goto L_019E57;
L_019E57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E57u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E57u, 4u + ((((0x9E10u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9E10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E57 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x9E10u), cpu.m8?8:16));
    goto L_019E5A;
L_019E5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E5A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_019E5C;
L_019E5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E5C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019E5E;
L_019E5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Eu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Eu, 4u + ((((0x9E14u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9E14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E5E ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x9E14u), cpu.m8?8:16));
    goto L_019E61;
L_019E61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E61u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E61u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019E61 PHA
    cpu.push("PHA", hw);
    goto L_019E62;
L_019E62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E62u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E62u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E62 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019E64;
L_019E64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E64u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E64u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E64 SEC
    cpu.setFlag('C', true);
    goto L_019E65;
L_019E65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E65u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E65u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E65 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_019E67;
L_019E67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E67u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E67u, 5u, 3u, cpu.address("absy", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E67 STA
    hw.write(cpu.address("absy", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_019E6A;
L_019E6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019E6A PLA
    cpu.pop("PLA", hw);
    goto L_019E6B;
L_019E6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Bu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E6B SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16));
    goto L_019E6D;
L_019E6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E6D BNE -> $019E93
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019E93; }
    goto L_019E6F;
L_019E6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E6F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019E71;
L_019E71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E71u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E71u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E71 SEC
    cpu.setFlag('C', true);
    goto L_019E72;
L_019E72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E72u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E72u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E72 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_019E74;
L_019E74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E74u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E74u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E74 CLC
    cpu.setFlag('C', false);
    goto L_019E75;
L_019E75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E75u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E75u, 4u + ((((0x9E18u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9E18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E75 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x9E18u), cpu.m8?8:16));
    goto L_019E78;
L_019E78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E78u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E78u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E78 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_019E7B;
L_019E7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Bu, 4u + ((((0x9E1Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9E1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E7B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9E1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019E7E;
L_019E7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E7E STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_019E81;
L_019E81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E81u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E81u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E81 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019E83;
L_019E83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E83u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E83u, 4u + ((((0x9E20u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9E20u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E83 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x9E20u), cpu.m8?8:16));
    goto L_019E86;
L_019E86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E86u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E86u, 5u, 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E86 STA
    hw.write(cpu.address("absy", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_019E89;
L_019E89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E89u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E89 TYA
    cpu.transfer("TYA");
    goto L_019E8A;
L_019E8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E8A LSR
    cpu.lsrA();
    goto L_019E8B;
L_019E8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E8B LSR
    cpu.lsrA();
    goto L_019E8C;
L_019E8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E8C TAY
    cpu.transfer("TAY");
    goto L_019E8D;
L_019E8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Du, 4u + ((((0x9E24u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9E24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E8D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9E24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019E90;
L_019E90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E90u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E90u, 5u, 3u, cpu.address("absy", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019E90 STA
    hw.write(cpu.address("absy", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_019E93;
L_019E93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019E93 PLX
    cpu.pop("PLX", hw);
    goto L_019E94;
L_019E94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E94u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E94u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019E94 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x019E94u);return;} hw.unresolvedReturn(0x019E94u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_028ED2_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x028ED2u: goto L_028ED2;
    case 0x028ED5u: goto L_028ED5;
    case 0x028ED7u: goto L_028ED7;
    case 0x028EDAu: goto L_028EDA;
    case 0x028EDCu: goto L_028EDC;
    case 0x028EDEu: goto L_028EDE;
    case 0x028EE1u: goto L_028EE1;
    case 0x028EE4u: goto L_028EE4;
    case 0x028EE7u: goto L_028EE7;
    case 0x028EE8u: goto L_028EE8;
    case 0x028EEAu: goto L_028EEA;
    case 0x028EECu: goto L_028EEC;
    case 0x028EEEu: goto L_028EEE;
    case 0x028EF1u: goto L_028EF1;
    case 0x028EF4u: goto L_028EF4;
    case 0x028EF5u: goto L_028EF5;
    case 0x028EF7u: goto L_028EF7;
    case 0x028EF9u: goto L_028EF9;
    case 0x028EFBu: goto L_028EFB;
    case 0x028EFEu: goto L_028EFE;
    case 0x028F01u: goto L_028F01;
    case 0x028F02u: goto L_028F02;
    case 0x028F05u: goto L_028F05;
    case 0x028F06u: goto L_028F06;
    case 0x028F07u: goto L_028F07;
    case 0x028F08u: goto L_028F08;
    case 0x028F09u: goto L_028F09;
    case 0x028F0Au: goto L_028F0A;
    case 0x028F0Cu: goto L_028F0C;
    case 0x028F0Eu: goto L_028F0E;
    case 0x028F0Fu: goto L_028F0F;
    case 0x028F10u: goto L_028F10;
    case 0x028F11u: goto L_028F11;
    case 0x028F14u: goto L_028F14;
    case 0x028F17u: goto L_028F17;
    case 0x028F19u: goto L_028F19;
    case 0x028F1Bu: goto L_028F1B;
    case 0x028F1Eu: goto L_028F1E;
    case 0x028F21u: goto L_028F21;
    case 0x028F22u: goto L_028F22;
    case 0x028F23u: goto L_028F23;
    case 0x028F24u: goto L_028F24;
    case 0x028F25u: goto L_028F25;
    case 0x028F27u: goto L_028F27;
    case 0x028F2Au: goto L_028F2A;
    case 0x028F87u: goto L_028F87;
    case 0x028F8Au: goto L_028F8A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_028ED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED2u, 4u + ((((0x1850u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1850u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028ED2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1850u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028ED5;
L_028ED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028ED5 BNE -> $028EDA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_028EDA; }
    goto L_028ED7;
L_028ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u, 3u, 3u, cpu.address("abs", 0x8F87u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028ED7 JMP -> $028F87
    goto L_028F87;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u, 3u, 3u, cpu.address("abs", 0x8F87u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028ED7 JMP -> $028F87
    goto L_028F87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8ED7u,0x028ED7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028EDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDAu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EDA LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x9Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_028EDC;
L_028EDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EDC BNE -> $028EE1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_028EE1; }
    goto L_028EDE;
L_028EDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu, 7u, 3u, cpu.address("absx", 0x1850u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EDE DEC
    cpu.decMem(hw, cpu.address("absx", 0x1850u), cpu.m8?8:16);
    goto L_028EE1;
L_028EE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u, 4u + ((((0x8B78u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8B78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EE1 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x8B78u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_028EE4;
L_028EE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE4u, 4u + ((((0x1808u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1808u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EE4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1808u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028EE7;
L_028EE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EE7 SEC
    cpu.setFlag('C', true);
    goto L_028EE8;
L_028EE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE8u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EE8 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_028EEA;
L_028EEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EEA CMP
    cpu.compareA(0xF0u);
    goto L_028EEC;
L_028EEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EECu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EEC BCS -> $028ED7
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_028ED7; }
    goto L_028EEE;
L_028EEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEEu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEEu, 5u, 3u, cpu.address("absy", 0x0200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EEE STA
    hw.write(cpu.address("absy", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_028EF1;
L_028EF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF1u, 4u + ((((0x17FCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x17FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EF1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x17FCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028EF4;
L_028EF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EF4 SEC
    cpu.setFlag('C', true);
    goto L_028EF5;
L_028EF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EF5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_028EF7;
L_028EF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EF7 CMP
    cpu.compareA(0xF0u);
    goto L_028EF9;
L_028EF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF9u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EF9 BCS -> $028ED7
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_028ED7; }
    goto L_028EFB;
L_028EFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFBu, 5u, 3u, cpu.address("absy", 0x0201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EFB STA
    hw.write(cpu.address("absy", 0x201u), cpu.a, cpu.m8?8:16);
    goto L_028EFE;
L_028EFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFEu, 4u + ((((0x17F0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x17F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EFE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x17F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028F01;
L_028F01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F01u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F01u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $028F01 PHA
    cpu.push("PHA", hw);
    goto L_028F02;
L_028F02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F02u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F02u, 4u + ((((0x1850u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1850u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F02 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1850u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028F05;
L_028F05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F05u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F05 LSR
    cpu.lsrA();
    goto L_028F06;
L_028F06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F06u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F06 LSR
    cpu.lsrA();
    goto L_028F07;
L_028F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F07 LSR
    cpu.lsrA();
    goto L_028F08;
L_028F08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F08u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F08u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F08 TAX
    cpu.transfer("TAX");
    goto L_028F09;
L_028F09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $028F09 PLA
    cpu.pop("PLA", hw);
    goto L_028F0A;
L_028F0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F0A CMP
    cpu.compareA(0x5u);
    goto L_028F0C;
L_028F0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F0C BNE -> $028F11
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_028F11; }
    goto L_028F0E;
L_028F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F0E INX
    cpu.inc('X');
    goto L_028F0F;
L_028F0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F0F INX
    cpu.inc('X');
    goto L_028F10;
L_028F10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F10u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F10u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F10 INX
    cpu.inc('X');
    goto L_028F11;
L_028F11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F11u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F11u, 4u + ((((0x8ECCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8ECCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F11 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8ECCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028F14;
L_028F14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F14u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F14u, 5u, 3u, cpu.address("absy", 0x0202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F14 STA
    hw.write(cpu.address("absy", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_028F17;
L_028F17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F17u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F17u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F17 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028F19;
L_028F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F19 ORA
    cpu.logicOr(0x6u);
    goto L_028F1B;
L_028F1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu, 5u, 3u, cpu.address("absy", 0x0203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F1B STA
    hw.write(cpu.address("absy", 0x203u), cpu.a, cpu.m8?8:16);
    goto L_028F1E;
L_028F1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Eu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Eu, 4u, 3u, cpu.address("abs", 0x1698u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F1E LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1698u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_028F21;
L_028F21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F21u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F21 TYA
    cpu.transfer("TYA");
    goto L_028F22;
L_028F22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F22 LSR
    cpu.lsrA();
    goto L_028F23;
L_028F23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F23u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F23 LSR
    cpu.lsrA();
    goto L_028F24;
L_028F24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F24u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F24 TAY
    cpu.transfer("TAY");
    goto L_028F25;
L_028F25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F25 LDA
    cpu.setA(0x0u, 8);
    goto L_028F27;
L_028F27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F27u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F27u, 5u, 3u, cpu.address("absy", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F27 STA
    hw.write(cpu.address("absy", 0x420u), cpu.a, cpu.m8?8:16);
    goto L_028F2A;
L_028F2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $028F2A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x028F2Au);return;} hw.unresolvedReturn(0x028F2Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_028F87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F87u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F87u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F87u, 5u, 3u, cpu.address("absx", 0x17F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F87 STZ
    hw.write(cpu.address("absx", 0x17F0u), 0, cpu.m8?8:16);
    goto L_028F8A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F87u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F87u, 5u, 3u, cpu.address("absx", 0x17F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F87 STZ
    hw.write(cpu.address("absx", 0x17F0u), 0, cpu.m8?8:16);
    goto L_028F8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F87u,0x028F87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028F8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $028F8A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x028F8Au);return;} hw.unresolvedReturn(0x028F8Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $028F8A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x028F8Au);return;} hw.unresolvedReturn(0x028F8Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F8Au,0x028F8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_028ED2_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x028ED2u: goto L_028ED2;
    case 0x028ED5u: goto L_028ED5;
    case 0x028ED7u: goto L_028ED7;
    case 0x028EDAu: goto L_028EDA;
    case 0x028EDCu: goto L_028EDC;
    case 0x028EDEu: goto L_028EDE;
    case 0x028EE1u: goto L_028EE1;
    case 0x028EE4u: goto L_028EE4;
    case 0x028EE7u: goto L_028EE7;
    case 0x028EE8u: goto L_028EE8;
    case 0x028EEAu: goto L_028EEA;
    case 0x028EECu: goto L_028EEC;
    case 0x028EEEu: goto L_028EEE;
    case 0x028EF1u: goto L_028EF1;
    case 0x028EF4u: goto L_028EF4;
    case 0x028EF5u: goto L_028EF5;
    case 0x028EF7u: goto L_028EF7;
    case 0x028EF9u: goto L_028EF9;
    case 0x028EFBu: goto L_028EFB;
    case 0x028EFEu: goto L_028EFE;
    case 0x028F01u: goto L_028F01;
    case 0x028F02u: goto L_028F02;
    case 0x028F05u: goto L_028F05;
    case 0x028F06u: goto L_028F06;
    case 0x028F07u: goto L_028F07;
    case 0x028F08u: goto L_028F08;
    case 0x028F09u: goto L_028F09;
    case 0x028F0Au: goto L_028F0A;
    case 0x028F0Cu: goto L_028F0C;
    case 0x028F0Eu: goto L_028F0E;
    case 0x028F0Fu: goto L_028F0F;
    case 0x028F10u: goto L_028F10;
    case 0x028F11u: goto L_028F11;
    case 0x028F14u: goto L_028F14;
    case 0x028F17u: goto L_028F17;
    case 0x028F19u: goto L_028F19;
    case 0x028F1Bu: goto L_028F1B;
    case 0x028F1Eu: goto L_028F1E;
    case 0x028F21u: goto L_028F21;
    case 0x028F22u: goto L_028F22;
    case 0x028F23u: goto L_028F23;
    case 0x028F24u: goto L_028F24;
    case 0x028F25u: goto L_028F25;
    case 0x028F27u: goto L_028F27;
    case 0x028F2Au: goto L_028F2A;
    case 0x028F87u: goto L_028F87;
    case 0x028F8Au: goto L_028F8A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_028ED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED2u, 4u + ((((0x1850u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1850u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028ED2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1850u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028ED5;
L_028ED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028ED5 BNE -> $028EDA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_028EDA; }
    goto L_028ED7;
L_028ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u, 3u, 3u, cpu.address("abs", 0x8F87u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028ED7 JMP -> $028F87
    goto L_028F87;
L_028EDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDAu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EDA LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x9Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_028EDC;
L_028EDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EDC BNE -> $028EE1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_028EE1; }
    goto L_028EDE;
L_028EDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu, 7u, 3u, cpu.address("absx", 0x1850u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EDE DEC
    cpu.decMem(hw, cpu.address("absx", 0x1850u), cpu.m8?8:16);
    goto L_028EE1;
L_028EE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u, 4u + ((((0x8B78u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8B78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EE1 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x8B78u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_028EE4;
L_028EE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE4u, 4u + ((((0x1808u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1808u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EE4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1808u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028EE7;
L_028EE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EE7 SEC
    cpu.setFlag('C', true);
    goto L_028EE8;
L_028EE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE8u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EE8 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_028EEA;
L_028EEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EEA CMP
    cpu.compareA(0xF0u);
    goto L_028EEC;
L_028EEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EECu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EEC BCS -> $028ED7
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_028ED7; }
    goto L_028EEE;
L_028EEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEEu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEEu, 5u, 3u, cpu.address("absy", 0x0200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EEE STA
    hw.write(cpu.address("absy", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_028EF1;
L_028EF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF1u, 4u + ((((0x17FCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x17FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EF1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x17FCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028EF4;
L_028EF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EF4 SEC
    cpu.setFlag('C', true);
    goto L_028EF5;
L_028EF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EF5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_028EF7;
L_028EF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EF7 CMP
    cpu.compareA(0xF0u);
    goto L_028EF9;
L_028EF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF9u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EF9 BCS -> $028ED7
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_028ED7; }
    goto L_028EFB;
L_028EFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFBu, 5u, 3u, cpu.address("absy", 0x0201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EFB STA
    hw.write(cpu.address("absy", 0x201u), cpu.a, cpu.m8?8:16);
    goto L_028EFE;
L_028EFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFEu, 4u + ((((0x17F0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x17F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028EFE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x17F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028F01;
L_028F01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F01u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F01u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $028F01 PHA
    cpu.push("PHA", hw);
    goto L_028F02;
L_028F02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F02u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F02u, 4u + ((((0x1850u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1850u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F02 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1850u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028F05;
L_028F05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F05u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F05 LSR
    cpu.lsrA();
    goto L_028F06;
L_028F06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F06u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F06 LSR
    cpu.lsrA();
    goto L_028F07;
L_028F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F07 LSR
    cpu.lsrA();
    goto L_028F08;
L_028F08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F08u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F08u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F08 TAX
    cpu.transfer("TAX");
    goto L_028F09;
L_028F09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $028F09 PLA
    cpu.pop("PLA", hw);
    goto L_028F0A;
L_028F0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F0A CMP
    cpu.compareA(0x5u);
    goto L_028F0C;
L_028F0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F0C BNE -> $028F11
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_028F11; }
    goto L_028F0E;
L_028F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F0E INX
    cpu.inc('X');
    goto L_028F0F;
L_028F0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F0F INX
    cpu.inc('X');
    goto L_028F10;
L_028F10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F10u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F10u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F10 INX
    cpu.inc('X');
    goto L_028F11;
L_028F11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F11u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F11u, 4u + ((((0x8ECCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8ECCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F11 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8ECCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028F14;
L_028F14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F14u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F14u, 5u, 3u, cpu.address("absy", 0x0202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F14 STA
    hw.write(cpu.address("absy", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_028F17;
L_028F17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F17u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F17u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F17 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028F19;
L_028F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F19 ORA
    cpu.logicOr(0x6u);
    goto L_028F1B;
L_028F1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu, 5u, 3u, cpu.address("absy", 0x0203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F1B STA
    hw.write(cpu.address("absy", 0x203u), cpu.a, cpu.m8?8:16);
    goto L_028F1E;
L_028F1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Eu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Eu, 4u, 3u, cpu.address("abs", 0x1698u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F1E LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1698u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_028F21;
L_028F21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F21u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F21 TYA
    cpu.transfer("TYA");
    goto L_028F22;
L_028F22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F22 LSR
    cpu.lsrA();
    goto L_028F23;
L_028F23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F23u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F23 LSR
    cpu.lsrA();
    goto L_028F24;
L_028F24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F24u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F24 TAY
    cpu.transfer("TAY");
    goto L_028F25;
L_028F25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F25 LDA
    cpu.setA(0x0u, 8);
    goto L_028F27;
L_028F27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F27u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F27u, 5u, 3u, cpu.address("absy", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F27 STA
    hw.write(cpu.address("absy", 0x420u), cpu.a, cpu.m8?8:16);
    goto L_028F2A;
L_028F2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $028F2A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x028F2Au);return;} hw.unresolvedReturn(0x028F2Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_028F87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F87u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F87u, 5u, 3u, cpu.address("absx", 0x17F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028F87 STZ
    hw.write(cpu.address("absx", 0x17F0u), 0, cpu.m8?8:16);
    goto L_028F8A;
L_028F8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $028F8A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x028F8Au);return;} hw.unresolvedReturn(0x028F8Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02ACE5_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02ACE5u: goto L_02ACE5;
    case 0x02ACE6u: goto L_02ACE6;
    case 0x02ACE7u: goto L_02ACE7;
    case 0x02ACE9u: goto L_02ACE9;
    case 0x02ACEDu: goto L_02ACED;
    case 0x02ACEEu: goto L_02ACEE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02ACE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE5u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE5u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02ACE5 PHX
    cpu.push("PHX", hw);
    goto L_02ACE6;
L_02ACE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ACE6 CLC
    cpu.setFlag('C', false);
    goto L_02ACE7;
L_02ACE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ACE7 ADC
    cpu.adc(0x5u);
    goto L_02ACE9;
L_02ACE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE9u, 8u, 4u, 0x02ACEFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02ACE9 JSL -> $02ACEF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xACECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xACEDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACEFu, 0x02ACE9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02ACED;
L_02ACED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACEDu,0x02ACEDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEDu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02ACED PLX
    cpu.pop("PLX", hw);
    goto L_02ACEE;
L_02ACEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02ACEE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02ACEEu);return;} hw.unresolvedReturn(0x02ACEEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_02ACE5_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02ACE5u: goto L_02ACE5;
    case 0x02ACE6u: goto L_02ACE6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02ACE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE5u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE5u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02ACE5 PHX
    cpu.push("PHX", hw);
    goto L_02ACE6;
L_02ACE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ACE6 CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACE7u,0x02ACE6u); return;
}

void sub_02ACE5_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02ACE5u: goto L_02ACE5;
    case 0x02ACE6u: goto L_02ACE6;
    case 0x02ACE7u: goto L_02ACE7;
    case 0x02ACE9u: goto L_02ACE9;
    case 0x02ACEDu: goto L_02ACED;
    case 0x02ACEEu: goto L_02ACEE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02ACE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE5u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE5u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02ACE5 PHX
    cpu.push("PHX", hw);
    goto L_02ACE6;
L_02ACE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ACE6 CLC
    cpu.setFlag('C', false);
    goto L_02ACE7;
L_02ACE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ACE7 ADC
    cpu.adc(0x5u);
    goto L_02ACE9;
L_02ACE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACE9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACE9u, 8u, 4u, 0x02ACEFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02ACE9 JSL -> $02ACEF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xACECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xACEDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACEFu, 0x02ACE9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02ACED;
L_02ACED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACEDu,0x02ACEDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEDu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02ACED PLX
    cpu.pop("PLX", hw);
    goto L_02ACEE;
L_02ACEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02ACEE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02ACEEu);return;} hw.unresolvedReturn(0x02ACEEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_02E159_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02E159u: goto L_02E159;
    case 0x02E15Bu: goto L_02E15B;
    case 0x02E15Du: goto L_02E15D;
    case 0x02E15Fu: goto L_02E15F;
    case 0x02E161u: goto L_02E161;
    case 0x02E162u: goto L_02E162;
    case 0x02E164u: goto L_02E164;
    case 0x02E166u: goto L_02E166;
    case 0x02E169u: goto L_02E169;
    case 0x02E16Bu: goto L_02E16B;
    case 0x02E16Du: goto L_02E16D;
    case 0x02E16Fu: goto L_02E16F;
    case 0x02E171u: goto L_02E171;
    case 0x02E174u: goto L_02E174;
    case 0x02E176u: goto L_02E176;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02E159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE159u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE159u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E159 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E15B;
L_02E15B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE15Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E15B BMI -> $02E161
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_02E161; }
    goto L_02E15D;
L_02E15D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE15Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E15D CMP
    cpu.compareA(0x40u);
    goto L_02E15F;
L_02E15F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE15Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E15F BCS -> $02E166
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_02E166; }
    goto L_02E161;
L_02E161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE161u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE161u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE161u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E161 CLC
    cpu.setFlag('C', false);
    goto L_02E162;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE161u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE161u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E161 CLC
    cpu.setFlag('C', false);
    goto L_02E162;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE161u,0x02E161u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02E162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE162u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE162u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E162 ADC
    cpu.adc(0x2u);
    goto L_02E164;
L_02E164:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE164u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE164u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE164u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E164 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_02E166;
L_02E166:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE166u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE166u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE166u, 7u, 3u, cpu.address("absx", 0x1570u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E166 INC
    cpu.incMem(hw, cpu.address("absx", 0x1570u), cpu.m8?8:16);
    goto L_02E169;
L_02E169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE169u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE169u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE169u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E169 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E16B;
L_02E16B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE16Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE16Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE16Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E16B CMP
    cpu.compareA(0xF0u);
    goto L_02E16D;
L_02E16D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE16Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE16Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE16Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E16D BMI -> $02E176
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_02E176; }
    goto L_02E16F;
L_02E16F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE16Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE16Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE16Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E16F LDA
    cpu.setA(0x50u, 8);
    goto L_02E171;
L_02E171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE171u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE171u, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E171 STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_02E174;
L_02E174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE174u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE174u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E174 INC
    cpu.incMem(hw, cpu.address("dpx", 0xC2u), cpu.m8?8:16);
    goto L_02E176;
L_02E176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE176u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE176u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02E176 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02E176u);return;} hw.unresolvedReturn(0x02E176u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02E159_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02E159u: goto L_02E159;
    case 0x02E15Bu: goto L_02E15B;
    case 0x02E15Du: goto L_02E15D;
    case 0x02E15Fu: goto L_02E15F;
    case 0x02E161u: goto L_02E161;
    case 0x02E162u: goto L_02E162;
    case 0x02E164u: goto L_02E164;
    case 0x02E166u: goto L_02E166;
    case 0x02E169u: goto L_02E169;
    case 0x02E16Bu: goto L_02E16B;
    case 0x02E16Du: goto L_02E16D;
    case 0x02E16Fu: goto L_02E16F;
    case 0x02E171u: goto L_02E171;
    case 0x02E174u: goto L_02E174;
    case 0x02E176u: goto L_02E176;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02E159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE159u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE159u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E159 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E15B;
L_02E15B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE15Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E15B BMI -> $02E161
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_02E161; }
    goto L_02E15D;
L_02E15D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE15Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E15D CMP
    cpu.compareA(0x40u);
    goto L_02E15F;
L_02E15F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE15Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE15Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E15F BCS -> $02E166
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_02E166; }
    goto L_02E161;
L_02E161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE161u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE161u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E161 CLC
    cpu.setFlag('C', false);
    goto L_02E162;
L_02E162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE162u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE162u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E162 ADC
    cpu.adc(0x2u);
    goto L_02E164;
L_02E164:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE164u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE164u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE164u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E164 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_02E166;
L_02E166:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE166u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE166u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE166u, 7u, 3u, cpu.address("absx", 0x1570u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E166 INC
    cpu.incMem(hw, cpu.address("absx", 0x1570u), cpu.m8?8:16);
    goto L_02E169;
L_02E169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE169u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE169u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE169u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E169 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02E16B;
L_02E16B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE16Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE16Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE16Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E16B CMP
    cpu.compareA(0xF0u);
    goto L_02E16D;
L_02E16D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE16Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE16Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE16Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E16D BMI -> $02E176
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_02E176; }
    goto L_02E16F;
L_02E16F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE16Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE16Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE16Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E16F LDA
    cpu.setA(0x50u, 8);
    goto L_02E171;
L_02E171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE171u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE171u, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E171 STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_02E174;
L_02E174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE174u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE174u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02E174 INC
    cpu.incMem(hw, cpu.address("dpx", 0xC2u), cpu.m8?8:16);
    goto L_02E176;
L_02E176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE176u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE176u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02E176 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02E176u);return;} hw.unresolvedReturn(0x02E176u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04E9EC_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04E9ECu: goto L_04E9EC;
    case 0x04E9EFu: goto L_04E9EF;
    case 0x04E9F1u: goto L_04E9F1;
    case 0x04E9F3u: goto L_04E9F3;
    case 0x04EA4Bu: goto L_04EA4B;
    case 0x04EA5Au: goto L_04EA5A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04E9EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu, 4u, 3u, cpu.address("abs", 0x1DEAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E9EC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DEAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E9EF;
L_04E9EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E9EF STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_04E9F1;
L_04E9F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E9F1 LDX
    cpu.setX(0x2Bu, 8);
    goto L_04E9F3;
L_04E9F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9F3u, 5u, 4u, ((0x04E8E4u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E9F3 CMP
    cpu.compareA(hw.readW(((0x4E8E4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9F7u,0x04E9F3u); return;
L_04EA4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA4Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA4Bu,0x04EA4Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu, 3u, 3u, cpu.address("abs", 0xEA5Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EA4B JMP -> $04EA5A
    goto L_04EA5A;
L_04EA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EA5A SEP
    cpu.sep(0x30u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,0x04EA5Au); return;
}

void sub_04E9EC_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04E9ECu: goto L_04E9EC;
    case 0x04E9EFu: goto L_04E9EF;
    case 0x04EA4Bu: goto L_04EA4B;
    case 0x04EA5Au: goto L_04EA5A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04E9EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ECu, 4u, 3u, cpu.address("abs", 0x1DEAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E9EC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DEAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E9EF;
L_04E9EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9EFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E9EF STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9F1u,0x04E9EFu); return;
L_04EA4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA4Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA4Bu,0x04EA4Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu, 3u, 3u, cpu.address("abs", 0xEA5Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EA4B JMP -> $04EA5A
    goto L_04EA5A;
L_04EA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EA5A SEP
    cpu.sep(0x30u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,0x04EA5Au); return;
}

void sub_0DA68E_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA68Eu: goto L_0DA68E;
    case 0x0DA691u: goto L_0DA691;
    case 0x0DA695u: goto L_0DA695;
    case 0x0DA697u: goto L_0DA697;
    case 0x0DA699u: goto L_0DA699;
    case 0x0DA69Cu: goto L_0DA69C;
    case 0x0DA69Eu: goto L_0DA69E;
    case 0x0DA6A0u: goto L_0DA6A0;
    case 0x0DA6A1u: goto L_0DA6A1;
    case 0x0DA6A4u: goto L_0DA6A4;
    case 0x0DA6A6u: goto L_0DA6A6;
    case 0x0DA6A9u: goto L_0DA6A9;
    case 0x0DA6ACu: goto L_0DA6AC;
    case 0x0DA6AEu: goto L_0DA6AE;
    case 0x0DA6B0u: goto L_0DA6B0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA68E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Eu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Eu, 4u, 3u, cpu.address("abs", 0x13BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA68E LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13BFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DA691;
L_0DA691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA691u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA691u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA691u, 5u, 4u, ((0x001EA2u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA691 LDA
    cpu.loadA(hw.readW(((0x1EA2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA695;
L_0DA695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA695u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA695u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA695 AND
    cpu.logicAnd(0x40u);
    goto L_0DA697;
L_0DA697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA697 BNE -> $0DA6B0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA6B0; }
    goto L_0DA699;
L_0DA699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u, 4u, 3u, cpu.address("abs", 0x13CEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA699 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA69C;
L_0DA69C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA69C BNE -> $0DA6B0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA6B0; }
    goto L_0DA69E;
L_0DA69E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA69E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DA6A0;
L_0DA6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA6A0 DEY
    cpu.decReg('Y');
    goto L_0DA6A1;
L_0DA6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA6A1 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xA6A3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6A4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DA6A1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA6A4;
L_0DA6A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6A4u,0x0DA6A4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA6A4 LDA
    cpu.setA(0x35u, 8);
    goto L_0DA6A6;
L_0DA6A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A6u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA6A6 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xA6A8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6A9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DA6A6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA6A9;
L_0DA6A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A9u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA6A9 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xA6ABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6ACu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DA6A9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA6AC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A9u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA6A9 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xA6ABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6ACu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DA6A9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA6AC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6A9u,0x0DA6A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DA6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ACu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA6AC LDA
    cpu.setA(0x38u, 8);
    goto L_0DA6AE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA6AC LDA
    cpu.setA(0x38u, 8);
    goto L_0DA6AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6ACu,0x0DA6ACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DA6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DA6AE STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA6B0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DA6AE STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA6B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6AEu,0x0DA6AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0DA6B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA6B0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA6B0u);return;} hw.unresolvedReturn(0x0DA6B0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA6B0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA6B0u);return;} hw.unresolvedReturn(0x0DA6B0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6B0u,0x0DA6B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_0DA68E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA68Eu: goto L_0DA68E;
    case 0x0DA691u: goto L_0DA691;
    case 0x0DA695u: goto L_0DA695;
    case 0x0DA697u: goto L_0DA697;
    case 0x0DA699u: goto L_0DA699;
    case 0x0DA69Cu: goto L_0DA69C;
    case 0x0DA69Eu: goto L_0DA69E;
    case 0x0DA6A0u: goto L_0DA6A0;
    case 0x0DA6A1u: goto L_0DA6A1;
    case 0x0DA6A4u: goto L_0DA6A4;
    case 0x0DA6A6u: goto L_0DA6A6;
    case 0x0DA6A9u: goto L_0DA6A9;
    case 0x0DA6ACu: goto L_0DA6AC;
    case 0x0DA6AEu: goto L_0DA6AE;
    case 0x0DA6B0u: goto L_0DA6B0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA68E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Eu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Eu, 4u, 3u, cpu.address("abs", 0x13BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA68E LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13BFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DA691;
L_0DA691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA691u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA691u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA691u, 5u, 4u, ((0x001EA2u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA691 LDA
    cpu.loadA(hw.readW(((0x1EA2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA695;
L_0DA695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA695u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA695u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA695 AND
    cpu.logicAnd(0x40u);
    goto L_0DA697;
L_0DA697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA697 BNE -> $0DA6B0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA6B0; }
    goto L_0DA699;
L_0DA699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u, 4u, 3u, cpu.address("abs", 0x13CEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA699 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA69C;
L_0DA69C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA69C BNE -> $0DA6B0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA6B0; }
    goto L_0DA69E;
L_0DA69E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA69E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DA6A0;
L_0DA6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA6A0 DEY
    cpu.decReg('Y');
    goto L_0DA6A1;
L_0DA6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA6A1 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xA6A3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6A4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DA6A1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA6A4;
L_0DA6A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6A4u,0x0DA6A4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA6A4 LDA
    cpu.setA(0x35u, 8);
    goto L_0DA6A6;
L_0DA6A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A6u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA6A6 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xA6A8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6A9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DA6A6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA6A9;
L_0DA6A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6A9u,0x0DA6A9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A9u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA6A9 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xA6ABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6ACu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DA6A9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA6AC;
L_0DA6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6ACu,0x0DA6ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA6AC LDA
    cpu.setA(0x38u, 8);
    goto L_0DA6AE;
L_0DA6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DA6AE STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA6B0;
L_0DA6B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA6B0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA6B0u);return;} hw.unresolvedReturn(0x0DA6B0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB571_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB571u: goto L_0DB571;
    case 0x0DB573u: goto L_0DB573;
    case 0x0DB575u: goto L_0DB575;
    case 0x0DB576u: goto L_0DB576;
    case 0x0DB578u: goto L_0DB578;
    case 0x0DB579u: goto L_0DB579;
    case 0x0DB57Cu: goto L_0DB57C;
    case 0x0DB580u: goto L_0DB580;
    case 0x0DB582u: goto L_0DB582;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB571u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB571u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB571 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB573;
L_0DB573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB573u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB573u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB573 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB575;
L_0DB575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB575u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB575u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB575 SEC
    cpu.setFlag('C', true);
    goto L_0DB576;
L_0DB576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB576u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB576u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB576 SBC
    cpu.sbc(0x68u);
    goto L_0DB578;
L_0DB578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB578u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB578u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB578u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB578 TAX
    cpu.transfer("TAX");
    goto L_0DB579;
L_0DB579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB579u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB579u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB579 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB57Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB57Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB579u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB57C;
L_0DB57C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB57Cu,0x0DB57Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Cu, 5u, 4u, ((0x0DB569u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB57C LDA
    cpu.loadA(hw.readW(((0xDB569u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB580;
L_0DB580:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB580u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB580u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB580u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB580 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DB582;
L_0DB582:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB582u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB582 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB582u);return;} hw.unresolvedReturn(0x0DB582u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DE971_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DE971u: goto L_0DE971;
    case 0x0DE973u: goto L_0DE973;
    case 0x0DE975u: goto L_0DE975;
    case 0x0DE977u: goto L_0DE977;
    case 0x0DE97Au: goto L_0DE97A;
    case 0x0DE97Cu: goto L_0DE97C;
    case 0x0DE97Eu: goto L_0DE97E;
    case 0x0DE97Fu: goto L_0DE97F;
    case 0x0DE981u: goto L_0DE981;
    case 0x0DE983u: goto L_0DE983;
    case 0x0DE984u: goto L_0DE984;
    case 0x0DE986u: goto L_0DE986;
    case 0x0DE988u: goto L_0DE988;
    case 0x0DE98Au: goto L_0DE98A;
    case 0x0DE98Cu: goto L_0DE98C;
    case 0x0DE98Eu: goto L_0DE98E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DE971:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE971u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE971u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE971u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE971 LDA
    cpu.setA(0x3u, 8);
    goto L_0DE973;
L_0DE973:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE973u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE973u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE973u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE973 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DE975;
L_0DE975:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE975u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE975u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE975u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE975 LDY
    cpu.setY(0x0u, 8);
    goto L_0DE977;
L_0DE977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE977u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE977u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE977 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xE979u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE97Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DE977u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE97A;
L_0DE97A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE97Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE97Au,0x0DE97Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE97A LDA
    cpu.setA(0x77u, 8);
    goto L_0DE97C;
L_0DE97C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE97Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Cu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Cu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DE97C STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DE97E;
L_0DE97E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE97Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE97E INY
    cpu.inc('Y');
    goto L_0DE97F;
L_0DE97F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE97Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE97F BNE -> $0DE977
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DE977; }
    goto L_0DE981;
L_0DE981:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE981u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE981u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE981u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE981 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DE983;
L_0DE983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE983u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE983u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE983 CLC
    cpu.setFlag('C', false);
    goto L_0DE984;
L_0DE984:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE984u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE984u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE984u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE984 ADC
    cpu.adc(0x1u);
    goto L_0DE986;
L_0DE986:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE986u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE986u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE986u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE986 STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0DE988;
L_0DE988:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE988u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE988u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE988u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE988 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0DE98A;
L_0DE98A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE98Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Au,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE98A DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DE98C;
L_0DE98C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE98Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE98C BPL -> $0DE977
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DE977; }
    goto L_0DE98E;
L_0DE98E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE98Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE98E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DE98Eu);return;} hw.unresolvedReturn(0x0DE98Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

